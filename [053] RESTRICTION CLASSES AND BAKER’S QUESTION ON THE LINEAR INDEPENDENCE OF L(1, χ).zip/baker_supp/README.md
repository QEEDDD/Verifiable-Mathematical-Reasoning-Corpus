# Supplementary material: "Restriction classes and Baker's question on the linear independence of L(1, χ)"

Author: Keio (24 October 2026).

The material here supports the computations of Sections 4 and 5 of the paper (`paper/baker_question_restriction_classes.tex`).
All arithmetic is exact: integers, finite fields and exact ranks.
Requirements: Python 3, numpy, sympy and python-flint.

## Layout

| Path | Contents |
|---|---|
| `code/baker_classes.py` | Unit-group structure of (Z/qZ)^× (discrete logarithms). Imported by the certifier. |
| `code/baker_classes_fast.py` | **Theorem D for q ≤ 10^4.** Class-by-class certificates (Lemma 5.1). Usage: `python3 baker_classes_fast.py qlo qhi logfile`. Moduli with φ(δ) ≤ 2 are skipped, because Corollary B covers them. |
| `code/baker_rank2.py` | Independent cross-check that does not use Theorem A. It computes the exact Z-rank of the vectors q·W_χ (χ odd) in Z[ζ_N]. Usage: `python3 baker_rank2.py qlo qhi logfile`. |
| `code/fermat_rank.py` | **Theorem D for q = p², p < 5000.** Rank of the matrix of Theorem 4.3 modulo 2^61 − 1. Usage: `python3 fermat_rank.py lo hi`. |
| `code/psquare_criterion_fast.py` | Fermat quotients, β_j (Lemma 4.5), the characters of U_{2^v}, and the first-order sums S_β. |
| `code/psquare_criterion.py` | Slow, direct implementation of the first-order sums. Used only to cross-check the fast version. |
| `code/psquare_twoterm.py` | **Condition (C_p)** of Theorem 4.8(4): the sums S_β and S_γ. Usage: `python3 psquare_twoterm.py pmin pmax`. |
| `code/padic_valuations.py` | Direct π-adic expansion of π·e_1(ω^j) in F_p[π]/(π^R) from the definition. It checks Lemma 4.6 and computes the valuations of the isotypic elements. Usage: `python3 padic_valuations.py pmin pmax R`. |
| `code/checks/` | Numerical checks of individual lemmas; see the next section. Run them from inside `code/checks/`. |
| `logs/` | Output of all runs used in the paper. |
| `independent_review/` | Scripts and report of an independent check of the paper (if present). |

## Checks (`code/checks/`)

| Script | What it checks |
|---|---|
| `check_psquare_class.py` | Lemma 4.1: the Gauss sum and the formula for L(1, θψ_c), compared numerically with the cotangent formula (p = 5, 7, 11). |
| `check_lemmas.py` | The Bernoulli-number formula of Lemma 4.1. Also checks Σ λ(b)·b·q(b) ≡ −B_k/k ≡ h(−p) (mod p) for p ≡ 3 (mod 4). |
| `check_criterion_impl.py` | β_j against Bernoulli numbers (p < 400). Also checks the fast first-order sums against the slow implementation (p < 1200). |
| `check_second_coeff.py` | The π²-coefficient c·γ_j of Lemma 4.6 (p < 300, several c). Also checks Lemma 4.7: both coordinates of B_{1,θ} are odd for θ quartic and p ≡ 5 (mod 8), p < 20000. |
| `check_gamma_derivative.py` | γ_j ≡ −(B_{j+p}/(j+p) − B_{j+1}/(j+1))/p (mod p) (Remark 4.9). |
| `exactB.py` | Exact B_{1,θ} for θ of order 8 (Remark 4.9: for p = 41, B_{1,θ} = −1 + i − √2). |
| `counts.py` | The counts of moduli in Remark 3.4. |
| `inspect_vanishing.py`, `resolvents.py` | Exploratory: which first-order sums vanish and why. |

## Logs used in the paper

| Log | Contents |
|---|---|
| `logs/classes_3_10000.txt` | 2708 moduli with φ(δ) ≥ 4 and 964,083 classes, all of full rank. Final line: `DONE 3..10000: trivial(phi(delta)<=2)=7290 checked=2708 deficient=[]`. |
| `logs/baker_3_60.txt`, `logs/baker_61_200.txt` | Exact ranks over Q for 3 ≤ q ≤ 200. All moduli are independent. |
| `logs/star_3_5000.txt` | The criterion of Theorem 4.3 for all primes p < 5000. |
| `logs/twoterm_5_3000.txt`, `logs/twoterm_3001_200000.txt` | Condition (C_p). The paper uses all primes p < 1.6·10^5 of the form 2^v·ℓ + 1 with v ≥ 2: 1138 primes, and (C_p) holds for all of them. The second run stopped at p = 163733, before the prime 163841 (v = 15). Primes above 1.6·10^5 are not used in the paper. |
| `logs/padic_valuations_5_1200.txt` | Direct π-adic expansions for p < 1200. |
| `logs/check_*.txt` | Output of the check scripts. |
| `logs/criterion_5_3000.txt` | The first-order condition alone, p < 3000. It fails for many v ≥ 3 primes (Remark 4.9). |

## Approximate run times on one core

| Run | Time |
|---|---|
| Classes for q ≤ 10^4 | about 35 minutes |
| Theorem 4.3 for p < 5000 | about 40 minutes |
| (C_p) for p < 1.6·10^5 | about 30 minutes |
