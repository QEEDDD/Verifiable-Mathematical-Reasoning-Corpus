"""Baker's question, odd part, verified class by class.

For q >= 3 let m = lambda(q) (exponent of U_q), delta = gcd(q, m), H = ker(U_q -> U_delta).
Class reduction: Q-linear relations among W_chi = sum_a chi(a) y_a, y_a = (z^a+1)/(z^a-1), z = e^{2 pi i/q}
(L(1,chi) = pi i W_chi/(2q) for odd chi) split along the classes {chi odd : chi|_H = given}.
A class with one element is trivially independent (W_chi != 0).  For each class with k >= 2 elements
we certify Q-independence by exhibiting k embeddings sigma_j of Q(zeta_N) (N = lcm(q,m)) into F_ell
(ell prime, ell = 1 mod N) for which the k x k matrix (sigma_j(q W_chi)) is nonsingular mod ell:
an integer relation sum x_chi W_chi = 0 with gcd(x)=1 would give a nonzero kernel vector mod ell.

Usage: python3 baker_classes.py qlo qhi [logfile]"""
import sys, random
from math import gcd
from itertools import product
import sympy
import flint

def lcm(a, b): return a * b // gcd(a, b)

def unit_structure(q):
    """generators/orders of U_q as a product of cyclic groups, with discrete logs."""
    f = sympy.factorint(q)
    comps = []
    for p, e in sorted(f.items()):
        pe = p ** e
        if p == 2:
            if e == 1: continue
            comps.append((pe, 'm1', 2))
            if e >= 3: comps.append((pe, 'five', 2 ** (e - 2)))
        else:
            comps.append((pe, int(sympy.primitive_root(pe)), (p - 1) * p ** (e - 1)))
    tabs = []
    for pe, kind, o in comps:
        if kind == 'm1':
            tabs.append(None)
        else:
            g = 5 if kind == 'five' else kind
            t, x, tab = 0, 1, {}
            while t < o:
                tab[x] = t; x = x * g % pe; t += 1
            tabs.append(tab)
    units = [a for a in range(1, q) if gcd(a, q) == 1]
    dl = {}
    for a in units:
        v = []
        for (pe, kind, o), tab in zip(comps, tabs):
            r = a % pe
            if kind == 'm1':
                v.append(0 if r % 4 == 1 else 1)
            elif kind == 'five':
                r2 = r if r % 4 == 1 else (pe - r) % pe
                v.append(tab[r2])
            else:
                v.append(tab[r])
        dl[a] = v
    orders = [o for _, _, o in comps]
    m = 1
    for o in orders: m = lcm(m, o)
    return units, dl, orders, m

def find_prime(N, start=None):
    k = (start or (2 ** 40)) // N + 1
    while True:
        ell = k * N + 1
        if sympy.isprime(ell):
            return ell
        k += 1

def element_of_order(N, ell):
    fac = sympy.factorint(N)
    while True:
        x = random.randrange(2, ell - 1)
        g = pow(x, (ell - 1) // N, ell)
        if all(pow(g, N // p, ell) != 1 for p in fac):
            return g

def check(q, extra=3, seed=1):
    random.seed(seed + q)
    units, dl, orders, m = unit_structure(q)
    delta = gcd(q, m)
    phid = int(sympy.totient(delta))
    if phid <= 2:
        return ('trivial', delta, 0, 0)
    N = lcm(q, m)
    H = [s for s in units if (s - 1) % delta == 0]
    # odd characters: exponent function e(a) in Z/m
    chars = {}
    for ks in product(*[range(o) for o in orders]):
        e = {a: sum(k * (m // o) * x for k, o, x in zip(ks, orders, dl[a])) % m for a in units}
        if e[q - 1] != m // 2:
            continue
        key = tuple(e[s] for s in H)
        chars.setdefault(key, []).append(e)
    ell = find_prime(N)
    g = element_of_order(N, ell)
    worst = 0; nclass = 0; maxk = 0
    # one embedding per element of Gal(K/Q), K = Q(zeta_m): rows from the same coset of
    # Gal(Q(zeta_N)/K) are proportional on a class (common factor), so these rows realise
    # the full embedding rank of the class.
    seen = {}
    for j in range(1, N):
        if gcd(j, N) == 1 and (j % m) not in seen:
            seen[j % m] = j
    reps = sorted(seen.values())
    for key, cls in chars.items():
        k = len(cls)
        maxk = max(maxk, k)
        if k == 1:
            continue
        nclass += 1
        js = reps
        rows = []
        for j in js:
            gj = pow(g, j, ell)
            zq = pow(gj, N // q, ell); zm = pow(gj, N // m, ell)
            Y = {}
            for a in units:
                t = pow(zq, a, ell)
                Y[a] = (t + 1) * pow(t - 1, ell - 2, ell) % ell
            pw = [1] * m
            for r in range(1, m): pw[r] = pw[r - 1] * zm % ell
            rows.append([sum(pw[e[a]] * Y[a] for a in units) % ell for e in cls])
        M = flint.nmod_mat(rows, ell)
        r = M.rank()
        worst = max(worst, k - r)
    return ('checked', delta, nclass, worst, maxk)

if __name__ == '__main__':
    lo, hi = int(sys.argv[1]), int(sys.argv[2])
    log = sys.argv[3] if len(sys.argv) > 3 else None
    bad = []
    for q in range(lo, hi + 1):
        if q % 4 == 2 and False:
            pass
        res = check(q)
        if res[0] == 'trivial':
            line = f'{q} delta={res[1]} trivial(phi(delta)<=2)'
        else:
            _, delta, nclass, worst, maxk = res
            line = f'{q} delta={delta} classes>=2:{nclass} maxk={maxk} deficiency={worst}'
            if worst: bad.append(q)
        print(line, flush=True)
        if log:
            with open(log, 'a') as fh: fh.write(line + '\n')
    print('DONE', lo, hi, 'deficient moduli:', bad, flush=True)
    if log:
        with open(log, 'a') as fh: fh.write(f'DONE {lo} {hi} deficient: {bad}\n')
