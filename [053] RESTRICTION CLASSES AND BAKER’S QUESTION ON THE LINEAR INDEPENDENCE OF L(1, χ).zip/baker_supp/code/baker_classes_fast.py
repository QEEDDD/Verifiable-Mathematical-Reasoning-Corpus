"""Fast class-by-class certification of Baker's question (odd part) -- numpy version.
Same certificate as baker_classes.py: for each restriction class (size k >= 2) the matrix
(sigma_t(q W_chi))_{t in U_m, chi in class} has rank k modulo a prime ell = 1 (mod N).
Moduli with phi(gcd(q, lambda(q))) <= 2 are covered by the class reduction (all classes are singletons).
Usage: python3 baker_classes_fast.py qlo qhi logfile"""
import sys, random
from math import gcd
from itertools import product
import numpy as np
import sympy, flint
from baker_classes import unit_structure, lcm

def prime_1_mod(N, lo):
    k = lo // N + 1
    while True:
        ell = k * N + 1
        if sympy.isprime(ell): return ell
        k += 1

def elt_order(N, ell):
    fac = sympy.factorint(N)
    rnd = random.Random(N)
    while True:
        g = pow(rnd.randrange(2, ell - 1), (ell - 1) // N, ell)
        if all(pow(g, N // p, ell) != 1 for p in fac): return g

def check(q):
    units, dl, orders, m = unit_structure(q)
    delta = gcd(q, m)
    if int(sympy.totient(delta)) <= 2:
        return None
    N = lcm(q, m)
    H = [s for s in units if (s - 1) % delta == 0]
    U = np.array(units, dtype=np.int64)
    D = np.array([dl[a] for a in units], dtype=np.int64)          # (phi(q), r)
    Ev = []; keys = []
    ia = {a: i for i, a in enumerate(units)}
    Hidx = [ia[s] for s in H]
    for ks in product(*[range(o) for o in orders]):
        coef = np.array([k * (m // o) for k, o in zip(ks, orders)], dtype=np.int64)
        e = (D @ coef) % m
        if e[ia[q - 1]] != m // 2: continue
        Ev.append(e); keys.append(tuple(e[Hidx].tolist()))
    E = np.array(Ev, dtype=np.int64)                                 # (#odd, phi(q))
    classes = {}
    for i, k in enumerate(keys): classes.setdefault(k, []).append(i)
    big = [idx for idx in classes.values() if len(idx) >= 2]
    if not big:
        return (delta, 0, 1, 0)
    lo = 2 ** 24 if N < 2 ** 23 else 2 ** 40
    ell = prime_1_mod(N, lo)
    use_np = ell < 2 ** 26
    g = elt_order(N, ell)
    reps = {}
    for j in range(1, N):
        if gcd(j, N) == 1 and (j % m) not in reps: reps[j % m] = j
    reps = list(reps.values())
    random.Random(q).shuffle(reps)
    def row(j):
        gj = pow(g, j, ell); zq = pow(gj, N // q, ell); zm = pow(gj, N // m, ell)
        tq = [pow(zq, int(a), ell) for a in units]
        Y = [(t + 1) * pow(t - 1, ell - 2, ell) % ell for t in tq]
        pw = [1] * m
        for r in range(1, m): pw[r] = pw[r - 1] * zm % ell
        if use_np:
            Yn = np.array(Y, dtype=np.uint64); pwn = np.array(pw, dtype=np.uint64)
            acc = np.zeros(E.shape[0], dtype=np.uint64)
            for c0 in range(0, E.shape[1], 2048):
                blk = (pwn[E[:, c0:c0 + 2048]] * Yn[None, c0:c0 + 2048]).sum(axis=1) % np.uint64(ell)
                acc = (acc + blk) % np.uint64(ell)
            return [int(x) for x in acc]
        return [sum(pw[int(E[c, a])] * Y[a] for a in range(len(units))) % ell for c in range(E.shape[0])]
    maxk = max(len(idx) for idx in big)
    rows = []
    pending = list(range(len(big)))
    pos = 0
    batch = max(4, maxk + 2)
    while pending and pos < len(reps):
        for j in reps[pos:pos + batch]:
            rows.append(row(j))
        pos += batch
        batch = max(4, batch // 2)
        still = []
        for b in pending:
            idx = big[b]
            k = len(idx)
            if len(rows) < k:
                still.append(b); continue
            rk = flint.nmod_mat([[r[c] for c in idx] for r in rows], ell).rank()
            if rk < k: still.append(b)
        pending = still
    worst = 0
    for b in pending:
        idx = big[b]
        rk = flint.nmod_mat([[r[c] for c in idx] for r in rows], ell).rank()
        worst = max(worst, len(idx) - rk)
    return (delta, len(big), maxk, worst)

if __name__ == '__main__':
    lo, hi, log = int(sys.argv[1]), int(sys.argv[2]), sys.argv[3]
    bad = []; ntriv = 0; nchk = 0
    for q in range(lo, hi + 1):
        res = check(q)
        if res is None:
            ntriv += 1
            continue
        delta, nb, maxk, worst = res
        nchk += 1
        line = f'{q} delta={delta} classes>=2:{nb} maxk={maxk} deficiency={worst}'
        if worst: bad.append(q)
        with open(log, 'a') as fh: fh.write(line + '\n')
    summary = f'DONE {lo}..{hi}: trivial(phi(delta)<=2)={ntriv} checked={nchk} deficient={bad}'
    with open(log, 'a') as fh: fh.write(summary + '\n')
    print(summary, flush=True)
