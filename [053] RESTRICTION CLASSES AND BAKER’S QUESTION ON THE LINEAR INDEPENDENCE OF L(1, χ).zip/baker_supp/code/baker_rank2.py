"""General q (odd or even): exact Q-rank of {W_chi : chi odd mod q}, where
L(1,chi) = (pi i/(2q)) * W_chi... precisely L(1,chi) = (pi/(2q)) sum_a chi(a) cot(pi a/q),
cot(pi a/q) = i (z^a+1)/(z^a-1), z = exp(2 pi i/q).  W_chi := sum_a chi(a) (z^a+1)/(z^a-1)."""
import sys
from math import gcd
from itertools import product
import numpy as np
import flint
import sympy

def lcm(a, b): return a * b // gcd(a, b)

def cyclic_components(q):
    """list of (modulus pe, generator g, order o) such that U_q = prod <g_i> (CRT lifts handled by idx)."""
    f = sympy.factorint(q)
    comps = []
    for p, e in sorted(f.items()):
        pe = p ** e
        if p == 2:
            if e == 1:
                continue
            if e == 2:
                comps.append((pe, 3, 2))          # U_4 = <-1>
            else:
                comps.append((pe, pe - 1, 2))     # <-1>
                comps.append((pe, 5, 2 ** (e - 2)))
        else:
            comps.append((pe, int(sympy.primitive_root(pe)), (p - 1) * p ** (e - 1)))
    return comps

def char_setup(q):
    comps = cyclic_components(q)
    units = [a for a in range(1, q) if gcd(a, q) == 1]
    m = 1
    for _, _, o in comps:
        m = lcm(m, o)
    # discrete log of a in each component (for 2-power: decompose a mod 2^e = (-1)^s 5^t)
    f = sympy.factorint(q)
    idx = {}
    for a in units:
        v = []
        for p, e in sorted(f.items()):
            pe = p ** e
            if p == 2:
                if e == 1:
                    continue
                r = a % pe
                if e == 2:
                    v.append(0 if r == 1 else 1)
                else:
                    s = 0 if r % 4 == 1 else 1
                    r2 = r if s == 0 else (pe - r) % pe
                    t, x = 0, 1
                    while x != r2:
                        x = x * 5 % pe; t += 1
                    v.append(s); v.append(t)
            else:
                g = int(sympy.primitive_root(pe))
                t, x = 0, 1
                while x != a % pe:
                    x = x * g % pe; t += 1
                v.append(t)
        idx[a] = tuple(v)
    return comps, m, units, idx

def odd_characters(q):
    comps, m, units, idx = char_setup(q)
    orders = [o for _, _, o in comps]
    chars = []
    for ks in product(*[range(o) for o in orders]):
        e = {a: sum(k * (m // o) * ia for k, o, ia in zip(ks, orders, idx[a])) % m for a in units}
        if e[q - 1] == m // 2:
            chars.append((ks, e))
    return m, units, chars

_phi_cache = {}
def cyclo(N):
    if N not in _phi_cache:
        x = sympy.Symbol('x')
        _phi_cache[N] = flint.fmpz_poly([int(c) for c in sympy.Poly(sympy.cyclotomic_poly(N, x)).all_coeffs()[::-1]])
    return _phi_cache[N]

def rank_for(q):
    m, units, chars = odd_characters(q)
    if not chars:
        return 0, 0, None, m
    N = lcm(q, m)
    sq, sm = N // q, N // m
    ks = np.arange(q, dtype=np.int64)
    Y = {}
    for a in units:
        v = np.zeros(N, dtype=np.int64)
        v[0] += q
        np.add.at(v, (sq * ((a * ks) % q)) % N, 2 * ks)
        Y[a] = v
    Phi = cyclo(N); deg = Phi.degree()
    rows = []
    for ks_, e in chars:
        w = np.zeros(N, dtype=np.int64)
        for a in units:
            w += np.roll(Y[a], sm * e[a])
        R = flint.fmpz_poly([int(x) for x in w]) % Phi
        rows.append([int(R[i]) for i in range(deg)])
    M = flint.fmpz_mat(len(rows), deg, [x for r in rows for x in r])
    return len(chars), M.rank(), N, m

if __name__ == "__main__":
    lo, hi = int(sys.argv[1]), int(sys.argv[2])
    out = open(sys.argv[3], 'w') if len(sys.argv) > 3 else None
    bad = []
    for q in range(lo, hi + 1):
        n, r, N, m = rank_for(q)
        line = f"{q} oddchars {n} rank {r} N {N} m {m} gcd(q,phi) {gcd(q, int(sympy.totient(q)))} {'IND' if r == n else 'DEP'}"
        if r != n:
            bad.append(q)
        if out:
            out.write(line + "\n"); out.flush()
        else:
            print(line, flush=True)
    msg = f"DONE q in [{lo},{hi}]; dependent moduli: {bad}"
    if out:
        out.write(msg + "\n"); out.close()
    print(msg)
