"""Cross-check psquare_criterion_fast against (i) Bernoulli numbers from sympy and (ii) the slow direct
implementation psquare_criterion.check_p, for small primes."""
import sys, sympy
from fractions import Fraction
sys.path.insert(0, '..')
sys.path.insert(0, '.')
import psquare_criterion_fast as F
import psquare_criterion as S

def beta_exact(p, j):
    B = sympy.bernoulli(j + 1)
    fr = Fraction(int(B.p), int(B.q)) / (j + 1)
    return fr.numerator * pow(fr.denominator, -1, p) % p

bad = 0
for p in sympy.primerange(5, 400):
    q = F.fermat_quotients(p)
    g = sympy.primitive_root(p)
    js = [j for j in range(1, p - 3, 2)]
    b = F.betas(p, js, q, g)
    for j in js:
        if b[j] != beta_exact(p, j):
            bad += 1
print('beta mismatches for p<400:', bad)
agree = 0; total = 0
for p in sympy.primerange(5, 1200):
    r = F.check_p(p, slow=True)
    if r is None: continue
    kind, ok = S.check_p(p)
    total += 1
    agree += ((r[2] == 0) == ok)
print('fast vs slow agreement:', agree, '/', total)
