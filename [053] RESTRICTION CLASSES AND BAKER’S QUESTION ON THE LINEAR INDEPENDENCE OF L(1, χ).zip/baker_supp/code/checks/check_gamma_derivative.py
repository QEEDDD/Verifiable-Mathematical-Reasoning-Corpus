"""gamma_j = (1/2) sum_b b^{j+1} q(b)^2  vs  -(B_{k+p-1}/(k+p-1) - B_k/k)/p mod p, k = j+1."""
import sympy
from fractions import Fraction
def fr(B): return Fraction(int(B.p), int(B.q))
bad = tot = 0
for p in sympy.primerange(7, 60):
    for k in range(4, p - 2, 2):
        j = k - 1
        g = sum(pow(b, k, p) * (((pow(b, p - 1, p * p) - 1) // p) % p) ** 2 for b in range(1, p)) * pow(2, p - 2, p) % p
        d = (fr(sympy.bernoulli(k + p - 1)) / (k + p - 1) - fr(sympy.bernoulli(k)) / k) / p
        dv = d.numerator * pow(d.denominator, -1, p) % p
        tot += 1
        bad += (g != (-dv) % p)
print('gamma vs Bernoulli derivative: mismatches', bad, 'of', tot)
