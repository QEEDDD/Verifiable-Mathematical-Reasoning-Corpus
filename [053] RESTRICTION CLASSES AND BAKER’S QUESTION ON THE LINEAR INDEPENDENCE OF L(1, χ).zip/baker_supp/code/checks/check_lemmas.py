"""Numerical checks of the prime-square lemmas (Lemma 5.2 formula for B_{1,theta psi}, and the
residue S = sum_b lambda(b) b q(b) = -B_k/k = h(-p) mod p for p = 3 mod 4)."""
import cmath, sympy
from fractions import Fraction
from math import gcd

def fermat_q(b, p):
    return ((pow(b, p - 1, p * p) - 1) // p) % p

def check_B_formula(p, c, jt):
    # theta = character mod p with theta(g) = e^{2 pi i jt/(p-1)}, g primitive root mod p
    g = sympy.primitive_root(p)
    ind = {pow(g, k, p): k for k in range(p - 1)}
    theta = lambda a: cmath.exp(2j * cmath.pi * jt * ind[a % p] / (p - 1))
    zp = lambda e: cmath.exp(2j * cmath.pi * e / p)
    psibar = lambda a: zp(-c * fermat_q(a, p))
    # direct B_{1, theta psibar} = (1/p^2) sum_{a=1}^{p^2} theta psibar(a) a
    direct = sum(theta(a) * psibar(a) * a for a in range(1, p * p) if a % p) / p ** 2
    formula = sum(theta(b) * zp(-c * fermat_q(b, p)) / (zp(c * pow(b, -1, p)) - 1) for b in range(1, p))
    return abs(direct - formula)

for p in [5, 7, 11, 13]:
    worst = max(check_B_formula(p, c, jt) for c in range(1, p) for jt in range(1, p - 1, 2))
    print(f'p={p}: max |B_direct - B_formula| over c, odd theta = {worst:.2e}')

def h_minus(p):
    return -sum(sympy.legendre_symbol(a, p) * a for a in range(1, p)) // p

for p in [7, 11, 19, 23, 31, 43, 47, 59, 83, 107, 167, 179, 227, 263]:
    k = (p + 1) // 2
    S = sum(sympy.legendre_symbol(b, p) * b * fermat_q(b, p) for b in range(1, p)) % p
    Bk = sympy.bernoulli(k)
    rhs = (-Fraction(int(Bk.p), int(Bk.q)) / k)
    rhs_mod = rhs.numerator * pow(rhs.denominator, -1, p) % p
    h = h_minus(p)
    print(f'p={p}: S={S}  -B_k/k mod p={rhs_mod}  h(-p)={h}  h mod p={h % p}  safe={sympy.isprime((p-1)//2)}')
