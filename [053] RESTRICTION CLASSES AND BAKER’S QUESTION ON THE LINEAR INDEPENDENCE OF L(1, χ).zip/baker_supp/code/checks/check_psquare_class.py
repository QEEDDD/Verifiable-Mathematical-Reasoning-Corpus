"""Check for q = p^2: (1) tau(theta psi_c) = p theta(c) psi_c(c) zeta_{p^2}^c, psi_c(a) = zeta_p^{c fq(a)};
(2) L(1, theta psi_c) = (pi i/p) psi_c(c) zeta_{p^2}^c theta(c) * S_c(conj theta),
    S_c(t) = sum_b t(b) zeta_p^{-c fq(b)}/(zeta_p^{c b^{-1}} - 1)."""
import cmath, sympy, mpmath
from math import gcd
mpmath.mp.dps = 30
def fq(a, p): return ((pow(a, p - 1, p * p) - 1) // p) % p
for p in [5, 7, 11]:
    g = sympy.primitive_root(p); ind = {pow(g, k, p): k for k in range(p - 1)}
    zp = lambda e: cmath.exp(2j * cmath.pi * e / p)
    zp2 = lambda e: cmath.exp(2j * cmath.pi * e / (p * p))
    worst1 = worst2 = 0
    for c in range(1, p):
        for jt in range(1, p - 1, 2):   # odd theta
            th = lambda a: cmath.exp(2j * cmath.pi * jt * ind[a % p] / (p - 1))
            thb = lambda a: th(a).conjugate()
            chi = lambda a: th(a) * zp(c * fq(a, p))
            tau = sum(chi(x) * zp2(x) for x in range(1, p * p) if x % p)
            pred = p * th(c) * zp(c * fq(c, p)) * zp2(c)
            worst1 = max(worst1, abs(tau - pred))
            # L(1,chi) via cot formula
            L = (cmath.pi / (2 * p * p)) * sum(chi(a) * (1 / cmath.tan(cmath.pi * a / (p * p))) for a in range(1, p * p) if a % p)
            S = sum(thb(b) * zp(-c * fq(b, p)) / (zp(c * pow(b, -1, p)) - 1) for b in range(1, p))
            pred2 = (cmath.pi * 1j / p) * zp(c * fq(c, p)) * zp2(c) * th(c) * S
            worst2 = max(worst2, abs(L - pred2))
    print(f'p={p}: max|tau - formula| = {worst1:.2e}, max|L - formula| = {worst2:.2e}')
