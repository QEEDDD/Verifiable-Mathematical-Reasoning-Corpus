"""Check: pi^2-coefficient of T_j (c=1) equals gamma_j = (1/2) sum_b b^{j+1} q(b)^2 mod p for odd 3<=j<=p-4;
and for general c, the pi^2 coefficient of sum_b b^j P_b^{(c)} equals c*gamma_j.
Also check: for p = 5 mod 8 and theta an odd quartic character, Re and Im of B_{1,theta} are odd integers."""
import sys, numpy as np, sympy
sys.path.insert(0, '..')
import padic_valuations as PV
import psquare_criterion_fast as F
bad = 0
for p in sympy.primerange(7, 300):
    for c in [1, 2, p - 1, 5 % p or 3]:
        T, q, g = PV.T_series(p, 4, c=c)
        for j in range(3, p - 3, 2):
            gam = (sum(pow(b, j + 1, p) * int(q[b - 1]) ** 2 for b in range(1, p)) * pow(2, p - 2, p)) % p
            if T[j, 2] != (c * gam) % p:
                bad += 1
print('second-coefficient mismatches (p<300, several c):', bad)
# parity of B_{1,theta}
odd_ok = 0; tot = 0; viol = []
for p in sympy.primerange(13, 20000):
    if p % 8 != 5: continue
    g = sympy.primitive_root(p)
    # theta(g) = i ; sum theta(a) a = sum_k i^k * (g^k mod p)
    re = im = 0
    x = 1
    for k in range(p - 1):
        r = k % 4
        if r == 0: re += x
        elif r == 1: im += x
        elif r == 2: re -= x
        else: im -= x
        x = x * g % p
    assert re % p == 0 and im % p == 0
    X, Y = re // p, im // p
    tot += 1
    if X % 2 and Y % 2: odd_ok += 1
    else: viol.append((p, X, Y))
print('p = 5 mod 8 below 20000:', tot, 'with Re,Im of B_{1,theta} both odd:', odd_ok, 'violations:', viol[:10])
