from math import gcd
import sympy
def carmichael(n): return int(sympy.reduced_totient(n))
X = 10000
a = b = c = 0; first = []
for q in range(3, X + 1):
    lam = carmichael(q); d = gcd(q, lam); ph = int(sympy.totient(q))
    if int(sympy.totient(d)) <= 2: a += 1
    elif len(first) < 12: first.append(q)
    if gcd(q, ph) == 1: b += 1
    if gcd(q, ph) <= 2: c += 1
print('q in [3,%d]: phi(delta)<=2: %d ; gcd(q,phi)=1: %d ; gcd(q,phi)<=2: %d ; total %d' % (X, a, b, c, X - 2))
print('first moduli with phi(delta)>=4:', first)
for q in [8,9,12,16,18,24,36,48]:
    lam=carmichael(q); print(q, 'lambda',lam,'delta',gcd(q,lam),'gcd(q,phi)',gcd(q,int(sympy.totient(q))))
# distribution of delta (Remark 3.4): delta<=2 (Okada over Q(zeta_lambda)) vs delta in {3,4,6} (new)
from collections import Counter
cnt = Counter()
for q in range(3, X + 1):
    d = gcd(q, carmichael(q))
    cnt[d if d in (1, 2, 3, 4, 6) else 'other'] += 1
print('delta distribution:', dict(cnt), '; delta<=2:', cnt[1] + cnt[2], '; delta in {3,4,6}:', cnt[3] + cnt[4] + cnt[6])
