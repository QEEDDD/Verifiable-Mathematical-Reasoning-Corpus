"""Exact B_{1,theta} in Q(zeta_8) for theta odd of order 8 mod p (p-1 = 8 l), coordinates in basis 1, i, sqrt2, sqrt-2."""
import sympy
from fractions import Fraction
for p in [41, 89, 137, 233, 569, 809, 857, 1049, 1097, 1193]:
    g = sympy.primitive_root(p)
    ind = {}
    x = 1
    for k in range(p - 1):
        ind[x] = k; x = x * g % p
    l = (p - 1) // 8
    # theta(g) = zeta_8 ; theta odd since theta(-1) = zeta_8^{(p-1)/2} = zeta_8^{4l} = -1 (l odd)
    # zeta_8^e in basis (1, i, s2, sm2): zeta8 = (1+i)/sqrt2 = (sqrt2 + sqrt-2)/2  since sqrt-2 = i sqrt2
    basis = {0: (1, 0, 0, 0), 1: (0, 0, Fraction(1, 2), Fraction(1, 2)), 2: (0, 1, 0, 0), 3: (0, 0, Fraction(-1, 2), Fraction(1, 2)),
             4: (-1, 0, 0, 0), 5: (0, 0, Fraction(-1, 2), Fraction(-1, 2)), 6: (0, -1, 0, 0), 7: (0, 0, Fraction(1, 2), Fraction(-1, 2))}
    S = [Fraction(0)] * 4
    for a in range(1, p):
        e = ind[a] % 8
        for t in range(4):
            S[t] += basis[e][t] * a
    B = [s / p for s in S]
    facs = [sympy.factorint(abs(b.numerator)) if b.numerator else 'ZERO' for b in B]
    print(p, 'B coords', [str(b) for b in B], ' p divides:', [ (b.numerator % p == 0) for b in B], ' b0+-b1 div p:', ((B[0]-B[1]).numerator % p == 0, (B[0]+B[1]).numerator % p == 0))
