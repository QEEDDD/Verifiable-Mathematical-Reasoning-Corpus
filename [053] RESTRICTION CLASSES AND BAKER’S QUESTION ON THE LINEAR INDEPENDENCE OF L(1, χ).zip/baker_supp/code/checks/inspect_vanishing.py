import sys, numpy as np, sympy
sys.path.insert(0,'..'); sys.path.insert(0,'.')
import psquare_criterion_fast as F
for p in [41, 137, 233, 113]:
    n=p-1; v=sympy.multiplicity(2,n); l=n>>v; M=2**v
    g=sympy.primitive_root(p); q=F.fermat_quotients(p)
    U,C=F.char_table_U2v(v,p,g)
    js=[l*u for u in U]; beta=F.betas(p,js,q,g)
    z=pow(g,n//M,p)
    print('p',p,'v',v,'l',l,'betas',[beta[j] for j in js])
    for a in range(M):
        for ci in range(C.shape[0]):
            s=sum(int(C[ci,k])*pow(z,a*U[k],p)*beta[js[k]] for k in range(len(U)))%p
            if s==0: print('   vanishing: xi=z^%d'%a,'phi row',ci, [int(C[ci,k]) for k in range(len(U))])
