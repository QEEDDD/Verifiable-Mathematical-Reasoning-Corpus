import sys, numpy as np, sympy
sys.path.insert(0,'..')
import psquare_criterion_fast as F
# v=3: U_8 = {1,3,5,7}; characters: 1, chi_{-4}=[1,-1,1,-1], chi_8=[1,-1,-1,1], chi_{-8}=[1,1,-1,-1]
chars={'1':[1,1,1,1],'m4':[1,-1,1,-1],'8':[1,-1,-1,1],'m8':[1,1,-1,-1]}
for p in sympy.primerange(17, 1200):
    n=p-1; v=sympy.multiplicity(2,n); l=n>>v
    if v!=3 or not sympy.isprime(l): continue
    g=sympy.primitive_root(p); q=F.fermat_quotients(p)
    js=[l*u for u in [1,3,5,7]]; b=F.betas(p,js,q,g); bb=[b[j] for j in js]
    R={k:sum(c*x for c,x in zip(ch,bb))%p for k,ch in chars.items()}
    i=pow(g,(p-1)//4,p); s2=None
    # squares relations
    rel1 = (R['1']**2 + R['m4']**2)%p
    rel2 = (R['8']**2 + R['m8']**2)%p   # chi_8 res in Q sqrt2, chi_-8 in Q sqrt-2
    print(p, 'l',l,'R',R, 'R1^2+Rm4^2', rel1, ' R8^2+Rm8^2', rel2)
