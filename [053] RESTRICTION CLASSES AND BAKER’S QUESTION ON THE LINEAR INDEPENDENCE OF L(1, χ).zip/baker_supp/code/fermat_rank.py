"""q = p^2 reduction: Baker's question for the classes with nontrivial restriction to H = 1+pZ/p^2Z
holds if X_n = zeta^{q(n)+1/n}/(zeta^{1/n}-1), 1<=n<=(p-1)/2, are Q-linearly independent in Q(zeta_p),
q(n) = Fermat quotient (n^{p-1}-1)/p mod p.  X_n = (1/p) sum_j <n j - n q(n) - 1> zeta^j.
We compute the rank mod a large prime (full rank mod ell => full rank over Q)."""
import sys
import numpy as np
import sympy
import flint

def rank_mod(M, ell):
    A = flint.nmod_mat(M.shape[0], M.shape[1], [int(x) % ell for x in M.flatten()], ell)
    return A.rank()

def test(p, ell=(1 << 61) - 1):
    h = (p - 1) // 2
    rows = []
    js = np.arange(p, dtype=np.int64)
    for n in range(1, h + 1):
        qn = (pow(n, p - 1, p * p) - 1) // p % p
        v = (n * js - n * qn - 1) % p          # least nonnegative residues
        w = v[:p - 1] - v[p - 1]               # reduce mod 1+z+...+z^{p-1}: basis 1..z^{p-2}
        rows.append(w)
    M = np.array(rows, dtype=np.int64)
    r = rank_mod(M, ell)
    return h, r

if __name__ == "__main__":
    lo, hi = int(sys.argv[1]), int(sys.argv[2])
    bad = []
    for p in sympy.primerange(lo, hi + 1):
        h, r = test(p)
        if r != h:
            bad.append((p, h, r))
            print("DEFICIENT", p, h, r, flush=True)
    print("checked primes in", lo, hi, "deficient:", bad)
