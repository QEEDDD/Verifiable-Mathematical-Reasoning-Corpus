"""Exact pi-adic valuations of the isotypic class elements for q = p^2  (pi = zeta_p - 1).

For an odd prime p, c in F_p^*, b = 1..p-1 (integers), q(b) the Fermat quotient of the integer b and
k_b in [1, p-1] with k_b = c/b mod p, the class elements are
     e_c(theta) = conj(theta)(c) * sum_b theta(b) zeta^{-c q(b)} / (zeta^{k_b} - 1).
We work in O/pO = F_p[pi]/(pi^{p-1}) (O = Z_p[mu_{p-1}][zeta_p] localised at the prime above p) with theta = omega^j,
omega the Teichmueller character, so theta(b) = b^j mod p.  Then
     pi * e_c(omega^j) = c^{-j} * T_j(pi),   T_j = sum_b b^j (1+pi)^{-c q(b)} * pi/((1+pi)^{k_b}-1)  mod (p, pi^R).
For p - 1 = 2^v l (l odd prime) and the orbit of order 2^v (j = l u, u in U_{2^v}) we compute, for every
xi in mu_{2^v}(F_p) and every phi: U_{2^v} -> F_p^*, the truncated series
     E(xi, phi) = sum_u phi(u)^{-1} xi^u T_{lu}(pi)          (c = 1; other c are Galois twists, see paper)
and its pi-adic valuation w (first nonzero coefficient).  Then v_pi(eps) = w - 1, and the class element eps
is separated from the polar element (valuation -1) iff w is not divisible by p-1.
We also check that the pi^1-coefficient of T_j equals beta_j = B_{j+1}/(j+1) mod p (the leading-term lemma)
for all odd j <= p-4, and that T_{p-2} has constant coefficient -1 (the polar term).

Usage: python3 padic_valuations.py pmin pmax R
"""
import sys
import numpy as np
import sympy

sys.path.insert(0, __file__.rsplit('/', 1)[0])
import psquare_criterion_fast as F


def series_inv(a, R, p):
    """inverse of a power series a (a[0] != 0) mod (p, x^R)."""
    inv = [0] * R
    a0inv = pow(int(a[0]), p - 2, p)
    inv[0] = a0inv
    for n in range(1, R):
        s = 0
        for i in range(1, min(n, len(a) - 1) + 1):
            s += int(a[i]) * inv[n - i]
        inv[n] = (-s * a0inv) % p
    return inv


def binom_row(m, R, p):
    """coefficients of (1+x)^m mod (p, x^R), 0 <= m < p."""
    out = [0] * R
    c = 1
    for i in range(min(R, m + 1)):
        out[i] = c % p
        c = c * (m - i) // (i + 1)
    return out


def mul_trunc(a, b, R, p):
    out = [0] * R
    for i, ai in enumerate(a):
        if ai:
            for k in range(R - i):
                out[i + k] += ai * b[k]
    return [x % p for x in out]


def T_series(p, R, c=1):
    """matrix T[j, i] for all j in 0..p-2 (rows), coefficient i < R; T_j = sum_b b^j P_b."""
    q = F.fermat_quotients(p)
    P = np.zeros((p - 1, R), dtype=np.int64)
    for b in range(1, p):
        k = c * pow(b, p - 2, p) % p
        m = (-c * int(q[b - 1])) % p
        # u_k = ((1+x)^k - 1)/x has coefficients C(k, i+1)
        uk = binom_row(k, R + 1, p)[1:]
        P[b - 1] = mul_trunc(binom_row(m, R, p), series_inv(uk, R, p), R, p)
    g = sympy.primitive_root(p)
    # V[j, b] = b^j mod p
    bs = np.arange(1, p, dtype=np.int64)
    V = np.empty((p - 1, p - 1), dtype=np.int64)
    V[0] = 1
    for j in range(1, p - 1):
        V[j] = V[j - 1] * bs % p
    T = (V @ P) % p if p < 3000 else np.array([(V[j] @ P) % p for j in range(p - 1)])
    return T, q, g


def run(p, R, verbose=False):
    T, q, g = T_series(p, R)
    # leading-term lemma checks
    js = list(range(1, p - 3, 2))
    beta = F.betas(p, js, q, g)
    lead_ok = all(T[j, 0] == 0 and T[j, 1] == beta[j] for j in js)
    polar_ok = (T[p - 2, 0] == p - 1)
    n = p - 1
    v = sympy.multiplicity(2, n)
    l = n >> v
    res = {'lead_ok': lead_ok, 'polar_ok': polar_ok}
    if v >= 1 and l > 1 and sympy.isprime(l):
        M = 2 ** v
        if v >= 2:
            U, C = F.char_table_U2v(v, p, g)
        else:
            U, C = [1], np.array([[1]], dtype=np.int64)
        z = pow(g, n // M, p)
        ws = []
        for a in range(M):
            xi = pow(z, a, p)
            for ci in range(C.shape[0]):
                E = np.zeros(R, dtype=np.int64)
                for k, u in enumerate(U):
                    E = (E + int(C[ci, k]) * pow(xi, u, p) * T[l * u]) % p
                nz = np.nonzero(E)[0]
                w = int(nz[0]) if len(nz) else None
                ws.append(w)
        res['v'] = v
        res['l'] = l
        res['valuations'] = ws
        res['bad'] = [w for w in ws if w is None or w % (p - 1) == 0]
    return res


if __name__ == '__main__':
    pmin, pmax, R = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])
    for p in sympy.primerange(max(5, pmin), pmax + 1):
        r = run(p, R)
        line = f"p={p} lead_ok={r['lead_ok']} polar_ok={r['polar_ok']}"
        if 'valuations' in r:
            ws = r['valuations']
            from collections import Counter
            cnt = Counter(ws)
            line += f" v={r['v']} l={r['l']} valuation_counts={dict(sorted(cnt.items(), key=lambda t: (t[0] is None, t[0] or 0)))} undetermined_or_bad={len(r['bad'])}"
        print(line, flush=True)
