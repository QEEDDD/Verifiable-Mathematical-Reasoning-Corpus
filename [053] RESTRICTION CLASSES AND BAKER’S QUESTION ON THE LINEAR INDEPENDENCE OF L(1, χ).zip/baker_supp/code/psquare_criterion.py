"""Leading-term criterion for Baker's question at q = p^2 (Section 5 of the paper).
For p - 1 = 2^v * l with l = 1 or l an odd prime, the fibres are independent provided
   C(p):  for every xi in mu_{2^v}(F_p) and every character phi of U_{2^v} (values in F_p),
          sum_{u in U_{2^v}} phi(u)^{-1} xi^u beta_{l u} != 0 in F_p,
where beta_j = B_{j+1}/(j+1) mod p = - sum_{b=1}^{p-1} b^{j+1} q_p(b) mod p (j odd, j != p-2),
the index l*u being reduced modulo p-1.  (For v = 1 the condition is beta_l != 0, i.e. p does not
divide h(-p), which always holds; for l = 1, i.e. p a Fermat prime, there is no condition.)
Usage: python3 psquare_criterion.py pmax"""
import sys
import numpy as np
import sympy

def betas(p, js):
    b = np.arange(1, p, dtype=np.int64)
    q = np.array([((pow(int(x), p - 1, p * p) - 1) // p) % p for x in b], dtype=np.int64)
    out = {}
    for j in js:
        e = (j + 1) % (p - 1)
        pw = np.array([pow(int(x), e, p) for x in b], dtype=np.int64)
        out[j] = int((-(pw * q % p).sum()) % p)
    return out

def chars_U2v(v):
    """characters of U_{2^v} as functions on odd u mod 2^v, given by exponent pairs on <-1>, <5>."""
    M = 2 ** v
    U = list(range(1, M, 2))
    if v == 2:
        gens = [(lambda u: 0 if u % 4 == 1 else 1, 2)]
    else:
        def lg(u):
            s = 0 if u % 4 == 1 else 1
            r = u if s == 0 else (M - u) % M
            t, x = 0, 1
            while x != r: x = x * 5 % M; t += 1
            return s, t
        L = {u: lg(u) for u in U}
        gens = [(lambda u: L[u][0], 2), (lambda u: L[u][1], 2 ** (v - 2))]
    return U, gens

def check_p(p):
    n = p - 1
    v = sympy.multiplicity(2, n)
    l = n >> v
    if l == 1:
        return 'fermat', True
    if not sympy.isprime(l):
        return 'not of shape', None
    M = 2 ** v
    U, gens = chars_U2v(v) if v >= 2 else ([1], [])
    js = sorted({(l * u) % n for u in U})
    beta = betas(p, js)
    if any(beta[j] == 0 for j in js) and v == 1:
        return 'v=1', False
    # primitive 2^v-th root of unity in F_p
    g = sympy.primitive_root(p)
    z = pow(g, n // M, p)
    exps = [range(o) for _, o in gens]
    from itertools import product
    ok = True
    for ks in product(*exps):
        # phi(u) = z^{ sum k_i * (M / (2 o_i)) ... } : map character exponents into mu_{2^v}
        def phi(u):
            e = 0
            for (f, o), k in zip(gens, ks):
                e += k * f(u) * (M // o)
            return pow(z, e % M, p)
        for xi_e in range(M):
            xi = pow(z, xi_e, p)
            s = 0
            for u in U:
                s += pow(phi(u), p - 2, p) * pow(xi, u, p) * beta[(l * u) % n]
            if s % p == 0:
                ok = False
    return f'v={v}', ok

if __name__ == '__main__':
    pmax = int(sys.argv[1])
    stats = {}
    fails = []
    for p in sympy.primerange(5, pmax + 1):
        kind, ok = check_p(p)
        if ok is None: continue
        stats.setdefault(kind, [0, 0])
        stats[kind][0] += 1
        if ok: stats[kind][1] += 1
        else: fails.append(p)
    for k, (a, b) in sorted(stats.items()):
        print(f'{k}: primes of this shape {a}, criterion holds for {b}')
    print('criterion fails for:', fails[:50], '...' if len(fails) > 50 else '')
