"""Condition (C_p) of Theorem C(3) for q = p^2, fast version.

p - 1 = 2^v * l with v >= 2 and l an odd prime.  beta_j = B_{j+1}/(j+1) mod p, computed as
beta_j = - sum_{b=1}^{p-1} b^{j+1} q_p(b) mod p  (Lemma: sum b^k q(b) = -B_k/k mod p, k even, 2<=k<=p-3),
q_p(b) = (b^{p-1}-1)/p mod p the Fermat quotient of the integer b.

(C_p): for every xi in mu_{2^v}(F_p) and every homomorphism phi: U_{2^v} -> F_p^*,
        sum_{u in U_{2^v}} phi(u)^{-1} xi^u beta_{l u} != 0 in F_p          (u odd, 1 <= u < 2^v).

The table of all these sums is (matrix with rows xi, columns u) x (character table)^T; it is computed
with exact float64 matrix products (all partial sums stay below 2^53) and reduced mod p.

Usage: python3 psquare_criterion_fast.py pmin pmax [--slowcheck]
Prints one line per prime of the shape, with the number of vanishing sums, and a summary.
"""
import sys
import numpy as np
import sympy


def fermat_quotients(p):
    p2 = p * p
    return np.array([((pow(b, p - 1, p2) - 1) // p) % p for b in range(1, p)], dtype=np.int64)


def betas(p, js, q, g):
    """beta_j for j in js; q[b-1] = Fermat quotient of b; g a primitive root mod p."""
    n = p - 1
    powg = np.empty(n, dtype=np.int64)
    x = 1
    for i in range(n):
        powg[i] = x
        x = x * g % p
    ind = np.empty(p, dtype=np.int64)
    ind[powg] = np.arange(n, dtype=np.int64)
    ib = ind[1:p]                      # index of b = 1..p-1
    out = {}
    for j in js:
        e = (j + 1) % n
        bp = powg[(ib * e) % n]        # b^{j+1} mod p
        out[j] = int((-(bp * q % p).sum()) % p)
    return out


def char_table_U2v(v, p, g):
    """Rows: all homomorphisms phi: U_{2^v} -> F_p^*, entries phi(u)^{-1} mod p, columns u = 1,3,...,2^v-1."""
    M = 2 ** v
    U = list(range(1, M, 2))
    if v == 2:
        return U, np.array([[1, 1], [1, p - 1]], dtype=np.int64)
    # u = s * 5^k mod M with s in {+1,-1}, 0 <= k < 2^{v-2}
    o = 2 ** (v - 2)
    dl = {}
    x = 1
    for k in range(o):
        dl[x] = (0, k)
        dl[(M - x) % M] = (1, k)
        x = x * 5 % M
    w = pow(g, (p - 1) // o, p)        # primitive o-th root of unity in F_p
    rows = []
    for s in range(2):
        for t in range(o):
            row = []
            for u in U:
                su, ku = dl[u]
                val = (pow(p - 1, s * su, p) * pow(w, t * ku, p)) % p
                row.append(pow(val, p - 2, p))   # phi(u)^{-1}
            rows.append(row)
    return U, np.array(rows, dtype=np.int64)


def check_p(p, slow=False):
    n = p - 1
    v = sympy.multiplicity(2, n)
    l = n >> v
    if v < 2 or l == 1 or not sympy.isprime(l):
        return None
    M = 2 ** v
    g = sympy.primitive_root(p)
    q = fermat_quotients(p)
    U, C = char_table_U2v(v, p, g)
    js = [l * u for u in U]            # l*u < p-1, all odd, none equal to p-2
    beta = betas(p, js, q, g)
    z = pow(g, n // M, p)              # primitive 2^v-th root of unity
    a = np.arange(M, dtype=np.int64)[:, None]
    uu = np.array(U, dtype=np.int64)[None, :]
    zpow = np.empty(M, dtype=np.int64)
    x = 1
    for i in range(M):
        zpow[i] = x
        x = x * z % p
    G = zpow[(a * uu) % M] * np.array([beta[j] for j in js], dtype=np.int64)[None, :] % p
    assert p < 2 ** 18 and (p - 1) ** 2 * len(U) < 2 ** 53
    T = np.rint(G.astype(np.float64) @ C.T.astype(np.float64)).astype(np.int64) % p
    zeros = int((T == 0).sum())
    if slow:   # direct evaluation of every sum, for validation
        zs = 0
        for ai in range(M):
            for ci in range(C.shape[0]):
                s = sum(int(C[ci, k]) * pow(z, ai * U[k], p) * beta[js[k]] for k in range(len(U))) % p
                zs += (s == 0)
        assert zs == zeros, (p, zs, zeros)
    return v, l, zeros, T.size


if __name__ == '__main__':
    pmin, pmax = int(sys.argv[1]), int(sys.argv[2])
    slow = '--slowcheck' in sys.argv
    stats = {}
    fails = []
    for p in sympy.primerange(max(5, pmin), pmax + 1):
        r = check_p(p, slow)
        if r is None:
            continue
        v, l, zeros, size = r
        st = stats.setdefault(v, [0, 0])
        st[0] += 1
        if zeros == 0:
            st[1] += 1
        else:
            fails.append((p, v, l, zeros, size))
        print(f'p={p} v={v} l={l} sums={size} vanishing={zeros}', flush=True)
    print('SUMMARY range', pmin, pmax)
    for v in sorted(stats):
        print(f'  v={v}: primes {stats[v][0]}, (C_p) holds for {stats[v][1]}')
    print('  (C_p) fails for', [(p, v, l, z) for (p, v, l, z, s) in fails])
