"""Two-term condition (C'_p) of Theorem C(4) for q = p^2.

p - 1 = 2^v * l with v >= 2 and l an odd prime.  For odd j with 3 <= j <= p-4:
   beta_j  = -sum_{b=1}^{p-1} b^{j+1} q(b)   mod p   ( = B_{j+1}/(j+1) mod p ),
   gamma_j = (1/2) sum_{b=1}^{p-1} b^{j+1} q(b)^2  mod p,
q(b) the Fermat quotient of the integer b.  These are the pi^1 and pi^2 coefficients of pi*e_1(omega^j).
(C'_p): for every xi in mu_{2^v}(F_p) and every phi: U_{2^v} -> F_p^*, the two sums
   S1 = sum_u phi(u)^{-1} xi^u beta_{l u},   S2 = sum_u phi(u)^{-1} xi^u gamma_{l u}
are not both 0.  (C_p) is the stronger condition S1 != 0 for all (xi, phi).
Usage: python3 psquare_twoterm.py pmin pmax [vmin]
"""
import sys
import numpy as np
import sympy
sys.path.insert(0, __file__.rsplit('/', 1)[0])
import psquare_criterion_fast as F


def beta_gamma(p, js, q, g):
    n = p - 1
    powg = np.empty(n, dtype=np.int64)
    x = 1
    for i in range(n):
        powg[i] = x
        x = x * g % p
    ind = np.empty(p, dtype=np.int64)
    ind[powg] = np.arange(n, dtype=np.int64)
    ib = ind[1:p]
    q2 = q * q % p
    inv2 = (p + 1) // 2
    B, G = {}, {}
    for j in js:
        e = (j + 1) % n
        bp = powg[(ib * e) % n]
        B[j] = int((-(bp * q % p).sum()) % p)
        G[j] = int(((bp * q2 % p).sum() * inv2) % p)
    return B, G


def table(p, v, l, vals, U, C, z):
    M = 2 ** v
    a = np.arange(M, dtype=np.int64)[:, None]
    uu = np.array(U, dtype=np.int64)[None, :]
    zpow = np.empty(M, dtype=np.int64)
    x = 1
    for i in range(M):
        zpow[i] = x
        x = x * z % p
    Gm = zpow[(a * uu) % M] * np.array([vals[l * u] for u in U], dtype=np.int64)[None, :] % p
    assert (p - 1) ** 2 * len(U) < 2 ** 53
    return np.rint(Gm.astype(np.float64) @ C.T.astype(np.float64)).astype(np.int64) % p


def check_p(p, vmin=2):
    n = p - 1
    v = sympy.multiplicity(2, n)
    l = n >> v
    if v < vmin or l == 1 or not sympy.isprime(l):
        return None
    M = 2 ** v
    g = sympy.primitive_root(p)
    q = F.fermat_quotients(p)
    U, C = F.char_table_U2v(v, p, g)
    js = [l * u for u in U]
    B, G = beta_gamma(p, js, q, g)
    z = pow(g, n // M, p)
    T1 = table(p, v, l, B, U, C, z)
    T2 = table(p, v, l, G, U, C, z)
    first_zero = int((T1 == 0).sum())
    both_zero = int(((T1 == 0) & (T2 == 0)).sum())
    return v, l, T1.size, first_zero, both_zero


if __name__ == '__main__':
    pmin, pmax = int(sys.argv[1]), int(sys.argv[2])
    vmin = int(sys.argv[3]) if len(sys.argv) > 3 else 2
    stats = {}
    fails = []
    for p in sympy.primerange(max(5, pmin), pmax + 1):
        r = check_p(p, vmin)
        if r is None:
            continue
        v, l, size, fz, bz = r
        st = stats.setdefault(v, [0, 0, 0])
        st[0] += 1
        st[1] += (fz == 0)
        st[2] += (bz == 0)
        if bz:
            fails.append((p, v, l, bz))
        print(f'p={p} v={v} l={l} sums={size} first_vanish={fz} both_vanish={bz}', flush=True)
    print('SUMMARY range', pmin, pmax)
    for v in sorted(stats):
        a, b, c = stats[v]
        print(f'  v={v}: primes {a}; (C_p) holds for {b}; (C\'_p) holds for {c}')
    print("  (C'_p) fails for", fails)
