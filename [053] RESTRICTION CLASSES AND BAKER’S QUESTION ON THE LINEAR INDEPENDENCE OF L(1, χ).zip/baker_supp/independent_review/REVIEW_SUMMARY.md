# Independent review: summary and response

A separate agent reviewed the paper independently. It was given the LaTeX source only. It re-derived the proofs and wrote its own verification scripts, which are the `.py` files in this folder. It did not use the author's code.

## Verdict

The reviewer judged that the following are proved as stated:

- Theorem A and Corollary B
- Lemmas 4.1–4.7, Theorem 4.3, Proposition 4.4
- Theorem 4.8 (Theorem C): cases (1)–(3) unconditionally, and case (4) under (C_p)
- Lemma 5.1 and Proposition 6.1

The reviewer found no error that affects a main result.

## What the reviewer reproduced with its own code

| Check | Result |
|---|---|
| Section 2 formulas, Lemmas 4.1 and 4.2 | All odd θ and all c for p = 5, 7, 11, 13; error below 1e-38 |
| Theorem A / Corollary B, structure | Exact checks for many moduli, including 9, 16, 18, 36, 48 and 25, 27, 32, …, 121 |
| All odd W_χ, full rank | Every 3 ≤ q ≤ 300 |
| F_r certificates (own code) | q = 1331, 1681, 2197, 2401, 3125, 5329, 7921, 9409, 9801, 9000, 9984, 6561 and 8192 |
| Theorem 4.3 criterion | Full rank for all 667 primes 5 ≤ p < 5000 |
| Lemma 4.5 | p < 400 |
| Lemma 4.6 | Coefficients of π^0, π^1, π^2 from a direct expansion, p < 110 |
| Lemma 4.7 | x and y odd for all 2398 primes p ≡ 5 (mod 8), 13 ≤ p < 10^5 |
| Remark 4.9 | The p = 41 example |
| Table 1 | All entries: 1138 primes; 958 with all S_β ≠ 0; (C_p) holds for all; for v ≥ 3, 624 primes, of which 180 need S_γ |

## Points raised, and how they were addressed in the final version

1. **Abstract dimension bound.** The bound was wrong for δ ≤ 2. It is now φ(q)/max(2, φ(δ)).
2. **Sign in the expansion of X_b (Theorem 4.3).** The sign was corrected to +1/p before the review ended. The rank criterion was not affected.
3. **Normalisation of ζ_ψ in Washington's Theorem 7.10.** The normalisation is ζ_ψ = ψ(1+p)^{-1}. Remark 4.10 and the introduction now evaluate at T = ζ_p^{-c} − 1, and the factor is −θ(c) instead of "up to sign".
4. **Unit index Q = 1.** The uncertain citation was removed. The inline argument is kept.
5. **Novelty of Corollary B for δ ∈ {3, 4, 6}.** The reviewer showed that these cases follow quickly from classical facts. This argument was added as Remark 3.5. The introduction now calls Corollary B elementary. It says only that these cases were not found stated in the literature.
6. **"Nothing general is known" about Iwasawa coefficients mod p.** This was replaced by a precise statement that cites Ferrero–Washington and Anglès–Ranieri.
7. **Smaller fixes:**
   - Lemma 4.6 now states its identities in Z_p[[X]] and justifies ω(b) ≡ b mod pO.
   - Lemma 4.7 now covers integrality at both primes above p.
   - The proof of Theorem 4.8 notes that ξ and φ range over everything.
   - Notation clashes were removed:
     - the valuation is now ν;
     - the uniformiser is now ϖ;
     - the exponent is now M;
     - the certificate prime is now r;
     - the Euler-product index is now r.
   - The attribution of the gcd(q, φ(q)) ≤ 2 criterion now reads "implicit in [GK22, Thm 2]".
