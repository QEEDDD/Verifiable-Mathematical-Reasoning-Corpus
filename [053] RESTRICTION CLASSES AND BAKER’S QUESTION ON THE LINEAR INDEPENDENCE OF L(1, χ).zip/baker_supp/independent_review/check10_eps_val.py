# Direct check of the valuations used in the proof of Theorem 4.8:
#   pi * eps_{2^v}^phi(c) computed in F_p[pi]/(pi^L) from the definition of e_c,
#   reporting the index of the first nonzero coefficient (= (p-1)*v(pi*eps)).
from check5_padic import pi_e
from sympy import primitive_root

def homs_list(p, v, zeta):
    n = 1 << v
    us = list(range(1, n, 2))
    if v == 2:
        return us, [{1: 1, 3: 1}, {1: 1, 3: p - 1}]
    dl = {}
    x = 1
    for t in range(1 << (v - 2)):
        dl[x] = (0, t); dl[(n - x) % n] = (1, t)
        x = x * 5 % n
    z4 = pow(zeta, 4, p)
    out = []
    for eps in (1, p - 1):
        for m in range(1 << (v - 2)):
            eta = pow(z4, m, p)
            out.append({u: pow(eps, dl[u][0], p) * pow(eta, dl[u][1], p) % p for u in us})
    return us, out

for p, v, l in [(13, 2, 3), (29, 2, 7), (53, 2, 13), (41, 3, 5), (89, 3, 11), (113, 4, 7), (97, 5, 3)]:
    g = primitive_root(p)
    zeta = pow(g, l, p)
    L = 5
    hist = {}
    for c in range(1, p):
        E = pi_e(p, c, L)  # j -> coefficients of pi*e_c(omega^j)
        us, H = homs_list(p, v, zeta)
        for phi in H:
            co = [0] * L
            for u in us:
                w = pow(phi[u], p - 2, p)  # bar phi(u)
                for i in range(L):
                    co[i] = (co[i] + w * E[l * u][i]) % p
            first = next((i for i in range(L) if co[i]), None)
            hist[first] = hist.get(first, 0) + 1
    print("p=%d v=%d l=%d: first nonzero pi-index of pi*eps over all (c,phi):" % (p, v, l), dict(sorted(hist.items(), key=lambda t: (t[0] is None, t[0]))))
