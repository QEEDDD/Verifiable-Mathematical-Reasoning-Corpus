# For q=p^2 and each class C_c: rank over Q of { zeta_{p-1}^r * e_c(theta) : theta odd, 0<=r<phi(p-1) }
# should be phi(p-1)*(p-1)/2 (Theorem 4.3 "moreover": independence over Q(zeta_{p-1})).
# Also: rank over Q of {e_c(theta)} should be (p-1)/2 (Baker for the class).
import flint
from sympy import primitive_root, totient
from cyc import reduce_mod_phi, rank_mod

BIGP = (1 << 61) - 1

def fq(a, p):
    return ((pow(a, p - 1, p * p) - 1) // p) % p

def run(p):
    Np = p * (p - 1)
    g = primitive_root(p)
    dlog = {}
    x = 1
    for k in range(p - 1):
        dlog[x] = k
        x = x * g % p
    sp = p - 1   # zeta_p = zeta_Np^(p-1)
    sl = p       # zeta_{p-1} = zeta_Np^p
    phl = int(totient(p - 1))
    res = []
    for c in range(1, p):
        rowsQ = []
        rowsK = []
        for k in range(1, p - 1, 2):  # theta(g) = zeta_{p-1}^k
            v = [0] * Np
            th_c_bar = (-k * dlog[c]) % (p - 1)
            for b in range(1, p):
                th_b = (k * dlog[b]) % (p - 1)
                binv = pow(b, -1, p)
                base_p = (-c * fq(b, p)) % p
                # p*z_b = zeta_p^{base} * sum_i i zeta_p^{c binv i}
                for i in range(1, p):
                    ep = (base_p + c * binv * i) % p
                    e = (sl * ((th_c_bar + th_b) % (p - 1)) + sp * ep) % Np
                    v[e] += i
            red = reduce_mod_phi(v, Np)
            rowsQ.append(red)
            for r in range(phl):
                w = [0] * Np
                for e, coef in enumerate(v):
                    if coef:
                        w[(e + sl * r) % Np] += coef
                rowsK.append(reduce_mod_phi(w, Np))
        rq = rank_mod(rowsQ, BIGP)
        rk = rank_mod(rowsK, BIGP)
        res.append((c, rq, rk))
    okQ = all(rq == (p - 1) // 2 for c, rq, rk in res)
    okK = all(rk == phl * (p - 1) // 2 for c, rq, rk in res)
    print("p=%d: all classes Q-rank (p-1)/2: %s; all classes independent over Q(zeta_{p-1}): %s" % (p, okQ, okK), flush=True)

for p in [5, 7, 11, 13, 17, 19, 23]:
    run(p)
