# Independent numerical checks of Section 2 and Lemmas 4.1, 4.2, Thm 4.3 expansion
import mpmath as mp
from sympy import primitive_root, isprime
mp.mp.dps = 40
I = mp.mpc(0, 1)

def e(x):
    return mp.exp(2 * mp.pi * I * x)

def Lval(chi, q, terms=None):
    # L(1,chi) for q-periodic chi via Hurwitz zeta: L = q^{-1} sum chi(a) zeta(1? ) -> use digamma
    # L(1,f) = -1/q sum f(a) psi(a/q), valid when sum f = 0
    return -sum(chi[a] * mp.digamma(mp.mpf(a) / q) for a in range(1, q) if chi[a] != 0) / q

def fq(a, p):
    return ((pow(a, p - 1, p * p) - 1) // p) % p

def check_cot(q):
    # all odd characters mod q via brute force: build U_q generators? use generic: characters of cyclic case only
    pass

# Lemma 4.1 for p = 5,7,11,13
for p in [5, 7, 11, 13]:
    g = primitive_root(p)
    # discrete log mod p
    dlog = {}
    x = 1
    for k in range(p - 1):
        dlog[x] = k
        x = x * g % p
    zp = e(mp.mpf(1) / p)
    zp2 = e(mp.mpf(1) / (p * p))
    maxerr = 0
    for k in range(1, p - 1, 2):  # theta odd: theta(g) = zeta_{p-1}^k, k odd
        theta = lambda a, k=k: e(mp.mpf(k * dlog[a % p]) / (p - 1)) if a % p else 0
        for c in range(1, p):
            psi = lambda a, c=c: e(mp.mpf(c * fq(a, p)) / p) if a % p else 0
            chi = [theta(a) * psi(a) for a in range(p * p)]
            # Gauss sum
            tau = sum(chi[x] * e(mp.mpf(x) / (p * p)) for x in range(p * p))
            tau_formula = p * theta(c) * zp ** (c * fq(c, p)) * zp2 ** c
            err1 = abs(tau - tau_formula)
            # B_{1, bar theta psi_{-c}}
            chib = [mp.conj(theta(a)) * (e(mp.mpf(-c * fq(a, p)) / p) if a % p else 0) for a in range(p * p)]
            B1 = sum(chib[a] * a for a in range(1, p * p)) / (p * p)
            z = {b: zp ** (-c * fq(b, p)) / (zp ** (c * pow(b, -1, p)) - 1) for b in range(1, p)}
            B1_formula = sum(mp.conj(theta(b)) * z[b] for b in range(1, p))
            err2 = abs(B1 - B1_formula)
            # L(1, theta psi_c)
            L = Lval(chi, p * p)
            # e_c(bar theta) = theta(c) sum bar theta(b) z_b
            ecbar = theta(c) * sum(mp.conj(theta(b)) * z[b] for b in range(1, p))
            L_formula = mp.pi * I / p * zp ** (c * fq(c, p)) * zp2 ** c * ecbar
            err3 = abs(L - L_formula)
            # cot formula: L = pi/(2q) sum chi(a) cot(pi a/q)
            q = p * p
            Lcot = mp.pi / (2 * q) * sum(chi[a] * mp.cot(mp.pi * a / q) for a in range(1, q) if chi[a] != 0)
            err4 = abs(L - Lcot)
            # Lemma 4.2
            err5 = max(abs(z[p - b] + z[b]) for b in range(1, p))
            maxerr = max(maxerr, err1, err2, err3, err4, err5)
    print("p=%d Lemma 4.1/4.2/cot max error: %s" % (p, mp.nstr(maxerr, 5)))

# Theorem 4.3 expansion of X_b, test sign
for p in [5, 7, 11, 13, 17]:
    zp = e(mp.mpf(1) / p)
    worst_minus = 0
    worst_plus = 0
    for b in range(1, (p - 1) // 2 + 1):
        bi = pow(b, -1, p)
        Xb = zp ** (fq(b, p) + bi) / (zp ** bi - 1)
        S = sum(((b * j - b * fq(b, p) - 1) % p) * zp ** j for j in range(p))
        worst_minus = max(worst_minus, abs(Xb - (-S / p)))
        worst_plus = max(worst_plus, abs(Xb - (S / p)))
    print("p=%d  |X_b - (-(1/p)S)| max = %s   |X_b - (+(1/p)S)| max = %s" % (p, mp.nstr(worst_minus, 5), mp.nstr(worst_plus, 5)))

# Also: 1/(zeta^a - 1) = ? (1/p) sum i zeta^{ai}
p = 7
zp = e(mp.mpf(1) / p)
for a in [1, 2, 3]:
    lhs = 1 / (zp ** a - 1)
    rhs = sum(i * zp ** (a * i) for i in range(p)) / p
    print("1/(z^%d-1) =" % a, mp.nstr(lhs, 10), "  +(1/p)sum i z^{ai} =", mp.nstr(rhs, 10))
