# Exact checks of Theorem A / Corollary B for small moduli
import sys
from math import gcd
from sympy import totient
from cyc import *

BIGP = (1 << 61) - 1

def analyse(q, do_K=True):
    chars, lam, gens, table = characters(q)
    N = lcm(q, lam)
    delta = gcd(q, lam)
    odd = [(ks, chi) for ks, chi in chars if is_odd(chi, q, lam)]
    # restriction to H = {a = 1 mod delta}
    H = [a for a in table if a % delta == 1 % delta]
    classes = {}
    for ks, chi in odd:
        key = tuple(chi[a] for a in sorted(H))
        classes.setdefault(key, []).append((ks, chi))
    vecs = {}
    for ks, chi in odd:
        vecs[ks] = reduce_mod_phi(qW_vector(chi, q, lam, N), N)
    allrows = [vecs[ks] for ks, chi in odd]
    r_all = rank_exact(allrows) if len(allrows[0]) <= 400 else rank_mod(allrows, BIGP)
    sizes = sorted(set(len(c) for c in classes.values()))
    out = dict(q=q, lam=lam, delta=delta, N=N, n_odd=len(odd), n_classes=len(classes),
               class_sizes=sizes, rank_Q_all=r_all)
    if do_K:
        # K-dimension test: multiply by zeta_lam^k = zeta_N^{k N/lam}, k < phi(lam)
        phl = int(totient(lam))
        sh = N // lam
        def times_zeta(v, k):
            # v is reduced vector of length phi(N); multiply by zeta_N^{k*sh} and reduce
            full = [0] * (len(v) + k * sh)
            for i, x in enumerate(v):
                full[i + k * sh] = x
            return reduce_mod_phi(full, N)
        rowsK = []
        per_class_ok = True
        for key, cl in classes.items():
            rows = [times_zeta(vecs[ks], k) for ks, chi in cl for k in range(phl)]
            rk = rank_mod(rows, BIGP)
            if rk != phl:
                per_class_ok = False
            rowsK += rows
        rK = rank_mod(rowsK, BIGP)
        out['K_rank_each_class_equals_phi(lam)'] = per_class_ok
        out['Q_rank_of_K_span_all'] = rK
        out['expected_classes_times_phi(lam)'] = len(classes) * phl
    # per-class Q-rank
    out['all_classes_full_Q_rank'] = all(rank_mod([vecs[ks] for ks, chi in cl], BIGP) == len(cl) for cl in classes.values())
    return out

if __name__ == "__main__":
    qs = [int(x) for x in sys.argv[1:]] or [9, 16, 18, 36, 48, 25, 27, 32, 45, 49, 50, 54, 55, 63]
    for q in qs:
        print(analyse(q), flush=True)
