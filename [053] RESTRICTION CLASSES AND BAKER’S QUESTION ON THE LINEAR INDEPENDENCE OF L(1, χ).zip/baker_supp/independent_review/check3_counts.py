# Verify the counting claims of the Introduction / Remark 3.? / Section 5
from math import gcd
from sympy import totient, factorint
from cyc import carmichael

c_gcd1 = c_gcd2 = c_d2 = c_phid2 = 0
n_rest = 0
n_classes = 0
maxsize = (0, None)
bad_char = []
for q in range(3, 10001):
    ph = int(totient(q))
    lam = carmichael(q)
    d = gcd(q, lam)
    pd = int(totient(d))
    g = gcd(q, ph)
    if g == 1: c_gcd1 += 1
    if g <= 2: c_gcd2 += 1
    if d <= 2: c_d2 += 1
    if pd <= 2:
        c_phid2 += 1
    else:
        n_rest += 1
        n_classes += ph // pd
        if pd // 2 > maxsize[0]:
            maxsize = (pd // 2, q)
    # explicit characterisation in Remark: check equivalence
    f = factorint(q)
    primes = list(f)
    cond = True
    for p, e in f.items():
        if p >= 5:
            if e > 1 or any((r - 1) % p == 0 for r in primes):
                cond = False
    if f.get(3, 0) >= 2:
        if f[3] >= 3 or any((r - 1) % 9 == 0 for r in primes):
            cond = False
    if f.get(2, 0) >= 3:
        if f[2] >= 5 or any((r - 1) % 8 == 0 for r in primes if r > 2):
            cond = False
    if d % 3 == 0 and d % 4 == 0:
        cond = False
    if cond != (pd <= 2):
        bad_char.append(q)
print("gcd(q,phi)=1:", c_gcd1, " gcd<=2:", c_gcd2, " delta<=2:", c_d2, " phi(delta)<=2:", c_phid2)
print("delta in {3,4,6}:", c_phid2 - c_d2)
print("remaining moduli:", n_rest, " classes:", n_classes, " largest class size:", maxsize)
print("explicit characterisation mismatches:", bad_char[:20], len(bad_char))
# first moduli with phi(delta) >= 4
first = [q for q in range(3, 200) if int(totient(gcd(q, carmichael(q)))) >= 4][:10]
print("first moduli with phi(delta)>=4:", first)
# examples from intro
for q in [8, 9, 12, 16, 18, 24, 36, 48]:
    lam = carmichael(q); d = gcd(q, lam)
    print(q, "lam", lam, "delta", d, "gcd(q,phi)", gcd(q, int(totient(q))))
