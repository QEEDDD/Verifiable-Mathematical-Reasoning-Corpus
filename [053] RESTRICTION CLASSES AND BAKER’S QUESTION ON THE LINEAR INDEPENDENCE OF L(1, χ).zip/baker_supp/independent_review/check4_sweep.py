# For each q in a range, rank over Q (via rank mod a 61-bit prime; full rank mod p => full rank over Q)
# of the vectors q*W_chi in Z[zeta_N] (power basis mod Phi_N), chi odd.  Does not use Theorem A.
import sys, time
from cyc import *

BIGP = (1 << 61) - 1
lo, hi = int(sys.argv[1]), int(sys.argv[2])
bad = []
t0 = time.time()
for q in range(lo, hi + 1):
    chars, lam, gens, table = characters(q)
    N = lcm(q, lam)
    odd = [chi for ks, chi in chars if is_odd(chi, q, lam)]
    rows = [reduce_mod_phi(qW_vector(chi, q, lam, N), N) for chi in odd]
    r = rank_mod(rows, BIGP)
    if r != len(odd):
        bad.append((q, r, len(odd)))
print("range", lo, hi, "failures:", bad, "time %.1fs" % (time.time() - t0))
