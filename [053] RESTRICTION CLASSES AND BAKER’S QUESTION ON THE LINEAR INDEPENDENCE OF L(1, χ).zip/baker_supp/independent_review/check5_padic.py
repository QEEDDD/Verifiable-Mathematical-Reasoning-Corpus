# Check Lemma 4.5 and Lemma 4.6 directly.
# pi*e_c(omega^j) is computed in O/pO = F_p[pi]/(pi^{p-1}) directly from the definition
#   e_c(theta) = bar theta(c) sum_b theta(b) zeta^{-c fq(b)} / (zeta^{c b^{-1}} - 1)
# using zeta = 1+pi, omega^j(b) = b^j mod p, without using the paper's expansion (4.3).
import sys
from sympy import bernoulli, Rational, primerange

def fq(a, p):
    return ((pow(a, p - 1, p * p) - 1) // p) % p

def polmul(A, B, p, L):
    C = [0] * L
    for i, a in enumerate(A):
        if a == 0:
            continue
        for j in range(min(len(B), L - i)):
            C[i + j] = (C[i + j] + a * B[j]) % p
    return C

def polinv(A, p, L):
    # inverse of power series A (A[0] unit) mod (p, pi^L)
    inv0 = pow(A[0], -1, p)
    R = [0] * L
    R[0] = inv0
    for n in range(1, L):
        s = 0
        for i in range(1, min(n, len(A) - 1) + 1):
            s += A[i] * R[n - i]
        R[n] = (-s * inv0) % p
    return R

def binom_mod(m, i, p):
    # binomial(m, i) mod p for 0 <= m < p
    from math import comb
    return comb(m, i) % p

def pi_e(p, c, L):
    """Return dict j -> list of coefficients of pi*e_c(omega^j) mod (p, pi^L), j odd in 1..p-2."""
    Lm = L
    # per b: pi*z_b as power series
    piz = {}
    for b in range(1, p):
        k = (c * pow(b, -1, p)) % p
        m = (-c * fq(b, p)) % p
        zm = [binom_mod(m, i, p) for i in range(min(m, Lm - 1) + 1)] + [0] * Lm
        zm = zm[:Lm]
        u = [binom_mod(k, i + 1, p) for i in range(k)]  # ((1+pi)^k - 1)/pi
        piz[b] = polmul(zm, polinv(u, p, Lm), p, Lm)
    out = {}
    for j in range(1, p - 1, 2):
        acc = [0] * Lm
        for b in range(1, p):
            w = pow(b, j, p)
            for i in range(Lm):
                acc[i] = (acc[i] + w * piz[b][i]) % p
        f = pow(c, -j % (p - 1), p)  # bar omega^j(c) = c^{-j} mod p
        out[j] = [(f * x) % p for x in acc]
    return out

def beta(j, p):
    B = bernoulli(j + 1) / (j + 1)
    return int(B.p * pow(int(B.q), -1, p)) % p

def gamma(j, p):
    s = sum(pow(b, j + 1, p) * fq(b, p) ** 2 for b in range(1, p)) % p
    return s * pow(2, -1, p) % p

def lemma45(p):
    ok = True
    for k in range(2, p - 2, 2):
        s = sum(pow(b, k, p) * fq(b, p) for b in range(1, p)) % p
        Bk = bernoulli(k) / k
        Bkk = int(Bk.p * pow(int(Bk.q), -1, p)) % p
        if s != (-Bkk) % p:
            ok = False
        # B_{1,omega^{k-1}} mod p via Teichmuller lifts mod p^2 (omega(a) = a^p mod p^2)
        M = p * p
        tot = sum(pow(pow(a, p, M), k - 1, M) * a for a in range(1, p)) % M
        if tot % p != 0:
            ok = False
        if (tot // p) % p != Bkk:
            ok = False
    return ok

if __name__ == "__main__":
    pmax = int(sys.argv[1]) if len(sys.argv) > 1 else 120
    allok45 = True
    for p in primerange(5, pmax):
        if not lemma45(p):
            allok45 = False
            print("Lemma 4.5 fails for p =", p)
    print("Lemma 4.5 congruences hold for all 5 <= p <", pmax, ":", allok45)
    bad = []
    for p in primerange(5, min(pmax, 110)):
        L = min(p - 1, 6)
        for c in sorted(set([1, 2, 3, p - 1, (p - 1) // 2])):
            E = pi_e(p, c, L)
            for j, co in E.items():
                if j == p - 2:
                    if co[0] != p - 1:
                        bad.append((p, c, j, 'const', co[:3]))
                    continue
                if co[0] != 0:
                    bad.append((p, c, j, 'const!=0', co[:3]))
                cj = pow(c, -j % (p - 1), p)
                if j <= p - 4 and co[1] != cj * beta(j, p) % p:
                    bad.append((p, c, j, 'lin', co[:3], cj * beta(j, p) % p))
                if 3 <= j <= p - 4 and L > 2 and co[2] != cj * c * gamma(j, p) % p:
                    bad.append((p, c, j, 'quad', co[:3], cj * c * gamma(j, p) % p))
                if j == 1 and L > 2:
                    # for j=1 the paper's formula needs a correction c/6 (not claimed)
                    pass
    print("Lemma 4.6 mismatches (p<110, several c):", bad[:10], len(bad))
    # Report what the pi^2 coefficient is for j=1, compared with c*gamma_1 (+ c/6 predicted by my derivation)
    p = 13; c = 2
    E = pi_e(p, c, 4)
    cj = pow(c, -1 % (p - 1), p)
    print("p=13,c=2,j=1: pi^2 coeff", E[1][2], " c^{-1}*c*gamma_1 =", cj * c * gamma(1, p) % p,
          " c^{-1}*(c*gamma_1 + c/6) =", cj * (c * gamma(1, p) + c * pow(6, -1, p)) % p)
