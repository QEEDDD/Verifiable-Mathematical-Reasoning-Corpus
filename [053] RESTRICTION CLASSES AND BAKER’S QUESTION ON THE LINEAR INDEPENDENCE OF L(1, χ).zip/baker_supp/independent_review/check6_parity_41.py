# Lemma 4.7 parity and Remark 4.9 (p = 41) checks
import sys
import mpmath as mp
from sympy import primerange, primitive_root, isprime

def quartic_B(p):
    g = primitive_root(p)
    # theta(g) = i ; theta(g^k) = i^k
    x = y = 0
    a = 1
    for k in range(p - 1):
        r = k % 4
        if r == 0: x += a
        elif r == 1: y += a
        elif r == 2: x -= a
        else: y -= a
        a = a * g % p
    assert x % p == 0 and y % p == 0
    return x // p, y // p

pmax = int(sys.argv[1]) if len(sys.argv) > 1 else 50000
bad = []
cnt = 0
for p in primerange(13, pmax):
    if p % 8 == 5:
        cnt += 1
        x, y = quartic_B(p)
        if x % 2 == 0 or y % 2 == 0:
            bad.append((p, x, y))
print("Lemma 4.7: primes p=5 mod 8, 13<=p<%d: %d, failures: %s" % (pmax, cnt, bad[:5]))
# count below 2*10^4 as in the paper (568 claimed)
print("count of p = 5 mod 8 below 2e4 (p>=13):", sum(1 for p in primerange(13, 20000) if p % 8 == 5))
print("count of p = 5 mod 8 below 2e4 (all):", sum(1 for p in primerange(2, 20000) if p % 8 == 5))

# Remark 4.9: p = 41, theta of order 8
p = 41
g = primitive_root(p)
mp.mp.dps = 30
z8 = mp.exp(2j * mp.pi / 8)
print("p=41, primitive root", g)
for k in [1, 3, 5, 7]:
    # theta(g) = zeta_8^k
    s = 0
    a = 1
    for e in range(p - 1):
        s += z8 ** (k * e) * a
        a = a * g % p
    B = s / p
    # express B = A + B' i + C sqrt2 + D sqrt(-2) with rationals: use numeric solve via basis of Q(zeta8)
    # B = c0 + c1 z + c2 z^2 + c3 z^3 with z = zeta_8 (integers here)
    # recover integer coords: compute exactly using integer arithmetic on exponents mod 8
    coeff = [0] * 8
    a = 1
    for e in range(p - 1):
        coeff[(k * e) % 8] += a
        a = a * g % p
    # reduce z^4 = -1
    c = [coeff[i] - coeff[i + 4] for i in range(4)]
    assert all(x % p == 0 for x in c)
    c = [x // p for x in c]
    # z = (sqrt2 + sqrt-2)/2, z^2 = i, z^3 = (-sqrt2 + sqrt-2)/2
    # B = c0 + c2 i + (c1 - c3)/2 sqrt2 + (c1 + c3)/2 sqrt-2
    print(" theta(g)=zeta8^%d: B = %s + %s i + %s sqrt2 + %s sqrt(-2)" % (k, c[0], c[2], mp.mpf(c[1] - c[3]) / 2, mp.mpf(c[1] + c[3]) / 2), " numeric:", mp.nstr(B, 8))
