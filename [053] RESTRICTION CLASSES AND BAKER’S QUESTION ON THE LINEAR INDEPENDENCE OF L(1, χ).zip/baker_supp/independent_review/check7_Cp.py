# Independent check of condition (C_p) and of Table 1.
# For p = 2^v*l + 1 (l odd prime, v >= 2):
#   beta_j  = B_{j+1}/(j+1) mod p  (computed as -sum_b b^{j+1} fq(b), Lemma 4.5; cross-checked vs Bernoulli for small p)
#   gamma_j = (1/2) sum_b b^{j+1} fq(b)^2 mod p
#   S_beta(xi,phi) = sum_{u in U_{2^v}} phi(u)^{-1} xi^u beta_{l u},   same for gamma
# (C_p): no (xi, phi) with S_beta = S_gamma = 0.
import sys, time
import numpy as np
from sympy import primerange, isprime, primitive_root, bernoulli, factorint

def decompose(p):
    m = p - 1
    v = 0
    while m % 2 == 0:
        m //= 2; v += 1
    return v, m

def fermat_quotients(p):
    p2 = p * p
    return [((pow(a, p - 1, p2) - 1) // p) % p for a in range(p)]

def beta_gamma(p, v, l, fq):
    g = primitive_root(p)
    n = 1 << v
    # B_i = g^i mod p, residue classes i mod 2^v
    P1 = [0] * n
    P2 = [0] * n
    b = 1
    for i in range(p - 1):
        r = i & (n - 1)
        qb = fq[b]
        P1[r] += b * qb
        P2[r] += b * qb * qb
        b = b * g % p
    P1 = [x % p for x in P1]
    P2 = [x % p for x in P2]
    zeta = pow(g, l, p)  # order 2^v
    us = list(range(1, n, 2))
    zpow = [pow(zeta, k, p) for k in range(n)]
    inv2 = pow(2, -1, p)
    beta = {}
    gamma = {}
    for u in us:
        s1 = 0
        s2 = 0
        for r in range(n):
            z = zpow[(r * u) & (n - 1)]
            s1 += P1[r] * z
            s2 += P2[r] * z
        beta[u] = (-s1) % p
        gamma[u] = (s2 * inv2) % p
    return beta, gamma, zeta, us

def homs(p, v, zeta):
    """List of phi as dict u -> phi(u) in F_p^*, for all homs U_{2^v} -> F_p^*."""
    n = 1 << v
    us = list(range(1, n, 2))
    if v == 2:
        return [{1: 1, 3: 1}, {1: 1, 3: p - 1}]
    # u = (-1)^a 5^t
    dl = {}
    x = 1
    for t in range(1 << (v - 2)):
        dl[x] = (0, t)
        dl[(n - x) % n] = (1, t)
        x = x * 5 % n
    assert len(dl) == n // 2
    z4 = pow(zeta, 4, p)  # order 2^{v-2}
    out = []
    for eps in (1, p - 1):
        for m in range(1 << (v - 2)):
            eta = pow(z4, m, p)
            phi = {}
            for u in us:
                a, t = dl[u]
                phi[u] = (pow(eps, a, p) * pow(eta, t, p)) % p
            out.append(phi)
    return out

def check_p(p):
    v, l = decompose(p)
    fq = fermat_quotients(p)
    beta, gamma, zeta, us = beta_gamma(p, v, l, fq)
    n = 1 << v
    H = homs(p, v, zeta)
    nh = len(H)
    # C[u_index, phi_index] = phi(u)^{-1}
    C = np.array([[pow(phi[u], p - 2, p) for phi in H] for u in us], dtype=np.float64)
    bvec = np.array([beta[u] for u in us], dtype=np.int64)
    gvec = np.array([gamma[u] for u in us], dtype=np.int64)
    uarr = np.array(us, dtype=np.int64)
    zpow = np.array([pow(zeta, k, p) for k in range(n)], dtype=np.int64)
    zero_beta = []
    fail = []
    chunk = 1024
    for s0 in range(0, n, chunk):
        ss = np.arange(s0, min(n, s0 + chunk), dtype=np.int64)
        E = zpow[(ss[:, None] * uarr[None, :]) % n]  # xi^u
        A = ((E * bvec[None, :]) % p).astype(np.float64)
        Sb = np.fmod(A @ C, p)
        idx = np.argwhere(Sb == 0)
        for (si, hi) in idx:
            s = int(ss[si])
            zero_beta.append((s, int(hi)))
            # compute S_gamma at this point
            phi = H[int(hi)]
            sg = 0
            for u in us:
                sg += pow(phi[u], p - 2, p) * pow(zeta, (s * u) % n, p) * gamma[u]
            if sg % p == 0:
                fail.append((s, int(hi)))
    return v, l, len(zero_beta), fail, beta, gamma

if __name__ == "__main__":
    lo = int(sys.argv[1]); hi = int(sys.argv[2])
    vmin = int(sys.argv[3]) if len(sys.argv) > 3 else 2
    stats = {}
    t0 = time.time()
    for p in primerange(lo, hi):
        v, l = decompose(p)
        if v < vmin or l == 1 or not isprime(l):
            continue
        v, l, nzb, fail, beta, gamma = check_p(p)
        st = stats.setdefault(v, [0, 0, 0])
        st[0] += 1
        if nzb == 0:
            st[1] += 1
        if not fail:
            st[2] += 1
        else:
            print("(C_p) FAILS for p =", p, fail[:5], flush=True)
        if p == 41:
            print("p=41: number of (xi,phi) with S_beta=0:", nzb, flush=True)
    for v in sorted(stats):
        print("v=%d primes=%d allSbeta!=0=%d Cp_holds=%d" % (v, *stats[v]))
    tot = [sum(s[i] for s in stats.values()) for i in range(3)]
    print("all", tot, "time %.1fs" % (time.time() - t0))
