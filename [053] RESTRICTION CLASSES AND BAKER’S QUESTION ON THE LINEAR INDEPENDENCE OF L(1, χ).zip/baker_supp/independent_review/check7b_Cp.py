# Memory-efficient version of check7 (same mathematics).
import sys, time
import numpy as np
from sympy import primerange, isprime, primitive_root

def decompose(p):
    m = p - 1; v = 0
    while m % 2 == 0:
        m //= 2; v += 1
    return v, m

def beta_gamma(p, v, l):
    p2 = p * p
    g = primitive_root(p)
    n = 1 << v
    P1 = [0] * n; P2 = [0] * n
    b = 1
    for i in range(p - 1):
        qb = ((pow(b, p - 1, p2) - 1) // p) % p
        r = i & (n - 1)
        P1[r] += b * qb
        P2[r] += b * qb * qb
        b = b * g % p
    P1 = np.array([x % p for x in P1], dtype=np.int64)
    P2 = np.array([x % p for x in P2], dtype=np.int64)
    zeta = pow(g, l, p)
    zpow = np.array([pow(zeta, k, p) for k in range(n)], dtype=np.int64)
    us = np.arange(1, n, 2, dtype=np.int64)
    r = np.arange(n, dtype=np.int64)
    beta = np.zeros(len(us), dtype=np.int64); gam = np.zeros(len(us), dtype=np.int64)
    inv2 = pow(2, -1, p)
    for ch in range(0, len(us), 512):
        uu = us[ch:ch + 512]
        Z = zpow[(r[:, None] * uu[None, :]) % n]  # n x chunk
        beta[ch:ch + 512] = (-(P1[:, None] * Z % p).sum(axis=0)) % p
        gam[ch:ch + 512] = ((P2[:, None] * Z % p).sum(axis=0) % p) * inv2 % p
    return beta, gam, zeta, zpow, us

def check_p(p):
    v, l = decompose(p)
    n = 1 << v
    beta, gam, zeta, zpow, us = beta_gamma(p, v, l)
    nu = len(us)
    # parametrise homs phi: U_{2^v} -> F_p^*
    if v == 2:
        a_of_u = np.array([0, 1], dtype=np.int64); t_of_u = np.array([0, 0], dtype=np.int64)
        T = 1
    else:
        T = 1 << (v - 2)
        a_of_u = np.zeros(nu, dtype=np.int64); t_of_u = np.zeros(nu, dtype=np.int64)
        x = 1
        for t in range(T):
            a_of_u[(x - 1) // 2] = 0; t_of_u[(x - 1) // 2] = t
            y = (n - x) % n
            a_of_u[(y - 1) // 2] = 1; t_of_u[(y - 1) // 2] = t
            x = x * 5 % n
    z4 = pow(zeta, 4, p) if v >= 3 else 1
    z4pow = np.array([pow(z4, k, p) for k in range(T)], dtype=np.int64)
    sign = np.where(a_of_u == 1, p - 1, 1).astype(np.int64)
    nzb = 0
    fails = []
    mchunk = max(1, min(T, (1 << 24) // max(1, nu)))
    schunk = max(1, min(n, (1 << 24) // max(1, nu)))
    for eps in (1, -1):
        for m0 in range(0, T, mchunk):
            ms = np.arange(m0, min(T, m0 + mchunk), dtype=np.int64)
            # C[u, m] = phi_{eps,m}(u)^{-1} = eps^{a(u)} * z4^{-m t(u)}
            Cm = z4pow[(-(t_of_u[:, None] * ms[None, :])) % T]
            if eps == -1:
                Cm = Cm * sign[:, None] % p
            Cf = Cm.astype(np.float64)
            for s0 in range(0, n, schunk):
                ss = np.arange(s0, min(n, s0 + schunk), dtype=np.int64)
                A = (zpow[(ss[:, None] * us[None, :]) % n] * beta[None, :] % p).astype(np.float64)
                Sb = np.fmod(A @ Cf, p)
                idx = np.argwhere(Sb == 0)
                nzb += len(idx)
                for si, mi in idx:
                    s = int(ss[si]); m = int(ms[mi])
                    col = Cm[:, mi]
                    sg = int((zpow[(s * us) % n] * gam % p * col % p).sum() % p)
                    if sg == 0:
                        fails.append((s, eps, m))
    return v, l, nzb, fails

if __name__ == "__main__":
    lo = int(sys.argv[1]); hi = int(sys.argv[2])
    stats = {}
    t0 = time.time()
    for p in primerange(lo, hi):
        v, l = decompose(p)
        if v < 2 or l == 1 or not isprime(l):
            continue
        v, l, nzb, fails = check_p(p)
        st = stats.setdefault(v, [0, 0, 0])
        st[0] += 1
        if nzb == 0: st[1] += 1
        if not fails: st[2] += 1
        else: print("(C_p) FAILS for p =", p, fails[:5], flush=True)
        if p == 41:
            print("p=41 zero S_beta pairs:", nzb, flush=True)
    for v in sorted(stats):
        print("v=%d primes=%d allSbeta!=0=%d Cp_holds=%d" % (v, *stats[v]))
    print("all", [sum(s[i] for s in stats.values()) for i in range(3)], "time %.1fs" % (time.time() - t0), flush=True)
