# Theorem 4.3 criterion: rank of the (p-1)/2 x (p-1) matrix with rows
#   a_j - a_{p-1},  a_j = <b j - b fq(b) - 1>,  0 <= j <= p-2
# computed modulo several primes (full rank mod one prime suffices).
import sys, time
import flint
from sympy import primerange

def fq(a, p):
    return ((pow(a, p - 1, p * p) - 1) // p) % p

def star_rank(p, mod):
    rows = []
    for b in range(1, (p - 1) // 2 + 1):
        t = (b * fq(b, p) + 1) % p
        a = [(b * j - t) % p for j in range(p)]
        last = a[p - 1]
        rows.append([(x - last) % mod for x in a[:p - 1]])
    M = flint.nmod_mat(len(rows), p - 1, [x for r in rows for x in r], mod)
    return M.rank()

lo, hi = int(sys.argv[1]), int(sys.argv[2])
MOD = 2305843009213693951  # 2^61-1 (as the paper) -- also try another prime for the failures
MOD2 = 1000000007
t0 = time.time()
fails = []
cnt = 0
for p in primerange(lo, hi):
    if p < 5:
        continue
    cnt += 1
    r = star_rank(p, MOD2); print(p, r, flush=True)
    if r != (p - 1) // 2:
        r2 = star_rank(p, MOD)
        if r2 != (p - 1) // 2:
            fails.append((p, r2))
print("primes %d..%d: %d tested, failures %s, time %.1fs" % (lo, hi, cnt, fails, time.time() - t0))
