# Independent spot-check of Theorem D for some large moduli: for each restriction class C,
# build the matrix (rho_j(W_chi))_{j in J, chi in C} over F_ell (ell = 1 mod N, ell < 2^31) and check rank |C|.
import sys, time, random
import numpy as np
import flint
from math import gcd
from sympy import isprime, factorint, primitive_root, totient
from cyc import carmichael, lcm

def unit_group_np(q):
    f = factorint(q)
    gens = []
    for p, e in f.items():
        pe = p ** e
        rest = q // pe
        def lift(x, pe=pe, rest=rest):
            if rest == 1:
                return x % q
            inv = pow(pe, -1, rest)
            return (x + pe * (((1 - x) * inv) % rest)) % q
        if p == 2:
            if e == 1:
                continue
            elif e == 2:
                gens.append((lift(3), 2))
            else:
                gens.append((lift(pe - 1), 2))
                gens.append((lift(5), 2 ** (e - 2)))
        else:
            gens.append((lift(primitive_root(pe)), (p - 1) * p ** (e - 1)))
    elems = np.array([1], dtype=np.int64)
    vecs = np.zeros((1, 0), dtype=np.int64)
    for g, n in gens:
        pw = np.array([pow(g, k, q) for k in range(n)], dtype=np.int64)
        elems = (elems[:, None] * pw[None, :] % q).reshape(-1)
        vecs = np.concatenate([np.repeat(vecs, n, axis=0), np.tile(np.arange(n), len(vecs))[:, None]], axis=1)
    return gens, elems, vecs

def find_ell(N, lo=1 << 29):
    k = (lo // N) + 1
    while True:
        ell = k * N + 1
        if ell >= (1 << 31):
            raise ValueError("no ell")
        if isprime(ell):
            return ell
        k += 1

def element_of_order(N, ell):
    fac = factorint(N)
    x = 2
    while True:
        h = pow(x, (ell - 1) // N, ell)
        if all(pow(h, N // r, ell) != 1 for r in fac):
            return h
        x += 1

def certify(q, seed=1):
    t0 = time.time()
    lam = carmichael(q)
    N = lcm(q, lam)
    delta = gcd(q, lam)
    gens, elems, vecs = unit_group_np(q)
    orders = np.array([n for g, n in gens], dtype=np.int64)
    scale = np.array([lam // n for n in orders], dtype=np.int64)
    # all characters k (vector), t_k(a) = sum k_i e_i(a) lam/n_i mod lam
    import itertools
    K = np.array(list(itertools.product(*[range(n) for n in orders])), dtype=np.int64)
    T = (K * scale[None, :]) @ vecs.T % lam  # (#chars) x phi(q)
    idx_m1 = int(np.where(elems == q - 1)[0][0])
    odd = np.where(T[:, idx_m1] == lam // 2)[0]
    Hidx = np.where(elems % delta == 1 % delta)[0]
    # classes by restriction to H
    classes = {}
    for c in odd:
        key = T[c, Hidx].tobytes()
        classes.setdefault(key, []).append(c)
    sizes = set(len(v) for v in classes.values())
    ell = find_ell(N)
    h = element_of_order(N, ell)
    rng = random.Random(seed)
    UN = [u for u in range(1, N) if gcd(u, N) == 1]
    # one u per residue class mod lam
    reps = {}
    for u in UN:
        reps.setdefault(u % lam, u)
    reps = list(reps.values())
    rng.shuffle(reps)
    ok = True
    a_vals = elems  # a in U_q
    for key, cl in classes.items():
        s = len(cl)
        Tc = T[cl, :]  # s x phi(q)
        rows = []
        r = 0
        ptr = 0
        while r < s and ptr < len(reps):
            batch = reps[ptr: ptr + max(8, s + 4 - len(rows))]
            ptr += len(batch)
            for j in batch:
                hj = pow(h, j, ell)
                zl = pow(hj, N // lam, ell)  # image of zeta_lam
                zq = pow(hj, N // q, ell)    # image of zeta_q
                Zl = np.array([pow(zl, k, ell) for k in range(lam)], dtype=np.int64) if lam <= 20000 else None
                # y_a = (zq^a + 1)/(zq^a - 1)
                za = np.array([pow(zq, int(a), ell) for a in a_vals], dtype=np.int64)
                num = (za + 1) % ell
                den = (za - 1) % ell
                inv = np.array([pow(int(d), ell - 2, ell) for d in den], dtype=np.int64)
                y = num * inv % ell
                X = Zl[Tc]  # s x phi(q), entries < ell < 2^31
                ylo = y & 0x7FFF
                yhi = y >> 15
                w = (X @ ylo) % ell
                w2 = (X @ yhi) % ell
                w = (w + (w2 << 15) % ell) % ell
                rows.append([int(x) for x in w])
            M = flint.nmod_mat(len(rows), s, [x for rr in rows for x in rr], ell)
            r = M.rank()
        if r < s:
            ok = False
            print("  class not certified: q=%d size %d rank %d" % (q, s, r))
    print("q=%d lam=%d delta=%d N=%d classes=%d sizes=%s ell=%d certified=%s (%.1fs)" %
          (q, lam, delta, N, len(classes), sorted(sizes), ell, ok, time.time() - t0), flush=True)
    return ok

if __name__ == "__main__":
    for q in [int(x) for x in sys.argv[1:]]:
        certify(q)
