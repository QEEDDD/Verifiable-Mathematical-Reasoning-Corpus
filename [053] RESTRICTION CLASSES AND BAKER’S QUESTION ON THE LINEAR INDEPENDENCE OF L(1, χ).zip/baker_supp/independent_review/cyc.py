# Own implementation: characters of U_q, W_chi in Z[zeta_N], exact/modular ranks
from math import gcd
from sympy import factorint, primitive_root, totient
from functools import reduce
import flint

def lcm(a, b):
    return a * b // gcd(a, b)

def carmichael(q):
    f = factorint(q)
    l = 1
    for p, e in f.items():
        if p == 2:
            t = 1 if e == 1 else (2 if e == 2 else 2 ** (e - 2))
        else:
            t = (p - 1) * p ** (e - 1)
        l = lcm(l, t)
    return l

def unit_group(q):
    """Return list of (generator g mod q, order n) giving U_q = prod <g_i>, and dlog function."""
    f = factorint(q)
    gens = []
    for p, e in f.items():
        pe = p ** e
        rest = q // pe
        def lift(x, pe=pe, rest=rest):
            # element = x mod pe, 1 mod rest
            if rest == 1:
                return x % q
            # CRT
            inv = pow(pe, -1, rest)
            # find y with y = x mod pe, y = 1 mod rest
            y = x + pe * (((1 - x) * inv) % rest)
            return y % q
        if p == 2:
            if e == 1:
                continue
            elif e == 2:
                gens.append((lift(3), 2))
            else:
                gens.append((lift(pe - 1), 2))  # -1
                gens.append((lift(5), 2 ** (e - 2)))
        else:
            g = primitive_root(pe)
            gens.append((lift(g), (p - 1) * p ** (e - 1)))
    # brute force dlog table: enumerate all products
    table = {}
    elems = [(1, ())]
    for g, n in gens:
        new = []
        for x, vec in elems:
            y = x
            for k in range(n):
                new.append((y, vec + (k,)))
                y = y * g % q
        elems = new
    for x, vec in elems:
        table[x] = vec
    assert len(table) == int(totient(q)), (q, len(table))
    return gens, table

def characters(q):
    """Yield characters as dict a -> exponent t (chi(a) = zeta_lam^t)."""
    gens, table = unit_group(q)
    lam = carmichael(q)
    orders = [n for g, n in gens]
    import itertools
    chars = []
    for ks in itertools.product(*[range(n) for n in orders]):
        chi = {}
        for a, vec in table.items():
            t = 0
            for k, ei, n in zip(ks, vec, orders):
                t += k * ei * (lam // n)
            chi[a] = t % lam
        chars.append((ks, chi))
    return chars, lam, gens, table

def is_odd(chi, q, lam):
    return chi[q - 1] == lam // 2

def qW_vector(chi, q, lam, N):
    """q*W_chi as integer coefficient vector of length N in zeta_N^k (not reduced)."""
    v = [0] * N
    sN_lam = N // lam
    sN_q = N // q
    for a, t in chi.items():
        base = (t * sN_lam) % N
        # q*y_a = q + 2 sum_j j zeta_q^{aj}
        v[base] += q
        for j in range(1, q):
            v[(base + sN_q * ((a * j) % q)) % N] += 2 * j
    return v

_phi_cache = {}
def cyclotomic_poly(N):
    if N not in _phi_cache:
        _phi_cache[N] = flint.fmpz_poly.cyclotomic(N)
    return _phi_cache[N]

def reduce_mod_phi(v, N):
    P = flint.fmpz_poly(v)
    R = P % cyclotomic_poly(N)
    d = int(totient(N))
    c = [int(x) for x in R.coeffs()]
    c += [0] * (d - len(c))
    return c

def rank_mod(rows, prime):
    if not rows:
        return 0
    M = flint.nmod_mat(len(rows), len(rows[0]), [x % prime for r in rows for x in r], prime)
    return M.rank()

def rank_exact(rows):
    M = flint.fmpz_mat(rows)
    return M.rank()
