Supplementary material for
  "Erdos's conjecture on sum f(n)/n is false: a 2-adic shadow of Okada's criterion
   and the least counterexample q = 105^2"   (Keio, 24 October 2026)

Requirements: Python 3 (tested 3.13) with sympy, mpmath, python-flint (0.9), ortools (9.15,
only for the search scripts); PARI/GP for the gp/ checks.  Run everything from this directory.

QUICK CHECK OF THE MAIN THEOREM (q = 11025, hand-checkable identities):
  python3 code/legendre11025.py data/f_11025_legendre.txt
     -> builds f from the Legendre-symbol table of the paper (Table 1), checks it equals the
        data file, prints the layer expansions c_{d,m}, the seven character coefficients
        A_chi (all 0), the three log-coefficients (all 0) and the convergence sum (0).
  python3 code/verify_full.py 11025 data/f_11025_legendre.txt all 50
     -> Okada's ORIGINAL criterion, implemented directly from its statement: all 5040 unit
        equations sum_{m in M(q)} f(am)/m = 0 (exact rationals, infinite sums as geometric
        series) and the 3 prime equations; plus mpmath value of L(1,f) at 50 digits.
  gp -q gp/check11025L.gp      (PARI/GP, 134 digits: L(1,f) ~ -1.2e-135)

SECOND COUNTEREXAMPLE (q = 27225 = 165^2):
  python3 code/check_tab27225.py data/tab_27225.tex data/f_27225.txt
  python3 code/verify_full.py 27225 data/f_27225.txt all 40
  python3 code/cert_table.py data/f_27225.txt logs/chartable_27225.txt
     -> invariance under the odd-order units (all 825 x 27224 checks) and the 15 character
        coefficients in Q(i) (all 0), log coefficients 0.
  gp -q gp/check.gp            (PARI/GP, 134 digits: L(1,f) ~ -1.1e-135)

FURTHER COUNTEREXAMPLES (q = 315^2 = 99225, 495^2 = 245025, 735^2 = 540225; Legendre type):
  python3 code/verify_legendre_type.py 99225 data/f_99225.txt
  python3 code/verify_legendre_type.py 245025 data/f_245025.txt
  python3 code/verify_legendre_type.py 540225 data/f_540225.txt
     -> checks that each layer function depends only on Legendre symbols and evaluates the
        seven character identities, three log identities and the convergence identity exactly.
  python3 code/verify_full.py 99225 data/f_99225.txt all 30     (Okada's original equations)
  sh gp/make_gp_data.sh; gp -q gp/check99225.gp; gp -q -s 200000000 gp/check245025.gp;
  gp -q -s 200000000 gp/check540225.gp

2-ADIC OBSTRUCTION FOR ALL ODD NON-SQUARES q <= 13105 (Theorem 5.6):
  certificates/certs2_all.jsonl.gz : one JSON line per odd composite non-square q <= 13105,
     {"q": q, "lam": [Lambda entries as rationals], "sec": time}; Lambda is indexed by the
     shadow unknowns in the order produced by code/shadow.py (class Shadow).
  python3 code/certcheck2.py certificates/certs2_all.jsonl
     -> for each q rebuilds the integer shadow system from its definition and checks:
        all entries of Lambda have odd denominator; Lambda(1,...,1) is odd;
        rank [M; Lambda] = rank M over Q (exact, FLINT).  Output in logs/certcheck2.out.
  logs/sweep_*.txt : the primal decision (kernel saturation) for every odd composite q <= 13105
     ("OB" = obstructed); obstructed exactly for the non-squares.

FILES (code/):
  core.py          layered Okada system in all q-1 unknowns (Theorem 2.2); test1.py validates it
                   (rank = phi+omega, kernel vectors have L(1,f)=0 numerically).
  twoadic.py       2-adic test on the full system (saturation, Lemma 4.3).
  shadow.py        the 2-shadow system (Theorem 4.5, integer form of Remark 4.6) and its test.
  shadow_b.py      equivalent test with unknowns b=(1-f)/2 and optional caps (relaxations).
  certgen2.py      certificate generator; certcheck2.py certificate checker.
  verify_full.py   independent implementation of Okada's original equations + numerics.
  legendre11025.py the counterexample of Table 1 and its hand-checkable identities.
  cert_table.py    character-coefficient verification for q = 27225.
  expand.py        expands a shadow solution (JSON) to the full list f(1..q-1).
  shadow_pm2.py    CP-SAT search for H-invariant Erdos functions (symmetric lifting),
                   options: parity odd/even, Legendre-only; structured_opt.py: the minimisation
                   that produced the Legendre solution; layerconst.py: gcd-only functions.
  relax1.py, parity_relax.py, refined.py : the relaxation experiments of Section 6.
  sweep.py         the decision sweep that produced logs/sweep_*.txt.
  gen_tables.py    regenerates Tables 1-3 of the paper from the defining data.

DATA (data/):
  f_11025_legendre.txt   f(1..11024) of Table 1 (whitespace separated).
  f_11025_first_found.txt the first counterexample found modulo 11025 (also verified).
  f_27225.txt            f(1..27224) of Table 4.
  shadow_solution_*.json the corresponding shadow solutions (sign patterns on Q_d).

LOGS (logs/): check_*.txt are the outputs of the commands above as run for the paper;
  sweep_*.txt the primal decision for all odd composite q <= 13105; batch_sq1.txt and
  batch_sq2.txt the CP-SAT runs on square moduli; certcheck2.out the certificate check;
  new_moduli_74.txt the moduli of Remark 5.8.

INDEPENDENT CHECK (independent_check/): a second program written from scratch, using only the
  statement of Okada's original equations (no characters, layers or descent).  task1*.log:
  re-verification of f_11025_first_found.txt and f_27225.txt (all Okada equations exactly 0 by
  two implementations; L(1,f) zero to >110 digits by three numerical methods, one digamma-free).
  task2_results.jsonl / exact_results.jsonl: for all 332 odd composite q <= 999, odd Okada
  vectors exist exactly for the 15 odd squares (two methods); exists_certificates.json gives
  explicit odd integer kernel vectors for those squares.
