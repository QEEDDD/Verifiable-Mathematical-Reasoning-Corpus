import sys, json, time
import sympy
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from shadow_pm2 import search
out = open(sys.argv[1], "a")
jobs = [(195, 1, 300), (315, 1, 600), (525, 1, 600), (735, 1, 600), (495, 1, 600), (825, 1, 600),
        (1155, 1, 900), (315, 0, 1800), (1155, 0, 1800)]
for m, quad, tl in jobs:
    q = m * m
    st, dt, sol, mm = search(q, tl, "any", quad, workers=1, seed=3)
    out.write(f"{m} {q} {dict(sympy.factorint(q))} quad={quad} {st} {dt:.1f}s\n"); out.flush()
    if sol:
        json.dump({"q": q, "fbar": sol, "m": mm}, open(f"sols/sol_{q}_quad{quad}.json", "w"))
out.close()
