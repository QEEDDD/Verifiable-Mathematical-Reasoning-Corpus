"""Human-checkable certificate for L(1,f)=0, q = 27225 = 3^2 5^2 11^2.

Decomposition (elementary): with f_d(x) = f((q/d)x) on U_d,
  L(1,f) = sum_{d|q,d>1} (d/q) * sum_{chi mod d} c_{d,chi} L(1,chi),  c = <f_d,chi>/phi(d),
  L(1,chi) = L(1,chi*) prod_{p|d, p not| cond}(1-chi*(p)/p),
and the principal parts give  (1/q) sum_p log p * [ sum_n f(n) eps_p(n) ] / ... .
So L(1,f)=0 follows from:
 (i)  A_chi := sum_{d: cond|d} (d/phi(d)) prod_{p|d,p not| cond}(1-chi(p)/p) <f_d,chi> = 0
      for every primitive chi != 1 of conductor dividing q;
 (ii) sum_n f(n) eps_p(n) = 0 for p = 3,5,11;  (iii) sum f = 0.
Step 1: check f is invariant under the odd-order subgroup H of U_q (then <f_d,chi>=0 unless
chi has 2-power order, i.e. chi = (./3)^a chi_5^b (./11)^c, chi_5(2)=i).
Step 2: tabulate <f_d,chi> for those 15 characters and evaluate A_chi exactly in Q(i)."""
import sys
from math import gcd
from fractions import Fraction
import sympy

q = 27225
vals = [int(x) for x in open(sys.argv[1]).read().split()]
f = [0] + vals
P = {3: 2, 5: 2, 11: 2}

# --- Step 1: invariance under H = odd part of U_q
U = [a for a in range(1, q) if gcd(a, q) == 1]
order2 = 16  # |2-part| = 2*4*2
gens = []
g = int(sympy.primitive_root(9)); h9 = None
# H = { u : u^{lcm of odd parts} ... } ; simplest: H = { x^16 : x in U }
H = sorted(set(pow(x, 16, q) for x in U))
assert len(H) * 16 == len(U), (len(H), len(U))
inv_ok = all(f[(h * n) % q] == f[n] for h in H[:50] for n in range(1, q))
# (checking all of H is cheap enough too)
inv_ok = inv_ok and all(f[(h * n) % q] == f[n] for h in H for n in range(1, q))
print("Step 1: |H| =", len(H), "; f invariant under H (all h, all n):", inv_ok)

# --- Gaussian rationals as pairs (re, im) of Fractions
def gmul(a, b): return (a[0]*b[0] - a[1]*b[1], a[0]*b[1] + a[1]*b[0])
def gadd(a, b): return (a[0]+b[0], a[1]+b[1])
I_POW = [(1, 0), (0, 1), (-1, 0), (0, -1)]
def ind2(x, p):
    x %= p; k = 0; y = 1
    while y != x: y = y * 2 % p; k += 1
    return k
def chi_val(a, b, c, x):
    """chi = (x/3)^a * chi5^b * (x/11)^c, chi5(x) = i^{ind_2(x mod 5)}; returns Gaussian int."""
    e = 0
    if a: e += 2 * (ind2(x, 3) % 2)
    if c: e += 2 * (ind2(x, 11) % 2)
    if b: e += b * (ind2(x, 5) % 4)
    return I_POW[e % 4]
def conj(z): return (z[0], -z[1])

D = [d for d in sympy.divisors(q) if d > 1]
results = []
chars = [(a, b, c) for a in (0, 1) for b in range(4) for c in (0, 1) if (a, b, c) != (0, 0, 0)]
table = {}
for (a, b, c) in chars:
    cond = (3 if a else 1) * (5 if b else 1) * (11 if c else 1)
    A = (Fraction(0), Fraction(0))
    for d in D:
        if d % cond: continue
        g_ = q // d
        S = (Fraction(0), Fraction(0))
        for x in range(1, d):
            if gcd(x, d) != 1: continue
            v = f[g_ * x]
            z = conj(chi_val(a, b, c, x))
            S = gadd(S, (v * z[0], v * z[1]))
        table[(a, b, c, d)] = S
        w = (Fraction(d, int(sympy.totient(d))), Fraction(0))
        for p in (3, 5, 11):
            if d % p == 0 and cond % p != 0:
                cp = chi_val(a, b, c, p)
                w = gmul(w, (1 - Fraction(cp[0], p), -Fraction(cp[1], p)))
        A = gadd(A, gmul(w, S))
    results.append(((a, b, c), cond, A))
print("Step 2: coefficients A_chi (should all be 0):")
for (abc, cond, A) in results:
    print("  chi=(3^%d,5^%d,11^%d) cond=%d  A_chi = %s + %s i" % (abc[0], abc[1], abc[2], cond, A[0], A[1]))

def vp(n, p):
    k = 0
    while n % p == 0: n //= p; k += 1
    return k
for p, e in P.items():
    s = Fraction(0)
    for n in range(1, q):
        v = min(vp(n, p), e)
        s += f[n] * (Fraction(v) - (Fraction(1, p - 1) if v < e else 0))
    print(f"Step 3: sum_n f(n) eps_{p}(n) = {s}")
print("Step 4: sum f =", sum(vals))
# dump the table of <f_d,chi> for the paper
with open(sys.argv[2], "w") as out:
    for key, S in sorted(table.items()):
        out.write(f"{key} {S[0]} {S[1]}\n")
print("table written:", len(table), "entries")
