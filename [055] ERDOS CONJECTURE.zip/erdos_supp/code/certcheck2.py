"""Verify certificates from certgen2: Lam must (i) have 2-integral entries, (ii) odd total,
(iii) lie in the Q-row space of the shadow system (rank test with exact integer matrices)."""
import sys, json
from fractions import Fraction
from math import lcm
import flint
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from shadow import Shadow

ok = bad = 0
for line in open(sys.argv[1]):
    rec = json.loads(line)
    q = rec["q"]
    if rec["lam"] is None:
        bad += 1; print("no certificate", q); continue
    lam = [Fraction(x) for x in rec["lam"]]
    S = Shadow(q); rows = S.rows(); n = S.nv
    assert len(lam) == n
    c1 = all(x.denominator % 2 == 1 for x in lam)
    tot = sum(lam, Fraction(0))
    c2 = tot.denominator % 2 == 1 and tot.numerator % 2 == 1
    L = lcm(*[x.denominator for x in lam])
    M = flint.fmpz_mat(len(rows), n, [r.get(j, 0) for r in rows for j in range(n)])
    M2 = flint.fmpz_mat(len(rows) + 1, n, [r.get(j, 0) for r in rows for j in range(n)] + [int(x * L) for x in lam])
    c3 = M.rank() == M2.rank()
    if c1 and c2 and c3: ok += 1
    else:
        bad += 1; print("FAILED", q, c1, c2, c3)
print("verified", ok, "failed", bad)
