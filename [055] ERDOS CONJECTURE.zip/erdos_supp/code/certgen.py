"""Generate explicit 2-adic obstruction certificates in the 2-shadow (f-form).
Certificate for q: rational multipliers y_i on the shadow rows R_i such that
Lambda = sum y_i R_i has 2-integral coefficients and Lambda(1,...,1) is a 2-adic unit.
Then for any odd 2-integral shadow solution phi: 0 = Lambda(phi) == Lambda(1) mod 2, impossible.
Output: JSON lines {q, y: {i: "num/den"}}.  Check with certcheck.py."""
import sys, json, time
from fractions import Fraction
import sympy
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from shadow import Shadow


def odd_unit(x):
    return x.denominator % 2 == 1 and x.numerator % 2 == 1


def bits(row, n):
    b = 0
    for j, x in row.items():
        if x.denominator % 2 == 0:
            raise ValueError
        if x.numerator % 2:
            b |= 1 << j
    return b


def certificate(q):
    S = Shadow(q)
    rows0 = S.rows()
    n = S.nv
    R = [{j: Fraction(v) for j, v in r.items()} for r in rows0]
    Y = [{i: Fraction(1)} for i in range(len(R))]
    while True:
        for i in range(len(R)):
            while R[i] and all(x.numerator % 2 == 0 for x in R[i].values()):
                R[i] = {j: x / 2 for j, x in R[i].items()}
                Y[i] = {k: v / 2 for k, v in Y[i].items()}
        piv = {}
        dep = None
        for i in range(len(R)):
            b = bits(R[i], n)
            c = 1 << i
            while b:
                h = b.bit_length() - 1
                if h in piv:
                    b ^= piv[h][0]
                    c ^= piv[h][1]
                else:
                    piv[h] = (b, c)
                    break
            if b == 0:
                dep = c
                break
        if dep is None:
            break
        idx = [i for i in range(len(R)) if dep >> i & 1]
        new, ny = {}, {}
        for i in idx:
            for j, x in R[i].items():
                new[j] = new.get(j, 0) + x / 2
            for k, v in Y[i].items():
                ny[k] = ny.get(k, 0) + v / 2
        R[idx[-1]] = {j: x for j, x in new.items() if x}
        Y[idx[-1]] = {k: v for k, v in ny.items() if v}
    for i in range(len(R)):
        tot = sum(R[i].values(), Fraction(0))
        if odd_unit(tot):
            return Y[i]
    return None


if __name__ == "__main__":
    lo, hi = int(sys.argv[1]), int(sys.argv[2])
    out = open(sys.argv[3], "a")
    import math
    t0 = time.time()
    for q in range(lo, hi + 1, 2):
        if q < 9 or sympy.isprime(q) or math.isqrt(q) ** 2 == q:
            continue
        y = certificate(q)
        rec = {"q": q, "y": {str(k): f"{v.numerator}/{v.denominator}" for k, v in y.items()} if y else None}
        out.write(json.dumps(rec) + "\n")
        out.flush()
        if y is None:
            print("NO CERTIFICATE", q, flush=True)
    print("done", lo, hi, f"{time.time()-t0:.0f}s", flush=True)
