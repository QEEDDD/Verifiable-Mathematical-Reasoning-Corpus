"""Fast obstruction certificates.  Certificate = a vector Lam (2-integral rationals, one per shadow
unknown) lying in the Q-row-space of the shadow system M, with Lam(1,...,1) odd.
Construction: saturated kernel basis k_j (mod 2 independent) -> Lam_bar in F_2^N with
Lam_bar . k_j = 0 (mod 2) and Lam_bar . 1 = 1 -> lift Lam = Lam_bar + 2w with Lam . k_j = 0 exactly.
Verification (certcheck2.py) only needs: rank[M;Lam] = rank M over Q, 2-integrality, odd sum."""
import sys, json, time, math
from fractions import Fraction
import flint, sympy
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from shadow import Shadow
from twoadic import saturate2


def make_cert(q):
    S = Shadow(q)
    rows = S.rows()
    n = S.nv
    M = flint.fmpz_mat(len(rows), n, [r.get(j, 0) for r in rows for j in range(n)])
    K, nul = M.nullspace()
    cols = [[int(K[i, j]) for i in range(n)] for j in range(nul)]
    if cols:
        sat, piv = saturate2(cols)
    else:
        sat, piv = [], {}
    # F_2 system:  Lam_bar . k_j = 0 for all j, Lam_bar . 1 = 1
    eqs = []
    for k in sat:
        b = 0
        for i, x in enumerate(k):
            if x & 1: b |= 1 << i
        eqs.append((b, 0))
    eqs.append(((1 << n) - 1, 1))
    # gaussian elimination on equations (each eq: bitmask over n unknowns, rhs)
    pivots = {}
    for b, r in eqs:
        while b:
            h = b.bit_length() - 1
            if h in pivots:
                pb, pr = pivots[h]; b ^= pb; r ^= pr
            else:
                pivots[h] = (b, r); break
        if b == 0 and r == 1:
            return None  # inconsistent -> not obstructed
    # back-substitute: free vars = 0
    sol = 0
    for h in sorted(pivots):
        b, r = pivots[h]
        # value at h determined by lower bits already set
        rest = b & ~(1 << h)
        val = r ^ (bin(rest & sol).count("1") & 1)
        if val: sol |= 1 << h
    lam_bar = [(sol >> i) & 1 for i in range(n)]
    # lift: w supported on pivot coordinates of sat mod 2 (the keys of piv)
    if sat:
        P = sorted(piv.keys())  # pivot bit positions, one per basis vector
        m = len(sat)
        assert len(P) == m
        A = flint.fmpq_mat(m, m, [sat[j][i] for j in range(m) for i in P])
        c = []
        for k in sat:
            s = sum(lb * x for lb, x in zip(lam_bar, k))
            assert s % 2 == 0
            c.append(-s // 2)
        C = flint.fmpq_mat(m, 1, c)
        W = A.solve(C)
        w = [Fraction(0)] * n
        for t, i in enumerate(P):
            v = W[t, 0]
            w[i] = Fraction(int(v.p), int(v.q))
    else:
        w = [Fraction(0)] * n
    lam = [Fraction(lb) + 2 * wi for lb, wi in zip(lam_bar, w)]
    assert all(x.denominator % 2 == 1 for x in lam)
    tot = sum(lam, Fraction(0))
    assert tot.numerator % 2 == 1
    for k in sat:
        assert sum(x * kk for x, kk in zip(lam, k)) == 0
    return lam


if __name__ == "__main__":
    lo, hi = int(sys.argv[1]), int(sys.argv[2])
    out = open(sys.argv[3], "a")
    step = int(sys.argv[4]) if len(sys.argv) > 4 else 1
    off = int(sys.argv[5]) if len(sys.argv) > 5 else 0
    t0 = time.time()
    for q in range(lo, hi + 1, 2):
        if ((q - lo) // 2) % step != off: continue
        if q < 9 or sympy.isprime(q) or math.isqrt(q) ** 2 == q:
            continue
        t1 = time.time()
        lam = make_cert(q)
        rec = {"q": q, "lam": [f"{x.numerator}/{x.denominator}" if x.denominator != 1 else str(x.numerator) for x in lam] if lam else None,
               "sec": round(time.time() - t1, 2)}
        out.write(json.dumps(rec) + "\n"); out.flush()
        if lam is None: print("NOT OBSTRUCTED", q, flush=True)
    print("done", f"{time.time()-t0:.0f}s", flush=True)
