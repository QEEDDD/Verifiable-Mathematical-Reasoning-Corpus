"""Rebuild the q=27225 counterexample from the published LaTeX table (tab_27225.tex) using the
conventions stated in its caption, and compare with the value list."""
import sys, re
from math import gcd
from itertools import product
q = 27225
def ind2(x, p):
    x %= p; k = 0; y = 1
    while y != x:
        y = y * 2 % p; k += 1
    return k
rows = {}
for line in open(sys.argv[1]):
    m = re.match(r"^(\d+) & (\d+) & \$\((.*?)\)\$ & \\texttt\{([+-]+)\}", line)
    if m:
        d = int(m.group(1)); rows[d] = m.group(4)
assert len(rows) == 26, len(rows)
vals = []
for n in range(1, q):
    g = gcd(n, q); d = q // g; x = n // g
    pr = [p for p in (3, 5, 11) if d % p == 0]
    mods = {3: 2, 5: 4, 11: 2}
    coords = [ind2(x, p) % mods[p] for p in pr]
    # lexicographic index
    idx = 0
    for c, p in zip(coords, pr):
        idx = idx * mods[p] + c
    vals.append(1 if rows[d][idx] == '+' else -1)
ref = [int(v) for v in open(sys.argv[2]).read().split()]
print("table reproduces value list:", vals == ref, " sum:", sum(vals))
