"""Expand a shadow solution (fbar on 2-quotients) to the full function f(1..q-1)."""
import sys, json
from math import gcd
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from shadow import Shadow
D = json.load(open(sys.argv[1])); q = D["q"]
S = Shadow(q)
fb = {}
for k, v in D["fbar"].items():
    d, x = k.split(":"); fb[(int(d), tuple(int(t) for t in x.split(",")))] = v
vals = []
for n in range(1, q):
    g = gcd(n, q); d = q // g; x = n // g
    pr = S.rad_primes(d)
    img = tuple(S.dl[p][x % p] % (2 ** S.t[p]) for p in pr)
    vals.append(fb[(d, img)])
open(sys.argv[2], "w").write(" ".join(map(str, vals)) + "\n")
print("wrote", len(vals), "values; sum =", sum(vals))
