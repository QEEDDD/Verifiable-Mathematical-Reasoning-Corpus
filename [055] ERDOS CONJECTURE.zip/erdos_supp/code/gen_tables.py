"""Generate LaTeX tables for the paper (from the defining data, not from search output)."""
import sys, json
from fractions import Fraction
from itertools import product
import sympy
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from legendre11025 import TABLE, leg

primes = [3, 5, 7]
D = sorted(TABLE)
FORMULA = {
    3: r"$-1$", 5: r"$-\lambda_5$", 7: r"$-\lambda_7$", 9: r"$-1$", 15: r"$-\lambda_3\lambda_5$",
    21: r"$1$ if $\lambda_3=1$; $-\lambda_7$ if $\lambda_3=-1$", 25: r"$\lambda_5$", 35: r"$\lambda_5\lambda_7$",
    45: r"$-1$ if $\lambda_3=1$; $\lambda_5$ if $\lambda_3=-1$", 49: r"$-\lambda_7$",
    63: r"$1$ if $\lambda_3=1$; $-\lambda_7$ if $\lambda_3=-1$",
    75: r"$1$ if $\lambda_3=1$; $-\lambda_5$ if $\lambda_3=-1$",
    105: r"$-\lambda_7$ if $\lambda_3=1$; $-1$ if $\lambda_3=-1$", 147: r"$\lambda_7$",
    175: r"$-\lambda_5\lambda_7$", 225: r"$\lambda_3$", 245: r"$\lambda_5\lambda_7$", 315: r"$\lambda_5\lambda_7$",
    441: r"$-\lambda_3$", 525: r"$\lambda_5\lambda_7$", 735: r"$\lambda_5\lambda_7$", 1225: r"$\lambda_5\lambda_7$",
    1575: r"$\lambda_5\lambda_7$", 2205: r"$\lambda_5\lambda_7$", 3675: r"$\lambda_5\lambda_7$", 11025: r"$-\lambda_5\lambda_7$",
}

def coef(d, m):
    pr = [p for p in primes if d % p == 0]
    s = Fraction(0)
    for signs in product([1, -1], repeat=len(pr)):
        L = dict(zip(pr, signs))
        val = TABLE[d](L.get(3), L.get(5), L.get(7))
        w = 1
        for p in pr:
            if m % p == 0: w *= L[p]
        s += val * w
    return s / 2 ** len(pr)

def frac(x):
    x = Fraction(x)
    if x.denominator == 1: return f"{x.numerator}"
    sign = "-" if x < 0 else ""
    return f"{sign}\\tfrac{{{abs(x.numerator)}}}{{{x.denominator}}}"

def mname(m):
    return "1" if m == 1 else str(m)

out = []
# Table 1
out.append(r"\begin{longtable}{rrrll}")
out.append(r"\caption{The counterexample modulo $q=11025$: for $n$ with $\gcd(n,q)=q/d$ write $n=(q/d)x$; then $f(n)=F_d(x)$, where $\lambda_p=\bigl(\tfrac{x}{p}\bigr)$. The last column gives the expansion $F_d=\sum_m c_{d,m}\lambda_m$ ($\lambda_m=\prod_{p\mid m}\lambda_p$).}\label{tab:11025}\\")
out.append(r"\toprule $d$ & $q/d$ & $\varphi(d)$ & $F_d(x)$ & nonzero $c_{d,m}$\\ \midrule\endfirsthead")
out.append(r"\toprule $d$ & $q/d$ & $\varphi(d)$ & $F_d(x)$ & nonzero $c_{d,m}$\\ \midrule\endhead")
for d in D:
    cs = []
    pr = [p for p in primes if d % p == 0]
    for e in product([0, 1], repeat=len(pr)):
        m = 1
        for p, ee in zip(pr, e):
            if ee: m *= p
        c = coef(d, m)
        if c: cs.append(f"$c_{{{mname(m)}}}={frac(c)}$")
    out.append(f"{d} & {11025//d} & {sympy.totient(d)} & {FORMULA[d]} & " + ", ".join(cs) + r"\\")
out.append(r"\bottomrule\end{longtable}")
open(sys.argv[1] + "/tab_11025.tex", "w").write("\n".join(out) + "\n")

# Table 2: character identities
out = []
out.append(r"\begin{table}[ht]\centering\small")
out.append(r"\caption{The seven identities $\sum_{m\mid d} w_{d,m}c_{d,m}=0$, with $w_{d,m}=d\prod_{p\mid d,\,p\nmid m}\bigl(1-\chi_m(p)/p\bigr)$; entries are $w_{d,m}c_{d,m}$ for the layers with $c_{d,m}\neq0$.}\label{tab:chars}")
out.append(r"\begin{tabular}{lll}\toprule $m$ & $\chi_m(p)$, $p\nmid m$ & terms $w_{d,m}c_{d,m}$ (layer $d$ in brackets) \\ \midrule")
for m in [3, 5, 7, 15, 21, 35, 105]:
    def chi(a):
        v = 1
        for p in primes:
            if m % p == 0: v *= leg(a, p)
        return v
    terms = []; tot = Fraction(0)
    for d in D:
        if d % m: continue
        c = coef(d, m)
        if not c: continue
        w = Fraction(d)
        for p in primes:
            if d % p == 0 and m % p != 0:
                w *= (1 - Fraction(chi(p), p))
        terms.append(f"${frac(w*c)}\\,[{d}]$"); tot += w * c
    assert tot == 0
    vals = ", ".join(f"$\\chi_{{{m}}}({p})={chi(p):+d}$" for p in primes if m % p)
    out.append(f"{m} & {vals if vals else '---'} & " + " ".join(terms) + r" \\")
out.append(r"\bottomrule\end{tabular}\end{table}")
open(sys.argv[1] + "/tab_chars.tex", "w").write("\n".join(out) + "\n")

# Table 3: log identities
out = []
out.append(r"\begin{table}[ht]\centering\small")
out.append(r"\caption{Layer sums $S_d=\varphi(d)c_{d,1}$ (layers with $S_d\ne0$) and the weights $\varepsilon_p(d)=v_p(q/d)-[p\mid d]/(p-1)$.}\label{tab:logs}")
out.append(r"\begin{tabular}{rrrrr}\toprule $d$ & $S_d$ & $\varepsilon_3(d)$ & $\varepsilon_5(d)$ & $\varepsilon_7(d)$ \\ \midrule")
sums = {p: Fraction(0) for p in primes}; tot = 0
for d in D:
    S = sympy.totient(d) * coef(d, 1)
    if not S: continue
    eps = {}
    for p in primes:
        vd = sympy.multiplicity(p, d)
        eps[p] = Fraction(2 - vd) - (Fraction(1, p - 1) if vd > 0 else 0)
        sums[p] += S * eps[p]
    tot += S
    out.append(f"{d} & {S} & ${frac(eps[3])}$ & ${frac(eps[5])}$ & ${frac(eps[7])}$ \\\\")
out.append(r"\midrule $\sum$ & " + f"{tot} & " + " & ".join(f"$\\sum S_d\\varepsilon_{p}={sums[p]}$" for p in primes) + r" \\")
out.append(r"\bottomrule\end{tabular}\end{table}")
open(sys.argv[1] + "/tab_logs.tex", "w").write("\n".join(out) + "\n")
print("tables written; sums:", tot, sums)
