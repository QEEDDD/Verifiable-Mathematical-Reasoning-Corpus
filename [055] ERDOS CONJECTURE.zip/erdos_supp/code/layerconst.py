"""Layer-constant Erdos functions f(n)=s(gcd(n,q)): counterexample iff
sum_d s_d phi(d) = 0 and sum_d s_d phi(d) w_p(d) = 0 for all p|q,
w_p(d) = (p-1)(e_p - v_p(d)) - [v_p(d)>0].  CP-SAT feasibility."""
import sys
import sympy
from ortools.sat.python import cp_model

def vp(n, p):
    k = 0
    while n % p == 0: n //= p; k += 1
    return k

def solve(q, tl=60):
    P = sympy.factorint(q)
    D = [int(d) for d in sympy.divisors(q) if d > 1]
    phi = {d: int(sympy.totient(d)) for d in D}
    model = cp_model.CpModel()
    y = {d: model.NewBoolVar(f"y{d}") for d in D}
    eqs = [{d: phi[d] for d in D}]
    for p, e in P.items():
        eqs.append({d: phi[d] * ((p - 1) * (e - vp(d, p)) - (1 if vp(d, p) > 0 else 0)) for d in D})
    for E in eqs:
        model.Add(sum(2 * c * y[d] for d, c in E.items()) == sum(E.values()))
    s = cp_model.CpSolver(); s.parameters.max_time_in_seconds = tl; s.parameters.num_workers = 1
    st = s.Solve(model)
    sol = {d: 2 * s.Value(y[d]) - 1 for d in D} if st in (cp_model.OPTIMAL, cp_model.FEASIBLE) else None
    return s.StatusName(st), sol

if __name__ == "__main__":
    for a in sys.argv[1:]:
        q = int(a)
        st, sol = solve(q)
        print(q, dict(sympy.factorint(q)), st, sol if sol and len(sol) < 40 else ("(solution found)" if sol else ""))
