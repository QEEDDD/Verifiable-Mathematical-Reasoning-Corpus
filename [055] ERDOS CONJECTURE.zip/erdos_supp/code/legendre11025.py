"""The Legendre-symbol counterexample mod q = 11025 = 3^2 5^2 7^2, built directly from its
defining table (independent of the search code), and a hand-checkable proof of L(1,f)=0.

For n not divisible by q: g = gcd(n,q), d = q/g, x = n/g (gcd(x,d)=1),
l3=(x/3) if 3|d, l5=(x/5) if 5|d, l7=(x/7) if 7|d.  f(n) = F_d(l3,l5,l7) from TABLE."""
import sys
from math import gcd
from fractions import Fraction
from itertools import product
import sympy

q = 11025


def leg(x, p):
    return int(sympy.legendre_symbol(x % p, p))


TABLE = {
    3: lambda l3, l5, l7: -1,
    5: lambda l3, l5, l7: -l5,
    7: lambda l3, l5, l7: -l7,
    9: lambda l3, l5, l7: -1,
    15: lambda l3, l5, l7: -l3 * l5,
    21: lambda l3, l5, l7: 1 if l3 == 1 else -l7,
    25: lambda l3, l5, l7: l5,
    35: lambda l3, l5, l7: l5 * l7,
    45: lambda l3, l5, l7: -1 if l3 == 1 else l5,
    49: lambda l3, l5, l7: -l7,
    63: lambda l3, l5, l7: 1 if l3 == 1 else -l7,
    75: lambda l3, l5, l7: 1 if l3 == 1 else -l5,
    105: lambda l3, l5, l7: -l7 if l3 == 1 else -1,
    147: lambda l3, l5, l7: l7,
    175: lambda l3, l5, l7: -l5 * l7,
    225: lambda l3, l5, l7: l3,
    245: lambda l3, l5, l7: l5 * l7,
    315: lambda l3, l5, l7: l5 * l7,
    441: lambda l3, l5, l7: -l3,
    525: lambda l3, l5, l7: l5 * l7,
    735: lambda l3, l5, l7: l5 * l7,
    1225: lambda l3, l5, l7: l5 * l7,
    1575: lambda l3, l5, l7: l5 * l7,
    2205: lambda l3, l5, l7: l5 * l7,
    3675: lambda l3, l5, l7: l5 * l7,
    11025: lambda l3, l5, l7: -l5 * l7,
}


def f_of(n):
    if n % q == 0:
        return 0
    g = gcd(n, q); d = q // g; x = n // g
    l3 = leg(x, 3) if d % 3 == 0 else None
    l5 = leg(x, 5) if d % 5 == 0 else None
    l7 = leg(x, 7) if d % 7 == 0 else None
    return TABLE[d](l3, l5, l7)


if __name__ == "__main__":
    vals = [f_of(n) for n in range(1, q)]
    assert set(vals) == {1, -1}
    print("sum f =", sum(vals))
    if len(sys.argv) > 1:
        other = [int(v) for v in open(sys.argv[1]).read().split()]
        print("agrees with search output file:", other == vals)
    open("f_11025_legendre.txt", "w").write(" ".join(map(str, vals)) + "\n")
    # expansion of each layer function in real characters: f_d = sum_m c_{d,m} lambda_m
    primes = [3, 5, 7]
    D = sorted(TABLE)
    coef = {}
    for d in D:
        pr = [p for p in primes if d % p == 0]
        for m_set in product([0, 1], repeat=len(pr)):
            m = 1
            for p, e in zip(pr, m_set):
                if e: m *= p
            # c = average over sign patterns of F * prod l_p^{e}
            s = Fraction(0)
            for signs in product([1, -1], repeat=len(pr)):
                L = dict(zip(pr, signs))
                val = TABLE[d](L.get(3), L.get(5), L.get(7))
                w = 1
                for p, e in zip(pr, m_set):
                    if e: w *= L[p]
                s += val * w
            coef[(d, m)] = s / 2 ** len(pr)
    print("layer expansions f_d = sum c_{d,m} (x/m):")
    for d in D:
        terms = {m: c for (dd, m), c in coef.items() if dd == d and c}
        print("  d=%-5d phi=%-5d %s" % (d, sympy.totient(d), terms))
    # coefficients of L(1,chi_m) for the 7 nontrivial real primitive characters chi_m, m | 105
    def chi(m, a):
        v = 1
        for p in primes:
            if m % p == 0: v *= leg(a, p)
        return v
    print("A_chi (times q):")
    for m in [3, 5, 7, 15, 21, 35, 105]:
        A = Fraction(0)
        for d in D:
            if d % m: continue
            w = Fraction(d)
            for p in primes:
                if d % p == 0 and m % p != 0:
                    w *= (1 - Fraction(chi(m, p), p))
            A += w * coef[(d, m)]
        print(f"  m={m}: chi(p) for p not | m: {[(p, chi(m,p)) for p in primes if m % p]},  A = {A}")
    # log p coefficients:  sum_d S_d eps_p(d), S_d = phi(d) c_{d,1}
    for p in primes:
        s = Fraction(0)
        for d in D:
            vd = sympy.multiplicity(p, d)
            eps = Fraction(2 - vd) - (Fraction(1, p - 1) if vd > 0 else 0)
            s += sympy.totient(d) * coef[(d, 1)] * eps
        print(f"  B_{p}: sum_d S_d eps_p(d) = {s}")
    print("  C: sum_d S_d =", sum(sympy.totient(d) * coef[(d, 1)] for d in D))
