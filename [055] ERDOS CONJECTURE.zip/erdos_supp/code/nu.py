import sys
from fractions import Fraction
import sympy
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from shadow import Shadow
from certshadow import sat_rows
from gammalat import v2
def nu(q):
    S = Shadow(q); rows = S.rows(); n = S.nv
    R = sat_rows(rows, n)
    return min(v2(sum(r)) for r in R)
if __name__ == "__main__":
    for a in sys.argv[1:]:
        q = int(a); print(q, dict(sympy.factorint(q)), "nu =", nu(q), "v2(q-1) =", v2(q-1), flush=True)
