"""Relaxations: keep only odd-character (A) conditions (+ (C)), or only even ones (+ (B),(C)).
Test whether the 2-adic obstruction already follows."""
import sys
from itertools import product
import flint
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from shadow import Shadow
from twoadic import saturate2, in_span

def rows_parity(S, which):
    rows = []; q = S.q; primes = S.primes
    sqfree = [f for f in S.layers if all(f % (p * p) for p in primes)]
    for f in sqfree:
        fp = S.rad_primes(f); sizes = [2 ** S.t[p] for p in fp]
        Qf = list(product(*[range(s) for s in sizes]))
        H = {y: {} for y in Qf}
        for d in S.layers:
            if d % f: continue
            dp = S.rad_primes(d); c = 1
            for p in primes:
                if d % p: c *= (p - 1)
            Sx = [p for p in dp if f % p]
            shifts = {p: S.image(p, fp) for p in Sx}
            idx = [dp.index(p) for p in fp]
            for mask in range(1 << len(Sx)):
                coef = c * (-1) ** bin(mask).count("1"); sh = [0] * len(fp)
                for i, p in enumerate(Sx):
                    if mask >> i & 1: sh = [(a + b) % s for a, b, s in zip(sh, shifts[p], sizes)]
                    else: coef *= p
                for (dd, x), vi in S.var.items():
                    if dd != d: continue
                    z = tuple(x[i] for i in idx)
                    y = tuple((a - b) % s for a, b, s in zip(z, sh, sizes))
                    H[y][vi] = H[y].get(vi, 0) + coef
        iota = tuple(s // 2 for s in sizes)
        sgn = -1 if which == "odd" else 1
        Hp = {}
        for y in Qf:
            y2 = tuple((a + b) % s for a, b, s in zip(y, iota, sizes))
            row = dict(H[y])
            for k, v in H[y2].items(): row[k] = row.get(k, 0) + sgn * v
            Hp[y] = row
        w = len(fp)
        for ks in product(*[range(1, s) for s in sizes]):
            row = {}
            for eps in range(1 << w):
                y = tuple(0 if (eps >> i & 1) else ks[i] for i in range(w))
                sg = (-1) ** bin(eps).count("1")
                for vi, cf in Hp[y].items(): row[vi] = row.get(vi, 0) + sg * cf
            row = {k: v for k, v in row.items() if v}
            if row: rows.append(row)
    return rows

def test(q, which):
    S = Shadow(q); full = S.rows()
    rows = rows_parity(S, which)
    tail = full[-(len(S.primes) + 1):]
    rows += tail if which == "even" else tail[-1:]
    n = S.nv
    M = flint.fmpz_mat(len(rows), n, [r.get(j, 0) for r in rows for j in range(n)])
    K, nul = M.nullspace()
    cols = [[int(K[i, j]) for i in range(n)] for j in range(nul)]
    sat, piv = saturate2(cols)
    return not in_span(piv, (1 << n) - 1)

if __name__ == "__main__":
    which = sys.argv[1]
    out = []
    for a in sys.argv[2:]:
        q = int(a); out.append(f"{q}({q%8}):{'OB' if test(q, which) else 'no'}")
    print(which, " ".join(out))
