"""Refined 2-adic test using the parity splitting f = f_e + f_o.
For an Erdos f: f_e=(f+f(-.))/2 and f_o=(f-f(-.))/2 are {0,+-1}-valued, lie in the
Okada space separately, and f_e + f_o = f is odd everywhere.  In the 2-shadow:
pushforwards phi_e in K^+ (iota-even part), phi_o in K^- (iota-odd part), with
phi_e + phi_o == 1 (mod 2).  Test: is 1 in (K^+ mod 2) + (K^- mod 2) ?"""
import sys
import flint, sympy
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from shadow import Shadow
from twoadic import saturate2, in_span


def kernel_cols(rows, n):
    M = flint.fmpz_mat(len(rows), n, [r.get(j, 0) for r in rows for j in range(n)])
    K, nul = M.nullspace()
    return [[int(K[i, j]) for i in range(n)] for j in range(nul)]


def refined_test(q):
    S = Shadow(q)
    rows = S.rows()
    n = S.nv
    # involution iota on variables
    perm = [None] * n
    for (d, x), vi in S.var.items():
        pr = S.rad_primes(d)
        y = tuple((xi + 2 ** (S.t[p] - 1)) % (2 ** S.t[p]) for xi, p in zip(x, pr))
        perm[vi] = S.var[(d, y)]
    res = {}
    for sign in (+1, -1):
        extra = []
        for i in range(n):
            j = perm[i]
            if i < j:
                extra.append({i: 1, j: -sign})
            elif i == j and sign == -1:
                extra.append({i: 1})
        cols = kernel_cols(rows + extra, n)
        if cols:
            sat, piv = saturate2(cols)
            res[sign] = [p[0] for p in piv.values()]
        else:
            res[sign] = []
    # combined span mod 2
    piv = {}
    def add(b):
        while b:
            h = b.bit_length() - 1
            if h in piv:
                b ^= piv[h]
            else:
                piv[h] = b
                return
    for b in res[1] + res[-1]:
        add(b)
    ones = (1 << n) - 1
    b = ones
    while b:
        h = b.bit_length() - 1
        if h in piv:
            b ^= piv[h]
        else:
            break
    return b != 0, len(res[1]), len(res[-1]), n


if __name__ == "__main__":
    for a in sys.argv[1:]:
        q = int(a)
        ob, dp, dm, n = refined_test(q)
        print(q, dict(sympy.factorint(q)), "REFINED-OBSTRUCTED" if ob else "no refined obstruction",
              "dims", dp, dm, "nvars", n, flush=True)
