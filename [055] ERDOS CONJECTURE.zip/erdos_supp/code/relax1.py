"""Relaxation: keep only (A_f) for f prime (single-prime characters) + (B),(C). Still obstructed?"""
import sys
import flint, sympy
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from shadow import Shadow
from twoadic import saturate2, in_span

class Shadow1(Shadow):
    def rows(self):
        allrows = super().rows()
        return allrows

def test(q, maxsupp):
    S = Shadow(q)
    # rebuild rows but filter f by number of prime factors
    import types
    primes = S.primes
    orig_layers = S.layers
    rows = []
    # monkeypatch: compute rows for each squarefree f separately by temporarily restricting
    full = S.rows()
    # identify which rows came from which f: recompute per f
    rows = []
    sqfree = [f for f in orig_layers if all(f % (p*p) for p in primes)]
    for f in sqfree:
        if len(S.rad_primes(f)) > maxsupp: continue
        S2 = Shadow(q)
        S2.layers_backup = S2.layers
        # restrict rows(): only this f in the sqfree loop; we emulate by filtering via a flag
        rows += rows_for_f(S2, f)
    # (B),(C) are the last omega+1 rows of full
    rows += full[-(len(primes) + 1):]
    n = S.nv
    M = flint.fmpz_mat(len(rows), n, [r.get(j, 0) for r in rows for j in range(n)])
    K, nul = M.nullspace()
    cols = [[int(K[i, j]) for i in range(n)] for j in range(nul)]
    sat, piv = saturate2(cols)
    return not in_span(piv, (1 << n) - 1)

def rows_for_f(S, f0):
    from itertools import product
    rows = []; q = S.q; primes = S.primes
    f = f0
    fp = S.rad_primes(f); sizes = [2 ** S.t[p] for p in fp]
    Qf = list(product(*[range(s) for s in sizes]))
    H = {y: {} for y in Qf}
    for d in S.layers:
        if d % f: continue
        dp = S.rad_primes(d); c = 1
        for p in primes:
            if d % p: c *= (p - 1)
        Sx = [p for p in dp if f % p]
        shifts = {p: S.image(p, fp) for p in Sx}
        idx = [dp.index(p) for p in fp]
        for mask in range(1 << len(Sx)):
            coef = c * (-1) ** bin(mask).count("1"); sh = [0] * len(fp)
            for i, p in enumerate(Sx):
                if mask >> i & 1: sh = [(a + b) % s for a, b, s in zip(sh, shifts[p], sizes)]
                else: coef *= p
            for (dd, x), vi in S.var.items():
                if dd != d: continue
                z = tuple(x[i] for i in idx)
                y = tuple((a - b) % s for a, b, s in zip(z, sh, sizes))
                H[y][vi] = H[y].get(vi, 0) + coef
    w = len(fp)
    for ks in product(*[range(1, s) for s in sizes]):
        row = {}
        for eps in range(1 << w):
            y = tuple(0 if (eps >> i & 1) else ks[i] for i in range(w))
            sgn = (-1) ** bin(eps).count("1")
            for vi, cf in H[y].items(): row[vi] = row.get(vi, 0) + sgn * cf
        row = {k: v for k, v in row.items() if v}
        if row: rows.append(row)
    return rows

if __name__ == "__main__":
    ms = int(sys.argv[1])
    res = []
    for a in sys.argv[2:]:
        q = int(a); ob = test(q, ms)
        res.append(f"{q}:{'OB' if ob else 'no'}")
    print("maxsupp", ms, " ".join(res))
