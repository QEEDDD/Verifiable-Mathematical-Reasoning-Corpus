"""b-form 2-adic test with optional cap on the 2-power quotient (valid relaxation).

Unknowns b_d on Q'_d = prod_{p|d} C_{2^{t'_p}}, t'_p = min(t_p, cap).  f = 1 - 2b (pushed forward).
(A): homogeneous primitive-character conditions for characters of Q'.
(B),(C): affine:  sum_d w_p(d) sigma_d = -e_p (p-1)/2 ,  sum_d sigma_d = (q-1)/2,
          sigma_d = sum of b_d over Q'_d, w_p(d) = (p-1)(e_p - v_p(d)) - [v_p(d)>0].
Obstructed  <=>  target not in the Z_(2)-image of the (A)-kernel lattice under sigma -> (B,C).
With cap = infinity this is equivalent to the f-form test; with a cap it is a relaxation
(an obstruction for the capped system implies one for the full system)."""
import sys
from fractions import Fraction
from itertools import product
import flint, sympy
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from shadow import Shadow, v2 as v2int
from twoadic import saturate2


class ShadowCap(Shadow):
    def __init__(self, q, cap=None):
        super().__init__(q)
        if cap is not None:
            for p in self.t:
                self.t[p] = min(self.t[p], cap)
            self.var = {}
            for d in self.layers:
                pr = [p for p in self.primes if d % p == 0]
                for x in product(*[range(2 ** self.t[p]) for p in pr]):
                    self.var[(d, x)] = len(self.var)
            self.nv = len(self.var)


def v2(x):
    x = Fraction(x)
    if x == 0:
        return 10 ** 9
    n, d = x.numerator, x.denominator
    k = 0
    while n % 2 == 0:
        n //= 2; k += 1
    while d % 2 == 0:
        d //= 2; k -= 1
    return k


def member2(gens, target):
    """Is target (vector of rationals) in the Z_(2)-span of integer vectors gens?"""
    m = len(target)
    G = [[Fraction(x) for x in g] for g in gens if any(g)]
    t = [Fraction(x) for x in target]
    for col in range(m):
        piv = None
        for g in G:
            if g[col] != 0 and (piv is None or v2(g[col]) < v2(piv[col])):
                piv = g
        if piv is None:
            if t[col] != 0:
                return False
            continue
        G = [g for g in G if g is not piv]
        # reduce others and target (2-integral multipliers only)
        newG = []
        for g in G:
            if g[col] != 0:
                c = g[col] / piv[col]
                assert v2(c) >= 0
                g = [a - c * b for a, b in zip(g, piv)]
            newG.append(g)
        G = newG
        if t[col] != 0:
            c = t[col] / piv[col]
            if v2(c) < 0:
                return False
            t = [a - c * b for a, b in zip(t, piv)]
    return all(x == 0 for x in t)


def test_b(q, cap=None):
    S = ShadowCap(q, cap)
    rows = S.rows()
    k = len(S.primes) + 1
    Arows, BC = rows[:-k], rows[-k:]
    n = S.nv
    if Arows:
        M = flint.fmpz_mat(len(Arows), n, [r.get(j, 0) for r in Arows for j in range(n)])
        K, nul = M.nullspace()
        cols = [[int(K[i, j]) for i in range(n)] for j in range(nul)]
        sat, piv = saturate2(cols)
    else:
        sat = [[1 if j == i else 0 for j in range(n)] for i in range(n)]
    gens = []
    for c in sat:
        gens.append([sum(r.get(j, 0) * c[j] for j in range(n)) for r in BC])
    target = []
    for (p, e) in sorted(S.P.items()):
        target.append(Fraction(-e * (p - 1), 2))
    target.append(Fraction(q - 1, 2))
    return (not member2(gens, target)), n


if __name__ == "__main__":
    cap = None if sys.argv[1] == "none" else int(sys.argv[1])
    for a in sys.argv[2:]:
        q = int(a)
        ob, n = test_b(q, cap)
        print(q, dict(sympy.factorint(q)), "cap", cap, "OBSTRUCTED" if ob else "no-obstruction", "nvars", n, flush=True)
