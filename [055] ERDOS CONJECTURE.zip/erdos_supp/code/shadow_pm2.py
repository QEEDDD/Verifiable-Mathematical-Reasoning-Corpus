"""Symmetric +-1 search with optional extra symmetry:
  parity=odd/even/any : fbar(x+iota) = -fbar(x) / +fbar(x)
  quad=1              : fbar invariant under the squares subgroup (depends only on Legendre symbols)
"""
import sys, time, json
import sympy
from ortools.sat.python import cp_model
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from shadow import Shadow

def search(q, tlimit=600, parity="any", quad=0, workers=2, seed=0):
    S = Shadow(q); rows = S.rows(); n = S.nv
    inv = {vi: key for key, vi in S.var.items()}
    m = {}
    for d in S.layers:
        size = 1
        for p in S.rad_primes(d): size *= 2 ** S.t[p]
        m[d] = int(sympy.totient(d)) // size
    model = cp_model.CpModel()
    y = [model.NewBoolVar(f"y{i}") for i in range(n)]
    for r in rows:
        coefs = {v: c * m[inv[v][0]] for v, c in r.items()}
        model.Add(sum(2 * c * y[v] for v, c in coefs.items()) == sum(coefs.values()))
    for (d, x), vi in S.var.items():
        pr = S.rad_primes(d)
        if parity != "any":
            z = tuple((xi + 2 ** (S.t[p] - 1)) % (2 ** S.t[p]) for xi, p in zip(x, pr))
            vj = S.var[(d, z)]
            if parity == "odd": model.Add(y[vi] + y[vj] == 1)
            else: model.Add(y[vi] == y[vj])
        if quad:
            for k, p in enumerate(pr):
                if S.t[p] >= 2:
                    z = list(x); z[k] = (z[k] + 2) % (2 ** S.t[p]); vj = S.var[(d, tuple(z))]
                    model.Add(y[vi] == y[vj])
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = tlimit
    solver.parameters.num_workers = workers
    solver.parameters.random_seed = seed
    t0 = time.time(); st = solver.Solve(model)
    sol = None
    if st in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        sol = {f"{inv[i][0]}:{','.join(map(str, inv[i][1]))}": 2 * solver.Value(y[i]) - 1 for i in range(n)}
    return solver.StatusName(st), time.time() - t0, sol, m

if __name__ == "__main__":
    q = int(sys.argv[1]); tl = float(sys.argv[2]); parity = sys.argv[3]; quad = int(sys.argv[4])
    st, dt, sol, m = search(q, tl, parity, quad)
    print(q, parity, "quad" if quad else "", st, f"{dt:.1f}s", flush=True)
    if sol:
        out = f"sol_{q}_{parity}_{quad}.json"
        json.dump({"q": q, "fbar": sol, "m": m}, open(out, "w")); print("saved", out)
