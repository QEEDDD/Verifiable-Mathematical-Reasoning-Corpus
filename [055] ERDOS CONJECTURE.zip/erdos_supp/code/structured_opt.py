"""Minimize deviations from the pattern fbar_d = s_d * (x/K) on layers K|d (others free, but
also penalize non-constant patterns there? no). Objective: number of deviating shadow points."""
import sys, json
import sympy
from ortools.sat.python import cp_model
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from shadow import Shadow

def run(q, Kprimes, tl, seed=0, hint=None):
    S = Shadow(q); rows = S.rows(); n = S.nv
    inv = {vi: key for key, vi in S.var.items()}
    m = {}
    for d in S.layers:
        size = 1
        for p in S.rad_primes(d): size *= 2 ** S.t[p]
        m[d] = int(sympy.totient(d)) // size
    model = cp_model.CpModel()
    y = [model.NewBoolVar(f"y{i}") for i in range(n)]
    for r in rows:
        coefs = {v: c * m[inv[v][0]] for v, c in r.items()}
        model.Add(sum(2 * c * y[v] for v, c in coefs.items()) == sum(coefs.values()))
    K = 1
    for p in Kprimes: K *= p
    sd = {}; dev = []
    for (d, x), vi in S.var.items():
        if d % K: continue
        pr = S.rad_primes(d)
        par = sum(xi for xi, p in zip(x, pr) if p in Kprimes) % 2
        if d not in sd: sd[d] = model.NewBoolVar(f"s{d}")
        e = model.NewBoolVar(f"e{vi}")  # deviation indicator
        if par == 0:
            model.Add(y[vi] == sd[d]).OnlyEnforceIf(e.Not())
        else:
            model.Add(y[vi] + sd[d] == 1).OnlyEnforceIf(e.Not())
        dev.append(e)
    model.Minimize(sum(dev))
    if hint:
        for i in range(n):
            key = f"{inv[i][0]}:{','.join(map(str, inv[i][1]))}"
            model.AddHint(y[i], 1 if hint[key] > 0 else 0)
    solver = cp_model.CpSolver(); solver.parameters.max_time_in_seconds = tl
    solver.parameters.num_workers = 2; solver.parameters.random_seed = seed
    st = solver.Solve(model)
    sol = None
    if st in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        sol = {f"{inv[i][0]}:{','.join(map(str, inv[i][1]))}": 2 * solver.Value(y[i]) - 1 for i in range(n)}
    return solver.StatusName(st), sol, m, solver.ObjectiveValue() if sol else None, solver.BestObjectiveBound()

if __name__ == "__main__":
    q = int(sys.argv[1]); Kp = [int(a) for a in sys.argv[2].split(",")]; tl = float(sys.argv[3])
    hint = json.load(open(sys.argv[4]))["fbar"] if len(sys.argv) > 4 else None
    st, sol, m, obj, bd = run(q, Kp, tl, hint=hint)
    print(q, Kp, st, "deviations", obj, "bound", bd, flush=True)
    if sol:
        json.dump({"q": q, "fbar": sol, "m": m}, open(f"sols/opt_{q}_{'_'.join(map(str,Kp))}.json", "w"))
