import sys, time
import sympy
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from shadow import shadow_test

lo, hi, step, off = (int(a) for a in sys.argv[1:5])
out = open(sys.argv[5], "a")
t0 = time.time()
for q in range(lo, hi + 1):
    if q % 2 == 0 or q < 3:
        continue
    if (q // 2) % step != off:
        continue
    F = sympy.factorint(q)
    if len(F) == 1 and list(F.values())[0] == 1:
        continue  # primes: trivially obstructed (BBW)
    ob, dim, n = shadow_test(q)
    out.write(f"{q} {q%4} {dict(F)} {'OB' if ob else 'NO'} {n}\n")
    out.flush()
    if not ob and len(F) > 1:
        print("NON-OBSTRUCTED non-prime-power:", q, F, flush=True)
out.write(f"# done {lo}-{hi} step {step} off {off} in {time.time()-t0:.0f}s\n")
out.close()
