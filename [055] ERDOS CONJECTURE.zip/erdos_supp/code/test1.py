"""Validate the layered criterion: rank = phi(q)+omega(q); kernel vectors have L(1,f)=0
numerically; generic vectors do not."""
import sys, random
from fractions import Fraction
import flint, sympy
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from core import system, L1_numeric, fac

random.seed(1)
qs = [int(a) for a in sys.argv[1:]] or [9, 15, 21, 25, 27, 35, 45, 63, 75, 105, 135, 165, 189, 225, 315]
for q in qs:
    rows, rb, rf, lab = system(q)
    n = q - 1
    M = flint.fmpz_mat(len(rows), n, [row.get(j + 1, 0) for row in rows for j in range(n)])
    r = M.rank()
    phi = int(sympy.totient(q)); om = len(fac(q))
    K, nul = M.nullspace()
    # pick random integer combination of kernel basis columns
    cols = [[K[i, j] for i in range(n)] for j in range(nul)]
    maxdev = 0
    for trial in range(3):
        coeffs = [random.randint(-5, 5) for _ in range(nul)]
        v = [sum(c * col[i] for c, col in zip(coeffs, cols)) for i in range(n)]
        fv = [0] + [int(x) for x in v]
        val = L1_numeric(q, fv, 50)
        scale = max(abs(x) for x in fv) or 1
        maxdev = max(maxdev, abs(val) / scale)
    # generic vector with sum 0
    g = [random.randint(-3, 3) for _ in range(n)]
    g[-1] -= sum(g)
    gen = abs(L1_numeric(q, [0] + g, 30))
    print(f"q={q} fac={fac(q)} rank={r} phi+omega={phi+om} nullity={nul} "
          f"max|L(1,kernel)|/scale={float(maxdev):.2e} generic|L|={float(gen):.3e}")
