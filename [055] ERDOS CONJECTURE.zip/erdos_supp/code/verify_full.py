"""Independent verification of a candidate Erdos function f mod q with L(1,f)=0.

(1) f(n) in {+1,-1} for n=1..q-1, f(0)=0, sum f = 0.
(2) Okada's criterion, implemented directly from its statement (independent of the
    layered/character code):  for every unit a,  sum_{m in M(q)} f(a m)/m = 0
    (M(q) = integers composed of primes dividing q; infinite sums summed exactly
    as geometric series), and for every prime p|q
    sum_{1<=r<=q, (r,q)>1} f(r) eps(r,p) = 0,  eps = v_p(r) if v_p(r)<v_p(q) else v_p(q)+1/(p-1).
(3) High-precision numerics: L(1,f) = -(1/q) sum_a f(a) psi(a/q).
Usage: python3 verify_full.py q f_values_file   (file: q-1 integers, f(1..q-1))"""
import sys
from math import gcd
from fractions import Fraction
from itertools import product
import sympy


def vp(n, p):
    k = 0
    while n % p == 0:
        n //= p
        k += 1
    return k


def okada_unit_sums(q, f, units_to_check):
    P = dict(sympy.factorint(q))
    primes = sorted(P)
    res = {}
    for a in units_to_check:
        total = Fraction(0)
        # m = prod p^{i_p}; pattern: i_p < e_p exact, or "saturated" (i_p >= e_p)
        for pattern in product(*[list(range(P[p])) + ["sat"] for p in primes]):
            g = 1
            sat = []
            for p, i in zip(primes, pattern):
                if i == "sat":
                    g *= p ** P[p]
                    sat.append(p)
                else:
                    g *= p ** i
            if g == q:
                continue  # a*m == 0 mod q, f = 0
            qq = q // g
            # u ranges over products of saturated primes' powers p^{j}, j>=0 (extra beyond e_p)
            if not sat:
                total += Fraction(f[(a * g) % q], g)
                continue
            periods = [int(sympy.n_order(p, qq)) if qq > 1 else 1 for p in sat]
            sub = Fraction(0)
            for js in product(*[range(T) for T in periods]):
                u = 1
                for p, j in zip(sat, js):
                    u *= p ** j
                val = f[(a * g * u) % q]
                if val:
                    sub += Fraction(val, u)
            fac = Fraction(1)
            for p, T in zip(sat, periods):
                fac *= Fraction(p ** T, p ** T - 1)
            total += sub * fac / g
        res[a] = total
    return res


def okada_prime_sums(q, f):
    P = dict(sympy.factorint(q))
    out = {}
    for p, e in P.items():
        s = Fraction(0)
        for r in range(1, q + 1):
            if gcd(r, q) == 1:
                continue
            v = vp(r, p)
            eps = Fraction(v) if v < e else Fraction(e) + Fraction(1, p - 1)
            s += f[r % q] * eps
        out[p] = s
    return out


if __name__ == "__main__":
    q = int(sys.argv[1])
    vals = [int(x) for x in open(sys.argv[2]).read().split()]
    assert len(vals) == q - 1
    f = [0] + vals
    assert all(v in (1, -1) for v in vals), "values not +-1"
    print("values +-1: OK; sum f =", sum(vals))
    reps = sys.argv[3] if len(sys.argv) > 3 else "all"
    units = [a for a in range(1, q) if gcd(a, q) == 1]
    if reps != "all":
        units = units[: int(reps)]
    U = okada_unit_sums(q, f, units)
    bad = [a for a, v in U.items() if v != 0]
    print(f"Okada unit equations checked: {len(U)}; nonzero: {len(bad)}", bad[:5], [U[a] for a in bad[:3]])
    Pp = okada_prime_sums(q, f)
    print("Okada prime equations:", {p: str(v) for p, v in Pp.items()})
    import mpmath
    mpmath.mp.dps = int(sys.argv[4]) if len(sys.argv) > 4 else 50
    L = mpmath.mpf(0)
    for a in range(1, q):
        L += f[a] * mpmath.digamma(mpmath.mpf(a) / q)
    L = -L / q
    print("numeric L(1,f) =", mpmath.nstr(L, 15), " (dps", mpmath.mp.dps, ")")
    # a control: flip one sign pair to see L becomes visibly nonzero
    g = list(f)
    g[1], g[2] = g[2], g[1]
    if g[1] != f[1]:
        Lg = mpmath.mpf(0)
        for a in range(1, q):
            Lg += g[a] * mpmath.digamma(mpmath.mpf(a) / q)
        print("control (swap f(1),f(2)) L =", mpmath.nstr(-Lg / q, 10))
