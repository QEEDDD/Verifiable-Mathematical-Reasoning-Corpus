"""Verify an Erdos function f mod q (values file) whose layer functions depend only on Legendre
symbols: (1) check that dependence; (2) exact real-character coefficients A_chi_m (m | rad q),
log coefficients and convergence, via the elementary decomposition (Prop. 2.1)."""
import sys
from math import gcd
from fractions import Fraction
from itertools import product
import sympy
q = int(sys.argv[1]); vals = [int(v) for v in open(sys.argv[2]).read().split()]
f = [0] + vals
P = dict(sympy.factorint(q)); primes = sorted(P)
leg = lambda x, p: int(sympy.legendre_symbol(x % p, p))
D = [int(d) for d in sympy.divisors(q) if d > 1]
coef = {}; ok = True
for d in D:
    g = q // d; pr = [p for p in primes if d % p == 0]
    table = {}
    for x in range(1, d):
        if gcd(x, d) != 1: continue
        key = tuple(leg(x, p) for p in pr)
        v = f[g * x]
        if key in table and table[key] != v: ok = False
        table[key] = v
    for e in product([0, 1], repeat=len(pr)):
        m = 1
        for p, ee in zip(pr, e):
            if ee: m *= p
        s = Fraction(0)
        for key, v in table.items():
            w = 1
            for p, ee, k in zip(pr, e, key):
                if ee: w *= k
            s += v * w
        coef[(d, m)] = s / 2 ** len(pr)
print("layer functions depend only on Legendre symbols:", ok)
def chi(m, a):
    r = 1
    for p in primes:
        if m % p == 0: r *= leg(a, p)
    return r
allzero = True
for e in product([0, 1], repeat=len(primes)):
    m = 1
    for p, ee in zip(primes, e):
        if ee: m *= p
    if m == 1: continue
    A = Fraction(0)
    for d in D:
        if d % m: continue
        w = Fraction(d)
        for p in primes:
            if d % p == 0 and m % p != 0: w *= (1 - Fraction(chi(m, p), p))
        A += w * coef[(d, m)]
    print(f"  m={m}: q*A_chi = {A}"); allzero &= (A == 0)
for p in primes:
    s = Fraction(0)
    for d in D:
        vd = sympy.multiplicity(p, d)
        eps = Fraction(P[p] - vd) - (Fraction(1, p - 1) if vd > 0 else 0)
        s += sympy.totient(d) * coef[(d, 1)] * eps
    print(f"  log {p}: {s}"); allzero &= (s == 0)
c = sum(sympy.totient(d) * coef[(d, 1)] for d in D); print("  convergence:", c); allzero &= (c == 0)
print("values +-1:", set(vals) <= {1, -1}, " ALL IDENTITIES HOLD:", allzero and ok)
