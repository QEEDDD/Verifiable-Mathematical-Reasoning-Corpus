\p 60
read("gp/f540225.gp");
q=540225;
if(#F!=q-1, error("len"));
if(vecsum(F)!=0, error("sum"));
L=-sum(a=1,q-1,F[a]*psi(a/q))/q;
print("L(1,f) at 60 digits = ", L);
\q
