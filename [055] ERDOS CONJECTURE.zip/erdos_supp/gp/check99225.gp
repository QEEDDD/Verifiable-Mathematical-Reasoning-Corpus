\p 120
read("gp/f99225.gp");
q=99225;
if(#F!=q-1, error("len"));
if(vecsum(F)!=0, error("sum"));
L=-sum(a=1,q-1,F[a]*psi(a/q))/q;
print("L(1,f) at 120 digits = ", L);
\\ independent check via partial sums with tail correction: S(N)=sum_{n<=N} f(n)/n for N = k*q
S=0.; for(n=1,2*q, r=n%q; if(r, S+=F[r]/n)); print("partial sum to 5q: ", S);
\q
