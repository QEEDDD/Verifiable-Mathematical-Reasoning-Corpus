#!/bin/sh
# Create PARI/GP data files gp/f*.gp from the plain value lists in data/ (run from the supplement root).
for pair in "f_11025_legendre f11025L" "f_27225 f27225" "f_99225 f99225" "f_245025 f245025" "f_540225 f540225"; do
  set -- $pair
  python3 -c "import sys; v=open('data/$1.txt').read().split(); open('gp/$2.gp','w').write('F=['+','.join(v)+'];\n')"
done
echo "gp data files written"
