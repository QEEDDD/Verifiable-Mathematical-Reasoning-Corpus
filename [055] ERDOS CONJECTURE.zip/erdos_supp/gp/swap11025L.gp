\p 60
read("gp/f11025L.gp");
q=11025; G=F; t=G[1]; G[1]=G[2]; G[2]=t;
print("f(1),f(2) = ", F[1], " ", F[2]);
print("swapped L = ", -sum(a=1,q-1,G[a]*psi(a/q))/q);
\q
