default(realprecision, 120);
read("/tmp/claude-0/-home-claude/5ad56b25-3dae-5235-9aee-21861d660576/scratchpad/indep_check/f_27225.gp");
q = 27225;
if (#f != q-1 || vecsum(f) != 0, error("bad f"));
L = -sum(a=1, q-1, f[a]*psi(a/q))/q;
printf("q=%d  PARI psi (realprecision 120):  L(1,f)  = %.10e\n", q, L);
Lp = -sum(a=1, q-1, fp[a]*psi(a/q))/q;
printf("q=%d  PARI psi (realprecision 120):  L(1,f') = %.45e  (perturbed control)\n", q, Lp);
\q
