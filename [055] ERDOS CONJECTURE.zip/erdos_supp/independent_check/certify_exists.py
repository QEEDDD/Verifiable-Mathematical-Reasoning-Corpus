"""For each q in the EXISTS list, build an explicit INTEGER vector x with every
coordinate odd and A x = 0 exactly (A = Okada rows (1),(2) + sum row), from the
exact 2-saturated kernel basis.  Also report L(1,x) at 60 digits.
usage: python3 certify_exists.py out.json q1 q2 ...
"""
import sys, json
import flint, mpmath
sys.path.insert(0, '/tmp/claude-0/-home-claude/5ad56b25-3dae-5235-9aee-21861d660576/scratchpad/indep_check')
from system2 import build_system

mpmath.mp.dps = 60


def v2(x):
    return (x & -x).bit_length() - 1


def prim2(col):
    s = min(v2(x) for x in col if x)
    return [x >> s for x in col] if s else col


def reduce(basis, v, combo):
    while v:
        t = v.bit_length() - 1
        if t in basis:
            bv, bc = basis[t]
            v ^= bv
            combo ^= bc
        else:
            return v, combo, t
    return 0, combo, None


def saturate(cols):
    cols = [prim2(c) for c in cols]
    while True:
        basis, dep = {}, None
        for k, c in enumerate(cols):
            v = sum(1 << i for i, x in enumerate(c) if x & 1)
            r, combo, t = reduce(basis, v, 1 << k)
            if r == 0:
                dep = combo
                break
            basis[t] = (r, combo)
        if dep is None:
            return cols, basis
        idx = [k for k in range(len(cols)) if (dep >> k) & 1]
        new = [sum(cols[k][i] for k in idx) // 2 for i in range(len(cols[0]))]
        cols[idx[0]] = prim2(new)


outfile = sys.argv[1]
res = {}
for q in map(int, sys.argv[2:]):
    rows, kinds, N, D = build_system(q)
    n = q - 1
    A = flint.fmpz_mat(rows)
    X, d = A.nullspace()
    cols = [[int(X[i, j]) for i in range(n)] for j in range(d)]
    sat, basis = saturate(cols)
    r, combo, _ = reduce(basis, (1 << n) - 1, 0)
    assert r == 0, f"q={q}: ones not in L mod 2"
    idx = [k for k in range(d) if (combo >> k) & 1]
    x = [sum(sat[k][i] for k in idx) for i in range(n)]
    Ax = A * flint.fmpz_mat([[v] for v in x])
    exact_zero = all(Ax[i, 0] == 0 for i in range(Ax.nrows()))
    all_odd = all(v % 2 == 1 for v in x)
    terms = [x[a - 1] * mpmath.digamma(mpmath.mpf(a) / q) for a in range(1, q)]
    L = -mpmath.fsum(terms) / q
    scale = mpmath.fsum(abs(t) for t in terms) / q
    res[q] = dict(x=x, exact_Ax_zero=exact_zero, all_odd=all_odd, sum=sum(x),
                  max_abs=max(abs(v) for v in x), L1=mpmath.nstr(L, 5), L1_rel=mpmath.nstr(abs(L) / scale, 3))
    print(f"q={q:4d}: explicit integer x, all odd={all_odd}, A x = 0 exactly={exact_zero}, sum={sum(x)}, "
          f"max|x_i|={max(abs(v) for v in x)} (bits {max(abs(v) for v in x).bit_length()}), "
          f"L(1,x)={mpmath.nstr(L, 5)} (rel {mpmath.nstr(abs(L)/scale, 3)})", flush=True)
json.dump(res, open(outfile, 'w'))
