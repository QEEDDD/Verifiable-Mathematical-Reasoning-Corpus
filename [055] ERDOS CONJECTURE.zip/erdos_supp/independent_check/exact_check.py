"""Independent exact cross-check for small q:
  * exact rank over Q and an exact integer kernel basis (flint fmpz_mat.nullspace),
  * explicit 2-saturation of that (non-saturated) integer basis,
  * test whether the all-ones vector lies in (saturated lattice) mod 2,
  * high-precision L(1,x) for random integer kernel vectors (should vanish),
    and for random non-kernel x with sum 0 (control, should not vanish).
usage: python3 exact_check.py qmin qmax outfile.jsonl
"""
import sys, time, json, random
from math import gcd
import flint, sympy, mpmath
sys.path.insert(0, '/tmp/claude-0/-home-claude/5ad56b25-3dae-5235-9aee-21861d660576/scratchpad/indep_check')
from okada_lib import factor, phi
from system2 import build_system

qmin, qmax, outfile = int(sys.argv[1]), int(sys.argv[2]), sys.argv[3]
mpmath.mp.dps = 60
out = open(outfile, 'a')


def v2(x):
    return (x & -x).bit_length() - 1


def prim2(col):
    """divide an integer vector by the largest power of 2 dividing all entries"""
    nzv = [v2(x) for x in col if x]
    s = min(nzv)
    return [x >> s for x in col] if s else col


def gf2_basis_reduce(basis, v, combo):
    while v:
        top = v.bit_length() - 1
        if top in basis:
            bv, bc = basis[top]
            v ^= bv
            combo ^= bc
        else:
            return v, combo, top
    return 0, combo, None


def saturate_at_2(cols):
    """cols: list of d integer vectors spanning K over Q (all in K).  Returns a
    Z_(2)-basis of K cap Z_(2)^n (2-saturated), and the number of steps."""
    cols = [prim2(c) for c in cols]
    steps = 0
    while True:
        basis = {}
        dep = None
        for k, c in enumerate(cols):
            v = 0
            for i, x in enumerate(c):
                if x & 1:
                    v |= 1 << i
            r, combo, top = gf2_basis_reduce(basis, v, 1 << k)
            if r == 0:
                dep = combo
                break
            basis[top] = (r, combo)
        if dep is None:
            return cols, basis, steps
        idx = [k for k in range(len(cols)) if (dep >> k) & 1]
        new = [sum(cols[k][i] for k in idx) for i in range(len(cols[0]))]
        assert all(x % 2 == 0 for x in new)
        new = prim2([x // 2 for x in new])
        cols[idx[0]] = new
        steps += 1


psi_cache = {}


def L1(x, q):
    if q not in psi_cache:
        psi_cache[q] = [mpmath.digamma(mpmath.mpf(a) / q) for a in range(1, q)]
    ps = psi_cache[q]
    terms = [x[a - 1] * ps[a - 1] for a in range(1, q) if x[a - 1]]
    val = -mpmath.fsum(terms) / q
    scale = mpmath.fsum(abs(t) for t in terms) / q
    return val, scale


for q in range(qmin, qmax + 1):
    if q % 2 == 0 or q < 9 or sympy.isprime(q):
        continue
    t0 = time.time()
    rows, kinds, N, D = build_system(q)
    m, n = len(rows), q - 1
    A = flint.fmpz_mat(rows)
    rank = A.rank()
    X, nullity = A.nullspace()
    cols = [[int(X[i, j]) for i in range(n)] for j in range(nullity)]
    # verify A * kernel = 0 exactly
    K = flint.fmpz_mat([[cols[j][i] for j in range(nullity)] for i in range(n)])
    AK = A * K
    zero_ok = all(AK[i, j] == 0 for i in range(m) for j in range(nullity))
    maxbits = max(abs(x).bit_length() for c in cols for x in c)
    sat, basis, steps = saturate_at_2(cols)
    # all sat columns still in the kernel?
    Ks = flint.fmpz_mat([[sat[j][i] for j in range(nullity)] for i in range(n)])
    AKs = A * Ks
    sat_ok = all(AKs[i, j] == 0 for i in range(m) for j in range(nullity))
    ones = (1 << n) - 1
    r, _, _ = gf2_basis_reduce(basis, ones, 0)
    exists = (r == 0)
    # numeric checks of L(1,x)
    rnd = random.Random(q)
    worst_rel = 0
    for _ in range(3):
        c = [rnd.randint(-5, 5) for _ in range(nullity)]
        x = [sum(c[j] * sat[j][i] for j in range(nullity)) for i in range(n)]
        if not any(x):
            continue
        assert sum(x) == 0
        val, sc = L1(x, q)
        worst_rel = max(worst_rel, float(abs(val) / sc))
    # control: random +-1 vector with sum 0 (q-1 even)
    y = [1] * (n // 2) + [-1] * (n // 2)
    rnd.shuffle(y)
    cval, csc = L1(y, q)
    rec = dict(q=q, phi=phi(q), omega=len(factor(q)), rank_Q=rank,
               expected=phi(q) + len(factor(q)), nullity=nullity, kernel_exact_ok=zero_ok,
               kernel_maxbits=maxbits, saturation_steps=steps, saturated_in_kernel=sat_ok,
               exists=exists, L1_kernel_worst_rel=worst_rel,
               L1_control_rel=float(abs(cval) / csc), time=round(time.time() - t0, 2))
    out.write(json.dumps(rec) + '\n')
    out.flush()
    print(f"q={q:4d} rankQ={rank:4d} (phi+w={rec['expected']:4d}) nullity={nullity:4d} "
          f"kernel ok={zero_ok} bits={maxbits:6d} sat_steps={steps:4d} sat ok={sat_ok} "
          f"EXISTS={exists} |L1(ker)|/scale={worst_rel:.1e} |L1(ctrl)|/scale={rec['L1_control_rel']:.1e} "
          f"t={rec['time']}s", flush=True)
