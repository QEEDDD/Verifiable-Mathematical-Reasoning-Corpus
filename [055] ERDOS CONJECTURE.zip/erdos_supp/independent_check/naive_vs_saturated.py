"""Show that 2-saturation matters: test 1 in (kernel basis mod 2) using the raw
integer nullspace basis from flint (each column only made 2-primitive), versus
the 2-saturated lattice (results of exact_check / task2)."""
import sys, json
import flint, sympy
sys.path.insert(0, '/tmp/claude-0/-home-claude/5ad56b25-3dae-5235-9aee-21861d660576/scratchpad/indep_check')
from system2 import build_system
D = '/tmp/claude-0/-home-claude/5ad56b25-3dae-5235-9aee-21861d660576/scratchpad/indep_check'
sat = {r['q']: r['exists'] for r in map(json.loads, open(D + '/exact_results.jsonl'))}
qmax = int(sys.argv[1])
def v2(x): return (x & -x).bit_length() - 1
diff = []
for q in sorted(sat):
    if q > qmax: break
    rows, kinds, N, Dd = build_system(q)
    n = q - 1
    X, d = flint.fmpz_mat(rows).nullspace()
    basis = {}
    for j in range(d):
        col = [int(X[i, j]) for i in range(n)]
        s = min(v2(x) for x in col if x)
        v = 0
        for i, x in enumerate(col):
            if (x >> s) & 1: v |= 1 << i
        while v:
            t = v.bit_length() - 1
            if t in basis: v ^= basis[t]
            else: basis[t] = v; break
    rank2 = len(basis)
    v = (1 << n) - 1
    while v:
        t = v.bit_length() - 1
        if t in basis: v ^= basis[t]
        else: break
    naive = (v == 0)
    if naive != sat[q] or rank2 < d:
        diff.append((q, d, rank2, naive, sat[q]))
print("q, nullity, rank of raw basis mod 2, naive answer, saturated answer (only q where they differ or raw basis degenerates mod 2):")
for t in diff: print(t)
print("q with different final answer:", [t[0] for t in diff if t[3] != t[4]])
