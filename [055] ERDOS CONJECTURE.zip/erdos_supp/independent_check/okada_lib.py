"""
Independent implementation of Okada's criterion pieces, written from the
mathematical statement only.

Setting: q odd (or any q>2), f q-periodic rational, f(q)=0, sum_{n=1}^{q} f(n)=0.
 (1) for every unit a mod q:  sum_{m in M(q)} f(a m)/m = 0,
     M(q) = positive integers whose prime factors all divide q (incl. m=1).
 (2) for every prime p|q:  sum_{r=1, gcd(r,q)>1}^{q} f(r) eps(r,p) = 0,
     eps(r,p) = v_p(r) if v_p(r) < v_p(q), else v_p(q) + 1/(p-1).

Exact evaluation of (1): for p^e || q put Q = q/p^e and T = ord_Q(p)
(T = 1 if Q = 1).  For i >= e, p^i mod q is periodic in i with period T
(p^i = 0 mod p^e and p^i mod Q is purely periodic).  Hence
   sum_{i>=0} c(p^i mod q) p^{-i}
     = sum_{i<e} c(p^i) p^{-i} + sum_{i=e}^{e+T-1} c(p^i) p^{-i} * p^T/(p^T-1).
For several primes the residue of m = prod p^{i_p} mod q depends only on the
reduced exponents, so the (absolutely convergent) series over M(q) equals a
finite weighted sum over exponent vectors with i_p in E_p = {0..e+T-1}.
All weights are scaled by D_p = p^{e+T-1} (p^T-1) to become integers.
"""
from fractions import Fraction
from math import gcd


def factor(n):
    fs = []
    d = 2
    while d * d <= n:
        if n % d == 0:
            e = 0
            while n % d == 0:
                n //= d
                e += 1
            fs.append((d, e))
        d += 1
    if n > 1:
        fs.append((n, 1))
    return fs


def mult_order(a, m):
    if m == 1:
        return 1
    assert gcd(a, m) == 1
    x, k = a % m, 1
    while x != 1:
        x = (x * a) % m
        k += 1
    return k


def phi(n):
    r = n
    for p, _ in factor(n):
        r = r // p * (p - 1)
    return r


def vp(n, p):
    k = 0
    while n % p == 0:
        n //= p
        k += 1
    return k


def prime_data(q):
    """For each p^e||q: dict with p,e,T, list of residues p^i mod q (i in E_p),
    integer weights wt[i] = D_p * w_p(i), and D_p."""
    out = []
    for p, e in factor(q):
        Q = q // p**e
        T = mult_order(p, Q)
        Dp = p**(e + T - 1) * (p**T - 1)
        res, wt = [], []
        for i in range(e + T):
            res.append(pow(p, i, q))
            if i < e:
                wt.append(p**(e + T - 1 - i) * (p**T - 1))
            else:
                wt.append(p**(e + 2 * T - 1 - i))
        # sanity: sum of weights equals sum_{i>=0} p^{-i} = p/(p-1)
        assert Fraction(sum(wt), Dp) == Fraction(p, p - 1)
        # sanity: periodicity claim p^{e+T} = p^e mod q
        assert pow(p, e + T, q) == pow(p, e, q)
        out.append(dict(p=p, e=e, T=T, res=res, wt=wt, Dp=Dp))
    return out


def W_weights(q):
    """Return (N, D): dict r -> integer N(r) with W(r) = N(r)/D, where
    W(r) = sum_{m in M(q), m = r mod q} 1/m."""
    pd = prime_data(q)
    cur = {1 % q: 1}
    D = 1
    for d in pd:
        new = {}
        for r, val in cur.items():
            for res, w in zip(d['res'], d['wt']):
                s = (r * res) % q
                new[s] = new.get(s, 0) + val * w
        cur = new
        D *= d['Dp']
    # sanity: total mass = prod p/(p-1)
    tot = Fraction(1)
    for p, _ in factor(q):
        tot *= Fraction(p, p - 1)
    assert Fraction(sum(cur.values()), D) == tot
    return cur, D


def eps(r, p, e):
    """Okada's epsilon as a Fraction; e = v_p(q)."""
    v = vp(r, p)
    if v < e:
        return Fraction(v)
    return Fraction(e) + Fraction(1, p - 1)


def okada2_values(f, q):
    """f: list of length q, f[n] = f(n) for 1<=n<=q-1, f[0] = f(q) = 0.
    Returns list of (p, exact Fraction value of the sum in (2))."""
    out = []
    for p, e in factor(q):
        s = Fraction(0)
        for r in range(1, q + 1):
            if gcd(r, q) > 1:
                s += f[r % q] * eps(r, p, e)
        out.append((p, s))
    return out


def okada1_sequential(f, q):
    """Exact values of (1) for all units a, via successive per-prime
    geometric-series stages.  Returns (dict a -> integer G(a), D) with the
    sum in (1) equal to G(a)/D."""
    pd = sorted(prime_data(q), key=lambda d: len(d['res']))
    units = [a for a in range(1, q) if gcd(a, q) == 1]
    g = [int(v) for v in f]          # g[x], x in Z/q, g[0] = f(q) = 0
    D = 1
    for idx, d in enumerate(pd):
        last = idx == len(pd) - 1
        xs = units if last else range(q)
        pairs = list(zip(d['res'], d['wt']))
        newg = [0] * q
        for x in xs:
            s = 0
            for res, w in pairs:
                v = g[(x * res) % q]
                if v:
                    s += w * v
            newg[x] = s
        g = newg
        D *= d['Dp']
    return {a: g[a] for a in units}, D
