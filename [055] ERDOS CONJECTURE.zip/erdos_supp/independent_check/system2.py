"""Build Okada's linear system for x = (x_1..x_{q-1}) (x_q = f(q) = 0) and
solve the 2-adic question.

Rows:
  (1) for each unit a mod q:  sum_{s=1}^{q-1} W(a^{-1} s) x_s = 0,
      W(r) = sum_{m in M(q), m = r mod q} 1/m   (stored as integers N(r) = D W(r))
      [coefficient of x_s in sum_m x(am)/m is the total weight of m with a m = s]
  (2) for each prime p|q:  sum_{1<=r<=q-1, gcd(r,q)>1} (p-1) eps(r,p) x_r = 0
  (3) sum_{s=1}^{q-1} x_s = 0
"""
import sys
from math import gcd
import numpy as np
sys.path.insert(0, '/tmp/claude-0/-home-claude/5ad56b25-3dae-5235-9aee-21861d660576/scratchpad/indep_check')
from okada_lib import factor, phi, vp, W_weights

M64 = (1 << 64) - 1


def build_system(q):
    fs = factor(q)
    units = [a for a in range(1, q) if gcd(a, q) == 1]
    N, D = W_weights(q)
    rows = []
    kinds = []
    for a in units:
        ainv = pow(a, -1, q)
        rows.append([N.get((ainv * s) % q, 0) for s in range(1, q)])
        kinds.append(('1', a))
    for p, e in fs:
        row = []
        for r in range(1, q):
            if gcd(r, q) > 1:
                v = vp(r, p)
                row.append((p - 1) * v if v < e else (p - 1) * e + 1)
            else:
                row.append(0)
        rows.append(row)
        kinds.append(('2', p))
    rows.append([1] * (q - 1))
    kinds.append(('S', 0))
    return rows, kinds, N, D


def v2(x):
    return (x & -x).bit_length() - 1


def two_adic_normalize_rows(rows):
    """Divide every integer row by the largest power of 2 dividing all its
    entries (rescaling a row by a nonzero rational does not change the
    system), then reduce mod 2^64.  Returns uint64 matrix and precision vector."""
    m, n = len(rows), len(rows[0])
    M = np.zeros((m, n), dtype=np.uint64)
    shifts = []
    for i, row in enumerate(rows):
        vmin = min(v2(x) for x in row if x != 0)
        shifts.append(vmin)
        M[i] = np.array([((x >> vmin) & M64) if x >= 0 else ((x >> vmin) % (1 << 64)) for x in row], dtype=np.uint64)
    prec = np.full(m, 64, dtype=np.int64)
    return M, prec, shifts


def masks(prec):
    return np.array([M64 if p >= 64 else (1 << int(p)) - 1 for p in prec], dtype=np.uint64)


def two_adic_rref(M, prec, rng=None):
    """Gaussian elimination over Z_(2), entries stored mod 2^prec[i] in uint64.
    Rows are kept 2-primitive (divided by 2^v when all entries become even),
    pivots are 2-adic units, and the pivot column is cleared in ALL other rows
    (reduced row echelon form).  Returns status (1 = pivot row, 2 = row zero
    to its precision), pivot column of each pivot row, precision vector."""
    M = M.copy()
    prec = prec.copy()
    m, n = M.shape
    one = np.uint64(1)
    status = np.zeros(m, dtype=np.int8)
    pivcol = -np.ones(m, dtype=np.int64)
    ors = np.bitwise_or.reduce(M, axis=1)
    status[ors == 0] = 2
    while True:
        act = np.flatnonzero(status == 0)
        if act.size == 0:
            break
        pm = prec[act].max()
        cands = act[prec[act] == pm]
        i = cands[0] if rng is None else cands[rng.integers(cands.size)]
        row = M[i].copy()
        odd = np.flatnonzero(row & one)
        assert odd.size > 0, "active row not normalized"
        j = odd[0] if rng is None else odd[rng.integers(odd.size)]
        inv = pow(int(row[j]), -1, 1 << 64)
        with np.errstate(over='ignore'):
            row = row * np.uint64(inv)
        row &= masks([prec[i]])[0]
        M[i] = row
        status[i] = 1
        pivcol[i] = j
        col = M[:, j].copy()
        col[i] = 0
        nz = np.flatnonzero(col)
        if nz.size:
            assert np.all(status[nz] != 2)
            with np.errstate(over='ignore'):
                M[nz] -= col[nz, None] * row[None, :]
            prec[nz] = np.minimum(prec[nz], prec[i])
            M[nz] &= masks(prec[nz])[:, None]
            a = nz[status[nz] == 0]
            if a.size:
                o = np.bitwise_or.reduce(M[a], axis=1)
                z = o == 0
                status[a[z]] = 2
                a2, o2 = a[~z], o[~z]
                low = o2 & ((~o2) + one)
                v = np.rint(np.log2(low.astype(np.float64))).astype(np.int64)
                sh = v > 0
                if np.any(sh):
                    rows_sh = a2[sh]
                    M[rows_sh] >>= v[sh].astype(np.uint64)[:, None]
                    prec[rows_sh] -= v[sh]
    return M, status, pivcol, prec


def odd_solution_test(M, status, pivcol, prec):
    """Given the 2-adic RREF, decide whether the all-ones vector lies in
    (kernel lattice) mod 2, i.e. whether every pivot row has even weight mod 2."""
    piv = np.flatnonzero(status == 1)
    P = pivcol[piv]
    assert np.all(prec[piv] >= 1)
    sub = (M[np.ix_(piv, P)] & np.uint64(1)).astype(np.int64)
    assert np.array_equal(sub, np.eye(len(piv), dtype=np.int64)), "not an RREF mod 2"
    parities = (np.count_nonzero(M[piv] & np.uint64(1), axis=1) % 2)
    exists = bool(np.all(parities == 0))
    return exists, piv, P, parities


def build_odd_solution(M, piv, P, prec, n):
    """x_J = 1 on non-pivot columns, x_P = -B 1 (mod 2^k), k = min precision."""
    k = int(prec[piv].min())
    mod = 1 << k
    J = np.setdiff1d(np.arange(n), P)
    x = [0] * n
    for j in J:
        x[j] = 1
    for i, c in zip(piv, P):
        s = 0
        rowi = M[i]
        for j in J:
            s += int(rowi[j])
        x[c] = (-s) % mod
    return x, k
