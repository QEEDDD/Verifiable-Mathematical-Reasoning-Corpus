"""Task 1: independent check of the two data files.

usage: python3 task1.py q path
"""
import sys, time, random
from math import gcd
from fractions import Fraction
sys.path.insert(0, '/tmp/claude-0/-home-claude/5ad56b25-3dae-5235-9aee-21861d660576/scratchpad/indep_check')
from okada_lib import *
import mpmath

OUTDIR = '/tmp/claude-0/-home-claude/5ad56b25-3dae-5235-9aee-21861d660576/scratchpad/indep_check'

q = int(sys.argv[1])
path = sys.argv[2]
toks = open(path).read().split()
vals = [int(t) for t in toks]
print(f"=== q = {q}, file {path}")
print("factorization:", factor(q), " phi(q) =", phi(q))
print("number of values:", len(vals), " (q-1 =", q - 1, ")  OK" if len(vals) == q - 1 else "  MISMATCH")
print("all values in {-1,+1}:", all(v in (-1, 1) for v in vals))
print("sum f(1..q-1) =", sum(vals), " #(+1) =", vals.count(1), " #(-1) =", vals.count(-1))
f = [0] + vals          # f[n] for n in 0..q-1, f[0] = f(q) = 0
assert len(f) == q

units = [a for a in range(1, q) if gcd(a, q) == 1]


def okada_report(f, label):
    t0 = time.time()
    G, D1 = okada1_sequential(f, q)
    t1 = time.time()
    nz1 = [a for a in units if G[a] != 0]
    print(f"[{label}] Okada (1), method A (per-prime staged sums, exact ints): "
          f"{len(nz1)} of {len(units)} unit equations nonzero  ({t1-t0:.1f}s)")
    # method B: residue weights W(r) = sum_{m in M(q), m=r} 1/m, then sum_r f(ar) W(r)
    N, D2 = W_weights(q)
    items = list(N.items())
    nz2 = []
    agree = True
    for a in units:
        s = 0
        for r, v in items:
            x = f[(a * r) % q]
            if x:
                s += x * v
        if s != 0:
            nz2.append(a)
        # exact agreement of the two rationals G/D1 and s/D2
        if G[a] * D2 != s * D1:
            agree = False
    t2 = time.time()
    print(f"[{label}] Okada (1), method B (residue weights, |S|={len(N)}, exact ints): "
          f"{len(nz2)} of {len(units)} nonzero; methods A and B agree exactly on every a: {agree}  ({t2-t1:.1f}s)")
    o2 = okada2_values(f, q)
    nz3 = [(p, v) for p, v in o2 if v != 0]
    print(f"[{label}] Okada (2): " + ", ".join(f"p={p}: {v}" for p, v in o2)
          + f"  -> {len(nz3)} of {len(o2)} nonzero")
    return G, D1, nz1, o2


G, D1, nz1, o2 = okada_report(f, "data f")

# ---------------- L(1,f) numerically ----------------
DPS = 110
mpmath.mp.dps = DPS


def L_digamma(f):
    s = mpmath.mpf(0)
    terms = []
    for a in range(1, q):
        if f[a]:
            terms.append(f[a] * mpmath.digamma(mpmath.mpf(a) / q))
    return -mpmath.fsum(terms) / q


def L_moment(f, K=40):
    """sum_{n<=Kq} f(n)/n in exact fixed point + tail via power moments:
    tail = sum_{j>=1} (-1)^j mu_j q^{-j-1} zeta(j+1, K), mu_j = sum_a f(a) a^j."""
    assert sum(f) == 0
    SCALE_BITS = 460
    SC = 1 << SCALE_BITS
    S = 0
    for k in range(K):
        base = k * q
        for a in range(1, q):
            x = f[a]
            if x == 1:
                S += SC // (base + a)
            elif x == -1:
                S -= SC // (base + a)
    partial = mpmath.mpf(S) / mpmath.mpf(SC)
    part_err = mpmath.mpf(K * q) / mpmath.mpf(SC)
    # number of tail terms: 2 K^{-J}/(1-1/K) < 10^{-(DPS+5)}
    J = 1
    while mpmath.mpf(2) * mpmath.mpf(K) ** (-J) / (1 - mpmath.mpf(1) / K) > mpmath.mpf(10) ** (-(DPS + 5)):
        J += 1
    tail = mpmath.mpf(0)
    pw = [f[a] for a in range(q)]          # pw[a] = f(a) a^j, updated incrementally (exact ints)
    for j in range(1, J + 1):
        for a in range(1, q):
            if pw[a]:
                pw[a] *= a
        mu = sum(pw)
        tail += (-1) ** j * mpmath.mpf(mu) / mpmath.mpf(q) ** (j + 1) * mpmath.zeta(j + 1, K)
    return partial + tail, part_err, J


t0 = time.time()
L1 = L_digamma(f)
t1 = time.time()
L2, perr, J = L_moment(f)
t2 = time.time()
print(f"[data f] L(1,f) via mpmath digamma (dps={DPS}):  {mpmath.nstr(L1, 15)}   ({t1-t0:.1f}s)")
print(f"[data f] L(1,f) via partial sums n<=40q (fixed point, err<{mpmath.nstr(perr,3)}) + moment tail ({J} terms): "
      f"{mpmath.nstr(L2, 15)}   ({t2-t1:.1f}s)")
print(f"[data f] |difference of the two methods| = {mpmath.nstr(abs(L1-L2), 5)}")

# ---------------- perturbation control ----------------
rng = random.Random(12345)
while True:
    i, j = rng.randrange(1, q), rng.randrange(1, q)
    if f[i] != f[j]:
        break
fp = list(f)
fp[i], fp[j] = fp[j], fp[i]
print(f"--- control: swap f({i})={f[i]} and f({j})={f[j]}; sum still {sum(fp)}")
Gp, D1p, nz1p, o2p = okada_report(fp, "perturbed")
L1p = L_digamma(fp)
L2p, perrp, Jp = L_moment(fp)
print(f"[perturbed] L(1,f') via digamma: {mpmath.nstr(L1p, 40)}")
print(f"[perturbed] L(1,f') via partial sums + moments: {mpmath.nstr(L2p, 40)}")
print(f"[perturbed] |difference| = {mpmath.nstr(abs(L1p-L2p), 5)}")
# Expected change: L(1,f')-L(1,f) = -(1/q) sum (f'-f)(a) psi(a/q)
d_expected = -(mpmath.mpf(fp[i]-f[i]) * mpmath.digamma(mpmath.mpf(i)/q) + mpmath.mpf(fp[j]-f[j]) * mpmath.digamma(mpmath.mpf(j)/q)) / q
print(f"[perturbed] predicted change -(1/q)[2 f(j)psi(i/q)+2 f(i)psi(j/q)] = {mpmath.nstr(d_expected, 40)}")
# numerical cross-check of one nonzero exact Okada (1) value by brute-force truncated summation
if nz1p:
    # pick the unit a with the largest |exact value| so truncation error is negligible
    a = max(nz1p, key=lambda b: abs(Gp[b]))
    exact = Fraction(Gp[a], D1p)
    ps = [p for p, _ in factor(q)]
    ms = [1]
    X = 10**30
    for p in ps:
        new = []
        for m in ms:
            t = m
            while t <= X:
                new.append(t)
                t *= p
        ms = new
    br = mpmath.fsum(mpmath.mpf(fp[(a * m) % q]) / m for m in ms)
    print(f"[perturbed] Okada(1) at a={a}: exact = {mpmath.nstr(mpmath.mpf(exact.numerator)/exact.denominator, 20)}, "
          f"brute-force sum over {len(ms)} m<=1e30: {mpmath.nstr(br, 20)}")

# write a gp-readable copy of f for the PARI check (named after the data file)
import os
tag = os.path.basename(path).rsplit('.', 1)[0]
with open(f"{OUTDIR}/{tag}.gp", "w") as fh:
    fh.write("f = [" + ",".join(str(v) for v in vals) + "];\n")
    fh.write(f"fp = [" + ",".join(str(fp[n]) for n in range(1, q)) + "];\n")
print("wrote", f"{OUTDIR}/{tag}.gp")
