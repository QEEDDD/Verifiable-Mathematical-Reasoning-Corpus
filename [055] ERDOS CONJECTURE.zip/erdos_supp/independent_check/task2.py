"""Task 2 driver: for each odd composite q in [qmin, qmax], decide whether
Okada's system (1),(2) + sum x = 0 has a 2-adic solution with all x_n odd.

usage: python3 task2.py qmin qmax outfile.jsonl
"""
import sys, time, json
import numpy as np
from math import gcd
import flint
import sympy
sys.path.insert(0, '/tmp/claude-0/-home-claude/5ad56b25-3dae-5235-9aee-21861d660576/scratchpad/indep_check')
from okada_lib import factor, phi
from system2 import (build_system, two_adic_normalize_rows, two_adic_rref,
                     odd_solution_test, build_odd_solution)

qmin, qmax, outfile = int(sys.argv[1]), int(sys.argv[2]), sys.argv[3]
PRIMES = [sympy.prevprime(2**62), sympy.prevprime(2**61 - 12345)]

out = open(outfile, 'a')
for q in range(qmin, qmax + 1):
    if q % 2 == 0 or q < 9 or sympy.isprime(q):
        continue
    t0 = time.time()
    fs = factor(q)
    omega = len(fs)
    r_exp = phi(q) + omega
    rows, kinds, N, D = build_system(q)
    m, n = len(rows), q - 1
    t1 = time.time()
    flat = [x for row in rows for x in row]
    rks = []
    for P in PRIMES:
        A = flint.nmod_mat(m, n, [x % P for x in flat], P)
        rks.append(A.rank())
    del flat
    t2 = time.time()
    M0, prec0, shifts = two_adic_normalize_rows(rows)
    M, status, pivcol, prec = two_adic_rref(M0, prec0)
    npiv = int(np.count_nonzero(status == 1))
    exists, piv, P, par = odd_solution_test(M, status, pivcol, prec)
    minprec = int(prec[piv].min())
    # second elimination with random pivot choices: must give the same answer
    rng = np.random.default_rng(q)
    Mb, sb, pcb, precb = two_adic_rref(M0, prec0, rng=rng)
    existsb, pivb, Pb, parb = odd_solution_test(Mb, sb, pcb, precb)
    npivb = int(np.count_nonzero(sb == 1))
    t3 = time.time()
    rec = dict(q=q, fac=fs, phi=phi(q), omega=omega, expected_rank=r_exp,
               nrows=m, ncols=n, S=len(N), Dbits=D.bit_length(),
               rank_modp=rks, pivots_2adic=npiv, pivots_2adic_rand=npivb,
               min_prec=minprec, min_prec_rand=int(precb[pivb].min()),
               odd_rows=int(np.count_nonzero(par)), exists=exists, exists_rand=existsb,
               row_shifts_2=sorted(set(shifts)))
    if exists:
        x, k = build_odd_solution(M, piv, P, prec, n)
        xa = np.array([v & ((1 << 64) - 1) for v in x], dtype=np.uint64)
        with np.errstate(over='ignore'):
            res = M0 @ xa
        mk = np.uint64((1 << k) - 1) if k < 64 else np.uint64((1 << 64) - 1)
        rec['odd_sol_check'] = dict(k=k, all_odd=all(v % 2 == 1 for v in x),
                                    residual_zero_mod_2k=bool(np.all((res & mk) == 0)))
    else:
        # trivial-level info: does the all-ones vector already fail mod 2 on an original row?
        with np.errstate(over='ignore'):
            res1 = M0 @ np.ones(n, dtype=np.uint64)
        rec['orig_rows_odd_on_ones'] = int(np.count_nonzero(res1 & np.uint64(1)))
    rec['ok'] = (rks[0] == r_exp and rks[1] == r_exp and npiv == r_exp and npivb == r_exp
                 and exists == existsb)
    rec['time'] = round(time.time() - t0, 2)
    out.write(json.dumps(rec) + '\n')
    out.flush()
    print(f"q={q:4d} {str(fs):28s} phi+w={r_exp:4d} rank_p={rks} piv={npiv}/{npivb} "
          f"minprec={minprec:2d} oddrows={rec['odd_rows']:3d} EXISTS={exists} "
          f"{'' if rec['ok'] else '!!! CHECK FAILED'} {rec.get('odd_sol_check','')} t={rec['time']}s",
          flush=True)
