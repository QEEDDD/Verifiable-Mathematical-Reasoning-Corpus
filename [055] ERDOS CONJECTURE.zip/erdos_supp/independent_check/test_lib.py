"""Sanity tests of okada_lib against brute force (floating point)."""
import sys, random
from math import gcd
sys.path.insert(0, '/tmp/claude-0/-home-claude/5ad56b25-3dae-5235-9aee-21861d660576/scratchpad/indep_check')
from okada_lib import *

def brute_W(q, X):
    ps = [p for p, _ in factor(q)]
    acc = {}
    stack = [1]
    seen = 0
    # enumerate all m in M(q) with m <= X
    ms = [1]
    for p in ps:
        new = []
        for m in ms:
            t = m
            while t <= X:
                new.append(t)
                t *= p
        ms = new
    for m in ms:
        acc[m % q] = acc.get(m % q, 0.0) + 1.0 / m
    return acc, len(ms)

for q in [9, 15, 21, 45, 63, 75, 105, 225, 11025, 27225]:
    N, D = W_weights(q)
    X = 10**14
    bw, cnt = brute_W(q, X)
    err = 0.0
    for r in set(N) | set(bw):
        ex = N.get(r, 0) / D
        err = max(err, abs(ex - bw.get(r, 0.0)))
    print(f"q={q:6d} |S|={len(N):6d} brute terms={cnt:8d} max|W_exact - W_brute(X=1e14)| = {err:.3e}  D bits={D.bit_length()}")
    sys.stdout.flush()

# check okada1_sequential against direct W-based formula on random f for small q
for q in [9, 15, 21, 45, 63, 75, 105, 225]:
    f = [0] + [random.choice([-1, 1]) for _ in range(q - 1)]
    G, D1 = okada1_sequential(f, q)
    N, D2 = W_weights(q)
    ok = True
    for a in G:
        direct = Fraction(sum(f[(a * r) % q] * v for r, v in N.items()), D2)
        if Fraction(G[a], D1) != direct:
            ok = False
    print(f"q={q}: sequential vs W-direct exact agreement on all units: {ok}")
