# Square moduli, sparse masks, and sign obstructions for vanishing Erdős sums

Supplement to the separate follow-up manuscript by Keio, 24 October 2026.
The preceding counterexample manuscript has not been edited.

## Proved statements in this draft

1. An odd rational Okada vector modulo an odd q exists exactly when q is a square. This is an analytic theorem, not a finite-range inference.
2. For every prime ell and integer q > 1, an Okada vector with f(0)=0 and all other values in 1 + ell Z_(ell) exists exactly when q=m^ell with m=1 modulo ell. The proof includes nonsplit primes and even q.
3. Every modulus 3^(2a) 5^(2b) 7^(2c), a,b,c>=1, admits an actual sign counterexample. This completely classifies odd moduli supported on {3,5,7}: counterexamples are exactly the squares divisible by 105^2.
4. An arbitrary even power of 11 can be appended to this family. Further partial families on {3,5,11} are stated precisely in the manuscript.
5. No sign counterexample exists at 195^2=38025, without a symmetry assumption. The final proof uses small explicit inequalities rather than solver output.
6. Every odd square has feasible bounded integer orbit sums. Feasible orbit sums do not certify a sign counterexample. An infinite large-prime family also has no sign counterexample invariant under the specified odd-order subgroup; arbitrary non-invariant signs remain undecided there.

These are mathematical proofs and internal independent computational audits, not external peer review. No unrelated named conjecture is claimed solved. A 2025 seminar announcement by Bharadwaj, Murty, and Pathak already states nonsquare nonvanishing for sign functions. Their submitted manuscript was not obtained, so novelty of the stronger congruence classification and proof must still be compared with it.

## Main reproducibility command

From this directory, run:

```sh
python run_checks.py
```

Only the Python standard library is needed. This checks the original four seed functions, all five sparse masks, three independent checks concerning 38025, and both nonbinary congruence examples. All arrays use indices 0 through q-1. The mask tables are expanded independently and compared to their saved arrays.

For additional algebra audits:

```sh
python -m pip install -r requirements-optional.txt
python run_checks.py --algebra
```

The optional audits check global deletion circuits, explicit exponent-reduction maps, and the equivalence between the original 38025 equation space and its supplied shadow matrix. They require SymPy and python-flint. Optimization software is not required for any distributed verification.

The exact run already completed is recorded in `verification_results.json`; the congruence examples also have separate JSON reports. These finite checks support reproducibility. The global mathematical inductions are in `manuscript.tex` and the audit notes.

## Files

- `manuscript.tex`: complete standalone LaTeX source; compile twice with pdflatex.
- `data/seed_11025.json`, `seed_27225.json`, `seed_99225.json`, `seed_245025.json`: the four original exact seeds used here.
- `verify_q11025_full.py`: original-equation verifier using exact functional-graph resolvents, despite its historical filename.
- `followup/propagation/mask_*.json`: five compact mask tables, their full value arrays, and exact verification reports.
- `followup/propagation/verify_sparse_masks.py`: standard-library mask expander and original-equation checker.
- `followup/nonsymmetric_195/`: analytic count checker, integer-matrix checker, eight exact separating certificates, and detailed proof.
- `followup/character_constructions/`: independent short-proof audit, integration review, and the optional rigidity calculation for direct prime substitution in the preceding paper's template.
- `followup/new_principles/`: full-equation space audit, global proof audit, and exact examples at 343 and 64.
- `followup/global_obstruction_independent_audit.md`: independent review of the analytic support-elimination proof.
- `followup/audit_global_elimination.py`: exact tests of 226 deletion circuits and 52 anchored decompositions.
- `followup/exponent_reduction.tex`: additional constructive exponent-reduction argument.
- `followup/core_certificates_*.json`: earlier finite core certificates, retained as regression data. They are no longer needed for global nonsquare nonvanishing.
- `followup/independent_shadow_certificate_check.py`: independent reconstruction and verification of those certificates; requires python-flint.
- `followup/propagation/automatic_transfer.tex`: optional elementary transfer to nonperiodic automatic sign sequences, not advertised as a named conjecture resolution.
- `audit_attachment/erdos_supp/code/`: three unchanged support modules from the earlier supplied supplement, used by optional algebra audits. The original full-residue mask and seed checks do not depend on these modules.
- `SHA256SUMS`: checksums for every other file in this supplement.

The integration-review note records three issues which were corrected in the final manuscript: masks require m>1, undefined height-proof notation was removed, and all promised seed data and exact checks are included here.

## Sparse-mask rules

| Period Q | Zero positions | Inflation rule |
|---:|---:|---|
| 11025 | Multiples of 49 | q -> 49q when 225 divides q |
| 11025 | Multiples of 25 | q -> 25q when 441 divides q |
| 99225 | Multiples of 81 | q -> 81q when 1225 divides q |
| 27225 | Multiples of 121 | q -> 121q when 225 divides q |
| 245025 | Multiples of 81 | q -> 81q when 3025 divides q |

For each mask g and eligible seed f, set H(n)=g(n) off the mask's zero positions, and H(n)=f(n/m) when m divides n. The proof uses L(1,H)=L(1,g)+L(1,f)/m. All five masks were independently checked against every original unit equation and every prime equation, using rational arithmetic.

## Primary-source priority records

- https://sites.google.com/view/shman/number-theory-seminar-2025-26 (1 October 2025 announcement)
- https://www.cmi.ac.in/~siddhi/publications.html (submitted paper, item 21)
- https://www.cmi.ac.in/~siddhi/Okada_space_RM_SP_Final.pdf
- https://arxiv.org/abs/2204.03674

Do not infer that every square has a genuine sign solution, or that an inconclusive search proves nonexistence. The generalized ell-adic theorem permits unbounded rational coefficients and does not assert a binary sign construction for ell>2.
