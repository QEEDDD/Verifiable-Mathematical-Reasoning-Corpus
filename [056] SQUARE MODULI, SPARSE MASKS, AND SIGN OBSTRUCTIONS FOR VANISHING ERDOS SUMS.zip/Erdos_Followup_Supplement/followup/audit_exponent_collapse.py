"""Independent exact coordinate audit of the p^3 -> p shadow map.

The map is implemented from its coordinate formula, then checked against every
integer-kernel basis vector of the full source shadow matrix. No solver status
or numerical tolerance is used.
"""
from fractions import Fraction as F
from pathlib import Path
from itertools import product, combinations
import sys
import json
import flint

sys.path.insert(0, str(Path(__file__).resolve().parents[1] /
                       "audit_attachment/erdos_supp/code"))
from shadow import Shadow


def matrix(s):
    rows = s.rows()
    return flint.fmpz_mat(len(rows), s.nv,
                         [r.get(j, 0) for r in rows for j in range(s.nv)])


def independent_target_rows(s):
    """Rebuild integer character rows coefficient by coefficient.

    Unlike Shadow.rows(), this does not construct the functions H_m and then
    difference their rows. Each variable's coefficient is calculated directly
    as a product of two indicator differences in each primitive coordinate.
    """
    rows = []
    primes = s.primes
    for size in range(1, len(primes) + 1):
        for mp in combinations(primes, size):
            m = 1
            for p in mp:
                m *= p
            ns = [2 ** s.t[p] for p in mp]
            for ks in product(*(range(1, n) for n in ns)):
                row = {}
                for (d, x), i in s.var.items():
                    if d % m:
                        continue
                    dp = s.rad_primes(d)
                    z = [x[dp.index(p)] for p in mp]
                    extra = [p for p in dp if p not in mp]
                    base = 1
                    for p in primes:
                        if d % p:
                            base *= p - 1
                    value = 0
                    for bits in product((0, 1), repeat=len(extra)):
                        coef = base
                        shifts = [0] * size
                        for p, use_shift in zip(extra, bits):
                            if use_shift:
                                coef = -coef
                                for j, ell in enumerate(mp):
                                    shifts[j] += s.dl[ell][p % ell]
                            else:
                                coef *= p
                        for zi, shift, n, k in zip(z, shifts, ns, ks):
                            y = (zi - shift) % n
                            coef *= int(y == k) - int(y == 0)
                        value += coef
                    if value:
                        row[i] = value
                rows.append(row)
    for p, e in sorted(s.P.items()):
        row = {}
        for (d, x), i in s.var.items():
            valuation = 0
            while d % p == 0:
                valuation += 1
                d //= p
            coefficient = (p - 1) * (e - valuation) - (valuation > 0)
            if coefficient:
                row[i] = coefficient
        rows.append(row)
    rows.append(dict.fromkeys(range(s.nv), 1))
    return rows


def audit(p, r, ell):
    q = p ** 3 * r
    source = Shadow(q)
    target = Shadow(p * r)
    assert source.P[p] == 3 and r % p and r % ell == 0
    np = 2 ** source.t[p]
    nl = 2 ** source.t[ell]
    shift = source.dl[ell][p % ell] % nl
    correction = [F(0) for _ in range(target.nv)]
    for (d, x), i in target.var.items():
        pr = target.rad_primes(d)
        if d == p * ell and x[pr.index(ell)] == 0:
            correction[i] -= F(1, np)
        elif d == ell:
            if x[0] == 0:
                correction[i] += F(p, p - 1)
            if (x[0] + shift) % nl == 0:
                correction[i] -= F(1, p - 1)
    folds = []
    positive_p = []
    for (d, x), i in source.var.items():
        new_d = d
        if d % p == 0:
            positive_p.append(i)
            while new_d % (p * p) == 0:
                new_d //= p
        folds.append((i, target.var[(new_d, x)]))
    big = matrix(source)
    small_rows = independent_target_rows(target)
    canonical = lambda rows: sorted(tuple(sorted(row.items())) for row in rows)
    assert canonical(small_rows) == canonical(target.rows()), "independent matrix reconstruction mismatch"
    kernel, nullity = big.nullspace()
    for k in range(nullity):
        v = [int(kernel[i, k]) for i in range(source.nv)]
        total = sum(v[i] for i in positive_p)
        w = [total * c for c in correction]
        for old_i, new_i in folds:
            w[new_i] += v[old_i]
        assert all(sum(a * w[i] for i, a in row.items()) == 0
                   for row in small_rows), (p, r, ell, k)
    return {"source_q": q, "target_q": p*r, "p": p,
            "auxiliary_prime": ell, "source_variables": source.nv,
            "target_variables": target.nv, "source_nullity": nullity,
            "status": "every source-kernel basis vector maps into independently reconstructed target kernel"}


if __name__ == "__main__":
    # Mixed sizes of 2-quotients, higher auxiliary exponents, and extra primes.
    cases = [(3, 5, 5), (5, 3, 3), (7, 9, 3), (3, 25, 5),
             (3, 49, 7), (3, 125, 5), (5, 17, 17),
             (3, 5*7, 5), (3, 5*7, 7), (17, 3, 3)]
    results = [audit(*case) for case in cases]
    path = Path(__file__).with_name("audit_exponent_collapse.json")
    path.write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2))
