"""Exact independent checks of the support-elimination circuit.

This is a regression check for a general algebraic proof, not a replacement
for that proof. All arithmetic is integral or fractions.Fraction.
"""
from fractions import Fraction as F
from itertools import combinations, product
from pathlib import Path
from math import prod
import json
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] /
                       "audit_attachment/erdos_supp/code"))
from shadow import Shadow
from audit_exponent_collapse import independent_target_rows


def tuples(primes, sizes):
    return list(product(*(range(sizes[p]) for p in primes)))


def anchored_decompose(primes, sizes, values):
    """Decompose a zero-mixed-contrast function without any division."""
    k = len(primes)
    lower = {i: {x: 0 for x in tuples(primes[:i] + primes[i+1:], sizes)}
             for i in range(k)}
    for mask in range(1 << k):
        active = [i for i in range(k) if mask >> i & 1]
        omitted = [i for i in range(k) if not mask >> i & 1]
        component = {}
        for coords in product(*(range(sizes[primes[i]]) for i in active)):
            total = 0
            for subset in range(1 << len(active)):
                point = [0] * k
                for j, i in enumerate(active):
                    if subset >> j & 1:
                        point[i] = coords[j]
                total += (-1) ** (len(active) - subset.bit_count()) * values[tuple(point)]
            component[coords] = total
        if not omitted:
            assert not any(component.values()), "nonzero full mixed contrast"
            continue
        destination = omitted[0]
        for x in lower[destination]:
            full = list(x)
            full.insert(destination, 0)
            lower[destination][x] += component[tuple(full[i] for i in active)]
    for x, value in values.items():
        assert value == sum(lower[i][x[:i] + x[i+1:]] for i in range(k))
    for h in lower.values():
        assert len({v % 2 for v in h.values()}) == 1
    return lower


def audit(primes):
    shadow = Shadow(prod(primes))
    rows = independent_target_rows(shadow)
    # Omit the logarithmic rows: the circuit changes the removed prime's B*.
    char_rows = rows[:-len(primes)-1]
    sizes = {p: 2 ** shadow.t[p] for p in primes}
    tested_basis = 0
    tested_decompositions = 0
    for card in range(2, len(primes) + 1):
        for support in combinations(primes, card):
            source_d = prod(support)
            source_points = tuples(support, sizes)
            for index, p in enumerate(support):
                other = support[:index] + support[index+1:]
                target_d = prod(other)
                other_points = tuples(other, sizes)
                shift = tuple(shadow.dl[ell][p % ell] % sizes[ell] for ell in other)
                np = sizes[p]
                for origin in other_points:
                    changes = {}
                    for point in source_points:
                        if point[:index] + point[index+1:] == origin:
                            changes[shadow.var[(source_d, point)]] = F(-1)
                    for point in other_points:
                        translated = tuple((x+s) % sizes[ell]
                                           for x, s, ell in zip(point, shift, other))
                        coefficient = F(np, p-1) * (
                            p * int(point == origin) - int(translated == origin))
                        if coefficient:
                            changes[shadow.var[(target_d, point)]] = coefficient
                    assert sum(changes.values()) == 0
                    for row in char_rows:
                        assert sum(row.get(i, 0) * v for i, v in changes.items()) == 0
                    # Each other prime's total mass is unchanged; p changes by -N_p.
                    for ell in primes:
                        delta_t = sum(v for (d, x), i in shadow.var.items()
                                      if d % ell == 0 and (v := changes.get(i, F(0))))
                        assert delta_t == (-np if ell == p else 0)
                    tested_basis += 1
            # Construct constant-parity examples with no primitive component,
            # then recover them by integer-only anchored inclusion-exclusion.
            for seed in range(4):
                values = {}
                for x in source_points:
                    value = 0
                    for i in range(card):
                        omitted_x = x[:i] + x[i+1:]
                        value += ((seed+i) % 2) + 2 * sum(
                            (j+1)*(z+1)*(seed+2) for j, z in enumerate(omitted_x))
                    values[x] = value
                pieces = anchored_decompose(support, sizes, values)
                for i, h in pieces.items():
                    p = support[i]
                    other = support[:i] + support[i+1:]
                    shift = tuple(shadow.dl[ell][p % ell] % sizes[ell] for ell in other)
                    assert sum(h.values()) % 2 == 0
                    for x in h:
                        translated = tuple((z+s) % sizes[ell]
                                           for z, s, ell in zip(x, shift, other))
                        v = F(sizes[p], p-1) * (p*h[x]-h[translated])
                        assert v.denominator % 2 == 1 and v.numerator % 2 == 0
                tested_decompositions += 1
    return {"primes": primes, "basis_circuits_checked": tested_basis,
            "anchored_decompositions_checked": tested_decompositions,
            "status": "all exact character, mean, mass-change, parity checks passed"}


if __name__ == "__main__":
    results = [audit(primes) for primes in ((3, 5), (3, 5, 7), (3, 5, 17), (7, 11, 13))]
    Path(__file__).with_name("audit_global_elimination.json").write_text(
        json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2))
