# Integration review of the follow-up paper

Reviewed: `../Erdos_Followup_Square_Moduli_20261024.tex` (24 October 2026).
The main file was not edited. The pending generalization of the prime-adic
section was deliberately left to its assigned reviewer.

## Required small corrections

1. **The mask definition admits an unintended endpoint.** It only says
   `m | Q`, so `m=1` and the identically zero function are allowed. The
   later statement that every such mask obeys
   `2 phi(Q) <= Q-Q/m` is false for that endpoint. Define masks with
   `1 < m | Q`, or restrict the support corollary to `m>1`. All actual
   certificates and inflation rules already satisfy the stronger condition.

2. **The height proof imports notation missing from the assembled paper.**
   It writes `q A_chi(f)` without defining `A_chi` in the preliminary
   character criterion. Either define it there as `1/q` times the left
   side of the character equation, or remove the intermediate symbol.
   The remark's `B_r=0` is also undefined; replace it by “the prime-r
   equation.” These are notation gaps, not proof gaps.

## Recommended clarification

The smooth-modulus classification invokes “Okada's inequality” without
stating its exact form. A forward reference to the paper's own support
bound with `h=f` proves `2 phi(q) <= q-1` and makes this step self-contained.

The verification section promises original seed data and their exact
full-equation checks in the supplement. Ensure these are actually included
in the final package, especially the four seeds at 105^2, 315^2, 165^2,
and 495^2. This is a packaging check, not a mathematical objection to
citing the preceding certified constructions.

## Checks that passed

- The initial distinction between odd rational vectors, bounded actual
  orbit sums, and genuine sign vectors is maintained throughout. The
  abstract's complete classification on prime support contained in
  `{3,5,7}` follows from the proved results, with no missing edge case.
- The shadow sufficiency construction uses orbit sums of absolute value
  one and correctly divides by odd fibre sizes. Its arbitrary sign lifts
  are never asserted to satisfy omitted equations. The displayed q=9
  example and its primitive-character coefficient 4 are correct.
- The support-count proof is correct apart from the `m=1` endpoint above.
  Its weight-one identity includes the zero residue correctly.
- The mask insertion condition `Q | m q` is sufficient, with no
  coprimality needed. Period sums and harmonic sums compose as claimed.
- All five advertised unit-equation counts equal phi(Q). The displayed
  49-mask table matches its JSON certificate entry for entry.
- The two seeds 105^2 and 315^2, together with multiplication by 81,
  cover both parities of the half-exponent of 3. The 25 and 49 masks then
  increase the other half-exponents independently. All divisibility
  conditions remain true under iteration.
- The two radical-165 seeds cover b=1 under multiplication by 81 and
  121. Multiplication of b such counterexamples gives every pair of
  half-exponents a,c >= b, exactly as stated. The paper does not
  accidentally claim the remaining radical-165 exponents.
- Appending powers of 121 to the complete radical-105 family gives the
  displayed four-prime family, since divisibility by 225 persists.
- The assembled analytic 195^2 proof retains the valid forcing, CRT,
  fibre-count, Fourier-shift, and transition arguments previously audited.
- The height theorem is correctly limited to local odd-order-invariant
  functions. Its infinite family is not misreported as excluding all
  counterexamples. The N=1 sharpness example is valid.
- The announced 2025 nonsquare result is clearly separated from the
  stronger odd-vector theorem, and the absence of the full submitted
  manuscript is disclosed. No claim of resolving an unrelated named
  conjecture appears.
- The higher-integer-argument nonvanishing inequality is correct and
  explicitly identified as an elementary estimate.

No substantive integration error was found beyond the trivial-mask
endpoint. The original manuscript was left unchanged.
