# Independent audit of the short analytic exclusion at 38025

Audited document: `../nonsymmetric_195/q195_exclusion.md`.

Verdict: the proof is valid for arbitrary sign functions, conditional only
on the standard necessary Okada equations stated in the original paper.
No invariance hypothesis on the original function is used. No error or
unjustified step was found in this audit.

The audit checked the reasoning independently, then recomputed the
constants using divisor Euler-phi formulas in `audit_38025_short.py`.
The latter does not import the author's raw-residue checker or matrix
code. It also checks the Fourier-shift direction using exact Gaussian
integer arithmetic. All checks passed.

## Forcing and unit rigidity

The mass of smooth multiples of q is exactly R/q, and their values are
zero. Thus agreeing mass is `(R*(1-1/q)-2)/2=73/4680<1/64`.
Each listed multiplier has reciprocal mass exceeding this budget, so
its value must oppose the unit sign. This applies uniformly to every
unit, not just to one orbit.

The multiplier 9 removes the entire U_9 coordinate of the unit sign
function; multiplier 25 removes U_25; multiplier 13 removes the kernel
of U_169 -> U_13. The simultaneous conclusion is dependence only on
the residue modulo 13, by CRT.

The comparison of 9 with 27 is legitimate: a unit b can be chosen with
`b=3a (mod q/9)` because q/9 is coprime to 3. This gives `9b=27a (mod q)`.
The forced signs then imply `G(3t)=G(t)`. Since 3 has order 3 modulo 13,
the four unit signs are correctly indexed by discrete logarithm modulo 4.
No comparison of distinct gcd layers such as 9 and 45 is required.

Each unit modulo d=q/g lifts to a unit modulo q, so the nine full gcd
layers are indeed fixed. The correct four-sign index is that of x=n/g,
not that of n. The proof uses this convention consistently.

## Character equation and the direction of translation

For a character of U_13/<3>, one has chi(3)=1. The layered coefficient
weight is 13/12 when 5 does not divide d, and
`(13/48)*(5-chi(5))` when 5 divides d, independently of the exponent of 3.
Multiplication by 96/13 gives 8 and `10-2*chi(5)`.

Because `ind_2(5)=9=1 (mod 4)` and the Fourier transform uses the
complex conjugate character, the transform of `B(j+1)` is
`chi(5)*hat(B)`. Therefore the correct expression is exactly
`H(j)=8*A(j)+10*B(j)-2*B(j+1)`.

The three nonprincipal Fourier coefficients vanish, so H is constant.
The quantities A and B are actual fibre sums of the original signs;
the argument never replaces a sign function by its nonintegral average.

## Counts and final contradiction

Each A fibre contains 378 entries, with signed fixed contribution
`-234*F_j` and 144 free entries. Each B fibre contains 9072 entries,
with signed fixed contribution `456*F_j` and 168 free entries.
Thus `H_j=2688*F_j-912*F_(j+1)+e_j`, with `|e_j|<=3168`.

Any nonconstant cyclic sign pattern has both kinds of sign transition.
At a positive-to-negative transition, H is at least 432; at the reverse
transition, H is at most -432. This contradicts constancy.

For a constant pattern the fixed part of twice the prime-3 equation is
`-8886*sum(F_j)`, of magnitude 35544. There are 1472 remaining signs, and
the coefficient magnitude is at most 4, giving the sufficient bound
5888. The exact sum of their coefficient magnitudes is even smaller,
2912. Hence a constant pattern is impossible too.

This independently validates the analytic theorem excluding all
Erdos counterexamples at q=195^2. It is an internal audit, not external
peer review or an assertion that the literature has been fully searched.
