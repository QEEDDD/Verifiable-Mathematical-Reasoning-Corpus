#!/usr/bin/env python3
"""Independent exact audit of the short 195^2 proof.

This checker uses divisor formulas, not the other agent's raw-residue
enumeration or any shadow matrix.  Every calculation uses exact fractions.
It additionally checks the character weights as polynomials in chi(5).
"""
from fractions import Fraction as Q
from itertools import product
import json
from pathlib import Path

primes = (3, 5, 13)
q = 195**2
fixed_g = {1, 3, 5, 9, 13, 15, 25, 39, 45}

def pp_phi(p, e):
    return (p-1)*p**(e-1) if e else 1

layers = []
for exponents in product(range(3), repeat=3):
    d = 1
    phi = 1
    for p, e in zip(primes, exponents):
        d *= p**e
        phi *= pp_phi(p, e)
    if d > 1:
        layers.append((d, phi, exponents))

R = Q(3, 2)*Q(5, 4)*Q(13, 12)
E = (R*(1-Q(1, q))-2)/2
assert E == Q(73, 4680)
assert E < Q(1, 64)
forced = [3, 5, 9, 13, 15, 25, 27, 39, 45]
assert all(Q(1, m) > E for m in forced)
assert pow(2, 4, 13) == 3 and pow(2, 9, 13) == 5
assert len({pow(2, k, 13) for k in range(12)}) == 12

totals = {"A": 0, "B": 0}
signed_fixed = {"A": 0, "B": 0}
fixed_count = {"A": 0, "B": 0}
fixed_p3_per_fibre = 0
free_count = 0
free_p3_bound = 0
weight_checks = 0
for d, phi, exponents in layers:
    g = q//d
    is_fixed = g in fixed_g
    p3_coefficient = 2*(2-exponents[0]) - int(exponents[0] > 0)
    if is_fixed:
        assert d % 13 == 0
        fixed_p3_per_fibre += p3_coefficient*(1 if g == 1 else -1)*(phi//4)
    else:
        free_count += phi
        free_p3_bound += abs(p3_coefficient)*phi
    if d % 13:
        continue
    assert phi % 4 == 0
    group = "B" if d % 5 == 0 else "A"
    totals[group] += phi//4
    if is_fixed:
        fixed_count[group] += phi//4
        signed_fixed[group] += (1 if g == 1 else -1)*(phi//4)

    # The coefficient is a polynomial C0 + C1*t, where t=chi(5).
    # First take d/phi(d), then multiply every actual Euler factor.
    C0, C1 = Q(d, phi), Q(0)
    if exponents[0]:
        C0 *= Q(2, 3)  # chi(3)=1
    if exponents[1]:
        C1 = -C0/5
    C0 *= Q(96, 13)
    C1 *= Q(96, 13)
    assert (C0, C1) == ((Q(10), Q(-2)) if exponents[1] else (Q(8), Q(0)))
    weight_checks += 1

assert totals == {"A": 378, "B": 9072}
assert signed_fixed == {"A": -234, "B": 456}
free_fibres = {key: totals[key]-fixed_count[key] for key in totals}
assert free_fibres == {"A": 144, "B": 168}
assert free_count == 1472
assert fixed_p3_per_fibre == -8886
assert free_p3_bound == 2912

# Check Fourier shift directly in Q(i). Complex pairs below are exact.
def add(z, w):
    return (z[0]+w[0], z[1]+w[1])
def mul(z, w):
    return (z[0]*w[0]-z[1]*w[1], z[0]*w[1]+z[1]*w[0])
ipower = [(1, 0), (0, 1), (-1, 0), (0, -1)]
def fft(values, k):
    result = (0, 0)
    for j, value in enumerate(values):
        result = add(result, mul((value, 0), ipower[(-k*j)%4]))
    return result
for basis_index in range(4):
    basis = [int(j == basis_index) for j in range(4)]
    shifted = [basis[(j+1)%4] for j in range(4)]
    for k in range(4):
        assert fft(shifted, k) == mul(ipower[k], fft(basis, k))

error = 8*free_fibres["A"] + 12*free_fibres["B"]
assert error == 3168
nonconstant_gap = 2*(2688+912)-2*error
assert nonconstant_gap == 864
assert 4*abs(fixed_p3_per_fibre) > 4*free_count

report = {
    "status": "PASS",
    "method": "Independent divisor arithmetic and exact Q(i) Fourier shift",
    "agreeing_mass": str(E),
    "conductor_13_layer_weight_checks": weight_checks,
    "fibre_totals": totals,
    "signed_fixed_fibres": signed_fixed,
    "free_fibre_bounds": free_fibres,
    "fixed_prime3_coefficient": fixed_p3_per_fibre,
    "unrestricted_residues": free_count,
    "exact_unrestricted_prime3_bound": free_p3_bound,
    "nonconstant_pattern_separation_margin": nonconstant_gap,
    "fourier_shift": "B(j+1) transforms by multiplication by chi(5)",
}
Path(__file__).with_suffix(".json").write_text(json.dumps(report, indent=2)+"\n")
print(json.dumps(report, indent=2))
