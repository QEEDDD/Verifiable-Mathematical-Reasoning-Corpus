#!/usr/bin/env python3
"""Exact symbolic audit of the Table 1 template rigidity identities.

Only seven layer means are nonzero.  They are derived from the constant
Fourier coefficients in the original table, not from numerical L-values.
Run: python followup/character_constructions/symbolic_rigidity.py
"""
import json
from pathlib import Path
import sympy as s

a, b, c = primes = s.symbols("a b c", positive=True, integer=True)
R = s.Rational
constant = {
    (1, 0, 0): -1,
    (2, 0, 0): -1,
    (1, 0, 1): R(1, 2),
    (2, 1, 0): R(-1, 2),
    (2, 0, 1): R(1, 2),
    (1, 2, 0): R(1, 2),
    (1, 1, 1): R(-1, 2),
}

def phi_layer(exponents):
    return s.prod(p ** (k - 1) * (p - 1)
                  for p, k in zip(primes, exponents) if k)

means = {exponents: coeff * phi_layer(exponents)
         for exponents, coeff in constant.items()}
C = s.factor(sum(means.values()))
B = []
for idx, p in enumerate(primes):
    B.append(s.factor(sum(value * (2 - exponents[idx]
                         - (1 / (p - 1) if exponents[idx] else 0))
                         for exponents, value in means.items())))

expected = [
    -(a - 1) * (a - b + 2) * (b - c + 2) / 2,
    (b - c + 2) * (a*b - a - 2*b + 4) / 2,
    -(a - 1) * (a*b - 2*a*c + 4*a + b*c - 4*c + 8) / 2,
    -(a - 1) * (a - b + 2) * (2*b - c + 4) / 2,
]
assert all(s.expand(actual - wanted) == 0
           for actual, wanted in zip([C] + B, expected))
Tc = s.factor(sum(value for exponents, value in means.items()
                  if exponents[2]))
assert s.factor(Tc - (a-1)*(c-1)*(a-b+2)/2) == 0
assert s.factor(B[2] - (2*C - c*Tc/(c-1))) == 0
assert s.factor(B[0].subs(b, a+2) - a*(a-1)*(a-c+4)/2) == 0
assert all(value.subs({a: 3, b: 5, c: 7}) == 0 for value in [C] + B)

# Progression used in the large-prime theorem, independently evaluated.
examples = []
for r in range(11025 // 420 * 420 + 419, 22000, 420):
    if r > 11025 and s.isprime(r):
        symbols = [int(s.legendre_symbol(p, r)) for p in [3, 5, 7]]
        assert r % 4 == 3 and symbols == [1, 1, 1]
        examples.append({"r": r, "q": (105*r)**2,
                         "legendre_3_5_7": symbols})

report = {
    "C": str(C), "B_a": str(B[0]), "B_b": str(B[1]),
    "B_c": str(B[2]), "T_c": str(Tc),
    "rigidity_forces": ["b = a + 2", "c = a + 4", "(a,b,c) = (3,5,7)"],
    "large_prime_examples": examples,
    "status": "all exact symbolic identities and residue checks passed",
}
out = Path(__file__).with_name("symbolic_results.json")
out.write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
