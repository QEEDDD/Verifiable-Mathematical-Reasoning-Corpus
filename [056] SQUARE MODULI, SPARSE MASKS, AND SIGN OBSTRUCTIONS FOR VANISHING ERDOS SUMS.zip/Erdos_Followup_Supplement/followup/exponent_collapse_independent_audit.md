# Independent audit of the exponent reduction

Audited by a second agent against the displayed shadow equations in the original manuscript and the draft `general_shadow.md`, on 2026-10-24.

**Conclusion:** the reductions p^e r → p^(e−2)r for e≥4, and p^3 r → pr, are valid for the existence of all-odd Z_(2)-valued shadow vectors. No step proves preservation of ±1-valued functions. The stronger odd/even exponent core is justified.

## The e≥4 step

The coefficient D/φ(D), its Euler factors in the primitive-character equations, and the maximal 2-quotient Q_D depend on the prime support of D, not its positive exponents. Therefore replacing the top three p-layers by their pointwise sum preserves every character equation. It preserves oddness because three odd values sum to an odd value.

Under the mean equation, the logarithmic equation for p is equivalent to

B*_p = Σ_(p|D) ((p−1)v_p(D)+1) S_D = 0.

Collapsing layers e−2,e−1,e changes this by the negative of (p−1)Δ, where Δ=Σ_d(S_(e−1,d)+2S_(e,d)). Each S_(j,d) is even in Z_(2), because Q_(p^j d) has even cardinality. Thus Δ is even. Transferring an even vector of total Δ from layer p to layer p² restores B*_p and affects no other equation. Both target layers exist for e−2≥2.

The upward extension by opposite quadratic-character functions has zero total on each new layer and zero sum across the two layers. All displayed equations are therefore preserved. This checks both implications.

## The subtle e=3 to e=1 step

Assume r>1 and fix any prime ℓ dividing r. Let N_p=2^v2(p−1). Collapse the three positive p-layers and put

T=Σ_(j=1,2,3; d|r) S_(j,d),
Δ=Σ_d(S_(2,d)+2S_(3,d)).

The source equation is pT+(p−1)Δ=0. Since Δ is even and p is a unit in Z_(2),

T/N_p = −((p−1)/N_p) Δ/p ∈ 2 Z_(2).

This is sufficient for the parity argument. It is not necessary to assert the false stronger claim that each S_(j,d) is divisible by N_p; evenness of each sum suffices.

Choose h supported at one coordinate of Q_ℓ, with total −T/N_p. Every value of h is even. Make the following corrections to the collapsed vector:

δΦ_(pℓ)(y_p,y_ℓ)=h(y_ℓ),
δΦ_ℓ=−N_p/(p−1) (p−T_p)h,

where (T_p h)(y)=h(y+image(p)). The multiplier N_p/(p−1) has odd denominator and is a unit in Z_(2), so both corrections are even.

The total changes at layers pℓ and ℓ are −T and +T, respectively. Hence the mean is unchanged. Both layers have ℓ-valuation one, so their B*_ℓ weights are equal to ℓ and their changes cancel. Every other B*_s except B*_p sees neither layer. The correction changes B*_p by −pT, which cancels its value pT after collapse.

For the character equations there are only three possible affected primitive conductors: p, ℓ, and pℓ. At the two conductors containing p, the Fourier coefficient of δΦ_(pℓ) vanishes because this function is constant in the p-coordinate. At conductor ℓ, after removing the common factor ℓ/(ℓ−1), the increment is

δΦ̂_ℓ(χ) + (p−χ(p))/(p−1) · (N_p ĥ(χ)) = 0.

The translation sign is correct: with the stated convention and Fourier coefficient Σ h(y)overline(χ(y)), translating by +image(p) multiplies the coefficient by χ(p). Thus this cancellation holds exactly, including complex characters of order greater than two.

This verifies every equation and oddness. The upward implication follows from the opposite-character extension already checked. If r=1, both p and p³ are obstructed: the primitive equations force the sum of the odd number of p-layers to be constant, and the mean forces that constant to be zero, contradicting its oddness.

Consequently, for every odd q>1, the existence of an odd shadow vector depends only on its prime support and the parity of each positive exponent. Each positive odd exponent can be replaced by 1 and each positive even exponent by 2.

## Exact coordinate checks

`audit_exponent_collapse.py` implements the e=3 correction directly in coordinates. For each test, it computes an exact integer nullspace basis of the source shadow matrix, maps every basis vector by the rational collapse map, and verifies every target equation using exact rational arithmetic. The target character rows are reconstructed independently, coefficient by coefficient using indicator differences, instead of the original code's intermediate H_m arrays. The reconstructed rows also agree exactly with the supplied row implementation.

Tests cover:

- 135 → 15, with p=3 and ℓ=5;
- 375 → 15, with p=5 and ℓ=3;
- 3087 → 63, with p=7 and ℓ=3;
- 675 → 75, with p=3 and ℓ=5;
- 1323 → 147, with p=3 and ℓ=7;
- 3375 → 375, with p=3 and ℓ=5;
- 2125 → 85, with p=5 and ℓ=17;
- 945 → 105, separately with auxiliary primes 5 and 7;
- 14739 → 51, with p=17 and ℓ=3.

All mapped source-kernel basis vectors satisfy the independently reconstructed target equations. The tests include distinct powers of two in the quotient sizes, auxiliary primes with higher exponents in r, complex-character quotients, and more than two prime factors. The output is saved in `audit_exponent_collapse.json`.

The computation validates the map, while the parity and all-exponent claims follow from the proof above. The audit does not establish novelty or the full nonsquare obstruction conjecture across arbitrary prime supports.
