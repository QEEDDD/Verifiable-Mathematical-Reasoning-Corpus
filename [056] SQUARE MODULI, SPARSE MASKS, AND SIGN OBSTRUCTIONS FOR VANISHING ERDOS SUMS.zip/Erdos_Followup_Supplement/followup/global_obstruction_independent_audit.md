# Independent adversarial audit: global odd-vector obstruction

Audited against `global_obstruction_candidate.tex` and the original manuscript's displayed shadow equations, 2026-10-24.

**Verdict:** the global proof is valid. For every odd q>1, an all-odd Z_(2)-valued Okada vector exists if and only if q is a square. The necessity proof is finite support elimination and does not depend on any bounded computation. The converse has a direct construction. This does not prove that each square admits a ±1-valued Erdős counterexample.

## 1. Compression and the required congruence

Let q=∏p^(e_p), R=Z_(2), and N_p=2^v2(p−1). For every nonempty prime support S, sum the shadow layers with that support to obtain G_S. Its parity is constant and equal to ∏_(p∈S)e_p. This uses the exact number of positive exponent choices and requires no averaging or division.

The character coefficient for a layer D depends only on its prime support. Dividing by the common nonzero factor ∏_(p∈M)p/(p−1) yields precisely

Σ_(S⊇M) [∏_(p∈S\M)(p−χ(p))/(p−1)] Ĝ_S(χ)=0.

No local factor is omitted. Characters on the product quotient are primitive at squarefree support M exactly when their local components are nonprincipal at every prime in M.

Using the mean equation, the logarithmic equation for p becomes

Σ_(p|D) ((p−1)v_p(D)+1) S_D=0.

Thus, with T_p=Σ_(S∋p)ΣG_S,

T_p=−(p−1)Σ_(p|D)v_p(D)S_D ∈ 2(p−1)R=2N_pR.

Here each layer sum S_D is even because its domain has even cardinality and all its entries are odd. **Only evenness is required.** It would be false in general to claim divisibility of each S_D by |Q_D|, but the proof does not make or need that claim.

## 2. Anchored decomposition does not divide by 2

Suppose F on Q_S has constant parity and all its fully primitive Fourier coefficients vanish. Define

F_U(x_U)=Σ_(V⊆U)(−1)^(|U|−|V|)F(x_V,0_(S\V)).

The identity F=Σ_(U⊆S)F_U is ordinary finite inclusion–exclusion. The full term F_S is zero. To see this without any arithmetic assumption, expand F over complex characters: every remaining character is trivial in some coordinate, and taking a difference in that coordinate kills it. Equivalently, the integer primitive rows of the supplied shadow formulation are exactly these full anchored differences.

For nonempty U, the expression defining F_U has 2^|U| terms of identical parity. Therefore F_U is even-valued. The empty component is a constant. Assign each proper U to one missing coordinate p∈S\U and collect its inflation into h_p on Q_(S\{p}). This gives F=Σ_p inf h_p, with each h_p having constant parity. All coefficients in this construction are integers. No Fourier projector or division by |Q_S| is used to construct the h_p.

This verifies the key arithmetic step rather than merely a decomposition over Q or C.

## 3. The elimination circuit preserves exactly the needed data

For U=S\{p}, with |S|≥2, the circuit is

δG_S=−inf h,
δG_U=N_p/(p−1)(p−T_p^tr)h,

where (T_p^tr h)(y)=h(y+image(p)).

The ratio N_p/(p−1) has odd denominator. Since h has constant parity and p is odd, (p−T_p^tr)h is even. Therefore the lower-layer modification lies in 2R and does not alter that layer's parity.

For a primitive support containing p, the upper correction has zero Fourier coefficient because it is constant in the p-coordinate. For a support M⊆U, inflation contributes N_p and translation contributes χ(p), so the two contributions are exactly

−[(p−χ(p))/(p−1)]N_p ĥ(χ)
+[N_p/(p−1)](p−χ(p))ĥ(χ)=0.

The common Euler factors indexed by U\M multiply both terms equally. Other supports are unaffected. The sign of χ(p), including for nonreal characters, is correct for the stated translation convention.

Writing H=Σh, the upper and lower total changes are −N_pH and +N_pH. Consequently the mean and all T_s for s≠p are unchanged. The change in T_p is −N_pH. Since U is nonempty, |Q_U| is even, and constant parity of h gives H∈2R. Hence the congruence T_p∈2N_pR is preserved.

The circuit need not preserve the original logarithmic equations individually after compression. This is not a gap: the proof explicitly retains their necessary congruences T_p∈2N_pR, and those are sufficient for its contradiction.

## 4. Finite elimination and the final contradiction

Process supports of size at least two in descending size. When S is reached, all strict supersets are zero, so its primitive character equations require G_S to have no fully primitive component. Earlier modifications of this still-unprocessed layer were all even, so it still has constant parity. The anchored decomposition applies, and its circuits set G_S to zero while changing only smaller supports.

There are finitely many supports. Once only singletons remain, each G_{p} has all nonprincipal Fourier coefficients zero, so it is a constant a_p∈R. Its parity is still e_p. But

N_pa_p=T_p∈2N_pR

forces a_p even, hence e_p even. This proves necessity for arbitrary finite prime support, with no bound on the primes or exponents. It also covers a single-prime support, for which no elimination steps are necessary.

## 5. Converse checked directly

If every e_p is even, choose p(S) in each nonempty support S and a nontrivial quadratic character η on its quotient. Set

Φ_D(y)=(−1)^(v_(p(S))(D))η(y_(p(S)))

for every layer with support S. Every Φ_D is ±1-valued, every individual layer sum is zero, and each G_S is zero by summing over the even number of positive exponents of p(S). Thus all shadow equations hold. Dividing by the odd fibre cardinalities gives the required odd R-valued original vector. This construction proves the relaxation statement, not the stronger ±1 condition on the original f.

## 6. Exact circuit and decomposition checks

`audit_global_elimination.py` independently rebuilds the integer character equations coefficientwise and checks every elementary basis input h for every deletion circuit on prime sets

(3,5), (3,5,7), (3,5,17), (7,11,13).

This checks 226 basis circuits using exact fractions. Every character equation and the mean are unchanged; each T_s changes by the formula proved above. The latter two prime sets test quotient sizes 16 and odd-denominator ratios such as 1/3 and 1/5.

The script also builds 52 constant-parity examples with zero full mixed difference, reconstructs each using the integer-only anchored decomposition, and verifies constant parity of each h_p, evenness of Σh_p, and evenness with odd denominators of each lower correction. All checks passed. Results are saved in `audit_global_elimination.json`.

These calculations audit the formulas. The theorem follows from the general proof, not from the finite test range.

## 7. Scope of this verdict

No mathematical gap was found in the supplied global proof. The review does not establish bibliographic priority. The full announced Bharadwaj–Murty–Pathak result must still be compared: its published announcement about sign functions alone does not identify whether its proof already gives this stronger odd-vector classification.
