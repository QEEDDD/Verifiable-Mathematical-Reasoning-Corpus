"""Independent exact checker for the follow-up's shadow dual certificates.

Reconstructs the integer equation matrix directly from the displayed
primitive-functional formula. Does not import the original shadow, core,
twoadic, or certificate-generation code. Requires python-flint only.
"""
from pathlib import Path
from itertools import product
from math import prod, isqrt
from functools import lru_cache
import json, sys, time
import flint

def factor(n):
    result = []
    p = 2
    while p*p <= n:
        if n % p == 0:
            exponent = 0
            while n % p == 0:
                exponent += 1
                n //= p
            result.append((p, exponent))
        p = 3 if p == 2 else p+2
    if n > 1:
        result.append((n,1))
    return result

def divisors(factors):
    return sorted(prod(p**e for (p,_),e in zip(factors,exponents))
                  for exponents in product(*(range(a+1) for _,a in factors)))

@lru_cache(None)
def prime_data(p):
    divisors_pminus1 = [r for r,_ in factor(p-1)]
    generator = next(g for g in range(2,p)
                     if all(pow(g,(p-1)//r,p) != 1 for r in divisors_pminus1))
    size = (p-1) & -(p-1)
    logs = {}
    residue = 1
    for exponent in range(p-1):
        logs[residue] = exponent % size
        residue = residue*generator % p
    assert residue == 1 and len(logs) == p-1
    return size, logs

def independent_matrix(q):
    factors = factor(q)
    primes = [p for p,_ in factors]
    sizes = {p:prime_data(p)[0] for p in primes}
    ds = [d for d in divisors(factors) if d>1]
    supports = {d:tuple(p for p in primes if d%p==0) for d in ds}
    variables = [(d,x) for d in ds
                 for x in product(*(range(sizes[p]) for p in supports[d]))]
    rows = []
    conductors = sorted(prod(p for p,b in zip(primes,bs) if b)
                        for bs in product((0,1),repeat=len(primes)) if any(bs))
    for conductor in conductors:
        cps = supports[conductor]
        specifications = []
        for d in ds:
            if d%conductor: continue
            dps = supports[d]
            others = tuple(p for p in dps if p not in cps)
            prefactor = prod(p-1 for p in primes if p not in dps)
            projection = tuple(dps.index(p) for p in cps)
            shifts = []
            for bits in product((0,1),repeat=len(others)):
                sign = (-1)**sum(bits)
                coefficient = prefactor*sign*prod(p for p,b in zip(others,bits) if not b)
                shift = tuple(sum(prime_data(s)[1][p%s]
                                  for p,b in zip(others,bits) if b)%sizes[s]
                              for s in cps)
                shifts.append((coefficient,shift))
            specifications.append((d,projection,shifts))
        specs = {d:(projection,shifts) for d,projection,shifts in specifications}
        for ks in product(*(range(1,sizes[p]) for p in cps)):
            row = []
            for d,x in variables:
                if d not in specs:
                    row.append(0)
                    continue
                projection,shifts = specs[d]
                value = 0
                for coefficient,shift in shifts:
                    functional = 1
                    for s,k,j,t in zip(cps,ks,projection,shift):
                        z = (x[j]-t)%sizes[s]
                        functional *= int(z==k)-int(z==0)
                        if not functional: break
                    value += coefficient*functional
                row.append(value)
            if any(row): rows.append(row)
    # Use B* rather than the original B rows; together with C their
    # rational row spans agree by the displayed identity in the proof note.
    for p,_ in factors:
        row = []
        for d,x in variables:
            exponent, rest = 0, d
            while rest%p==0:
                exponent += 1
                rest //= p
            row.append((p-1)*exponent+1 if exponent else 0)
        rows.append(row)
    rows.append([1]*len(variables))
    return rows

def check_file(filename):
    results = json.loads(Path(filename).read_text())
    start = time.time()
    ncerts, nsquares = 0, 0
    seen = set()
    prime_support = None
    exponents_seen = set()
    for record in results:
        q = record['q']
        assert q not in seen
        seen.add(q)
        primes = tuple(record['primes'])
        exps = tuple(record['exponents'])
        if prime_support is None: prime_support=primes
        assert primes == prime_support
        assert q==prod(p**e for p,e in zip(primes,exps))
        exponents_seen.add(exps)
        certificate = record['certificate']
        if certificate is None:
            assert not record['obstructed'] and isqrt(q)**2==q
            nsquares += 1
            continue
        assert record['obstructed'] and isqrt(q)**2!=q
        assert all(type(value) is int for value in certificate)
        assert sum(certificate)%2==1
        rows = independent_matrix(q)
        assert len(rows[0])==len(certificate)==record['nvars']
        rank = flint.fmpz_mat(rows).rank()
        assert rank==record['rank']
        assert flint.fmpz_mat(rows+[certificate]).rank()==rank
        ncerts += 1
    expected = {es for es in product(range(4),repeat=len(prime_support)) if any(es)}
    assert exponents_seen==expected
    print(json.dumps({'file':str(filename),'records':len(results),
          'independently_verified_nonsquare_certificates':ncerts,
          'squares_covered_by_general_construction':nsquares,
          'seconds':round(time.time()-start,3)}))

if __name__=='__main__':
    for filename in sys.argv[1:]: check_file(filename)
