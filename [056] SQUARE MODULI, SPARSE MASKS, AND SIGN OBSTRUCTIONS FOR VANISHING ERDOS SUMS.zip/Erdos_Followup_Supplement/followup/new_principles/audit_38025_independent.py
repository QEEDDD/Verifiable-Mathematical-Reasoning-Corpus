"""Independent necessity and exact certificate audit for q=38025.

Does not import shadow.py or quotient.py and does not assume the supplied
matrix is necessary. Reconstructs averaged *original Okada unit equations*
by exact geometric summation of the three multiplication operators. It then
proves every supplied row lies in their rational span together with original
prime-valuation equations and the period sum.
"""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
import json, math
import flint

ROOT=Path(__file__).resolve().parents[2]
q=38025;primes=(3,5,13);powers={3:2,5:2,13:2};orders={3:2,5:4,13:4}
divisors=sorted(3**a*5**b*13**c for a,b,c in product(range(3),repeat=3))
logs={p:{pow(2,j,p):j for j in range(p-1)} for p in primes}
assert all(len(logs[p])==p-1 for p in primes)
dp=lambda d:tuple(p for p in primes if d%p==0)
labels=[(d,x) for d in divisors if d>1 for x in product(*(range(orders[p]) for p in dp(d)))]
index={x:i for i,x in enumerate(labels)};n=len(labels)
phi=lambda d:math.prod(p**(sum(1 for a in (1,2) if d%p**a==0)-1)*(p-1) for p in dp(d))
sizes=[phi(d)//math.prod(orders[p] for p in dp(d)) for d,x in labels]
assert n==404 and sum(sizes)==q-1 and all(m%2 for m in sizes)

def transition(state,p):
    """Multiplication of a residue by p, after passage to H-orbits."""
    d,x=state;ps=dp(d)
    if d%p==0:
        dd=d//p
        if dd==1:return None
        xx=tuple(x[ps.index(t)] for t in dp(dd))
        return (dd,xx)
    return (d,tuple((v+logs[t][p%t])%orders[t] for t,v in zip(ps,x)))

def geometric(state,p):
    """Sum p^{-k}[p^k state], k>=0, as an exact finite distribution."""
    seq=[];seen={};cur=state
    while cur is not None and cur not in seen:
        seen[cur]=len(seq);seq.append(cur);cur=transition(cur,p)
    cycle_start=seen[cur] if cur is not None else len(seq)
    length=len(seq)-cycle_start
    out={}
    for k,t in enumerate(seq):
        weight=F(1,p**k)
        if k>=cycle_start:weight/=1-F(1,p**length)
        out[t]=weight
    return out

# 32 original Okada unit equations after averaging under H_q.
A=[]
for start in (label for label in labels if label[0]==q):
    distribution={start:F(1)}
    for p in primes:
        nxt={}
        for state,weight in distribution.items():
            for dest,coefficient in geometric(state,p).items():
                nxt[dest]=nxt.get(dest,F(0))+weight*coefficient
        distribution=nxt
    row=[F(0)]*n
    for state,coefficient in distribution.items():
        j=index[state];row[j]=coefficient/sizes[j]
    A.append(row)

# Original Okada epsilon equations, not the transformed shadow version.
for p in primes:
    row=[]
    for d,x in labels:
        a=sum(1 for t in (1,2) if d%p**t==0)
        v=2-a
        row.append(F(v)+(F(1,p-1) if a==0 else F(0)))
    A.append(row)
A.append([F(1)]*n)

record=json.loads((ROOT/'followup/nonsymmetric_195/exact_no_counterexample_38025.json').read_text())
M=record['matrix']
assert record['q']==q and len(M)==35 and all(len(row)==n for row in M)
assert record['column_labels']==[[d,list(x)] for d,x in labels]
assert record['fiber_sizes']==sizes
Q=lambda rows:flint.fmpq_mat([[str(v) for v in row] for row in rows])
QA=Q(A);QM=Q(M)
rank_a=QA.rank();rank_m=QM.rank();rank_join=Q(A+M).rank()
assert rank_a==rank_m==rank_join==35

# Obtain a reproducible rational row-space identity M = T B, where B consists
# of 35 independently regenerated original Okada/epsilon/mean rows.
def pivots(R):
    return [next(j for j in range(R.ncols()) if R[i,j]) for i in range(R.nrows()) if any(R[i,j] for j in range(R.ncols()))]
AT=QA.transpose();rr,_=AT.rref();basis_indices=pivots(rr)
B=Q([A[i] for i in basis_indices]);br,_=B.rref();cols=pivots(br)
G=flint.fmpq_mat([[B[i,j] for j in cols] for i in range(35)])
MP=flint.fmpq_mat([[QM[i,j] for j in cols] for i in range(35)])
T=MP*G.inv();assert T*B==QM

# Exact forcing threshold, including the q-multiple zero terms.
R=math.prod(F(p,p-1) for p in primes)
W=R-1-R/q;E=(W-1)/2
assert R==F(65,32) and E==F(1,64)-F(1,37440)
smooth=sorted(3**a*5**b*13**c for a,b,c in product(range(5),range(4),range(3)) if 1<3**a*5**b*13**c<64)
assert smooth==[3,5,9,13,15,25,27,39,45]
assert all(F(1,m)>E for m in smooth)
assert pow(3,3,13)==1 and pow(3,1,13)!=1
assert {pow(3,j,13) for j in range(3)}=={pow(2,4*j,13) for j in range(3)}

# Check the eight supplied dual inequalities without calling any solver.
forced={1,3,5,9,13,15,25,39,45}
fixed=[i for i,(d,x) in enumerate(labels) if q//d in forced]
free=[i for i in range(n) if i not in set(fixed)]
assert len(fixed)==232 and len(free)==172
assert sum(sizes[i] for i in free)==1472
expected={(1,)+t for t in product((-1,1),repeat=3)}
assert {tuple(c['unit_pattern']) for c in record['certificates']}==expected
checks=[]
for cert in record['certificates']:
    pattern=cert['unit_pattern'];y=cert['integer_row_multiplier']
    assert len(y)==35 and all(isinstance(v,int) for v in y)
    fixed_values={}
    for i in fixed:
        d,x=labels[i];g=q//d;j=x[dp(d).index(13)]
        fixed_values[i]=(1 if g==1 else -1)*sizes[i]*pattern[j]
    row=[sum(y[r]*M[r][j] for r in range(35)) for j in range(n)]
    left=-sum(row[i]*fixed_values[i] for i in fixed)
    support=sum(sizes[i]*abs(row[i]) for i in free)
    assert left==cert['left'] and support==cert['box_support']
    assert left-support==cert['strict_gap'] and left>support
    checks.append({'pattern':pattern,'left':left,'support':support,'gap':left-support})

# Audit the shorter analytic proof by enumerating individual residues, rather
# than reusing totient/fibre formulas. Also check its three H-difference rows
# against the independently reconstructed original Okada rowspace.
H=[[0]*n for j in range(4)]
for i,(d,x) in enumerate(labels):
    if d%13:continue
    k=x[dp(d).index(13)]
    if d%5:
        H[k][i]+=8
    else:
        H[k][i]+=10;H[(k-1)%4][i]-=2
Hdiff=[[H[j][i]-H[0][i] for i in range(n)] for j in (1,2,3)]
assert Q(A+Hdiff).rank()==rank_a
counts={'forced_A':[0]*4,'forced_B':[0]*4,'free_A':[0]*4,'free_B':[0]*4,
        'forced_prime3':[0]*4,'free_all':0}
for r in range(1,q):
    g=math.gcd(r,q);d=q//g;x=r//g
    isfixed=g in forced
    if not isfixed:counts['free_all']+=1
    if d%13:continue
    k=logs[13][x%13]%4
    category='A' if d%5 else 'B'
    if isfixed:
        sign=1 if g==1 else -1
        counts['forced_'+category][k]+=sign
        exponent=sum(1 for a in (1,2) if d%3**a==0)
        coefficient=2*(2-exponent)-(1 if exponent else 0)
        counts['forced_prime3'][k]+=sign*coefficient
    else:
        counts['free_'+category][k]+=1
assert counts=={'forced_A':[-234]*4,'forced_B':[456]*4,'free_A':[144]*4,
               'free_B':[168]*4,'forced_prime3':[-8886]*4,'free_all':1472}
error_bound=8*144+12*168
assert error_bound==3168<3600
assert 4*1472==5888<2*8886

out={'q':q,'result':'PASS','independent_equations':len(A),'independent_rank':rank_a,
     'supplied_rank':rank_m,'joined_rank':rank_join,'exact_row_identity':'M = T B',
     'basis_indices':basis_indices,'basis_pivot_columns':cols,
     'T':[[str(T[i,j]) for j in range(T.ncols())] for i in range(T.nrows())],
     'basis_rows':[[str(v) for v in A[i]] for i in basis_indices],
     'forcing_agreement_mass':str(E),'forcing_smooth_integers':smooth,
     'free_individual_signs':sum(sizes[i] for i in free),'checks':checks,
     'short_proof_raw_residue_counts':counts,'H_difference_rows_necessary':True,
     'H_error_bound':error_bound,'H_transition_forcing':3600}
(Path(__file__).parent/'audit_38025_independent.json').write_text(json.dumps(out,indent=2))
print(json.dumps({k:v for k,v in out.items() if k not in ('basis_rows','T','basis_indices','basis_pivot_columns')},indent=2))
