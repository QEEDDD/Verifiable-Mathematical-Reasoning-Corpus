# Independent audit of the global square obstruction

Audited 24 October 2026 against `followup/global_obstruction_candidate.tex` and the original shadow equations.

**Conclusion: the argument is valid.** It proves that an odd modulus admits a rational Okada vector all of whose nonzero-residue values lie in `1+2 Z_(2)` if and only if it is a square. The forward direction does not rely on finite computation. The converse is the original prime-square construction and composition. This is a statement about odd rational vectors, not about the existence of an actual sign counterexample at every square.

The full proof also extends to the prime-ℓ congruence theorem in `ell_adic_classification.tex`. Both agents independently checked that extension. Novelty relative to the submitted Bharadwaj–Murty–Pathak paper remains unverified.

The finalized and stronger extension, covering arbitrary moduli rather than only primes `p≡1 mod ℓ`, is in `followup/ell_extension.tex`. Its criterion is exactly `q=m^ℓ` with `m≡1 mod ℓ`.

## 1. Compression retains the precise congruence information needed

Let `q=∏p^{e_p}`, `N_p=2^{v_2(p−1)}`, and `R=Z_(2)`. For each nonempty prime support `S`, let `Γ_S` be the pointwise sum of the shadow functions over all divisor layers with precisely that support. Then `Γ_S` has constant parity `∏_{p∈S} e_p`.

The normalized primitive-character equation of conductor `M` is

\[
\sum_{S\supseteq M}\prod_{p\in S\setminus M}
\frac{p-\chi(p)}{p-1}\,\widehat\Gamma_S(\chi)=0.
\]

This follows by factoring the common `∏_{p∈M}p/(p−1)` out of the original formula; there is no omitted exponent-dependent coefficient.

Under the mean equation, the original logarithm equation is equivalent to

\[
0=\sum_{p\mid D}((p-1)v_p(D)+1)\sum\Phi_D.
\]

Every layer sum is even, since the layer's quotient group has even cardinality and its entries are odd. Consequently

\[
T_p:=\sum_{S\ni p}\sum\Gamma_S\in2N_p R.
\]

It would be false to assert that each layer sum is divisible by `N_p`. The proof does not need that stronger assertion: evenness, followed by multiplication by `p−1`, is sufficient.

## 2. Anchoring avoids division by even group orders

Process supports in decreasing order of size, stopping at singletons. At a current support `S`, all strict supersets have already been eliminated. The primitive-character equations for full conductor `S` therefore say that `Γ_S` has no Fourier component nonprincipal in every coordinate.

For a chosen base point in each coordinate, let `E_i` set coordinate `i` to that base point. The operators commute. Absence of the full-coordinate Fourier part implies

\[
\prod_{i\in S}(I-E_i)\Gamma_S=0.
\]

Indeed, the character decomposition expresses `Γ_S` as a sum of functions each missing at least one coordinate, and the displayed product kills each such function. No Fourier denominators are used in the subsequent construction.

For any ordering of `S`, the telescoping identity now gives

\[
\Gamma_S=\sum_i E_i\prod_{j<i}(I-E_j)\Gamma_S
=\sum_i\operatorname{infl}_i h_i.
\]

Every `h_i` is `R`-valued. The first has the same constant parity as `Γ_S`; every later one is even because at least one anchored difference has been applied to a constant-parity function. Thus every `h_i` has constant parity.

## 3. Every invariant of the elimination circuit checks

For `p∈S`, set `U=S\{p}`. Remove a summand `infl_p h` from `Γ_S` and add

\[
\frac{N_p}{p-1}(p-\tau_p)h
\]

to `Γ_U`, where `τ_p h(y)=h(y+image(p))`.

- `N_p/(p−1)` is a unit of `R`, so the addition is `R`-valued.
- Since `h` has constant parity and `p` is odd, `(p−τ_p)h` is even. The parity of the still-live lower support is therefore unchanged.
- If a primitive conductor contains `p`, the removed summand has zero coefficient because it is constant in the `p`-coordinate. If the conductor does not contain `p`, its two changes cancel through the Euler factor `(p−χ(p))/(p−1)`. The translation sign is correct: `hat(τ_p h)(χ)=χ(p)hat(h)(χ)` with the stated Fourier convention.
- The top total decreases by `N_p Σh`; the lower total increases by the same quantity. Hence the mean is preserved.
- Every `T_r` with `r∈U` is unchanged. The only changed invariant is `T_p`, whose change is `−N_p Σh`.
- Here `U` is nonempty, so its quotient group has even cardinality. Since `h` has constant parity, `Σh∈2R`. Thus the congruence `T_p∈2N_pR` is preserved.

The parity of a support that has been completely removed may change from odd to zero. This is harmless. Only the unremoved lower supports need retain their initial parity, and the circuit does preserve it. Treating all supports' parities as invariant would be an incorrect formulation; the proof uses the correct weaker invariant.

## 4. The terminal singletons force all exponents even

After descent, only singleton functions remain. Their primitive-character equations force `Γ_{p}` to be constant, say `a_p`. Its parity is still `e_p mod 2`, because only even corrections have reached a singleton. Its invariant is now `T_p=N_p a_p∈2N_pR`, so `a_p` is even. Therefore every `e_p` is even.

The nonempty-support condition used in the circuit explains why descent must stop at singletons; removing a singleton would lose exactly the final obstruction. This boundary is respected by the proof.

## 5. Resulting additional classification

Combined with the explicit bounded-shadow construction in `new_principles.md`, the square criterion strengthens to:

> For odd `q>1`, the exact bounded integer orbit-sum shadow of a sign function is feasible if and only if `q` is a square.

Necessity follows because every such integer shadow is an odd rational shadow. Sufficiency is the explicit construction whose orbit sums are `±m_d` or `±m_d/p`. Thus the maximal 2-shadow, even with every orbit's exact finite alphabet imposed, detects squarehood and cannot distinguish individual square moduli admitting sign counterexamples.

## 6. Audit of the full prime-ℓ extension

The finalized theorem asserts existence of a rational period-`q` zero-mean vector with `f(0)=0`, `f(n)≡1 mod ℓ` off zero, and `L(1,f)=0`, if and only if `q≡1 mod ℓ` and every prime exponent of `q` is divisible by ℓ.

The mean gives `q≡1 mod ℓ`, so no prime divisor equals ℓ. For a nonsplit prime `b` with `ℓ∤b−1`, reducing its original transformed logarithm equation modulo ℓ gives `0≡e_b(b−1)q`; the divisor-sum identity behind this is exact. Thus `ℓ|e_b` without using descent.

For split primes, where `ℓ|p−1`, retain their maximal ℓ-quotients. The nonsplit quotients are trivial. The compressed residue at a support S is the product of `e_p(p−1)/N_p` over its split primes and `b^{e_b}−1` over its nonsplit primes. Folding each nonsplit coordinate with `(b−τ_b)/(b−1)` is integral over `Z_(ℓ)`, preserves augmentation, and acts as the identity on constant residues. Summing over subsets multiplies each remaining split-support residue by `r=∏ b^{e_b}`, a unit. It also preserves each split `T_p` exactly and groups the character equations correctly. The previous descent therefore forces the split exponents to be divisible by ℓ as well.

Two points need care: anchored **differences**, not merely a count of `2^k` terms, annihilate constant residues for odd ℓ; and a separate mean equation for the folded functions is not needed by the descent. The finalized text handles both correctly.

For sufficiency, the split prime-power construction has zero mean on every valuation layer, and its exact multiplier is `Σ c_t/p^t=0`. For the nonsplit factor r, every φ(D) is an ℓ-adic unit. Starting with fibre totals φ(D), the residual mean r−1 and all transformed prime totals are ℓ-multiples. An ℓ-multiple correction at one prime layer fixes the mean. A transfer from the p-layer to the p²-layer changes its prime equation by exactly `(p−1)` times the transfer and changes no other prime equation. Since every exponent is at least ℓ≥2, both layers exist. The resulting actual layer constants are still 1 modulo ℓ, and all nonprincipal characters vanish. Composition preserves every stated property.

Exact independent tests of the two explicit examples passed: at q=343, all 294 original Okada unit equations and the prime-7 equation; at q=64, all 32 original unit equations and the prime-2 equation. Both examples have zero mean and every nonzero-residue value is 1 modulo 3. The computations check the examples; the all-modulus theorem follows from the argument above.
