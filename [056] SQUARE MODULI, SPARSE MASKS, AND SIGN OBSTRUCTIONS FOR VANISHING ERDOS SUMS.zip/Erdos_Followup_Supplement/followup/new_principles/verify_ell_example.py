"""Independent exact verification of the nonbinary ell=3, q=343 example."""
from fractions import Fraction as F
from pathlib import Path
import json, math

p=7;q=343;ell=3;c=(1,1,-56)
def u(n):
    a=n%p
    return 0 if a==0 else (-5 if a==1 else 1)
def f(n):
    if n%q==0:return 0
    t=0
    while n%p==0:t+=1;n//=p
    return c[t]*u(n)
values=[f(n) for n in range(q)]
assert values[0]==0 and all(x%ell==1 for x in values[1:])
assert sum(values)==0
units=[a for a in range(1,q) if math.gcd(a,q)==1]
for a in units:
    # Every term with exponent >=3 vanishes exactly.
    assert sum((F(values[(a*p**j)%q],p**j) for j in range(3)),F(0))==0
prime_sum=F(0)
for n in range(p,q,p):
    t=0;m=n
    while m%p==0:t+=1;m//=p
    prime_sum+=t*values[n]
assert prime_sum==0
record={'q':q,'ell':ell,'values':sorted(set(values[1:])),
        'all_nonzero_residue_values_congruent_to_1':True,'period_sum':sum(values),
        'exact_original_Okada_unit_equations':len(units),
        'nonzero_unit_residuals':0,'prime_equation':str(prime_sum),
        'analytic_multiplier':str(sum((F(c[j],p**j) for j in range(3)),F(0)))}
(Path(__file__).parent/'verify_ell_example.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record,indent=2))
