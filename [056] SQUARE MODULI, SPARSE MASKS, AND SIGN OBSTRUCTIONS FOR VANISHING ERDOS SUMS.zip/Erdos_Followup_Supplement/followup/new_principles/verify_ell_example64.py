"""Exact original-Okada check of the nonsplit ell=3, q=64 example."""
from fractions import Fraction as F
from pathlib import Path
import json
q=64
values=[0]+[1]*63
values[32]=196
values[16]=values[48]=-128
assert sum(values)==0 and all(x%3==1 for x in values[1:])
for a in range(1,q,2):
    assert sum((F(values[(a*2**j)%q],2**j) for j in range(6)),F(0))==0
prime_sum=F(0)
for n in range(2,q,2):
    t=0;m=n
    while m%2==0:t+=1;m//=2
    prime_sum+=t*values[n]
assert prime_sum==0
record={'q':q,'ell':3,'values':sorted(set(values[1:])),
        'all_nonzero_residue_values_congruent_to_1':True,'period_sum':sum(values),
        'exact_original_Okada_unit_equations':32,'nonzero_unit_residuals':0,
        'prime_equation':str(prime_sum)}
(Path(__file__).parent/'verify_ell_example64.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record,indent=2))
