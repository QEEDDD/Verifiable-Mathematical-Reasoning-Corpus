#!/usr/bin/env python3
"""Check every finite count in the analytic q=38025 exclusion, using raw residues.
No shadow matrices, optimization software, SymPy, or external packages.
"""
from collections import Counter, defaultdict
from fractions import Fraction
from itertools import product
from math import gcd

q = 38025
D = {1, 3, 5, 9, 13, 15, 25, 39, 45}
log4 = {pow(2, k, 13): k % 4 for k in range(12)}
assert len(log4) == 12 and log4[3] == 0 and log4[5] == 1
R = Fraction(3, 2) * Fraction(5, 4) * Fraction(13, 12)
E = (R * (1 - Fraction(1, q)) - 2) / 2
assert E == Fraction(73, 4680) < Fraction(1, 64)
for m in [3, 5, 9, 13, 15, 25, 27, 39, 45]:
    assert Fraction(1, m) > E and q % gcd(m, q) == 0
counts = Counter()
fixed_prime3 = [0] * 4
free_prime3_bound = 0
A_total = [0] * 4
B_total = [0] * 4
A_fixed = [0] * 4
B_fixed = [0] * 4
A_free = [0] * 4
B_free = [0] * 4
free = 0
for n in range(1, q):
    g = gcd(n, q)
    d = q // g
    x = n // g
    counts[g] += 1
    v3 = 0
    t = d
    while t % 3 == 0:
        t //= 3
        v3 += 1
    c3 = 2 * (2 - v3) - int(d % 3 == 0)
    assert c3 in (4, 1, -1)
    fixed = g in D
    if fixed:
        assert d % 13 == 0
        j = log4[x % 13]
        sign = 1 if g == 1 else -1
        fixed_prime3[j] += c3 * sign
    else:
        free += 1
        free_prime3_bound += abs(c3)
    if d % 13 == 0:
        j = log4[x % 13]
        if d % 5:
            A_total[j] += 1
            if fixed:
                A_fixed[j] += sign
            else:
                A_free[j] += 1
        else:
            B_total[j] += 1
            if fixed:
                B_fixed[j] += sign
            else:
                B_free[j] += 1
assert sum(counts[g] for g in D) == 36552
assert free == 1472
assert fixed_prime3 == [-8886] * 4
assert free_prime3_bound == 2912 <= 4 * free == 5888
assert A_total == [378] * 4
assert B_total == [9072] * 4
assert A_fixed == [-234] * 4
assert B_fixed == [456] * 4
assert A_free == [144] * 4
assert B_free == [168] * 4
error_bound = 8 * 144 + 12 * 168
assert error_bound == 3168
assert 2 * 3600 > 2 * error_bound
assert 4 * 8886 > 4 * 1472
# Redundant exhaustive check of the 16 four-sign patterns, not needed in proof.
for pattern in product((-1, 1), repeat=4):
    h = [2688 * pattern[j] - 912 * pattern[(j + 1) % 4] for j in range(4)]
    if len(set(pattern)) > 1:
        assert max(h) == 3600 and min(h) == -3600
        assert max(h) - min(h) > 2 * error_bound
    else:
        assert abs(8886 * sum(pattern)) > 4 * free
print('PASS: raw enumeration of all 38024 nonzero residues verifies every layer count.')
print('Fixed prime-3 coefficient per pattern sign: -8886; unrestricted count: 1472.')
print('A: fixed -234, free bound 144. B: fixed 456, free bound 168, for every j.')
print('Nonconstant pattern contradiction: 7200 > 6336.')
print('Constant pattern contradiction: 35544 > 5888 (actual residual bound 2912).')
