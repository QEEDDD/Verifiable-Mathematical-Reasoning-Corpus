#!/usr/bin/env python3
"""Standalone, standard-library-only checker of the q=38025 exclusion.

Rebuilds the integer shadow matrix directly from its defining formula, then
checks eight separating inequalities using only integers.  The stored matrix
is checked against the rebuilt matrix; it is never trusted as input to proof.
Run: python check_exact_38025.py [certificate.json]
"""
from fractions import Fraction
from itertools import product
from math import gcd, prod
from pathlib import Path
import json
import sys


def factor(n):
    ans = {}
    p = 2
    while p * p <= n:
        while n % p == 0:
            ans[p] = ans.get(p, 0) + 1
            n //= p
        p += 1
    if n > 1:
        ans[n] = ans.get(n, 0) + 1
    return ans


def valuation(n, p):
    v = 0
    while n % p == 0:
        n //= p
        v += 1
    return v


def rebuild(q):
    factors = factor(q)
    primes = sorted(factors)
    divisors = sorted(prod(p**e for p, e in zip(primes, es))
                      for es in product(*(range(factors[p] + 1) for p in primes)))
    layers = [d for d in divisors if d > 1]
    orders = {p: 2 ** valuation(p - 1, 2) for p in primes}
    roots = {}
    logs = {}
    for p in primes:
        root = next(g for g in range(2, p)
                    if len({pow(g, j, p) for j in range(p - 1)}) == p - 1)
        roots[p] = root
        logs[p] = {pow(root, j, p): j % orders[p] for j in range(p - 1)}
    support = {d: [p for p in primes if d % p == 0] for d in layers}
    labels = [(d, x) for d in layers
              for x in product(*(range(orders[p]) for p in support[d]))]
    sizes = [prod((p - 1) * p ** (valuation(d, p) - 1) for p in support[d])
             // prod(orders[p] for p in support[d]) for d, x in labels]
    rows, row_labels = [], []
    # Coefficient of a source variable in each mixed-difference functional.
    # This uses direct coefficient evaluation, without the supplied shadow code.
    for m in layers:
        if any(m % (p * p) == 0 for p in primes):
            continue
        mp = support[m]
        for k in product(*(range(1, orders[p]) for p in mp)):
            row = []
            for d, x in labels:
                if d % m:
                    row.append(0)
                    continue
                dp = support[d]
                c = prod(p - 1 for p in primes if d % p)
                extra = [p for p in dp if m % p]
                coordinate = dict(zip(dp, x))
                coefficient = 0
                for bits in product((0, 1), repeat=len(extra)):
                    weight = c * prod(-1 if bit else p for p, bit in zip(extra, bits))
                    for p, kp in zip(mp, k):
                        shift = sum(logs[p][r % p] for r, bit in zip(extra, bits) if bit)
                        z = (coordinate[p] - shift) % orders[p]
                        weight *= int(z == kp) - int(z == 0)
                    coefficient += weight
                row.append(coefficient)
            if any(row):
                rows.append(row)
                row_labels.append(['character', m, list(k)])
    for p in primes:
        rows.append([(p - 1) * (factors[p] - valuation(d, p)) - int(d % p == 0)
                     for d, x in labels])
        row_labels.append(['prime', p])
    rows.append([1] * len(labels))
    row_labels.append(['mean'])
    return rows, labels, sizes, orders, roots, row_labels


def main():
    path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).with_name('exact_no_counterexample_38025.json')
    record = json.loads(path.read_text())
    q = record['q']
    assert q == 38025 and factor(q) == {3: 2, 5: 2, 13: 2}
    matrix, labels, sizes, orders, roots, row_labels = rebuild(q)
    assert matrix == record['matrix'], 'Stored matrix differs from defining formula'
    assert [[d, list(x)] for d, x in labels] == record['column_labels']
    assert sizes == record['fiber_sizes']
    assert {str(p): v for p, v in orders.items()} == record['orders']
    assert {str(p): v for p, v in roots.items()} == record['primitive_roots']
    assert len(matrix) == record['rows'] == 35
    assert len(labels) == record['columns'] == 404
    # Exact arithmetic checks underlying the forcing and unit-pattern lemmas.
    R = prod(Fraction(p, p - 1) for p in factor(q))
    agreeing_mass = (R * (1 - Fraction(1, q)) - 2) / 2
    assert R == Fraction(65, 32)
    assert agreeing_mass == Fraction(1, 64) - Fraction(1, 37440)
    forced_m = [m for m in range(2, 64) if all(p in factor(q) for p in factor(m))]
    assert forced_m == [3, 5, 9, 13, 15, 25, 27, 39, 45]
    assert all(Fraction(1, m) > agreeing_mass for m in forced_m)
    forced_g = sorted({1} | {gcd(q, m) for m in forced_m})
    assert forced_g == record['forced_gcd_layers'] == [1, 3, 5, 9, 13, 15, 25, 39, 45]
    assert q // 9 == 4225 and gcd(3, q // 9) == 1
    assert pow(3, 3, 13) == 1 and 3 % 13 != 1
    assert {1, 3, 9} == {pow(2, e, 13) for e in (0, 4, 8)}
    fixed = [i for i, (d, x) in enumerate(labels) if q // d in forced_g]
    free = [i for i, (d, x) in enumerate(labels) if q // d not in forced_g]
    assert len(fixed) == record['fixed_columns'] == 232
    assert len(free) == record['free_columns'] == 172
    assert sum(sizes[i] for i in free) == 1472
    assert sum(sizes[i] for i in fixed) == 36552
    expected_patterns = {(1,) + tail for tail in product((-1, 1), repeat=3)}
    certificates = record['certificates']
    assert len(certificates) == 8
    assert {tuple(c['unit_pattern']) for c in certificates} == expected_patterns
    print('Reconstructed 35 x 404 integer matrix; 232 fixed and 172 free fibre sums.')
    print('Forcing mass =', agreeing_mass, '; all nine required multipliers forced.')
    for cert in certificates:
        pattern = cert['unit_pattern']
        fixed_value = {}
        for i in fixed:
            d, x = labels[i]
            primes_d = [p for p in sorted(factor(q)) if d % p == 0]
            assert 13 in primes_d
            j = x[primes_d.index(13)]
            fixed_value[i] = (1 if d == q else -1) * sizes[i] * pattern[j]
        b = [-sum(row[i] * fixed_value[i] for i in fixed) for row in matrix]
        y = cert['integer_row_multiplier']
        assert len(y) == len(matrix) and all(type(v) is int for v in y)
        lhs = sum(u * v for u, v in zip(y, b))
        support = sum(sizes[i] * abs(sum(y[r] * matrix[r][i] for r in range(len(matrix))))
                      for i in free)
        assert lhs == cert['left'] and support == cert['box_support']
        assert lhs - support == cert['strict_gap'] > 0
        print(f'{pattern}: {lhs} > {support}; exact gap {lhs - support}')
    print('PASS: every possible normalized unit pattern has an exact separating certificate.')
    print('Consequently no Erdős function modulo 38025 has L(1,f)=0, under Okada\'s criterion.')


if __name__ == '__main__':
    main()
