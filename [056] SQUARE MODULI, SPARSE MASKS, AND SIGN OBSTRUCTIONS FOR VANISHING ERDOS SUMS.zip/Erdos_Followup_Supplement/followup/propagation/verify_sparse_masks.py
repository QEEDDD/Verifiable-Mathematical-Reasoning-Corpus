"""Independent exact verifier for sparse zero-harmonic sign masks.

Only Python's standard library is required.  The input is a compact divisor-layer
table; no solver, floating-point computation, or shadow equations are used.
Run: python verify_sparse_masks.py mask_11025_hole_49.json --save-values
"""
import argparse
from collections import Counter
from fractions import Fraction
from math import gcd
from pathlib import Path
import json
import time


def factor(n):
    ans = {}
    p = 2
    while p * p <= n:
        while n % p == 0:
            ans[p] = ans.get(p, 0) + 1
            n //= p
        p += 1
    if n > 1:
        ans[n] = 1
    return ans


def expand(data):
    q = data['q']
    sizes = {int(p): s for p, s in data['quotient_sizes'].items()}
    logs = {}
    for p0, g in data['primitive_roots'].items():
        p = int(p0)
        x = 1
        logs[p] = {}
        for e in range(p - 1):
            assert x not in logs[p]
            logs[p][x] = e % sizes[p]
            x = x * g % p
        assert len(logs[p]) == p - 1 and x == 1
    tables = {int(d): s for d, s in data['layer_signs'].items()}
    values = [0] * q
    for n in range(1, q):
        common = gcd(n, q)
        d = q // common
        if d not in tables:
            continue
        x = n // common
        index = 0
        expected_size = 1
        for p in sorted(logs):
            if d % p == 0:
                index = index * sizes[p] + logs[p][x % p]
                expected_size *= sizes[p]
        assert len(tables[d]) == expected_size
        values[n] = {'+': 1, '-': -1}[tables[d][index]]
    return values


def resolvent(values, p):
    """Solve T(a)=values[a]+T(pa)/p exactly on its functional graph."""
    q = len(values)
    out = [None] * q
    for a in range(q):
        if out[a] is not None:
            continue
        path, position = [], {}
        n = a
        while out[n] is None and n not in position:
            position[n] = len(path)
            path.append(n)
            n = p * n % q
        if out[n] is None:
            start = position[n]
            cycle = path[start:]
            numerator = Fraction(0)
            for node in cycle:
                numerator = p * numerator + values[node]
            out[cycle[0]] = p * numerator / (p ** len(cycle) - 1)
            current = out[cycle[0]]
            for node in reversed(cycle[1:]):
                current = values[node] + current / p
                out[node] = current
            path = path[:start]
        for node in reversed(path):
            out[node] = values[node] + out[p * node % q] / p
    assert all(out[a] - out[p * a % q] / p == values[a] for a in range(q))
    return out


def verify(data, values):
    begun = time.perf_counter()
    q, hole = data['q'], data['hole']
    assert len(values) == q and q % hole == 0
    support_ok = all(v == 0 if a % hole == 0 else v in (-1, 1)
                     for a, v in enumerate(values))
    assert support_ok
    assert sum(values) == 0
    factors = factor(q)
    smooth = list(map(Fraction, values))
    for p in factors:
        smooth = resolvent(smooth, p)
    units = [a for a in range(1, q) if gcd(a, q) == 1]
    failed = [a for a in units if smooth[a] != 0]
    prime_residuals = {}
    for p, e in factors.items():
        total = 0
        for a in range(1, q):
            b, v = a, 0
            while b % p == 0:
                b //= p
                v += 1
            coefficient = (p - 1) * v if v < e else (p - 1) * e + 1
            total += coefficient * values[a]
        prime_residuals[p] = total
    assert not failed and not any(prime_residuals.values())
    return {'q': q, 'zeros_exactly_multiples_of': hole,
            'period_sum': sum(values), 'value_counts': dict(Counter(values)),
            'unit_equations_checked': len(units),
            'nonzero_unit_equations': len(failed),
            'prime_residuals': prime_residuals,
            'verified_sparse_zero_harmonic_mask': True,
            'elapsed_seconds': time.perf_counter() - begun}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('certificate', type=Path)
    parser.add_argument('--save-values', action='store_true')
    args = parser.parse_args()
    data = json.loads(args.certificate.read_text())
    values = expand(data)
    result = verify(data, values)
    args.certificate.with_suffix('.verification.json').write_text(
        json.dumps(result, indent=2) + '\n')
    if args.save_values:
        args.certificate.with_suffix('.values.json').write_text(json.dumps(values))
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
