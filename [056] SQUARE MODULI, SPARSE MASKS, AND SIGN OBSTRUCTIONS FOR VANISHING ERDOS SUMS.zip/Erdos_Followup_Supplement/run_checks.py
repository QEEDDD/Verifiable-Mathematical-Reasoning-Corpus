"""Reproduce the exact finite certificates in the distributed supplement.

Run from any directory: python run_checks.py
Optional additional algebra audits: python run_checks.py --algebra
"""
from pathlib import Path
import argparse
import importlib.util
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from verify_q11025_full import verify


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    obj = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(obj)
    return obj


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--algebra', action='store_true')
    args = parser.parse_args()
    results = {'seeds': [], 'masks': [], 'checks': []}
    for path in sorted((ROOT/'data').glob('seed_*.json')):
        result = verify(json.loads(path.read_text()))
        assert result['verified_counterexample'], path
        results['seeds'].append(result)
        print('PASS seed', result['q'], flush=True)
    folder = ROOT/'followup/propagation'
    mask = module(folder/'verify_sparse_masks.py', 'mask_checker')
    for q, hole in [(11025,49),(11025,25),(99225,81),(27225,121),(245025,81)]:
        path = folder/f'mask_{q}_hole_{hole}.json'
        data = json.loads(path.read_text())
        values = mask.expand(data)
        assert values == json.loads(path.with_suffix('.values.json').read_text())
        result = mask.verify(data, values)
        results['masks'].append(result)
        print('PASS sparse mask', q, hole, flush=True)
    checks = ['followup/nonsymmetric_195/check_analytic_38025.py',
              'followup/nonsymmetric_195/check_exact_38025.py',
              'followup/character_constructions/audit_38025_short.py',
              'followup/new_principles/verify_ell_example.py',
              'followup/new_principles/verify_ell_example64.py']
    if args.algebra:
        checks += ['followup/audit_global_elimination.py',
                   'followup/audit_exponent_collapse.py',
                   'followup/new_principles/audit_38025_independent.py']
    for script in checks:
        completed = subprocess.run([sys.executable, str(ROOT/script)],
                                   cwd=ROOT, text=True, capture_output=True)
        if completed.returncode:
            print(completed.stdout, completed.stderr)
            raise SystemExit(completed.returncode)
        results['checks'].append({'script': script, 'passed': True,
                                  'output': completed.stdout})
        print('PASS', script, flush=True)
    (ROOT/'verification_results.json').write_text(json.dumps(results, indent=2)+'\n')
    print('All requested exact checks passed.', flush=True)


if __name__ == '__main__':
    main()
