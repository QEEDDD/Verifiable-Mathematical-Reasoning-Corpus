"""Independent exact full-residue Okada verifier (no orbit projection).

Input JSON may have values_1_through_q (indices 1,...,q), values_0_through_q_minus_1,
or be an unadorned list indexed 0,...,q-1. All algebra uses Fraction.
"""
from fractions import Fraction
from math import gcd
from collections import Counter
from time import perf_counter
from pathlib import Path
import argparse
import hashlib
import json


def factor(n):
    ans = {}
    p = 2
    while p * p <= n:
        while n % p == 0:
            ans[p] = ans.get(p, 0) + 1
            n //= p
        p += 1
    if n > 1:
        ans[n] = 1
    return ans


def resolvent(values, p):
    """Return exact T(a)=sum_{j>=0} values[p**j*a mod q]/p**j.

    Solve T(a)=values[a]+T(p*a mod q)/p along the complete functional graph.
    For each cycle, geometric summation gives one exact value; the remaining
    cycle values and all incoming trees follow by backward substitution.
    """
    q = len(values)
    out = [None] * q
    cycle_lengths = Counter()
    for a in range(q):
        if out[a] is not None:
            continue
        path, pos = [], {}
        n = a
        while out[n] is None and n not in pos:
            pos[n] = len(path)
            path.append(n)
            n = p * n % q
        if out[n] is None:
            start = pos[n]
            cycle = path[start:]
            size = len(cycle)
            cycle_lengths[size] += 1
            # Horner form for sum values[cycle[j]]*p**(size-j).
            numerator = Fraction(0)
            for node in cycle:
                numerator = p * numerator + values[node]
            first = p * numerator / (p ** size - 1)
            out[cycle[0]] = first
            current = first
            for node in reversed(cycle[1:]):
                current = values[node] + current / p
                out[node] = current
            path = path[:start]
        for node in reversed(path):
            out[node] = values[node] + out[p * node % q] / p
    # Independent local recurrence check at EVERY residue.
    assert all(out[a] - out[p * a % q] / p == values[a] for a in range(q))
    return out, dict(sorted(cycle_lengths.items()))


def verify(values):
    begun = perf_counter()
    q = len(values)
    assert q > 1
    assert all(type(x) is int for x in values)
    factors = factor(q)
    domain_ok = values[0] == 0 and all(x in (-1, 1) for x in values[1:])
    mean = sum(values)
    result = {
        'q': q,
        'factorization': factors,
        'domain_exactly_plus_minus_one_off_zero': domain_ok,
        'value_at_zero': values[0],
        'period_sum': mean,
        'value_counts': dict(Counter(values)),
        'canonical_index_0_vector_sha256': hashlib.sha256(
            json.dumps(values, separators=(',', ':')).encode()).hexdigest(),
    }
    if not domain_ok or mean != 0:
        result['verified_counterexample'] = False
        result['stopped_before_Okada'] = True
        return result
    smooth = list(map(Fraction, values))
    cycles = {}
    for p in factors:
        smooth, cycles[p] = resolvent(smooth, p)
    units = [a for a in range(1, q) if gcd(a, q) == 1]
    failed = [(a, str(smooth[a])) for a in units if smooth[a] != 0]
    valuation_residuals = {}
    for p, alpha in factors.items():
        s = 0
        for a in range(1, q):
            n, v = a, 0
            while n % p == 0:
                n //= p
                v += 1
            coefficient = ((p - 1) * v if v < alpha
                           else (p - 1) * alpha + 1)
            s += coefficient * values[a]
        valuation_residuals[p] = s
    result.update({
        'smooth_equations_checked': len(units),
        'smooth_equations_nonzero': len(failed),
        'first_nonzero_smooth_residuals': failed[:10],
        'prime_valuation_equations_checked': len(factors),
        'prime_valuation_integer_residuals': valuation_residuals,
        'functional_graph_cycle_lengths': cycles,
        'verified_counterexample': not failed and not any(valuation_residuals.values()),
        'elapsed_seconds': perf_counter() - begun,
        'method': 'Full-residue functional-graph resolvents; exact Fraction arithmetic; every recurrence rechecked',
    })
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('input', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    data = json.loads(args.input.read_text())
    if isinstance(data, list):
        values = data
    elif 'values_1_through_q' in data:
        old = data['values_1_through_q']
        values = [old[-1]] + old[:-1]
    else:
        values = data['values_0_through_q_minus_1']
    result = verify(values)
    if args.output:
        args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
