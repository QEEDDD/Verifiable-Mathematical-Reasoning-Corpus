Supplementary material for
  "Erdos's conjecture on sum f(n)/n holds for every non-square modulus"   (Keio, 24 October 2026)

The theorems of the paper are proved by hand; nothing here is needed for the proofs.
The scripts below CORROBORATE the proofs (Section 7 of the paper).

Requirements: Python 3 (tested 3.13) with sympy and python-flint (0.9).
Run everything from the code/ directory, e.g.  cd code && python3 lemmaB_numeric.py

code/
  agg.py            Support-aggregated version of the 2-power-character part of Okada's system
                    (depends only on rad(q), O = {p: v_p(q) odd}, E1 = {p: v_p(q) = 1}); decides
                    existence of odd 2-integral solutions by 2-saturation of an exact kernel basis.
                    `python3 agg.py 105 675 11025` prints the decision for given q.
  subsys.py         The conductor-p subsystem of Section 3 with arbitrary prescribed layer parities.
                    `python3 subsys.py SEED TRIALS` runs random tests: with the bottom layer odd the
                    system (conditions (A) for p | conductor, plus the log condition at p) is always
                    obstructed; with the bottom layer even, or without the log condition, never.
  lemmaB_numeric.py Exact-rational test of Lemmas 4.2-4.3 (elementary solutions satisfy all conditions;
                    Gamma_0 is 2-integral and == Psi_0 mod 2) for nine prime configurations.
  span_check.py     Rank check that bottom layer + nu-solutions + telescoping pairs span the solution
                    space of the conditions Gamma_J in N(X_J), J nonempty (Remark 4.4).
  radsweep.py       All squarefree radicals r in a range, all subsets O (E1 empty) and O=E1=all.
                    `python3 radsweep.py 15 1500 1200 ../logs/radsweep_15_1500.txt`
  radsweep_list.py  Products of 4 and 5 primes from a pool (many-prime radicals).
  validate2.py      Aggregated decision vs. "q is not a square" for all odd composite q <= 13105,
                    and vs. the full shadow system of the companion paper for q <= 1200.
  bigshadow.py      Full shadow system of the companion paper ([Kei26, Thm 4.5]) for large moduli.
  parity_patterns.py  Sharpness (Theorem 5.2): for each q, the F_2-space of layer parity patterns of
                    2-integral solutions of the full Okada system (all q-1 unknowns) vs. the space
                    {c : sum_j c_{p^j} even for all p}.  `python3 parity_patterns.py 15 105 275`
  companion/        shadow.py, twoadic.py, core.py from the companion paper's supplement (used by
                    validate2.py and bigshadow.py only).

logs/   outputs of the runs reported in Section 7 of the paper.
independent_review/  code and logs written by an independent checker from the paper's definitions
                     and from Okada's original equations (see its own README if present).
paper/  LaTeX source of the paper.
