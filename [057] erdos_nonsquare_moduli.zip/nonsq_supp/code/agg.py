"""Aggregated (support-level) 2-shadow system.

For q = prod p^{e_p}, the 2-adic obstruction depends only on
  primes = rad(q),  O = {p : e_p odd},  E1 = {p : e_p = 1}  (E1 subset of O).
Unknowns: Psi_P : Q_P -> Z_(2) for every nonempty P subset primes, with
  Psi_P == n_P = prod_{p in P} e_p  (mod 2), i.e. odd iff P subset O;
plus integers z_p for p not in E1.
Equations:
  (A) for every nonempty M: the M-primitive part of
      H_M = sum_{P >= M} c_P prod_{p in P\\M} (p - T_p) pi_{P->M} Psi_P   vanishes,
      c_P = prod_{p notin P} (p-1);
  (C) sum_P S_P = 0                       (S_P = sum_y Psi_P(y));
  (B1) p in E1:      sum_{P ni p} S_P = 0;
  (B2) p notin E1:   sum_{P ni p} S_P = 2^{t_p+1} z_p.
"""
import sys
from itertools import product, combinations
import flint
import sympy

HERE = __file__.rsplit('/', 1)[0]
sys.path.insert(0, HERE)


def v2(n):
    k = 0
    while n % 2 == 0:
        n //= 2
        k += 1
    return k


def dlog_table(p):
    g = int(sympy.primitive_root(p))
    tab = {}
    x = 1
    for e in range(p - 1):
        tab[x] = e
        x = x * g % p
    return tab


class Agg:
    def __init__(self, primes, O, E1):
        self.primes = sorted(primes)
        self.O = set(O)
        self.E1 = set(E1)
        assert self.E1 <= self.O <= set(self.primes)
        self.t = {p: v2(p - 1) for p in self.primes}
        self.dl = {p: dlog_table(p) for p in self.primes}
        k = len(self.primes)
        self.supports = []
        for r in range(1, k + 1):
            for c in combinations(self.primes, r):
                self.supports.append(c)
        self.var = {}
        for P in self.supports:
            for x in product(*[range(2 ** self.t[p]) for p in P]):
                self.var[(P, x)] = len(self.var)
        self.npsi = len(self.var)
        self.zvar = {}
        for p in self.primes:
            if p not in self.E1:
                self.zvar[p] = self.npsi + len(self.zvar)
        self.nv = self.npsi + len(self.zvar)

    def image(self, n, pr):
        return tuple(self.dl[p][n % p] % (2 ** self.t[p]) for p in pr)

    def target_bits(self):
        b = 0
        for (P, x), vi in self.var.items():
            if set(P) <= self.O:
                b |= 1 << vi
        return b

    def rows(self):
        rows = []
        primes = self.primes
        for M in self.supports:
            sizes = [2 ** self.t[p] for p in M]
            QM = list(product(*[range(s) for s in sizes]))
            H = {y: {} for y in QM}
            for P in self.supports:
                if not set(M) <= set(P):
                    continue
                c = 1
                for p in primes:
                    if p not in P:
                        c *= (p - 1)
                S = [p for p in P if p not in M]
                shifts = {p: self.image(p, M) for p in S}
                idx = [P.index(p) for p in M]
                for mask in range(1 << len(S)):
                    coef = c * (-1) ** bin(mask).count("1")
                    sh = [0] * len(M)
                    for i, p in enumerate(S):
                        if mask >> i & 1:
                            sh = [(a + b) % s for a, b, s in zip(sh, shifts[p], sizes)]
                        else:
                            coef *= p
                    for x in product(*[range(2 ** self.t[p]) for p in P]):
                        vi = self.var[(P, x)]
                        z = tuple(x[i] for i in idx)
                        y = tuple((a - b) % s for a, b, s in zip(z, sh, sizes))
                        H[y][vi] = H[y].get(vi, 0) + coef
            w = len(M)
            for ks in product(*[range(1, s) for s in sizes]):
                row = {}
                for eps in range(1 << w):
                    y = tuple(0 if (eps >> i & 1) else ks[i] for i in range(w))
                    sgn = (-1) ** bin(eps).count("1")
                    for vi, cf in H[y].items():
                        row[vi] = row.get(vi, 0) + sgn * cf
                row = {kk: v for kk, v in row.items() if v}
                if row:
                    rows.append(row)
        # (C)
        rows.append({vi: 1 for vi in self.var.values()})
        # (B1)/(B2)
        for p in primes:
            row = {vi: 1 for (P, x), vi in self.var.items() if p in P}
            if p not in self.E1:
                row[self.zvar[p]] = -(2 ** (self.t[p] + 1))
            rows.append(row)
        return rows


def to_bits(col):
    b = 0
    for i, x in enumerate(col):
        if x & 1:
            b |= 1 << i
    return b


def saturate2(cols):
    cols = [list(c) for c in cols]
    while True:
        for c in cols:
            while c and any(c) and all(x % 2 == 0 for x in c):
                for i in range(len(c)):
                    c[i] //= 2
        piv = {}
        dep = None
        for j, c in enumerate(cols):
            b = to_bits(c)
            combo = 1 << j
            while b:
                h = b.bit_length() - 1
                if h in piv:
                    pb, pc = piv[h]
                    b ^= pb
                    combo ^= pc
                else:
                    piv[h] = (b, combo)
                    break
            if b == 0:
                dep = combo
                break
        if dep is None:
            return cols
        idx = [j for j in range(len(cols)) if dep >> j & 1]
        n = len(cols[0])
        s = [sum(cols[j][i] for j in idx) for i in range(n)]
        assert all(x % 2 == 0 for x in s)
        cols[idx[-1]] = [x // 2 for x in s]


def span_contains(vecs, target):
    piv = {}
    for b in vecs:
        while b:
            h = b.bit_length() - 1
            if h in piv:
                b ^= piv[h]
            else:
                piv[h] = b
                break
    b = target
    while b:
        h = b.bit_length() - 1
        if h in piv:
            b ^= piv[h]
        else:
            return False
    return True


def agg_test(primes, O, E1, return_system=False):
    """Return True if OBSTRUCTED (no odd solution)."""
    A = Agg(primes, O, E1)
    rows = A.rows()
    n = A.nv
    M = flint.fmpz_mat(len(rows), n, [r.get(j, 0) for r in rows for j in range(n)])
    K, nul = M.nullspace()
    cols = [[int(K[i, j]) for i in range(n)] for j in range(nul)]
    target = A.target_bits()
    if not cols:
        ob = target != 0
    else:
        sat = saturate2(cols)
        mask = (1 << A.npsi) - 1
        proj = [to_bits(c) & mask for c in sat]
        ob = not span_contains(proj, target)
    if return_system:
        return ob, A, rows
    return ob


def types_of(q):
    f = sympy.factorint(q)
    primes = sorted(f)
    O = [p for p in primes if f[p] % 2]
    E1 = [p for p in primes if f[p] == 1]
    return primes, O, E1


if __name__ == "__main__":
    for a in sys.argv[1:]:
        q = int(a)
        pr, O, E1 = types_of(q)
        print(q, pr, "O=", O, "E1=", E1, "OB" if agg_test(pr, O, E1) else "no-ob", flush=True)
