import sys, time
sys.path.insert(0, __file__.rsplit('/', 1)[0] + '/companion')
import sympy
from math import isqrt
import shadow
qs = [int(a) for a in sys.argv[1:]]
for q in qs:
    t0 = time.time()
    ob, dim, n = shadow.shadow_test(q)
    sq = isqrt(q) ** 2 == q
    print(q, dict(sympy.factorint(q)), "square" if sq else "non-square",
          "OBSTRUCTED" if ob else "no-obstruction", "nvars", n,
          "consistent" if ob != sq else "INCONSISTENT", f"{time.time()-t0:.1f}s", flush=True)
