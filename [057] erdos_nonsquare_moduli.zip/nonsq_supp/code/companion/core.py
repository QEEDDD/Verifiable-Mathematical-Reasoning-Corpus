"""Exact layered criterion for Erdos's conjecture on L(1,f) != 0.

Notation (q odd).  Residues n = 1..q-1.  Layer of n: d = q/gcd(n,q) (>1),
n = (q/d) x with x in U_d = (Z/d)^*.  Variables b_n in {0,1}, f(n) = 1 - 2 b_n.

L(1,f) = 0  <=>  (A_f) for every f | q, f > 1:  H_f has no primitive component mod f,
                 (B_p) for every p | q:  sum_n f(n) eps_p(n) = 0,
                 (C)   sum_n f(n) = 0,
where  H_f = sum_{f | d | q} c(d) prod_{p in S(d,f)} (p - M_p) pi_{d->f} g_d  (g = f or b),
       c(d) = prod_{p | q, p not| d} (p-1),  S(d,f) = {p | d, p not| f},
       (M_p h)(y) = h(p y),  (pi h)(z) = sum_{x in U_d, x = z mod f} h(x),
       eps_p(n) = v_p(gcd(n,q)) - [v_p(gcd(n,q)) < v_p(q)]/(p-1).
(Equivalent to Okada's criterion / Bharadwaj's Theorem 4; constants drop out of (A_f).)
"""
from math import gcd
from fractions import Fraction
import sympy


def fac(n):
    return dict(sympy.factorint(n))


def divs(n):
    return sorted(int(d) for d in sympy.divisors(n))


def units(m):
    if m == 1:
        return [0]
    return [x for x in range(1, m) if gcd(x, m) == 1]


def vp(n, p):
    if n == 0:
        return 10 ** 9
    k = 0
    while n % p == 0:
        n //= p
        k += 1
    return k


def crt_pair(a, m, b, n):
    # x = a mod m, x = b mod n, gcd(m,n)=1
    t = ((b - a) * pow(m, -1, n)) % n
    return (a + m * t) % (m * n)


def H_forms(q, P=None):
    """Return dict f -> dict y -> {n: coef} (integer linear forms in g_n)."""
    if P is None:
        P = fac(q)
    primes = sorted(P)
    D = [d for d in divs(q) if d > 1]
    out = {}
    for f in D:
        Uf = units(f)
        Hf = {y: {} for y in Uf}
        for d in D:
            if d % f:
                continue
            c = 1
            for p in primes:
                if d % p:
                    c *= (p - 1)
            S = [p for p in primes if d % p == 0 and f % p != 0]
            g = q // d
            fib = {z: [] for z in Uf}
            for x in units(d):
                fib[x % f].append(x)
            for mask in range(1 << len(S)):
                mT = 1
                coefT = c * (-1) ** bin(mask).count("1")
                for i, p in enumerate(S):
                    if mask >> i & 1:
                        mT *= p
                    else:
                        coefT *= p
                for y in Uf:
                    z = (mT * y) % f
                    row = Hf[y]
                    for x in fib[z]:
                        n = g * x
                        row[n] = row.get(n, 0) + coefT
        for y in Uf:
            Hf[y] = {n: v for n, v in Hf[y].items() if v}
        out[f] = Hf
    return out


def primitive_functionals(f):
    """List of functionals on functions of U_f, each a list of (y, sign) with
    2^omega(f) terms; together they cut out exactly the primitive part
    (count = number of primitive characters mod f)."""
    P = fac(f)
    comps = []  # per prime: list of (k, base(k)) for non-base k
    mods = []
    for p, e in sorted(P.items()):
        m = p ** e
        U = units(m)
        if e == 1:
            base = {k: 1 for k in U}
        else:
            mm = p ** (e - 1)
            fibers = {}
            for k in U:
                fibers.setdefault(k % mm, []).append(k)
            base = {}
            for key, lst in fibers.items():
                b0 = min(lst)
                for k in lst:
                    base[k] = b0
        comps.append([(k, base[k]) for k in U if base[k] != k])
        mods.append(m)
    funcs = []

    def rec(i, cur):
        if i == len(comps):
            funcs.append(list(cur))
            return
        for pair in comps[i]:
            cur.append(pair)
            rec(i + 1, cur)
            cur.pop()

    rec(0, [])
    res = []
    w = len(mods)
    for tup in funcs:
        terms = []
        for eps in range(1 << w):
            y, M = 0, 1
            sign = 1
            for i in range(w):
                k, b0 = tup[i]
                val = b0 if (eps >> i & 1) else k
                if eps >> i & 1:
                    sign = -sign
                y = crt_pair(y, M, val, mods[i]) if M > 1 else val % mods[i]
                M *= mods[i]
            terms.append((y, sign))
        res.append(terms)
    return res


def system(q):
    """Return (rows, rhs_b, rhs_f, labels): integer equations sum_n row[n]*x_n = rhs.
    rhs_b: right-hand side when x = b (0/1 variables);
    rhs_f: right-hand side when x = f (rational function values)."""
    P = fac(q)
    H = H_forms(q, P)
    rows, rb, rf, lab = [], [], [], []
    for f, Hf in H.items():
        for fn in primitive_functionals(f):
            row = {}
            for y, s in fn:
                for n, v in Hf[y].items():
                    row[n] = row.get(n, 0) + s * v
            row = {n: v for n, v in row.items() if v}
            rows.append(row)
            rb.append(0)
            rf.append(0)
            lab.append(("A", f))
    for p, e in sorted(P.items()):
        row = {}
        for n in range(1, q):
            v = min(vp(n, p), e)
            w = (p - 1) * v - (1 if v < e else 0)
            if w:
                row[n] = w
        tot = sum(row.values())
        rows.append(row)
        rf.append(0)
        # sum w (1-2b) = 0  ->  sum w b = tot/2
        rb.append(Fraction(tot, 2))
        lab.append(("B", p))
    rows.append({n: 1 for n in range(1, q)})
    rf.append(0)
    rb.append(Fraction(q - 1, 2))
    lab.append(("C", 1))
    return rows, rb, rf, lab


def L1_numeric(q, fvals, dps=40):
    import mpmath
    mpmath.mp.dps = dps
    s = mpmath.mpf(0)
    for a in range(1, q):
        if fvals[a]:
            s += fvals[a] * mpmath.digamma(mpmath.mpf(a) / q)
    return -s / q
