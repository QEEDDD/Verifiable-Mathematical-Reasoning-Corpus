"""2-shadow of the Erdos/Okada system.

Push every layer function forward to the maximal 2-power quotient
Q_d = prod_{p|d} C_{2^{t_p}},  t_p = v_2(p-1)  (via discrete logs mod p).
An Erdos function (all values odd) maps to a shadow vector with all entries odd
(fibres have odd size); conversely a shadow solution with odd entries lifts.
So: 2-adic obstruction for q  <=>  all-ones not in (2-saturated shadow kernel mod 2).
"""
import sys
from itertools import product
import flint
import sympy
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from twoadic import saturate2, in_span


def v2(n):
    k = 0
    while n % 2 == 0:
        n //= 2
        k += 1
    return k


def dlog_table(p):
    g = int(sympy.primitive_root(p))
    tab = {}
    x = 1
    for e in range(p - 1):
        tab[x] = e
        x = x * g % p
    return tab


class Shadow:
    def __init__(self, q):
        self.q = q
        P = dict(sympy.factorint(q))
        self.P = P
        self.primes = sorted(P)
        self.t = {p: v2(p - 1) for p in self.primes}
        self.dl = {p: dlog_table(p) for p in self.primes}
        self.layers = [int(d) for d in sympy.divisors(q) if d > 1]
        # variables
        self.var = {}
        for d in self.layers:
            pr = [p for p in self.primes if d % p == 0]
            for x in product(*[range(2 ** self.t[p]) for p in pr]):
                self.var[(d, x)] = len(self.var)
        self.nv = len(self.var)

    def rad_primes(self, d):
        return [p for p in self.primes if d % p == 0]

    def image(self, n, pr):
        """image of integer n (coprime to the primes pr) in Q_{prod pr}"""
        return tuple(self.dl[p][n % p] % (2 ** self.t[p]) for p in pr)

    def rows(self):
        rows = []
        q = self.q
        primes = self.primes
        sqfree = [f for f in self.layers if all(f % (p * p) for p in primes)]
        for f in sqfree:
            fp = self.rad_primes(f)
            sizes = [2 ** self.t[p] for p in fp]
            Qf = list(product(*[range(s) for s in sizes]))
            # H_f(y) as linear form over variables
            H = {y: {} for y in Qf}
            for d in self.layers:
                if d % f:
                    continue
                dp = self.rad_primes(d)
                c = 1
                for p in primes:
                    if d % p:
                        c *= (p - 1)
                S = [p for p in dp if f % p]
                shifts = {p: self.image(p, fp) for p in S}
                idx = [dp.index(p) for p in fp]
                for mask in range(1 << len(S)):
                    coef = c * (-1) ** bin(mask).count("1")
                    sh = [0] * len(fp)
                    for i, p in enumerate(S):
                        if mask >> i & 1:
                            sh = [(a + b) % s for a, b, s in zip(sh, shifts[p], sizes)]
                        else:
                            coef *= p
                    # (M_m pi phi_d)(y) = (pi phi_d)(y + sh) ; pi sums over coords not in fp
                    for (dd, x), vi in self.var.items():
                        if dd != d:
                            continue
                        z = tuple(x[i] for i in idx)  # image in Q_f
                        y = tuple((a - b) % s for a, b, s in zip(z, sh, sizes))
                        H[y][vi] = H[y].get(vi, 0) + coef
            # primitive functionals
            nonzero = [range(1, s) for s in sizes]
            w = len(fp)
            for ks in product(*nonzero):
                row = {}
                for eps in range(1 << w):
                    y = tuple(0 if (eps >> i & 1) else ks[i] for i in range(w))
                    sgn = (-1) ** bin(eps).count("1")
                    for vi, cf in H[y].items():
                        row[vi] = row.get(vi, 0) + sgn * cf
                row = {k: v for k, v in row.items() if v}
                if row:
                    rows.append(row)
        # (B_p)
        for p, e in sorted(self.P.items()):
            row = {}
            for (d, x), vi in self.var.items():
                vd = 0
                dd = d
                while dd % p == 0:
                    dd //= p
                    vd += 1
                w_ = (p - 1) * (e - vd) - (1 if vd > 0 else 0)
                if w_:
                    row[vi] = w_
            rows.append(row)
        # (C)
        rows.append({vi: 1 for vi in self.var.values()})
        return rows


def shadow_test(q):
    S = Shadow(q)
    rows = S.rows()
    n = S.nv
    M = flint.fmpz_mat(len(rows), n, [r.get(j, 0) for r in rows for j in range(n)])
    K, nul = M.nullspace()
    cols = [[int(K[i, j]) for i in range(n)] for j in range(nul)]
    if not cols:
        return True, 0, n
    sat, piv = saturate2(cols)
    ones = (1 << n) - 1
    return (not in_span(piv, ones)), len(piv), n


if __name__ == "__main__":
    for a in sys.argv[1:]:
        q = int(a)
        ob, dim, n = shadow_test(q)
        print(q, q % 4, dict(sympy.factorint(q)), "OBSTRUCTED" if ob else "no-obstruction", "nvars", n, flush=True)
