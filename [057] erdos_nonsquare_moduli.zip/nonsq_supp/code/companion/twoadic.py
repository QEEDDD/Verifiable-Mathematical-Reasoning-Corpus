"""2-adic (parity) obstruction test.

An Erdos function f (f(n)=+-1, n=1..q-1) with L(1,f)=0 is a vector of the
integer kernel lattice K = {x in Z^{q-1}: Mx = 0} with every coordinate odd.
So if the all-ones vector is not in (K tensor Z_(2)) mod 2, Erdos holds for q.
We compute the 2-saturation of a rational kernel basis and test membership.
Returns (obstructed, dim_mod2)."""
import sys
import flint
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from core import system


def kernel_basis(q):
    rows, rb, rf, lab = system(q)
    n = q - 1
    M = flint.fmpz_mat(len(rows), n, [row.get(j + 1, 0) for row in rows for j in range(n)])
    K, nul = M.nullspace()
    cols = [[int(K[i, j]) for i in range(n)] for j in range(nul)]
    return cols, n


def to_bits(col):
    b = 0
    for i, x in enumerate(col):
        if x & 1:
            b |= 1 << i
    return b


def saturate2(cols):
    """Return list of integer columns spanning (span_Q cols) cap Z_(2)^n, with
    reductions mod 2 linearly independent."""
    cols = [list(c) for c in cols]
    from math import gcd
    while True:
        # remove common factors of 2 in each column
        for c in cols:
            while c and all(x % 2 == 0 for x in c) and any(c):
                for i in range(len(c)):
                    c[i] //= 2
        # gaussian elimination mod 2 tracking combinations
        piv = {}  # pivot bit -> (bits, combo)
        dep = None
        for j, c in enumerate(cols):
            b = to_bits(c)
            combo = 1 << j
            while b:
                h = b.bit_length() - 1
                if h in piv:
                    pb, pc = piv[h]
                    b ^= pb
                    combo ^= pc
                else:
                    piv[h] = (b, combo)
                    break
            if b == 0:
                dep = combo
                break
        if dep is None:
            return cols, piv
        idx = [j for j in range(len(cols)) if dep >> j & 1]
        n = len(cols[0])
        s = [sum(cols[j][i] for j in idx) for i in range(n)]
        assert all(x % 2 == 0 for x in s)
        cols[idx[-1]] = [x // 2 for x in s]


def in_span(piv, target):
    b = target
    while b:
        h = b.bit_length() - 1
        if h in piv:
            b ^= piv[h][0]
        else:
            return False
    return True


def test(q):
    cols, n = kernel_basis(q)
    if not cols:
        return True, 0
    sat, piv = saturate2(cols)
    ones = (1 << n) - 1
    return (not in_span(piv, ones)), len(piv)


if __name__ == "__main__":
    for a in sys.argv[1:]:
        q = int(a)
        ob, dim = test(q)
        print(q, q % 4, "OBSTRUCTED" if ob else "no-2adic-obstruction", dim, flush=True)
