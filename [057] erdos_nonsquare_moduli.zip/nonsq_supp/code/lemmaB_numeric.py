"""Direct numerical check of the peeling lemma (Lemma B) with the actual operators.

Build random integral constant-parity solutions of the J != {} conditions of the
p-subsystem from elementary pieces, verify the conditions hold exactly (rational
arithmetic), and verify Gamma_0 is integral and == Psi_0 (mod 2).  Also verify that
elementary pieces + bottom layer span the full solution space (dimension count).
"""
import sys, random
from fractions import Fraction as Fr
from itertools import product, combinations
import flint
HERE = __file__.rsplit('/', 1)[0]
sys.path.insert(0, HERE)
from agg import v2, dlog_table
from subsys import build


class Sys:
    def __init__(self, primes, p):
        self.primes = sorted(primes); self.p = p
        self.t = {r: v2(r - 1) for r in self.primes}
        self.dl = {r: dlog_table(r) for r in self.primes}
        self.W = [r for r in self.primes if r != p]
        self.Ls = [c for k in range(len(self.W) + 1) for c in combinations(self.W, k)]

    def coords(self, L):  # ordered coordinates of X_L
        return (self.p,) + tuple(L)

    def pts(self, L):
        return list(product(*[range(2 ** self.t[r]) for r in self.coords(L)]))

    def img(self, r, L):  # image of prime r in X_L
        return tuple(self.dl[s][r % s] % (2 ** self.t[s]) for s in self.coords(L))

    def E(self, r, L, F):  # (r - tau_r)/(r-1) on functions on X_L, (tau F)(x)=F(x+h)
        h = self.img(r, L); sz = [2 ** self.t[s] for s in self.coords(L)]
        out = {}
        for x in F:
            xh = tuple((a + b) % s for a, b, s in zip(x, h, sz))
            out[x] = (r * F[x] - F[xh]) / Fr(r - 1)
        return out

    def R(self, r, L, F):
        u = Fr(2 ** self.t[r], r - 1)
        return {x: v * (r - 1) * u for x, v in self.E(r, L, F).items()}

    def proj(self, L, J, F):  # sum over coordinates in L\J
        cL = self.coords(L); cJ = self.coords(J)
        idx = [cL.index(s) for s in cJ]
        out = {y: Fr(0) for y in self.pts(J)}
        for x, v in F.items():
            out[tuple(x[i] for i in idx)] += v
        return out

    def Gamma(self, Psi, J):
        tot = {y: Fr(0) for y in self.pts(J)}
        for L in self.Ls:
            if not set(J) <= set(L):
                continue
            F = self.proj(L, J, Psi[L])
            for r in L:
                if r not in J:
                    F = self.E(r, J, F)
            for y in tot:
                tot[y] += F[y]
        return tot

    def in_N(self, J, F):
        """no fully primitive part: prod_i (1 - eps_i) F == 0 with eps_i = set coord i to 0"""
        c = self.coords(J); k = len(c)
        G = dict(F)
        for i in range(k):
            H = {}
            for x, v in G.items():
                x0 = list(x); x0[i] = 0
                H[x] = v - G[tuple(x0)]
            G = H
        return all(v == 0 for v in G.values())


def random_solution(S, rng):
    """Superpose random elementary pieces with constant parity; return Psi."""
    Psi = {L: {x: Fr(0) for x in S.pts(L)} for L in S.Ls}
    # bottom layer arbitrary
    for x in Psi[()]:
        Psi[()][x] = Fr(rng.randrange(-5, 6))
    for L in S.Ls:
        if not L:
            continue
        cL = S.coords(L)
        # nu-piece: function of Q_L only (independent of p coordinate), constant parity
        par = rng.randint(0, 1)
        vals = {}
        for x in S.pts(L):
            key = x[1:]
            if key not in vals:
                vals[key] = par + 2 * rng.randrange(-3, 4)
            Psi[L][x] += vals[key]
        # omega-pieces for each i in L
        for i in L:
            Li = tuple(r for r in L if r != i)
            par = rng.randint(0, 1)
            om = {y: Fr(par + 2 * rng.randrange(-3, 4)) for y in S.pts(Li)}
            ci = cL.index(i)
            cLi = S.coords(Li)
            for x in S.pts(L):
                y = tuple(x[cL.index(s)] for s in cLi)
                Psi[L][x] += om[y]
            Rom = S.R(i, Li, om)
            for y in S.pts(Li):
                Psi[Li][y] -= Rom[y]
    return Psi


def check(primes, p, trials, rng):
    S = Sys(primes, p)
    for _ in range(trials):
        Psi = random_solution(S, rng)
        # constant parity in each layer? (holds by construction mod 2 sums)
        for L in S.Ls:
            assert all(v.denominator % 2 == 1 for v in Psi[L].values()), "Psi not 2-integral"
            pars = {v.numerator % 2 for v in Psi[L].values()}
            assert len(pars) == 1 or not L, "layer parity not constant"
        for J in S.Ls:
            if J:
                assert S.in_N(J, S.Gamma(Psi, J)), ("condition fails", J)
        G0 = S.Gamma(Psi, ())
        for y in G0:
            assert G0[y].denominator % 2 == 1, "Gamma_0 not 2-integral"
            d = G0[y] - Psi[()][y]
            assert d.numerator % 2 == 0, "parity transfer fails"
    return True


def dimcount(primes, p):
    """dim of solution space of J != {} conditions vs. (bottom + elementary pieces)."""
    supports, var, npsi, nv, rows = build(primes, p, use_Ap=False, use_B2=False)
    M = flint.fmpq_mat(len(rows), npsi, [r.get(j, 0) for r in rows for j in range(npsi)])
    rank = M.rank()
    return npsi - rank


if __name__ == "__main__":
    rng = random.Random(7)
    cases = [([3, 5], 3), ([3, 5], 5), ([3, 7, 11], 7), ([5, 13, 17], 5), ([3, 5, 7], 5),
             ([3, 5, 7, 11], 3), ([3, 5, 13], 13), ([7, 11, 19, 23], 11), ([5, 41], 41)]
    for primes, p in cases:
        check(primes, p, 3, rng)
        print("ok", primes, p, "solution-space dim", dimcount(primes, p), flush=True)
