"""Which layer-constant parity patterns c (one bit per layer d|q, d>1) occur for 2-integral
Okada vectors?  Theorem C says: sum_{j=1}^{e_p} c_{p^j} = 0 for every p.  Test whether this
is also sufficient (V == V*), using the full Okada system of the companion paper (core.py)."""
import sys
sys.path.insert(0, __file__.rsplit('/', 1)[0] + '/companion')
import sympy
from twoadic import kernel_basis, saturate2, to_bits

def f2_rank(vecs):
    piv = {}
    r = 0
    for b in vecs:
        while b:
            h = b.bit_length() - 1
            if h in piv:
                b ^= piv[h]
            else:
                piv[h] = b; r += 1; break
    return r, piv

def reduce(piv, b):
    """full (canonical) reduction modulo the span of pivots with distinct leading bits"""
    for h in sorted(piv, reverse=True):
        if (b >> h) & 1:
            b ^= piv[h]
    return b

def test(q):
    cols, n = kernel_basis(q)
    sat, piv = saturate2(cols)
    Vbar = [to_bits(c) for c in sat]  # independent mod 2
    rk, P = f2_rank(Vbar)
    layers = [d for d in sympy.divisors(q) if d > 1]
    # layer indicator vectors in F_2^{q-1}: coordinate n-1 for n=1..q-1, layer d: gcd(n,q)=q/d
    ind = {}
    for d in layers:
        b = 0
        for nn in range(1, q):
            if sympy.gcd(nn, q) == q // d:
                b |= 1 << (nn - 1)
        ind[d] = b
    # V = {c in F_2^D : sum c_d ind_d in Vbar}; compute by brute-force linear algebra:
    # find all c with combination in span(Vbar): solve via elimination on augmented system
    D = len(layers)
    # Represent the map c -> sum c_d ind_d reduced modulo span(Vbar); kernel of that linear map = V
    imgs = [reduce(P, ind[d]) for d in layers]
    # kernel of linear map F_2^D -> F_2^{q-1}, c -> sum c_d imgs[d]
    # gaussian elimination tracking combinations
    piv2 = {}
    kernel = []
    for j, v in enumerate(imgs):
        combo = 1 << j
        b = v
        while b:
            h = b.bit_length() - 1
            if h in piv2:
                pb, pc = piv2[h]; b ^= pb; combo ^= pc
            else:
                piv2[h] = (b, combo); break
        if b == 0:
            kernel.append(combo)
    dimV = len(kernel)
    f = sympy.factorint(q)
    dimVstar = D - len(f)
    # check V subset of V*: each kernel vector satisfies sum_j c_{p^j} = 0
    ok_nec = True
    for c in kernel:
        for p, e in f.items():
            s = 0
            for j in range(1, e + 1):
                s ^= (c >> layers.index(p ** j)) & 1
            if s:
                ok_nec = False
    return D, dimV, dimVstar, ok_nec

if __name__ == "__main__":
    for a in sys.argv[1:]:
        q = int(a)
        D, dV, dVs, ok = test(q)
        print(q, dict(sympy.factorint(q)), "layers", D, "dim V", dV, "dim V*", dVs,
              "V subset V*" if ok else "VIOLATION", "EQUAL" if (ok and dV == dVs) else "proper", flush=True)
