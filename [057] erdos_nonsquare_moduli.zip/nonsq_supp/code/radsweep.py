"""For every odd squarefree r in [lo,hi] with >=2 prime factors and system size <= cap,
and every subset O of primes(r): decide the aggregated system with E1 = {} (all odd
exponents >= 3, the weakest constraints) and, for O = all primes, also E1 = O.
Prediction (Main Theorem): obstructed iff O nonempty."""
import sys, time
from itertools import combinations
import sympy
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from agg import agg_test, v2
lo, hi, cap = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])
out = open(sys.argv[4], 'w')
n = bad = 0
t0 = time.time()
for r in range(lo, hi + 1, 2):
    f = sympy.factorint(r)
    if len(f) < 2 or any(e > 1 for e in f.values()):
        continue
    primes = sorted(f)
    size = 1
    for p in primes:
        size *= 1 + 2 ** v2(p - 1)
    if size - 1 > cap:
        out.write(f"{r} SKIP size {size-1}\n"); continue
    for k in range(0, len(primes) + 1):
        for O in combinations(primes, k):
            ob = agg_test(primes, O, [])
            ok = (ob == (len(O) > 0))
            n += 1; bad += (not ok)
            out.write(f"{r} O={list(O)} E1=[] {'OB' if ob else 'no-ob'} {'ok' if ok else 'MISMATCH'}\n")
    ob = agg_test(primes, primes, primes)
    ok = ob; n += 1; bad += (not ok)
    out.write(f"{r} O=all E1=all {'OB' if ob else 'no-ob'} {'ok' if ok else 'MISMATCH'}\n")
    out.flush()
out.write(f"DONE cases {n} mismatches {bad} time {time.time()-t0:.0f}s\n")
out.close()
print("cases", n, "mismatches", bad)
