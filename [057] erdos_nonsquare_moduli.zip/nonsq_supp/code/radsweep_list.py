"""Radical sweep over products of k distinct primes from a pool (many-prime cases)."""
import sys, time
from itertools import combinations
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from agg import agg_test, v2
pool = [int(x) for x in sys.argv[1].split(',')]
ks = [int(x) for x in sys.argv[2].split(',')]
cap = int(sys.argv[3]); out = open(sys.argv[4], 'w')
n = bad = skipped = 0; t0 = time.time()
for k in ks:
    for primes in combinations(pool, k):
        size = 1
        for p in primes:
            size *= 1 + 2 ** v2(p - 1)
        if size - 1 > cap:
            skipped += 1; continue
        r = 1
        for p in primes:
            r *= p
        # all O subsets would be 2^k; test O = each single prime, O = all, and O = {} (E1 = {})
        Os = [()] + [(p,) for p in primes] + [tuple(primes)]
        for O in Os:
            ob = agg_test(list(primes), O, [])
            ok = (ob == (len(O) > 0)); n += 1; bad += (not ok)
            out.write(f"{r} {list(primes)} O={list(O)} E1=[] {'OB' if ob else 'no-ob'} {'ok' if ok else 'MISMATCH'}\n")
        ob = agg_test(list(primes), primes, primes); n += 1; bad += (not ob)
        out.write(f"{r} {list(primes)} O=all E1=all {'OB' if ob else 'no-ob'} {'ok' if ob else 'MISMATCH'}\n")
        out.flush()
out.write(f"DONE cases {n} mismatches {bad} skipped {skipped} time {time.time()-t0:.0f}s\n"); out.close()
print("cases", n, "mismatches", bad, "skipped", skipped)
