"""Check that bottom layer + nu-pieces + omega-pieces span the full solution space
of the J != {} conditions (so the peeling argument's decomposition is exhaustive)."""
import sys
from fractions import Fraction as Fr
import flint
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from lemmaB_numeric import Sys
from subsys import build


def vectors(S):
    order = [(L, x) for L in S.Ls for x in S.pts(L)]
    index = {k: i for i, k in enumerate(order)}
    vecs = []
    def blank():
        return {L: {x: Fr(0) for x in S.pts(L)} for L in S.Ls}
    for y in S.pts(()):
        Psi = blank(); Psi[()][y] = Fr(1); vecs.append(Psi)
    for L in S.Ls:
        if not L:
            continue
        cL = S.coords(L)
        # nu pieces: delta in the Q_L coordinates, constant in p
        seen = set()
        for x in S.pts(L):
            key = x[1:]
            if key in seen:
                continue
            seen.add(key)
            Psi = blank()
            for x2 in S.pts(L):
                if x2[1:] == key:
                    Psi[L][x2] = Fr(1)
            vecs.append(Psi)
        for i in L:
            Li = tuple(r for r in L if r != i)
            cLi = S.coords(Li)
            for y0 in S.pts(Li):
                om = {y: Fr(1 if y == y0 else 0) for y in S.pts(Li)}
                Psi = blank()
                for x in S.pts(L):
                    y = tuple(x[cL.index(s)] for s in cLi)
                    Psi[L][x] += om[y]
                Rom = S.R(i, Li, om)
                for y in S.pts(Li):
                    Psi[Li][y] -= Rom[y]
                vecs.append(Psi)
    mat = []
    for Psi in vecs:
        row = [Fr(0)] * len(order)
        for L in S.Ls:
            for x, v in Psi[L].items():
                row[index[(L, x)]] = v
        mat.append(row)
    return mat, order


if __name__ == "__main__":
    cases = [([3, 5], 3), ([3, 5], 5), ([3, 7, 11], 7), ([3, 5, 7], 5), ([3, 5, 13], 13),
             ([3, 5, 7, 11], 3), ([5, 41], 41), ([7, 11, 19, 23], 11)]
    for primes, p in cases:
        S = Sys(primes, p)
        mat, order = vectors(S)
        n = len(order)
        M = flint.fmpq_mat(len(mat), n, [flint.fmpq(v.numerator, v.denominator) for r in mat for v in r])
        r_span = M.rank()
        supports, var, npsi, nv, rows = build(primes, p, use_Ap=False, use_B2=False)
        A = flint.fmpq_mat(len(rows), npsi, [r.get(j, 0) for r in rows for j in range(npsi)])
        dim_sol = npsi - A.rank()
        assert npsi == n
        print(primes, p, "span rank", r_span, "solution dim", dim_sol, "OK" if r_span == dim_sol else "MISMATCH", flush=True)
