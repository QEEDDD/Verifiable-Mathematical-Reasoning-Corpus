"""Test of the parity-transfer mechanism on the p-subsystem.

Unknowns: Psi_P for P containing p (functions on Q_P), plus z (for B2_p).
Conditions: (A_M) for all M containing p [optionally without M={p}],
            optionally (B2_p): sum_{P ni p} S_P = 2^{t_p+1} z.
Parities: arbitrary prescribed constant parity n_P for each layer.
Prediction (Lemma B + A_{p} + B2_p): obstructed whenever n_{p} = 1.
"""
import sys, random
from itertools import product, combinations
import flint
HERE = __file__.rsplit('/', 1)[0]
sys.path.insert(0, HERE)
from agg import v2, dlog_table, saturate2, to_bits, span_contains


def build(primes, p, use_Ap=True, use_B2=True):
    primes = sorted(primes)
    t = {r: v2(r - 1) for r in primes}
    dl = {r: dlog_table(r) for r in primes}
    others = [r for r in primes if r != p]
    supports = []
    for k in range(0, len(others) + 1):
        for c in combinations(others, k):
            supports.append(tuple(sorted((p,) + c)))
    var = {}
    for P in supports:
        for x in product(*[range(2 ** t[r]) for r in P]):
            var[(P, x)] = len(var)
    npsi = len(var)
    nv = npsi + (1 if use_B2 else 0)

    def image(n, pr):
        return tuple(dl[r][n % r] % (2 ** t[r]) for r in pr)

    rows = []
    for M in supports:
        if M == (p,) and not use_Ap:
            continue
        sizes = [2 ** t[r] for r in M]
        QM = list(product(*[range(s) for s in sizes]))
        H = {y: {} for y in QM}
        for P in supports:
            if not set(M) <= set(P):
                continue
            c = 1
            for r in primes:
                if r not in P:
                    c *= (r - 1)
            S = [r for r in P if r not in M]
            shifts = {r: image(r, M) for r in S}
            idx = [P.index(r) for r in M]
            for mask in range(1 << len(S)):
                coef = c * (-1) ** bin(mask).count("1")
                sh = [0] * len(M)
                for i, r in enumerate(S):
                    if mask >> i & 1:
                        sh = [(a + b) % s for a, b, s in zip(sh, shifts[r], sizes)]
                    else:
                        coef *= r
                for x in product(*[range(2 ** t[r]) for r in P]):
                    vi = var[(P, x)]
                    z = tuple(x[i] for i in idx)
                    y = tuple((a - b) % s for a, b, s in zip(z, sh, sizes))
                    H[y][vi] = H[y].get(vi, 0) + coef
        w = len(M)
        for ks in product(*[range(1, s) for s in sizes]):
            row = {}
            for eps in range(1 << w):
                y = tuple(0 if (eps >> i & 1) else ks[i] for i in range(w))
                sgn = (-1) ** bin(eps).count("1")
                for vi, cf in H[y].items():
                    row[vi] = row.get(vi, 0) + sgn * cf
            row = {kk: v for kk, v in row.items() if v}
            if row:
                rows.append(row)
    if use_B2:
        row = {vi: 1 for vi in range(npsi)}
        row[npsi] = -(2 ** (t[p] + 1))
        rows.append(row)
    return supports, var, npsi, nv, rows


def lattice_mod2(rows, nv, npsi):
    M = flint.fmpz_mat(len(rows), nv, [r.get(j, 0) for r in rows for j in range(nv)])
    K, nul = M.nullspace()
    cols = [[int(K[i, j]) for i in range(nv)] for j in range(nul)]
    if not cols:
        return []
    sat = saturate2(cols)
    mask = (1 << npsi) - 1
    return [to_bits(c) & mask for c in sat]


def test(primes, p, parity, use_Ap=True, use_B2=True):
    supports, var, npsi, nv, rows = build(primes, p, use_Ap, use_B2)
    proj = lattice_mod2(rows, nv, npsi)
    target = 0
    for (P, x), vi in var.items():
        if parity[P]:
            target |= 1 << vi
    return not span_contains(proj, target)  # True = obstructed


if __name__ == "__main__":
    random.seed(int(sys.argv[1]) if len(sys.argv) > 1 else 1)
    import sympy
    pool = [r for r in sympy.primerange(3, 120)]
    results = {"pred_ok": 0, "pred_fail": 0, "n0_obstructed": 0, "n0_free": 0,
               "noB2_obstructed": 0, "noB2_free": 0}
    fails = []
    for trial in range(int(sys.argv[2]) if len(sys.argv) > 2 else 40):
        k = random.choice([2, 2, 3, 3, 3, 4])
        primes = sorted(random.sample(pool, k))
        # keep size moderate
        size = 1
        for r in primes:
            size *= (1 + 2 ** v2(r - 1))
        if size > 3000:
            continue
        p = random.choice(primes)
        supports, _, _, _, _ = build(primes, p, True, True)
        par = {P: random.randint(0, 1) for P in supports}
        par[(p,)] = 1
        ob = test(primes, p, par)
        if ob:
            results["pred_ok"] += 1
        else:
            results["pred_fail"] += 1
            fails.append((primes, p, par))
        par0 = dict(par); par0[(p,)] = 0
        if test(primes, p, par0):
            results["n0_obstructed"] += 1
        else:
            results["n0_free"] += 1
        if test(primes, p, par, use_B2=False):
            results["noB2_obstructed"] += 1
        else:
            results["noB2_free"] += 1
    print(results)
    print("fails:", fails[:5])
