import sys, time
sys.path.insert(0, __file__.rsplit('/', 1)[0])
sys.path.insert(1, __file__.rsplit('/', 1)[0] + '/companion')
import sympy
from math import isqrt
from agg import agg_test, types_of
import shadow
lim_full = int(sys.argv[1]); lim_agg = int(sys.argv[2]); out = open(sys.argv[3], 'w')
cache = {}; t0 = time.time(); bad = []; n = nfull = 0
for q in range(9, lim_agg + 1, 2):
    if sympy.isprime(q):
        continue
    pr, O, E1 = types_of(q)
    key = (tuple(pr), tuple(O), tuple(E1))
    if key not in cache:
        cache[key] = agg_test(pr, O, E1)
    ob = cache[key]
    sq = isqrt(q) ** 2 == q
    line = f"{q} agg={'OB' if ob else 'no'} square={sq}"
    if ob == sq:
        bad.append(('agg-vs-square', q)); line += " MISMATCH-square"
    if q <= lim_full:
        ob2, _, _ = shadow.shadow_test(q); nfull += 1
        line += f" shadow={'OB' if ob2 else 'no'}"
        if ob2 != ob:
            bad.append(('agg-vs-shadow', q)); line += " MISMATCH-shadow"
    n += 1
    out.write(line + "\n"); out.flush()
out.write(f"DONE checked {n} moduli (full-shadow compared {nfull}); type classes {len(cache)}; time {time.time()-t0:.0f}s; disagreements {bad}\n")
out.close()
