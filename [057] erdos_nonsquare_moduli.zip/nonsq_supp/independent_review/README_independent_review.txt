Independent check (written by a separate agent from the statements of the paper and from Okada's
original 1982 equations; it shares no code with ../code).

  tools.py, subsystem.py, layer_parity.py : core implementations
    - Okada's original system in all q-1 unknowns (unit equations with geometric tails, prime equations,
      convergence), exact over Q (FLINT); 2-saturation and a second, dual 2-adic echelon method.
    - the conductor-p subsystem of Section 3 built directly from the definitions (own kappa, own
      translations), elementary solutions of Lemma 4.2, telescoping lemma checks.
  run_*.py : drivers;  log_*.txt : their outputs.
    log_b_small.txt / log_b_main.txt : rank phi+omega, numerics, odd vectors exist exactly for squares
                                       among 20 moduli <= 375; Theorems 5.1 and 5.2 on the mod-2 space.
    log_a_first.txt / log_a_rest.txt : Lemmas 4.2-4.3 and spanning in 10 configurations (p, W).
    log_prop32_*.txt                 : Prop 3.2 and Lemma 2.4 on exact solutions (12 moduli, all p),
                                       with a reversed-translation control that fails as it should.
    log_example15.txt                : q = 15 example showing the constant-parity hypothesis is needed.
    log_pointwise.txt, log_misc.txt, log_anysol.txt, log_pm1_all.txt, log_kei105.txt, log_kei165.txt :
                                       remarks of Section 6 and the inputs cited from the companion paper.
All scripts are self-contained (the companion paper's tables are re-typed inside run_kei105.py and
run_kei165.py); PARI/GP is needed for the numerical L(1,f) checks.
