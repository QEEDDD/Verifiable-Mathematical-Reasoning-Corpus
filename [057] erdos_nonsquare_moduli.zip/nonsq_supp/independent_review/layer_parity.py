"""Layer-parity analysis on the reduction mod 2 of the saturated Okada lattice.
bar(Lambda) = {x in F2^{q-1} : <e,x> = 0 for all e in Ebits}  (Ebits from adic_echelon of
Okada's original equations).
 * Thm 5.2 (sharpness): realizable layer-constant patterns == predicted F2-space.
 * Thm 5.1 (parity transfer) at each p: layers d with p|d constant, all other residues free
   => sum_j c_{p^j} = 0 on every solution."""
from tools import *


def layer_masks(q):
    L = layers(q)
    return {d: sum(1 << (n - 1) for n in ns) for d, ns in L.items()}


def predicted_space(q, ds):
    fac = factor(q)
    idx = {d: k for k, d in enumerate(ds)}
    gens = []
    for d in ds:
        if len(factor(d)) >= 2:
            gens.append(1 << idx[d])
    for p, e in fac.items():
        for i in range(1, e + 1):
            for j in range(i + 1, e + 1):
                gens.append((1 << idx[p**i]) | (1 << idx[p**j]))
    # constraint functionals
    cons = []
    for p, e in fac.items():
        c = 0
        for j in range(1, e + 1):
            c |= 1 << idx[p**j]
        cons.append((p, c))
    return gens, cons


def realizable_space(q, Ebits, masks, ds):
    rows = []
    for e in Ebits:
        r = 0
        for k, d in enumerate(ds):
            if popc(e & masks[d]) & 1:
                r |= 1 << k
        rows.append(r)
    return f2_kernel(rows, len(ds))


def check_sharpness(q, Ebits):
    masks = layer_masks(q)
    ds = list(masks)
    R = realizable_space(q, Ebits, masks, ds)
    gens, cons = predicted_space(q, ds)
    dimR = f2_rank(R)
    dimV = f2_rank(gens)
    gens_ok = all(f2_in_span(g, R) for g in gens)
    cons_ok = all(f2_dot(r, c) == 0 for r in R for (p, c) in cons)
    allones = (1 << len(ds)) - 1
    return {'num_layers': len(ds), 'dim_realizable': dimR, 'dim_predicted': dimV,
            'predicted_gens_realizable': gens_ok, 'constraints_hold_on_realizable': cons_ok,
            'equal': gens_ok and cons_ok and dimR == dimV,
            'all_ones_pattern_realizable': f2_in_span(allones, R)}


def check_transfer(q, Ebits):
    """Thm 5.1 at each p, with only the layers d, p|d, constrained to constant parity."""
    fac = factor(q)
    masks = layer_masks(q)
    ds = list(masks)
    N = q - 1
    res = {}
    for p, e in fac.items():
        pds = [d for d in ds if d % p == 0]
        free_res = [n for d in ds if d % p != 0 for n in layers(q)[d]]
        # unknown vector: first len(pds) coords = c_d, then the free residues
        nvar = len(pds) + len(free_res)
        rows = []
        for E in Ebits:
            r = 0
            for k, d in enumerate(pds):
                if popc(E & masks[d]) & 1:
                    r |= 1 << k
            for k, n in enumerate(free_res):
                if (E >> (n - 1)) & 1:
                    r |= 1 << (len(pds) + k)
            rows.append(r)
        ker = f2_kernel(rows, nvar)
        func = 0
        for j in range(1, e + 1):
            func |= 1 << pds.index(p**j)
        ok = all(f2_dot(x, func) == 0 for x in ker)
        # also: is the constraint the ONLY one on the bottom layers? (dimension of the
        # projection of solutions to the bottom-layer parities)
        proj = []
        for x in ker:
            y = 0
            for j in range(1, e + 1):
                if (x >> pds.index(p**j)) & 1:
                    y |= 1 << (j - 1)
            proj.append(y)
        res[p] = {'e_p': e, 'transfer_holds': ok, 'dim_solutions': len(ker),
                  'dim_bottom_projection': f2_rank(proj), 'expected_bottom_dim': e - 1}
    return res
