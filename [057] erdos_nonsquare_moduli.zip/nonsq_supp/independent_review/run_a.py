"""(a) Checks of Section 3/4 for several (p, W)."""
import sys, random, itertools, time, cmath
from fractions import Fraction
import numpy as np
from subsystem import *
from tools import bit, is2int, f2_kernel

random.seed(2026)


def rand2int(par=None):
    """random element of Z_(2) (odd denominators), with prescribed parity if given."""
    den = random.choice([1, 1, 3, 5, 7, 15])
    num = random.randint(-20, 20)
    x = Fraction(num, den)
    if par is not None and bit(x) != par:
        x += Fraction(1, den) if den % 2 else 1
        x = Fraction(num + 1, den) if bit(Fraction(num + 1, den)) == par else Fraction(num, den)
    return x


def rand_const_parity(shape, par):
    a = F0(shape)
    for idx in itertools.product(*[range(n) for n in shape]):
        while True:
            x = rand2int()
            if bit(x) == par:
                break
        a[idx] = x
    return a


def fft_full_ok(S, J, F):
    """complex check: hat F(chi) = 0 for all full chi (numerical)."""
    sh = F.shape
    Fn = np.array([float(x) for x in F.reshape(-1)]).reshape(sh)
    Fh = np.fft.fftn(Fn)
    mx = 0.0
    for k in itertools.product(*[range(n) for n in sh]):
        if all(kk != 0 for kk in k):
            mx = max(mx, abs(Fh[k]))
    return mx


def run(p, W):
    t0 = time.time()
    S = Subsys(p, W)
    print(f'=== p={p}, W={S.W}, t={S.t}, N={S.N} unknowns, sizes={S.size}')
    print('   h_r^J images:', {(J, r): S.h(J, r) for J in S.subsets for r in S.W if r not in J})
    Crows = S.condition_rows()
    rk = fmpq_rank(Crows)
    dimS = S.N - rk
    nfull = sum(int(np.prod([S.C[s] - 1 for s in (p,) + J])) for J in S.subsets if J)
    print(f'   rank of conditions (ii) = {rk} (number of full characters over J != empty: {nfull}); dim S = {dimS}')
    # FFT cross-check of the exact 'full part' test on random vectors
    for _ in range(2):
        v = [Fraction(random.randint(-9, 9)) for _ in range(S.N)]
        Psi = S.split(v)
        for J in S.subsets:
            if not J:
                continue
            G = S.Gamma(J, Psi)
            ex = S.in_N(G)
            num = fft_full_ok(S, J, G)
            assert ex == (num < 1e-9), (J, ex, num)
    # elementary solutions
    elem = S.elementary_basis()
    bad = 0
    gamma_ok = 0
    vecs = []
    for kind, data, Psi in elem:
        v = S.join(Psi)
        vecs.append(v)
        for row in Crows:
            if sum(a * b for a, b in zip(row, v)) != 0:
                bad += 1
                break
        G0 = S.Gamma((), Psi)
        if kind == 'nu':
            L0 = data[0]
            tot = sum(Psi[L0].reshape(-1))
            exp = tot * Fraction(1, S.C[p])
            gamma_ok += all(x == exp for x in G0.reshape(-1))
        elif kind == 'tp':
            gamma_ok += all(x == 0 for x in G0.reshape(-1))
        else:
            gamma_ok += 1
        # the elementary solutions are in N(X_J) also for J = empty? (Gamma_empty constant)
    rk_el = fmpq_rank(vecs)
    print(f'   elementary solutions: {len(elem)} generators, {bad} violate (ii); '
          f'Gamma_empty as claimed for {gamma_ok}/{len(elem)}; rank of their span = {rk_el}; '
          f'spans S: {rk_el == dimS}')
    # ---- exhaustive 2-adic verification of the telescoping lemma
    ker = fmpq_kernel(Crows, S.N)
    assert len(ker) == dimS
    B = exact_adic_basis(ker)
    assert len(B) == dimS
    g_int = all(all(is2int(x) for x in S.Gamma((), S.split(b)).reshape(-1)) for b in B)
    # U_c: constant parity on each nonempty X_L. Conditions on alpha in F2^m.
    m = len(B)
    Bbits = [[bit(x) for x in b] for b in B]
    conds = []
    for L in S.subsets:
        if not L:
            continue
        o, n = S.off[L], S.size[L]
        for k in range(1, n):
            r = 0
            for s in range(m):
                if Bbits[s][o + k] ^ Bbits[s][o]:
                    r |= 1 << s
            conds.append(r)
    alphas = f2_kernel(conds, m)
    lam_c_ok = True
    for al in alphas:
        w = [Fraction(0)] * S.N
        for s in range(m):
            if (al >> s) & 1:
                w = [x + y for x, y in zip(w, B[s])]
        Psi = S.split(w)
        G0 = S.Gamma((), Psi)
        for y in range(S.C[p]):
            d = G0[y] - Psi[()][y]
            if not (is2int(d) and bit(d) == 0):
                lam_c_ok = False
    # without hypothesis (i): is the congruence false for some 2-integral solution?
    viol = 0
    for b in B:
        Psi = S.split(b)
        G0 = S.Gamma((), Psi)
        if any(bit(G0[y] - Psi[()][y]) for y in range(S.C[p])):
            viol += 1
    print(f'   telescoping lemma, exhaustive on the lattice S∩Z_(2)^N: Gamma_empty(Lambda) 2-integral: {g_int}; '
          f'Gamma_empty ≡ Psi_empty on Lambda_c (dim of constant-parity part mod 2 = {len(alphas)}): {lam_c_ok}; '
          f'basis vectors violating the congruence when (i) is dropped: {viol}/{m}')
    # ---- random constant-parity superpositions of elementary solutions
    ok = 0
    ntr = 5
    for _ in range(ntr):
        Psi = {L: F0(S.shape[L]) for L in S.subsets}
        Psi[()] = np.array([rand2int() for _ in range(S.C[p])], dtype=object)
        for L0 in S.subsets:
            if not L0:
                continue
            sh = S.shape[L0]
            nu0 = rand_const_parity(sh[1:], random.randint(0, 1)) if len(sh) > 1 else None
            nu = np.repeat(np.expand_dims(nu0, 0), sh[0], axis=0)
            P1 = S.nu_solution(L0, nu)
            for L in S.subsets:
                Psi[L] = Psi[L] + P1[L]
            for i in L0:
                K = tuple(r for r in L0 if r != i)
                om = rand_const_parity(S.shape[K], random.randint(0, 1))
                P2 = S.tp_solution(L0, i, om)
                for L in S.subsets:
                    Psi[L] = Psi[L] + P2[L]
        v = S.join(Psi)
        c1 = all(sum(a * b for a, b in zip(row, v)) == 0 for row in Crows)
        c2 = all(len(set(bit(x) for x in Psi[L].reshape(-1))) == 1 for L in S.subsets if L)
        G0 = S.Gamma((), Psi)
        c3 = all(is2int(x) for x in G0.reshape(-1))
        c4 = c3 and all(bit(G0[y]) == bit(Psi[()][y]) for y in range(S.C[p]))
        ok += c1 and c2 and c3 and c4
    print(f'   random constant-parity superpositions: {ok}/{ntr} satisfy (ii), have constant parity, '
          f'Gamma_empty 2-integral and ≡ Psi_empty   [{time.time()-t0:.1f}s]', flush=True)
    return S


if __name__ == '__main__':
    configs = [(3, [5, 7]), (5, [3, 7]), (7, [3, 5, 11]), (13, [3, 5]), (3, [5, 17]),
               (17, [3, 5]), (5, [3, 41]), (3, [5, 7, 11]), (3, [7]), (5, [13])]
    if len(sys.argv) > 1:
        configs = [configs[int(k)] for k in sys.argv[1:]]
    for p, W in configs:
        run(p, W)
