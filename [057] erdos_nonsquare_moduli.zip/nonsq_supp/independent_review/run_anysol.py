"""Does Gamma_empty ≡ Psi_empty (mod 2) hold for ALL 2-integral Okada solutions (no parity
hypothesis)?  Checked on a Z_(2)-basis of the saturated Okada lattice (suffices by linearity)."""
import sys
from fractions import Fraction
from tools import *
from subsystem import Subsys, exact_adic_basis
from run_okada import exact_kernel
from run_prop32 import pushforwards, aggregate

for q in [int(x) for x in sys.argv[1:]]:
    rows, _ = okada_rows(q)
    ker = exact_kernel(integerize(rows), q - 1)
    B = exact_adic_basis([[Fraction(x) for x in k] for k in ker])
    fac = factor(q)
    out = {}
    for p in fac:
        S = Subsys(p, [r for r in fac if r != p])
        nbad = 0; nnonconst = 0
        for b in B:
            f = {n: b[n - 1] for n in range(1, q)}
            Psi = aggregate(S, pushforwards(q, f, S))
            G0 = S.Gamma((), Psi).reshape(-1)
            P0 = Psi[()].reshape(-1)
            assert all(is2int(x) for x in G0)
            if any(bit(g - x) for g, x in zip(G0, P0)):
                nbad += 1
            if len(set(bit(x) for x in P0)) > 1:
                nnonconst += 1
        out[p] = f'{nbad}/{len(B)} basis vectors violate Gamma_0 ≡ Psi_0; {nnonconst} have non-constant-parity Psi_0'
    print(q, out, flush=True)
