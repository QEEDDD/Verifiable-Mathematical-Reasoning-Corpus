import sys
from run_okada import analyse
from layer_parity import check_sharpness, check_transfer
qs = [int(x) for x in sys.argv[1:]]
for q in qs:
    out, Ebits = analyse(q, verbose=False, do_M1=True, do_num=True)
    print(out, flush=True)
    print('  sharpness:', check_sharpness(q, Ebits), flush=True)
    print('  transfer :', check_transfer(q, Ebits), flush=True)
