from fractions import Fraction
import flint
from tools import *
from subsystem import Subsys
from run_okada import exact_kernel
from run_prop32 import pushforwards, aggregate
q = 15
rows, _ = okada_rows(q)
ker = exact_kernel(integerize(rows), q - 1)
# integer lattice ker ∩ Z^14 via HNF-saturation: use LLL on kernel basis then saturate by checking
K = flint.fmpz_mat(len(ker), q - 1, [x for k in ker for x in k])
L = K.lll()
S = Subsys(3, [5])
best = None
import itertools
vecs = [[int(L[i, j]) for j in range(q - 1)] for i in range(L.nrows())]
for co in itertools.product(range(-1, 2), repeat=len(vecs)):
    v = [sum(c * w[j] for c, w in zip(co, vecs)) for j in range(q - 1)]
    if not any(v):
        continue
    from math import gcd
    g = 0
    for x in v: g = gcd(g, x)
    v = [x // g for x in v]
    f = {n: Fraction(v[n - 1]) for n in range(1, q)}
    Psi = aggregate(S, pushforwards(q, f, S))
    G0 = S.Gamma((), Psi).reshape(-1); P0 = Psi[()].reshape(-1)
    if any(bit(a - b) for a, b in zip(G0, P0)):
        m = max(abs(x) for x in v)
        if best is None or m < best[0]:
            best = (m, v, list(G0), list(P0))
m, v, G0, P0 = best
print('f(1..14) =', v)
assert all(sum(a * b for a, b in zip(r, v)) == 0 for r in rows)
print('satisfies all of Okada\'s original equations exactly: True')
print('Gamma_empty =', G0, ' Psi_empty = (Phi_3) =', P0)
print('layer parities:', {d: sorted(set(v[n-1] % 2 for n in ns)) for d, ns in layers(q).items()})
