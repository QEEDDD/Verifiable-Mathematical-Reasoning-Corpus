"""Sanity check of the cited input [Kei26, Thm 3.1] (used in Cor. D(2),(3)):
the Erdos function mod 105^2 of Table 1 of the companion, rebuilt from its Legendre-symbol
description; check values +-1, period sum 0, and L(1,f) ~ 0 (digamma formula, PARI/GP)."""
import subprocess
from math import gcd
import sympy

q = 105**2


def leg(x, p):
    return int(sympy.legendre_symbol(x % p, p))


def F(d, x):
    l3 = leg(x, 3) if d % 3 == 0 else None
    l5 = leg(x, 5) if d % 5 == 0 else None
    l7 = leg(x, 7) if d % 7 == 0 else None
    T = {3: lambda: -1, 5: lambda: -l5, 7: lambda: -l7, 9: lambda: -1, 15: lambda: -l3 * l5,
         21: lambda: 1 if l3 == 1 else -l7, 25: lambda: l5, 35: lambda: l5 * l7,
         45: lambda: -1 if l3 == 1 else l5, 49: lambda: -l7, 63: lambda: 1 if l3 == 1 else -l7,
         75: lambda: 1 if l3 == 1 else -l5, 105: lambda: -l7 if l3 == 1 else -1, 147: lambda: l7,
         175: lambda: -l5 * l7, 225: lambda: l3, 245: lambda: l5 * l7, 315: lambda: l5 * l7,
         441: lambda: -l3, 525: lambda: l5 * l7, 735: lambda: l5 * l7, 1225: lambda: l5 * l7,
         1575: lambda: l5 * l7, 2205: lambda: l5 * l7, 3675: lambda: l5 * l7, 11025: lambda: -l5 * l7}
    return T[d]()


f = [0] * q
for n in range(1, q):
    g = gcd(n, q)
    d = q // g
    x = n // g
    f[n] = F(d, x)
assert all(abs(v) == 1 for v in f[1:])
print('values +-1:', True, ' period sum:', sum(f))
vec = ','.join(str(v) for v in f[1:])
gp = f"default(realprecision,60); f=[{vec}]; q={q}; s=-sum(a=1,q-1,f[a]*psi(a/q))/q; print(s); " \
     f"f[1]=-f[1]; f[2]=-f[2]; print(-sum(a=1,q-1,f[a]*psi(a/q))/q)"
out = subprocess.run(['gp', '-q', '-s', '200000000'], input=gp, capture_output=True, text=True)
print('L(1,f) via PARI psi (60 digits):', out.stdout.strip().split('\n')[0])
print('control (f(1),f(2) flipped):     ', out.stdout.strip().split('\n')[-1])
