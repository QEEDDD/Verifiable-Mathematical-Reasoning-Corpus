"""Sanity check of [Kei26, Thm 3.3] (used in Cor. D(3)): the function mod 165^2 of the
companion's Appendix A table, rebuilt from its index encoding."""
import subprocess, itertools
from math import gcd
q = 27225
tab = """3 ++|5 ----|9 ++|11 -+|15 --+++---|25 +-+-|33 +-+-|45 -+---+--|55 +--++--+|75 ++--+-++|99 --++|121 -+|165 +--+----+--+++++|225 -+-++--+|275 -+-+++--|363 ++--|495 -+---+-+-+++-+-+|605 -+-+-+-+|825 -+-+-+-+-+-+-+-+|1089 -+-+|1815 -+-+-+-+-+-+-+-+|2475 -+-+-+-+-+-+-+-+|3025 -+-+-+-+|5445 -+-+-+-+-+-+-+-+|9075 -+-+-+-+-+-+-+-+|27225 +-+-+-+-+-+-+-+-"""
T = {int(s.split()[0]): s.split()[1] for s in tab.split('|')}
def ind2(x, p):
    k, y = 0, 1
    while y != x % p:
        y = y * 2 % p; k += 1
    return k
rng = {3: 2, 5: 4, 11: 2}
f = [0] * q
for n in range(1, q):
    g = gcd(n, q); d = q // g; x = n // g
    ps = [p for p in (3, 5, 11) if d % p == 0]
    coords = [ind2(x, p) % rng[p] for p in ps]
    idx = 0
    for p, c in zip(ps, coords):
        idx = idx * rng[p] + c
    s = T[d]
    assert len(s) == eval('*'.join(str(rng[p]) for p in ps))
    f[n] = 1 if s[idx] == '+' else -1
print('period sum:', sum(f))
vec = ','.join(str(v) for v in f[1:])
gp = f"default(realprecision,60); f=[{vec}]; q={q}; print(-sum(a=1,q-1,f[a]*psi(a/q))/q); f[1]=-f[1]; f[2]=-f[2]; print(-sum(a=1,q-1,f[a]*psi(a/q))/q)"
out = subprocess.run(['gp', '-q', '-s', '400000000'], input=gp, capture_output=True, text=True)
print('L(1,f) [60 digits] and control:', out.stdout.split())
