"""Misc checks of side claims.
 (1) Remark 'value at 0': for odd q, Thm A / Thm 5.1 still hold with f(0) free.
 (2) Abstract: 'conductor-p projection of ANY solution is congruent mod 2 to its bottom layer'
     -> find 2-integral Okada solutions whose bottom layer Psi_empty is not ≡ Gamma_empty.
 (3) Section 6.1 example (N | q, f=0 on N|n, +-1 otherwise) for EVEN q (Cor 6.1 assumes q odd).
 (4) Section 6.4: for N = 2p, Phi_p + (2 - T_2) Phi_{2p} is constant on C_p for Okada solutions."""
import sys, itertools, random
from fractions import Fraction
from math import gcd, lcm
import numpy as np
import flint, sympy, mpmath
from tools import *
from layer_parity import layer_masks

mpmath.mp.dps = 40
random.seed(5)


def lam_bits(q, with_zero):
    rows, _ = okada_rows(q, with_zero=with_zero)
    irows = integerize(rows)
    n = q if with_zero else q - 1
    A = flint.fmpz_mat(len(irows), n, [x for r in irows for x in r])
    rk = A.rank()
    r2, vals, Ebits, _ = adic_echelon(irows, K=256)
    assert r2 == rk
    return Ebits, n


def part1(qs):
    print('(1) value at 0 (unknowns f(0..q-1), bit 0 = f(0)):')
    for q in qs:
        Ebits, n = lam_bits(q, True)
        ones = ((1 << q) - 1) & ~1        # odd on 1..q-1, f(0) even
        ones1 = (1 << q) - 1              # odd on 1..q-1, f(0) odd
        ok0 = all(f2_dot(e, ones) == 0 for e in Ebits)
        ok1 = all(f2_dot(e, ones1) == 0 for e in Ebits)
        print(f'   q={q} ({factor(q)}): odd solution with f(0) even: {ok0}, with f(0) odd: {ok1}')


def part2(q=15):
    Ebits, n = lam_bits(q, False)
    ker = f2_kernel(Ebits, n)
    p = 3
    # bottom layer for p=3 in q=15: d=3 -> residues 5,10 ; is f(5)+f(10) parity free?
    # look for v in bar(Lambda) with bits of f(5), f(10) different (then Psi_empty is not constant mod 2,
    # while Gamma_empty is a constant)
    found = [v for v in ker if ((v >> 4) & 1) != ((v >> 9) & 1)]
    print(f'(2) q={q}, p=3: 2-integral solutions with f(5) and f(10) of different parity exist: {bool(found)}'
          ' (then Psi_empty = (f(5),f(10)) up to kappa is not ≡ the constant Gamma_empty)')


def pm1_with_zeros(q, N):
    """f(n)=0 if N|n, f(n)=+-1 otherwise; sum f = 0 and L(1,f)=0. Exhaustive via Okada."""
    rows, _ = okada_rows(q, with_zero=True)
    forced = [n for n in range(q) if n % N == 0]
    for n in forced:
        r = [Fraction(0)] * q; r[n] = Fraction(1); rows.append(r)
    M = flint.fmpq_mat(len(rows), q, [flint.fmpq(x.numerator, x.denominator) for r in rows for x in r])
    R, rk = M.rref()
    piv = []
    for i in range(rk):
        for j in range(q):
            if R[i, j] != 0:
                piv.append(j); break
    free = [j for j in range(q) if j not in piv]
    if any(j in forced for j in free):
        raise RuntimeError
    D = 1
    for i in range(rk):
        for j in free:
            D = lcm(D, int(R[i, j].q))
    Rp = np.array([[int(R[i, j].p) * (D // int(R[i, j].q)) for j in free] for i in range(rk)], dtype=object)
    nf = len(free)
    piv_forced = [i for i, pc in enumerate(piv) if pc in forced]
    piv_pm = [i for i, pc in enumerate(piv) if pc not in forced]
    sols = []
    if nf > 22:
        return None, nf
    for start in range(0, 1 << nf, 1 << min(nf, 14)):
        idx = np.arange(start, min(start + (1 << min(nf, 14)), 1 << nf))
        X = (((idx[:, None] >> np.arange(nf)) & 1) * 2 - 1).astype(object)
        Y = X.dot(Rp.T)
        ok = np.ones(len(idx), dtype=bool)
        for i in piv_pm:
            ok &= np.array([(y == D) or (y == -D) for y in Y[:, i]])
        for i in piv_forced:
            ok &= np.array([y == 0 for y in Y[:, i]])
        for k in np.nonzero(ok)[0]:
            f = [0] * q
            for t, j in enumerate(free):
                f[j] = int(X[k, t])
            for i, pc in enumerate(piv):
                f[pc] = -int(Y[k, i]) // D
            sols.append(f)
    return sols, nf


def L1(f, q):
    s = mpmath.mpf(0)
    for a in range(1, q + 1):
        if f[a % q]:
            s += f[a % q] * mpmath.digamma(mpmath.mpf(a) / q)
    return -s / q


def part3(qmax=40):
    print('(3) Section 6.1 example for even q: f = 0 on N|n, +-1 otherwise, N | q non-square:')
    for q in range(4, qmax + 1, 2):
        for N in sympy.divisors(q):
            if N == 1 or sympy.sqrt(N).is_integer:
                continue
            if (q - q // N) % 2:
                continue  # sum of an odd number of +-1 cannot vanish
            sols, nf = pm1_with_zeros(q, N)
            if sols is None:
                print(f'   q={q}, N={N}: skipped (free={nf})')
                continue
            if sols:
                f = sols[0]
                print(f'   q={q}, N={N}: {len(sols)} solutions, e.g. f(0..q-1)={f}, |L|={float(abs(L1(f, q))):.1e}')
    print('   (odd q control) q=45,N=15 / q=75,N=15 / q=63, N=21:')
    for q, N in [(45, 15), (75, 15), (63, 21), (27, 3), (45, 5)]:
        sols, nf = pm1_with_zeros(q, N)
        print(f'   q={q}, N={N}: free={nf}, solutions={None if sols is None else len(sols)}')


def part4(ps=(5, 13, 17)):
    print('(4) N=2p: Phi_p + (2 - T_2) Phi_{2p} constant on C_p for Okada solutions (f(0) included):')
    for p in ps:
        N = 2 * p
        rows, _ = okada_rows(N, with_zero=True)
        M = flint.fmpq_mat(len(rows), N, [flint.fmpq(x.numerator, x.denominator) for r in rows for x in r])
        R, rk = M.rref()
        piv = []
        for i in range(rk):
            for j in range(N):
                if R[i, j] != 0:
                    piv.append(j); break
        free = [j for j in range(N) if j not in piv]
        t = v2int(p - 1); C = 1 << t
        g = int(sympy.primitive_root(p))
        ind = {pow(g, k, p): k for k in range(p - 1)}
        kap = lambda x: ind[x % p] % C
        h = kap(2)
        oks = 0
        for _ in range(3):
            f = [Fraction(0)] * N
            for j in free:
                f[j] = Fraction(random.randint(-5, 5))
            for i, pc in enumerate(piv):
                f[pc] = -sum(Fraction(int(R[i, j].p), int(R[i, j].q)) * f[j] for j in free)
            Php = [Fraction(0)] * C; Ph2p = [Fraction(0)] * C
            for x in range(1, p):          # layer p: n = 2x
                Php[kap(x)] += f[2 * x % N]
            for x in range(1, N):          # layer 2p: n = x, gcd(x, 2p) = 1
                if gcd(x, N) == 1:
                    Ph2p[kap(x)] += f[x]
            G = [Php[y] + 2 * Ph2p[y] - Ph2p[(y + h) % C] for y in range(C)]
            oks += len(set(G)) == 1
        print(f'   N={N}: constant in {oks}/3 random solutions')


if __name__ == '__main__':
    part1([15, 21, 27, 45, 75, 105, 135, 9, 25, 225])
    part2()
    part4()
    part3()
