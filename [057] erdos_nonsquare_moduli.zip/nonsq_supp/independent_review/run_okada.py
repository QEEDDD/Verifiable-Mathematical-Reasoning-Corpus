"""(b) Okada's ORIGINAL criterion in all q-1 unknowns: rank, numerics, odd-vector test,
layer-parity analysis (Thm 5.1 parity transfer, Thm 5.2 sharpness)."""
import sys, time, random
from fractions import Fraction
from math import gcd
import flint, mpmath, sympy
from tools import *

mpmath.mp.dps = 60
random.seed(12345)


def exact_kernel(irows, ncols):
    A = flint.fmpz_mat(len(irows), ncols, [x for r in irows for x in r])
    X, nul = A.nullspace()
    ker = [[int(X[i, j]) for i in range(ncols)] for j in range(nul)]
    return ker


def L1_digamma(fvals, q):
    """fvals[n-1] = f(n), n=1..q-1 ; returns -(1/q) sum f(a) psi(a/q)."""
    s = mpmath.mpf(0)
    for a in range(1, q):
        if fvals[a - 1] != 0:
            s += mpmath.mpf(fvals[a - 1]) * mpmath.digamma(mpmath.mpf(a) / q)
    return -s / q


def analyse(q, do_M1=True, do_num=True, nnum=2, K=256, verbose=True):
    t0 = time.time()
    fac = factor(q)
    rows, labels = okada_rows(q)
    irows = integerize(rows)
    N = q - 1
    A = flint.fmpz_mat(len(irows), N, [x for r in irows for x in r])
    rk = A.rank()
    phi = int(sympy.totient(q)); om = len(fac)
    out = {'q': q, 'fac': fac, 'rank': rk, 'expected_rank': phi + om, 'N': N}
    # ---- M2: 2-adic echelon of the equations
    r2, vals, Ebits, _ = adic_echelon(irows, K=K)
    out['M2_rank_found'] = r2
    out['M2_maxval'] = max(vals) if vals else 0
    assert r2 == rk, (q, r2, rk, 'increase K')
    ones = (1 << N) - 1
    odd_M2 = all(f2_dot(e, ones) == 0 for e in Ebits)
    out['odd_vector_M2'] = odd_M2
    lam_dim = N - rk
    # ---- M1: exact kernel basis, 2-saturate, test all-ones
    if do_M1:
        ker = exact_kernel(irows, N)
        assert len(ker) == lam_dim
        # check kernel really solves the Fraction system exactly
        for kv in ker[:3]:
            for r in rows:
                assert sum(x * y for x, y in zip(r, kv)) == 0
        rk1, vals1, Kbits, _ = adic_echelon(ker, K=max(K, 4096))
        assert rk1 == lam_dim, (rk1, lam_dim)
        out['M1_maxval'] = max(vals1) if vals1 else 0
        odd_M1 = f2_in_span(ones, Kbits)
        out['odd_vector_M1'] = odd_M1
        # both descriptions of bar(Lambda) must agree: Kbits orthogonal to Ebits, dims add up
        agree = all(f2_dot(e, k) == 0 for e in Ebits for k in Kbits) and \
            f2_rank(Kbits) == lam_dim and f2_rank(Ebits) == rk
        out['M1_M2_same_space'] = agree
        # ---- numerics
        if do_num:
            nums = []
            for _ in range(nnum):
                coeffs = [random.randint(-5, 5) for _ in ker]
                fv = [sum(c * kv[i] for c, kv in zip(coeffs, ker)) for i in range(N)]
                g = 0
                for x in fv: g = gcd(g, x)
                fv = [x // g for x in fv] if g else fv
                L = L1_digamma(fv, q)
                scale = max(abs(x) for x in fv)
                nums.append((float(abs(L)), scale))
            # control: perturb one coordinate
            fv2 = list(fv); fv2[0] += 1; fv2[1] -= 1
            Lc = L1_digamma(fv2, q)
            out['numerics'] = nums
            out['control_L'] = float(Lc)
    out['time'] = round(time.time() - t0, 1)
    if verbose:
        print(out, flush=True)
    return out, Ebits


if __name__ == '__main__':
    qs = [int(x) for x in sys.argv[1:]] or [9, 15, 25, 45]
    for q in qs:
        analyse(q)
