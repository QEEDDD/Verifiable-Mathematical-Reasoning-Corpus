"""Section 6.4 check: N-periodic f with f(n) = +-1 for ALL n (incl. N|n), sum f = 0,
sum f(n)/n = 0.  Exhaustive search through Okada's original system (unknowns f(0..N-1)):
enumerate +-1 values of the free variables of the exact RREF and test the pivots."""
import sys, time
from fractions import Fraction
from math import lcm
import numpy as np
import flint, mpmath
from tools import okada_rows

mpmath.mp.dps = 40


def search(N, maxsol=5):
    rows, _ = okada_rows(N, with_zero=True)
    M = flint.fmpq_mat(len(rows), N, [flint.fmpq(x.numerator, x.denominator) for r in rows for x in r])
    R, rk = M.rref()
    piv = []
    for i in range(rk):
        for j in range(N):
            if R[i, j] != 0:
                piv.append(j); break
    free = [j for j in range(N) if j not in piv]
    D = 1
    for i in range(rk):
        for j in free:
            D = lcm(D, int(R[i, j].q))
    Rp = [[int(R[i, j].p) * (D // int(R[i, j].q)) for j in free] for i in range(rk)]
    big = max([abs(x) for r in Rp for x in r] + [D]) * len(free)
    use_int = big < 2**62
    A = np.array(Rp, dtype=np.int64 if use_int else object)
    nf = len(free)
    sols = []
    chunk = 1 << min(nf, 16)
    total = 1 << nf
    for start in range(0, total, chunk):
        idx = np.arange(start, min(start + chunk, total), dtype=np.int64)
        X = ((idx[:, None] >> np.arange(nf)) & 1) * 2 - 1        # +-1 matrix (chunk x nf)
        X = X.astype(A.dtype)
        Y = X @ A.T                                                # chunk x rk ; x_P = -Y/D
        ok = np.all((Y == D) | (Y == -D), axis=1)
        for k in np.nonzero(ok)[0]:
            f = [0] * N
            for t, j in enumerate(free):
                f[j] = int(X[k, t])
            for i, pc in enumerate(piv):
                f[pc] = -int(Y[k, i]) // D
            sols.append(f)
    return rk, nf, sols


def L1(f, N):
    # f[n] for n=0..N-1 ; sum_{n>=1} f(n)/n = -(1/N) sum_{a=1}^{N} f(a) psi(a/N)
    s = mpmath.mpf(0)
    for a in range(1, N + 1):
        s += f[a % N] * mpmath.digamma(mpmath.mpf(a) / N)
    return -s / N


if __name__ == '__main__':
    Ns = [int(x) for x in sys.argv[1:]] or list(range(2, 37, 2))
    for N in Ns:
        t0 = time.time()
        rk, nf, sols = search(N)
        line = f'N={N:3d} (N mod 4 = {N%4}): rank={rk}, free={nf}, #(+-1 solutions)={len(sols)}'
        if sols:
            f = sols[0]
            line += f'; first: f(0..N-1)={"".join("+" if x > 0 else "-" for x in f)}, |L(1,f)|={float(abs(L1(f, N))):.2e}'
        print(line + f'  [{time.time()-t0:.1f}s]', flush=True)
