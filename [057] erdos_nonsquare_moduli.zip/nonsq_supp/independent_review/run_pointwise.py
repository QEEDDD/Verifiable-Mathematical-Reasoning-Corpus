"""Remark 'A pointwise statement' (Sect. 6): if layers d (p|d, d not a p-power) have constant
parity and all S_{p^j} are even, then Psi_empty(y) is even for every y in C_p.
Checked exhaustively on bar(Lambda) (reduction of the saturated Okada lattice)."""
import sys
import sympy
from tools import *
from run_okada import analyse
from layer_parity import layer_masks
from subsystem import Subsys

for q in [int(x) for x in sys.argv[1:]]:
    out, Ebits = analyse(q, do_M1=False, do_num=False, verbose=False)
    N = q - 1
    ker = f2_kernel(Ebits, N)          # basis of bar(Lambda) in F2^{q-1}
    masks = layer_masks(q)
    fac = factor(q)
    res = {}
    for p, e in fac.items():
        S = Subsys(p, [r for r in fac if r != p])
        # linear conditions on coefficients alpha (over the basis 'ker')
        conds = []
        def lin(func):   # func: bitvector over residues; returns condition row on alpha
            r = 0
            for s, v in enumerate(ker):
                if popc(v & func) & 1:
                    r |= 1 << s
            return r
        for d, msk in masks.items():
            if d % p == 0 and len(factor(d)) >= 2:
                ns = [n for n in range(1, q) if msk >> (n - 1) & 1]
                for a, b in zip(ns, ns[1:]):
                    conds.append(lin((1 << (a - 1)) | (1 << (b - 1))))
        for j in range(1, e + 1):
            conds.append(lin(masks[p**j]))       # S_{p^j} even
        sub = f2_kernel(conds, len(ker))
        # Psi_empty(y) functionals
        bad = 0
        for y in range(S.C[p]):
            func = 0
            for j in range(1, e + 1):
                d = p**j
                for x in range(1, d):
                    if x % p and S.kappa(p, x) == y:
                        func |= 1 << ((q // d) * x % q - 1)
            r = lin(func)
            bad += any(popc(al & r) & 1 for al in sub)
        res[p] = 'holds' if bad == 0 else f'FAILS at {bad} points'
    print(q, res, flush=True)
