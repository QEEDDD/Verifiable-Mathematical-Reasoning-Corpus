"""End-to-end: Okada's ORIGINAL system -> exact solutions f -> pushforwards Phi_d (own kappa)
-> aggregated Psi_L -> Gamma_J.  Checks Prop 3.2, Lemma 2.4, and (with prescribed parities)
the chain of Thm 5.1.  Also checks the Thm 5.2 constructions (a), (b) against Okada's
original equations."""
import sys, random, itertools
from fractions import Fraction
from math import gcd
import numpy as np
import sympy, flint
from tools import *
from subsystem import Subsys, F0, exact_adic_basis
from run_okada import exact_kernel
from layer_parity import layer_masks

random.seed(77)


def units(d):
    return [x for x in range(1, d) if gcd(x, d) == 1] if d > 1 else [0]


def pushforwards(q, f, S):
    """f: dict n->value for 1<=n<q. Returns dict d -> (L, Phi_d array) for layers d with p|d."""
    p = S.p
    out = {}
    for d in sympy.divisors(q):
        if d == 1 or d % p:
            continue
        L = tuple(sorted(r for r in factor(d) if r != p))
        Phi = F0(S.shape[L])
        for x in units(d):
            y = tuple(S.kappa(s, x) for s in (p,) + L)
            Phi[y] += f[(q // d) * x % q]
        out[d] = (L, Phi)
    return out


def aggregate(S, PF):
    Psi = {L: F0(S.shape[L]) for L in S.subsets}
    for d, (L, Phi) in PF.items():
        Psi[L] = Psi[L] + Phi
    return Psi


def check_prop32(q, nsamp=3, wrong=True):
    rows, _ = okada_rows(q)
    irows = integerize(rows)
    ker = exact_kernel(irows, q - 1)
    fac = factor(q)
    res = {}
    for p in fac:
        W = [r for r in fac if r != p]
        S = Subsys(p, W)
        Sw = Subsys(p, W, trans_sign=-1)
        okc = 0; okw = 0; ok24 = 0
        for _ in range(nsamp):
            co = [random.randint(-3, 3) for _ in ker]
            fv = [sum(c * k[i] for c, k in zip(co, ker)) for i in range(q - 1)]
            f = {n: Fraction(fv[n - 1]) for n in range(1, q)}
            PF = pushforwards(q, f, S)
            Psi = aggregate(S, PF)
            allN = all(S.in_N(S.Gamma(J, Psi)) for J in S.subsets)
            G0 = S.Gamma((), Psi)
            Ssum = sum(sum(Phi.reshape(-1)) for (L, Phi) in PF.values())
            const = all(x == Ssum / S.C[p] for x in G0.reshape(-1))
            okc += allN and const
            # Lemma 2.4 identity
            lhs = Ssum
            rhs = -(p - 1) * sum(vp(d, p) * sum(Phi.reshape(-1)) for d, (L, Phi) in PF.items())
            ok24 += (lhs == rhs)
            if wrong:
                okw += all(Sw.in_N(Sw.Gamma(J, Psi)) for J in Sw.subsets)
        res[p] = {'W': W, 'Prop3.2_holds': f'{okc}/{nsamp}', 'Lemma2.4_identity': f'{ok24}/{nsamp}',
                  'wrong_translation_direction_also_passes': f'{okw}/{nsamp}' if wrong else None}
    return res, ker


def legendre(x, p):
    return int(sympy.legendre_symbol(x % p, p)) if x % p else 0


def construction_a(q, d, p, r):
    """f = chi on layer d, beta*chi on layer d'' = d / r^v, beta = -r^{v-1}(r - chi(r))."""
    v = vp(d, r); d2 = d // r**v
    chir = legendre(r, p)
    beta = -r**(v - 1) * (r - chir)
    f = {n: Fraction(0) for n in range(1, q)}
    for x in units(d):
        f[(q // d) * x % q] = Fraction(legendre(x, p))
    for x in units(d2):
        f[(q // d2) * x % q] = Fraction(beta * legendre(x, p))
    return f


def construction_b(q, p, i, j):
    f = {n: Fraction(0) for n in range(1, q)}
    for x in units(p**i):
        f[(q // p**i) * x % q] = Fraction(p**(j - i) * legendre(x, p))
    for x in units(p**j):
        f[(q // p**j) * x % q] = Fraction(-legendre(x, p))
    return f


def check_constructions(q):
    rows, _ = okada_rows(q)
    fac = factor(q)
    masks = layer_masks(q)
    nok = ntot = 0
    fails = []
    for d in masks:
        fd = factor(d)
        if len(fd) >= 2:
            for p in fd:
                for r in fd:
                    if r == p:
                        continue
                    f = construction_a(q, d, p, r)
                    vec = [f[n] for n in range(1, q)]
                    sol = all(sum(a * b for a, b in zip(row, vec)) == 0 for row in rows)
                    par = {dd: set(bit(f[n]) for n in range(1, q) if masks[dd] >> (n - 1) & 1) for dd in masks}
                    parok = all(par[dd] == ({1} if dd == d else {0}) for dd in masks)
                    ntot += 1; nok += sol and parok
                    if not (sol and parok):
                        fails.append(('a', d, p, r, sol, parok))
    for p, e in fac.items():
        for i in range(1, e + 1):
            for j in range(i + 1, e + 1):
                f = construction_b(q, p, i, j)
                vec = [f[n] for n in range(1, q)]
                sol = all(sum(a * b for a, b in zip(row, vec)) == 0 for row in rows)
                par = {dd: set(bit(f[n]) for n in range(1, q) if masks[dd] >> (n - 1) & 1) for dd in masks}
                parok = all(par[dd] == ({1} if dd in (p**i, p**j) else {0}) for dd in masks)
                ntot += 1; nok += sol and parok
                if not (sol and parok):
                    fails.append(('b', p, i, j, sol, parok))
    return nok, ntot, fails


def sample_parity_solutions(q, ker, nsamp=2):
    """Thm 5.1 chain on explicit 2-integral solutions realizing every realizable layer pattern."""
    B = exact_adic_basis([[Fraction(x) for x in k] for k in ker])
    masks = layer_masks(q)
    ds = list(masks)
    m = len(B)
    Bb = [sum(bit(x) << i for i, x in enumerate(b)) for b in B]
    fac = factor(q)
    report = []
    for pattern in itertools.product([0, 1], repeat=len(ds)):
        target = 0
        for k, d in enumerate(ds):
            if pattern[k]:
                target |= masks[d]
        # solve sum alpha_s Bb_s = target over F2 (augmented elimination)
        basis = []  # (pivotbit, vec, combo)
        for s, v in enumerate(Bb):
            c = 1 << s
            for pv, bv, bc in basis:
                if v & pv:
                    v ^= bv; c ^= bc
            if v:
                basis.append((v & -v, v, c))
        t, comb = target, 0
        for pv, bv, bc in basis:
            if t & pv:
                t ^= bv; comb ^= bc
        feasible = (t == 0)
        predicted = all(sum(pattern[ds.index(p**j)] for j in range(1, e + 1)) % 2 == 0
                        for p, e in fac.items())
        chain_ok = None
        if feasible:
            chain_ok = True
            for _ in range(nsamp):
                w = [Fraction(0)] * (q - 1)
                for s in range(m):
                    co = ((comb >> s) & 1) + 2 * random.randint(-2, 2)
                    if co:
                        w = [x + co * y for x, y in zip(w, B[s])]
                f = {n: w[n - 1] for n in range(1, q)}
                # exact Okada check
                rows, _ = okada_rows(q) if not hasattr(sample_parity_solutions, 'rows') else (sample_parity_solutions.rows, None)
                assert all(sum(a * b for a, b in zip(row, w)) == 0 for row in rows)
                for k, d in enumerate(ds):
                    assert all(is2int(f[n]) and bit(f[n]) == pattern[k]
                               for n in range(1, q) if masks[d] >> (n - 1) & 1)
                for p in fac:
                    S = Subsys(p, [r for r in fac if r != p])
                    PF = pushforwards(q, f, S)
                    Psi = aggregate(S, PF)
                    G0 = S.Gamma((), Psi)
                    c0 = G0.reshape(-1)[0]
                    ok = all(x == c0 for x in G0.reshape(-1)) and is2int(c0) and bit(c0) == 0
                    ok = ok and all(bit(x) == bit(c0) for x in Psi[()].reshape(-1))
                    chain_ok = chain_ok and ok
        report.append((pattern, feasible, predicted, chain_ok))
    return report


if __name__ == '__main__':
    for q in [int(x) for x in sys.argv[1:]]:
        res, ker = check_prop32(q)
        print(f'q={q}: Prop 3.2 / Lemma 2.4 end-to-end:', res, flush=True)
        nok, ntot, fails = check_constructions(q)
        print(f'q={q}: Thm 5.2 constructions (a),(b) satisfy Okada\'s original equations with the '
              f'claimed parity pattern: {nok}/{ntot}', fails if fails else '', flush=True)
        if q <= 230:
            sample_parity_solutions.rows = okada_rows(q)[0]
            rep = sample_parity_solutions(q, ker)
            nf = sum(1 for r in rep if r[1]); npred = sum(1 for r in rep if r[2])
            agree = all(r[1] == r[2] for r in rep)
            chain = all(r[3] for r in rep if r[1])
            print(f'q={q}: layer patterns: {len(rep)} total, feasible {nf}, predicted {npred}, '
                  f'feasible==predicted: {agree}; explicit random 2-integral solutions for every '
                  f'feasible pattern pass the Thm 5.1 chain (Gamma_empty even constant ≡ Psi_empty): {chain}',
                  flush=True)
