"""(a) The conductor-p subsystem of Section 3, implemented from the definitions.
Functions on X_J = C_p x prod_{r in J} C_r are numpy object arrays of Fractions with axes
ordered (p,) + J (J a sorted tuple).  (T_r F)(x) = F(x + h_r^J), h_r^J = kappa_{m_J}(r)."""
import itertools
from fractions import Fraction
import numpy as np
import sympy
import flint
from tools import v2int, bit, is2int, f2_kernel, f2_rank, f2_in_span


def F0(shape):
    a = np.empty(shape, dtype=object)
    a.fill(Fraction(0))
    return a


class Subsys:
    def __init__(self, p, W, trans_sign=+1):
        self.p = p
        self.W = tuple(sorted(W))
        self.primes = (p,) + self.W
        self.t = {s: v2int(s - 1) for s in self.primes}
        self.C = {s: 1 << self.t[s] for s in self.primes}
        self.g = {s: int(sympy.primitive_root(s)) for s in self.primes}
        self.ind = {}
        for s in self.primes:
            tab, x = {}, 1
            for k in range(s - 1):
                tab[x] = k
                x = x * self.g[s] % s
            self.ind[s] = tab
        self.trans_sign = trans_sign  # +1 = manuscript convention; -1 = deliberately wrong
        self.subsets = [tuple(c) for k in range(len(self.W) + 1)
                        for c in itertools.combinations(self.W, k)]
        self.shape = {L: tuple(self.C[s] for s in (p,) + L) for L in self.subsets}
        self.size = {L: int(np.prod(self.shape[L])) for L in self.subsets}
        self.off, o = {}, 0
        for L in self.subsets:
            self.off[L] = o
            o += self.size[L]
        self.N = o

    # ------------------------------------------------------------ basic maps
    def kappa(self, s, x):
        return self.ind[s][x % s] % self.C[s]

    def h(self, J, r):
        return tuple(self.kappa(s, r) for s in (self.p,) + J)

    def T(self, J, r, F):
        hv = self.h(J, r)
        G = F
        for ax, hh in enumerate(hv):
            G = np.roll(G, -self.trans_sign * hh, axis=ax)   # G[x] = F[x + h]
        return G

    def E(self, J, r, F):
        return (r * F - self.T(J, r, F)) * Fraction(1, r - 1)

    def R(self, J, r, F):
        u = Fraction(1 << self.t[r], r - 1)
        return (r * F - self.T(J, r, F)) * u

    def pi(self, L, J, F):
        axes = tuple(1 + L.index(r) for r in L if r not in J)
        if not axes:
            return F
        return F.sum(axis=axes)  # remaining axes keep order (p,)+J since J subset of L sorted

    def split(self, vec):
        return {L: np.array(vec[self.off[L]:self.off[L] + self.size[L]], dtype=object)
                .reshape(self.shape[L]) for L in self.subsets}

    def join(self, Psi):
        v = []
        for L in self.subsets:
            v += list(Psi[L].reshape(-1))
        return v

    def Gamma(self, J, Psi):
        G = F0(self.shape[J])
        for L in self.subsets:
            if set(J) <= set(L):
                F = self.pi(L, J, Psi[L])
                for r in L:
                    if r not in J:
                        F = self.E(J, r, F)
                G = G + F
        return G

    @staticmethod
    def full_part(F):
        """prod_i (1 - A_i) F, A_i = average over axis i: projection on full characters."""
        G = F
        for ax in range(F.ndim):
            m = G.sum(axis=ax, keepdims=True) * Fraction(1, G.shape[ax])
            G = G - m
        return G

    def in_N(self, F):
        return all(x == 0 for x in self.full_part(F).reshape(-1))

    # ------------------------------------------------------------ condition matrix
    def condition_rows(self, include_empty=False):
        rows = []
        Js = [J for J in self.subsets if J or include_empty]
        # apply to unit vectors (columns)
        cols = []
        for k in range(self.N):
            v = [Fraction(0)] * self.N
            v[k] = Fraction(1)
            Psi = self.split(v)
            col = []
            for J in Js:
                col += list(self.full_part(self.Gamma(J, Psi)).reshape(-1))
            cols.append(col)
        nrow = len(cols[0])
        return [[cols[k][i] for k in range(self.N)] for i in range(nrow)]

    # ------------------------------------------------------------ elementary solutions
    def bottom_solutions(self):
        out = []
        for y in range(self.C[self.p]):
            Psi = {L: F0(self.shape[L]) for L in self.subsets}
            Psi[()][y] = Fraction(1)
            out.append(('bottom', y, Psi))
        return out

    def nu_solution(self, L0, nu):
        Psi = {L: F0(self.shape[L]) for L in self.subsets}
        Psi[L0] = nu
        return Psi

    def tp_solution(self, L0, i, omega):
        K = tuple(r for r in L0 if r != i)
        Psi = {L: F0(self.shape[L]) for L in self.subsets}
        ax = 1 + L0.index(i)
        Psi[L0] = np.repeat(np.expand_dims(omega, ax), self.C[i], axis=ax)  # omega o pr_i
        Psi[K] = -self.R(K, i, omega)
        return Psi

    def elementary_basis(self):
        out = self.bottom_solutions()
        for L0 in self.subsets:
            if not L0:
                continue
            # nu independent of p: indicator of a fibre of the projection forgetting p
            sh = self.shape[L0]
            for y in itertools.product(*[range(n) for n in sh[1:]]):
                nu = F0(sh)
                for a in range(sh[0]):
                    nu[(a,) + y] = Fraction(1)
                out.append(('nu', (L0, y), self.nu_solution(L0, nu)))
            for i in L0:
                K = tuple(r for r in L0 if r != i)
                shK = self.shape[K]
                for z in itertools.product(*[range(n) for n in shK]):
                    om = F0(shK)
                    om[z] = Fraction(1)
                    out.append(('tp', (L0, i, z), self.tp_solution(L0, i, om)))
        return out


def fmpq_rank(rows):
    if not rows:
        return 0
    M = flint.fmpq_mat(len(rows), len(rows[0]), [flint.fmpq(x.numerator, x.denominator)
                                                  for r in rows for x in r])
    return M.rank()


def fmpq_kernel(rows, ncols):
    M = flint.fmpq_mat(len(rows), ncols, [flint.fmpq(x.numerator, x.denominator)
                                          for r in rows for x in r])
    Rr, rk = M.rref()
    piv = []
    for i in range(rk):
        for j in range(ncols):
            if Rr[i, j] != 0:
                piv.append(j)
                break
    free = [j for j in range(ncols) if j not in piv]
    ker = []
    for j in free:
        v = [Fraction(0)] * ncols
        v[j] = Fraction(1)
        for i, pc in enumerate(piv):
            x = Rr[i, j]
            v[pc] = -Fraction(int(x.p), int(x.q))
        ker.append(v)
    return ker


def exact_adic_basis(vecs):
    """Exact 2-adic echelon of a list of rational vectors spanning V: returns a
    Z_(2)-basis of V intersect Z_(2)^n (each vector 2-integral, reductions independent)."""
    M = [list(v) for v in vecs]
    n = len(M[0])
    basis = []
    rows = M
    used_cols = []
    while rows:
        best = None
        for i, r in enumerate(rows):
            for j, x in enumerate(r):
                if x != 0:
                    v = v2int(x.numerator) - v2int(x.denominator)
                    if best is None or v < best[0]:
                        best = (v, i, j)
        if best is None:
            break
        v, i, j = best
        pr = rows.pop(i)
        a = pr[j]
        pr = [x / a for x in pr]          # pivot 1, others 2-integral (min valuation)
        newrows = []
        for r in rows:
            c = r[j]
            if c != 0:
                r = [x - c * y for x, y in zip(r, pr)]
            if any(x != 0 for x in r):
                newrows.append(r)
        rows = newrows
        basis.append(pr)
        used_cols.append(j)
    for b in basis:
        assert all(is2int(x) for x in b)
    return basis
