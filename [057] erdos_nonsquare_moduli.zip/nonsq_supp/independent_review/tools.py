"""Independent referee tools (written from scratch).

- 2-adic echelon form of an integer matrix modulo 2^K (pivot of minimal valuation),
  giving the reduction mod 2 of the 2-saturation of the row lattice.
- F2 linear algebra with Python ints as bit vectors.
- Okada's ORIGINAL criterion (1982) for a q-periodic f, unknowns f(1..q-1) (f(0)=0),
  or f(0..q-1) if with_zero=True.
"""
from fractions import Fraction
from math import gcd, lcm
import numpy as np
import sympy


# ---------------------------------------------------------------- basics
def factor(q):
    return dict(sorted(sympy.factorint(q).items()))


def v2int(x):
    """2-adic valuation of a nonzero Python int."""
    return (x & -x).bit_length() - 1


def vp(n, p):
    k = 0
    while n % p == 0:
        n //= p
        k += 1
    return k


def v2frac(x):
    x = Fraction(x)
    if x == 0:
        return 10**9
    return v2int(x.numerator) - v2int(x.denominator)


def is2int(x):
    return Fraction(x).denominator % 2 == 1


def bit(x):
    """residue mod 2 of a 2-integral rational."""
    x = Fraction(x)
    assert x.denominator % 2 == 1, x
    return x.numerator & 1


# ---------------------------------------------------------------- 2-adic echelon
def adic_echelon(rows, K=256):
    """rows: list of lists of Python ints (an integer matrix A, nr x nc).
    Performs row operations over Z_(2) (exact mod 2^K) with full pivoting by minimal
    2-adic valuation (column swaps recorded).  Returns (rank, vals, Ebits, colperm) where
    Ebits[s] is the bit vector (original column order) of (row s)/2^{v_s} mod 2.
    The rows Ebits span the reduction mod 2 of the saturated row lattice
    (rowspace_Q(A) intersect Z_(2)^nc), provided K > max v_s.
    Caller must compare rank with the exact rational rank."""
    MOD = 1 << K
    M = np.array([[int(x) % MOD for x in r] for r in rows], dtype=object)
    nr, nc = M.shape
    colperm = list(range(nc))
    vals = []
    s = 0
    while s < nr and s < nc:
        sub = M[s:, s:]
        lb = sub & (-sub)            # lowest set bit (0 for zero entries)
        lb = np.where(sub == 0, MOD, lb)
        idx = int(np.argmin(lb))
        i, j = divmod(idx, sub.shape[1])
        if lb[i, j] == MOD:
            break
        i += s
        j += s
        if i != s:
            M[[s, i], :] = M[[i, s], :]
        if j != s:
            M[:, [s, j]] = M[:, [j, s]]
            colperm[s], colperm[j] = colperm[j], colperm[s]
        a = int(M[s, s])
        v = v2int(a)
        u = a >> v
        uinv = pow(u, -1, MOD)
        if s + 1 < nr:
            col = M[s + 1:, s]
            c = np.array([((int(x) >> v) * uinv) % MOD for x in col], dtype=object)
            M[s + 1:, s:] = (M[s + 1:, s:] - np.outer(c, M[s, s:])) % MOD
        vals.append(v)
        s += 1
    rank = len(vals)
    Ebits = []
    for t in range(rank):
        v = vals[t]
        b = 0
        for jj in range(t, nc):
            x = int(M[t, jj])
            if (x >> v) & 1:
                b |= 1 << colperm[jj]
        Ebits.append(b)
    return rank, vals, Ebits, colperm


# ---------------------------------------------------------------- F2 linear algebra
def f2_rref(rows):
    """rows: list of int bitvectors. Returns list of (pivotbit, row) in reduced form."""
    basis = []  # list of [pivot, row]
    for r in rows:
        for pv, b in basis:
            if r & pv:
                r ^= b
        if r:
            pv = r & -r
            # reduce existing basis rows
            for k in range(len(basis)):
                if basis[k][1] & pv:
                    basis[k][1] ^= r
            basis.append([pv, r])
    return basis


def f2_rank(rows):
    return len(f2_rref(rows))


def f2_in_span(vec, rows):
    basis = f2_rref(rows)
    for pv, b in basis:
        if vec & pv:
            vec ^= b
    return vec == 0


def f2_kernel(rows, ncols):
    """basis of {x in F2^ncols : popcount(row & x) even for all rows}."""
    basis = f2_rref(rows)
    pivots = {}
    for pv, b in basis:
        pivots[pv.bit_length() - 1] = b
    free = [j for j in range(ncols) if j not in pivots]
    ker = []
    for j in free:
        x = 1 << j
        for pc, b in pivots.items():
            if (b >> j) & 1:
                x |= 1 << pc
        ker.append(x)
    return ker


def popc(x):
    return bin(x).count('1')


def f2_dot(a, b):
    return popc(a & b) & 1


# ---------------------------------------------------------------- Okada's original criterion
def okada_rows(q, with_zero=False):
    """Okada (1982): for q-periodic f,  sum f(n)/n = 0 (with sum_{n=1}^q f(n)=0)  iff
       (U_a) sum_{m in M(q)} f(a m)/m = 0  for all units a mod q,
       (P_p) sum_{1<=r<=q, gcd(r,q)>1} f(r) eps(r,p) = 0 for each prime p|q, where
             eps(r,p) = v_p(r) if v_p(r) < v_p(q), and v_p(q)+1/(p-1) otherwise,
       (C)   sum_{n=1}^q f(n) = 0.
    Unknowns: f(1),...,f(q-1) (f(0)=0), or f(0),...,f(q-1) if with_zero.
    Returns (rows as lists of Fractions, labels)."""
    fac = factor(q)
    primes = list(fac)
    combos = [(1, Fraction(1))]
    for p in primes:
        e = fac[p]
        qp = q // p**e
        o = int(sympy.n_order(p, qp)) if qp > 1 else 1
        opts = [(pow(p, k, q), Fraction(1, p**k)) for k in range(e)]
        tail = 1 / (1 - Fraction(1, p**o))
        opts += [(pow(p, k, q), Fraction(1, p**k) * tail) for k in range(e, e + o)]
        combos = [((m * mp) % q, w * wp) for (m, w) in combos for (mp, wp) in opts]
    agg = {}
    for m, w in combos:
        agg[m] = agg.get(m, 0) + w
    off = 0 if with_zero else 1
    ncols = q if with_zero else q - 1
    rows, labels = [], []
    for a in range(1, q):
        if gcd(a, q) != 1:
            continue
        row = [Fraction(0)] * ncols
        for m, w in agg.items():
            n = a * m % q
            if n == 0 and not with_zero:
                continue
            row[n - off] += w
        rows.append(row)
        labels.append(('U', a))
    for p in primes:
        e = fac[p]
        row = [Fraction(0)] * ncols
        for r in range(1, q + 1):
            if gcd(r, q) > 1:
                n = r % q
                if n == 0 and not with_zero:
                    continue
                v = vp(r, p)
                row[n - off] += Fraction(v) if v < e else Fraction(e) + Fraction(1, p - 1)
        rows.append(row)
        labels.append(('P', p))
    rows.append([Fraction(1)] * ncols)
    labels.append(('C',))
    return rows, labels


def integerize(rows):
    out = []
    for r in rows:
        L = 1
        for x in r:
            L = lcm(L, x.denominator)
        ir = [int(x * L) for x in r]
        g = 0
        for x in ir:
            g = gcd(g, x)
        if g == 0:
            out.append(ir)
            continue
        out.append([x // g for x in ir])
    return out


def layers(q):
    """dict d -> list of residues n (1<=n<q) with gcd(n,q) = q/d."""
    res = {}
    for n in range(1, q):
        d = q // gcd(n, q)
        res.setdefault(d, []).append(n)
    return dict(sorted(res.items()))
