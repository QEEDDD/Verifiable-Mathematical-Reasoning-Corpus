# Supplementary material

**Paper:** *Exponent collapse and a question of Corvaja and Zannier on squares in S-unit shifts* (Keio, 25 October 2026).

All computations are exact: integer arithmetic, exact rationals (`fractions.Fraction`) and exact modular exponentiation. The scripts need Python 3 with `sympy` and `numpy`; `verify_cert.py` and `small_decide.py` use neither.

To reproduce everything, run from this directory:

```
sh code/run_all.sh
```

This takes about 15 minutes on one core. It writes JSON to `out/` and text logs to `logs/`. Every script is run as `python3 -I`.

## What the proofs depend on

The general theorems need no computation. These are Theorem A, Corollary 1.3 (the answer to Corvaja–Zannier) and Remark 3.2 (the local obstruction).

Theorem B (printed as "Theorem B" in the paper) is explicit and computational:

- **Theorem B(1).** gcd(2^E−1, 3^E−1) with E = 1441440 has 379 digits. `gcd_primes.py` factors it completely by trial division, finding 114 primes, all larger than 3. It then evaluates E² ∏_{ℓ}(ℓ+1)/(2ℓ) exactly; the result is 2.6839·10⁻²² < 2.7·10⁻²². The bound holds uniformly for all integers a, b.
- **Theorem B(2).** Five covering certificates (Table 1); the one for t₀ = 58 uses 20 primes. They were found by `cert_search.py` (numpy, vectorised) and re-verified class by class by `verify_cert.py`, a separately written pure-Python check.
- **Theorem B(3).** `small_decide.py` searches every t₀ ∈ [−50, 100] with exact rationals over max(|m|, |n|) ≤ 12. It finds a representation t₀ + 2^m + 3^n = x² for 146 of them; the largest exponent needed is 9. The remaining five are −44, −38, −14, 58 and 100, which are exactly the certified ones.

## Scripts

| Script | What it does | Paper reference | Log / output |
|---|---|---|---|
| `lam.py` | For several E, lists the prime factors ℓ > 3 of gcd(2^E−1, 3^E−1) and which of them satisfy ℓ−1 \| E. | §4 | `00_primes_for_E.txt` |
| `gcd_primes.py` | Complete factorisation of gcd(2^E−1, 3^E−1) for E = 1441440; re-checks 2^E ≡ 3^E ≡ 1 (mod ℓ); exact bound. | Theorem B(1) | `01_gcd_primes_bound.txt`, `gcd_primes_1441440.json` |
| `union_bound.py` | The earlier, weaker bound using only the 108 primes below 2·10⁵ (1.72·10⁻²⁰), and the E = 5040 comparison bound 0.0270. | Remark 4.1 | `01b_union_bound_108primes.txt` |
| `cert_search.py` | Vectorised search for certificates (t₀, P): every class (μ,ν) ∈ (Z/E)² must be killed by some ℓ ∈ P, meaning t₀ + 2^μ + 3^ν is a non-zero non-residue mod ℓ. | Theorem B(2) | `03_*.txt`, `04_*.txt`, `cert_*.json` |
| `verify_cert.py` | Independent pure-Python check of each certificate over all E_P² classes, where E_P = lcm of the orders of 2 and 3 modulo the primes of P. | Theorem B(2), Table 1 | `02_verify_certificates.txt`, `certificates.json` |
| `small_decide.py` | Exhibits a representation for every represented t₀ ∈ [−50, 100]. | Theorem B(3) | `06_small_decide.txt`, `small_decide.json` |
| `random_check.py` | Sanity check, not used in any proof: certifies random large t₀ with E = 5040. Result: 97 of 100 in [10^15, 10^16), seed 2026. | Remark 4.1 | `05_random_check.txt` |

The folder `independent_review/` contains the referee's own scripts and outputs (written from the LaTeX source only; see `REVIEW_SUMMARY.md`).

The folder `aux_murty_pathak/` is **not part of this paper**. It is an exploratory computation on the Murty–Pathak ±1 variant of Erdős's problem; see its `NOTE.md`. That note also contains a correction to the final problem of our earlier paper, and a proof that no admissible f exists for N = 4p.

## Notes on rigour

- **Negative exponents.** For m, n ∈ Z (also negative) and ℓ > 3, the residue 2^m mod ℓ depends only on m mod ord_ℓ(2), and 3^n mod ℓ only on n mod ord_ℓ(3).
- **Rational squares.** If t + 2^m + 3^n = x² with x ∈ Q, then x is ℓ-integral, so the left side is a square, possibly 0, mod ℓ.
- **What counts as killed.** A class is killed only when the residue is a non-zero non-residue. The residue 0 counts as a square, because x = 0 is allowed.
- **Why the union bound is valid.** For each class (μ,ν) the polynomial x ↦ x² − a2^μ − b3^ν takes exactly (ℓ+1)/2 values mod ℓ, even when ℓ | ab. So the exceptional residues have density at most E² ∏(ℓ+1)/(2ℓ).
