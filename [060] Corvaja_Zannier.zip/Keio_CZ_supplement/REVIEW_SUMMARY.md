# Independent review: summary and response

A separate agent reviewed the paper. It received only the LaTeX source, not the author's code or outputs. It re-derived all proofs, compared the paper's account of the Corvaja–Zannier question with the original (arXiv:2608.28255v1), checked the citations, and redid every computation with its own code. That code is in `independent_review/`.

## First pass (version 1)

**Verdict.** No fatal or significant errors; minor revision recommended. Theorem A, Corollary 1.3 and Theorem B(1),(2) are proved as stated. The corollary answers the Corvaja–Zannier question as they posed it, for S-units of Q, in a strong density-one form.

**Independent computations.** All agreed with the paper:

- **Theorem B(1).** The reviewer confirmed the 96 primes ℓ > 3 with ℓ−1 | E and the 12 further primes below 2·10⁵ whose orders of 2 and 3 divide E. Their union is exactly the 108-prime list of version 1.
- **The bound.** E²∏(ℓ+1)/(2ℓ) = 1.717697·10⁻²⁰ exactly, and 5.009949·10⁻²⁰ with 5 and 7 removed.
- **The gcd.** The reviewer factored gcd(2^E−1, 3^E−1) completely: 379 digits, 114 primes. With all 114 primes the bound becomes 2.68·10⁻²².
- **Theorem B(2).** All five certificates verify, by a numpy implementation and a separate pure-Python loop, with the stated |P| and E_P. M₅₈ has 41 digits.
- **Negative controls.** The values t₀ = −1, 0, 2, 57, 59 fail, as they should. The 58-certificate stays valid without the primes 71 and 241.
- **Brute force** with |m| ≤ 160 and |n| ≤ 100 finds no representation for the five certified t₀. Every other t₀ ∈ [−50, 100] is represented with max(|m|, |n|) ≤ 9.
- **Random check.** 389 of 400 random t₀ in [10^15, 10^16) have certificates for E = 5040.

**Novelty.** The reviewer found no prior density-zero or "almost all Hasse" result for polynomial-exponential equations. Bertók–Hajdu (2016, 2018) and Bartolome–Bilu–Luca treat purely exponential equations only. The method, however, is a short adaptation of Bertók–Hajdu: their EPS-type moduli are exactly "exponent collapse", and the new ingredient is the value-set factor. The reviewer asked for the credit to be sharpened.

**Issues raised, and how they were addressed:**

| # | Issue | Fix |
|---|---|---|
| i | After Corollary 1.3, a quantifier slip: "for almost all t₀ … not solvable modulo a fixed M" is false as written; the claim also concerns Bertók–Hajdu, not Skolem. | **Fixed.** For each ε, one M serves all t₀ outside a set of density ε; along a fixed sequence (M_j), almost every t₀ is obstructed modulo some M_j. The paper now also explains why no single M can obstruct all non-represented t₀. |
| ii | The conditional approach mentioned by CZ is due to Bresciani. | **Fixed.** Bresciani is now cited [Bre25]. |
| iii | "Arbitrary S-units" should read "S-units of Q". | **Fixed**, with a remark that a number-field version would need Prachar-type results for primes of degree one. |
| iv | Attributions in Lemma 2.4(2). | **Fixed.** Lenstra proved that exceptional polynomials satisfy gcd(d, q−1) = 1 (elementary version by Cohen–Fried); von zur Gathen shows that permutation polynomials over large fields are exceptional; the value-set bound is credited to Wan 1993, with WSC93, Thm 3.1. |
| v | Naming: the theorem labelled thm:C prints as "Theorem B". | **Fixed** in the supplement and the report, which now say "Theorem B". |
| vi | S₁ was larger than needed: only the numerator and denominator of c and the denominators of the coefficients of the A_i need to be excluded. | **Fixed.** As a consequence, Theorem B(1) now holds uniformly for all integers a, b. |
| vii | The E = 5040 bound is 0.0270, not 0.0271. | **Fixed.** |
| viii | "Exceptional t₀" is ambiguous. | **Fixed.** Now "represented t₀". |
| ix | "∉ Q²" should be written out. | **Fixed.** Now "is not a square in Q". |
| x (optional) | Strengthenings suggested by the reviewer. | **All adopted.** Theorem B(1) uses all 114 prime factors of the gcd (bound < 2.7·10⁻²²). The reduced 58-certificate is used (20 primes, 37-digit modulus). The new Theorem B(3) states the complete decision of [−50, 100]. The credit to Bertók–Hajdu is sharpened in the abstract and introduction ("exponent collapse" is only a name for a classical device; Theorem A adapts their argument). The odd-degree remark now points to AGP-type constructions in progressions [Wri13] as a possible source, still not claimed. |

## Second pass (version 2)

The same reviewer checked the revisions against a diff with version 1 (`independent_review/v1_v2.diff`). It re-ran its own code on the numbers parsed from the revised source (`recheck_v2.py`, `recheck_v2.out`).

**Verdict.** Every requested change is in place and correct; nothing is fatal or significant.

**Checks:**

- **Theorem B(1).** The bound is uniform in the integers a, b, including a = 0 or b = 0, because θ_ℓ = (ℓ+1)/(2ℓ) even when ℓ | ab. The 114 listed primes are exactly the prime factors of the 379-digit gcd: trial division below 3·10⁶ leaves cofactor 1. The product is E²∏(ℓ+1)/(2ℓ) = 2.683935·10⁻²² < 2.7·10⁻²².
- **Theorem B(2).** The reduced 58-certificate is valid: 20 primes, E_P = 2520, 0 uncovered classes in both the numpy and the pure-Python check. M₅₈ = 3057227090099877676435689114776461565 has 37 digits.
- **Theorem B(3).** Correct: the five values are certified, and the other 146 are represented with max(|m|, |n|) ≤ 9.
- **Bresciani reference.** [Bre25] is the right paper, identified by its content (Theorem A there matches CZ's footnote).

**Remaining minor points, and how they were addressed:**

| # | Point | Fix |
|---|---|---|
| a | "Classes of represented integers such as y²−a−b" presupposes a+b ∈ Z; for rational a, b the represented set can even be empty. | **Fixed.** Non-emptiness of B now follows from \|B_ξ\| = ∏\|V_{ξ,ℓ}\| ≥ 1. |
| b | Stale wording: "for the instance t₀+2^m+3^n", and the §4 title. | **Fixed.** Both now refer to t₀+a2^m+b3^n with a,b ∈ Z. |
| c | The introduction credited the value-set bound to WSC93 alone. | **Fixed.** Now [Wan93, WSC93]. |
| d | A revision-history sentence was left in the proof of B(1). | **Deleted.** |
| e | "Prime to 6 when n is even" should hold for all n. | **Fixed.** |
| f | The Organisation paragraph did not mention the search behind B(3). | **Fixed.** |
| g | "Permutation polynomial over a large field is exceptional" needs d prime to the characteristic. | **Fixed.** |
| h | Bresciani's actual hypothesis was not stated. | **Fixed.** Now "assumes conjectures of Bombieri–Lang type". |

**Final verdict.** Theorem A, Corollary 1.3 and Theorem B(1)–(3) are proved as stated. The corollary answers the Corvaja–Zannier question, in the form they posed it, for S-units of Q. The reviewer's novelty assessment is unchanged:

- no prior density-zero or "almost all Hasse principle" result for polynomial-exponential equations was found;
- the method is an adaptation of Bertók–Hajdu, and the paper now says so explicitly.
