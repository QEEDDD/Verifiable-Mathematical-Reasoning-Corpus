# Auxiliary exploration: the Murty–Pathak ±1 variant

This folder is **not part of the paper**. It records an exploratory computation made while choosing this round's target, and a correction to an earlier problem statement of ours.

## Question

Murty and Pathak (Funct. Approx. 66 (2022)) consider N-periodic f with f(n) = ±1 for every n, including N | n. Convergence of the series forces Σf = 0, hence N even. They proved L(1,f) ≠ 0 when N ≡ 2 (mod 4). They asked to classify the N for which some such f has L(1,f) = 0. Tengely found an example for N = 36, the least such period.

## Method

`okada_even.py` builds Okada's exact rational system for an arbitrary modulus N. It includes the residue 0 (layer d = 1) and is exact for even N. CP-SAT (OR-Tools) then decides whether a ±1 solution exists. Every solution found was checked in two ways:

- exactly against all linear conditions;
- numerically, via L(1,f) = −(1/N) Σ f(a) ψ(a/N), with |L| < 10⁻³⁰.

## Results

For N ≡ 0 (mod 4), all N ≤ 400 not divisible by 3 were tested, all N ≤ 160 divisible by 3, and some larger N by hand (`logs/summary.txt`). INFEASIBLE means proved infeasible by CP-SAT.

**Feasible:** 36, 48, 60, 72, 80, 84, 96, 108, 120, 132, 144, 156, 160, 200, 220, 260, 280, 320, 380, 400, 572, 616.

**Minimal feasible values among those tested:** 36, 48, 60, 80, 84, 132, 156, 200, 220, 260, 280, 380, 572, 616.

**Unknown (time limit reached):** 340, 728.

The feasible set is closed under taking multiples, since an N-periodic f is also kN-periodic. Its structure is irregular:

- 4·5·7 is infeasible, while 4·5·11, 4·5·13 and 4·11·13 are feasible.
- 4·7·11 is infeasible, while 8·7·11 is feasible.
- 4·25 is infeasible, while 8·25 is feasible.

Moreover, the 2-adic relaxation (a 2-integral rational solution with all values odd) is feasible for every N ≡ 0 (mod 4) tested, as `twoadic.py` shows. So these obstructions are not parity obstructions. We did not find a clean classification.

## Correction to our earlier paper

The final Problem of our earlier paper on non-square moduli asked whether L(1,f) ≠ 0 for every non-square N ≡ 0 (mod 4). The answer is trivially **no**:

- Tengely's 36-periodic f is also 72-periodic, and 72 is a non-square.
- 48 is a non-square with its own solution (`out/first_sols.txt`).

The meaningful question is the one about minimal periods. That is the classification question above, which remains open.

## A small proved byproduct: N = 4p

**Proposition.** Let p be an odd prime. There is no 4p-periodic f with f(n) = ±1 for all n, Σf = 0 and L(1,f) = 0.

This is not used anywhere in the paper. The proof uses only necessary conditions from Okada's criterion: conditions (A) for each primitive character, conditions (B_p) for p | N, and (C) Σf = 0.

**Setup.** The layers are d ∈ {1, 2, 4, p, 2p, 4p}. Write:

- f_{4p} for f on the units mod 4p;
- B, g, f_p for the induced functions on U_p, coming from the units, from n = 2x and from n = 4x respectively.

**Step 1: the units depend on one coordinate.** Condition (A) at conductor 4p says that f_{4p}(x) = A(x mod 4) + B(x mod p). A ±1-valued function of this form depends on only one of the two coordinates.

**Step 2: f_{4p} cannot be ±χ₋₄.** Suppose f_{4p} = ±χ₋₄. Condition (A) for χ₋₄ gives f(p) − f(3p) = ∓2(p − χ₋₄(p)). The left side lies in {0, ±2}, while the right side has absolute value at least 4. This is impossible, so f_{4p}(x) = B(x mod p).

**Step 3: consequences of (A_4), (B_p) and (C).**

- (A_4) gives f(p) = f(3p).
- (B_p) together with (C) gives f(N) + f(2p) + 2f(p) = 0. Hence f(2p) = f(N) = −f(p).
- They also give S_p + S_{2p} + S_{4p} = 0.

**Step 4: the conductor-p conditions.** These say that the function f_p + (2 − M₂)g + (2 − M₂)(2B) is constant on U_p. By Step 3 the constant is 0.

**Step 5: reduction mod 4 forces invariance under ×2.** Reducing the identity of Step 4 mod 4 gives f_p(u) = g(2u). Substituting back gives g(u) = B(2u) − 2B(u). Since g takes the values ±1, this forces B(2u) = B(u) and g = −B. It follows that f_p = −B.

**Step 6: the parity contradiction.** Condition (B₂) reads f(N) − f(p) + S_p − ΣB = 0. Substituting the relations above gives ΣB = f(N) = ±1. But ΣB is a sum of p − 1 terms equal to ±1, and p − 1 is even, so ΣB is even. This contradiction proves the proposition.

**Consistency with the computations.** CP-SAT reports N = 12, 20, 28, 44, 52, 68, 76, 92, 116, 124, 148, 164, 172, 188, … as infeasible, which agrees with the proposition.
