"""Describe a +-1 solution layer by layer: for each d | N, the function x -> f((N/d)x) on U_d,
   and its dependence (minimal modulus m | d such that f_d factors through U_d -> U_m)."""
import sys, json
from math import gcd
sys.path.insert(0, sys.argv[1])
from okada_even import divs, units, residue_of

def minimal_modulus(d, vals):
    # smallest m | d such that vals[x] depends only on x mod m
    for m in divs(d):
        ok = True
        seen = {}
        for x, v in vals.items():
            k = x % m if m > 1 else 0
            if k in seen and seen[k] != v:
                ok = False
                break
            seen[k] = v
        if ok:
            return m, seen
    return d, vals

N = int(sys.argv[2]); s = sys.argv[3]
f = {n: (1 if s[n - 1] == '+' else -1) for n in range(1, N + 1)}
for d in divs(N):
    vals = {x: f[residue_of(N, d, x)] for x in units(d)}
    m, red = minimal_modulus(d, vals)
    S = sum(vals.values())
    print(f"d={d:4d} |U_d|={len(vals):3d} S_d={S:4d} depends on x mod {m}: ", dict(sorted(red.items())) if m <= 60 else "")
