import sys, json
sys.path.insert(0, sys.argv[1])
from okada_even import solve_pm1, check_exact, L1_numeric
N = int(sys.argv[2]); maxs = int(sys.argv[3])
st, sols = solve_pm1(N, time_limit=float(sys.argv[4]), all_solutions=True, max_solutions=maxs)
print(N, st, len(sols))
strs = sorted("".join("+" if f[n] > 0 else "-" for n in range(1, N + 1)) for f in sols)
for s in strs[:40]:
    print(s)
json.dump(strs, open(sys.argv[5], "w"))
