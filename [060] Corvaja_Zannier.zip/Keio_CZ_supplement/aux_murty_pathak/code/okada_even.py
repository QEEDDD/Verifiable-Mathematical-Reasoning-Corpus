"""Exact Okada system for an arbitrary modulus N (even allowed), all residues 1..N.

Layer of a residue n (1 <= n <= N):  d = N / gcd(n, N),  n = (N/d) x,  x in U_d.
The residue N (i.e. 0) is the layer d = 1.

For f: Z/N -> Q with sum_{n=1}^N f(n) = 0,
  L(1,f) = (1/N) sum_{chi*} A_chi* L(1,chi*) - (1/N) sum_{p | N} B_p log p,
  A_chi* = sum_{m | d | N} (d/phi(d)) prod_{r | d, r not| m} (1 - chi*(r)/r) <f_d, chi*>,
  B_p    = sum_{d | N} S_d eps_p(d),  eps_p(d) = v_p(N/d) - [p | d]/(p-1)
(the layer d = 1 enters only B_p, with S_1 = f(N), eps_p(1) = v_p(N)).
By Okada's theorem L(1,f) = 0 iff all A_chi* = 0 and all B_p = 0.

After multiplying A_chi* by the non-zero constant prod_{p|N}(p-1) / prod_{r|m} r, the conditions
for all primitive chi* of conductor m are: the function on U_m
  H_m = sum_{m | d | N} c(d) prod_{r in S(d,m)} (r - M_r) pi_{d->m} f_d,
  c(d) = prod_{p | N, p not| d} (p-1),  S(d,m) = {r | d : r not| m},  (M_r h)(y) = h(r y),
has no component along primitive characters mod m.
"""
import sys
from math import gcd
from fractions import Fraction
import sympy


def fac(n):
    return dict(sympy.factorint(n))


def divs(n):
    return sorted(int(d) for d in sympy.divisors(n))


def units(m):
    if m == 1:
        return [0]
    return [x for x in range(1, m) if gcd(x, m) == 1]


def vp(n, p):
    k = 0
    while n % p == 0:
        n //= p
        k += 1
    return k


def crt_pair(a, m, b, n):
    t = ((b - a) * pow(m, -1, n)) % n
    return (a + m * t) % (m * n)


def residue_of(N, d, x):
    """residue in 1..N of the element (N/d) x"""
    r = ((N // d) * x) % N
    return N if r == 0 else r


def H_forms(N):
    P = fac(N)
    primes = sorted(P)
    D = [d for d in divs(N) if d > 1]
    out = {}
    for m in D:
        Um = units(m)
        Hm = {y: {} for y in Um}
        for d in D:
            if d % m:
                continue
            c = 1
            for p in primes:
                if d % p:
                    c *= (p - 1)
            S = [p for p in primes if d % p == 0 and m % p != 0]
            fib = {z: [] for z in Um}
            for x in units(d):
                fib[x % m].append(x)
            for mask in range(1 << len(S)):
                mT = 1
                coefT = c * (-1) ** bin(mask).count("1")
                for i, p in enumerate(S):
                    if mask >> i & 1:
                        mT *= p
                    else:
                        coefT *= p
                for y in Um:
                    z = (mT * y) % m
                    row = Hm[y]
                    for x in fib[z]:
                        n = residue_of(N, d, x)
                        row[n] = row.get(n, 0) + coefT
        for y in Um:
            Hm[y] = {n: v for n, v in Hm[y].items() if v}
        out[m] = Hm
    return out


def primitive_functionals(m):
    """Functionals (lists of (y, sign)) on functions on U_m cutting out exactly the
    primitive part; their number equals the number of primitive characters mod m."""
    P = fac(m)
    comps, mods = [], []
    for p, e in sorted(P.items()):
        mm = p ** e
        U = units(mm)
        if e == 1:
            base = {k: 1 for k in U}
        else:
            lower = p ** (e - 1)
            fibers = {}
            for k in U:
                fibers.setdefault(k % lower, []).append(k)
            base = {}
            for key, lst in fibers.items():
                b0 = min(lst)
                for k in lst:
                    base[k] = b0
        comps.append([(k, base[k]) for k in U if base[k] != k])
        mods.append(mm)
    res = []
    w = len(mods)

    def rec(i, cur):
        if i == w:
            terms = []
            for eps in range(1 << w):
                y, M, sign = 0, 1, 1
                for j in range(w):
                    k, b0 = cur[j]
                    val = b0 if (eps >> j & 1) else k
                    if eps >> j & 1:
                        sign = -sign
                    y = crt_pair(y, M, val, mods[j]) if M > 1 else val % mods[j]
                    M *= mods[j]
                terms.append((y, sign))
            res.append(terms)
            return
        for pair in comps[i]:
            cur.append(pair)
            rec(i + 1, cur)
            cur.pop()

    rec(0, [])
    return res


def system(N):
    """Integer linear forms row: dict n -> coef (n in 1..N); each must vanish on f."""
    P = fac(N)
    H = H_forms(N)
    rows, lab = [], []
    for m, Hm in H.items():
        for fn in primitive_functionals(m):
            row = {}
            for y, s in fn:
                for n, v in Hm[y].items():
                    row[n] = row.get(n, 0) + s * v
            row = {n: v for n, v in row.items() if v}
            if row:
                rows.append(row)
                lab.append(("A", m))
    for p, e in sorted(P.items()):
        row = {}
        for n in range(1, N + 1):
            v = min(vp(n, p), e)
            w = (p - 1) * v - (1 if v < e else 0)
            if w:
                row[n] = w
        rows.append(row)
        lab.append(("B", p))
    rows.append({n: 1 for n in range(1, N + 1)})
    lab.append(("C", 1))
    return rows, lab


def check_exact(N, f, rows=None):
    if rows is None:
        rows, _ = system(N)
    return all(sum(v * f[n] for n, v in row.items()) == 0 for row in rows)


def L1_numeric(N, f, dps=50):
    import mpmath
    mpmath.mp.dps = dps
    s = mpmath.mpf(0)
    for a in range(1, N + 1):
        if f[a]:
            s += f[a] * mpmath.digamma(mpmath.mpf(a) / N)
    return -s / N


def solve_pm1(N, time_limit=60.0, workers=8, extra=None, all_solutions=False, max_solutions=10**6):
    """CP-SAT: find f in {+-1}^N satisfying the system. Returns (status, list_of_solutions)."""
    from ortools.sat.python import cp_model
    rows, lab = system(N)
    model = cp_model.CpModel()
    b = {n: model.NewBoolVar(f"b{n}") for n in range(1, N + 1)}
    for row in rows:
        tot = sum(row.values())
        if tot % 2:
            return "INFEASIBLE_PARITY", []
        model.Add(sum(v * b[n] for n, v in row.items()) == tot // 2)
    if extra:
        extra(model, b)
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = time_limit
    solver.parameters.num_search_workers = workers if not all_solutions else 1
    sols = []
    if all_solutions:
        solver.parameters.enumerate_all_solutions = True

        class CB(cp_model.CpSolverSolutionCallback):
            def __init__(self):
                super().__init__()

            def on_solution_callback(self):
                sols.append({n: 1 - 2 * self.Value(b[n]) for n in range(1, N + 1)})
                if len(sols) >= max_solutions:
                    self.StopSearch()

        st = solver.Solve(model, CB())
    else:
        st = solver.Solve(model)
        if st in (cp_model.OPTIMAL, cp_model.FEASIBLE):
            sols.append({n: 1 - 2 * solver.Value(b[n]) for n in range(1, N + 1)})
    return solver.StatusName(st), sols


if __name__ == "__main__":
    N = int(sys.argv[1])
    st, sols = solve_pm1(N, time_limit=float(sys.argv[2]) if len(sys.argv) > 2 else 60)
    print(N, st)
    for f in sols:
        print("".join("+" if f[n] > 0 else "-" for n in range(1, N + 1)), check_exact(N, f), L1_numeric(N, f))
