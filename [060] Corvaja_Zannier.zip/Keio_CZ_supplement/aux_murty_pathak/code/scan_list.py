"""Scan a given list of N for existence of f: Z/N -> {+-1} with sum f = 0 and L(1,f) = 0."""
import sys, json, time
sys.path.insert(0, sys.argv[1])
from okada_even import solve_pm1, check_exact, L1_numeric

Ns = [int(x) for x in sys.argv[2].split(",")]
tl = float(sys.argv[3])
outfile = sys.argv[4]
workers = int(sys.argv[5]) if len(sys.argv) > 5 else 8
res = {}
for N in Ns:
    t0 = time.time()
    st, sols = solve_pm1(N, time_limit=tl, workers=workers)
    dt = time.time() - t0
    rec = {"status": st, "time": round(dt, 2)}
    if sols:
        f = sols[0]
        rec["f"] = "".join("+" if f[n] > 0 else "-" for n in range(1, N + 1))
        rec["exact"] = check_exact(N, f)
        rec["L1"] = float(abs(L1_numeric(N, f, dps=30)))
    res[N] = rec
    print(N, st, round(dt, 1), rec.get("exact", ""), rec.get("L1", ""), flush=True)
    with open(outfile, "w") as fh:
        json.dump(res, fh, indent=1)
