"""2-adic relaxation for the +-1 variant: is there a 2-integral rational solution f of the
Okada system (all residues 1..N) with every f(n) odd?

Method: integer kernel basis of the constraint matrix, 2-saturation (divide out mod-2 dependencies
until the rows are independent mod 2), then test whether the all-ones vector lies in the mod-2
row space.
"""
import sys
sys.path.insert(0, sys.argv[1])
from okada_even import system
import flint


def kernel_basis_int(N):
    rows, lab = system(N)
    M = flint.fmpz_mat(len(rows), N, [0] * (len(rows) * N))
    for i, row in enumerate(rows):
        for n, v in row.items():
            M[i, n - 1] = v
    # integer nullspace (columns span the rational kernel)
    X, nullity = M.nullspace()
    basis = []
    from math import gcd as igcd
    for j in range(nullity):
        vec = [int(X[i, j]) for i in range(N)]
        g = 0
        for v in vec:
            g = igcd(g, v)
        g = g if g else 1
        vec = [v // g for v in vec]
        basis.append(vec)
    return basis, M


def rank_mod2_and_dependency(vecs):
    """Gaussian elimination over F_2 on integer vectors; return (pivot rows, a dependency or None).
    A dependency is a list of indices whose sum is 0 mod 2."""
    n = len(vecs)
    m = len(vecs[0]) if n else 0
    # represent rows as Python ints (bitsets) together with combination masks
    rows = []
    for i, v in enumerate(vecs):
        bits = 0
        for j, x in enumerate(v):
            if x & 1:
                bits |= 1 << j
        rows.append([bits, 1 << i])
    pivots = {}
    for r in rows:
        b, comb = r
        while b:
            h = b.bit_length() - 1
            if h in pivots:
                pb, pc = pivots[h]
                b ^= pb
                comb ^= pc
            else:
                pivots[h] = (b, comb)
                break
        if b == 0:
            return None, [i for i in range(n) if comb >> i & 1]
    return pivots, None


def saturate(basis):
    vecs = [list(v) for v in basis]
    while True:
        piv, dep = rank_mod2_and_dependency(vecs)
        if dep is None:
            return vecs, piv
        s = [0] * len(vecs[0])
        for i in dep:
            for j, x in enumerate(vecs[i]):
                s[j] += x
        assert all(x % 2 == 0 for x in s)
        s = [x // 2 for x in s]
        # replace one of the dependent rows by s (keeps the Q-span, enlarges the lattice)
        vecs[dep[0]] = s


def ones_in_span(piv, N):
    b = (1 << N) - 1
    while b:
        h = b.bit_length() - 1
        if h in piv:
            b ^= piv[h][0]
        else:
            return False
    return True


if __name__ == "__main__":
    for N in [int(x) for x in sys.argv[2].split(",")]:
        basis, M = kernel_basis_int(N)
        vecs, piv = saturate(basis)
        print(N, "kernel dim", len(basis), "odd 2-integral solution exists:", ones_in_span(piv, N), flush=True)
