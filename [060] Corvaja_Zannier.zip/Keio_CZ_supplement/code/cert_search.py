"""Search for explicit covering certificates for the Corvaja-Zannier instance

    x^2 = t0 + a*2^m + b*3^n,   x in Q,  m, n in Z.

For a prime l > 3 not dividing ab, 2 and 3 are l-units, so the right side is l-integral and must be a
square (or 0) mod l; moreover 2^m mod l depends only on m mod ord_l(2), and 3^n mod l only on
n mod ord_l(3).  If E is a common multiple of all these orders for a set L of primes, the pair
(m mod E, n mod E) determines everything.  t0 is certified if every pair (mu, nu) in (Z/E)^2 is
"killed" by some l in L, i.e. t0 + a 2^mu + b 3^nu is a non-residue mod l.
A certificate depends only on t0 mod M = prod L, so it covers a whole residue class.

usage: python3 -I cert_search.py E a b t_lo t_hi out.json
"""
import sys, json, time
from math import gcd
import numpy as np
import sympy


def order(g, l):
    return int(sympy.n_order(g, l))


def primes_for(E, a, b):
    G = gcd(2 ** E - 1, 3 ** E - 1)
    ps = sorted(p for p in sympy.factorint(G) if p > 3 and (a % p) and (b % p))
    return ps


def setup(E, a, b):
    data = []
    for l in primes_for(E, a, b):
        o2, o3 = order(2, l), order(3, l)
        assert E % o2 == 0 and E % o3 == 0
        P2 = np.array([a * pow(2, m, l) % l for m in range(o2)], dtype=np.int64)
        P3 = np.array([b * pow(3, n, l) % l for n in range(o3)], dtype=np.int64)
        QR = np.zeros(l, dtype=bool)
        QR[[(i * i) % l for i in range(l)]] = True
        data.append((l, o2, o3, P2, P3, QR))
    # sort by kill power: small orders first
    data.sort(key=lambda d: (d[1] * d[2], d[0]))
    return data


def certify(t0, E, data, want_witness=False):
    alive = np.ones((E, E), dtype=bool)
    used = []
    for (l, o2, o3, P2, P3, QR) in data:
        vals = (t0 + P2[:, None] + P3[None, :]) % l
        killed = ~QR[vals]
        if not killed.any():
            continue
        K = np.tile(killed, (E // o2, E // o3))
        before = alive.sum()
        alive &= ~K
        if alive.sum() < before:
            used.append(l)
        if not alive.any():
            return True, used
    return False, int(alive.sum())


if __name__ == "__main__":
    E, a, b, lo, hi = (int(x) for x in sys.argv[1:6])
    out = sys.argv[6]
    t = time.time()
    data = setup(E, a, b)
    print("E", E, "primes", [d[0] for d in data], flush=True)
    res = {"E": E, "a": a, "b": b, "primes": [d[0] for d in data], "certified": {}, "failed": {}}
    for t0 in range(lo, hi + 1):
        ok, info = certify(t0, E, data)
        if ok:
            res["certified"][t0] = info
        else:
            res["failed"][t0] = info
    print("certified", len(res["certified"]), "of", hi - lo + 1, "time", round(time.time() - t, 1))
    print("certified t0:", sorted(res["certified"])[:80])
    json.dump(res, open(out, "w"), indent=1)
