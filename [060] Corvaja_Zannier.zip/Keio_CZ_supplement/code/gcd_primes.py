"""All prime factors l > 3 of gcd(2^E - 1, 3^E - 1): trial division by primes with 2^E = 3^E = 1 mod l,
then check that the cofactor is 1 (complete factorisation).  Exact bound E^2 prod (l+1)/(2l).
usage: python3 -I gcd_primes.py E bound out.json"""
import sys, json
from math import gcd
from fractions import Fraction
import sympy
E = int(sys.argv[1]); B = int(sys.argv[2])
g = gcd(2 ** E - 1, 3 ** E - 1)
cof = g
L = []
for l in sympy.primerange(2, B):
    if cof % l == 0:
        L.append(int(l))
        while cof % l == 0:
            cof //= l
print("digits of gcd:", len(str(g)), "number of prime factors found:", len(L), "cofactor:", cof)
assert cof == 1, "factorisation incomplete"
L = [l for l in L if l > 3]
for l in L:
    assert pow(2, E, l) == 1 and pow(3, E, l) == 1
P = Fraction(1)
for l in L:
    P *= Fraction(l + 1, 2 * l)
bound = E * E * P
print("primes >3:", len(L), "largest:", max(L), "bound:", float(bound))
extra = [l for l in L if E % (l - 1)]
print("primes with l-1 not dividing E:", extra)
json.dump({"E": E, "primes": L, "bound_float": float(bound), "bound_num": str(bound.numerator), "bound_den": str(bound.denominator)}, open(sys.argv[3], "w"), indent=1)
