"""Primes l > 3 with ord_l(2) | E and ord_l(3) | E, i.e. the prime factors of gcd(2^E-1, 3^E-1)
other than 2, 3; also the subset with l-1 | E (Prachar-type primes)."""
import sys
from math import gcd
import sympy

def lam(E, gens=(2, 3)):
    g = 0
    for a in gens:
        g = gcd(g, a ** E - 1)
    fac = sympy.factorint(g)
    ps = sorted(p for p in fac if all(p % a for a in gens))
    return ps, g

if __name__ == "__main__":
    for E in [int(x) for x in sys.argv[1].split(",")]:
        ps, g = lam(E)
        shifted = [p for p in ps if E % (p - 1) == 0]
        print(E, "num primes", len(ps), "with l-1|E:", len(shifted), "primes:", ps[:60])
