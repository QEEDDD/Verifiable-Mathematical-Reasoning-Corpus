"""Empirical check of the density statement: certify random large t0 with exponent E.
usage: python3 -I random_check.py codedir E a b count seed lo hi out.json"""
import sys, json, random, time
sys.path.insert(0, sys.argv[1])
from cert_search import setup, certify
E, a, b, cnt, seed = (int(x) for x in sys.argv[2:7])
lo, hi = int(float(sys.argv[7])), int(float(sys.argv[8]))
rng = random.Random(seed)
data = setup(E, a, b)
ok = 0; res = []
t = time.time()
for i in range(cnt):
    t0 = rng.randrange(lo, hi)
    c, info = certify(t0, E, data)
    ok += c
    res.append((t0, bool(c), info if not c else len(info)))
print(f"E={E} a={a} b={b}: certified {ok}/{cnt} random t0 in [{lo},{hi}); time {time.time()-t:.1f}s")
json.dump({"E": E, "a": a, "b": b, "seed": seed, "results": res}, open(sys.argv[9], "w"))
