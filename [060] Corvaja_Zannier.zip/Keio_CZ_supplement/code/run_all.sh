#!/bin/sh
# Reproduce all computations of the paper (about 15 minutes on one core).
# Run from the supplement root:  sh code/run_all.sh
set -e
mkdir -p out logs
C=code
python3 -I $C/lam.py 12,24,36,48,60,72,120,144,180,240,360,720,1440,2520,5040,10080 > logs/00_primes_for_E.txt
# Theorem B(1): all prime factors of gcd(2^E-1,3^E-1), E = 1441440, exact bound
python3 -I $C/gcd_primes.py 1441440 3000000 out/gcd_primes_1441440.json > logs/01_gcd_primes_bound.txt
# earlier (weaker) variant with the 108 primes below 2*10^5, and E = 5040 comparison bound
python3 -I $C/union_bound.py 1441440 200000 "1,1;1,-1;-1,-1;2,3" out/union_bound_1441440_108primes.json > logs/01b_union_bound_108primes.txt
python3 -I $C/union_bound.py 5040 200000 "1,1" out/union_bound_5040.json >> logs/01b_union_bound_108primes.txt
# Theorem B(2): certificate search and independent verification
python3 -I $C/cert_search.py 2520 1 1 -30 60 out/cert_2520_11.json > logs/03_cert_search_2520.txt
python3 -I $C/cert_search.py 5040 1 1 -50 100 out/cert_5040_11.json > logs/04_cert_search_5040.txt
python3 -I -c "
import json
c2=json.load(open('out/cert_5040_11.json'))
certs=[{'t0':58,'a':1,'b':1,'primes':[5,7,11,13,19,29,31,37,41,43,61,73,127,181,211,281,337,421,631,1009]}]
for t in ['-44','-38','-14','100']:
    certs.append({'t0':int(t),'a':1,'b':1,'primes':sorted(c2['certified'][t])})
json.dump(certs, open('out/certificates.json','w'), indent=1)
"
python3 -I $C/verify_cert.py out/certificates.json > logs/02_verify_certificates.txt
# Theorem B(3): complete decision of [-50,100]
python3 -I $C/small_decide.py -50 100 12 out/small_decide.json > logs/06_small_decide.txt
# sanity check (not used in proofs)
python3 -I $C/random_check.py "$PWD/$C" 5040 1 1 100 2026 1e15 1e16 out/random_5040_11.json > logs/05_random_check.txt
echo done
