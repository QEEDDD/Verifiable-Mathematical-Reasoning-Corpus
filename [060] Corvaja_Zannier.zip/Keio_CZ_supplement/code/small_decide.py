"""Decide every t0 in a range for x^2 = t0 + 2^m + 3^n (x in Q, m, n in Z):
either exhibit a representation with |m|, |n| <= K, or report it (to be covered by a certificate).
usage: python3 -I small_decide.py lo hi K out.json"""
import sys, json
from fractions import Fraction
from math import isqrt
lo, hi, K = (int(v) for v in sys.argv[1:4])
def is_rat_square(q):
    if q < 0:
        return False
    a, b = q.numerator, q.denominator
    ra, rb = isqrt(a), isqrt(b)
    return ra * ra == a and rb * rb == b
pw2 = {m: Fraction(2) ** m for m in range(-K, K + 1)}
pw3 = {n: Fraction(3) ** n for n in range(-K, K + 1)}
res = {}
for t0 in range(lo, hi + 1):
    best = None
    for s in range(0, K + 1):            # search by increasing max(|m|,|n|)
        for m in range(-s, s + 1):
            for n in range(-s, s + 1):
                if max(abs(m), abs(n)) != s:
                    continue
                V = t0 + pw2[m] + pw3[n]
                if is_rat_square(V):
                    best = (m, n, str(V))
                    break
            if best: break
        if best: break
    res[t0] = best
unrep = [t for t, v in res.items() if v is None]
print(f"t0 in [{lo},{hi}], K={K}: represented {sum(v is not None for v in res.values())}, not found: {unrep}")
print("max height needed:", max(max(abs(v[0]), abs(v[1])) for v in res.values() if v))
json.dump({str(k): v for k, v in res.items()}, open(sys.argv[4], "w"), indent=1)
