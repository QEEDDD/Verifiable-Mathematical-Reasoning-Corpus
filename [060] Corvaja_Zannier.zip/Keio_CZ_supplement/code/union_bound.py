"""Exact explicit density bound (Theorem C(i)).

For a, b in Z\\{0} and an exponent E, let L be a set of primes l > 3, l not dividing ab, with
2^E = 1 and 3^E = 1 mod l.  Then the set of t in Z for which t + a 2^m + b 3^n is a rational square
for some m, n in Z is contained in a union of residue classes modulo M = prod L whose density is at
most  E^2 * prod_{l in L} (l+1)/(2l).

This script builds L = {l : l-1 | E} union {extra primes up to a bound with both orders | E},
re-verifies every l (primality, l not | 6ab, 2^E = 3^E = 1 mod l), and prints the bound exactly.

usage: python3 -I union_bound.py E extra_bound "a,b;a,b;..." out.json
"""
import sys, json
from fractions import Fraction
import sympy


def primes_for(E, extra_bound, a, b):
    L = set()
    for d in sympy.divisors(E):
        l = int(d) + 1
        if l > 3 and sympy.isprime(l):
            L.add(l)
    for l in sympy.primerange(5, extra_bound):
        if pow(2, E, l) == 1 and pow(3, E, l) == 1:
            L.add(int(l))
    L = sorted(l for l in L if (a % l) and (b % l))
    for l in L:  # independent re-verification
        assert sympy.isprime(l) and l > 3 and a % l and b % l
        assert pow(2, E, l) == 1 and pow(3, E, l) == 1
    return L


if __name__ == "__main__":
    E = int(sys.argv[1]); extra = int(sys.argv[2])
    pairs = [tuple(int(v) for v in p.split(",")) for p in sys.argv[3].split(";")]
    out = {}
    for (a, b) in pairs:
        L = primes_for(E, extra, a, b)
        P = Fraction(1)
        for l in L:
            P *= Fraction(l + 1, 2 * l)
        bound = E * E * P
        # a clean decimal upper bound  m * 10^(-k) with 1 <= m < 10, rounded up to one decimal
        k = 0
        while bound * 10 ** k < 1:
            k += 1
        mant = bound * 10 ** k            # in [1, 10)
        ub = (int(mant * 10) + 1) / 10.0
        assert Fraction(int(ub * 10), 10) / 10 ** k > bound
        print(f"E={E} (a,b)=({a},{b}) |L|={len(L)} bound={float(bound):.4e} < {ub}e-{k}")
        out[f"{a},{b}"] = {"E": E, "num_primes": len(L), "primes": L,
                          "bound_num": str(bound.numerator), "bound_den": str(bound.denominator),
                          "bound_float": float(bound), "decimal_upper": f"{ub}e-{k}"}
    json.dump(out, open(sys.argv[4], "w"), indent=1)
