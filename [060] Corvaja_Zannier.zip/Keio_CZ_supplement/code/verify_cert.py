"""Independent (pure Python, no numpy) verification of covering certificates (Theorem C(ii)).

A certificate is (t0, a, b, [l_1, ..., l_s]) with primes l_i > 3, l_i not | ab.  Let o2, o3 be the
orders of 2, 3 mod l, and E = lcm of all o2, o3.  The certificate is valid iff for every
(mu, nu) in (Z/E)^2 some l_i has  (t0 + a 2^mu + b 3^nu  mod l_i)  a quadratic NON-residue (nonzero).
Then for every integer t = t0 (mod prod l_i) and all m, n in Z, t + a 2^m + b 3^n is not a square in Q.

usage: python3 -I verify_cert.py certs.json
"""
import sys, json
from math import gcd


def is_prime(n):
    if n < 2:
        return False
    i = 2
    while i * i <= n:
        if n % i == 0:
            return False
        i += 1
    return True


def order(g, l):
    k, x = 1, g % l
    while x != 1:
        x = x * g % l
        k += 1
    return k


def lcm(a, b):
    return a // gcd(a, b) * b


def verify(t0, a, b, primes):
    tables = []
    E = 1
    for l in primes:
        assert is_prime(l) and l > 3 and a % l and b % l
        o2, o3 = order(2, l), order(3, l)
        E = lcm(E, lcm(o2, o3))
        squares = set((i * i) % l for i in range(l))
        p2 = [a * pow(2, m, l) % l for m in range(o2)]
        p3 = [b * pow(3, n, l) % l for n in range(o3)]
        killed = [[((t0 + p2[i] + p3[j]) % l) not in squares for j in range(o3)] for i in range(o2)]
        tables.append((o2, o3, killed))
    # sort tables by size (cheap, strong primes first)
    tables.sort(key=lambda T: T[0] * T[1])
    bad = 0
    for mu in range(E):
        rows = [(T[2][mu % T[0]], T[1]) for T in tables]
        for nu in range(E):
            for row, o3 in rows:
                if row[nu % o3]:
                    break
            else:
                bad += 1
                if bad <= 3:
                    print("  uncovered class", (mu, nu))
    return E, bad


if __name__ == "__main__":
    certs = json.load(open(sys.argv[1]))
    allok = True
    for c in certs:
        E, bad = verify(c["t0"], c["a"], c["b"], c["primes"])
        M = 1
        for l in c["primes"]:
            M *= l
        ok = (bad == 0)
        allok &= ok
        print(f"t0={c['t0']} a={c['a']} b={c['b']} #primes={len(c['primes'])} E={E} "
              f"classes={E*E} uncovered={bad} -> {'VALID' if ok else 'INVALID'}; M={M}", flush=True)
    print("ALL VALID" if allok else "SOME INVALID")
