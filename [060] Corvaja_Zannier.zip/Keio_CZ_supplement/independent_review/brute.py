# Brute force: is t0 + 2^m + 3^n the square of a rational for some m,n in a box (negative allowed)?
import sys
from fractions import Fraction
from math import isqrt

def is_rat_square(q: Fraction) -> bool:
    if q < 0:
        return False
    a, b = q.numerator, q.denominator      # lowest terms, b>0
    ra, rb = isqrt(a), isqrt(b)
    return ra * ra == a and rb * rb == b

def solutions(t0, mbox, nbox):
    p2 = {m: Fraction(2) ** m for m in range(-mbox, mbox + 1)}
    p3 = {n: Fraction(3) ** n for n in range(-nbox, nbox + 1)}
    out = []
    for m, u in p2.items():
        for n, v in p3.items():
            s = t0 + u + v
            if is_rat_square(s):
                out.append((m, n, s))
    return out

if __name__ == "__main__":
    # 1) the five certificate values: big box
    for t0 in (58, -44, -38, -14, 100):
        sol = solutions(t0, 160, 100)
        print(f"t0={t0}: solutions with |m|<=160, |n|<=100: {sol}")
    # 2) t0=-1 and a few others
    for t0 in (-1, 0, 57, 59):
        sol = solutions(t0, 40, 25)
        print(f"t0={t0}: {len(sol)} solutions with |m|<=40,|n|<=25; first few: {sol[:4]}")
    # 3) scan -50..100 with a moderate box; record t0 with no solution found
    nosol = []
    for t0 in range(-50, 101):
        if not solutions(t0, 40, 26):
            nosol.append(t0)
    print("t0 in [-50,100] with NO solution for |m|<=40,|n|<=26:", nosol)
