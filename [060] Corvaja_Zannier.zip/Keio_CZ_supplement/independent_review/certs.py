# Independent verification of the covering certificates of Theorem C(2) (Table 1).
# (t0,P) is a certificate iff for every (mu,nu) in (Z/E_P)^2 some l in P has
# t0 + 2^mu + 3^nu a NONZERO quadratic non-residue mod l.
import sys, time
from math import lcm, prod
import numpy as np
from sympy import n_order, isprime

BASE44 = [5, 7, 11, 13, 17, 19, 29, 31, 37, 41, 43, 61, 71, 73, 97, 113, 127, 181, 211, 241, 281,
          337, 421, 577, 631, 673]
TABLE = {
    58: ([5, 7, 11, 13, 19, 29, 31, 37, 41, 43, 61, 71, 73, 127, 181, 211, 241, 281, 337, 421, 631, 1009], 22, 2520),
    -44: (BASE44, 26, 5040),
    -38: ([l for l in BASE44 if l != 211], 25, 5040),
    -14: (BASE44, 26, 5040),
    100: (BASE44 + [3361], 27, 5040),
}

def nonres_table(l):
    """killed[r] = True iff r is a nonzero quadratic non-residue mod l (Euler criterion)."""
    return np.array([r != 0 and pow(r, (l - 1) // 2, l) == l - 1 for r in range(l)], dtype=bool)

def EP_of(P):
    return lcm(*[lcm(int(n_order(2, l)), int(n_order(3, l))) for l in P])

def check_numpy(t0, P):
    """Return number of (mu,nu) in (Z/E_P)^2 NOT killed by any l in P."""
    EP = EP_of(P)
    mu = np.arange(EP)
    alive = np.ones((EP, EP), dtype=bool)
    for l in P:
        o2, o3 = int(n_order(2, l)), int(n_order(3, l))
        p2 = np.array([pow(2, i, l) for i in range(o2)], dtype=np.int64)
        p3 = np.array([pow(3, j, l) for j in range(o3)], dtype=np.int64)
        small = nonres_table(l)[(t0 + p2[:, None] + p3[None, :]) % l]   # shape (o2,o3)
        alive &= ~small[np.ix_(mu % o2, mu % o3)]
    return int(alive.sum()), EP

def check_pure(t0, P):
    """Pure-Python double loop over all E_P^2 classes with early exit; uses Legendre via Euler."""
    EP = EP_of(P)
    data = []
    for l in P:
        o2, o3 = int(n_order(2, l)), int(n_order(3, l))
        sq = set((x * x) % l for x in range(l))      # squares incl. 0
        data.append((l, [pow(2, i % o2, l) for i in range(EP)], [pow(3, j % o3, l) for j in range(EP)], sq))
    bad = 0
    for i in range(EP):
        rows = [(l, p2[i] + t0, p3, sq) for (l, p2, p3, sq) in data]
        for j in range(EP):
            for (l, a, p3, sq) in rows:
                if (a + p3[j]) % l not in sq:
                    break
            else:
                bad += 1
    return bad, EP

if __name__ == "__main__":
    which = [int(a) for a in sys.argv[1:] if a.lstrip('-').isdigit()]
    pure = "--pure" in sys.argv
    for t0 in which:
        P, nP, EPclaim = TABLE[t0]
        assert all(isprime(l) and l > 3 for l in P)
        M = prod(P)
        print(f"t0={t0}: |P|={len(P)} (claimed {nP}), E_P={EP_of(P)} (claimed {EPclaim}), "
              f"prod P has {len(str(M))} digits", flush=True)
        t = time.time()
        nb, EP = check_numpy(t0, P)
        print(f"   numpy: uncovered classes = {nb} of {EP*EP}  ({time.time()-t:.1f}s)", flush=True)
        if pure:
            t = time.time()
            nb2, _ = check_pure(t0, P)
            print(f"   pure-python: uncovered classes = {nb2}  ({time.time()-t:.1f}s)", flush=True)
    if "--m58" in sys.argv:
        M58 = 5*7*11*13*19*29*31*37*41*43*61*71*73*127*181*211*241*281*337*421*631*1009
        print("M_58 =", M58, "digits:", len(str(M58)))
