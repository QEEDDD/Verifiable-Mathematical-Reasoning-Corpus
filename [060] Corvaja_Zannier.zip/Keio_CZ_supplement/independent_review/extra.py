import sys
sys.path.insert(0, "/tmp/claude-0/-home-claude/5ad56b25-3dae-5235-9aee-21861d660576/scratchpad/cz_review")
from fractions import Fraction
from math import prod
from thmC1 import bound, PAPER
from certs import check_numpy, TABLE, EP_of
L5 = [5,7,11,13,17,19,29,31,37,41,43,61,71,73,97,113,127,181,211,241,281,337,421,577,631,673,1009,2017,2521,3361,13441]
v, n = bound(5040, L5); print("E=5040 bound, 31 primes: %.8f" % float(v))
FULL = PAPER + [270271, 332641, 411841, 576577, 960961, 1921921]
v, n = bound(1441440, FULL); print("E=1441440, all %d admissible primes: %.6e" % (n, float(v)))
# greedy shrink of the t0=58 certificate (largest primes first)
P = list(TABLE[58][0])
for l in sorted(P, reverse=True):
    Q = [q for q in P if q != l]
    if check_numpy(58, Q)[0] == 0:
        P = Q
print("greedy-reduced 58-certificate:", len(P), "primes", P, "E_P =", EP_of(P), "modulus digits:", len(str(prod(P))))
