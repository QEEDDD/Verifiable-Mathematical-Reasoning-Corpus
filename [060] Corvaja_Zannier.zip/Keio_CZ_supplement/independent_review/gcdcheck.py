# Completeness of admissible prime sets: G = gcd(2^E-1, 3^E-1); divide out the primes found.
import sys, time
from math import gcd
from sympy import primerange, isprime

def admissible_complete(E, bound):
    t = time.time()
    G = gcd(2**E - 1, 3**E - 1)
    small = [l for l in primerange(2, bound) if G % l == 0]
    C = G
    for l in small:
        while C % l == 0:
            C //= l
    print(f"E={E}: gcd has {len(str(G))} digits, computed in {time.time()-t:.1f}s; primes<{bound} dividing it:",
          len(small), small)
    print("  cofactor after removing them:", C if C < 10**30 else f"<{len(str(C))} digits>",
          "is 1" if C == 1 else ("prime" if isprime(C) else "composite/unknown"))
    return small, C

if __name__ == "__main__":
    for E in map(int, sys.argv[1:]):
        admissible_complete(E, 2 * 10**6)
