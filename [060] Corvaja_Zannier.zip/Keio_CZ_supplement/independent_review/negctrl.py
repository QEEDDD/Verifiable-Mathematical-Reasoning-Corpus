# Negative controls for the certificate checker (must report uncovered classes).
import sys
sys.path.insert(0, "/tmp/claude-0/-home-claude/5ad56b25-3dae-5235-9aee-21861d660576/scratchpad/cz_review")
from certs import check_numpy, check_pure, TABLE
P58 = TABLE[58][0]
for t0 in (-1, 57, 59, 0, 2):
    print("t0=%d with P58: uncovered (numpy, pure) =" % t0, check_numpy(t0, P58)[0], check_pure(t0, P58)[0])
# minimality of the 58-certificate: drop each prime in turn
drops = {l: check_numpy(58, [q for q in P58 if q != l])[0] for l in P58}
print("58: uncovered classes after dropping one prime:", drops)
