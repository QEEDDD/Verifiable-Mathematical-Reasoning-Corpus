# Second pass: parse the revised cz_squares.tex and re-verify Theorem B(1), B(2) data with own code.
import re, sys
sys.path.insert(0, "/tmp/claude-0/-home-claude/5ad56b25-3dae-5235-9aee-21861d660576/scratchpad/cz_review")
from fractions import Fraction
from math import gcd, prod
from sympy import isprime, primerange
from certs import check_numpy, check_pure, EP_of
TEX = open("/tmp/claude-0/-home-claude/5ad56b25-3dae-5235-9aee-21861d660576/scratchpad/cz/paper/cz_squares.tex").read()
# --- B(1): the 114-prime list in the quote environment of Section 4
q = re.search(r"\\begin\{quote\}\\small\s*(.*?)\.\s*\\end\{quote\}", TEX, re.S).group(1)
L = [int(s) for s in q.replace("\n", " ").split(",")]
E = 1441440
print("parsed list: %d entries, sorted & distinct: %s" % (len(L), L == sorted(set(L))))
g = gcd(2**E - 1, 3**E - 1)
mine = [p for p in primerange(2, 3 * 10**6) if g % p == 0]
cof = g
for p in mine:
    while cof % p == 0: cof //= p
print("g digits:", len(str(g)), "| my prime factors (<3e6):", len(mine), "| cofactor:", cof)
print("paper list == prime factors of g:", L == mine, "| all prime, >3:", all(isprime(p) and p > 3 for p in L))
print("g squarefree:", prod(mine) == g)
div = [p for p in L if E % (p - 1) == 0]; nd = [p for p in L if E % (p - 1)]
print("(l-1)|E: %d ; (l-1)!|E: %d, from %d to %d" % (len(div), len(nd), min(nd), max(nd)))
print("orders of 2,3 divide E for all l:", all(pow(2, E, p) == 1 and pow(3, E, p) == 1 for p in L))
v = Fraction(E * E) * prod(Fraction(p + 1, 2 * p) for p in L)
print("E^2*prod = %.6e  < 2.7e-22: %s" % (float(v), v < Fraction(27, 10**23)))
v108 = Fraction(E * E) * prod(Fraction(p + 1, 2 * p) for p in L if p < 2 * 10**5)
print("108-prime (<2e5) bound: %.4e (count %d)" % (float(v108), sum(p < 2e5 for p in L)))
print("gcd(2^n-1,3^n-1) prime to 6 for n=1..50:", all(gcd(gcd(2**n - 1, 3**n - 1), 6) == 1 for n in range(1, 51)))
# --- B(2): M_58 in the theorem statement vs Table 1
mth = re.search(r"Let \$M_\{58\}=(.*?)\$", TEX).group(1)
P_thm = [int(s) for s in mth.split(r"\cdot")]
row = re.search(r"\$58\$ & (\d+) & (\d+) & ([0-9, ]+)\\\\", TEX)
P_tab = [int(s) for s in row.group(3).split(",")]
print("theorem list == table list:", P_thm == P_tab, "| |P| =", len(P_tab), "(table says", row.group(1) + ")",
      "| E_P =", EP_of(P_tab), "(table says", row.group(2) + ")")
M58 = prod(P_thm); print("M_58 =", M58, "digits:", len(str(M58)))
print("58-certificate uncovered classes: numpy", check_numpy(58, P_tab)[0], "| pure", check_pure(58, P_tab)[0])
