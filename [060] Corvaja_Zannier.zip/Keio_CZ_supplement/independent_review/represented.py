# For each t0 in [-50,100] find one (m,n,x) with t0 + 2^m + 3^n = x^2 (x rational), smallest max(|m|,|n|),
# and re-verify with pure integer arithmetic: (t0*2^A*3^B + 2^(m+A)*3^B + 3^(n+B)) == X^2 * (2^a*3^b)^2 style check.
from fractions import Fraction
from math import isqrt
def find(t0, R=40):
    for r in range(0, R + 1):                       # increasing box radius
        for m in range(-r, r + 1):
            for n in range(-r, r + 1):
                if max(abs(m), abs(n)) != r: continue
                s = Fraction(t0) + Fraction(2) ** m + Fraction(3) ** n
                if s >= 0:
                    a, b = s.numerator, s.denominator
                    if isqrt(a) ** 2 == a and isqrt(b) ** 2 == b:
                        return m, n, Fraction(isqrt(a), isqrt(b))
    return None
def verify(t0, m, n, x):
    # integer check: multiply by D = 2^max(0,-m) * 3^max(0,-n) squared-compatible denominator
    A, B = max(0, -m), max(0, -n)
    lhs = t0 * 2**A * 3**B + 2**(m + A) * 3**B + 3**(n + B) * 2**A
    return Fraction(lhs, 2**A * 3**B) == x * x
hard = []
fails = []
for t0 in range(-50, 101):
    r = find(t0)
    if r is None:
        fails.append(t0); continue
    m, n, x = r
    assert verify(t0, m, n, x), (t0, r)
    hard.append((max(abs(m), abs(n)), t0, m, n, x))
print("no solution found (box 40):", fails)
hard.sort(reverse=True)
print("hardest represented t0 (max(|m|,|n|), t0, m, n, x):")
for h in hard[:8]: print("  ", h[0], h[1], h[2], h[3], h[4])
print("t0=-1:", find(-1), " t0=58:", find(58))
