# Which t0 admit a certificate with E=5040 (i.e. using the full set of 31 admissible primes)?
# t0 has a certificate iff every (mu,nu) in (Z/5040)^2 is killed by some admissible prime.
import sys, random, time
import numpy as np
from sympy import n_order

E = 5040
PR = [5, 7, 11, 13, 17, 19, 29, 31, 37, 41, 43, 61, 71, 73, 97, 113, 127, 181, 211, 241, 281, 337,
      421, 577, 631, 673, 1009, 2017, 2521, 3361, 13441]   # complete list (gcd check)
INFO = []
for l in PR:
    o2, o3 = int(n_order(2, l)), int(n_order(3, l))
    assert E % o2 == 0 and E % o3 == 0
    nonres = np.array([r != 0 and pow(r, (l - 1) // 2, l) == l - 1 for r in range(l)], dtype=bool)
    p2 = np.array([pow(2, i, l) for i in range(o2)], dtype=np.int64)
    p3 = np.array([pow(3, j, l) for j in range(o3)], dtype=np.int64)
    INFO.append((l, o2, o3, nonres, p2, p3))
MU = np.arange(E)

def survivors(t0):
    """number of uncovered classes (mu,nu) mod 5040 for t0 (0 <=> certificate exists)."""
    alive = None
    idx = None
    for (l, o2, o3, nonres, p2, p3) in INFO:
        small = nonres[(t0 % l + p2[:, None] + p3[None, :]) % l]
        if idx is None:
            k = small[np.ix_(MU % o2, MU % o3)]
            alive = ~k if alive is None else (alive & ~k)
            if alive.sum() < 200000:
                idx = np.nonzero(alive)
        else:
            i, j = idx
            keep = ~small[i % o2, j % o3]
            idx = (i[keep], j[keep])
            if len(idx[0]) == 0:
                return 0
    return int(alive.sum()) if idx is None else len(idx[0])

if __name__ == "__main__":
    t = time.time()
    res = {t0: survivors(t0) for t0 in range(-50, 101)}
    cert = [t0 for t0, s in res.items() if s == 0]
    print("t0 in [-50,100] with E=5040 certificate:", cert, f"({time.time()-t:.0f}s)", flush=True)
    rng = random.Random(int(sys.argv[1]) if len(sys.argv) > 1 else 12345)
    N = int(sys.argv[2]) if len(sys.argv) > 2 else 400
    t = time.time()
    ok = sum(survivors(rng.randrange(10**15, 10**16)) == 0 for _ in range(N))
    print(f"random t0 in [1e15,1e16): {ok}/{N} have an E=5040 certificate ({time.time()-t:.0f}s)")
