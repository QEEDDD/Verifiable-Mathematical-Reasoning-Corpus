# Independent check of Theorem C(1) (printed as Theorem B(1) in the PDF).
# Recompute: primes l>3 with (l-1)|E (no size limit), primes l<2e5 with 2^E=3^E=1 mod l,
# compare with the paper's list of 108 primes, and evaluate E^2*prod (l+1)/(2l) exactly.
from fractions import Fraction
from math import gcd, prod
from sympy import isprime, divisors, factorint, primerange

PAPER = [5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 53, 61, 67, 71, 73, 79, 89, 97, 113, 127,
         131, 157, 181, 193, 199, 211, 241, 281, 313, 331, 337, 353, 397, 421, 463, 521, 547, 577,
         617, 631, 661, 673, 859, 881, 911, 937, 991, 1009, 1093, 1171, 1249, 1321, 1873, 2003,
         2017, 2081, 2113, 2311, 2341, 2521, 2731, 2861, 2971, 3121, 3169, 3361, 3433, 3697, 4621,
         5281, 6007, 6337, 6553, 7393, 7489, 8009, 8191, 8581, 8737, 9241, 13441, 13729, 14561,
         16381, 18481, 20021, 20161, 20593, 21841, 24571, 25741, 26209, 27457, 36037, 37441, 48049,
         51481, 55441, 65521, 72073, 96097, 110881, 120121, 131041, 180181, 192193]

def admissible(E, bound):
    """primes 3<l<bound with 2^E = 3^E = 1 mod l"""
    return [l for l in primerange(5, bound) if pow(2, E, l) == 1 and pow(3, E, l) == 1]

def report(E, bound, paper=None):
    print(f"=== E = {E} = {factorint(E)} ===")
    divs = [d + 1 for d in divisors(E) if isprime(d + 1) and d + 1 > 3]
    print("#primes l>3 with (l-1)|E (any size):", len(divs), " max:", max(divs))
    big = [p for p in divs if p >= bound]
    print("  of these >= bound", bound, ":", big)
    adm = admissible(E, bound)
    extra = [l for l in adm if E % (l - 1) != 0]
    print(f"#admissible primes < {bound}:", len(adm), "; with (l-1)!|E:", len(extra), extra)
    L = sorted(set(adm) | set(divs))
    print("#L (admissible <bound  U  (l-1)|E):", len(L))
    if paper is not None:
        print("paper list length:", len(paper), "sorted/distinct:", paper == sorted(set(paper)))
        print("paper - mine:", sorted(set(paper) - set(L)), " mine - paper:", sorted(set(L) - set(paper)))
        bad = [l for l in paper if not (isprime(l) and pow(2, E, l) == 1 and pow(3, E, l) == 1)]
        print("listed primes failing primality or 2^E=3^E=1:", bad)
    return L

def bound(E, L, remove=()):
    Ls = [l for l in L if l not in remove]
    val = Fraction(E * E) * prod(Fraction(l + 1, 2 * l) for l in Ls)
    return val, len(Ls)

if __name__ == "__main__":
    E = 1441440
    L = report(E, 200000, PAPER)
    for ab, rem in [((1, 1), ()), ((1, -1), ()), ((-1, -1), ()), ((2, 3), ()), ((5, -7), (5, 7))]:
        v, n = bound(E, PAPER, rem)
        print(f"(a,b)={ab}: |L|={n}, E^2*prod = {float(v):.6e}  (<1.8e-20: {v < Fraction(18, 10**21)},"
              f" <5.1e-20: {v < Fraction(51, 10**21)})")
    v, _ = bound(E, PAPER)
    print("exact value numerator digits:", len(str(v.numerator)), "denominator digits:", len(str(v.denominator)))
    # E = 5040 (remark 'Small versus large t0'): 31 admissible primes, bound 0.0271
    L5 = report(5040, 10**6)
    print("E=5040 admissible primes (<1e6):", L5)
    v5, n5 = bound(5040, L5)
    print(f"E=5040: |L|={n5}, bound = {float(v5):.6f}")
    # also E=2520
    L25 = report(2520, 10**6)
    print("E=2520 admissible primes (<1e6):", L25)
    v25, n25 = bound(2520, L25)
    print(f"E=2520: |L|={n25}, bound = {float(v25):.6f}")
