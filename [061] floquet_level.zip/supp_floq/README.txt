Supplement to: Keio, "Floquet isospectrality to the discrete Laplacian: level-set
degenerations, period lattices and node coordinates" (October 2026).

Numbering below refers to the final version of the paper.  Run every Python script with
"python3 -I" from inside code/ (the scripts that import sing_gen look for it in the
current directory, and gamma.py / tab.py read their input from ../data/).
Software: Singular 4.x, msolve, Python 3 with numpy, sympy, scipy, mpmath and
python-flint (Arb ball arithmetic; version 0.9.0 was used).

code/  -- exact algebra for period lattices (Sections 5 and 7.1-7.3)
  sing_gen.py      Builds and runs a Singular script for a lattice with dual group H
                   (exponent vectors mod m); exact arithmetic over Q(exp(2 pi i/m)).
                   Prints RIGID if every Fourier variable is nilpotent modulo the
                   isospectrality ideal.
  hnf2d.py         Runs sing_gen over all planar Hermite normal forms (a,0)Z+(b,c)Z with
                   max(gcd(a,b),c) <= 3 in a given index range (Proposition 7.1).
  sing_mod.py      Same computation over F_p (p = 1000033); evidence only, not a certificate.
  hnf2d_mod.py     Modular planar runs, unknowns restricted to H° (Corollary 3.3).
  cyc3d.py         Cyclic dual groups <(u,u^a,u^b)> in Z^3, N <= 7 (Section 7.2).
  sep_test.py      Full isospectrality ideal for a rectangular lattice; tests whether all
                   off-axis Fourier variables are nilpotent (Section 7.3, 4Z+2Z).

code/  -- Conjecture 2 of FFORS, certificates (Section 7.4)
  cert_cheb.py     The certifier used for Proposition 7.3 and Table 1.  Unknowns
                   u = (x_1..x_m, y_1..y_m, x_c), v = (x_1+iy_1,..,x_m+iy_m, x_c, x_m-iy_m,..,x_1-iy_1).
                   Equations G_q(u) = (D_v(x_j))_j at the Chebyshev nodes
                   x_j = 2cos(pi(2j+1)/2q), where D_0 vanishes; D_v - D_0 has degree <= q-1,
                   so G_q = 0 iff D_v = D_0.  Damped Newton search in floating point from
                   Gaussian random starts, then refinement and the Krawczyk test in Arb ball
                   arithmetic (python-flint) with 6q+400 bits on the box of radius
                   2^-(3q+150) about the refined point.  Prints KRAWCZYK_CERTIFIED and the
                   point to 30 digits.
                   Usage: python3 -I cert_cheb.py q seed trials sigma [maxit accept]
                   (defaults maxit = 150, accept = 1e-7).  Candidates that do not refine in
                   ball arithmetic or fail the Krawczyk test are discarded and the search
                   continues.  Settings used: sigma = 0.5 with the defaults for q <= 139;
                   sigma = 0.3, maxit = 200, accept = 1e-5 for q >= 149 (recorded in the
                   "search:" line of those logs).  Only the search differs; the certificate
                   (refinement, box, precision, Krawczyk test) is the same for all q.
  batch_cheb.sh    Runs cert_cheb.py for a list of q (seeds 1..4, first success kept),
                   writing logsC/q<q>_seed<s>.log; SIG, MAXIT, ACC may be set in the
                   environment.
  make_table.py    Reads logsC/*.log and writes table_block.tex (Table 1 of the paper).
  verify_point.py  Independent re-verification from the stored 30-digit points alone:
                   refines each stored point in ball arithmetic, repeats the Krawczyk test,
                   reports the distance between the certified zero and the stored point,
                   and evaluates |D_v - D_0|/(1+|D_0|) at the stored point at 2q further
                   points off the nodes.  Usage: python3 -I verify_point.py LOG [LOG ...]
  mk.py, mk2.py    Build the real coefficient system F_q (msolve format); mk2.py uses
                   transfer matrices.  sys_q5.ms is the q = 5 system.
  krawczyk5.py     60-digit interval Krawczyk certificate for the q = 5 point of
                   Proposition 7.2 (coefficient system, starting from the msolve box).
  krawczykq.py     Krawczyk certificate for a point of a system produced by mk2.py.
  cert_any.py      An earlier, independent certifier for the coefficient system F_q
                   (mpmath interval arithmetic, 70 digits).  It certified q = 5,7,9,11,13,
                   17,19 (logs/krawczyk_general_q*.log) and is not needed for Table 1; it is
                   kept as a cross-check of a different formulation.
  newton2.py       Damped Newton search for F_q from uniform random starts; produced the
                   solution lists data/sys2_q*_newton.npy used for the counts in Remark 6.5
                   and Section 8(4).

code/  -- node coordinates (Section 6).  In these scripts "gamma" denotes the node data
           beta of Lemma 6.1 and "sigma"/"sigma0" the residue nu/nu_0 of Theorem 6.2.
  sigma0.py        Monodromy polynomials; computes nu_0 of an isospectral potential from
                   P_n(0) = (-1)^m omega^(-nu_0).
  gamma.py         Recovers the node data kappa (varkappa in the paper) and beta of an
                   isospectral potential from its Bloch solution.
  gsys.py          The Hirota system E_nu(beta) of Corollary 6.3 and the potential V(beta)
                   of Theorem 6.2(b).
  tab.py           For the Newton solutions of q = 5, 7, 9, 11: real node coordinates after
                   a cyclic shift, the residue nu_0, orthant and index sign (Remark 6.5).

data/
  sys2_q{5,7,9,11,13}.ms         the coefficient systems F_q (msolve format, from mk2.py).
  sys2_q{5,7,9,11,13}_newton.npy the distinct nonzero real solutions found by newton2.py:
                                 4, 115, 397, 251, 108 points; closed under v -> -v and
                                 v -> conj(v) they number 4, 120, 1024, 992, 432.

logs/
  planar_exact_index_2_10.log      exact runs, index 2..10 (64 lattices, all RIGID); the
                                   final traceback records the time-out at index 11.
  planar_modp_index_11_12.log      modular runs, index 11..12 (26 lattices, all RIGID mod p).
  cyclic3d_exact_index_4_7.log     exact runs for cyclic dual groups in Z^3 (15 classes).
  separability_4x2_exact.log       4Z+2Z: ideal zero-dimensional (vdim 201), all off-axis
                                   variables nilpotent.
  msolve_q5_real_solutions.txt     msolve real-root output for sys_q5.ms.
  krawczyk_q5.log                  output of krawczyk5.py (Proposition 7.2).
  chebyshev_certificates/          output of cert_cheb.py for every period in Table 1
                                   (q = 9 and all primes 5 <= q <= 199); each log has the
                                   verdict line and the refined point to 30 digits.
  chebyshev_certificates/table_block.tex   Table 1 as produced by make_table.py.
  chebyshev_certificates/reverification.txt   output of verify_point.py on all logs.
  krawczyk_general_q*.log          output of the older certifier cert_any.py (cross-check).
  newton_real_solutions_q*.txt     text listing of data/sys2_q*_newton.npy.
  node_coordinates_check_q*.txt    output of tab.py: every listed real solution has real
                                   node coordinates (after a cyclic shift) solving the
                                   Hirota system; class/orthant/index statistics.
