#!/bin/bash
# usage: [SIG=0.5] [MAXIT=150] [ACC=1e-7] batch_cheb.sh q1 q2 ...
# Runs cert_cheb.py for each q (seeds 1..4, first certified seed kept), writing logsC/q<q>_seed<s>.log.
cd "$(dirname "$0")"
SIG=${SIG:-0.5}; MAXIT=${MAXIT:-150}; ACC=${ACC:-1e-7}
mkdir -p logsC
for q in "$@"; do
  for seed in 1 2 3 4; do
    timeout 5400 python3 -I -W ignore cert_cheb.py $q $seed 400 $SIG $MAXIT $ACC > logsC/q${q}_seed${seed}.log 2>&1
    if grep -q KRAWCZYK_CERTIFIED logsC/q${q}_seed${seed}.log; then
      echo "q=$q seed=$seed CERTIFIED $(grep '^q=' logsC/q${q}_seed${seed}.log | cut -c1-110)"
      break
    else
      echo "q=$q seed=$seed not certified: $(tail -1 logsC/q${q}_seed${seed}.log | cut -c1-100)"
    fi
  done
done
