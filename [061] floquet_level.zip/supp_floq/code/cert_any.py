"""Certified nonzero conjugate-reflection symmetric potential Floquet isospectral to 0, period q.

Real unknowns u = (x_1..x_m, y_1..y_m, x_c), q = 2m+1, potential
    v = (x_1+i y_1, ..., x_m+i y_m, x_c, x_m-i y_m, ..., x_1-i y_1).
Equations: the q coefficients of D_v(L) - D_0(L), D_v(L) = tr T_q...T_1, T_n = [[L-v_n,-1],[1,0]].
They are real for u real.  Steps: (1) damped Newton from random starts (numpy, complex128),
(2) refinement in mpmath, (3) Krawczyk test in mpmath interval arithmetic:
    K(X) = xt - Y F(xt) + (I - Y J(X)) (X - xt)  contained in int(X)  ==> unique zero in X.
Usage: python3 -I cert_any.py q seed [trials]
"""
import sys, numpy as np, mpmath as mp
from mpmath import iv

q = int(sys.argv[1]); seed = int(sys.argv[2]); trials = int(sys.argv[3]) if len(sys.argv) > 3 else 400
CMAX = float(sys.argv[4]) if len(sys.argv) > 4 else 1e8
m = q // 2; assert q == 2 * m + 1

def build_v(u, I=1j):
    x, y, xc = u[:m], u[m:2*m], u[2*m]
    return [x[j] + I*y[j] for j in range(m)] + [xc] + [x[j] - I*y[j] for j in reversed(range(m))]

# ---------- generic polynomial helpers (coefficient lists, index = power of L) ----------
def pmul(a, b, zero):
    out = [zero] * (len(a) + len(b) - 1)
    for i, ai in enumerate(a):
        for j, bj in enumerate(b):
            out[i + j] = out[i + j] + ai * bj
    return out
def padd(a, b, zero):
    n = max(len(a), len(b)); out = []
    for i in range(n):
        out.append((a[i] if i < len(a) else zero) + (b[i] if i < len(b) else zero))
    return out
def pscale(a, c): return [c * t for t in a]

def step(Mx, vn, zero, one):
    # T = [[L - vn, -1], [1, 0]];  returns T * M
    (A, B), (C, D) = Mx
    LmV = [-vn, one]
    nA = padd(pmul(LmV, A, zero), pscale(C, -one), zero)
    nB = padd(pmul(LmV, B, zero), pscale(D, -one), zero)
    return ((nA, nB), (A, B))

def disc_coeffs(v, zero, one):
    M = (([one], [zero]), ([zero], [one]))
    for vn in v: M = step(M, vn, zero, one)
    tr = padd(M[0][0], M[1][1], zero)
    return tr  # coefficients of L^0..L^q

def F_and_J(u, zero, one, I, D0, re):
    """F_k = coeff of L^{q-k} (k=1..q) of D_v - D_0;  J = dF/du (real coordinates)."""
    v = build_v(u, I)
    # prefix products P_n = T_n...T_1 (P_0 = I) and suffix S_n = T_q...T_{n+1} (S_q = I)
    Id = (([one], [zero]), ([zero], [one]))
    P = [Id]
    for vn in v: P.append(step(P[-1], vn, zero, one))
    tr = padd(P[-1][0][0], P[-1][1][1], zero)
    # suffix: S_n = S_{n+1} * T_{n+1}; compute right-multiplication by T
    def rstep(Mx, vn):
        (A, B), (C, D) = Mx  # M * T, T = [[L-vn,-1],[1,0]]
        LmV = [-vn, one]
        return ((padd(pmul(A, LmV, zero), B, zero), pscale(A, -one)),
                (padd(pmul(C, LmV, zero), D, zero), pscale(C, -one)))
    S = [None] * (q + 1); S[q] = Id
    for n in range(q - 1, -1, -1): S[n] = rstep(S[n + 1], v[n])
    # d tr / d v_n (site n = 1..q, v[n-1]) = - (P_{n-1} S_n)_{11}
    dtr = []
    for n in range(1, q + 1):
        A = P[n - 1]; B = S[n]
        e11 = padd(pmul(A[0][0], B[0][0], zero), pmul(A[0][1], B[1][0], zero), zero)  # (P S)_{11}? see note
        dtr.append(pscale(e11, -one))
    # F
    diff = padd(tr, pscale(D0, -one), zero)
    def coeff(poly, k):  # coefficient of L^{q-k}
        i = q - k
        return poly[i] if i < len(poly) else zero
    F = [re(coeff(diff, k)) for k in range(1, q + 1)]
    J = []
    for k in range(1, q + 1):
        row = []
        for j in range(m):
            a = coeff(dtr[j], k); b = coeff(dtr[q - 1 - j], k)
            row.append(re(a + b))
        for j in range(m):
            a = coeff(dtr[j], k); b = coeff(dtr[q - 1 - j], k)
            row.append(re(I * (a - b)))
        row.append(re(coeff(dtr[m], k)))
        J.append(row)
    return F, J

# Note on d tr/d v_n: tr(T_q..T_1) with T_n = T0_n - v_n E11 ; derivative = -tr(S_n E11 P_{n-1})
#   = -(P_{n-1} S_n)_{11}, and (P S)_{11} = P_{11} S_{11} + P_{12} S_{21}.

# ---------- numpy versions ----------
D0_np = [complex(t) for t in disc_coeffs([0.0] * q, 0j, 1 + 0j)]
def FJ_np(u):
    F, J = F_and_J(list(u), 0j, 1 + 0j, 1j, D0_np, lambda z: z.real)
    return np.array(F), np.array(J)

rng = np.random.default_rng(seed); sol = None
for t in range(trials):
    u = rng.uniform(-2.0, 2.0, q)
    ok = False
    for it in range(150):
        f, Jm = FJ_np(u); nf = np.linalg.norm(f)
        if nf < 1e-12: ok = True; break
        try: du = np.linalg.solve(Jm, -f)
        except np.linalg.LinAlgError: break
        lam = 1.0
        while lam > 1e-6 and np.linalg.norm(FJ_np(u + lam * du)[0]) >= nf: lam /= 2
        u = u + lam * du
        if not np.all(np.isfinite(u)) or np.linalg.norm(u) > 1e3: break
    if ok and np.linalg.norm(u) > 0.3:
        c = np.linalg.cond(FJ_np(u)[1])
        if c >= CMAX: print('  trial %d converged, rejected cond=%.2e' % (t, c), flush=True)
        if c < CMAX:
            sol = u; print('newton: trial %d |u|=%.5f cond=%.3e' % (t, np.linalg.norm(u), c), flush=True); break
if sol is None:
    print('NO_SOLUTION_FOUND'); sys.exit(1)

# ---------- mpmath refinement ----------
mp.mp.dps = 70
D0_mp = [mp.mpc(t) for t in disc_coeffs([mp.mpc(0)] * q, mp.mpc(0), mp.mpc(1))]
x = mp.matrix([mp.mpf(float(t)) for t in sol])
for it in range(40):
    F, J = F_and_J([x[i] for i in range(q)], mp.mpc(0), mp.mpc(1), mp.mpc(0, 1), D0_mp, lambda z: mp.re(z))
    Fm = mp.matrix(F)
    if mp.norm(Fm) < mp.mpf(10) ** (-62): break
    x = x - mp.lu_solve(mp.matrix(J), Fm)
F, J = F_and_J([x[i] for i in range(q)], mp.mpc(0), mp.mpc(1), mp.mpc(0, 1), D0_mp, lambda z: mp.re(z))
res = mp.norm(mp.matrix(F))
Y = mp.inverse(mp.matrix(J))
Yiv = [[None]*q for _ in range(q)]

# ---------- Krawczyk in interval arithmetic ----------
iv.dps = 70
r = mp.mpf(10) ** (-25)
def ivc(re_, im_=0): return iv.mpc(re_, im_) if hasattr(iv, 'mpc') else None
# complex intervals represented as pairs (re, im) of real intervals
class CI:
    __slots__ = ('a', 'b')
    def __init__(self, a, b=None): self.a = a; self.b = iv.mpf(0) if b is None else b
    def __add__(s, o): return CI(s.a + o.a, s.b + o.b)
    def __sub__(s, o): return CI(s.a - o.a, s.b - o.b)
    def __mul__(s, o):
        if isinstance(o, CI): return CI(s.a * o.a - s.b * o.b, s.a * o.b + s.b * o.a)
        return CI(s.a * o, s.b * o)
    __rmul__ = __mul__
    def __neg__(s): return CI(-s.a, -s.b)
ZERO = CI(iv.mpf(0)); ONE = CI(iv.mpf(1)); IU = CI(iv.mpf(0), iv.mpf(1))
def cmul(c, z):  # c may be CI
    return c * z
D0_iv = [CI(iv.mpf(int(round(float(mp.re(t)))))) for t in D0_mp]  # integer coefficients
assert all(abs(mp.im(t)) == 0 and mp.re(t) == int(mp.re(t)) for t in D0_mp)
# patch pscale to work with CI scalars
def pscale(a, c): return [c * t if not isinstance(c, CI) else t * c for t in a]
globals()['pscale'] = pscale
xt = [iv.mpf(x[i]) for i in range(q)]
for i in range(q):
    for k in range(q): Yiv[i][k] = iv.mpf(Y[i, k])
X = [iv.mpf([x[i] - r, x[i] + r]) for i in range(q)]
Ft, _ = F_and_J([CI(t) for t in xt], ZERO, ONE, IU, D0_iv, lambda z: z.a)
_, JX = F_and_J([CI(t) for t in X], ZERO, ONE, IU, D0_iv, lambda z: z.a)
ok = True; maxw = mp.mpf(0)
for i in range(q):
    s = xt[i]
    for k in range(q): s = s - Yiv[i][k] * Ft[k]
    for j in range(q):
        cij = iv.mpf(1 if i == j else 0) - sum((Yiv[i][k] * JX[k][j] for k in range(q)), iv.mpf(0))
        s = s + cij * (X[j] - xt[j])
    lo, hi = s.a, s.b
    if not (lo > X[i].a and hi < X[i].b): ok = False
    maxw = max(maxw, hi - lo)
print('q=%d residual=%s max_K_width=%s norm=%s %s' % (q, mp.nstr(res, 3), mp.nstr(maxw, 3),
      mp.nstr(mp.norm(x), 8), 'KRAWCZYK_CERTIFIED' if ok else 'KRAWCZYK_FAILED'))
print('point:', [mp.nstr(x[i], 25) for i in range(q)])
