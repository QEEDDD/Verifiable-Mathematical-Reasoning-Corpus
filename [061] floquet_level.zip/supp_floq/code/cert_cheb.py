"""Certified nonzero conjugate-reflection symmetric potential Floquet isospectral to 0, odd period q.

Equivalent well-conditioned formulation: D_v - D_0 has degree <= q-1, so it vanishes identically iff
it vanishes at the q Chebyshev nodes x_j = 2 cos(pi (2j+1)/(2q)), j = 0..q-1, where D_0(x_j) = 0.
Unknowns u = (x_1..x_m, y_1..y_m, x_c), v = (x_1+iy_1,...,x_m+iy_m, x_c, x_m-iy_m,...,x_1-iy_1);
equations G_j(u) = Re D_v(x_j) (D_v(x_j) is real for such v).
D_v(x) = tr T_q(x)...T_1(x),  T_n(x) = [[x - v_n, -1],[1, 0]],
dD_v(x)/dv_n = -(P_{n-1}(x) S_n(x))_{11},  P_{n-1} = T_{n-1}...T_1,  S_n = T_q...T_{n+1}.
Steps: damped Newton (numpy), refinement and Krawczyk test in python-flint ball arithmetic:
    K(X) = ut - Y G(ut) + (I - Y G'(X))(X - ut)  inside int(X)  ==>  unique zero of G in X.
Usage: python3 -I cert_cheb.py q seed trials sigma [maxit accept]
  maxit  (default 150): Newton iterations per random start;
  accept (default 1e-7): a start whose Newton iteration stalls with |G| < accept is passed to the
         ball-arithmetic refinement.  A candidate that does not refine, or fails the Krawczyk
         test, is discarded and the search continues; with the default values the search
         reproduces the logs written by the first version of this script.
"""
import sys, numpy as np
from flint import arb, acb, arb_mat, ctx

q = int(sys.argv[1]); seed = int(sys.argv[2])
trials = int(sys.argv[3]) if len(sys.argv) > 3 else 400
SIG = float(sys.argv[4]) if len(sys.argv) > 4 else 0.5
MAXIT = int(sys.argv[5]) if len(sys.argv) > 5 else 150
ACC = float(sys.argv[6]) if len(sys.argv) > 6 else 1e-7
m = q // 2; assert q == 2 * m + 1
nodes = 2 * np.cos(np.pi * (2 * np.arange(q) + 1) / (2 * q))

def build_v(u):
    x, y, xc = u[:m], u[m:2*m], u[2*m]
    return np.array([x[j] + 1j*y[j] for j in range(m)] + [xc] + [x[j] - 1j*y[j] for j in reversed(range(m))])

def GJ_np(u):
    v = build_v(u); G = np.zeros(q); J = np.zeros((q, q))
    for jj, x0 in enumerate(nodes):
        T = [np.array([[x0 - vn, -1.0], [1.0, 0.0]], dtype=complex) for vn in v]
        P = [np.eye(2, dtype=complex)]
        for Tn in T: P.append(Tn @ P[-1])
        S = [None] * (q + 1); S[q] = np.eye(2, dtype=complex)
        for k in range(q - 1, -1, -1): S[k] = S[k + 1] @ T[k]
        G[jj] = (P[q][0, 0] + P[q][1, 1]).real
        d = np.array([-(P[k - 1] @ S[k])[0, 0] for k in range(1, q + 1)])
        for j in range(m):
            a, b = d[j], d[q - 1 - j]
            J[jj, j] = (a + b).real; J[jj, m + j] = (1j * (a - b)).real
        J[jj, 2 * m] = d[m].real
    return G, J

def GJ_vec(u):
    # vectorized over the nodes: arrays of shape (q, 2, 2)
    v = build_v(u); nq = len(nodes)
    I2 = np.broadcast_to(np.eye(2, dtype=complex), (nq, 2, 2))
    T = []
    for vn in v:
        Tn = np.zeros((nq, 2, 2), dtype=complex)
        Tn[:, 0, 0] = nodes - vn; Tn[:, 0, 1] = -1.0; Tn[:, 1, 0] = 1.0
        T.append(Tn)
    P = [I2]
    for Tn in T: P.append(Tn @ P[-1])
    S = [None] * (q + 1); S[q] = I2
    for k in range(q - 1, -1, -1): S[k] = S[k + 1] @ T[k]
    G = (P[q][:, 0, 0] + P[q][:, 1, 1]).real
    d = np.array([-(P[k - 1] @ S[k])[:, 0, 0] for k in range(1, q + 1)])  # shape (q sites, nodes)
    J = np.zeros((nq, q))
    for j in range(m):
        a, b = d[j], d[q - 1 - j]
        J[:, j] = (a + b).real; J[:, m + j] = (1j * (a - b)).real
    J[:, 2 * m] = d[m].real
    return G, J
_u = np.random.default_rng(5).normal(0, 0.5, q)
_g1, _j1 = GJ_np(_u); _g2, _j2 = GJ_vec(_u)
assert np.allclose(_g1, _g2) and np.allclose(_j1, _j2), 'vectorized mismatch'
GJ_np = GJ_vec

def G_vec(u):
    # same batched products as GJ_vec, hence bit-identical G; used in the line search
    v = build_v(u); nq = len(nodes)
    P = np.broadcast_to(np.eye(2, dtype=complex), (nq, 2, 2))
    for vn in v:
        Tn = np.zeros((nq, 2, 2), dtype=complex)
        Tn[:, 0, 0] = nodes - vn; Tn[:, 0, 1] = -1.0; Tn[:, 1, 0] = 1.0
        P = Tn @ P
    return (P[:, 0, 0] + P[:, 1, 1]).real
_ga = G_vec(_u); _gb = GJ_vec(_u)[0]
assert np.array_equal(_ga, _gb), 'G_vec mismatch'

# ---------------- ball arithmetic set-up ----------------
ctx.prec = 6 * q + 400
pi = arb.pi()
bnodes = [2 * ((2 * j + 1) * pi / (2 * q)).cos() for j in range(q)]

def mat_mul(A, B):
    return [[A[0][0]*B[0][0] + A[0][1]*B[1][0], A[0][0]*B[0][1] + A[0][1]*B[1][1]],
            [A[1][0]*B[0][0] + A[1][1]*B[1][0], A[1][0]*B[0][1] + A[1][1]*B[1][1]]]

def GJ_ball(u, want_J=True):
    x, y, xc = u[:m], u[m:2*m], u[2*m]
    v = [acb(x[j], y[j]) for j in range(m)] + [acb(xc)] + [acb(x[j], -y[j]) for j in reversed(range(m))]
    one, zero = acb(1), acb(0)
    G = []; J = []
    for x0 in bnodes:
        T = [[[acb(x0) - vn, -one], [one, zero]] for vn in v]
        P = [[[one, zero], [zero, one]]]
        for Tn in T: P.append(mat_mul(Tn, P[-1]))
        G.append((P[q][0][0] + P[q][1][1]).real)
        if not want_J: continue
        S = [None] * (q + 1); S[q] = [[one, zero], [zero, one]]
        for k in range(q - 1, -1, -1): S[k] = mat_mul(S[k + 1], T[k])
        d = []
        for k in range(1, q + 1):
            A = P[k - 1]; B = S[k]
            d.append(-(A[0][0] * B[0][0] + A[0][1] * B[1][0]))
        row = [None] * q
        for j in range(m):
            a, b = d[j], d[q - 1 - j]
            row[j] = (a + b).real; row[m + j] = -((a - b).imag)
        row[2 * m] = d[m].real
        J.append(row)
    return G, (J if want_J else None)


def newton_search(u):
    ok = False
    for it in range(MAXIT):
        g, Jm = GJ_np(u); ng = np.linalg.norm(g)
        if ng < 1e-12: ok = True; break
        try: du = np.linalg.solve(Jm, -g)
        except np.linalg.LinAlgError: break
        lam = 1.0
        while lam > 1e-8 and np.linalg.norm(G_vec(u + lam * du)) >= ng: lam /= 2
        if lam <= 1e-8: break
        u = u + lam * du
        if not np.all(np.isfinite(u)) or np.linalg.norm(u) > 60: break
    if not ok and np.all(np.isfinite(u)):
        g_last = np.linalg.norm(G_vec(u))
        if g_last < ACC: ok = True      # rounding floor reached; polished in ball arithmetic below
    return ok, u


def certify(sol, t_used):
    """Refine in ball arithmetic and run the Krawczyk test; None if the candidate does not refine."""
    ut = [arb(float(t)) for t in sol]
    try:
        for it in range(14):
            G, J = GJ_ball(ut)
            if it == 7 and max(abs(g).upper() for g in G) > 1e-15:
                return None                       # not converging: spurious candidate
            Jm = arb_mat([[e.mid() for e in row] for row in J]); Gm = arb_mat([[g.mid()] for g in G])
            du = Jm.solve(Gm)
            ut = [(ut[i] - du[i, 0]).mid() for i in range(q)]
        G, J = GJ_ball(ut)
        res = max(abs(g).upper() for g in G)
        r = arb(2) ** (-(3 * q + 150))
        X = [arb(ut[i], r) for i in range(q)]
        Gx, _ = GJ_ball(ut, want_J=False)
        _, JX = GJ_ball(X)
        Yb = arb_mat([[e.mid() for e in row] for row in J]).inv()
    except (ZeroDivisionError, ValueError):
        return None
    Y = arb_mat([[Yb[i, j].mid() for j in range(q)] for i in range(q)])
    Id = arb_mat([[arb(1) if i == j else arb(0) for j in range(q)] for i in range(q)])
    K = (arb_mat([[ut[i]] for i in range(q)]) - Y * arb_mat([[g] for g in Gx])
         + (Id - Y * arb_mat(JX)) * arb_mat([[X[i] - ut[i]] for i in range(q)]))
    ok = all(X[i].contains_interior(K[i, 0]) for i in range(q))
    maxw = max(2 * K[i, 0].rad() for i in range(q))
    norm = sum(float(t.mid()) ** 2 for t in ut) ** 0.5
    line1 = 'q=%d seed=%d trial=%d prec=%d box_radius=2^-%d residual<=%s max_K_width=%s norm=%.7f %s' % (
        q, seed, t_used, ctx.prec, 3 * q + 150, res.str(3, radius=False), maxw.str(3, radius=False), norm,
        'KRAWCZYK_CERTIFIED' if ok else 'KRAWCZYK_FAILED')
    line2 = 'point (x_1..x_m, y_1..y_m, x_c): ' + ' '.join(t.str(30, radius=False) for t in ut)
    return ok, line1, line2


if (MAXIT, ACC) != (150, 1e-7):
    print('search: sigma=%g maxit=%d accept=%g' % (SIG, MAXIT, ACC), flush=True)
rng = np.random.default_rng(seed)
for t in range(trials):
    u = rng.normal(0.0, SIG, q)
    ok, u = newton_search(u)
    if ok and np.linalg.norm(u) > 0.3:
        try: c = np.linalg.cond(GJ_np(u)[1])
        except np.linalg.LinAlgError: c = float('inf')
        print('newton: trial %d |u|=%.5f cond=%.3e' % (t, np.linalg.norm(u), c), flush=True)
        out = certify(u, t)
        if out is None:
            print('candidate of trial %d discarded (no ball-arithmetic convergence)' % t, flush=True)
            continue
        ok2, line1, line2 = out
        if not ok2:
            print('rejected candidate: ' + line1, flush=True)
            continue
        print(line1); print(line2)
        open('certC_q%d_seed%d.txt' % (q, seed), 'w').write(line1 + '\n' + line2 + '\n')
        sys.exit(0)
print('NO_SOLUTION_FOUND'); sys.exit(1)
