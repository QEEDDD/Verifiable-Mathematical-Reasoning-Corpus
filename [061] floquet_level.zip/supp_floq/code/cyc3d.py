"""Rigidity test for cyclic dual groups H = <(u, u^a, u^b)> in Z^3 (u = primitive N-th root of unity).
Axis indices: |H cap axis_j|. Only cases with all axis indices <= 3 are 'gap/conjecture-rigid' cases."""
import sys, math
sys.path.insert(0, '.')
from sing_gen import run
NMIN, NMAX = int(sys.argv[1]), int(sys.argv[2])
seen = set()
for N in range(NMIN, NMAX + 1):
    for a in range(1, N):
        for b in range(a, N):
            H = sorted({((k) % N, (a * k) % N, (b * k) % N) for k in range(N)})
            if len(H) != N: continue
            key = (N, tuple(H))
            # canonical up to coordinate permutation and inversion of coordinates
            def canon(H):
                import itertools
                best = None
                for perm in itertools.permutations(range(3)):
                    for sg in itertools.product([1, -1], repeat=3):
                        G = tuple(sorted(tuple((sg[j] * h[perm[j]]) % N for j in range(3)) for h in H))
                        if best is None or G < best: best = G
                return best
            c = canon(H)
            if c in seen: continue
            seen.add(c)
            ax = []
            for j in range(3):
                ax.append(sum(1 for h in H if all(h[i] == 0 for i in range(3) if i != j)))
            if max(ax) > 3: continue
            # directional periods
            mper = [N // math.gcd(N, x) for x in (1, a, b)]
            label = 'c3N%da%db%d' % (N, a, b)
            rig = run({'H': [list(h) for h in H], 'm': N, 'label': label, 'timeout': int(sys.argv[3]) if len(sys.argv) > 3 else 1200})
            print('   axis indices %s directional periods %s -> %s' % (ax, mper, 'rigid' if rig else 'NOT PROVEN RIGID'), flush=True)
