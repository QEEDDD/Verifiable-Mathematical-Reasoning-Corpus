# Recover the node parameters kappa_l and gamma_l of a potential isospectral to 0.
import numpy as np, sys
sys.path.insert(0, '.')
from sigma0 import monodromy_polys
def poles_P0(v):
    q = len(v); M = monodromy_polys(v)
    mu = np.roots(M[1][0].coeffs); poles = []
    for x0 in mu:
        th = np.roots([1.0, -x0, 1.0])
        vals = [abs(t**q - M[1][1](x0)) for t in th]
        poles.append(th[int(np.argmax(vals))])
    return np.array(poles)
def gamma_of(v):
    q = len(v); g = q - 1
    th = np.exp(1j*np.pi*np.arange(1, q)/q)
    P0 = np.poly(poles_P0(v))
    kap = np.array([np.polyval(P0, t)/np.polyval(P0, 1/t) for t in th])
    F = lambda l, k: (th[k] - 1/th[l])/(th[k] - th[l])
    gam = np.array([-kap[l]*np.prod([F(l, k) for k in range(g) if k != l]) for l in range(g)])
    return kap, gam
if __name__ == '__main__':
    for q in [5, 7]:
        S = np.load('../data/sys2_q%d_newton.npy' % q); m = q // 2
        for u in S[:4]:
            x = u[:m]; y = u[m:2*m]; xm = u[2*m]
            v = np.array([x[j]+1j*y[j] for j in range(m)] + [xm] + [x[j]-1j*y[j] for j in reversed(range(m))])
            for shift in range(q):
                vv = np.roll(v, shift)
                kap, gam = gamma_of(vv)
                if np.max(np.abs(gam.imag)) < 1e-6 * max(1, np.max(np.abs(gam))):
                    print('q=%d shift=%d gamma real:' % (q, shift), np.round(gam.real, 6).tolist()); break
            else:
                print('q=%d no shift gives real gamma; gamma(shift0)=' % q, np.round(gamma_of(v)[1], 4).tolist())
