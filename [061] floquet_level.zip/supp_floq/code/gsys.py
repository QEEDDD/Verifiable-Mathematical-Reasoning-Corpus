# The node-parameter (gamma) system: E_sigma(gamma) = sum_{I subset [q-1], s(I)=sigma mod q} gamma^I prod_{l<k in I} a_lk
# Real gamma <-> conjugate-reflection symmetric V. Here: real Newton search per sigma0, then
# reconstruct V from gamma and verify isospectrality directly.
import numpy as np, itertools, sys
def setup(q):
    g = q - 1; L = np.arange(1, q)
    a = np.ones((g, g))
    for i in range(g):
        for j in range(g):
            if i != j:
                l, k = L[i], L[j]
                a[i, j] = (np.sin(np.pi*(k-l)/(2*q))/np.sin(np.pi*(k+l)/(2*q)))**2
    subsets = []
    for mask in range(1 << g):
        I = [i for i in range(g) if mask >> i & 1]
        A = 1.0
        for x in range(len(I)):
            for y in range(x+1, len(I)): A *= a[I[x], I[y]]
        s = sum(L[i] for i in I) % q
        subsets.append((mask, I, A, s))
    return a, subsets
def E(gam, q, subsets):
    out = np.zeros(q)
    for mask, I, A, s in subsets:
        out[s] += A * np.prod(gam[I]) if I else A
    return out
def J(gam, q, subsets):
    g = q - 1; out = np.zeros((q, g))
    for mask, I, A, s in subsets:
        for t, i in enumerate(I):
            rest = I[:t] + I[t+1:]
            out[s, i] += A * (np.prod(gam[rest]) if rest else 1.0)
    return out
def V_from_gamma(gam, q, sig0, subsets):
    # V_n = rho_{n+1}-rho_n, rho_n = sum_I c_I delta(I) w^{-n s(I)} / tau_n, delta(I)=sum_{l in I}(th_l^{-1}-th_l)
    th = np.exp(1j*np.pi*np.arange(1, q)/q); w = np.exp(2j*np.pi/q)
    def tau(n): return sum((A*np.prod(gam[I]) if I else A) * w**(-n*s) for mask, I, A, s in subsets)
    def num(n): return sum((A*np.prod(gam[I]) if I else A) * sum(1/th[i]-th[i] for i in I) * w**(-n*s) for mask, I, A, s in subsets)
    rho = [num(n)/tau(n) for n in range(q+1)]
    return np.array([rho[n+1]-rho[n] for n in range(q)])
def isodef(v):
    q = len(v); C = np.zeros((q,q))
    for i in range(q): C[i,(i+1)%q] = C[(i+1)%q,i] = 1
    return np.max(np.abs(np.poly(C+np.diag(v)) - np.poly(C)))
if __name__ == '__main__':
    q = int(sys.argv[1]); trials = int(sys.argv[2]); seed = int(sys.argv[3])
    a, subsets = setup(q); g = q - 1
    rng = np.random.default_rng(seed); found = {}
    for sig0 in range(q):
        idx = [s for s in range(q) if s != sig0]
        sols = []
        for t in range(trials):
            gam = rng.standard_normal(g) * np.exp(rng.uniform(-1, 3, g))
            ok = False
            for it in range(100):
                f = E(gam, q, subsets)[idx]; nf = np.linalg.norm(f) / max(1, abs(E(gam, q, subsets)[sig0]))
                if nf < 1e-12: ok = True; break
                Jm = J(gam, q, subsets)[idx]
                try: d = np.linalg.solve(Jm, -f)
                except Exception: break
                lam = 1.0
                while lam > 1e-8 and np.linalg.norm(E(gam+lam*d, q, subsets)[idx]) >= np.linalg.norm(f): lam /= 2
                gam = gam + lam*d
                if not np.all(np.isfinite(gam)) or np.max(np.abs(gam)) > 1e9: break
            if ok and abs(E(gam, q, subsets)[sig0]) > 1e-6 and not any(np.linalg.norm(gam-s)/max(1,np.linalg.norm(s)) < 1e-6 for s in sols):
                sols.append(gam.copy())
        found[sig0] = sols
        checks = []
        for s in sols[:3]:
            v = V_from_gamma(s, q, sig0, subsets)
            checks.append(isodef(v))
        print('q=%d sigma0=%d real solutions=%d  sign patterns=%s  iso-defect(first 3)=%s' % (
            q, sig0, len(sols), sorted(set(''.join('+' if x > 0 else '-' for x in s) for s in sols)),
            ['%.1e' % c for c in checks]), flush=True)
    np.save('gsys_q%d.npy' % q, np.array([(k, s) for k in found for s in found[k]], dtype=object), allow_pickle=True)
