"""Test the conjectured classification on all 2D Hermite-normal-form lattices
Gamma = <(a,0),(b,c)>, 0<=b<a, with index a*c <= NMAX.
Conjecture: rigid  <=>  max(gcd(a,b), c) <= 3   (axis indices of Gamma)."""
import sys, math, itertools
sys.path.insert(0, '.')
from sing_gen import run

NMIN = int(sys.argv[1]); NMAX = int(sys.argv[2])
for N in range(NMIN, NMAX + 1):
    for a in range(1, N + 1):
        if N % a: continue
        c = N // a
        for b in range(0, a):
            M = a * c
            H = [(e1, e2) for e1 in range(M) for e2 in range(M)
                 if (a * e1) % M == 0 and (b * e1 + c * e2) % M == 0]
            assert len(H) == N, (a, b, c, len(H))
            g1 = math.gcd(a, b) if b else a
            g2 = c
            conj = max(g1, g2) <= 3
            label = 'a%db%dc%d' % (a, b, c)
            if N == 1: continue
            if not conj and len(sys.argv)<4: continue
            rig = run({'H': H, 'm': M, 'label': label, 'timeout': 3000})
            print('   axis indices (%d,%d) conjecture says %s; computed %s %s' % (
                g1, g2, 'rigid' if conj else 'nonrigid', 'rigid' if rig else 'not-rigid/unknown',
                '' if rig == conj else '<<<< MISMATCH'), flush=True)
