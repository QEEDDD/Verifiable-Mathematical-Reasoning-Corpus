import sys, math
sys.path.insert(0, '.')
from sing_mod import run
NMIN, NMAX = int(sys.argv[1]), int(sys.argv[2])
for N in range(NMIN, NMAX + 1):
    for a in range(1, N + 1):
        if N % a: continue
        c = N // a
        for b in range(0, a):
            M = a * c
            H = [(e1, e2) for e1 in range(M) for e2 in range(M) if (a * e1) % M == 0 and (b * e1 + c * e2) % M == 0]
            g1 = math.gcd(a, b) if b else a; g2 = c
            if max(g1, g2) > 3: continue
            # cluster lemma (proved): coefficients on H_1 = {e1=0} and H_2 = {e2=0} vanish; keep only H°
            sup = [h for h in H if h[0] % M and h[1] % M]
            if not sup:
                print('a%db%dc%d trivially rigid (H° empty)' % (a, b, c)); continue
            run(H, M, sup, 'a%db%dc%d' % (a, b, c), 'all', 3000)
