"""Krawczyk interval-Newton certificate for a real zero of a polynomial system (msolve format),
starting from a float candidate (row `idx` of an .npy file of Newton solutions)."""
import sys, numpy as np, sympy as sp
from mpmath import mp, iv, mpf, matrix, lu_solve
mp.dps = 60; iv.dps = 60
fn, npy, idx = sys.argv[1], sys.argv[2], int(sys.argv[3])
lines = open(fn).read().split('\n'); names = lines[0].split(',')
syms = sp.symbols(names)
eqs = [sp.sympify(e) for e in '\n'.join(lines[2:]).replace('^', '**').strip().rstrip(',').split(',\n')]
n = len(syms); assert len(eqs) == n
Jsym = sp.Matrix(eqs).jacobian(syms)
f_num = [sp.lambdify(syms, e, 'mpmath') for e in eqs]
J_num = [[sp.lambdify(syms, Jsym[i, j], 'mpmath') for j in range(n)] for i in range(n)]
x = matrix([mpf(float(t)) for t in np.load(npy)[idx]])
for it in range(30):
    F = matrix([f(*x) for f in f_num]); Jm = matrix([[J_num[i][j](*x) for j in range(n)] for i in range(n)])
    x = x - lu_solve(Jm, F)
F = matrix([f(*x) for f in f_num]); res = max(abs(t) for t in F)
Jm = matrix([[J_num[i][j](*x) for j in range(n)] for i in range(n)]); Y = Jm ** -1
r = mpf('1e-20')
X = [iv.mpf([x[i] - r, x[i] + r]) for i in range(n)]; xc = [iv.mpf(x[i]) for i in range(n)]
Fx = [f(*xc) for f in f_num]
JX = [[J_num[i][j](*X) for j in range(n)] for i in range(n)]
ok = True; wmax = 0
for i in range(n):
    s = xc[i]
    for k in range(n): s = s - iv.mpf(Y[i, k]) * Fx[k]
    for j in range(n):
        mcoef = iv.mpf(1 if i == j else 0)
        for k in range(n): mcoef = mcoef - iv.mpf(Y[i, k]) * JX[k][j]
        s = s + mcoef * (X[j] - xc[j])
    ok = ok and (s.a > X[i].a) and (s.b < X[i].b); wmax = max(wmax, float(s.delta))
print('%s idx=%d residual=%.2e max_K_width=%.2e norm=%s %s' % (fn, idx, float(res), wmax,
      mp.nstr(mp.sqrt(sum(t**2 for t in x)), 8), 'KRAWCZYK_CERTIFIED' if ok else 'NOT_CERTIFIED'))
print('point:', [mp.nstr(t, 20) for t in x])
