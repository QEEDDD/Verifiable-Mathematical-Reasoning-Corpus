"""Collect the Chebyshev-node certificates (logsC/q*_seed*.log) and emit a LaTeX table block.

Only logs written with the final settings (6q+400 bits, box radius 2^-(3q+150)) are accepted.
"""
import glob, re, sys
rows = {}
for fn in glob.glob('logsC/q*_seed*.log'):
    txt = open(fn).read()
    m = re.search(r'^q=(\d+) seed=(\d+) trial=(\d+) prec=(\d+) box_radius=2\^-(\d+) residual<=(\S+) '
                  r'max_K_width=(\S+) norm=(\S+) (KRAWCZYK_\w+)', txt, re.M)
    if not m or m.group(9) != 'KRAWCZYK_CERTIFIED':
        continue
    q = int(m.group(1))
    assert int(m.group(4)) == 6 * q + 400 and int(m.group(5)) == 3 * q + 150, fn
    rows[q] = dict(seed=int(m.group(2)), width=m.group(7), norm=float(m.group(8)), fn=fn)
qs = sorted(rows)


def fmt_e(s):
    mant, ex = s.lower().split('e')
    return r'$%s\cdot10^{%d}$' % (mant, int(ex))


def cell(q):
    r = rows[q]
    return r'%d & %.3f & %s' % (q, r['norm'], fmt_e(r['width']))


ncol = 3
nrow = (len(qs) + ncol - 1) // ncol
lines = []
for i in range(nrow):
    cells = []
    for c in range(ncol):
        k = i + c * nrow
        cells.append(cell(qs[k]) if k < len(qs) else r'& &')
    lines.append(' & '.join(cells) + r' \\')
head = ' & '.join([r'$q$ & $\|u\|$ & width'] * ncol)
colspec = r'@{}' + r'@{\hspace{1.4em}}'.join([r'rrl'] * ncol) + r'@{}'
block = r"""\begin{table}[ht]
\centering\scriptsize
\begin{tabular}{""" + colspec + r"""}
\toprule
""" + head + r"""\\
\midrule
""" + '\n'.join(lines) + r"""
\bottomrule
\end{tabular}
\caption{Krawczyk certificates for Proposition~\ref{prop:conj2all}.  For each
$q$: the norm of the certified point $u=(x,y,x_c)$ and the largest width of a
coordinate of the Krawczyk image, which lies in the interior of the box of
radius $2^{-3q-150}$ about the refined point (ball arithmetic with $6q+400$
bits).  The points, to $30$ digits, are in the supplementary archive.}\label{tab:krawczyk}
\end{table}"""
print('certified q (%d):' % len(qs), qs, file=sys.stderr)
open('table_block.tex', 'w').write(block)
