"""Build the real polynomial system for FFORS Conjecture 2: q-periodic potentials
v = (v_1,...,v_m,[v_mid],conj(v_m),...,conj(v_1)) Floquet isospectral to 0 (1D).
Isospectral <=> det(L I - C_q - diag v) = det(L I - C_q) as polynomials in L (z-dependence is v-free).
Write v_j = x_j + i y_j. Output msolve input (variables over QQ)."""
import sys, sympy as sp
q = int(sys.argv[1]); m = q // 2
xs = sp.symbols('x1:%d' % (m + 1)); ys = sp.symbols('y1:%d' % (m + 1))
I = sp.I
v = [xs[j] + I * ys[j] for j in range(m)]
if q % 2 == 1:
    xm = sp.Symbol('xm'); mid = [xm]
else:
    mid = []
vv = v + mid + [sp.conjugate(t) for t in reversed(v)]
vv = [sp.expand(t.subs({sp.conjugate(s): s for s in xs + ys})) if False else t for t in vv]
# conjugate of x+iy with real symbols: declare real
xr = sp.symbols('x1:%d' % (m + 1), real=True); yr = sp.symbols('y1:%d' % (m + 1), real=True)
sub = {xs[j]: xr[j] for j in range(m)}; sub.update({ys[j]: yr[j] for j in range(m)})
v = [xr[j] + I * yr[j] for j in range(m)]
mids = []
if q % 2 == 1:
    xmr = sp.Symbol('xm', real=True); mids = [xmr]
vv = v + mids + [xr[j] - I * yr[j] for j in reversed(range(m))]
L = sp.Symbol('L')
C = sp.zeros(q, q)
for i in range(q):
    C[i, (i + 1) % q] += 1; C[i, (i - 1) % q] += 1
A = L * sp.eye(q) - C - sp.diag(*vv)
A0 = L * sp.eye(q) - C
P = sp.expand(A.det(method='berkowitz') - A0.det(method='berkowitz'))
coeffs = sp.Poly(P, L).all_coeffs()
eqs = []
for c in coeffs:
    c = sp.expand(c)
    re, im = sp.expand(sp.re(c)), sp.expand(sp.im(c))
    assert sp.simplify(im) == 0, im
    if re != 0: eqs.append(re)
vars_ = list(xr) + list(yr) + mids
names = [str(s) for s in vars_]
with open('sys_q%d.ms' % q, 'w') as f:
    f.write(','.join(names) + '\n0\n')
    f.write(',\n'.join(str(e).replace('**', '^') for e in eqs) + '\n')
print('q=%d vars=%s neq=%d degs=%s' % (q, names, len(eqs), [sp.Poly(e, *vars_).total_degree() for e in eqs]))
