"""Real polynomial system for FFORS Conjecture 2 (conjugate-reflection symmetric q-periodic
potentials isospectral to 0), via the transfer-matrix discriminant tr prod [[L-v_n,-1],[1,0]].
Output in msolve format: first line variables, second line 0, then equations."""
import sys, sympy as sp
q = int(sys.argv[1]); m = q // 2
L = sp.Symbol('L')
xs = sp.symbols('x1:%d' % (m + 1), real=True); ys = sp.symbols('y1:%d' % (m + 1), real=True)
v = [xs[j] + sp.I * ys[j] for j in range(m)]
mids = []
if q % 2:
    xm = sp.Symbol('xm', real=True); mids = [xm]
vv = v + mids + [xs[j] - sp.I * ys[j] for j in reversed(range(m))]
def trM(vals):
    A = sp.eye(2)
    for vn in vals:
        A = sp.Matrix([[L - vn, -1], [1, 0]]) * A
        A = A.applyfunc(sp.expand)
    return sp.expand(A[0, 0] + A[1, 1])
P = sp.expand(trM(vv) - trM([0] * q))
coeffs = sp.Poly(P, L).all_coeffs()
eqs = []
for c in coeffs:
    c = sp.expand(c)
    re, im = sp.expand(sp.re(c)), sp.expand(sp.im(c))
    assert im == 0, ('nonzero imaginary part', im)
    if re != 0: eqs.append(re)
vars_ = list(xs) + list(ys) + mids
names = [str(s) for s in vars_]
assert len(eqs) == len(vars_), (len(eqs), len(vars_))
with open('sys2_q%d.ms' % q, 'w') as f:
    f.write(','.join(names) + '\n0\n')
    f.write(',\n'.join(str(e).replace('**', '^') for e in eqs) + '\n')
print('q=%d vars=%d eqs=%d degrees=%s' % (q, len(vars_), len(eqs), [sp.Poly(e, *vars_).total_degree() for e in eqs]))
