import sys, numpy as np, sympy as sp
fn = sys.argv[1]; trials = int(sys.argv[2]); seed = int(sys.argv[3]); box = float(sys.argv[4]) if len(sys.argv) > 4 else 2.5
lines = open(fn).read().split('\n'); names = lines[0].split(',')
syms = sp.symbols(names)
eqs = [sp.sympify(e) for e in '\n'.join(lines[2:]).replace('^', '**').strip().rstrip(',').split(',\n')]
n = len(syms)
Fl = sp.lambdify(syms, eqs, 'numpy'); Jl = sp.lambdify(syms, sp.Matrix(eqs).jacobian(syms), 'numpy')
F = lambda u: np.array(Fl(*u), dtype=float); J = lambda u: np.array(Jl(*u), dtype=float)
rng = np.random.default_rng(seed); sols = []
for t in range(trials):
    u = rng.uniform(-box, box, size=n); ok = False
    for it in range(200):
        f = F(u); nf = np.linalg.norm(f)
        if nf < 1e-11: ok = True; break
        try: du = np.linalg.lstsq(J(u), -f, rcond=None)[0]
        except Exception: break
        lam = 1.0
        while lam > 1e-6 and np.linalg.norm(F(u + lam * du)) >= nf: lam /= 2
        u = u + lam * du
        if not np.all(np.isfinite(u)) or np.linalg.norm(u) > 1e3: break
    if ok and np.linalg.norm(u) > 0.2 and np.linalg.cond(J(u)) < 1e9 and not any(np.linalg.norm(u - s) < 1e-7 for s in sols):
        c = np.linalg.cond(J(u)); sols.append(u.copy())
        print('found %d |u|=%.5f cond=%.3e' % (len(sols), np.linalg.norm(u), c), np.round(u, 7).tolist(), flush=True)
print('total', len(sols), 'distinct nonzero real solutions from', trials, 'starts')
np.save(fn.replace('.ms', '_newton.npy'), np.array(sols))
