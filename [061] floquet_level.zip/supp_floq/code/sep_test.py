"""Separability experiment: for a lattice with dual group H (exponent vectors mod m),
compute the ideal of Floquet-isospectrality-to-zero in the Fourier variables and test
whether every OFF-AXIS Fourier coefficient vanishes on the variety (nilpotent mod ideal).
Also report vdim (number of solutions with multiplicity) when zero-dimensional."""
import sys, json, subprocess, time
sys.path.insert(0, '.')
from sing_gen import cyclo

OUT = '.'

def gen_sep(H, m, label):
    d = len(H[0]); N = len(H)
    def add(a, b): return tuple((a[j] + b[j]) % m for j in range(d))
    def neg(a): return tuple((-a[j]) % m for j in range(d))
    support = [h for h in H if any(h)]
    vname = {h: 'v(%d)' % (i + 1) for i, h in enumerate(support)}
    offaxis = [i + 1 for i, h in enumerate(support) if sum(1 for x in h if x) >= 2]
    zs = ['z%d' % (j + 1) for j in range(d)]; Z = '*'.join(zs)
    L = []
    L.append('ring R=(0,W),(x,%s,v(1..%d)),dp;' % (','.join(zs), len(support)))
    L.append('minpoly=%s;' % cyclo(m))
    L.append('matrix M[%d][%d]; matrix M0[%d][%d];' % (N, N, N, N))
    for i, h in enumerate(H):
        terms = []
        for j in range(d):
            others = '*'.join(zs[k] for k in range(d) if k != j) or '1'
            terms.append('W^%d*%s*%s' % (h[j] % m, zs[j], Z))
            terms.append('W^%d*%s' % ((-h[j]) % m, others))
        diag = '%s*x-(%s)' % (Z, '+'.join(terms))
        L.append('M[%d,%d]=%s; M0[%d,%d]=%s;' % (i + 1, i + 1, diag, i + 1, i + 1, diag))
    for i, h in enumerate(H):
        for k, hp in enumerate(H):
            if i == k: continue
            s = add(hp, neg(h))
            if s in vname:
                L.append('M[%d,%d]=M[%d,%d]-%s*%s;' % (k + 1, i + 1, k + 1, i + 1, Z, vname[s]))
    L.append('poly P=det(M)-det(M0);')
    L.append('matrix Cf=coef(P,x*%s);' % Z)
    L.append('ideal I; int k; for(k=1;k<=ncols(Cf);k++){I=I+Cf[2,k];}')
    L.append('ring S=(0,W),(v(1..%d)),dp; minpoly=%s;' % (len(support), cyclo(m)))
    L.append('ideal I=imap(R,I); ideal G=std(I);')
    L.append('print("dim="+string(dim(G)));')
    L.append('if(dim(G)==0){print("vdim="+string(vdim(G)));}')
    L.append('int e; int ok; int nil=1;')
    L.append('intvec off=%s;' % (','.join(map(str, offaxis)) if offaxis else '0'))
    L.append('for(k=1;k<=size(off);k++){ if(off[k]>0){ok=0; for(e=1;e<=30;e++){ if(reduce(v(off[k])^e,G)==0){ok=e;break;} } if(ok==0){nil=0;} print("offaxis v("+string(off[k])+") exp "+string(ok));}}')
    L.append('print("OFFAXIS_NILPOTENT="+string(nil));')
    L.append('quit;')
    src = '\n'.join(L)
    fn = '%s/sep_%s.sing' % (OUT, label)
    open(fn, 'w').write(src)
    return fn, support

def rect(qs):
    import itertools
    m = 1
    for q in qs:
        m = m * q // __import__('math').gcd(m, q)
    H = [tuple((m // q) * k for q, k in zip(qs, ks)) for ks in itertools.product(*[range(q) for q in qs])]
    return H, m

if __name__ == '__main__':
    qs = tuple(int(x) for x in sys.argv[1].split(','))
    H, m = rect(qs)
    label = 'r' + 'x'.join(map(str, qs))
    fn, sup = gen_sep(H, m, label)
    t0 = time.time()
    out = subprocess.run(['Singular', '-q', fn], capture_output=True, text=True, timeout=int(sys.argv[2]) if len(sys.argv) > 2 else 3000)
    print(label, 'N=%d' % len(H), 'time %.1fs' % (time.time() - t0))
    print(out.stdout[-3000:], out.stderr[-500:])
