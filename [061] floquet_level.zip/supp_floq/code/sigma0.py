# Compute the Baker-Akhiezer invariant sigma_0 of complex potentials isospectral to 0:
# p0 = prod(-poles of theta^{-1} f(1,theta)), predicted p0 = (-1)^m omega^{-sigma0}.
import numpy as np, sys
from numpy.polynomial import polynomial as Pn
def monodromy_polys(v):
    # entries of M(x)=T_q...T_1 as numpy poly1d in x
    q = len(v)
    M = [[np.poly1d([1.0+0j]), np.poly1d([0j])],[np.poly1d([0j]), np.poly1d([1.0+0j])]]
    for vn in v:
        T = [[np.poly1d([1.0, -vn]), np.poly1d([-1.0+0j])],[np.poly1d([1.0+0j]), np.poly1d([0j])]]
        M = [[T[0][0]*M[0][0] + T[0][1]*M[1][0], T[0][0]*M[0][1] + T[0][1]*M[1][1]],
             [T[1][0]*M[0][0] + T[1][1]*M[1][0], T[1][0]*M[0][1] + T[1][1]*M[1][1]]]
    return M
def sigma0(v, tol=1e-6):
    q = len(v); m = q // 2; w = np.exp(2j*np.pi/q)
    M = monodromy_polys(v)
    mu = np.roots(M[1][0].coeffs)            # Dirichlet eigenvalues (q-1 of them)
    poles = []
    for x0 in mu:
        th = np.roots([1.0, -x0, 1.0])        # theta + 1/theta = x0
        vals = [abs(t**q - M[1][1](x0)) for t in th]
        poles.append(th[int(np.argmax(vals))])
        if min(vals) > 1e-5 * max(1, max(vals)): return None, None, 'nonremovable both'
    p0 = np.prod([-t for t in poles])
    z = (-1)**m * p0                          # should be omega^{-sigma0}
    s = (-np.angle(z) * q / (2*np.pi)) % q
    return p0, s, abs(abs(z) - 1)
if __name__ == '__main__':
    q = int(sys.argv[1])
    L = [l.split() for l in open(sys.argv[2]).read().split('\n') if len(l.split()) == 2 and not l.startswith('/')]
    vals = [complex(float(a), float(b)) for a, b in L]
    sols = [np.array(vals[i:i+q]) for i in range(0, len(vals), q)]
    from collections import Counter
    cnt = Counter()
    for v in sols:
        if np.max(np.abs(v)) < 1e-8: cnt['vacuum'] += 1; continue
        p0, s, dev = sigma0(v)
        if p0 is None: cnt['degenerate'] += 1; continue
        key = round(s) % q if abs(s - round(s)) < 1e-4 and dev < 1e-4 else 'nonint(%.3f,%.1e)' % (s, dev)
        cnt[key] += 1
    print('q=%d distinct solutions=%d' % (q, len(sols)), dict(cnt))
