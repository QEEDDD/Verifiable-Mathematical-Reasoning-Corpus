"""Generate and run a Singular script deciding whether the only potential with
Fourier support `support` (subset of the finite group H, written additively as
exponent vectors modulo m) that is Floquet isospectral to 0 is V = 0.

Model: in the twisted Fourier basis e_h (h in H) the Floquet matrix is
   diag( sum_j W^{h_j} z_j + W^{-h_j} z_j^{-1} ) + C,   C[h', h] = Vhat(h' - h),
with W = exp(2 pi i/m) and z_j the (d-dimensional) quasimomentum variables.
Isospectrality for all z  <=>  det(xI - M_V) = det(xI - M_0) identically.
We multiply every row by Z = z_1...z_d to clear denominators.
The script prints whether every v(k) is nilpotent modulo the ideal of
coefficient identities (=> only the zero solution over C).
"""
import sys, json, subprocess, time
import sympy as sp

OUTDIR = '.'


def cyclo(m):
    W = sp.Symbol('W')
    return str(sp.cyclotomic_poly(m, W)).replace('**', '^')


def gen(H, m, support=None):
    d = len(H[0]); N = len(H)
    def add(a, b): return tuple((a[j] + b[j]) % m for j in range(d))
    def neg(a): return tuple((-a[j]) % m for j in range(d))
    nonid = [h for h in H if any(h)]
    if support is None:
        support = nonid
    vname = {h: 'v(%d)' % (i + 1) for i, h in enumerate(support)}
    zs = ['z%d' % (j + 1) for j in range(d)]
    Z = '*'.join(zs)
    L = []
    L.append('ring R=(0,W),(x,%s,v(1..%d)),dp;' % (','.join(zs), len(support)))
    L.append('minpoly=%s;' % cyclo(m))
    L.append('matrix M[%d][%d]; matrix M0[%d][%d];' % (N, N, N, N))
    for i, h in enumerate(H):
        terms = []
        for j in range(d):
            others = '*'.join(zs[k] for k in range(d) if k != j) or '1'
            terms.append('W^%d*%s*%s' % (h[j] % m, zs[j], Z))
            terms.append('W^%d*%s' % ((-h[j]) % m, others))
        diag = '%s*x-(%s)' % (Z, '+'.join(terms))
        L.append('M[%d,%d]=%s; M0[%d,%d]=%s;' % (i + 1, i + 1, diag, i + 1, i + 1, diag))
    for i, h in enumerate(H):
        for k, hp in enumerate(H):
            if i == k:
                continue
            s = add(hp, neg(h))
            if s in vname:
                L.append('M[%d,%d]=M[%d,%d]-%s*%s;' % (k + 1, i + 1, k + 1, i + 1, Z, vname[s]))
    L.append('poly P=det(M)-det(M0);')
    L.append('matrix Cf=coef(P,x*%s);' % Z)
    L.append('ideal I; int k; for(k=1;k<=ncols(Cf);k++){I=I+Cf[2,k];}')
    L.append('ring S=(0,W),(v(1..%d)),dp; minpoly=%s;' % (len(support), cyclo(m)))
    L.append('ideal I=imap(R,I); ideal G=std(I);')
    L.append('print("dim="+string(dim(G)));')
    L.append('if(dim(G)>0){print("ALL_NILPOTENT=0"); quit;}')
    L.append('int nil=1; int e; int ok; for(k=1;k<=%d;k++){ok=0; for(e=1;e<=24;e++){ if(reduce(v(k)^e,G)==0){ok=e;break;} } if(ok==0){nil=0;} print("v("+string(k)+") exp "+string(ok));}' % len(support))
    L.append('print("ALL_NILPOTENT="+string(nil));')
    L.append('quit;')
    return '\n'.join(L), support


def run(spec):
    H = [tuple(h) for h in spec['H']]; m = spec['m']
    sup = [tuple(s) for s in spec['support']] if 'support' in spec else None
    src, sup = gen(H, m, sup)
    label = spec.get('label', 'case')
    fn = '%s/run_%s.sing' % (OUTDIR, label)
    open(fn, 'w').write(src)
    t0 = time.time()
    out = subprocess.run(['Singular', '-q', fn], capture_output=True, text=True,
                         timeout=spec.get('timeout', 3000))
    res = out.stdout
    nil = 'ALL_NILPOTENT=1' in res
    dim = [l for l in res.splitlines() if l.startswith('dim=')]
    print('%-14s N=%-3d |supp|=%-3d %s %s  time %.1fs' % (label, len(H), len(sup), dim[0] if dim else '?',
          'RIGID' if nil else 'NOT-PROVEN-RIGID', time.time() - t0), flush=True)
    if not nil:
        print(res[-1500:], out.stderr[-500:])
    return nil


if __name__ == '__main__':
    run(json.loads(sys.argv[1]))
