"""Modular (finite-field) version of the isospectrality test. W is replaced by a primitive
m-th root of unity w0 in F_p (p prime, p = 1 mod m). Evidence only (not a certificate)."""
import sys, json, subprocess, time
OUT = '.'

def isprime(n):
    if n < 2: return False
    i = 2
    while i * i <= n:
        if n % i == 0: return False
        i += 1
    return True

def field(m, start=1000000):
    p = (start // m) * m + 1
    while not isprime(p): p += m
    # primitive m-th root
    fac = [q for q in range(2, m + 1) if m % q == 0 and isprime(q)]
    for g in range(2, p):
        w = pow(g, (p - 1) // m, p)
        if all(pow(w, m // q, p) != 1 for q in fac):
            return p, w
    raise ValueError

def gen(H, m, support, label, mode='all'):
    p, w0 = field(m)
    d = len(H[0]); N = len(H)
    def add(a, b): return tuple((a[j] + b[j]) % m for j in range(d))
    def neg(a): return tuple((-a[j]) % m for j in range(d))
    vname = {h: 'v(%d)' % (i + 1) for i, h in enumerate(support)}
    zs = ['z%d' % (j + 1) for j in range(d)]; Z = '*'.join(zs)
    L = ['ring R=%d,(x,%s,v(1..%d)),dp;' % (p, ','.join(zs), len(support)),
         'matrix M[%d][%d]; matrix M0[%d][%d];' % (N, N, N, N)]
    for i, h in enumerate(H):
        terms = []
        for j in range(d):
            others = '*'.join(zs[k] for k in range(d) if k != j) or '1'
            terms.append('%d*%s*%s' % (pow(w0, h[j] % m, p), zs[j], Z))
            terms.append('%d*%s' % (pow(w0, (-h[j]) % m, p), others))
        diag = '%s*x-(%s)' % (Z, '+'.join(terms))
        L.append('M[%d,%d]=%s; M0[%d,%d]=%s;' % (i + 1, i + 1, diag, i + 1, i + 1, diag))
    for i, h in enumerate(H):
        for k, hp in enumerate(H):
            if i == k: continue
            s = add(hp, neg(h))
            if s in vname:
                L.append('M[%d,%d]=M[%d,%d]-%s*%s;' % (k + 1, i + 1, k + 1, i + 1, Z, vname[s]))
    L.append('poly P=det(M)-det(M0);')
    L.append('matrix Cf=coef(P,x*%s);' % Z)
    L.append('ideal I; int k; for(k=1;k<=ncols(Cf);k++){I=I+Cf[2,k];}')
    L.append('ring S=%d,(v(1..%d)),dp;' % (p, len(support)))
    L.append('ideal I=imap(R,I); ideal G=std(I);')
    L.append('print("dim="+string(dim(G)));')
    L.append('if(dim(G)==0){print("vdim="+string(vdim(G)));}')
    if mode == 'all':
        idx = list(range(1, len(support) + 1))
    else:
        idx = [i + 1 for i, h in enumerate(support) if sum(1 for x in h if x) >= 2]
    L.append('int e; int ok; int nil=1;')
    L.append('intvec chk=%s;' % (','.join(map(str, idx)) if idx else '0'))
    L.append('if(dim(G)>0){print("NIL=0"); quit;}')
    L.append('for(k=1;k<=size(chk);k++){ if(chk[k]>0){ok=0; for(e=1;e<=40;e++){ if(reduce(v(chk[k])^e,G)==0){ok=e;break;} } if(ok==0){nil=0;} }}')
    L.append('print("NIL="+string(nil));')
    L.append('quit;')
    fn = '%s/mod_%s.sing' % (OUT, label)
    open(fn, 'w').write('\n'.join(L))
    return fn, p

def run(H, m, support, label, mode='all', timeout=3000):
    fn, p = gen(H, m, support, label, mode)
    t0 = time.time()
    try:
        out = subprocess.run(['Singular', '-q', fn], capture_output=True, text=True, timeout=timeout).stdout
    except subprocess.TimeoutExpired:
        print('%-16s TIMEOUT' % label, flush=True); return None
    nil = 'NIL=1' in out
    dim = [l for l in out.splitlines() if l.startswith('dim=') or l.startswith('vdim=')]
    print('%-16s N=%-3d p=%d |supp|=%-3d %s %s %.1fs' % (label, len(H), p, len(support), ' '.join(dim),
          ('RIGID(mod p)' if mode == 'all' else 'OFFAXIS-VANISH(mod p)') if nil else 'NOT-NIL', time.time() - t0), flush=True)
    return nil
