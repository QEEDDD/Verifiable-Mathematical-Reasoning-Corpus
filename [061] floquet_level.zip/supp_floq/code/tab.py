# For real conj-reflection solutions found in V-space: recover gamma (real after shift), class sigma0,
# orthant sign pattern, and the index sign det(dE/dgamma) (equations sigma != sigma0).
import numpy as np, sys
sys.path.insert(0, '.')
from gamma import gamma_of
from gsys import setup, E, J
from collections import defaultdict
q = int(sys.argv[1]); m = q // 2
a, subs = setup(q)
S = np.load('../data/sys2_q%d_newton.npy' % q)
table = defaultdict(list)
for u in S:
    x = u[:m]; y = u[m:2*m]; xm = u[2*m]
    v = np.array([x[j]+1j*y[j] for j in range(m)] + [xm] + [x[j]-1j*y[j] for j in reversed(range(m))])
    got = None
    for sh in range(q):
        kap, gam = gamma_of(np.roll(v, sh))
        if np.max(np.abs(gam.imag)) < 1e-6*max(1, np.max(np.abs(gam))):
            got = gam.real; break
    if got is None: table['nonreal'].append(0); continue
    Ev = E(got, q, subs); s0 = int(np.argmax(np.abs(Ev)))
    idx = [s for s in range(q) if s != s0]
    Jm = J(got, q, subs)[idx]
    sgn = int(np.sign(np.linalg.det(Jm)))
    pat = ''.join('+' if t > 0 else '-' for t in got)
    resid = np.max(np.abs(Ev[idx]))/abs(Ev[s0])
    table[(s0, pat)].append((sgn, resid))
tot = defaultdict(int)
for k in sorted(table, key=str):
    if k == 'nonreal': print('nonreal', len(table[k])); continue
    sg = [t[0] for t in table[k]]
    print('class %d orthant %s : count %d signed %+d  maxresid %.1e' % (k[0], k[1], len(sg), sum(sg), max(t[1] for t in table[k])))
    tot[k[0]] += sum(sg)
print('signed totals per class:', dict(tot))
