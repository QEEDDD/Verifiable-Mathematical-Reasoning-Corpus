"""Re-verify a Krawczyk certificate of cert_cheb.py from the stored 30-digit point alone.

Usage: python3 -I verify_point.py LOGFILE [LOGFILE ...]
For each log (written by cert_cheb.py) this script
  1. reads q and the 30-digit point u0 = (x_1..x_m, y_1..y_m, x_c);
  2. refines u0 by Newton's method in ball arithmetic (6q+400 bits) for G_q(u) = (D_v(x_j))_j,
     x_j = 2 cos(pi (2j+1)/(2q)), the Chebyshev nodes (D_0(x_j) = 0);
  3. runs the Krawczyk test on the box of radius 2^-(3q+150) about the refined point;
  4. reports |refined - u0| (agreement of the stored digits with the certified zero) and, as an
     independent sanity check, max |D_v(x) - D_0(x)| / (1 + |D_0(x)|) at the stored point u0 over the
     2q points x = 2 cos(pi (2k+1)/(4q)), k = 0..2q-1, which are distinct from the nodes.
Nothing is imported from cert_cheb.py.
"""
import sys, re
from flint import arb, acb, arb_mat, ctx


def mat_mul(A, B):
    return [[A[0][0]*B[0][0] + A[0][1]*B[1][0], A[0][0]*B[0][1] + A[0][1]*B[1][1]],
            [A[1][0]*B[0][0] + A[1][1]*B[1][0], A[1][0]*B[0][1] + A[1][1]*B[1][1]]]


def potential(u, q):
    m = q // 2
    x, y, xc = u[:m], u[m:2*m], u[2*m]
    return [acb(x[j], y[j]) for j in range(m)] + [acb(xc)] + [acb(x[j], -y[j]) for j in reversed(range(m))]


def monodromy_trace(v, x0):
    one, zero = acb(1), acb(0)
    P = [[one, zero], [zero, one]]
    for vn in v:
        P = mat_mul([[acb(x0) - vn, -one], [one, zero]], P)
    return P[0][0] + P[1][1]


def GJ_ball(u, q, nodes, want_J=True):
    m = q // 2
    v = potential(u, q)
    one, zero = acb(1), acb(0)
    G, J = [], []
    for x0 in nodes:
        T = [[[acb(x0) - vn, -one], [one, zero]] for vn in v]
        P = [[[one, zero], [zero, one]]]
        for Tn in T:
            P.append(mat_mul(Tn, P[-1]))
        G.append((P[q][0][0] + P[q][1][1]).real)
        if not want_J:
            continue
        S = [None] * (q + 1)
        S[q] = [[one, zero], [zero, one]]
        for k in range(q - 1, -1, -1):
            S[k] = mat_mul(S[k + 1], T[k])
        d = []
        for k in range(1, q + 1):
            A, B = P[k - 1], S[k]
            d.append(-(A[0][0] * B[0][0] + A[0][1] * B[1][0]))   # dD_v/dv_k
        row = [None] * q
        for j in range(m):
            a, b = d[j], d[q - 1 - j]
            row[j] = (a + b).real            # d/dx_j
            row[m + j] = -((a - b).imag)     # d/dy_j = Re(i(a-b))
        row[2 * m] = d[m].real               # d/dx_c
        J.append(row)
    return G, (J if want_J else None)


def verify(logfile):
    txt = open(logfile).read()
    mq = re.search(r'^q=(\d+) ', txt, re.M)
    mp = re.search(r'^point \(x_1\.\.x_m, y_1\.\.y_m, x_c\): (.*)$', txt, re.M)
    q = int(mq.group(1))
    toks = mp.group(1).split()
    assert len(toks) == q, 'point has %d coordinates, expected %d' % (len(toks), q)
    ctx.prec = 6 * q + 400
    pi = arb.pi()
    nodes = [2 * ((2 * j + 1) * pi / (2 * q)).cos() for j in range(q)]
    u0 = [arb(t).mid() for t in toks]
    ut = list(u0)
    for _ in range(10):
        G, J = GJ_ball(ut, q, nodes)
        du = arb_mat([[e.mid() for e in row] for row in J]).solve(arb_mat([[g.mid()] for g in G]))
        ut = [(ut[i] - du[i, 0]).mid() for i in range(q)]
    G, J = GJ_ball(ut, q, nodes)
    r = arb(2) ** (-(3 * q + 150))
    X = [arb(ut[i], r) for i in range(q)]
    Gx, _ = GJ_ball(ut, q, nodes, want_J=False)
    _, JX = GJ_ball(X, q, nodes)
    Yb = arb_mat([[e.mid() for e in row] for row in J]).inv()
    Y = arb_mat([[Yb[i, j].mid() for j in range(q)] for i in range(q)])
    Id = arb_mat([[arb(1) if i == j else arb(0) for j in range(q)] for i in range(q)])
    K = (arb_mat([[ut[i]] for i in range(q)]) - Y * arb_mat([[g] for g in Gx])
         + (Id - Y * arb_mat(JX)) * arb_mat([[X[i] - ut[i]] for i in range(q)]))
    ok = all(X[i].contains_interior(K[i, 0]) for i in range(q))
    dist = max(abs(ut[i] - u0[i]).upper() for i in range(q))
    # independent check at the stored point, 2q points off the nodes
    v0 = potential(u0, q)
    worst = arb(0)
    for k in range(2 * q):
        x = 2 * ((2 * k + 1) * pi / (4 * q)).cos()
        D0 = 2 * (q * (2 * k + 1) * pi / (4 * q)).cos()     # t^q + t^-q with t = e^{i phi}
        Dv = monodromy_trace(v0, x)
        rel = (abs(Dv - D0) / (1 + abs(D0))).upper()
        if rel > worst:
            worst = rel
    norm = sum(float(t) ** 2 for t in u0) ** 0.5
    print('q=%d prec=%d box_radius=2^-%d |u|=%.7f |refined-stored|<=%s offnode_rel_err<=%s %s' % (
        q, ctx.prec, 3 * q + 150, norm, dist.str(3, radius=False), worst.str(3, radius=False),
        'REVERIFIED' if ok else 'FAILED'), flush=True)
    return ok


if __name__ == '__main__':
    allok = True
    for fn in sys.argv[1:]:
        allok = verify(fn) and allok
    print('ALL_REVERIFIED' if allok else 'SOME_FAILED')
