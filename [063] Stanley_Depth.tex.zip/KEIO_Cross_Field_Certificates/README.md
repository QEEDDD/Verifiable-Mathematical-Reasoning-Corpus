# Exact Stanley-depth certificates and cross-field transfer notes

The completed theorem, over every field, is:

* sdepth(I_(n,2)) = 6 for n = 14, 15, 16;
* sdepth(I_(n,2)) = 7 for n = 17, 18, 19;
* sdepth(I_(n,3)) = 7 for n = 19, 20, 21, 22.

These are TEN parameter cases of ONE conjectural formula. They do not
resolve that whole conjecture, establish worldwide priority, or add ten
WOWII entries. The cases lie beyond the explicit exact ranges of the
primary papers examined. See algebra/prior_audit.md for the bounded audit.

## Reproduce the proof certificates

With Python 3.10 or later, from this folder:

```sh
python certificates.py
```

The program includes all proof data and uses only the standard library.
It enumerates all Boolean subsets for the three base cases (14,2), (17,2),
and (19,3). It checks disjointness and full coverage after singleton
completion. PASS means an exact finite interval partition has been
verified, not that random examples happened to satisfy a conjecture.
The paper proves why these partitions give Stanley decompositions and
why the known counting bound and recurrence yield the ten exact values.

Optional independent checking of the expanded certificates:

```sh
python verify_veronese_independent.py algebra/veronese14_2_partition.json
python verify_veronese_independent.py algebra/veronese17_2_partition.json
python verify_expanded.py algebra/veronese19_3_partition.json
```

The last command requires g++ with C++20 support. It uses a different
mask-by-mask checker, without cyclic orbit logic or a solver. The Python
mask-by-mask checker also accepts the largest certificate but is slower.
All three independent checks were completed successfully; outputs are
included. The compact and expanded data describe the same partitions.

The optional discovery program algebra/veronese_cyclic.py requires
OR-Tools (the recorded environment used version 9.15.6755). Commands for
the successful boundary searches were `python veronese_cyclic.py 14 2`,
`python veronese_cyclic.py 17 2`, and `python veronese_cyclic.py 19 3`.
Search is not needed to verify the supplied proof; parallel solver runs
may return different valid partitions. This boundary search script is
not asserted to find a partition for every parameter pair.

## Other attempts

The sets/, posets/, geometry/ and computation/ folders retain proved
transfer limitations, auxiliary results and their finite checks. None
of these lanes claims a newly solved named open conjecture. In particular:

* Frankl's conjecture is not disproved by a failed monotone-injection strategy.
* The 1/3--2/3 conjecture is not disproved by loss of a chosen balanced pair.
* The metric-tree shape theorem does not prove the Euclidean Steiner ratio.
* The EFX and discrepancy examples refute proposed transfer mechanisms,
  not the general named conjectures.

Geometry and some auxiliary checks use NetworkX; the primary Stanley-depth
certificate verifier does not. The TeX fragments in research-note folders
need suitable theorem environments and are not standalone manuscripts.
The separate delivered paper is a single self-contained TeX file with all
three compact certificates and the verifier embedded.
