# Algebra lane: exact Stanley-depth cases from cyclic interval certificates

## Obtained

For every field K and the squarefree Veronese ideal I_(n,d), exact finite
Boolean-interval certificates establish:

- sdepth(I_(n,2)) = 6 for n = 14, 15, 16;
- sdepth(I_(n,2)) = 7 for n = 17, 18, 19;
- sdepth(I_(n,3)) = 7 for n = 19, 20, 21, 22.

These are ten parameter pairs of ONE conjectural general formula, not ten
named conjectures and not a complete proof of that formula. No WOWII count
changes. Historical novelty is not certified here: these lie outside the
explicit published ranges inspected, but unpublished or unlocated finite
computations may exist.

The proof uses the established Herzog--Vladoiu--Zheng correspondence and
the classical counting upper bound, plus explicit cyclic interval partitions
at three boundary parameters. Variable splitting and the known maximal-ideal
formula extend each boundary to its small block. This is a genuine algebraic
conclusion about infinitely many monomials over arbitrary fields, certified
by a finite combinatorial partition. It is not random finite testing of an
universal claim.

## Deliverable source files

- `theorem_veronese.tex`: proof and exact scope.
- `veronese14_2_orbits.json`: 92 seeds, target top size6.
- `veronese17_2_orbits.json`: 472 seeds, target top size7.
- `veronese19_3_orbits.json`: 969 seeds, target top size7.
- `verify_orbit_certificate.py`: portable standard-library verifier.
- `orbit_verification.json`: completed PASS report for all three.
- `veronese_cyclic.py`: optional OR-Tools discovery program.
- `veronese*_partition.json`: expanded full interval lists; unnecessary
  for reproducing the proof from compact seeds.
- `veronese*_cyclic.log`: original discovery logs.

Every bit i encodes variable x_(i+1). Rotate endpoints simultaneously modulo
n. Complete uncovered subsets of size at least target with singleton
intervals. The checker does not use or trust the discovery solver.

## Verification counts

| n,d | target | seeds | nontrivial intervals | ideal subsets checked |
|---|---:|---:|---:|---:|
|14,2|6|92|1274|16369|
|17,2|7|472|8024|131054|
|19,3|7|969|18411|524097|

Discovery returned OPTIMAL (feasible satisfaction, no optimization objective)
in0.885s,9.168s,14.295s respectively, excluding model generation. These
durations are incidental; the explicit witnesses constitute the evidence.

Independent mask-by-mask checks passed all three expanded witnesses: Python
for (14,2) and (17,2), and C++20 for (19,3). The corresponding outputs are
in the archive root. The separate embedded-data checker also passed all three.

## Primary-source audit

1. Keller, Shen, Streib, Young, *On the Stanley Depth of Squarefree Veronese
   Ideals*, Journal of Algebraic Combinatorics33(2011),313--324.
   DOI10.1007/s10801-010-0249-1. arXiv0910.4645.
   https://arxiv.org/html/0910.4645v1
   Theorem1.1 gives n<5d+4. Section2.1 gives interval correspondence;
   Lemma2.2 gives counting upper bound; conclusion explicitly leaves
   general formula unresolved at the time of writing.
2. Ge, Lin, Shen, *On a conjecture of Stanley depth of squarefree Veronese
   ideals*, arXiv0911.5458; DOI10.1080/00927872.2011.585190.
   https://arxiv.org/abs/0911.5458
   Their explicit solved range is
   n <= (d+1) floor((1+sqrt(5+4d))/2)+2d.
   It does not cover the three boundary parameters certified here.
   It DOES cover n=5d+4 for d>=11; avoid calling that whole boundary open.
3. Herzog, Vladoiu, Zheng, *How to compute the Stanley depth of a monomial
   ideal*, Journal of Algebra322(2009),3151--3169.
   DOI10.1016/j.jalgebra.2008.01.006.
4. Biro, Howard, Keller, Trotter, Young, *Interval partitions and Stanley
   depth*, JCTA117(2010),475--482; DOI10.1016/j.jcta.2009.07.008.
   Maximal ideal formula sdepth(I_(m,1))=ceil(m/2).
5. Balanescu, Cimpoeas, Krattenthaler, *On the Hilbert depth of monomial
   ideals*, arXiv2306.09450v5,11September2025, subsequently2026journal.
   https://arxiv.org/html/2306.09450v5
   This is a Hilbert-depth formula, NOT a solution of the desired
   Stanley-depth formula. Their introduction also states the general
   module version of Stanley's conjecture has been refuted, whereas the
   ideal version remains open. Do not conflate these conjectures.

Searches for exact I_(14,2), exact14/6,and modern squarefree-Veronese
Stanley-depth work returned no earlier matching exact finite result in this
lane. Parent's literature lane is performing a separate broader audit.

## Failed direct topology transfer

It is false that purity plus minimal degeneracy forces shellability or
partitionability. Let H be the union of triangles012,234,456. It is
2-degenerate, every maximal clique has size3, and both H and its complement
are connected. Its clique complex has f-vector(1,7,9,3), hence
h-vector(1,4,-2,0). A pure partitionable complex has nonnegative h-vector,
since h_j counts intervals with lower face of size j. Thus this example
is not partitionable. It blocks a tempting but invalid direct transfer
of the WOWII simplicial-vertex lemma to a Stanley partition.

More strongly, root's private-simplex construction shows that the pure
minimal-degeneracy class can retain arbitrary finite homotopy types. The
construction was audited here and its collapse/degeneracy argument passes.

The regularity upper bound floor(degeneracy/2)+1 is a valid standard
consequence of flag homology minimum supports and is related to stronger
known collapsibility results in Malen, *Collapsibility of Random Clique
Complexes*, arXiv1903.05055. It should not be claimed as a newly solved
open algebraic problem.
