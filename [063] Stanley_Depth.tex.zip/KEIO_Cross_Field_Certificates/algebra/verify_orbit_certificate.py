"""Check a finite Stanley-depth witness using Python's standard library only.

Usage: python verify_orbit_certificate.py veronese14_2_orbits.json [...]
The SAT solver is not used, trusted, or required by this checker.
"""
import json
import sys
from collections import Counter
from pathlib import Path


def verify(path):
    data = json.loads(Path(path).read_text())
    n, d, target = (data[k] for k in ('n', 'd', 'minimum_top_size'))
    universe = (1 << n) - 1

    def rotate(mask, shift):
        return ((mask << shift) | (mask >> (n-shift))) & universe

    intervals = set()
    orbit_keys = set()
    for a, b in data['cyclic_interval_seeds']:
        assert 0 <= a <= universe and 0 <= b <= universe
        assert a & b == a and a.bit_count() >= d
        assert b.bit_count() >= target
        orbit = frozenset((rotate(a, t), rotate(b, t)) for t in range(n))
        assert orbit not in orbit_keys, 'Duplicate seed orbit'
        orbit_keys.add(orbit)
        intervals.update(orbit)

    multiplicity = [0] * (1 << n)
    for a, b in intervals:
        free = b ^ a
        sub = free
        while True:
            multiplicity[a | sub] += 1
            assert multiplicity[a | sub] == 1, 'Overlapping intervals'
            if not sub:
                break
            sub = (sub - 1) & free

    singletons = 0
    for mask in range(1 << n):
        rank = mask.bit_count()
        if rank < d:
            assert multiplicity[mask] == 0
        elif rank < target:
            assert multiplicity[mask] == 1, 'Uncovered low-rank subset'
        elif multiplicity[mask] == 0:
            # Complete the partition with [mask,mask]. Its top is large enough.
            multiplicity[mask] = 1
            singletons += 1
        else:
            assert multiplicity[mask] == 1
    return {
        'file': str(path), 'result': 'PASS', 'n': n, 'd': d,
        'minimum_top_size': target, 'orbit_seeds': len(orbit_keys),
        'nontrivial_intervals': len(intervals), 'singleton_intervals': singletons,
        'nontrivial_base_ranks': dict(sorted(Counter(a.bit_count() for a,b in intervals).items())),
        'covered_ideal_subsets': sum(multiplicity),
    }


if __name__ == '__main__':
    paths = sys.argv[1:] or sorted(Path(__file__).parent.glob('veronese*_orbits.json'))
    print(json.dumps([verify(path) for path in paths], indent=2))
