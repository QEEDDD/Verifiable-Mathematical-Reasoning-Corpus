from itertools import combinations
from collections import defaultdict
import json,time,sys
from ortools.sat.python import cp_model
from pathlib import Path
n=int(sys.argv[1]) if len(sys.argv)>1 else 14
d=int(sys.argv[2]) if len(sys.argv)>2 else 2
target=(n-d)//(d+1)+d
full=(1<<n)-1
def rot(x,t): return ((x<<t)|(x>>(n-t)))&full if t else x
def canon(x): return min(rot(x,t) for t in range(n))
def masks(k):
 for C in combinations(range(n),k): yield sum(1<<v for v in C)
rep={x:canon(x) for k in range(d,target+1) for x in masks(k)}
reps={k:sorted({rep[x] for x in masks(k)}) for k in range(d,target+1)}
print('orbit counts',{k:len(v) for k,v in reps.items()},flush=True)
candidates=[];byface=defaultdict(list);started=time.time()
for k in [d]+list(range(d+2,target)):
 for A in reps[k]:
  rest=[v for v in range(n) if not (A>>v&1)]
  seen=set()
  for add in combinations(rest,target-k):
   B=A|sum(1<<v for v in add)
   orbit=frozenset((rot(A,t),rot(B,t)) for t in range(n))
   if orbit in seen:continue
   seen.add(orbit)
   faces=set();ok=True
   for a,b in orbit:
    extra=b^a;s=extra
    while True:
     f=a|s
     if f in faces:ok=False;break
     faces.add(f)
     if not s:break
     s=(s-1)&extra
    if not ok:break
   if not ok:continue
   cs={rep[x] for x in faces};i=len(candidates)
   candidates.append((A,B,cs))
   for f in cs:byface[f].append(i)
 print('generated',k,len(candidates),'seconds',time.time()-started,flush=True)
model=cp_model.CpModel();vs=[model.NewBoolVar(f'x{i}') for i in range(len(candidates))]
for k in range(d,target+1):
 for f in reps[k]:
  terms=[vs[i] for i in byface[f]]
  if k<target:model.AddExactlyOne(terms)
  else:model.AddAtMostOne(terms)
solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=180
solver.parameters.num_search_workers=8
solver.parameters.log_search_progress=True
status=solver.Solve(model);print('STATUS',solver.StatusName(status),flush=True)
if status in (cp_model.FEASIBLE,cp_model.OPTIMAL):
 selected=[];covered=set()
 for i,(A,B,cs) in enumerate(candidates):
  if not solver.Value(vs[i]):continue
  orb=frozenset((rot(A,t),rot(B,t)) for t in range(n))
  selected.extend(sorted(orb))
  for a,b in orb:
   extra=b^a;s=extra
   while True:
    f=a|s;assert f not in covered;covered.add(f)
    if not s:break
    s=(s-1)&extra
 for k in range(d,target):assert all(x in covered for x in masks(k))
 selected.extend((x,x) for x in masks(target) if x not in covered)
 selected.extend((x,x) for k in range(target+1,n+1) for x in masks(k))
 out=Path(__file__).with_name(f'veronese{n}_{d}_partition.json')
 out.write_text(json.dumps({'n':n,'d':d,'minimum_top_size':target,'intervals':selected}))
 print('CERTIFICATE',out,'intervals',len(selected))
