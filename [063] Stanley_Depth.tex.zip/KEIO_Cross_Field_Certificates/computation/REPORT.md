# Round 10: local cuts, threshold control, fair division and discrepancy

## Outcome

No previously open conjecture outside graph theory was closed in this lane.
The successful deduction is a cost-sensitive heterogeneous-threshold certificate,
proved below; it extends the paper's local-cut argument but should be treated as
an algorithmic extension, not as an independently established new resolution.
Two explicit obstructions show why the argument cannot simply be transplanted
into EFX fair division or Beck--Fiala discrepancy.

## 1. Exact positive transfer: costs and heterogeneous thresholds

Let G be a finite simple undirected graph, I a prescribed seed set,
tau(v) nonnegative integer thresholds, and c(v) nonnegative integer costs.
Assume

    d_G(v) + |N_G(v) intersect I| >= 2 tau(v) - 1   for every v outside I.

For a graph J, define nu_c(J) as the largest sum of nonnegative integer edge
multiplicities z_e satisfying sum_{e incident v} z_e <= c(v) at every vertex.
Edges may have multiplicity exceeding one; c is a vertex capacity, not an edge
weight. For c identically one this is the ordinary matching number.

**Theorem.** There is a seed set D containing I such that every vertex outside D
has at least tau(v) neighbors in D and

    c(D) <= c(I) + nu_c(G-I).

The set D can be constructed in polynomial time in the ordinary binary input
size, using only unit graph edges, a local cut and a minimum-cost bipartite
vertex cover. Consequently an irreversible threshold process seeded by D
activates every other vertex in its very first update round.

**Proof.** Set J=G-I. Starting from any two-coloring of J, flip any vertex with
more same-color than opposite-color neighbors. Each successful flip increases
the integer cut size, so at most |E(J)| flips occur. Let B be the bipartite
crossing-edge graph. If a=|N_G(v) intersect I| then every v in J has

    a + d_B(v) >= a + ceil((d_G(v)-a)/2)
                 = ceil((d_G(v)+a)/2) >= tau(v).

Take a minimum-cost vertex cover C of B. For v outside I union C, every B-neighbor
is in C, so D=I union C has the required threshold property. Weighted bipartite
cover/flow duality, with integral vertex capacities c, gives c(C)=nu_c(B).
Since B is a subgraph of J, nu_c(B)<=nu_c(J), proving the inequality. A
polynomial-time max-flow/min-cut algorithm finds C even when the costs are
binary-encoded and numerically large. The cut itself is unweighted, so its
flip count does not depend on those costs. QED.

This is an application of the same combinatorial mechanism as the original
paper. There is no historical novelty claim. It should not be listed as an
additional solved named conjecture.

### Weighted-influence caveat

If *edge influences* are integer-weighted, the existential proof works after
replacing degrees by incident weight sums and using a locally maximal weighted
cut. But the naive flip bound becomes the sum of edge weights, which can be
exponential in their binary encoding. It is incorrect to infer polynomial time
from that potential bound. Weighted Local Max-Cut is PLS-complete; see the
primary source arXiv:1004.5329 and the references there. Vertex costs in the
unit-edge theorem above do not cause this issue.

### Exact finite verification

`check_transfer.py` ran 627 instances: three deterministic choices of seed sets,
integer costs in {0,1,2,3}, and maximal admissible heterogeneous thresholds for
every graph-atlas graph of order at most six. It checked the local-cut witness,
exhaustively optimized the bipartite weighted cover, and independently computed
nu_c by integer dynamic programming on edge multiplicities. All passed.
`check_transfer.json` contains the result. Finite testing is supplementary to the proof.

## 2. Target-set-selection route: apparent targets already solved

The first tempting claim was a matching-number upper bound for majority
activation. That is not an unclaimed open target. Khoshkhah, Soltani and Zaker,
*On dynamic monopolies of graphs: the average and strict majority thresholds*
(2012), explicitly prove a strict-majority dynamic-monopoly bound mu(G)+1 and
algorithmic half-order results. The paper's static sufficient seed set can be
useful, but an unrestricted new dynamic-majority resolution was not obtained.

Primary source: https://arxiv.org/abs/1202.1146
Root-openable source ref: turn469view2 (abstract lines16--19).

## 3. EFX fair division: genuine open target, failed simple transfer

For additive valuations v_i and an allocation A, EFX means
v_i(A_i) >= v_i(A_j minus {g}) for every i,j and every g in A_j.
General additive EFX existence is identified as open by the primary works
below. Branzei (2025) studies single-item local search and already proves that
variance descent works for identical valuations. The paper explicitly notes
that the total violation count can have strictly positive local minima.
Therefore the claim "an integer potential decreases, hence EFX is reached"
lacks exactly the essential implication that non-EFX states always have a
decreasing move.

### Explicit obstruction to the most direct variance extension

Use two agents and three goods a,b,c, with strictly positive valuations

    agent 1: 2,5,5
    agent 2: 10,1,1.

Both agents assign total value12 to all goods, so the failure is not removed
by normalizing total values. Allocate {a} to agent1 and {b,c} to agent2.
The agents' own utilities are (2,2), so the variance of own utility is zero,
a global minimum. Yet agent1 values either singleton remaining after removal
of b or c at5>2. Hence this global variance minimum is not EFX.

The same example gives a structural warning for any potential invariant under
permuting bundle owners. No partition of these three goods is EFX under *both*
assignments of its bundles to the two agents:

- empty|abc is not EFX in either assignment;
- a|bc makes agent1 with a envious;
- b|ac makes agent2 with b envious;
- c|ab makes agent2 with c envious.

Thus any bundle-label-invariant objective has a non-EFX global minimizer on
this instance: take an optimal partition and choose its bad assignment.
This is a direct finite proof, not a disproof of EFX existence. An EFX
allocation does exist, for example agent1 receives {b}, agent2 receives {a,c}.

### Scope audit preventing a false "new closure"

Graphical valuations are already known to admit EFX allocations. More strongly,
Afshinmehr et al. (June2026), arXiv:2606.18665, prove existence for multigraph
instances under cancelable valuations, a superclass of additive valuations.
Consequently translating a graph-cut argument to goods valued by two agents
would not in itself close an outstanding EFX problem.

Primary sources:
- https://arxiv.org/html/2510.05429v1 ; refs turn469view0 / turn471view0 / turn471view1.
  Exact objective and positive local minima: lines96--130.
  Identical-valuation variance potential: lines236--257.
- https://arxiv.org/abs/2606.18665 ; ref turn469view1.
  Exact multigraph closure and scope: abstract lines16--19.

## 4. Beck--Fiala: a precise failure of the incidence-cut route

The conjecture asks for an O(sqrt(t)) discrepancy coloring of every set system
in which each element occurs in at most t sets. The cut proof supplies
one-sided neighborhood coverage, whereas discrepancy requires two-sided balance.
Their difference cannot be fixed by directly taking a maximal cut of the
set-element incidence graph.

**Counterfamily.** Take one set S consisting of 2q elements. The occurrence
bound is t=1. Its incidence graph is a star. Every locally maximal cut cuts
every edge: each leaf would otherwise improve the cut by flipping. Therefore
all element vertices have the same sign, giving discrepancy2q on S, although
an equal split gives discrepancy0. The method fails without bound even for
t=1 and even when it finds a *global* maximum cut.

This refutes the proposed bridge, not the Beck--Fiala conjecture.
A different potential or rounding invariant is required; a matching bound
alone does not give the missing two-sided control.

Primary contextual sources:
- Bansal--Jiang, *An Improved Bound for the Beck-Fiala Conjecture*,
  https://arxiv.org/abs/2508.01937 (turn466search0).
- Altschuler, *Improved Algorithms for Beck--Fiala with Bounded Sets*,
  https://arxiv.org/abs/2609.19714 (turn466academia30).
The later paper gives bounded-row-size results, not a universal closure.
No claim here that the 2025 bound is the latest general bound in October2026.

## Safe summary for integration

- Newly closed named open problems in this lane: **0**.
- Proved extension: cost-sensitive heterogeneous-threshold seed certificate.
- Proved transfer obstructions: normalized-positive EFX variance example and
  label-invariant potential impossibility; t=1 incidence-cut discrepancy failure.
- Historical-priority claims: none.
- No edits were made to the existing WOWII paper.
