from itertools import product, combinations
import networkx as nx
import random, json

def cap_matching(G,c):
    # Exact integer b-matching with unrestricted edge multiplicity, by DP.
    es=list(G.edges()); memo={}
    vs=list(G); index={v:i for i,v in enumerate(vs)}
    cap=tuple(c[v] for v in vs)
    def dp(j,a):
        key=(j,a)
        if key in memo:return memo[key]
        if j==len(es):return 0
        u,v=map(index.get,es[j]);ans=0
        for t in range(min(a[u],a[v])+1):
            z=list(a);z[u]-=t;z[v]-=t
            ans=max(ans,t+dp(j+1,tuple(z)))
        memo[key]=ans;return ans
    return dp(0,cap)

def weighted_cover(B,c):
    vs=list(B)
    ans=None
    for mask in range(1<<len(vs)):
        C={v for j,v in enumerate(vs) if mask>>j&1}
        if all(u in C or v in C for u,v in B.edges()):
            value=sum(c[v] for v in C)
            if ans is None or value<ans[0]:ans=(value,C)
    return ans

def construct(G,I,c,tau):
    J=G.subgraph(set(G)-I).copy();color={v:0 for v in J};steps=0
    while True:
        changed=False
        for v in J:
            cross=sum(color[v]!=color[w] for w in J[v])
            if 2*cross<J.degree(v):color[v]^=1;steps+=1;changed=True;break
        if not changed:break
    assert steps<=J.number_of_edges()
    B=nx.Graph();B.add_nodes_from(J);B.add_edges_from((u,v) for u,v in J.edges() if color[u]!=color[v])
    covercost,C=weighted_cover(B,c);D=I|C
    assert all(len(set(G[v])&D)>=tau[v] for v in set(G)-D)
    bound=sum(c[v] for v in I)+cap_matching(J,c)
    cost=sum(c[v] for v in D)
    assert cost<=bound
    return steps

def efx(v,assignment):
    n=len(v);A=[{g for g,a in enumerate(assignment) if a==i} for i in range(n)]
    violations=[]
    for i in range(n):
        own=sum(v[i][g] for g in A[i])
        for j in range(n):
            if i==j:continue
            for g in A[j]:
                other=sum(v[i][h] for h in A[j]-{g})
                if other>own:violations.append((i,j,g,other-own))
    return violations

rng=random.Random(20261026);checked=0;steps=0
for G in nx.graph_atlas_g():
    if len(G)>6:continue
    for rep in range(3):
        c={v:rng.randrange(4) for v in G}
        I={v for v in G if rng.randrange(3)==0 or G.degree(v)==0}
        tau={v:max(0,(G.degree(v)+len(set(G[v])&I)+1)//2) for v in G}
        steps+=construct(G,I,c,tau);checked+=1
v=[[2,5,5],[10,1,1]];allocation=(0,1,1)
assert all(sum(row)==12 for row in v)
assert [sum(v[i][g] for g,a in enumerate(allocation) if a==i) for i in range(2)]==[2,2]
assert efx(v,allocation)
# Every unordered partition has a bad bundle-owner assignment.
for assignment in product(range(2), repeat=3):
    swapped=tuple(1-a for a in assignment)
    assert efx(v,assignment) or efx(v,swapped)
assert not efx(v,(1,0,1))
print(json.dumps({'weighted_threshold_certificates':checked,'flip_steps_total':steps,'variance_counterexample':{'values':v,'assignment':allocation,'violations':efx(v,allocation)},'result':'PASS'},indent=2))
