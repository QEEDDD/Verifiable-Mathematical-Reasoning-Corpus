# Geometry transfer: exact metric-tree extremals, stability, and failed open-problem bridges

**Outcome:** no new closure of a presently open named conjecture in this lane. A rigorous sharp continuous theorem with a quantitative stability refinement is obtained below. Its historical novelty has not been established. The geometric Steiner-ratio conjectures remain unresolved here.

## 1. Actual external targets and current-source audit

1. Gilbert--Pollak (1968): every finite Euclidean planar terminal set has SMT/MST at least sqrt(3)/2. A primary 2026 paper of Ke et al., *Towards Solving the Gilbert-Pollak Conjecture via Large Language Models*, ICML/PMLR306, reports the lower bound 0.8559, below the conjectured constant. This is the current primary result located, not an assertion that no later result can exist.
   - https://proceedings.mlr.press/v306/ke26a.html (root should open before citing; agent ref turn459view0)
   - https://arxiv.org/abs/2601.22365 (version2 May21,2026)
2. Fleischmann--Gamboa--Karthik--Matejka--Petr, *On Steiner Trees of the Regular Simplex*, arXiv2312.01252, Conjecture1.2: for a fixed number of terminals, the regular simplex minimizes SMT/MST. The article's weaker Conjecture1.3 concerns characteristic-vector embeddings of graph edges.
   - https://arxiv.org/html/2312.01252v1 (agent ref turn462view0, lines82--95)
   - published JoCG16(1),2025: https://jocg.org/index.php/jocg/article/view/4741
3. The weaker graph-embedding conjecture is **already solved** by a Kirszbraun extension argument in Woodruff et al., *Accelerating Scientific Research with Gemini*, arXiv2602.03837, Section4.2/Theorem4.14. I independently reconstructed the same contraction argument before finding this prior result. It must NOT be counted as a new closure.
   - https://arxiv.org/abs/2602.03837 (v1 Feb3,2026; v3 Mar6,2026)
   - author-hosted primary full paper: https://lance.fortnow.com/papers/files/AIdiscovery.pdf (agent ref turn481view1; Section4.2 starts p28)

No reliable prior match for the exact metric-tree stability formulation below was found in a short targeted search, but this is not enough to establish novelty.

## 2. Sharp theorem in metric geometry

A finite metric tree is a finite tree with positive edge lengths, including all points along each edge. Write L for its total length, r for its intrinsic radius, and

    p = max over x,y,z in T of min{d(x,y),d(y,z),d(z,x)}.

Thus the dispersion is optimized over the whole continuous tree, not only the vertices of a combinatorial representation. Assume r>0. Then r<=p<=2r.

**Theorem.**

    L >= r+p.

Equality holds exactly when T is the metric tripod with arm lengths

    r, r, p-r,

where a zero third arm means the interval of length2r. Consequently, for every pair r>0 and r<=p<=2r the minimum possible total length is exactly r+p, and its metric is unique up to isometry.

**Proof.** Let P be a diametral segment of length D=2r and let h=max d(x,P). Given any triple, project its points to P and order the projection coordinates as a<=b<=c. If their heights are hx,hy,hz, maximality of D implies hx<=a and hz<=D-c. Hence

    d(x,y)<=b+hy,   d(y,z)<=D-b+hy,

and the minimum pairwise distance is at most D/2+h=r+h. Therefore p<=r+h. The union Y of P and a path of height h has length D+h, so

    L >= D+h >= r+p.

For equality both inequalities must be equalities. Thus T=Y (a finite positive-length tree has no extra branch of length zero). Put the attachment coordinate a in [0,r] by reversing P. The tripod arms are a,2r-a,h, with h<=a because P is diametral. Its dispersion is

    p(Y)=max{r,a+h}.

Indeed, three points in distinct arms have minimum pairwise distance at most a+h; if two lie in one arm, their two relevant consecutive distances have sum at most D and hence minimum at most r. Both bounds are attained: use endpoints and midpoint of P, or the three leaves. If h>0, equality p=r+h therefore forces a=r. If h=0, T is an interval. Conversely the displayed balanced tripod has radius r, dispersion p and length r+p. QED.

The transfer is the continuous form of the WOWII diameter-projection argument. The exact optimizer and the stability statement below extend what the paper currently states. This is still tree-shaped geometry, not a complete escape from the paper's combinatorial setting.

## 3. Quantitative shape stability

Let S(r,p) denote the balanced tripod of arm lengths r,r,p-r.

**Theorem.** If epsilon=L-r-p, then

    d_GH(T,S(r,p)) <= 2 epsilon.

No optimality claim is made for the constant2.

**Proof.** Keep P,Y,a,h from above and define

    q=L-(2r+h),   delta=r+h-p.

Both are nonnegative and epsilon=q+delta. Let h*=p-r=h-delta. The total length discarded in passing from T to Y is q, so Y is an isometric subtree and d_GH(T,Y)<=q (indeed its Hausdorff distance in T is at most q).

Nearest-point projection from T to Y loses at most q in each pairwise distance: the portions of the unique geodesic outside Y are disjoint edges with total length at most q. Thus

    p <= p(Y)+q = max{r,a+h}+q.

Consider two cases.

* If a+h>=r, this gives r-a<=delta+q=epsilon. Shift the attachment point of the extra arm from a to r and shorten its length by delta to obtain S(r,p). Pair the points of the common base interval identically, and pair a point at height t on the old arm with the point at height min(t,h*) on the new arm. Include both base- and arm-pairings at attachment points. This is a surjective correspondence of distortion at most (r-a)+delta: for a base/arm pair use ||a-s|-|r-s||<=r-a, and for an arm/arm pair truncation loses at most delta. The standard correspondence bound gives d_GH(Y,S)<=((r-a)+delta)/2; the weaker bound <=(r-a)+delta is enough. Consequently

      d_GH(T,S)<=q+(r-a)+delta<=2epsilon.

* If a+h<r, then h*=p-r<=q and h=delta+h*<=delta+q=epsilon. Realize Y and S together as the same base interval with their two respective pendant arms attached. Their Hausdorff distance in this common metric tree is at most max(h,h*)=h. Thus d_GH(T,S)<=q+h<=2epsilon.

This proves the assertion. QED.

## 4. A Euclidean consequence and why it does not solve Gilbert--Pollak

For a finite Euclidean terminal set A with at least three points, let R(A) be its minimum enclosing-ball radius and p3(A) its maximum minimum pairwise separation among triples. Every embedded Steiner tree T spanning A, equipped with its intrinsic path metric, satisfies

    length(T) >= R(A)+p3(A).

The intrinsic center of T has ambient distance at most its intrinsic radius to every terminal, so R(A)<=r(T). Ambient pairwise distances are at most intrinsic distances, so p3(A)<=p(T). Apply the theorem. This inequality is a correct independent corollary, with no historical novelty claim.

It does not yield the desired global SMT/MST ratio. The decisive obstruction is that intrinsic tree metrics discard Euclidean angles. In the unit-arm tripod with its three endpoints as terminals, SMT=3 while the terminal MST in the tree metric has length4, so SMT/MST=3/4<sqrt(3)/2. The sharp radius--dispersion bound is already attained by this tripod. Thus an argument valid for arbitrary metric trees cannot establish the Euclidean constant without using additional Euclidean information. A star on m unit arms similarly has ratio m/(2m-2), tending to1/2. Restricting to degree-three trees does not fix the loss: replace the star center by a binary tree with arbitrarily short positive internal edges.

For the fixed-terminal simplex-ratio conjecture, Kirszbraun does imply contraction monotonicity of SMT: a 1-Lipschitz map of terminals extends to all Steiner vertices and cannot increase the objective. However, it also changes the terminal MST. Contracting all distances to the minimum terminal separation controls the numerator without preserving the normalized denominator. This is precisely why the known graph-embedding case does not settle the general ratio conjecture.

## 5. Finite corroboration

`verify_metric_tree.py` uses NetworkX and standard Python only. It checks 800 integer-weighted trees (orders2--9, edge lengths1--3). On half-unit subdivisions it enumerates every triple and independently confirms the exact continuous dispersion formula

    p(T)=max{D/2, max_v (second-largest branch height + third-largest branch height)}.

The half-unit grid is sufficient because the displayed exact formula is integral or half-integral. It verifies the length inequality, equality characterization, and all algebraic estimates used in stability. It does not numerically compute an exact Gromov--Hausdorff distance. Results are in `verify_metric_tree.json`.
