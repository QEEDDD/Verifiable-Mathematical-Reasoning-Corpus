#!/usr/bin/env python3
"""Exact half-unit subdivision corroboration of metric-tree dispersion formula."""
import itertools,json,random
import networkx as nx
rng=random.Random(20261026)
counts=0;equality=0
for n in range(2,10):
    for rep in range(100):
        tree=nx.random_labeled_tree(n,seed=rng)
        for u,v in tree.edges:tree[u][v]['weight']=rng.randint(1,3)
        dist=dict(nx.all_pairs_dijkstra_path_length(tree,weight='weight'))
        D=max(max(d.values()) for d in dist.values());r=D/2
        lengths=[]
        for v in tree:
            hs=[]
            for w in tree[v]:
                seen={v};stack=[w];best=0
                while stack:
                    u=stack.pop();seen.add(u);best=max(best,dist[v][u]);stack.extend(x for x in tree[u] if x not in seen)
                hs.append(best)
            if len(hs)>=3:
                hs.sort(reverse=True);lengths.append(hs[1]+hs[2])
        p=max([r]+lengths)
        sub=nx.Graph();sub.add_nodes_from(tree);nextnode=n
        for u,v in tree.edges:
            path=[u]
            for _ in range(2*tree[u][v]['weight']-1):path.append(nextnode);nextnode+=1
            path.append(v);sub.add_edges_from(zip(path,path[1:]))
        sd=dict(nx.all_pairs_shortest_path_length(sub))
        p_brute=max(min(sd[x][y],sd[y][z],sd[z][x]) for x,y,z in itertools.combinations(sub,3))/2
        assert p==p_brute
        L=sum(tree[u][v]['weight'] for u,v in tree.edges)
        assert L>=r+p
        u,v=max(((u,v) for u in tree for v in tree),key=lambda uv:dist[uv[0]][uv[1]])
        path=nx.shortest_path(tree,u,v)
        w=max(tree,key=lambda w:min(dist[w][x] for x in path));h=min(dist[w][x] for x in path)
        attach=min(path,key=lambda x:dist[w][x]);a=min(dist[u][attach],dist[v][attach]);q=L-D-h;delta=r+h-p;eps=L-r-p
        assert min(q,delta,eps)>=0 and eps==q+delta
        py=max(r,a+h)
        assert p<=py+q
        if a+h>=r:assert r-a<=eps
        else:assert h<=eps
        if eps==0:
            equality+=1
            assert q==0 and (h==0 or a==r)
        counts+=1
print(json.dumps({'PASS':True,'weighted_trees':counts,'orders':[2,9],'integer_edge_lengths':[1,3],'continuous_dispersion_verified_by':'half-unit subdivisions and exhaustive triples','equality_cases':equality},indent=2))
