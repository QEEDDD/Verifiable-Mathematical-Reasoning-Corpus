# Order-theory transfer: the 1/3–2/3 conjecture

## Outcome

No new complete resolution of an open poset conjecture was obtained. The
existing WOWII deletion/degeneracy argument does not automatically transfer
to uniform linear-extension probabilities. An exact six-element obstruction
identifies the missing ingredient. A quantitative insertion criterion below
is a valid auxiliary result, but no claim of historical novelty is made.

## Target and current primary-source status

For a finite poset P which is not a chain, the 1/3–2/3 conjecture asks for
incomparable a,b satisfying 1/3 <= Pr_P(a before b) <= 2/3 in a uniformly
random linear extension. This is a different invariant from domination,
clique number, radius or degeneracy.

Primary sources inspected:

1. Max Aires, Swee Hong Chan, Igor Pak, Greta Panova, *Breaking the Infinite
   Barrier in the 1/3–2/3 Conjecture*, arXiv:2609.30888, September 2026.
   https://arxiv.org/pdf/2609.30888 . Introduction, Conjecture 1.1 and
   Theorem 1.2: the general conjecture is still stated as open; their result
   improves the previous universal constant (5-sqrt(5))/10 by a positive
   epsilon, not all the way to 1/3. Primary retrieval ref: turn476view0.
2. Imed Zaguia, *The 1/3–2/3 Conjecture for ordered sets whose cover graph
   is a forest*, arXiv:1610.00809. https://arxiv.org/pdf/1610.00809 .
   Theorems 2 and 3 give established good-pair/almost-twin tools. Thus the
   straightforward forest transfer would repeat a known solution.
   Primary retrieval ref: turn476view1.
3. Emily J. Olson, Bruce E. Sagan, *On the 1/3–2/3 Conjecture*,
   arXiv:1706.04985. https://arxiv.org/pdf/1706.04985 .
   Theorem 1.3 and Definition 1.2 record almost twins; the paper also handles
   several lattice and Young-diagram classes. Primary ref: turn476view2.

This scoped search is not a worldwide exhaustive literature audit.

## Exact failure of the simplicial-deletion bridge

Let P consist of the chain a1<a2<a3, an element b incomparable with all
three chain elements, and two incomparable elements x,y above all of
{a1,a2,a3,b}. Equivalently,

    P = (C_3 disjoint-union {b}) ordinal-sum A_2.

Its incomparability graph H is K_(1,3) disjoint-union K_2. Thus:

- every maximal clique of H has size k=2;
- H is (k-1)=1-degenerate;
- the complement of H is connected;
- a3 is a degree-(k-1) simplicial vertex;
- deleting a3 preserves both purity and degeneracy.

These are exactly the strong graph-side hypotheses motivating the transfer.
Nevertheless, the pair (a1,b) is balanced after deletion and unbalanced
before deletion:

    Pr_{P-a3}(a1 before b) = 2/3,
    Pr_P(a1 before b)      = 3/4.

Proof: b can be inserted into the chain in any of its four gaps, equally
likely; a1 precedes b in three. For the two-element chain after deletion,
there are three gaps and two favorable gaps. The independent ordering of
x,y contributes the same factor 2 to every case. Therefore P has 8 linear
extensions, P-a3 has 6, and the displayed probabilities are exact.

The included verify_obstruction.py enumerates all permutations to verify
8, 6, 3/4 and 2/3 independently. It uses only Python's standard library.

This is NOT a counterexample to the 1/3–2/3 conjecture: x,y are a 1/2 pair.
It refutes the proposed proof step that any balanced pair in a smaller
pure-degenerate instance can simply be retained after reinsertion.
Also, when H is the incomparability graph, the two nonadjacent simplicial
vertices supplied by the WOWII lemma are comparable in P; they cannot
be a balanced pair themselves.

## The exact missing quantity: insertion weights

Let v be any element of a finite poset P, and Q=P-v. For a linear extension
L of Q, let w_v(L) be the number of gaps into which v can be inserted
without violating P. It is a positive integer. Let A be the event that a
precedes b, for two elements a,b of Q. Then

    Pr_P(A) = E_Q[w_v 1_A] / E_Q[w_v],

where E_Q is uniform over linear extensions of Q. Consequently

    Pr_P(A) - Pr_Q(A) = Cov_Q(w_v,1_A) / E_Q[w_v].

Proof: each L has exactly w_v(L) preimages under deletion of v from a
linear extension of P. Count preimages in A and in the whole sample space.
The covariance identity follows by expanding its definition.

For the six-element example the three orders of {a1,a2,b} have weights
1,1,2. The favorable event contains the second and third orders. Uniform
weight gives 2/3; the actual insertion weights give (1+2)/(1+1+2)=3/4.
Graph purity and a degeneracy ordering do not control this covariance.

## A valid quantitative transfer criterion

Suppose m <= w_v(L) <= M for every extension L of Q and let R=M/m.
Writing p=Pr_Q(A), direct weighting yields

    p/[p+R(1-p)] <= Pr_P(A) <= Rp/[Rp+1-p].

Proof: weight A by at least m and its complement by at most M for the
lower bound; reverse these choices for the upper bound.

In particular, if p=1/2 and R<=2, then (a,b) is 1/3-balanced in P.
If v is incomparable with at most one element, its number of insertion
gaps is at most 2 and at least 1, so this criterion applies whenever Q
has a 1/2 pair. No enumeration is required for this implication.

This auxiliary criterion makes the transfer genuinely probabilistic, but
it does not solve the target. General deletion need not produce a 1/2 pair,
and iterated insertion can accumulate unbounded weight distortion. Merely
showing that the reduced poset has some 1/3-balanced pair is insufficient,
as the exact obstruction already shows.

## Other routes examined

- Interpreting H as the comparability graph instead changes maximal cliques
  to maximal chains, so the graph hypotheses become equal maximal-chain
  length and small comparability degeneracy. The pure-clique lemma then
  produces incomparable vertices, but gives no linear-extension probability
  bound or established good-pair condition. No complete proof was obtained.
- Interpreting H as the incomparability graph gives equal maximal-antichain
  size. Low-width and forest subcases overlap known results, and the above
  example blocks naive induction even inside that restricted class.
- A graph-only center/diameter statement does not determine the insertion
  weights. A successful extension needs an additional probabilistic
  inequality, not only the graph geometry proved in the WOWII manuscript.

## Count

Additional fully resolved pre-existing open conjectures from this lane: 0.
Established new-to-this-session conclusions: an exact failed-bridge example
and the insertion-weight criterion. Neither is counted as historical novelty.
