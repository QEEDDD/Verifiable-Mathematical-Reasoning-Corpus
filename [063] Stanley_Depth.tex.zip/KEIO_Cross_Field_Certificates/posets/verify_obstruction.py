from fractions import Fraction
from itertools import permutations
import json

def extensions(vertices, relations):
    out=[]
    for perm in permutations(vertices):
        position={v:i for i,v in enumerate(perm)}
        if all(position[x]<position[y] for x,y in relations):out.append(perm)
    return out

def probability(exts,a,b):
    return Fraction(sum(p.index(a)<p.index(b) for p in exts),len(exts))

V=['a1','a2','a3','b','x','y']
rels=[('a1','a2'),('a2','a3'),('a1','a3')]
rels += [(a,z) for a in V[:4] for z in ['x','y']]
E=extensions(V,rels)
W=[v for v in V if v!='a3']
F=extensions(W,[(a,b) for a,b in rels if a in W and b in W])
assert len(E)==8 and len(F)==6
assert probability(E,'a1','b')==Fraction(3,4)
assert probability(F,'a1','b')==Fraction(2,3)
print(json.dumps({'P_extensions':len(E),'deleted_extensions':len(F),'P_a1_before_b':str(probability(E,'a1','b')),'deleted_a1_before_b':str(probability(F,'a1','b')),'result':'PASS'},indent=2))
