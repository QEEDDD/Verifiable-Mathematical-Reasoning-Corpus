# Round 10: set-system transfer

**Complete pre-existing open conjectures resolved in this lane: 0.**

## Target and prior-art audit

The target was Frankl's union-closed sets conjecture, an actual problem
in extremal set theory rather than a renamed domination inequality.
The inspected primary sources still treat the half-frequency conclusion
as unresolved. I tried the direct extension/matching route suggested by
the WOWII prescribed-set and matching proofs.

Primary sources inspected:

1. Pulaj and Wood, *Local Configurations in Union-Closed Families*,
   arXiv:2301.01331v2, 14 October 2024 (journal publication 2025),
   https://arxiv.org/html/2301.01331v2 .
   Introduction states the target and confirms that the old Morris
   three-set conjecture FC(3,n)=floor(n/2)+1 has ALREADY been proved by
   Pulaj. It must not be offered as a fresh open target. Their Conjecture1
   is a genuine lexicographic-extremality assertion for FC(k,n); I did
   not prove it. The paper also explains Poonen's obstruction to forcing
   an abundant element from one prescribed3set.
2. George M. Bergman, *Some Notes Regarding Peter Frankl's Conjecture*,
   dated 27 May 2026,
   https://math.berkeley.edu/~gbergman/papers/unpub/PFrankl_thts.pdf .
   Gives a two-element extension result and demonstrates that maximum
   frequency need not occur in a minimal nonempty member. That is
   already prior work, not a result of this attempt.
3. Costa and Sadhu, *Beyond Liu's 0.382709 Threshold for the Union-Closed
   Sets Conjecture*, arXiv:2610.02295,
   https://arxiv.org/abs/2610.02295 .
   Current primary record checked to avoid relying solely on an old
   open-status statement.

## An actual failed transfer, with a proved infinite obstruction

See `obstruction.tex` for the full proof. Let F_n consist of all unions
of cyclic consecutive pairs on [n], including empty, n>=5.
Every element is abundant. Nevertheless, for EVERY element x there is
NO injection from x-absent sets to x-present sets which only adds elements.

The Hall witness consists of four sets R, R+a, R+b, R+a+b, where a,b are
x's cyclic neighbors and R=[n] minus {a,x,b}. Their possible x-containing
supersets in F_n number exactly THREE: R+x+a, R+x+b, and [n].
For n5 this is a17-member transitive family with every frequency10/17.
Thus even selecting an abundant / maximum-frequency coordinate cannot
save the direct containment-matching strategy.

This obstruction was first found in a deterministic random search of
union-generated families, recognized as C5, and extended to all n>=5.
It is not a counterexample to Frankl. It is not represented as a
previously posed open conjecture, and historical novelty is not claimed.
It gives a concrete reason the WOWII matching proof does not simply
transfer to the Frankl problem.

## Verification

Run `python verify_obstruction.py` (standard library only).
`verification.json` records a completed PASS:
- generated-family and binary-string characterizations agree n5..14;
- four-to-three Hall witnesses verified for every coordinate;
- exact bipartite matching computed independently n5..9;
- every full-support union-closed family on1,2,3,4 elements enumerated;
  counts2,8,90,4542; each has at least one containment injection.

The exploratory `experiment.py` and `matching_counter.json` preserve the
first found instance. They are not needed to reproduce the proof.

## Quantitative amplification

A direct product of t disjoint C5 families gives17^t sets. Every element
still has abundance10/17, but the maximum containment matching from sets
omitting it has size exactly6*17^(t-1), leaving17^(t-1) unmatched out of
7*17^(t-1). Thus the obstruction persists as a fixed1/7 fraction of the
source class; it is not merely an isolated one-set exception. The corollary
and explicit6-edge base matching are included in `obstruction.tex`.
