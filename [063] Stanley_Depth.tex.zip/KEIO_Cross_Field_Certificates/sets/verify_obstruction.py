"""Exact finite corroboration of the monotone-injection obstruction.
Only the Python standard library is required.
"""
from itertools import combinations
import json

def generated(generators):
    family={0}
    for g in generators:
        family|={a|g for a in family}
    return family

def cycle_family(n):
    return generated([(1<<i)|(1<<((i+1)%n)) for i in range(n)])

def matching_size(F,x):
    absent=[a for a in F if not a>>x&1]
    present=[a for a in F if a>>x&1]
    adj=[[j for j,b in enumerate(present) if a&b==a] for a in absent]
    mt={}
    def aug(i,seen):
        for j in adj[i]:
            if j in seen:continue
            seen.add(j)
            if j not in mt or aug(mt[j],seen):
                mt[j]=i
                return True
        return False
    return sum(aug(i,set()) for i in range(len(absent))),len(absent)

def check_cycles():
    records=[]
    for n in range(5,15):
        F=cycle_family(n)
        full=(1<<n)-1
        # Independent characterization: selected vertices have no isolated 1.
        expected={a for a in range(1<<n) if all(not a>>i&1 or
            a>>((i-1)%n)&1 or a>>((i+1)%n)&1 for i in range(n))}
        assert F==expected
        frequencies=[]
        for x in range(n):
            left=(x-1)%n;right=(x+1)%n
            R=full^((1<<x)|(1<<left)|(1<<right))
            A={R,R|(1<<left),R|(1<<right),R|(1<<left)|(1<<right)}
            assert len(A)==4 and A<=F and all(not a>>x&1 for a in A)
            B={b for b in F if b>>x&1 and any(a&b==a for a in A)}
            assert len(B)==3
            frequencies.append(sum(bool(a>>x&1) for a in F))
            assert 2*frequencies[-1]>=len(F)
            if n<=9:
                m,absent=matching_size(F,x)
                assert m<absent
        assert len(set(frequencies))==1
        records.append({'n':n,'family_size':len(F),'frequency_each':frequencies[0],
                        'Hall_left':4,'Hall_right':3})
    return records

def check_small_universes():
    counts={}
    for n in range(1,5):
        top=(1<<n)-1;tested=0
        # No need to assume empty belongs, but top must belong and support is full.
        for code in range(1<<(1<<n)):
            if not (code>>top)&1:continue
            F=[a for a in range(1<<n) if code>>a&1]
            if any(not(code>>(a|b)&1) for a in F for b in F):continue
            tested+=1
            assert any(matching_size(F,x)[0]==matching_size(F,x)[1] for x in range(n))
        counts[n]=tested
    return counts

if __name__=='__main__':
    result={'result':'PASS','cycles':check_cycles(),'exhaustive_small_supports':check_small_universes()}
    print(json.dumps(result,indent=2))
