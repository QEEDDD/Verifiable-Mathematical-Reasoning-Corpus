"""Compile and run the independent C++20 checker on an expanded JSON witness.
Usage: python verify_expanded.py algebra/veronese19_3_partition.json
Requires g++; the compact certificates.py checker needs only Python.
"""
from pathlib import Path
import json
import subprocess
import sys
import tempfile

base = Path(__file__).resolve().parent
data = json.loads(Path(sys.argv[1]).read_text())
header = f"{data['n']} {data['d']} {data['minimum_top_size']} {len(data['intervals'])}\n"
payload = header + "\n".join(f"{a} {b}" for a,b in data['intervals']) + "\n"
with tempfile.TemporaryDirectory() as folder:
    binary = str(Path(folder)/'verify')
    subprocess.run(['g++','-O3','-std=c++20',str(base/'verify_full_certificate.cpp'),
                    '-o',binary],check=True)
    subprocess.run([binary],input=payload,text=True,check=True)
