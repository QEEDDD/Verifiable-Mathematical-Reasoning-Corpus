#include <bit>
#include <cstdint>
#include <iostream>
#include <utility>
#include <vector>

// Independent mask-by-mask checker. No orbit logic, solver or third-party code.
int main() {
    unsigned n, d, target, count;
    if (!(std::cin >> n >> d >> target >> count) || n >= 30) return 2;
    const uint32_t limit = 1u << n;
    std::vector<unsigned> singleton(limit, 0);
    std::vector<std::pair<uint32_t,uint32_t>> intervals;
    for (unsigned j = 0; j < count; ++j) {
        uint32_t a,b;
        if (!(std::cin >> a >> b) || a >= limit || b >= limit || (a&b)!=a ||
            std::popcount(a)<d || std::popcount(b)<target) return 3;
        if (a==b) ++singleton[a];
        else intervals.emplace_back(a,b);
    }
    uint64_t checked=0;
    for (uint32_t mask=0;mask<limit;++mask) {
        unsigned actual=singleton[mask];
        for (auto [a,b]:intervals)
            actual += ((mask&a)==a && (mask&b)==mask);
        const bool expected=std::popcount(mask)>=d;
        if (actual!=expected) {
            std::cerr << "FAIL " << mask << " multiplicity " << actual << '\n';
            return 4;
        }
        checked += expected;
    }
    std::cout << "PASS n=" << n << " d=" << d << " target=" << target
              << " all_masks=" << limit << " ideal_sets=" << checked
              << " intervals=" << count << " nontrivial=" << intervals.size() << '\n';
}
