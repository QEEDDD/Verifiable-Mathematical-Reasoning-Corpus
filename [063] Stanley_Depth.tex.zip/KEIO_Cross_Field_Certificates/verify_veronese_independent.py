"""Independent, standard-library-only validation of a Boolean interval certificate.

Unlike the generator, this checks each Boolean mask against all nontrivial
intervals; it uses neither rotation orbits nor an optimization solver.
"""
import argparse
from collections import Counter
import hashlib
import json
from math import comb
from pathlib import Path


def verify(path):
    raw = Path(path).read_bytes()
    data = json.loads(raw)
    n, d, target = data['n'], data['d'], data['minimum_top_size']
    intervals = data['intervals']
    singleton = Counter()
    nontrivial = []
    histogram = Counter()
    for entry in intervals:
        assert len(entry) == 2
        a, b = entry
        assert isinstance(a, int) and isinstance(b, int)
        assert 0 <= a <= b < 2**n and a & b == a
        assert a.bit_count() >= d and b.bit_count() >= target
        histogram[(a.bit_count(), b.bit_count())] += 1
        if a == b:
            singleton[a] += 1
        else:
            nontrivial.append((a, b))
    checked = 0
    for mask in range(2**n):
        multiplicity = singleton[mask]
        for a, b in nontrivial:
            if mask & a == a and mask & b == mask:
                multiplicity += 1
        expected = int(mask.bit_count() >= d)
        assert multiplicity == expected, (mask, multiplicity, expected)
        checked += expected
    upper = d + comb(n, d + 1) // comb(n, d)
    assert target == upper
    return {
        'status': 'PASS', 'n': n, 'd': d, 'stanley_depth': target,
        'checked_subsets_in_ideal': checked, 'checked_all_boolean_masks': 2**n,
        'total_intervals': len(intervals), 'nontrivial_intervals': len(nontrivial),
        'rank_histogram': {f'{a}->{b}':c for (a,b),c in sorted(histogram.items())},
        'upper_count': {'degree_d': comb(n,d), 'degree_d_plus_one': comb(n,d+1)},
        'certificate_sha256': hashlib.sha256(raw).hexdigest(),
    }


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('certificate')
    parser.add_argument('--output')
    args = parser.parse_args()
    report = json.dumps(verify(args.certificate), indent=2) + '\n'
    if args.output:
        Path(args.output).write_text(report)
    print(report, end='')
