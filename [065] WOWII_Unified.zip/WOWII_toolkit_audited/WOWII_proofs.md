# WOWII 증명 모음 (2026-10-26)

**상태 표기**
- **검토 완료**: 코디네이터(Claude)가 직접 쓰고 검토한 증명. 434a, 434b.
- **미검토**: 분야별 서브에이전트가 쓴 증명. 수치 재검증은 통과했지만 증명문 자체는 아직 아무도 검토하지 않았습니다. 결과로 쓰기 전에 반드시 검토해야 합니다.
- 증명은 표에 적힌 해석(reading)에 대해서만 성립합니다. 해석 정의는 툴킷의 `conj.py`에 있습니다.

**수치 재검증** (`verify_proved.py`): 아래 25개 모두 8정점 이하 연결그래프 전부, 14정점 이하 트리 전부, 랜덤 연결그래프 1,500개(10–16정점), 랜덤 트리 1,500개(10–40정점)에서 위반이 없었습니다. 전수 탐색 단계에서는 9정점 이하 연결그래프 전부와 16정점 이하 트리 전부도 통과했습니다.

## 목록

| 추측 | 상태 | 덮는 해석 | 공개 주장 |
|---|---|---|---|
| 434a | 검토 완료 | SW=degeneracy, degeneracy+1 둘 다 | 없음 |
| 434b | 검토 완료 | 모든 해석 | 없음 |
| 96 | 미검토 | `alpha<=1+min_de*(lam_max-1)` | proof (jomplox / Claude Opus 5.5 (umaia1234/agentic-conjectures)) |
| 136 | 미검토 | `path>=(1+girth)/Delta(R)` | 없음 |
| 137 | 미검토 | `path>=4/p(bar)` | 없음 |
| 157 | 미검토 | `Ls>=f1+sqrt(2max|E(R)|)` | 없음 |
| 161 | 미검토 | `Ls>=lam_max(bar)` | 없음 |
| 162 | 미검토 | `Ls>=freq(lam_min)*floor(1/delta)` | 없음 |
| 169 | 미검토 | `Ls>=1+maxde-minde` | 없음 |
| 233 | 미검토 | `gt>=2/3(1+ecc(B))` | 없음 |
| 235 | 미검토 | `gt>=2/3ecc(B)+chibip` | 없음 |
| 241 | 미검토 | `gt>=floor(c(N[D2])+distavgC)` | 없음 |
| 268 | 미검토 | `gt>=floor(1+distavg(C))` | 없음 |
| 290 | 미검토 | `gt<=HHk*Delta` | 없음 |
| 318 | 미검토 | `maxde>=|E(bar)| => wtd` | 없음 |
| 320 | 미검토 | `maxde=Tdistmin => wtd` | proof (txmy/ultra-mathematician (AI agents, run 2026-07-24-002)) |
| 321 | 미검토 | `eccavg>=Tdistmax/3 => wtd` | 없음 |
| 323 | 미검토 | `maxNbar(e)<=1+max(dodd-oddhor) => wtd` | 없음 |
| 324 | 미검토 | `maxNbar(e)<=1+res => wtd` | 없음 |
| 325 | 미검토 | `minNbar(e)<=1+c(N[D2]) => wtd` | 없음 |
| 326 | 미검토 | `3mu<=|E(D2)| => wtd` | 없음 |
| 356 | 미검토 | `gt>=|C|*distavg_from(L)` | 없음 |
| 372 | 미검토 | `gt>=vc/(p-1)` | 없음 |
| 377 | 미검토 | `gt>=iso(M)+upmedian` | 없음 |
| 380 | 미검토 | `gt>=|Deven|/(ecc(C)-1)` | 없음 |
| 421c | 미검토 | `i<=gamma(|N[Mlam]|-3)` | 없음 |
| 432b | 미검토 | `i<=|V-N(P)|+min(de-do)*chibip` | 없음 |

## A. 코디네이터 증명 (검토 완료)

# Central results (written by the coordinator)

Notation: H = complement of G, s = degen(H) = max over subgraphs of the minimum degree (WOWII's SW(H));
SW1 = s + 1 (classical Szekeres-Wilf number). i = independent domination, alpha = independence number,
M = set of maximum-degree vertices of G.

## Lemma* (two non-adjacent simplicial vertices)
Let k >= 1 and let H be a finite graph that is (k-1)-degenerate and in which every maximal clique has exactly
k vertices. If H is not complete, H has two non-adjacent vertices of degree k-1.

Proof. Every vertex lies in a maximal clique of size k, so every degree is >= k-1, and a vertex of degree k-1 has
closed neighbourhood equal to that clique ("simplicial"; it lies in exactly one maximal clique). Take a
counterexample H with the fewest vertices. H is not complete, so it has two non-adjacent vertices, n >= 2.
By degeneracy H has a vertex of degree <= k-1, so the set S of simplicial vertices is non-empty; by assumption its
members are pairwise adjacent, hence all lie in one maximal clique Q* (if s, s' in S are adjacent, s' lies in
N[s] = Q_s and in exactly one maximal clique, so Q_s' = Q_s), and N[s] = Q* for every s in S. V != Q*, otherwise
H = K_k is complete. Put R = Q* \ S.
* R empty: Q* is a connected component. H - Q* is non-empty and (k-1)-degenerate, so it has a vertex x of degree
  <= k-1 there; x has no neighbour in Q*, so deg_H(x) <= k-1, i.e. x in S, but x is outside Q*. Contradiction.
* R non-empty: H - S is non-empty and (k-1)-degenerate, so it has a vertex x with deg_{H-S}(x) <= k-1. If x is
  outside Q*, x has no neighbour in S (neighbours of S lie in Q*), so deg_H(x) <= k-1 and x in S, impossible. Hence
  x in R. As x is not simplicial, deg_H(x) >= k, so Out(x) := N(x) \ Q* is non-empty, and
  deg_{H-S}(x) = |R| - 1 + |Out(x)| <= k-1. Take y in Out(x); the edge xy lies in a maximal clique Q' (|Q'| = k),
  Q' is inside N[x] = Q* ∪ Out(x) and avoids S (no vertex of S is adjacent to y). So Q' is inside R ∪ Out(x), and
  k = |Q'| <= |R| + |Out(x)| <= k forces Q' = R ∪ Out(x). Now H* = H - S is (k-1)-degenerate and every maximal
  clique of H* has exactly k vertices (a maximal clique C of H* lies in a maximal clique D of H; if D != Q* then D
  avoids S and C = D; if every maximal clique of H containing C were Q*, then C would lie in R, which lies in Q',
  a different maximal clique of H containing C — impossible). H* is smaller than H.
  - If H* is complete then H* = K_k = Q', so V = S ∪ Q', and a vertex y of Out(x) = Q' \ R has degree k-1 in H,
    i.e. y in S, but y is outside Q*. Contradiction.
  - Otherwise, by minimality, H* has two non-adjacent vertices a, b of degree k-1 in H*. They are not both in the
    clique R; say a is not in R, so a is outside Q*, has no neighbour in S, and deg_H(a) = k-1: a in S outside Q*.
    Contradiction. ∎

(Checked by CP-SAT: no counterexample for k = 2..5 and n <= 12-16.)

## Reduction used for 434a/434b
For every graph G: i(G) <= alpha(G) = omega(H) <= s + 1. If i(G) = s + 1 =: k, then every maximal independent set of
G (= maximal clique of H) has size exactly k and H is (k-1)-degenerate, so Lemma* applies to H. Since every vertex of
H lies in a k-clique, delta(H) = k-1, so the vertices of H-degree k-1 are exactly M(G), the maximum-degree vertices
of G. Lemma* (H is not complete because G, being connected with n >= 2, has an edge) gives two vertices of M(G)
that are non-adjacent in H, i.e. adjacent in G.
Stronger form: in that case no vertex x of M(G) is adjacent in G to no other vertex of M(G). Otherwise x would be
H-adjacent to all of M(G) \ {x}, so all simplicial vertices of H would lie in N_H[x] = Q_x, pairwise adjacent,
and Lemma* would force H complete.

## 434a  i(G) <= |M| + 2*floor(SW(G^c)/2)      -> PROVED (both SW readings), all graphs
SW = s + 1: RHS >= 1 + 2 floor((s+1)/2) >= s + 1 >= i. SW = s: if s is even or |M| >= 2 the RHS is >= s + 1 >= i.
Remaining case s odd, |M| = 1, i = s + 1: contradicts the reduction (|M| >= 2). ∎

## 434b  i <= delta(G[M]) + 1 + SW(G^c); if diam > 2 then i <= delta(G[M]) + SW(G^c)   -> PROVED, all readings
First clause: i <= s + 1 <= delta(G[M]) + 1 + SW for either SW reading.
Second clause (we prove it without using diam > 2): with SW = s+1 it is i <= s+1 <= delta(G[M]) + s + 1. With SW = s:
if i <= s done; if i = s + 1, the stronger form above says every vertex of M has a G-neighbour in M, i.e.
delta(G[M]) >= 1, so delta(G[M]) + s >= s + 1 = i. Reading delta_G(M) (= Delta) is weaker still. ∎

## 434c  i <= delta(G[V-M]) + 1 + SW(G^c); if delta(G) = 1 then i <= delta(G[V-M]) + SW(G^c)
* Literal reading with the page's definition SW = degeneracy and delta of the induced subgraph: the second clause is
  FALSE on P4 (delta = 1, M = two inner vertices, G[V-M] = two isolated vertices so delta(G[V-M]) = 0, SW(P4^c) =
  SW(P4) = 1, RHS = 1 < i(P4) = 2).
* Every other reading is trivially true: first clause as above; with SW = s+1, RHS >= s+1 >= i; with
  delta_G(V-M) (minimum G-degree over V-M) >= delta(G) = 1, RHS >= 1 + s >= i.

## 378  gamma_t(T) >= c(<M>) + dist_avg(D_2(T))   (trees)   -> REFUTED under both readings of dist_avg
* Page-linked definition "average distance FROM a set" (average over v outside D_2 of dist(v, D_2)): the 5-vertex
  spider with centre of degree 3 (legs 1,1,2), g6 'DBc': gamma_t = 2, M = {centre}, c(<M>) = 1, D_2 = {the middle
  vertex of the long leg}, average distance from D_2 = (1+2+2+1)/4 = 3/2, RHS = 5/2 > 2.
* "average distance BETWEEN vertices of D_2": the 9-vertex tree g6 'H??KF@W' (edges 0-6,0-7,1-7,1-8,2-7,3-8,4-5,4-8;
  two non-adjacent degree-3 vertices 7, 8; D_2 = {0,1,4} with pairwise distances 2,4,2): gamma_t = 4 (brute force),
  c(<M>) = 2, RHS = 2 + 8/3 = 14/3 > 4.


## B. 서브에이전트 증명 (미검토)

### 96

**진술 (WOWII 원문):** If G is a simple connected graph, then α(G) ≤ 1 + minimum dist_even(v) *( maximum of λ(v) -1 )

**덮는 해석:** `alpha<=1+min_de*(lam_max-1)`  
**에이전트 자체 확신도:** high

Claim: for connected G with n>=2, alpha(G) <= 1 + dist_even(v)*(lam_max-1) for EVERY vertex v (in particular for the minimiser).
If lam_max = 1, every neighbourhood is a clique; in a connected graph this forces G complete (u~v~w implies u~w, propagate along paths), so alpha=1 <= 1. Assume lam_max >= 2. Fix v and let L_i = {w : d(v,w)=i}; E = union of even layers, |E| = dist_even(v) (v itself counted). Let I be a maximum independent set. For each w in I lying in an odd layer L_{2j+1} choose a neighbour par(w) in L_{2j} (exists since d(v,w)=2j+1). For u in E put C(u) = {w in I : par(w)=u}. Then I is the disjoint union of (I cap E) and the sets C(u), u in E, so alpha = sum_{u in E} ( [u in I] + |C(u)| ). If u in I then C(u) is empty (its elements are neighbours of u), so each summand is <= max(1, |C(u)|). For u = v: C(v) is an independent subset of N(v), so |C(v)| <= lam(v) <= lam_max. For u in L_{2j}, j>=1: pick q in N(u) cap L_{2j-1}. C(u) is contained in L_{2j+1}; there are no edges between layers L_{2j-1} and L_{2j+1}; hence C(u) u {q} is an independent subset of N(u), so |C(u)| <= lam(u)-1 <= lam_max-1. Therefore alpha <= max(1,lam_max) + (|E|-1)*max(1,lam_max-1) = lam_max + (|E|-1)(lam_max-1) = 1 + |E|(lam_max-1). QED
Degenerate case: for K1 the right side is 1+1*(0-1)=0 < 1 = alpha, so n>=2 is needed (the database presumably starts at n=2).

*비고:* Re-tested on 300 random graphs/trees 10<=n<=18: no violation. Coordinator reports a public proof exists as well.

### 136

**진술 (WOWII 원문):** If G is a simple connected graph, then path(G) >= (1+girth)/Delta(R)

**덮는 해석:** `path>=(1+girth)/Delta(R)`  
**에이전트 자체 확신도:** high

Setting: G connected, n>1, with a cycle; g = girth, r = rad(G), R = union over centers c of R(c) = {v : d(c,v)=r}, Delta(R) = max_G-degree over R (R is nonempty). path(G) = max order of an induced path. Claim: path(G) >= (1+g)/Delta(R).

Lemma 1 (Erdos-Saks-Sos 1986, proof due to F. Chung): path(G) >= 2r-1 for every connected G.
Proof (induction on n; r=1 trivial). Let r>=2. If some connected proper induced subgraph H has rad(H) >= r, apply induction to H. Otherwise take a non-cut vertex u0 (leaf of a spanning tree); rad(G-u0) <= r-1; let v0 be a center of G-u0. Then d_G(v0,u) <= r-1 for all u != u0, and since ecc_G(v0) >= r, d(v0,u0) = r. Let v0 v1 ... vr = u0 be a geodesic. Pick w with d(v2,w) >= r; w != u0 (d(v2,u0)=r-2), so s := d(v0,w) <= r-1, and s >= r-2. Let v0=x0,x1,...,xs=w be a geodesic. (i) x_i != v_j for i,j>=1 (else i=j and d(v2,w) <= s-2 or <= s, both < r). (ii) no edge x_i v_j with i>=1, j>=2 (it forces |i-j|<=1 and d(v2,w) <= (j-2)+1+(s-i) <= s < r). (iii) an edge x_i v1 forces i<=2; i=2 gives d(v2,w) <= s < r; i=1 is possible only if s=r-1. Hence vr,...,v1,v0,x1,...,xs is a path whose only possible chord is v1x1 (only when s=r-1): either it is induced with r+1+s >= 2r-1 vertices, or vr..v1 x1..xs is induced with 2r-1 vertices. QED

Lemma 2: a shortest cycle C is induced; if g>=5, every vertex outside C has at most one neighbour on C (two neighbours at C-distance t <= floor(g/2) would give a cycle of length t+2 < g).

Case 1: Delta(R) >= 2. C minus one vertex is an induced path on g-1 vertices and g-1 >= (g+1)/2 >= (g+1)/Delta(R) as g>=3.

Case 2: Delta(R) = 1, i.e. every vertex at distance r from a center is a leaf. We show path(G) >= g+1.
2.0 r>=2: if r=1 a center is adjacent to all vertices and all others are leaves, so G is a star (acyclic).
2.1 g <= 2r-1: let c be a center, G' = G minus all leaves; G' is connected, contains every cycle, and distances between vertices of G' are the same in G and G' (interior vertices of geodesics have degree >= 2). All vertices at distance r from c are leaves, so G' lies within distance r-1 of c. Take a BFS tree T of G' from c and an edge xy of G' not in T: the T-paths c->x, c->y and xy contain a cycle of length <= 2(r-1)+1.
2.2 If g <= 2r-2, Lemma 1 gives path >= 2r-1 >= g+1. So assume g = 2r-1 (odd).
2.3 g=3 (r=2): if G had no induced P4 then by Seinsche's theorem Gbar is disconnected, V = A u B with A complete to B; a leaf l exists (R is nonempty); l in A forces B={b} and b adjacent to every other vertex, so r=1, contradicting 2.0. Hence path >= 4 = g+1.
2.4 g >= 5. Let C = (u_0,...,u_{g-1}) be a shortest cycle.
 (a) If some vertex is at distance >= 2 from C, choose a2 at distance exactly 2 and a neighbour a1 of a2 at distance 1; a1 has a unique C-neighbour, say u_0 (Lemma 2). Then a2,a1,u_0,u_{g-1},...,u_2 is an induced path on g+1 vertices.
 (b) Otherwise V = N[C].
 (b1) If no two vertices outside C are adjacent, every vertex outside C is a leaf attached to C, so G = C plus leaves at a set S of cycle vertices. For u on C, ecc(u) = max(floor(g/2), 1+max_{v in S} d_C(u,v)); since ecc(u) >= r = floor(g/2)+1, S contains one of the two (adjacent) vertices at C-distance floor(g/2) from u; as u varies these pairs are all edges of C, so S is a vertex cover of the odd cycle C, hence contains adjacent u_i,u_{i+1}. If no two S-vertices were at C-distance 2 then u_{i+2} notin S, so u_{i+3} in S (cover edge u_{i+2}u_{i+3}), but d_C(u_{i+1},u_{i+3}) = 2. So u_j,u_{j+2} in S, and leaf-u_j-u_{j-1}-...-u_{j+3}-u_{j+2}-leaf (C minus u_{j+1}, plus two leaves) is an induced path on g+1 vertices.
 (b2) Otherwise two adjacent vertices a,a' outside C have C-neighbours u,v; u!=v (triangle), u not~ v (C4), and the cycle a-u-(C-arc of length t)-v-a' has length t+3 >= g with t <= floor(g/2), forcing g=5, t=2, r=3. Say u=u_0, v=u_2; C1 = (a,u_0,u_1,u_2,a') is also a shortest cycle, so by (a) we may assume V = N[C1] too. Every vertex of C u C1 is within distance 2 of u_1 (both are 5-cycles through u_1) and every other vertex has a neighbour on C, so ecc(u_1) <= 3 = r: u_1 is a center, and the vertices w at distance 3 from u_1 (they exist) are in R, hence leaves. But such a w lies outside C u C1 and has a neighbour on C and a neighbour on C1; being a leaf, that neighbour is in C cap C1 = {u_0,u_1,u_2}, giving d(u_1,w) <= 2, a contradiction. So (b2) is impossible.
Therefore path(G) >= g+1 = (1+g)/Delta(R) in Case 2. QED

Tightness: coronas C_g o K_1 (path = g+1, Delta(R)=1).

*비고:* Uses only the Erdos-Saks-Sos induced path theorem (proof included) and Seinsche's theorem. Re-tested with the library on 400 random graphs 10<=n<=18, on 352 random graphs with Delta(R)=1, and on 3772 generated 'rigid' graphs with Delta(R)=1 and g=2rad-1 (the critical case): no violation; min slack 0 (coronas).

### 137

**진술 (WOWII 원문):** If G is a simple connected graph, then path(G) >= 4/p(bar G)

**덮는 해석:** `path>=4/p(bar)`  
**에이전트 자체 확신도:** high

Claim: for every connected G with n>=2, path(G) >= 4/p(Gbar), where p is the path covering number.
Since n>=2 and G is connected, G has an edge, so path(G) >= 2.
(a) If p(Gbar) >= 2 then 4/p(Gbar) <= 2 <= path(G).
(b) If p(Gbar) = 1 then Gbar has a Hamiltonian path, hence Gbar is connected. Seinsche's theorem (1974): every P4-free graph on at least two vertices is disconnected or has a disconnected complement. G and Gbar are both connected and n>=2, so G is not P4-free: G contains an induced P4, i.e. path(G) >= 4 = 4/p(Gbar).
Boundary: n=2 (G=K2, Gbar=2K1, p=2, 4/2=2=path). Tight for G=P4 (Gbar=P4, p=1, path=4). QED

*비고:* Re-tested on 300 random connected graphs/trees with 10<=n<=18 with the library: no violation. Uses only Seinsche's theorem.

### 157

**진술 (WOWII 원문):** If G is a simple connected graph, then L_s(G) ≥ (f_1(G) + SQRT[2* maximum {|E(R(v))|: v is a center of G ]

**덮는 해석:** `Ls>=f1+sqrt(2max|E(R)|)`  
**에이전트 자체 확신도:** high

Let r = rad(G) and let v be a centre with e := |E(R(v))| maximum. n = 2: G = K2, Ls = 2 = f1, R(v) is one vertex, e = 0, RHS = 2. Let n >= 3 and let T be a BFS tree rooted at v (every u != v is joined to one neighbour at distance d(v,u)-1). Since ecc(v) = r, no vertex of R(v) (distance exactly r) has a child, so every vertex of R(v) is a leaf of T. Every pendant vertex of G is a leaf of every spanning tree. Let P = set of pendant vertices (|P| = f1) and R' = R(v) \ P. If x in R(v) is pendant, its only neighbour lies on a shortest v-x path, i.e. at distance r-1, so x has no neighbour in R(v); hence E(R(v)) = E(R'). With s = |R'| we get e <= s(s-1)/2 < s^2/2 when s >= 1, and e = 0 when s = 0; so s >= sqrt(2e). P and R' are disjoint sets of leaves of T, so Ls >= |P| + |R'| >= f1 + sqrt(2e). QED

*비고:* Re-tested on 34k random graphs/trees n=10..20 (no failure, ~1/3 tight).

### 161

**진술 (WOWII 원문):** If G is a simple connected graph, then L_s(G) ≥ maximum of λ(v) of bar(G).

**덮는 해석:** `Ls>=lam_max(bar)`  
**에이전트 자체 확신도:** high

In the complement, N_bar(v) = V \ N_G[v] and an independent set of bar(G) is a clique of G, so lambda_bar(v) = omega(G[V \ N[v]]). Let q = max_v lambda_bar(v), attained at v with a clique K of G, |K| = q, K inside V \ N[v]. If q = 0 there is nothing to prove (Ls >= 0). If n = 2 then bar(G) has no edges and q = 0. Let n >= 3, q >= 1. K != V (v is not in K) and G is connected, so some y in K has a neighbour outside K; y is adjacent to the other q-1 vertices of K, so deg(y) >= q and Delta >= q. Finally Ls >= Delta for n >= 3: extend the star at a maximum-degree vertex to a spanning tree (possible since G is connected); a tree with a vertex of degree Delta has at least Delta leaves. Hence Ls >= Delta >= q. QED

*비고:* Equality e.g. on 'Ck'-type small graphs; re-tested numerically.

### 162

**진술 (WOWII 원문):** If G is a simple connected graph, then L_s(G) ≥ freq of minimum of λ(v)*FLOOR[1 / δ(G)].

**덮는 해석:** `Ls>=freq(lam_min)*floor(1/delta)`  
**에이전트 자체 확신도:** high

If delta >= 2 then floor(1/delta) = 0 and the claim is Ls >= 0. Let delta = 1. Every vertex has a neighbour, so lambda(v) >= 1, and a pendant vertex has lambda = 1; hence lambda_min = 1 and freq(lambda_min) = |S| where S = {v : N(v) is a (non-empty) clique} (simplicial vertices). If G is complete, delta = 1 forces G = K2 and Ls = 2 = |S|. Assume G is not complete. (b) Every s in S has a neighbour outside S: otherwise put Q = N[s] (a clique). For t in N(s) (so t in S) the facts 's in N(t), N(t) a clique' and 't in N(s), N(s) a clique' give N[t] = N[s] = Q; so no vertex of Q has a neighbour outside Q, Q is a component, Q = V and G is complete - contradiction. In particular V \ S is non-empty. (a) G - S is connected: for a, b outside S take an a-b path with the fewest vertices of S; an interior vertex p_i in S has p_{i-1}, p_{i+1} in the clique N(p_i), so they are adjacent and p_i can be skipped - contradiction. Take a spanning tree of G - S and attach every s in S by one edge to a neighbour outside S (exists by (b)). This is a spanning tree of G in which every vertex of S is a leaf, so Ls >= |S| = freq(lambda_min)*floor(1/delta). QED

*비고:* Tight on many trees/graphs (e.g. all trees: S = leaves).

### 169

**진술 (WOWII 원문):** If G is a simple connected graph, then L_s(G) ≥ 1 + maximum of dist_even(v) - minimum of dist_even(v).

**덮는 해석:** `Ls>=1+maxde-minde`  
**에이전트 자체 확신도:** high

Fact: if T is a tree on n >= 2 vertices with bipartition (A,B), then T has at least |A|-|B|+1 leaves in A. (Every edge has exactly one end in A, so sum_{a in A} deg_T(a) = n-1 = |A|+|B|-1, i.e. sum_{a in A}(deg_T(a)-1) = |B|-1; each non-leaf of A contributes >= 1.) For a vertex v let E_v / O_v be the sets of vertices at even / odd distance from v; |E_v| = de(v). A BFS tree T_v rooted at v preserves distances from v, so its bipartition is (E_v, O_v). Let u maximise and w minimise de. n = 2: Ls = 2 > 1 = RHS. Let n >= 3. If de(u)+de(w) >= n: T_u has >= |E_u|-|O_u|+1 = 2de(u)-n+1 >= de(u)-de(w)+1 leaves. If de(u)+de(w) < n: T_w has >= |O_w|-|E_w|+1 = n-2de(w)+1 > de(u)-de(w)+1 leaves (in O_w). Either way Ls >= 1 + max de - min de. QED (the two bounds average exactly to the RHS).

*비고:* For bipartite G this is Ls >= 1+||X|-|Y||. Re-tested numerically.

### 233

**진술 (WOWII 원문):** If G is a simple connected graph, then γ_t(G) ≥ (2/3) * ( 1+ecc(B) )

**덮는 해석:** `gt>=2/3(1+ecc(B))`  
**에이전트 자체 확신도:** high

**Common lemmas (used below).** G connected, n >= 2, gamma_t = gamma_t(G).

*Lemma 1 (spanning tree).* If S is a TDS of G, there is a spanning tree T of G such that S is a TDS of T.
Proof: G[S] has no isolated vertex; take a spanning forest F of G[S] (every s in S keeps an F-neighbour). For each v not in S add one edge v s(v), s(v) in N(v) ∩ S; this keeps a forest (each new edge hangs a new leaf). Extend to a spanning tree T of G. Every vertex has a T-neighbour in S.

*Lemma 2 (tripod lemma).* Let T be a tree, S a TDS of T, K_1..K_m the components of T[S] (each |K_i| >= 2, so m <= |S|/2), and Y a subtree of T with at most 3 leaves. Then |V(Y)| <= |S| + 2m + 1 <= 2|S| + 1, and |V(Y)| <= |S| + 2m <= 2|S| if Y is a path.
Proof: Y ⊆ ∪ N(K_i), so |Y| <= Σ_i |N(K_i) ∩ Y|. (a) If K_i ∩ Y = ∅, K_i lies in one component W of T−V(Y), which is joined to Y by exactly one edge, so |N(K_i) ∩ Y| <= 1. (b) Otherwise Q_i = K_i ∩ Y is a subtree (intersection of subtrees). If y ∈ Y is adjacent to k ∈ K_i \ Y, then k is the attachment vertex of its component W of T−Y and y the attachment point; K_i is connected and meets Y, so its path from k to Q_i leaves W through y, i.e. y ∈ Q_i. Hence N(K_i) ∩ Y ⊆ N_Y[Q_i], of size |Q_i| + β_i where β_i = number of components of Y − Q_i (each is joined to Q_i by one edge). Each such component contains a leaf of Y, so β_i <= 3 (<= 2 if Y is a path), and Σ_{q∈Q_i}(deg_Y q − 2) = β_i − 2 shows β_i = 3 forces Q_i to contain the unique degree-3 vertex of Y; as the Q_i are disjoint this happens for at most one i. Summing, |Y| <= Σ(|K_i| + 2) + 1.

*Corollary 3.* For all x,y,z: 4 gamma_t >= d(x,y)+d(y,z)+d(z,x); and 2 gamma_t >= diam+1.
Proof: S a minimum TDS, T as in Lemma 1. The union Y of the T-paths between x,y,z is a subtree with <= 3 leaves and |E(Y)| = (d_T(x,y)+d_T(y,z)+d_T(z,x))/2 >= (d(x,y)+d(y,z)+d(z,x))/2 since d_T >= d_G. Lemma 2: |E(Y)| = |V(Y)|−1 <= 2 gamma_t. For a diametral pair, Y = T-path: diam+1 <= |V(Y)| <= 2 gamma_t.

*Lemma 4 (radius).* rad <= gamma_t; moreover if rad = gamma_t then G has two ADJACENT central vertices (and gamma_t is even).
Proof: S minimum TDS with components K_1..K_m, m <= floor(gamma_t/2). Auxiliary graph H on {1..m}, i~j iff dist(K_i,K_j) <= 3; H is connected (otherwise the vertex sets dominated by the two sides are disjoint, cover V, and an edge of G between them gives dist <= 3). Adding the <= 2 interior vertices of a shortest K_i–K_j path for each edge of a spanning tree of H gives a connected dominating set D with |D| <= gamma_t + 2(m−1) <= 2gamma_t − 2 (<= 2gamma_t − 3 if gamma_t is odd). Let T_D be a spanning tree of G[D], δ its diameter (<= |D|−1), c a central vertex of T_D: ecc_G(c) <= ceil(δ/2) + 1 <= gamma_t (every vertex is in D or adjacent to D). If rad = gamma_t then ceil(δ/2) = gamma_t − 1 with δ <= 2gamma_t − 3, so δ = 2gamma_t − 3 is odd (and gamma_t is even), T_D has two adjacent central vertices c1,c2 with ecc_{T_D} = gamma_t − 1, hence ecc_G(c_i) <= gamma_t = rad: both are centres of G.


**Theorem.** For connected G with n >= 2, gamma_t >= (2/3)(1 + ecc(B)), ecc(B) = max_{v not in B} dist(v,B) (0 if B = V).

Let e = ecc(B), d = diam. If B = V then e = 0 and the bound is 2/3 < 2 <= gamma_t. Otherwise take v not in B with dist(v,B) = e >= 1.
(i) e <= d − 1: if dist(v,B) >= d, every peripheral vertex is at distance d from v, so ecc(v) = d and v ∈ B, contradiction.
(ii) Let b,b' be a diametral pair (both lie in B). Then d(v,b) >= e, d(v,b') >= e, d(b,b') = d >= e+1, so by Corollary 3, 4 gamma_t >= 2e + d >= 3e + 1.
For e >= 5: (3e+1)/4 >= 2(e+1)/3 ⟺ e >= 5. For e = 1,2,3,4 integrality gives gamma_t >= max(2, ceil((3e+1)/4)) = 2,2,3,4, while ceil(2(e+1)/3) = 2,2,3,4. ∎

*비고:* Tight e.g. for paths. Uses only the tripod corollary 4*gt >= perimeter of any vertex triple.

### 235

**진술 (WOWII 원문):** If G is a simple connected graph, then γ_t(G) ≥ (2/3) ecc(B) + χ_bipartite(G).

**덮는 해석:** `gt>=2/3ecc(B)+chibip`  
**에이전트 자체 확신도:** high

**Common lemmas (used below).** G connected, n >= 2, gamma_t = gamma_t(G).

*Lemma 1 (spanning tree).* If S is a TDS of G, there is a spanning tree T of G such that S is a TDS of T.
Proof: G[S] has no isolated vertex; take a spanning forest F of G[S] (every s in S keeps an F-neighbour). For each v not in S add one edge v s(v), s(v) in N(v) ∩ S; this keeps a forest (each new edge hangs a new leaf). Extend to a spanning tree T of G. Every vertex has a T-neighbour in S.

*Lemma 2 (tripod lemma).* Let T be a tree, S a TDS of T, K_1..K_m the components of T[S] (each |K_i| >= 2, so m <= |S|/2), and Y a subtree of T with at most 3 leaves. Then |V(Y)| <= |S| + 2m + 1 <= 2|S| + 1, and |V(Y)| <= |S| + 2m <= 2|S| if Y is a path.
Proof: Y ⊆ ∪ N(K_i), so |Y| <= Σ_i |N(K_i) ∩ Y|. (a) If K_i ∩ Y = ∅, K_i lies in one component W of T−V(Y), which is joined to Y by exactly one edge, so |N(K_i) ∩ Y| <= 1. (b) Otherwise Q_i = K_i ∩ Y is a subtree (intersection of subtrees). If y ∈ Y is adjacent to k ∈ K_i \ Y, then k is the attachment vertex of its component W of T−Y and y the attachment point; K_i is connected and meets Y, so its path from k to Q_i leaves W through y, i.e. y ∈ Q_i. Hence N(K_i) ∩ Y ⊆ N_Y[Q_i], of size |Q_i| + β_i where β_i = number of components of Y − Q_i (each is joined to Q_i by one edge). Each such component contains a leaf of Y, so β_i <= 3 (<= 2 if Y is a path), and Σ_{q∈Q_i}(deg_Y q − 2) = β_i − 2 shows β_i = 3 forces Q_i to contain the unique degree-3 vertex of Y; as the Q_i are disjoint this happens for at most one i. Summing, |Y| <= Σ(|K_i| + 2) + 1.

*Corollary 3.* For all x,y,z: 4 gamma_t >= d(x,y)+d(y,z)+d(z,x); and 2 gamma_t >= diam+1.
Proof: S a minimum TDS, T as in Lemma 1. The union Y of the T-paths between x,y,z is a subtree with <= 3 leaves and |E(Y)| = (d_T(x,y)+d_T(y,z)+d_T(z,x))/2 >= (d(x,y)+d(y,z)+d(z,x))/2 since d_T >= d_G. Lemma 2: |E(Y)| = |V(Y)|−1 <= 2 gamma_t. For a diametral pair, Y = T-path: diam+1 <= |V(Y)| <= 2 gamma_t.

*Lemma 4 (radius).* rad <= gamma_t; moreover if rad = gamma_t then G has two ADJACENT central vertices (and gamma_t is even).
Proof: S minimum TDS with components K_1..K_m, m <= floor(gamma_t/2). Auxiliary graph H on {1..m}, i~j iff dist(K_i,K_j) <= 3; H is connected (otherwise the vertex sets dominated by the two sides are disjoint, cover V, and an edge of G between them gives dist <= 3). Adding the <= 2 interior vertices of a shortest K_i–K_j path for each edge of a spanning tree of H gives a connected dominating set D with |D| <= gamma_t + 2(m−1) <= 2gamma_t − 2 (<= 2gamma_t − 3 if gamma_t is odd). Let T_D be a spanning tree of G[D], δ its diameter (<= |D|−1), c a central vertex of T_D: ecc_G(c) <= ceil(δ/2) + 1 <= gamma_t (every vertex is in D or adjacent to D). If rad = gamma_t then ceil(δ/2) = gamma_t − 1 with δ <= 2gamma_t − 3, so δ = 2gamma_t − 3 is odd (and gamma_t is even), T_D has two adjacent central vertices c1,c2 with ecc_{T_D} = gamma_t − 1, hence ecc_G(c_i) <= gamma_t = rad: both are centres of G.


**Theorem.** gamma_t >= (2/3) ecc(B) + χ_bip(G) for connected G, n >= 2.

Notation as in 233 (e = ecc(B), v with dist(v,B) = e, diametral pair b,b' ∈ B, d >= e+1, p := d(v,b)+d(v,b')+d(b,b') >= 2e+d >= 3e+1, 4gamma_t >= p).
*Non-bipartite:* RHS = 2e/3 < 2(1+e)/3 <= gamma_t by 233.
*Bipartite:* need gamma_t >= 2e/3 + 1. Here p is even (d(x,y) ≡ c(x)+c(y) mod 2 for a 2-colouring c).
- e = 0: need 1. e = 1: need 5/3; gamma_t >= 2.
- e = 2: need 3. Suppose gamma_t = 2, S = {s1,s2}, s1~s2, V = N(s1) ∪ N(s2). Bipartite ⇒ N(s1) ∩ N(s2) = ∅, X := N(s2) ∋ s1 and Y := N(s1) ∋ s2 are the two colour classes, s1 is adjacent to all of Y, s2 to all of X; same-class vertices are at distance 2, x∈X,y∈Y at distance 1 or 3. If d <= 2 then (d = 2) a non-peripheral v has ecc 1 and dist(v,B) <= 1, or (d=1) B = V; so d = 3. Let v ∉ B, dist(v,B) = 2, say v ∈ X: ecc(v) <= 2 forces v ~ all of Y, and dist(v,B) = 2 forces B ∩ Y = ∅. But some x ∈ B ∩ X has ecc 3, i.e. some y ∈ Y at distance 3, and then y ∈ B ∩ Y. Contradiction; so gamma_t >= 3.
- e = 3: p >= 10 ⇒ gamma_t >= 3 = ceil(3). e = 4: p >= 14 ⇒ gamma_t >= 4 >= 11/3.
- e = 5: need 5. p >= 16; if d >= 7 or d(v,b)+d(v,b') >= 11 then p >= 18 and gamma_t >= 5. Remaining case d = 6, d(v,b) = d(v,b') = 5, and suppose gamma_t = 4: take S minimum, T from Lemma 1; the T-tripod Y on v,b,b' has |E(Y)| >= 8 and <= 2|S| = 8, so T-distances equal G-distances and Y is a spider with centre w and legs of lengths 2 (to v), 3, 3; |V(Y)| = 9 = 2|S|+1. In Lemma 2's count: a single component of size 4 covers <= 7 < 9; with two components of size 2 one missing Y covers <= 1, total <= 6; so both meet Y and 9 <= (2+3)+(2+2) forces K_1 = {w,w'} ⊆ Y (w' first vertex of a leg λ), K_2 = Q_2 an edge of Y avoiding w, and N_Y[K_1], N_Y[K_2] partition V(Y). N_Y[K_1] = {w, its 3 neighbours, 2nd vertex of λ}; the 4 remaining vertices include vertices of BOTH legs ≠ λ (each has length >= 2), but N_Y[K_2] ⊆ (one leg) ∪ {w}. Contradiction, so gamma_t >= 5.
- e = 6: p >= 20 ⇒ 5 >= 5. e = 7: p >= 22 ⇒ 6 >= 17/3. e = 8: p >= 26 ⇒ 7 >= 19/3.
- e >= 9: (3e+1)/4 >= (2e+3)/3 ⟺ e >= 9. ∎

*비고:* Proof via the tripod lemma plus parity and two small equality cases (e=2, e=5).

### 241

**진술 (WOWII 원문):** If G is a tree, then γ_t(G) ≥ FLOOR[number of components(<N[S]>) + dist_avg(C)], where <N[S]> is the subgraph induced by the closed neighborhood of the set of vertices of degree two and C is the set of center vertices.

**덮는 해석:** `gt>=floor(c(N[D2])+distavgC)`  
**에이전트 자체 확신도:** high

Let q = number of components of <N[D2]>. In a tree |C| <= 2 and two centres are adjacent, so dist_avg(C) is 1 (|C|=2) or 0/undefined (|C|=1, code uses 0); in all cases it lies in [0,1], so it suffices to show gamma_t >= q+1 when D2 is nonempty (if D2 is empty the RHS is <= 1 < 2 <= gamma_t).
Let D be a minimum TDS and Q_1..Q_q the components. Each Q_i contains a D-vertex: take y in Q_i of degree 2; its D-neighbour z lies in N(y), a subset of N[D2], and is adjacent to y, hence z is in Q_i. Suppose |D| = q. Then every Q_i contains exactly one D-vertex d_i and D is contained in the union of the Q_i. Now d_1 needs a D-neighbour d_j with j != 1; but d_j lies in N[D2] and is adjacent to d_1 in Q_1, so d_j is in Q_1, contradicting that d_1 is the only D-vertex of Q_1. Hence gamma_t >= q+1 >= floor(q + dist_avg(C)). QED
(Holds for any convention giving dist_avg(C) in [0,1] for one-centre trees.)

*비고:* Re-tested on 1500 random trees (n=10..22): no violation. Tight e.g. for P4 (q=1, two centres).

### 268

**진술 (WOWII 원문):** If G is a simple connected graph, then γ_t(G) ≥ FLOOR[1+dist_avg(C)], where C is the set of center vertices.

**덮는 해석:** `gt>=floor(1+distavg(C))`  
**에이전트 자체 확신도:** high

**Common lemmas (used below).** G connected, n >= 2, gamma_t = gamma_t(G).

*Lemma 1 (spanning tree).* If S is a TDS of G, there is a spanning tree T of G such that S is a TDS of T.
Proof: G[S] has no isolated vertex; take a spanning forest F of G[S] (every s in S keeps an F-neighbour). For each v not in S add one edge v s(v), s(v) in N(v) ∩ S; this keeps a forest (each new edge hangs a new leaf). Extend to a spanning tree T of G. Every vertex has a T-neighbour in S.

*Lemma 2 (tripod lemma).* Let T be a tree, S a TDS of T, K_1..K_m the components of T[S] (each |K_i| >= 2, so m <= |S|/2), and Y a subtree of T with at most 3 leaves. Then |V(Y)| <= |S| + 2m + 1 <= 2|S| + 1, and |V(Y)| <= |S| + 2m <= 2|S| if Y is a path.
Proof: Y ⊆ ∪ N(K_i), so |Y| <= Σ_i |N(K_i) ∩ Y|. (a) If K_i ∩ Y = ∅, K_i lies in one component W of T−V(Y), which is joined to Y by exactly one edge, so |N(K_i) ∩ Y| <= 1. (b) Otherwise Q_i = K_i ∩ Y is a subtree (intersection of subtrees). If y ∈ Y is adjacent to k ∈ K_i \ Y, then k is the attachment vertex of its component W of T−Y and y the attachment point; K_i is connected and meets Y, so its path from k to Q_i leaves W through y, i.e. y ∈ Q_i. Hence N(K_i) ∩ Y ⊆ N_Y[Q_i], of size |Q_i| + β_i where β_i = number of components of Y − Q_i (each is joined to Q_i by one edge). Each such component contains a leaf of Y, so β_i <= 3 (<= 2 if Y is a path), and Σ_{q∈Q_i}(deg_Y q − 2) = β_i − 2 shows β_i = 3 forces Q_i to contain the unique degree-3 vertex of Y; as the Q_i are disjoint this happens for at most one i. Summing, |Y| <= Σ(|K_i| + 2) + 1.

*Corollary 3.* For all x,y,z: 4 gamma_t >= d(x,y)+d(y,z)+d(z,x); and 2 gamma_t >= diam+1.
Proof: S a minimum TDS, T as in Lemma 1. The union Y of the T-paths between x,y,z is a subtree with <= 3 leaves and |E(Y)| = (d_T(x,y)+d_T(y,z)+d_T(z,x))/2 >= (d(x,y)+d(y,z)+d(z,x))/2 since d_T >= d_G. Lemma 2: |E(Y)| = |V(Y)|−1 <= 2 gamma_t. For a diametral pair, Y = T-path: diam+1 <= |V(Y)| <= 2 gamma_t.

*Lemma 4 (radius).* rad <= gamma_t; moreover if rad = gamma_t then G has two ADJACENT central vertices (and gamma_t is even).
Proof: S minimum TDS with components K_1..K_m, m <= floor(gamma_t/2). Auxiliary graph H on {1..m}, i~j iff dist(K_i,K_j) <= 3; H is connected (otherwise the vertex sets dominated by the two sides are disjoint, cover V, and an edge of G between them gives dist <= 3). Adding the <= 2 interior vertices of a shortest K_i–K_j path for each edge of a spanning tree of H gives a connected dominating set D with |D| <= gamma_t + 2(m−1) <= 2gamma_t − 2 (<= 2gamma_t − 3 if gamma_t is odd). Let T_D be a spanning tree of G[D], δ its diameter (<= |D|−1), c a central vertex of T_D: ecc_G(c) <= ceil(δ/2) + 1 <= gamma_t (every vertex is in D or adjacent to D). If rad = gamma_t then ceil(δ/2) = gamma_t − 1 with δ <= 2gamma_t − 3, so δ = 2gamma_t − 3 is odd (and gamma_t is even), T_D has two adjacent central vertices c1,c2 with ecc_{T_D} = gamma_t − 1, hence ecc_G(c_i) <= gamma_t = rad: both are centres of G.


**Theorem.** For connected G with n >= 2, gamma_t >= floor(1 + dist_avg(C)), dist_avg(C) = average of d(u,v) over distinct centres u,v (taken as 0 when |C| = 1, as in the library; then RHS = 1).

Let r = rad. Every two centres are at distance <= r (a centre has eccentricity r), so dist_avg(C) <= r.
- r = 1: centres are dominating vertices, pairwise adjacent, avg = 1, RHS = 2 <= gamma_t.
- r >= 2 and some two centres at distance < r: avg < r, so floor(1+avg) <= r <= gamma_t by Lemma 4.
- r >= 2 and all centre pairs at distance exactly r: no two centres are adjacent, so by Lemma 4 gamma_t ≠ r, hence gamma_t >= r+1 = floor(1+avg). ∎

*비고:* Lemma 4: rad <= gamma_t, with equality only if two centres are adjacent.

### 290

**진술 (WOWII 원문):** If G is a simple connected graph such that n(G)> 2, then γ_t(G) ≤ k *Δ(G), where k is the first step in which a zero appears in the Havil-Hakimi process.

**덮는 해석:** `gt<=HHk*Delta`  
**에이전트 자체 확신도:** high

**Theorem.** For connected G with n >= 3, gamma_t <= k·Δ where k = HH_k (number of Havel–Hakimi steps until a 0 appears).

Let q = number of vertices of degree >= 2. *Fact:* if q >= 2, the set Q of non-leaves is a TDS (n >= 3 ⇒ every leaf's neighbour is in Q; G[Q] is connected, being G minus leaves, with >= 2 vertices). If q = 1, G = K_{1,n−1} and gamma_t = 2 <= Δ <= kΔ. So it suffices to show q <= kΔ.
Run HH on the sorted sequence. At step j let d_j be the current maximum, N_j the number of entries >= 2 at the start of step j (N_1 = q), t_j the number of decremented entries equal to 2. For j < k no zero appears, i.e. all d_j decremented entries are >= 2 (d_j <= N_j − 1) and N_{j+1} = N_j − 1 − t_j. At step k a decremented entry equals 1, so N_k <= d_k (if d_k = 1 all entries are 1 and N_k = 0). Hence q = N_k + Σ_{j<k}(1 + t_j). The maxima are nonincreasing; let p = number of steps with d_j >= 3 (steps 1..p).
(a) For j < p: 1 + t_j <= d_j <= Δ. Indeed if t_j >= 1, some decremented entry was 2, so (sorting) every non-decremented entry is <= 2, and d_{j+1} >= 3 must be a decremented entry that was >= 4; thus t_j <= d_j − 1.
(b) 1 + t_p <= 1 + Δ; for p < j < k, d_j = 2 so 1 + t_j <= 3; and N_k <= d_k.
If Δ >= 3 then p >= 1. If p = k: q <= d_k + Σ_{j<k} d_j <= kΔ. If p < k: q <= (p−1)Δ + (Δ+1) + 3(k−1−p) + 2 = pΔ + 3(k−p) <= kΔ.
If Δ <= 2, G = P_n or C_n: HH_k = max(1, ceil((n−1)/3)) for P_n and ceil((n+1)/3) for C_n (each step removes a 2 and turns two 2's into 1's), and gamma_t(P_n), gamma_t(C_n) = floor(n/2)+ceil(n/4)−floor(n/4) <= n/2 + 1 <= 2k (check n = 3..9 directly for paths; for n >= 10, 2(n−1)/3 >= n/2+1; for cycles 2(n+1)/3 >= n/2+1 for all n >= 2). ∎

*비고:* Tight for coronas of stars (k=1, gamma_t = Δ) and P_3-type small graphs. Verified numerically on random graphs/trees.

### 318

**진술 (WOWII 원문):** Let G is a simple connected graph with n > 1. If maximum dist_even(v) ≥ |E( bar(G) )|, then G is well total dominated.

**덮는 해석:** `maxde>=|E(bar)| => wtd`  
**에이전트 자체 확신도:** high

Notation: H = complement of G, N_H[x] closed H-neighbourhood. Basic fact (used for all wtd items): D is a TDS of G iff for every x in V, D is NOT contained in N_H[x] (x has a G-neighbour in D iff some element of D differs from x and is not an H-neighbour of x).

Step 1. dist_even(v) counts v itself plus vertices at even distance >= 2, which are non-neighbours of v, i.e. H-neighbours. So dist_even(v) <= 1 + deg_H(v) <= 1 + Delta(H). The premise gives |E(H)| <= 1 + Delta(H). If E(H) is empty, G = K_n, and every minimal TDS of K_n has exactly 2 vertices (any 2 vertices form a TDS and any larger TDS contains one). Otherwise let c be a vertex of H-degree Delta(H) >= 1, L = N_H(c). At most one edge e = yz of H is not incident with c.

Step 2 (shape of the closed H-neighbourhoods). N_H[c] = {c} u L =: A; for l in L not in e: N_H[l] = {l, c}; isolated vertices: singletons; and if e exists, three cases: (i) y,z in L: N_H[y] = N_H[z] = {c,y,z}, a subset of A; (ii) y in L, z not in L u {c}: N_H[y] = {c,y,z}, N_H[z] = {y,z}; (iii) y,z not in L u {c}: N_H[y] = N_H[z] = {y,z}.

Step 3. Let D be a minimal TDS with |D| >= 3. For each d in D, D-d (nonempty) is not a TDS, so D-d is contained in N_H[x_d] for some x_d; in particular every 2-subset of D lies in some N_H[x] (take d outside the pair).
|D| >= 4: then |D-d| >= 3, so N_H[x_d] has >= 3 elements, hence is A or (cases i/ii) {c,y,z}. In case (i) {c,y,z} is inside A; in case (iii) only A is large; so D-d is inside A for all d, and D = (D-d) u (D-d') is inside A = N_H[c]: D is not a TDS, contradiction. In case (ii), if D-d = {c,y,z} for some d then D = {c,y,z,d} and D-c = {y,z,d} must lie in a set of size >= 3 among A, {c,y,z}; A misses z and {c,y,z} misses d: contradiction; so again all D-d lie in A and D lies in A: contradiction.
|D| = 3: case (i): every N_H[x] lies in A, so all three pairs lie in A and D lies in A = N_H[c], contradiction. Case (iii): the only pair not inside A that lies in some N_H[x] is {y,z}; if y were in D the two pairs through y would both have to be {y,z}: impossible; so y,z not in D and D lies in A, contradiction. Case (ii): if z in D, both pairs through z lie in {c,y,z} (the only N_H[x] containing z are {c,y,z} and {y,z}), so D = {c,y,z} = N_H[y]: not a TDS; if z not in D all pairs lie in A (the sets containing no z are inside A), so D lies in A: contradiction.
Hence every minimal TDS has exactly 2 vertices (a TDS exists since G is connected with n>=2, and no TDS has 1 vertex), i.e. G is wtd. QED

*비고:* Premise forces complement = star + at most one extra edge (+ isolated vertices); then all minimal TDS have size 2.

### 320

**진술 (WOWII 원문):** Let G is a simple connected graph with n > 1. If maximum dist_even(v) = Tdist_min(G), then G is well total dominated.

**덮는 해석:** `maxde=Tdistmin => wtd`  
**에이전트 자체 확신도:** high

For every v: dist_even(v) <= n - deg(v) (the deg(v) neighbours are at odd distance) and Tdist(v) >= deg(v) + 2(n-1-deg(v)) = 2n-2-deg(v) (G connected). Hence max_v dist_even <= n - delta and min_v Tdist >= 2n-2-Delta. The premise (equality) gives n - delta >= 2n-2-Delta, i.e. Delta - delta >= n-2, so Delta = n-1 and delta = 1: G has a universal vertex c and a vertex p of degree 1 (its only neighbour is c). Every TDS contains c (to dominate p). If D is a TDS with |D| >= 3, pick d in D-{c} and d' in D-{c,d}: D-d contains c (dominates every vertex other than c) and d' (dominates c), so D-d is a TDS and D is not minimal. Thus every minimal TDS has exactly 2 vertices (n=2: G=K_2, unique TDS V), so G is wtd. QED

*비고:* Premise <=> G has a universal vertex and a pendant vertex. Coordinator notes a public claim exists; included for completeness.

### 321

**진술 (WOWII 원문):** Let G is a simple connected graph with n > 1. If ecc_avg(G) ≥ (1/3)*Tdist_max(G), then G is well total dominated.

**덮는 해석:** `eccavg>=Tdistmax/3 => wtd`  
**에이전트 자체 확신도:** high

Let D = diam(G) and v with ecc(v) = D. Then ecc_avg(G) <= D. The distance layers N_i(v), 1<=i<=D, are all nonempty and partition V-v, so Tdist(v) = sum_i i|N_i(v)| = (n-1) + sum_i (i-1)|N_i(v)| >= n-1 + sum_{i=2}^{D}(i-1) = n-1 + D(D-1)/2. Premise: 3 ecc_avg >= Tdist_max >= Tdist(v), so 3D >= n-1+D(D-1)/2, i.e. n <= 3D+1-D(D-1)/2. For D >= 6 the right side is < D+1 <= n, impossible; for D = 1..5 it gives n <= 4,6,7,7,6. Hence n <= 7. All connected graphs on 2..7 vertices were checked exhaustively (central database n<=9, and independently here with the networkx graph atlas and an itertools brute force for minimal TDS): exactly 16 satisfy the premise and all are wtd. QED

*비고:* Finite reduction: premise implies n <= 7.

### 323

**진술 (WOWII 원문):** Let G is a simple connected graph with n > 1. If maximum of {|N_bar(G)(e)|: e an edge of bar(G) } ≤ 1 + maximum {dist_odd(v) - odd horizontal(v): v in V(G)}, then G is well total dominated.

**덮는 해석:** `maxNbar(e)<=1+max(dodd-oddhor) => wtd`  
**에이전트 자체 확신도:** high

Reading: for an edge uv of H = complement(G), N_H(e) = N_H(u) u N_H(v) (contains u,v); |N_H(e)| = n - |N_G(u) n N_G(v)| (G-common neighbours of the non-adjacent pair u,v). So the premise says: every non-adjacent pair of G has at least n-1-q common neighbours, where q = max_v (dist_odd(v) - oddhor(v)). (G complete: reading undefined; K_n is wtd anyway.)

Join lemma (used repeatedly): if G = G_1 v G_2 v ... v G_k (k>=2, complete join) and every G_i has a vertex isolated in G_i, then every minimal TDS of G has exactly 2 vertices. Proof: a minimal TDS D cannot lie inside one V(G_i) (an isolated vertex of G_i has all its neighbours outside V(G_i)); so D contains u in V(G_i), w in V(G_j), i != j, and {u,w} is already a TDS (u dominates everything outside V(G_i), w everything outside V(G_j), in particular u); minimality gives D = {u,w}.

Step 1: diam(G) <= 2. If d(u,w) = 3 for some u,w, they are non-adjacent with no common neighbour, so the premise needs q >= n-1, i.e. some v has dist_odd(v) = n-1 and oddhor(v) = 0; then no vertex is at distance 2 from v, so v is universal and N(v) = V-v is independent: G is a star, of diameter 2, contradiction.
So for every v: dist_odd(v) = deg(v), oddhor(v) = e(N(v)) (edges inside N(v)). Let v* attain q, d = deg(v*), N = N(v*), f = e(G[N]), R = V - N[v*], r = |R| = n-1-d. Then q = d-f and the premise says: every non-adjacent pair has >= r+f common neighbours.

Step 2: N is a clique, or f <= 2. If x,y in N are non-adjacent, their common neighbours lie in {v*} u (N_N(x) n N_N(y)) u R, so r+f <= 1 + c' + r with c' = |N_N(x) n N_N(y)|, i.e. f <= 1+c'; also the 2c' edges xz,yz (z common in N) lie in G[N], so 2c' <= f. Hence c' <= 1 and f <= 2.

Case A: N is a clique. q = d - d(d-1)/2 <= 1 (and q <= 0 if d >= 3). Since G is not complete some non-adjacent pair exists and has <= n-2 common neighbours, so n-1-q <= n-2, i.e. q = 1: every non-adjacent pair has exactly n-2 common neighbours, i.e. H is a matching M (plus isolated vertices). Then a 2-set {a,b} fails to be a TDS iff ab in M (no two H-edges share a vertex, so no common H-neighbours); a minimal TDS D with |D|>=3 has, for each d, D-d inside some N_H[x], which has <= 2 elements, so |D| = 3 and all three pairs of D are M-edges: a triangle in a matching, impossible. So all minimal TDS have size 2: wtd.
Case f = 0 (N independent, here d >= 2): N is complete to R: if x in N and a in R were non-adjacent, N(x) lies in {v*} u R and a is not adjacent to v*, so their common neighbours lie in R-{a}: at most r-1 < r+0, contradiction. Hence G = G[N] v G[{v*} u R], G[N] edgeless and v* isolated in G[{v*} u R]; join lemma: wtd.
Case f = 1: then d >= 3 (if d = 2 and f = 1, N is a clique: Case A). x in N non-adjacent to a in R would have common neighbours inside (R-{a}) u N_N(x), at most r-1+1 = r < r+1; so N is complete to R, G = G[N] v G[{v*} u R] with G[N] = K_2 u (d-2)K_1 (has an isolated vertex) and v* isolated in the other part: wtd by the join lemma.
Case f = 2 with N not a clique: every non-adjacent pair in N needs c' >= 1 (f <= 1+c'); with two edges in G[N] this forces G[N] = P_3 (2K_2 or an extra isolated vertex gives a pair with c' = 0), so d = 3, q = 1, and as in Case A every non-adjacent pair has n-2 common neighbours, H is a matching: wtd. QED

*비고:* Premise forces diam 2 and G = complement of a matching, or a join of an edgeless (or K2+isolated) part with a part having an isolated vertex.

### 324

**진술 (WOWII 원문):** Let G is a simple connected graph with n > 1. If maximum of {|N_bar(G)(e)|: e an edge of bar(G) } ≤ 1 + residue(G), then G is well total dominated.

**덮는 해석:** `maxNbar(e)<=1+res => wtd`  
**에이전트 자체 확신도:** high

Reading: |N_H(e)| for an edge uv of H = complement(G) is |N_H(u) u N_H(v)| (contains u,v). L := max over E(H). Premise: L <= 1 + res(G). (G complete: undefined; K_n wtd.)
Cited theorem (Favaron-Maheo-Sacle 1991): alpha(F) >= res(F) for every graph F. Since res depends only on the degree sequence: res(G) <= alpha(G') for EVERY graph G' with the same degree sequence as G.
Co-components = vertex sets of the components of H; G is the complete join of the G[Q]. An H-edge inside Q has both H-neighbourhoods inside Q; L_Q := max over H-edges of H[Q] of |N_H(u) u N_H(v)|; L = max_Q L_Q. Join lemma (see 323): if G has >= 2 co-components and each G[Q] has a vertex isolated in G[Q], every minimal TDS has size 2, so G is wtd. Since G is connected, V is not a co-component with an isolated vertex, so it suffices to show: (*) under the premise every co-component Q has a vertex isolated in G[Q] (singleton co-components = universal vertices qualify).

Lemma A. Let Q be a co-component, |Q| >= 2, s = alpha(G[Q]), S a maximum independent set of G[Q]. Then s >= 2 and L_Q >= s; L_Q = s only if G[Q] is edgeless; L_Q = s+1 only if Q = S u {z} with z adjacent to a nonempty proper subset S-K of S ("type Z"); if G[Q] has no isolated vertex then L_Q >= s+2.
Proof. H[Q] connected with >= 2 vertices has an edge, so s >= 2. For a != b in S, ab in E(H) and N_H(a) u N_H(b) contains S; so L_Q >= s + |M_a u M_b| where M_a = N_H(a) n (Q-S). Assume L_Q <= s+1: all |M_a u M_b| <= 1, hence all M_a lie in one singleton {z}; let K = {a in S : a not adjacent to z}. If K is empty, S is G-complete to Q-S, H has no S-(Q-S) edges, H[Q] connected forces Q = S (edgeless, L_Q = s). If a in K: N_H(a) = (S-a) u {z}, so |N_H(a) u N_H(z)| >= s+1+|N_H(z) n (Q-S-z)|, forcing z G-complete to Q-S-z; then H has no edges between S u {z} and the rest of Q, so Q = S u {z}; K != S (else S u {z} independent of size s+1); and L_Q = s+1. Both outcomes have isolated vertices in G[Q] (type Z: the vertices of K). QED
Lemma B. If G[Q] has no isolated vertex then |Q| >= 4 and H[Q] has two disjoint edges. (Co-connected graphs on <= 3 vertices are 2K_1, K_2+K_1, 3K_1; H[Q] is connected, not a star (a star centre would be isolated in G[Q]), on >= 4 vertices, hence contains a 4-vertex path.)

Proof of (*). Suppose some co-component B has no isolated vertex in G[B]. Let U = universal vertices, G_0 = G - U. (1) res(G) = res(G_0): HH lays off an entry n-1, subtracting 1 from all others, which gives the degree sequence of G-u; repeat. (2) L(G_0) = L(G) = L and the co-components of G_0 are those of G with >= 2 vertices. (3) T := L-2 >= alpha(G[B]) >= 2 by Lemma A (L >= L_B >= alpha(G[B])+2). (4) A co-component Q is needy if alpha(G[Q]) > T. Then s = alpha(G[Q]) >= L-1 >= L_Q - 1, so by Lemma A, Q is edgeless with s in {T+1, T+2} (demand 2 if s = T+2, else 1) or of type Z with s = T+1 (demand 1). B is not needy. Demand pairs (non-adjacent pairs inside Q, pairwise disjoint): edgeless demand 2: two disjoint pairs (s >= 4); edgeless demand 1: one pair; type Z: a pair inside K if |K| >= 2, else a pair inside S. Supply: two disjoint non-adjacent pairs in B (Lemma B). (5) Match demand pairs with demand pairs of a different needy co-component or with distinct supply pairs (always possible: if one needy co-component, use the <= 2 supply pairs; if >= 2 needy co-components with D demand pairs listed consecutively by co-component, for D even match position i with i+D/2 (D=2 means two different co-components; D>=4 means positions D/2 >= 2 apart, and a co-component occupies <= 2 consecutive positions); for D odd first match one pair of a maximum-demand co-component with a supply pair and proceed). (6) For each matched couple {a,b} in Q, {x,y} in Q' (Q != Q'), perform the 2-switch: delete ax, by (edges, as distinct co-components are completely joined), add ab, xy (non-edges). All vertices used are distinct, so the deleted edges form a matching, each between different co-components; degrees are preserved: G' has the degree sequence of G_0. (7) alpha(G') <= T: if an independent set S' of G' meets two co-components in u, v then uv is a deleted edge; any third w in S' outside u's co-component would be G'-adjacent to u (join edge, not deleted since u has only one deleted edge), similarly for v, so |S'| = 2 <= T. Inside one co-component Q, G'[Q] = G[Q] + added edges: non-needy Q gives <= T; edgeless Q gets 2 resp. 1 disjoint new edges: alpha = s-2 = T resp. s-1 = T; type Z: subsets of S miss an endpoint of the new edge (<= s-1), sets containing z lie in {z} u K minus one endpoint (|K| >= 2 case: <= |K| <= s-1) or are inside {z} u K with |K| = 1 (size <= 2 <= T). (8) FMS: res(G) = res(G_0) <= alpha(G') <= L-2, contradicting the premise L <= 1+res(G). Hence (*) holds and G is wtd. QED

*비고:* Premise forces G to be a join of co-components each having a vertex isolated inside it (all minimal TDS have size 2). Uses only the FMS bound alpha >= residue, applied to a degree-preserving 2-switch modification.

### 325

**진술 (WOWII 원문):** Let G is a simple connected graph with n > 1. If minimum of {|N_bar(G)(e)|: e an edge of bar(G) } ≤ 1 + number of components of <N[S}> where S is the set of vertices of degree two, then G is well total dominated.

**덮는 해석:** `minNbar(e)<=1+c(N[D2]) => wtd`  
**에이전트 자체 확신도:** high

Reading: min over edges uv of H = complement(G) of |N_H(u) u N_H(v)| = n - max over non-adjacent pairs of the number of common G-neighbours; c := number of components of G[N[D2]] (0 if D2 empty). (G complete: undefined.) Let u,v be a non-adjacent pair with X = N(u) n N(v) of maximum size; O := V - (X u {u,v}). Premise: n - |X| <= 1 + c, i.e. |O| <= c-1. So c >= 1 and D2 is nonempty. Each component of G[N[D2]] contains N[w] (3 vertices) for some w in D2, so 3c <= n.
n <= 5: covered by the exhaustive check (all connected graphs n<=9 centrally; n<=7 independently re-checked here).
n >= 6: |X| >= n-1-c >= n-1-n/3 >= 3, so u,v have degree >= 3 and are not in D2.
Claim c = 1. Suppose c >= 2. If w in X n D2 then N(w) = {u,v}, so all D2-vertices of X lie in the component K_0 containing u (and v). Every other component K_j contains some w_j in D2, necessarily in O (not in X, not u,v); these w_j are distinct, so c-1 <= |O| <= c-1: there is exactly one exceptional component K_0 (containing u,v) and O = {w_j}. Take j != 0. w_j is not adjacent to u or v (else u or v would lie in K_j), nor to another w_j' (different components), so N(w_j) lies in X; a neighbour x in X of w_j lies in N[D2] and is adjacent to u, which lies in N[D2] as well, so x and u are in the same component: K_j = K_0, contradiction.
So c = 1, |O| = 0: u and v are non-adjacent and adjacent to all other vertices; each other vertex has degree 2 + (its degree in G[X]), so D2 nonempty means G[X] has an isolated vertex. G = G[{u,v}] v G[X] with G[{u,v}] edgeless and G[X] having an isolated vertex; by the join lemma (see 323) every minimal TDS has size 2: wtd. QED

*비고:* For n>=6 the premise forces G = (2K_1) v W with W having an isolated vertex.

### 326

**진술 (WOWII 원문):** Let G is a simple connected graph with n > 1. If 3* μ(G) ≤ |E(S)| where S is the set of vertices of degree two, then G is well total dominated.

**덮는 해석:** `3mu<=|E(D2)| => wtd`  
**에이전트 자체 확신도:** high

Vertices of D2 have degree 2, so G[D2] has maximum degree <= 2: its components are paths and cycles. A cycle component consists of degree-2 vertices whose neighbours are all on the cycle, so it is a component of G; G connected means G is that cycle. Otherwise G[D2] is a linear forest with path components of k_i vertices, |E(D2)| = sum (k_i - 1) and mu(G) >= mu(G[D2]) = sum floor(k_i/2). For k >= 2, 3 floor(k/2) > k-1, so if E(D2) is nonempty then 3mu(G) > |E(D2)|; if E(D2) is empty, 3mu(G) >= 3 > 0 (G connected, n >= 2, has an edge). So the premise fails unless G = C_n, where it reads 3 floor(n/2) <= n, i.e. n = 3. G = K_3 is wtd (every minimal TDS is a pair). QED

*비고:* Premise holds only for K_3.

### 356

**진술 (WOWII 원문):** If T is a tree on n>2 vertices, then γ_T(T) ≥ |C|* dist_avg(L), where C is the center of T and L is the set of leaves of T.

**덮는 해석:** `gt>=|C|*distavg_from(L)`  
**에이전트 자체 확신도:** high

**Lemma A (counting lemma).** Let T be a tree, D a total dominating set (TDS) of T, c the number of components of T[D], O = V(T)\D, e(O) the number of edges with both ends in O, and O_1, O_2, O_3 the vertices of O of degree 1, 2, >=3. Then (i) every component of T[D] has >= 2 vertices, so c <= |D|/2; (ii) e(O) <= c-1; (iii) sum_{x in O}(deg x - 1) = c-1+e(O) <= 2c-2, in particular |O_2| + 2|O_3| <= 2c-2 <= |D|-2; (iv) n <= 2|D| + l - 2 (l = #leaves), i.e. gamma_t(T) >= (n-l+2)/2 (Chellali-Haynes bound).
*Proof.* (i): every vertex of D has a neighbour in D. Contract each component of T[D] to one vertex, obtaining T*. No x in O has two neighbours in one component and no two components are adjacent (either would give a cycle / contradict maximality), so T* is a simple connected graph with |O|+c vertices and (n-1) - sum_K(|K|-1) = |O|+c-1 edges, i.e. a tree; its edges are the e(O) edges inside O and the e(O,D) edges between O and D, so e(O)+e(O,D) = |O|+c-1. As D is a TDS, every x in O has a neighbour in D: e(O,D) >= |O|, giving (ii). Further sum_{x in O} deg x = e(O,D)+2e(O) = |O|+c-1+e(O), which is (iii) (deg x - 1 is >=1 on O_2 and >=2 on O_3). (iv): n = |D|+|O_1|+|O_2|+|O_3| <= |D| + l + (2c-2) <= 2|D| + l - 2. QED

Reading: gamma_t >= |C| * (average over non-leaves v of h(v) := dist(v,L)). Since |C| <= 2 we prove the stronger **gamma_t >= 2 * avg_{v not in L} h(v)** for every tree with n >= 3.
Let N' = n - l >= 1 (non-leaves), d = diam >= 2, H_t = {v : h(v) >= t}; H_1 = V\L and sum_{v not in L} h(v) = sum_{t>=1} |H_t|.
Claim 1: h(v) <= floor(d/2) for each non-leaf v: two branches at v each contain a leaf, at distances p, q from v; p+q (their distance) <= d, so h(v) <= min(p,q) <= d/2.
Claim 2: |H_t| <= max(0, N' - 2(t-1)) for t >= 2. Take a diametral path x_0...x_d (x_0, x_d leaves). For 1 <= i <= t-1, h(x_i) <= i < t and h(x_{d-i}) <= i < t. If d >= 2t-1 these are 2(t-1) distinct non-leaves outside H_t; if d <= 2t-2 then H_t is empty by Claim 1.
Hence sum h <= sum_{s>=0} max(0, N'-2s) = m(m+1) if N' = 2m, and = m^2 if N' = 2m-1. By Lemma A(iv), gamma_t >= (N'+2)/2, so gamma_t >= m+1 in both cases (integrality). If N' = 2m: 2*avg <= 2m(m+1)/(2m) = m+1 <= gamma_t. If N' = 2m-1: 2*avg <= 2m^2/(2m-1) <= m+1 since (m+1)(2m-1) - 2m^2 = m-1 >= 0. Therefore gamma_t >= 2*avg >= |C|*avg. QED (equality e.g. for stars and P_{4k}).

*비고:* Also re-tested on ~3000 trees incl. families; min slack of the stronger inequality = 0 (P3, P4, P8...).

### 372

**진술 (WOWII 원문):** If T is a tree on n>2 vertices, then γ_T(T) ≥ v_c(T)/(p(T) - 1)

**덮는 해석:** `gt>=vc/(p-1)`  
**에이전트 자체 확신도:** high

**Lemma A (counting lemma).** Let T be a tree, D a total dominating set (TDS) of T, c the number of components of T[D], O = V(T)\D, e(O) the number of edges with both ends in O, and O_1, O_2, O_3 the vertices of O of degree 1, 2, >=3. Then (i) every component of T[D] has >= 2 vertices, so c <= |D|/2; (ii) e(O) <= c-1; (iii) sum_{x in O}(deg x - 1) = c-1+e(O) <= 2c-2, in particular |O_2| + 2|O_3| <= 2c-2 <= |D|-2; (iv) n <= 2|D| + l - 2 (l = #leaves), i.e. gamma_t(T) >= (n-l+2)/2 (Chellali-Haynes bound).
*Proof.* (i): every vertex of D has a neighbour in D. Contract each component of T[D] to one vertex, obtaining T*. No x in O has two neighbours in one component and no two components are adjacent (either would give a cycle / contradict maximality), so T* is a simple connected graph with |O|+c vertices and (n-1) - sum_K(|K|-1) = |O|+c-1 edges, i.e. a tree; its edges are the e(O) edges inside O and the e(O,D) edges between O and D, so e(O)+e(O,D) = |O|+c-1. As D is a TDS, every x in O has a neighbour in D: e(O,D) >= |O|, giving (ii). Further sum_{x in O} deg x = e(O,D)+2e(O) = |O|+c-1+e(O), which is (iii) (deg x - 1 is >=1 on O_2 and >=2 on O_3). (iv): n = |D|+|O_1|+|O_2|+|O_3| <= |D| + l + (2c-2) <= 2|D| + l - 2. QED

Reading: gamma_t >= v_c/(p-1), v_c = n - alpha (vertex cover number), p = path-cover number; undefined when p = 1 (T a path). Let l = #leaves. In a path cover every leaf is an end of a path, so l <= 2p; l >= 3 since T is not a path. For n >= 3 the non-leaves form a vertex cover, so v_c <= n-l; by Konig v_c = nu (matching number) <= floor(n/2). Lemma A(iv): gamma_t >= (n-l+2)/2.
(a) p >= 3: v_c/(p-1) <= v_c/2 <= (n-l)/2 < (n-l+2)/2 <= gamma_t.
(b) p = 2, so l in {3,4}. l = 3: gamma_t >= ceil((n-1)/2) = floor(n/2) >= v_c. l = 4, n odd: gamma_t >= ceil((n-2)/2) = floor(n/2) >= v_c. Remaining case l = 4, p = 2: sum_{deg>=3}(deg-2) = l-2 = 2, so there is one vertex of degree 4, or two of degree 3, all other degrees <= 2. With 2 paths and 4 leaves, every path has two (distinct) leaf ends. A degree-4 vertex x lies on one path using two of its branches; the leaves of the other two branches are the ends of the second path, which must pass through x: impossible. If the two degree-3 vertices u, v are non-adjacent, the cover path through an inner vertex w of the u-v path joins a leaf beyond u to a leaf beyond v and uses u, v; the remaining two leaves (one beyond u, one beyond v) need a path through u and v too: impossible. So T is an H-tree: adjacent u, v of degree 3 with legs (pendant paths) of lengths a1,a2 at u and b1,b2 at v.
**Reduction lemma.** Let a leg have length L >= 5 and let y_0,...,y_5 be its last six vertices (y_5 the leaf, y_1..y_4 of degree 2, y_0 = u or v if L = 5); T' = T - {y_2,y_3,y_4,y_5}. Then gamma_t(T) = gamma_t(T')+2 and nu(T) = nu(T')+2. Proof: adding y_3, y_4 to a TDS of T' gives a TDS of T. Conversely let D be a minimum TDS of T; y_4 is in D (support). If y_5 in D replace it by y_3; so WLOG y_3 in D, y_5 not in D. If y_2 in D, then (D\{y_2,y_3,y_4}) u {y_0} is a TDS of T' (y_1 is dominated by y_0; no other vertex of T' is adjacent to y_2, y_3, y_4); if y_2 not in D then y_0 in D (to dominate y_1) and D\{y_3,y_4} is a TDS of T'. Either way gamma_t(T') <= gamma_t(T)-2. For nu: a maximum matching of T' plus y_2y_3, y_4y_5 shows nu(T) >= nu(T')+2; a matching of T uses at most 2 of the 4 edges of the path y_1...y_5 and its other edges form a matching of T', so nu(T) <= nu(T')+2. QED
Thus gamma_t - v_c is invariant when legs are reduced into {1,2,3,4} (T' is again an H-tree with p=2, l=4). A computer check of all H-trees with legs in {1..8}^4 (4096 trees, including all 4^4 reduced ones, n <= 18; library values, p = 2 confirmed for each) gives gamma_t >= v_c every time (also covered by the central exhaustive check of trees n <= 18). Hence gamma_t >= v_c = v_c/(p-1). QED

*비고:* The reduction lemma was also verified numerically on the H-trees. Re-tested on 1500 random trees.

### 377

**진술 (WOWII 원문):** If T is a tree on n>2 vertices, then γ_T(T) ≥ number of isolates of <M> + upper median(T).

**덮는 해석:** `gt>=iso(M)+upmedian`  
**에이전트 자체 확신도:** high

**Lemma A (counting lemma).** Let T be a tree, D a total dominating set (TDS) of T, c the number of components of T[D], O = V(T)\D, e(O) the number of edges with both ends in O, and O_1, O_2, O_3 the vertices of O of degree 1, 2, >=3. Then (i) every component of T[D] has >= 2 vertices, so c <= |D|/2; (ii) e(O) <= c-1; (iii) sum_{x in O}(deg x - 1) = c-1+e(O) <= 2c-2, in particular |O_2| + 2|O_3| <= 2c-2 <= |D|-2; (iv) n <= 2|D| + l - 2 (l = #leaves), i.e. gamma_t(T) >= (n-l+2)/2 (Chellali-Haynes bound).
*Proof.* (i): every vertex of D has a neighbour in D. Contract each component of T[D] to one vertex, obtaining T*. No x in O has two neighbours in one component and no two components are adjacent (either would give a cycle / contradict maximality), so T* is a simple connected graph with |O|+c vertices and (n-1) - sum_K(|K|-1) = |O|+c-1 edges, i.e. a tree; its edges are the e(O) edges inside O and the e(O,D) edges between O and D, so e(O)+e(O,D) = |O|+c-1. As D is a TDS, every x in O has a neighbour in D: e(O,D) >= |O|, giving (ii). Further sum_{x in O} deg x = e(O,D)+2e(O) = |O|+c-1+e(O), which is (iii) (deg x - 1 is >=1 on O_2 and >=2 on O_3). (iv): n = |D|+|O_1|+|O_2|+|O_3| <= |D| + l + (2c-2) <= 2|D| + l - 2. QED

Notation: I = isolated vertices of <M> (max-degree vertices with no max-degree neighbour), so iso(M) = |I|; I is independent. Upper median u = d_{floor(n/2)+1} of the nondecreasing degree sequence (library convention).
Step 0: u <= 2. Since l = 2 + sum_{deg>=3}(deg-2) >= 2 + n_{>=3}, fewer than n/2 vertices have degree >= 3, so at least floor(n/2)+1 degrees are <= 2. Also u = 1 iff l >= floor(n/2)+1.
Step 1: Delta = 2 (T = P_n). n = 3: |I| = 1, u = 1, gamma_t = 2. n >= 4: M = inner vertices induce a path with >= 2 vertices, I is empty, and gamma_t >= 2 >= u.
Step 2: Delta >= 3. Let D be a minimum TDS, c = #components of T[D], O = V\D. Each component K of T[D] contains a vertex not in I (|K| >= 2; a vertex of I in K has a neighbour in K, which is not in M). So |D\I| >= c. Vertices of I\D have degree Delta >= 3, so |I\D| <= |O_3| <= c-1 (Lemma A(iii)). Hence |D| >= |D n I| + c >= |D n I| + |I\D| + 1 = |I| + 1.
Step 3 (equality): if |D| = |I|+1 then |D\I| = c and |I\D| = |O_3| = c-1, so O_3 = I\D, O_2 is empty and e(O) = c-1 by Lemma A(iii). But no edge of O meets O_1 (a leaf outside D has its only neighbour in D) and O_3 = I\D is independent, so e(O) = 0 and c = 1. Thus I is inside D, D = I u {w} with T[D] connected, i.e. a star centred at w with leaf set I (r := |I| >= 1), and every vertex outside D is a leaf. So T is: w adjacent to the r vertices of I (each of degree Delta, with Delta-1 pendant leaves) and to deg(w)-r leaves; w is not in M, so deg w <= Delta-1. Its leaves: l = n - r - [deg w >= 2]. If deg w = 1 (r = 1, n = Delta+1 >= 4): l = n-1 >= floor(n/2)+1. If deg w >= 2: l = n-r-1 and n = 1 + r(Delta-1) + deg w >= 1 + 2r + max(r,2), so ceil(n/2) >= r+2 (r=1: n>=5; r=2: n>=7; r>=3: n>=3r+1 >= 2r+4), i.e. l >= floor(n/2)+1. Hence in the equality case u = 1.
Conclusion: if u = 1, gamma_t >= |I|+1 = iso(M)+u; if u = 2, the equality case is excluded, so gamma_t >= |I|+2 = iso(M)+u. QED

*비고:* Same argument also proves 376 (equality case is never bicentroidal). Re-tested on 1500 random trees.

### 380

**진술 (WOWII 원문):** If T is a tree on n>2 vertices, then γ_T(T) ≥ |D_even(T)|/(ecc(C) - 1), where C is the center of T and D_even(T) is the set of vertices whose degree is an even number.

**덮는 해석:** `gt>=|Deven|/(ecc(C)-1)`  
**에이전트 자체 확신도:** high

**Lemma A (counting lemma).** Let T be a tree, D a total dominating set (TDS) of T, c the number of components of T[D], O = V(T)\D, e(O) the number of edges with both ends in O, and O_1, O_2, O_3 the vertices of O of degree 1, 2, >=3. Then (i) every component of T[D] has >= 2 vertices, so c <= |D|/2; (ii) e(O) <= c-1; (iii) sum_{x in O}(deg x - 1) = c-1+e(O) <= 2c-2, in particular |O_2| + 2|O_3| <= 2c-2 <= |D|-2; (iv) n <= 2|D| + l - 2 (l = #leaves), i.e. gamma_t(T) >= (n-l+2)/2 (Chellali-Haynes bound).
*Proof.* (i): every vertex of D has a neighbour in D. Contract each component of T[D] to one vertex, obtaining T*. No x in O has two neighbours in one component and no two components are adjacent (either would give a cycle / contradict maximality), so T* is a simple connected graph with |O|+c vertices and (n-1) - sum_K(|K|-1) = |O|+c-1 edges, i.e. a tree; its edges are the e(O) edges inside O and the e(O,D) edges between O and D, so e(O)+e(O,D) = |O|+c-1. As D is a TDS, every x in O has a neighbour in D: e(O,D) >= |O|, giving (ii). Further sum_{x in O} deg x = e(O,D)+2e(O) = |O|+c-1+e(O), which is (iii) (deg x - 1 is >=1 on O_2 and >=2 on O_3). (iv): n = |D|+|O_1|+|O_2|+|O_3| <= |D| + l + (2c-2) <= 2|D| + l - 2. QED

Step 1: |D_even| <= 2 gamma_t - 2. Let D be a minimum TDS; leaves have odd degree, so D_even is contained in D u O_2 u O_3, and |O_2|+|O_3| <= 2c-2 <= |D|-2 by Lemma A.
Step 2: ecc(C) = floor(d/2), d = diam: if d = 2r, C = {c} and max dist(v,c) = r; if d = 2r-1, C = {c1,c2} adjacent with ecc = r, every vertex on c_i's side of the edge c1c2 is within r-1 of c_i, and the ends of a diametral path attain r-1.
Step 3: d <= 3 gives ecc(C)-1 = 0 (reading undefined). d >= 6: ecc(C)-1 >= 2 and RHS <= (2gamma_t-2)/2 < gamma_t.
Step 4: d = 4. Every vertex is within distance 2 of the centre c, so each neighbour x of c is a leaf or a support all of whose other neighbours are leaves; let s' >= 2 be the number of non-leaf neighbours of c. D_even is contained in {c} u (non-leaf neighbours of c), so |D_even| <= s'+1. The s' supports lie in every TDS D; if c is not in D each of them needs one of its own leaves in D, so |D| >= 2s' >= s'+2; otherwise |D| >= s'+1. So gamma_t >= |D_even| = RHS.
Step 5: d = 5. Centres c1 ~ c2; deleting c1c2 leaves T_1, T_2 (c_i in T_i) with every vertex of T_i within distance 2 of c_i; hence every non-leaf neighbour of c_i in T_i is a support whose other neighbours are leaves; let s_i >= 1 be their number. D_even is contained in {c1,c2} u (these s_1+s_2 vertices). A TDS D contains the s_1+s_2 supports; if c_i is not in D, the s_i supports at c_i need their own leaves in D (>= 1 extra vertex). So |D| >= s_1+s_2+2 >= |D_even| = RHS. QED

*비고:* Re-tested on 1500 random trees; tight e.g. for P5 (d=4).

### 421c

**진술 (WOWII 원문):** Let G be a connected graph on n > 3 vertices and M_λ the vertices of maximum local independence. Then i(G) ≤ γ(G)(|N[M_λ ]| - 3).

**덮는 해석:** `i<=gamma(|N[Mlam]|-3)`  
**에이전트 자체 확신도:** high

Notation: lambda(v)=alpha(G[N(v)]), lam=max_v lambda(v), M = M_lambda = {v: lambda(v)=lam}, N[M] closed neighbourhood of the set M. G connected, n>=4.

**Lemma A (Bollobas-Cockayne type count).** Let D be a minimum dominating set, I0 a maximal independent subset of D, R=V-N[I0], J a maximal independent set of G[R]. Then I0 u J is an independent dominating set, every j in J has a neighbour in D-I0, and |J n N(x)| <= lambda(x)-1 for every x in D-I0. Hence i(G) <= |I0| + sum_{x in D-I0} (lambda(x)-1).
*Proof.* J has no neighbour in I0 (R avoids N[I0]), so I0 u J is independent; N[I0] is dominated by I0 and R by J. A vertex j in J is not in D (vertices of D-I0 have a neighbour in I0 by maximality of I0, so lie in N(I0)), so j has a D-neighbour x, and x is not in I0 because j is not in N(I0). For x in D-I0 pick y in I0 n N(x); (J n N(x)) u {y} is an independent subset of N(x) (y has no neighbour in R), so |J n N(x)|+1 <= lambda(x). Summing over x gives the bound on |J|. Also |I0|>=1. QED

**Proof of 421c.** Pick v in M. N[M] contains N[v], so |N[M]| >= deg(v)+1 >= lam+1.
*Case lam=1.* Every neighbourhood is a clique; a connected graph with this property is complete (a vertex with two non-adjacent neighbours would have lambda>=2). Then i=gamma=1 and the bound is n-3>=1.
*Case lam>=2, |N[M]|>=lam+2.* Bound >= gamma(lam-1). Lemma A with lambda(x)<=lam: i <= |I0|+(lam-1)(gamma-|I0|) = (lam-1)gamma-(lam-2)|I0| <= (lam-1)gamma.
*Case lam>=2, |N[M]|=lam+1.* For every u in M, N[u] is contained in N[M] and |N[u]|>=lam+1, so N[u]=N[M], deg(u)=lam, and N(u) is independent (alpha(N(u))=lam=|N(u)|). If u,w in M were distinct, N[u]=N[w] gives w in N(u) and N(u)-{w} contained in N(w), contradicting independence of N(u) (as |N(u)|=lam>=2). So M={v}, N(v) is independent of size lam, the bound equals gamma(lam-2), and lambda(x)<=lam-1 for x != v.
 - lam=2: N(v)={a,b}, a,b non-adjacent, and every x != v has lambda(x)<=1, i.e. N(x) is a (non-empty) clique. N(a) is a clique containing v, so any other neighbour w of a is adjacent to v, i.e. w in {a,b}, impossible. So N(a)={v}, likewise N(b)={v}, and {a,v,b} is a component: G=P3, contradicting n>3.
 - lam=3: bound = gamma. Every x != v has lambda(x)<=2. Take a minimum dominating set D with the fewest edges in G[D]. Suppose G[D] has an edge xy; since x != y we may assume x != v. Let P={w in V-D : N(w) n D={x}}. If P is empty, D-{x} dominates (x is adjacent to y), contradiction. If w1,w2 in P were non-adjacent then {y,w1,w2} would be an independent subset of N(x) (w_i is not adjacent to y), so lambda(x)>=3, contradiction; so P is a non-empty clique. For w in P, D'=(D-{x}) u {w} is dominating (P inside N[w], x adjacent to y, all other vertices keep a D-neighbour), |D'|=|D|, and w has no neighbour in D-{x}, so G[D'] has fewer edges than G[D]. Contradiction. Hence D is independent and i <= gamma = bound.
 - lam>=4: Lemma A with lambda(x)<=lam-1 (x != v) and lambda(v)=lam: i <= |I0|+(lam-2)(gamma-|I0|)+[v in D-I0] <= (lam-2)gamma-(lam-3)|I0|+1 <= (lam-2)gamma, using |I0|>=1 and lam>=4.
All cases give i(G) <= gamma(G)(|N[M_lambda]|-3). QED
Boundary checks: K_n (n>=4): 1<=n-3; stars K_{1,k}: M={centre}, |N[M]|=k+1, bound k-2>=1 for k>=3; P4: lam=2, M = two inner vertices, |N[M]|=4, bound gamma*1=2=i (tight).

*비고:* Uses only the elementary Lemma A (essentially the Bollobas-Cockayne K_{1,k+1}-free argument) and the Allan-Laskar swap argument, both proved inline. Re-tested on 600 random graphs (n 10-18): min slack 0, no violation.

### 432b

**진술 (WOWII 원문):** Let G be a connected graph on n > 3 vertices and P the set of pendants of G. Then i(G) ≤ |V-N(P)|+ minimum{vertices at even distance from v - vertices at odd distance from v}*_bipartite.

**덮는 해석:** `i<=|V-N(P)|+min(de-do)*chibip`  
**에이전트 자체 확신도:** high

Reading: P = pendant vertices, N(P) = support vertices, de(v)/do(v) = number of vertices at even/odd distance from v with v itself counted (distance 0 is even), chi_bip = 1 iff G bipartite. G connected, n>=4.

*Non-bipartite G.* RHS = n-|N(P)|. P is independent (two adjacent pendants would form a K2 component). Extend P to a maximal independent set I; I is an independent dominating set and I misses N(P) (every vertex of N(P) has a neighbour in P subset I). So i <= |I| <= n-|N(P)|. (If P is empty this is i<=n.)

*Bipartite G* with parts X,Y, |X|>=|Y|>=1. For v in X the vertices at even distance are exactly X (G connected), so de(v)-do(v)=|X|-|Y|; for v in Y it is |Y|-|X|. Hence min_v(de-do)=|Y|-|X| and RHS = n-|N(P)|-(|X|-|Y|) = 2|Y|-|N(P)|.
Claim |N(P)| <= |Y|: map a support vertex s in X to one of its pendant neighbours (which lies in Y), and a support vertex s in Y to itself. Two supports never share a pendant, and a pendant (degree 1) is never a support (a support of degree 1 with its pendant would be a K2 component, impossible for connected n>=4); so the map is an injection into Y.
Therefore RHS >= 2|Y|-|Y| = |Y| >= i(G), since Y is independent and dominating (each vertex of X has a neighbour, necessarily in Y). QED
Remark: the variant that does NOT count v itself in de(v) is false already for K_{1,3} (RHS 0 < i=1); it is the counted version that survives the gate and is proved here.

*비고:* Re-tested on 600 random graphs: min slack 0, no violation. Tight for stars and many trees.

