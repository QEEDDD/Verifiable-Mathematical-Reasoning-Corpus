# Audited extension: WOWII 232, 392b and 392d

This folder contains three complete mathematical proofs and independent,
portable verification programs. The TeX files are integration fragments:
the companion single-file unified paper supplies their theorem environments,
cross-references and bibliography. Do not compile the fragments on their own.

## Complete results in this extension

- **232:** for every connected graph of order at least two,
  `2 gamma_t >= radius + p3`, where p3 is the largest minimum pairwise
  distance among three vertices. This implies the original periphery bound.
  Spiders with arm lengths 2, 4k+1, 4k+1 attain equality for every k >= 1.
- **392b and 392d:** proofs of the original inequalities for connected
  graphs of order greater than two, using constrained cuts and matching.
- The prescribed-set lemma gives `gamma_k <= |I| + matching(G-I)` whenever
  every vertex v outside I satisfies `degree(v)+|N(v) intersect I| >= 2k-1`.

The spanning-tree/tripod method has antecedents in Henning--Yeo (2014),
and the maximum-cut/matching method in DeLaVina et al. (2011). The paper
states the additional claims precisely and does not claim worldwide priority
for these methods or for every numbered entry it treats.

## Run the portable checks

Requirements: Python 3 and NetworkX. The recorded runs used NetworkX 3.7.
From this directory:

```sh
python -m pip install -r requirements.txt
python verify232.py
python verify392_cuts.py
```

`verify232.py` checks all 32,507 nonisomorphic trees on 2--16 vertices,
all 995 connected graph-atlas graphs on 2--7 vertices, and 10,000 additional
deterministic random/family instances on 8--20 vertices. It also checks
intermediate inequalities and cross-checks small total-domination optima
with independent subset enumeration. The complete run takes substantially
longer than the cut checker; the supplied log records a completed PASS.

`verify392_cuts.py` constructs and verifies actual two-dominating sets for
both statements on all 994 connected atlas graphs on 3--7 vertices and
172 structured examples up to 200 vertices. On the atlas it also computes
exact two-domination by independent subset enumeration. The supplied JSON
records a completed PASS. Neither script imports a workspace-specific module.
Finite computation corroborates the proofs; it does not replace them.

## Additional partial results

The files named `partial*` do not resolve their numbered conjectures in full.
The 269 refinement gives a dominating induced path under total-domination
equality. The leaf refinements narrow residual cases. For 434, the full
equality class `i(G)=degeneracy(complement)+1` has a dominating center and
diameter at most three. The remaining positive-slack cases are unresolved.
In particular, no claim that both 434d/e hold whenever complement degeneracy
is at most three is made.

## Toolkit repair and scope

The surrounding toolkit is a corrected copy of the user's uploaded ZIP.
The uploaded originals were not modified. `toolkit_accounting.patch` and
`toolkit_patch_report.md` describe the changes. Evaluations skipped because
of solver limits are now reported separately from passing tests. An
all-reading counterexample requires complete evaluation of every selected
reading. The small-graph gate is an empirical search filter, not a proof
of which source interpretation was intended. Existing `out/*.json` files
are historical snapshots and have not been retroactively revalidated.

The original toolkit's broader exhaustive-search claims are not repeated
as fresh runs here. The new checks above, the eight diagnostic regressions,
and the specific audits documented in the unified paper are the work
completed for this extension. The mathematical results already present
in the uploaded proof collection are not counted again as new closures.

From `../wowii`, run the diagnostic regressions with:

```sh
python -m unittest test_runner_diagnostics -v
```

The original toolkit has its own dependencies and compiles its C core
from the bundled source. Compiled binaries, caches, and graph databases
are deliberately omitted from this source archive.
