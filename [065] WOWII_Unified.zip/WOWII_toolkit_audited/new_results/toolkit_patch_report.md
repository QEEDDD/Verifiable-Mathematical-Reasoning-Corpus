# Round 9 toolkit accounting repair

Changes were made only in the extracted working copy
`tmp/round9/wowii_toolkit/`. The uploaded ZIP and uploaded source documents
were not edited. The main paper was not edited by this lane.

## Concrete defect

`families.py` contains `KG(7,3)`, but the 35-vertex graph's `core` property
calls `indsets_info()`, which has a 30-vertex guard. The old runner silently
omitted this undefined reading. Therefore the family generator's inclusion
of a graph did not establish that WOWII 108 was tested on it. The repaired
runner reports this case as `tested=0`, `fail=0`, `skipped=1`, with reason
`Undefined: too large for brute force`. It makes no passing claim.

## Changes

- `wowii/runner.py`: preserves the historical `evaluate(cid,G)` result and
  adds optional diagnostics. Records skipped counts, reasons and examples
  per reading, plus hypothesis/generator skips. A robust record requires
  all candidate readings to have been evaluated and to fail. Missing,
  undefined or passing readings, including false-premise implications,
  prevent that record. Gate-selected records name their empirical scope.
- `wowii/make_gate.py`: ignores `_timeouts` and other metadata; accepts old
  stats records; excludes readings never evaluated without calling them
  false. Its description and output explicitly identify an empirical
  reading filter, not an interpretation of the source statement.
- `wowii/merge.py`, `wowii/report.py`: preserve and display skip diagnostics,
  ignore metadata as conjectures, and display zero-test readings as
  `UNTESTED` rather than `ok`.
- `wowii/localsearch.py`, `wowii/check_cex.py`: require complete evaluation
  of selected readings before an all-reading violation claim. The latter
  reports `unevaluated_survivors` and checks the graph hypothesis.
- `wowii/collect.py`: ignores sweep metadata and labels gate observations
  `gate_sample_counterexamples`, replacing the misleading
  `false_as_written` field for those observations.
- Both toolkit `README.md` copies describe these distinctions and the
  original output snapshots' historical status.
- `wowii/test_runner_diagnostics.py`: eight targeted regression tests.

The gate and counterexample-map JSON formats remain compatible. The new
diagnostic fields are additive. The deliberate collection-field rename
above removes a source-truth claim that the empirical gate cannot justify.
No general CP-SAT core solver or symmetry oracle was added.

## Verification

Command, from the `wowii` directory:

```sh
python -m unittest test_runner_diagnostics -v
```

Result: **8 tests passed**, with no warnings, in 0.744 seconds in the
available environment. The cases cover:

1. Actual `KG(7,3)` core-limit skip and compatibility of the old call signature.
2. A failing reading plus a skipped reading, gated scope and missing readings.
3. A false implication premise blocking an all-reading counterexample claim.
4. Distinct hypothesis and reading-generator skip diagnostics.
5. Legacy stats, metadata and all-skipped gate input.
6. The real CLI chain runner → gate → merge → report, preserving skip counts.
7. Local-search and independent-certificate all-reading completeness.
8. Collection output distinguishing empirical gate observations from source truth.

## Mathematical follow-up

The supplied proof of 96 suggests BFS layer charging; 137 suggests a
P4-free join decomposition. I tried both as routes into 40, 61, 133, 189
and 199, including clique substitutions and separator obstructions for the
traceability implications. No additional full closure of those five was
obtained in this round. The previous round's infinite counterfamily for
108 remains the complete mathematical result from this lane, and is not
counted again.
