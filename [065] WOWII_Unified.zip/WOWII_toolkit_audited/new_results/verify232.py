"""Exact corroboration of the radius/three-point bound and WOWII 232.
Run with Python 3 and NetworkX. Finite tests do not replace the proof.
"""
from functools import lru_cache
from itertools import combinations
import random
import networkx as nx


def tree_total_domination(g):
    root = next(iter(g))
    parent = {root: None}
    order = [root]
    for u in order:
        for v in g[u]:
            if v != parent[u]:
                parent[v] = u
                order.append(v)
    infinity = len(g) + 1
    table = {}
    for u in reversed(order):
        children = [v for v in g[u] if parent.get(v) == u]
        for selected in (0, 1):
            choices = [
                (table[v, 0, selected], table[v, 1, selected])
                for v in children
            ]
            base = selected + sum(min(pair) for pair in choices)
            table[u, selected, 1] = min(infinity, base)
            extra = min((yes - min(no, yes) for no, yes in choices),
                        default=infinity)
            table[u, selected, 0] = min(infinity, base + extra)
    return min(table[root, 0, 0], table[root, 1, 0])


def exact_total_domination(g):
    n = len(g)
    masks = [sum(1 << v for v in g[u]) for u in range(n)]

    @lru_cache(None)
    def cover(remaining):
        if not remaining:
            return 0
        vertices = [v for v in range(n) if remaining >> v & 1]
        u = min(vertices, key=lambda v: masks[v].bit_count())
        return 1 + min(cover(remaining & ~masks[v]) for v in g[u])

    return cover((1 << n) - 1)


def brute_total_domination(g):
    n = len(g)
    for size in range(2, n + 1):
        for subset in combinations(range(n), size):
            if set().union(*(set(g[v]) for v in subset)) == set(g):
                return size
    raise AssertionError("No total dominating set")


def verify(g, tree=False, brute=False):
    g = nx.convert_node_labels_to_integers(g)
    n = len(g)
    distance = dict(nx.all_pairs_shortest_path_length(g))
    eccentricity = {u: max(distance[u].values()) for u in g}
    radius = min(eccentricity.values())
    diameter = max(eccentricity.values())
    periphery = [u for u in g if eccentricity[u] == diameter]
    peripheral_ecc = max(min(distance[u][v] for v in periphery) for u in g)
    dispersion = max(
        (min(distance[x][y], distance[x][z], distance[y][z])
         for x, y, z in combinations(range(n), 3)), default=0
    )
    total_domination = (tree_total_domination(g) if tree
                        else exact_total_domination(g))
    if brute:
        assert total_domination == brute_total_domination(g)
    assert 2 * total_domination >= radius + dispersion
    assert 2 * total_domination >= radius + peripheral_ecc
    if tree:
        end = periphery[0]
        other = max(distance[end], key=distance[end].get)
        path = nx.shortest_path(g, end, other)
        height = max(min(distance[v][w] for w in path) for v in g)
        assert dispersion <= diameter // 2 + height
        assert diameter + height <= 2 * total_domination
    return total_domination, radius, dispersion


def main():
    tree_count = 0
    tree_sharp = 0
    for n in range(2, 17):
        level = 0
        for g in nx.nonisomorphic_trees(n):
            t, r, p = verify(g, tree=True, brute=n <= 9)
            tree_sharp += 2 * t == r + p
            tree_count += 1
            level += 1
        print(f"trees n={n}: {level}; cumulative={tree_count}", flush=True)

    atlas_count = 0
    graph_sharp = 0
    for g in nx.graph_atlas_g():
        if len(g) >= 2 and nx.is_connected(g):
            t, r, p = verify(g, brute=True)
            graph_sharp += 2 * t == r + p
            atlas_count += 1
    print(f"connected atlas orders2--7: {atlas_count}", flush=True)

    rng = random.Random(20261027)
    random_count = 10000
    for iteration in range(random_count):
        n = rng.randrange(8, 21)
        g = nx.random_labeled_tree(n, seed=rng)
        kind = rng.randrange(5)
        if kind == 0:
            probability = rng.uniform(.02, .8)
            for x, y in combinations(range(n), 2):
                if rng.random() < probability:
                    g.add_edge(x, y)
        elif kind == 1:
            g.add_edges_from((v, (v + 1) % n) for v in range(n))
        elif kind == 2:
            size = rng.randrange(3, min(n, 10))
            g.add_edges_from(combinations(range(size), 2))
        elif kind == 3:
            for _ in range(rng.randrange(1, 7)):
                x, y = rng.sample(range(n), 2)
                g.add_edge(x, y)
        t, r, p = verify(g)
        graph_sharp += 2 * t == r + p
        if (iteration + 1) % 1000 == 0:
            print(f"random/family {iteration + 1}", flush=True)
    print(f"PASS trees={tree_count}, atlas={atlas_count}, random={random_count}")
    print(f"Strong-bound equality cases: trees={tree_sharp}, other={graph_sharp}")


if __name__ == "__main__":
    main()
