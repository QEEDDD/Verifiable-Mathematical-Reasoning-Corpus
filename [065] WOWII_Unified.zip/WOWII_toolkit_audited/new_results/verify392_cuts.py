#!/usr/bin/env python3
"""Verify constructive proofs of WOWII 392b and 392d.

Dependency: NetworkX. Run: python verify392_cuts.py
Optional: python verify392_cuts.py --output results.json

The default run checks all 994 connected atlas graphs of orders 3--7,
using independent exhaustive 2-domination, and 172 structured graphs
of orders up to 200, using explicit dominating-set certificates.
Finite checks support the accompanying proofs; they do not replace them.
"""

import argparse
import itertools
import json
import random
import time
from collections import Counter
from pathlib import Path

import networkx as nx


def neighbors(graph, vertices):
    """Union of open neighborhoods; vertices may overlap the result."""
    return {w for v in vertices for w in graph[v]}


def matching_number(graph):
    return len(nx.max_weight_matching(graph, maxcardinality=True))


def cut_cover(graph, prescribed=None):
    """Extend fixed colors by local cut improvement; cover crossing edges."""
    colors = {} if prescribed is None else dict(prescribed)
    free = set(graph) - set(colors)
    colors.update({v: 0 for v in free})
    while True:
        changed = False
        for v in free:
            crossing = sum(colors[v] != colors[w] for w in graph[v])
            if 2 * crossing < graph.degree(v):
                colors[v] = 1 - colors[v]
                changed = True
        if not changed:
            break
    cut = nx.Graph()
    cut.add_nodes_from(graph)
    cut.add_edges_from(
        (u, v) for u, v in graph.edges() if colors[u] != colors[v]
    )
    top = {v for v in cut if colors[v] == 0}
    matching = nx.bipartite.maximum_matching(cut, top_nodes=top)
    cover = nx.bipartite.to_vertex_cover(cut, matching, top_nodes=top)
    assert len(cover) == len(matching) // 2
    return cut, cover


def parameters(graph):
    vertices = set(graph)
    degrees = dict(graph.degree())
    delta = min(degrees.values())
    minimum = {v for v in vertices if degrees[v] == delta}
    leaves = {v for v in vertices if degrees[v] == 1}
    degree_two = {v for v in vertices if degrees[v] == 2}
    return vertices, degrees, delta, minimum, leaves, degree_two


def certify(graph, selected, colors, bound):
    remaining = graph.subgraph(set(graph) - selected)
    cut, cover = cut_cover(remaining, colors)
    for v in remaining:
        count = len(set(graph[v]) & selected) + cut.degree(v)
        assert count >= 2, "Selected neighbors plus cut degree below two"
    result = selected | cover
    assert all(
        v in result or len(set(graph[v]) & result) >= 2 for v in graph
    ), "Constructed set is not 2-dominating"
    assert len(result) <= bound, "Original conjecture bound exceeded"
    return result


def construct_392b(graph):
    vertices, degrees, delta, minimum, leaves, d2 = parameters(graph)
    b1 = {v for v in vertices if len(set(graph[v]) & d2) == 1}
    selected = minimum if delta >= 2 else leaves | b1
    remaining = graph.subgraph(vertices - selected)
    colors = {}
    if delta == 1:
        induced = graph.subgraph(d2)
        isolated = {v for v in d2 if induced.degree(v) == 0}
        for component in nx.connected_components(induced):
            if len(component) == 1:
                continue
            assert nx.is_tree(induced.subgraph(component))
            internal = component - selected
            assert all(set(remaining[v]) <= internal for v in internal)
            colors.update(nx.bipartite.color(remaining.subgraph(internal)))
        opposite = neighbors(graph, isolated) - selected
        assert not opposite & d2
        colors.update({v: 0 for v in isolated})
        colors.update({v: 1 for v in opposite})
    bound = (
        matching_number(graph.subgraph(vertices - minimum))
        + len(minimum) + len(b1)
    )
    result = certify(graph, selected, colors, bound)
    assert len(result) <= len(selected) + matching_number(remaining)
    return result, bound


def construct_392d(graph):
    vertices, degrees, delta, minimum, leaves, d2 = parameters(graph)
    supports = neighbors(graph, leaves)
    outside = vertices - neighbors(graph, supports)
    selected = minimum
    colors = {}
    if delta == 1:
        induced = graph.subgraph(outside)
        nonisolated = {v for v in induced if induced.degree(v) > 0}
        _, small_dom = cut_cover(induced.subgraph(nonisolated))
        assert len(small_dom) <= matching_number(induced)
        assert all(
            v in small_dom or set(graph[v]) & small_dom
            for v in nonisolated
        )
        selected = leaves | supports | small_dom
        closed = selected | neighbors(graph, selected)
        uncovered = d2 - closed
        opposite = neighbors(graph, uncovered)
        assert uncovered <= outside
        assert all(not set(graph[v]) & outside for v in uncovered)
        assert all(set(graph[v]) & supports for v in opposite)
        colors.update({v: 0 for v in uncovered})
        colors.update({v: 1 for v in opposite - selected})
        assert not leaves & supports
        assert matching_number(graph) >= (
            len(supports)
            + matching_number(graph.subgraph(vertices - leaves - supports))
        )
    bound = (
        matching_number(graph) + matching_number(graph.subgraph(outside))
        + len(minimum)
    )
    return certify(graph, selected, colors, bound), bound


def exact_gamma_two(graph):
    """Independent exhaustive implementation; used only on atlas graphs."""
    vertices = tuple(graph)
    adjacency = {v: set(graph[v]) for v in vertices}
    for size in range(len(vertices) + 1):
        for choice in itertools.combinations(vertices, size):
            selected = set(choice)
            if all(
                v in selected or len(adjacency[v] & selected) >= 2
                for v in vertices
            ):
                return size
    raise AssertionError("The full vertex set must be 2-dominating")


def structured_graphs():
    """Fixed seed: subdivided cores with leaves, then trees plus edges."""
    rng = random.Random(392)
    for order in range(2, 10):
        for _ in range(10):
            core = nx.gnp_random_graph(
                order, rng.uniform(0.3, 0.9), seed=rng.randrange(10**9)
            )
            if not nx.is_connected(core):
                continue
            graph = nx.empty_graph(order)
            next_vertex = order
            for u, v in core.edges():
                path = [u]
                for _ in range(rng.randrange(6)):
                    path.append(next_vertex)
                    next_vertex += 1
                path.append(v)
                nx.add_path(graph, path)
            for _ in range(rng.randrange(1, 7)):
                graph.add_edge(rng.randrange(next_vertex), next_vertex)
                next_vertex += 1
            yield graph
    for order in [12, 20, 30, 40, 60, 100, 200]:
        for _ in range(15):
            graph = nx.random_labeled_tree(
                order, seed=rng.randrange(10**9)
            )
            for _ in range(order // 3):
                u, v = rng.sample(range(order), 2)
                graph.add_edge(u, v)
            yield graph


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="Also save JSON here")
    args = parser.parse_args()
    start = time.perf_counter()
    counts = Counter()
    histograms = {"392b": Counter(), "392d": Counter()}
    constructions = [("392b", construct_392b), ("392d", construct_392d)]
    for graph in nx.graph_atlas_g():
        if len(graph) < 3 or not nx.is_connected(graph):
            continue
        gamma = exact_gamma_two(graph)
        for name, construct in constructions:
            selected, bound = construct(graph)
            assert gamma <= len(selected) <= bound
            histograms[name][bound - gamma] += 1
        counts["atlas"] += 1
        counts["atlas_with_leaves"] += min(dict(graph.degree()).values()) == 1
    for graph in structured_graphs():
        assert nx.is_connected(graph)
        for _, construct in constructions:
            construct(graph)
        counts["structured"] += 1
        counts["largest_structured_order"] = max(
            counts["largest_structured_order"], len(graph)
        )
    assert counts["atlas"] == 994 and counts["structured"] == 172
    report = {
        "result": "PASS",
        "networkx_version": nx.__version__,
        "counts_per_conjecture": dict(counts),
        "atlas_rhs_minus_gamma2": histograms,
        "seconds": round(time.perf_counter() - start, 3),
    }
    output = json.dumps(report, indent=2) + "\n"
    print(output, end="")
    if args.output is not None:
        args.output.write_text(output, encoding="utf-8")


if __name__ == "__main__":
    main()
