"""Brute-force check of WOWII 434a on all small connected graphs.

Reading used (site-wide WOWII convention):
  M      = set of maximum-degree vertices of G
  SW(H)  = max over induced subgraphs of the minimum degree (= degeneracy)
  i(G)   = independent domination number
434a:  i(G) <= |M| + 2*floor(SW(G^c)/2)   for connected G with n > 3.

Also evaluates the alternative reading |P| (P = pendant vertices) in place of |M|.
"""
import itertools
import sys
import networkx as nx
from networkx.generators.atlas import graph_atlas_g


def invariants(G):
    n = G.number_of_nodes()
    Gc = nx.complement(G)
    cliques_c = list(nx.find_cliques(Gc))           # maximal cliques of G^c = maximal independent sets of G
    i_G = min(len(c) for c in cliques_c)
    alpha = max(len(c) for c in cliques_c)
    sw_c = max(nx.core_number(Gc).values()) if Gc.number_of_edges() else 0
    deg = dict(G.degree())
    Delta = max(deg.values())
    M = [v for v in G if deg[v] == Delta]
    P = [v for v in G if deg[v] == 1]
    return dict(n=n, i=i_G, alpha=alpha, sw=sw_c, M=len(M), P=len(P))


def bound_M(x):
    return x["M"] + 2 * (x["sw"] // 2)


def bound_P(x):
    return x["P"] + 2 * (x["sw"] // 2)


def graphs_up_to_7():
    for G in graph_atlas_g():
        if 4 <= G.number_of_nodes() <= 7 and nx.is_connected(G):
            yield G


def graphs_8():
    base = [G for G in graph_atlas_g() if G.number_of_nodes() == 7]
    for H in base:
        for r in range(0, 8):
            for S in itertools.combinations(range(7), r):
                G = H.copy()
                G.add_node(7)
                G.add_edges_from((7, s) for s in S)
                if nx.is_connected(G):
                    yield G


def run(gen, label):
    total = fails_M = fails_P = tight_M = 0
    narrow = 0  # graphs in the only potentially-failing case: |M|=1 and SW(G^c) odd
    first_P_fail = None
    for G in gen:
        x = invariants(G)
        total += 1
        # sanity: i <= alpha <= SW(G^c)+1 must always hold
        assert x["i"] <= x["alpha"] <= x["sw"] + 1, x
        if x["i"] > bound_M(x):
            fails_M += 1
            print("COUNTEREXAMPLE (M reading):", label, nx.to_graph6_bytes(G, header=False), x)
        if x["i"] == bound_M(x):
            tight_M += 1
        if x["M"] == 1 and x["sw"] % 2 == 1:
            narrow += 1
        if x["i"] > bound_P(x):
            fails_P += 1
            if first_P_fail is None:
                first_P_fail = (sorted(G.edges()), x)
    print(f"[{label}] graphs checked={total}  M-reading failures={fails_M}  "
          f"tight(M)={tight_M}  narrow-case graphs={narrow}  P-reading failures={fails_P}")
    if first_P_fail:
        print(f"   first P-reading failure: edges={first_P_fail[0]} inv={first_P_fail[1]}")


if __name__ == "__main__":
    run(graphs_up_to_7(), "n=4..7 (all connected, atlas)")
    K4 = nx.complete_graph(4)
    print("K4 invariants:", invariants(K4), "bound_M=", bound_M(invariants(K4)), "bound_P=", bound_P(invariants(K4)))
    if len(sys.argv) > 1 and sys.argv[1] == "8":
        run(graphs_8(), "n=8 (all connected, with duplicates)")
