"""CP-SAT search for counterexamples to WOWII 434a in the only case where it can fail.

Reduction (G connected, n>3, s = SW(G^c) = degeneracy of H = G^c):
  i(G) <= alpha(G) = omega(H) <= s + 1, and |M| >= 1.
  If s is even or |M| >= 2 the bound |M| + 2*floor(s/2) is >= s+1, so it holds.
  A counterexample therefore needs: s odd, |M| = 1, and i(G) = alpha(G) = s + 1.
In terms of H = G^c with k = s + 1 (even):
  (1) every maximal clique of H has exactly k vertices   [i(G) = alpha(G) = k]
  (2) H is (k-1)-degenerate                              [s = k-1]
  (3) H has a unique vertex of minimum degree            [|M(G)| = 1]
  (4) G = complement of H is connected.
(1) forces delta(H) >= k-1 and (2) forces delta(H) <= k-1, so the unique
min-degree vertex has degree k-1.  WLOG it is vertex 0 and vertices are
labelled in a degeneracy (elimination) order.
"""
import itertools
import sys
import time
import networkx as nx
from ortools.sat.python import cp_model


CONTROL = False   # positive control: let the last vertex also have degree k-1


def build(n, k):
    m = cp_model.CpModel()
    E = {}
    for i, j in itertools.combinations(range(n), 2):
        E[(i, j)] = m.NewBoolVar(f"e{i}_{j}")

    def e(a, b):
        return E[(a, b)] if a < b else E[(b, a)]

    # (2) elimination order: vertex i has at most k-1 neighbours of larger index
    for i in range(n):
        m.Add(sum(e(i, j) for j in range(i + 1, n)) <= k - 1)
    # (3) degree conditions
    deg = [sum(e(i, j) for j in range(n) if j != i) for i in range(n)]
    m.Add(deg[0] == k - 1)
    for i in range(1, n):
        m.Add(deg[i] >= (k - 1 if (CONTROL and i == n - 1) else k))
        m.Add(deg[i] <= n - 2)          # no dominating vertex in H (needed for G connected)
    # (1a) no K_{k+1}
    for S in itertools.combinations(range(n), k + 1):
        m.Add(sum(e(a, b) for a, b in itertools.combinations(S, 2)) <= (k + 1) * k // 2 - 1)
    # clique indicators for subsets of size 2..k
    C = {}
    for a, b in itertools.combinations(range(n), 2):
        C[(a, b)] = e(a, b)
    for size in range(3, k + 1):
        for S in itertools.combinations(range(n), size):
            v = m.NewBoolVar("c" + "_".join(map(str, S)))
            sub = S[:-1]
            last = S[-1]
            lits = [C[sub]] + [e(x, last) for x in sub]
            # v <-> AND(lits)
            for l in lits:
                m.AddImplication(v, l)
            m.AddBoolOr([v] + [l.Not() for l in lits])
            C[S] = v
    # (1b) every clique of size 2..k-1 extends to a larger clique
    for size in range(2, k):
        for S in itertools.combinations(range(n), size):
            ext = []
            for x in range(n):
                if x in S:
                    continue
                T = tuple(sorted(S + (x,)))
                ext.append(C[T])
            m.AddBoolOr([C[S].Not()] + ext)
    return m, E


def complement_connected(n, edges):
    H = nx.Graph()
    H.add_nodes_from(range(n))
    H.add_edges_from(edges)
    return nx.is_connected(nx.complement(H)), H


def verify_on_G(H):
    G = nx.complement(H)
    Gc = H
    cl = list(nx.find_cliques(Gc))
    i_G = min(map(len, cl)); alpha = max(map(len, cl))
    sw = max(nx.core_number(Gc).values())
    deg = dict(G.degree()); D = max(deg.values())
    M = sum(1 for v in G if deg[v] == D)
    return dict(i=i_G, alpha=alpha, sw=sw, M=M, bound=M + 2 * (sw // 2), connected=nx.is_connected(G))


def search(n, k, time_limit):
    m, E = build(n, k)
    found_disconnected = 0
    while True:
        solver = cp_model.CpSolver()
        solver.parameters.max_time_in_seconds = time_limit
        solver.parameters.num_workers = 8
        st = solver.Solve(m)
        name = solver.StatusName(st)
        if st not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
            return name, found_disconnected, None
        edges = [p for p, var in E.items() if solver.Value(var)]
        ok, H = complement_connected(n, edges)
        if ok:
            return "FOUND", found_disconnected, H
        found_disconnected += 1
        # forbid this exact edge set and continue
        m.AddBoolOr([E[p].Not() if solver.Value(E[p]) else E[p] for p in E])


if __name__ == "__main__":
    k = int(sys.argv[1]); n_lo = int(sys.argv[2]); n_hi = int(sys.argv[3])
    tl = float(sys.argv[4]) if len(sys.argv) > 4 else 600
    CONTROL = len(sys.argv) > 5 and sys.argv[5] == "control"
    for n in range(n_lo, n_hi + 1):
        t = time.time()
        status, disc, H = search(n, k, tl)
        print(f"k={k} n={n}: {status} (disconnected-complement solutions skipped: {disc}) "
              f"[{time.time()-t:.1f}s]", flush=True)
        if H is not None:
            print("   H edges:", sorted(H.edges()))
            print("   check on G:", verify_on_G(H), flush=True)
