"""CP-SAT sanity check of the general lemma used to settle WOWII 434a:

  If H is (k-1)-degenerate, every maximal clique of H has exactly k vertices,
  and H is not complete, then H has two NON-adjacent vertices of degree k-1.

We search for a counterexample: such an H in which all degree-(k-1) vertices
are pairwise adjacent.  Expect INFEASIBLE for every n.
"""
import itertools
import sys
import time
from ortools.sat.python import cp_model


def model(n, k):
    m = cp_model.CpModel()
    E = {p: m.NewBoolVar(f"e{p[0]}_{p[1]}") for p in itertools.combinations(range(n), 2)}
    e = lambda a, b: E[(a, b)] if a < b else E[(b, a)]
    for i in range(n):  # labelling = elimination order
        m.Add(sum(e(i, j) for j in range(i + 1, n)) <= k - 1)
    low = []
    for i in range(n):
        d = sum(e(i, j) for j in range(n) if j != i)
        li = m.NewBoolVar(f"low{i}")
        m.Add(d >= k - 1)
        m.Add(d <= k - 1).OnlyEnforceIf(li)
        m.Add(d >= k).OnlyEnforceIf(li.Not())
        low.append(li)
    for i, j in itertools.combinations(range(n), 2):
        m.AddBoolOr([low[i].Not(), low[j].Not(), e(i, j)])
    m.Add(sum(E.values()) <= n * (n - 1) // 2 - 1)      # not complete
    for S in itertools.combinations(range(n), k + 1):    # no K_{k+1}
        m.Add(sum(e(a, b) for a, b in itertools.combinations(S, 2)) <= (k + 1) * k // 2 - 1)
    C = {p: e(*p) for p in itertools.combinations(range(n), 2)}
    for size in range(3, k + 1):
        for S in itertools.combinations(range(n), size):
            v = m.NewBoolVar("")
            lits = [C[S[:-1]]] + [e(x, S[-1]) for x in S[:-1]]
            for l in lits:
                m.AddImplication(v, l)
            m.AddBoolOr([v] + [l.Not() for l in lits])
            C[S] = v
    for size in range(2, k):                             # every small clique extends
        for S in itertools.combinations(range(n), size):
            m.AddBoolOr([C[S].Not()] + [C[tuple(sorted(S + (x,)))] for x in range(n) if x not in S])
    return m


if __name__ == "__main__":
    k, lo, hi = map(int, sys.argv[1:4])
    for n in range(lo, hi + 1):
        t = time.time()
        s = cp_model.CpSolver(); s.parameters.num_workers = 8; s.parameters.max_time_in_seconds = 600
        st = s.Solve(model(n, k))
        print(f"lemma k={k} n={n}: {s.StatusName(st)} [{time.time()-t:.1f}s]", flush=True)
