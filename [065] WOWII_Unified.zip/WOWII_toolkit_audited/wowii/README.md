# WOWII toolkit — Written on the Wall II (Graffiti.pc) 추측 공략 도구

2026-10-26 세션에서 쓴 코드 전체입니다. 반례 탐색·검증, 증명의 수치 재검증, 보조정리 SAT 검사가 들어 있습니다.

## 방법론 (파이프라인)

1. **대상 선정.** WOWII 페이지를 파싱한 데이터(Kuberwastaken/c5-k4의 `wowii-conjectures.json`, 2026년 7월)에서 미해결 220개를 가져오고, 파서가 빠뜨린 136–138을 더했습니다. 이미 해결된 것(2026년 7–8월 페이지 갱신분, formal-conjectures에서 `solved`인 것, Zenodo·arXiv 논문)을 빼면 183개가 남습니다.
2. **정의 → 실행 코드.** DeLaViña의 정의(`wowIIdefs.js`, c5-k4 글로서리)를 따릅니다. 원문 표기가 애매하면 가능한 해석(reading)을 모두 코드로 만들었습니다(`conj.py`). 예를 들면 SW = degeneracy 또는 degeneracy+1, WP(Ḡ)의 여러 변형, dist_avg를 "집합으로부터의 거리"로 볼지 "집합 내 쌍 거리"로 볼지, 임계 독립집합에 공집합을 포함할지, girth(트리)를 ∞로 볼지 등입니다.
3. **경험적 데이터베이스 필터.** `make_gate.py`는 검사한 작은 그래프에서 한 번 이상 계산되었고 반례가 관측되지 않은 실행 해석만 `out/gate.json`에 남깁니다. 이는 탐색 순서를 정하는 경험적 필터이며 원문의 의도나 참·거짓을 판정하지 않습니다. 계산 제한으로 건너뛴 해석은 통과한 것으로 세지 않습니다. `out/corrupt.json`은 기록된 모든 실행 해석에 표본 반례가 있는 항목을 담는 기존 형식의 파일명이며, 원문 해석의 정확성은 별도로 확인해야 합니다.
4. **전수 탐색.** 9정점 이하 연결그래프 261,080개와 18정점 이하 트리 전부를 검사합니다. 그래프는 pynauty 정규형으로 중복을 제거해 만듭니다(`gen_db.py`, `runner.py`).
5. **큰 그래프.** 구조적·랜덤 패밀리 1.26만 개(최대 60정점: 클리크 blow-up, corona, spider, caterpillar, circulant, Kneser 등, `families.py`)를 검사합니다. 여기에 담금질(simulated annealing) 탐색(`localsearch.py`)을 더해 모든 해석의 slack 최댓값을 최소화합니다.
6. **정확 계산.**
   - `wcore.c`: 비트마스크 브루트포스. 24정점까지 α, γ, γ_t, γ₂, i, γ_c(→L_s), α_k, b, f, tree, path, 경로덮개 p, 해밀턴 경로, 임계 독립집합 H, 최소 전지배집합 등을 계산합니다.
   - `big.py`: 트리 선형 DP와 CP-SAT입니다. 큰 그래프의 γ 계열과 α₂를 계산합니다.
7. **교차 검증.**
   - `test_lib.py`: 느린 독립 구현과 랜덤 그래프 400개에서 값을 대조합니다.
   - `verify.py` / `check_cex.py`: 반례마다 기본 불변량을 독립 계산으로 다시 구하고, 모든 해석을 재평가합니다.
   - `wowii_counterexamples.py`: networkx와 CP-SAT만 쓰는 완전 독립 재현 스크립트입니다.
8. **증명.**
   - 434a/434b는 Lemma*(아래)로 축소해 증명했습니다. Lemma*는 `scripts/sat_lemma.py`(CP-SAT)로 k=2..5, n ≤ 12–16에서 반례가 없음을 확인했고, 434a의 남은 경우는 `scripts/sat434a.py`로 확인했습니다.
   - 서브에이전트 증명 23개는 각 에이전트가 수치 재검증 후 작성했지만 아직 사람이나 코디네이터가 검토하지 않았습니다. 증명이 성립하는지는 `verify_proved.py`로 수치로만 다시 확인할 수 있습니다. 검사 범위는 전수(n ≤ 8, 트리 ≤ 14)와 랜덤 그래프입니다.

Lemma*: H가 (k−1)-degenerate이고 모든 극대 클리크의 크기가 정확히 k이며 완전그래프가 아니면, 차수가 k−1인 서로 인접하지 않은 꼭짓점이 둘 있다. 증명은 `WOWII_proofs.md`에 있습니다.

## 실행

```bash
pip install networkx ortools pynauty
cd wowii
gcc -O2 -shared -fPIC -o libwcore.so wcore.c
python3 test_lib.py                      # 라이브러리 자기검증 (불일치 0이어야 함)
python3 gen_db.py 9                      # db/: n<=9 연결그래프, 트리 n<=18 (약 2분)

# 게이트 → 전수 탐색
python3 runner.py out/gate_run.json conn2,conn3,conn4,conn5,conn6,conn7,tree8,tree9,tree10
python3 make_gate.py out/gate_run.json out/gate.json out/corrupt.json
python3 runner.py out/main.json conn8,conn9,tree11,tree12,tree13,tree14,tree15,tree16 --gate out/gate.json

# 패밀리 + 담금질
python3 families.py db/fam.g6
python3 runner.py out/fam.json fam --gate out/gate.json --big --per-graph 40
python3 localsearch.py out/gate.json out/ls.jsonl 402,393d --auto --time 120

# 반례 확인 / 증명한 것 수치 재검증 / 보조정리 SAT 검사
python3 check_cex.py 402 'L{eC?KF@_K_o@`'
python3 verify_proved.py --nmax 8 --tmax 14 --random 3000
python3 ../scripts/sat_lemma.py 4 5 14
python3 ../scripts/sat434a.py 4 5 16
python3 ../wowii_counterexamples.py      # 독립 재현 스크립트
```

`out/gate.json`과 `out/corrupt.json`은 이번 세션에서 만든 것을 함께 넣었습니다(재생성도 됩니다). `db/`는 용량 때문에 빼고 `gen_db.py`로 다시 만들게 했습니다.

## 계산 범위와 누락 진단

수정된 `runner.py`는 해석별 `tested`, `fail`과 별도로 `skipped`,
`skip_reasons`, `skipped_examples`를 저장합니다. 추측 수준의 `skipped`는
계산하지 못한 해석 평가 횟수이며, 가정이나 해석 생성 단계의 실패도 포함합니다.
`robust`는 선택한 모든 실행 해석을 실제로 계산했고 모두 실패한 경우에만 기록합니다.
계산 제한, 누락된 해석, 거짓인 전제를 가진 함의가 있으면 전체 해석 반례로 기록하지
않습니다. 경험적 게이트를 사용한 경우 해당 범위가 `scope`에 명시됩니다.

예를 들어 패밀리에 `KG(7,3)`이 있어도 35정점의 `core` 계산은 기존
`indsets_info()`의 30정점 제한으로 건너뜁니다. 이 경우 108은 `tested=0`,
`skipped=1`로 보고되어야 하며, 작은 그래프 검사 통과를 이 그래프까지 확장하면
안 됩니다. 수학적 대칭성 증명으로 이 계산 제한을 우회할 수 있다는 사실과 별개로,
이 수정은 새로운 큰 그래프 최적화 알고리즘을 추가하지 않습니다.

`make_gate.py`, `merge.py`, `report.py`는 `_timeouts` 등 메타데이터를 추측으로
읽지 않으며, 집계와 보고 과정에서 누락 횟수를 보존합니다. 회귀 검사는
`python -m unittest test_runner_diagnostics -v`로 실행합니다.
`localsearch.py`와 `check_cex.py`도 선택한 해석 하나라도 계산하지 못하면
전체 선택 해석을 위반했다고 판정하지 않습니다. `collect.py`의 게이트 관련
출력은 `gate_sample_counterexamples`이며 원문 반박 판정과 구분됩니다.
기존 `out/` 결과는 과거 실행의 기록이며 이 수정으로 소급 검증되지는 않습니다.

## 파일

| 파일 | 내용 |
|---|---|
| `lib.py` | 그래프 클래스 `Gr`와 모든 불변량 |
| `wcore.c` | C 코어 (NP-hard 불변량 브루트포스) |
| `big.py` | 트리 DP, CP-SAT |
| `conj.py` | 183개 추측의 실행 가능한 해석 |
| `runner.py`, `make_gate.py`, `merge.py`, `report.py` | 스윕·게이트·집계 |
| `gen_db.py`, `families.py` | 그래프 DB 생성 |
| `localsearch.py` | 담금질 반례 탐색 |
| `verify.py`, `check_cex.py`, `test_lib.py` | 교차 검증 |
| `verify_proved.py` | 증명한 것의 수치 재검증 |
| `slack.py`, `collect.py` | slack·tight 통계, 결과 집계 |
| `../scripts/sat_lemma.py`, `../scripts/sat434a.py`, `../scripts/check434a_small.py` | 434a·Lemma* 관련 검사 |
| `../wowii_counterexamples.py` | 반례 15개 독립 재현 |
