"""Exact invariants for larger graphs: linear-time tree DPs and CP-SAT models.

Hooked into lib.Gr through install(): for trees any size uses DP; for other graphs with n > BIGN
CP-SAT replaces the brute-force C core for gamma, gamma_t, gamma_2, i, alpha_k.
"""
import sys

from ortools.sat.python import cp_model

import lib
from lib import Gr, Undefined, bits, pc

BIGN = 22
INF = 10 ** 9


# ---------------------------------------------------------------- tree DPs
def _rooted(G, S=None):
    S = G.full if S is None else S
    order, parent = [], {}
    seen = 0
    roots = []
    for r in bits(S):
        if seen >> r & 1:
            continue
        roots.append(r)
        parent[r] = -1
        stack = [r]
        seen |= 1 << r
        while stack:
            v = stack.pop()
            order.append(v)
            for w in bits(G.adj[v] & S & ~seen):
                seen |= 1 << w
                parent[w] = v
                stack.append(w)
    children = {v: [] for v in order}
    for v in order:
        if parent[v] >= 0:
            children[parent[v]].append(v)
    return order, parent, children, roots


def tree_gamma_t(G):
    order, parent, ch, roots = _rooted(G)
    A, B, Cc, E = {}, {}, {}, {}   # A: in D & dominated by child; B: in D, not; C: out, dominated by child; E: out, not
    for v in reversed(order):
        cs = ch[v]
        # v in D
        sum_any = sum(min(A[u], B[u], Cc[u], E[u]) for u in cs)
        sum_out = sum(min(Cc[u], E[u]) for u in cs)
        B[v] = 1 + sum_out
        if cs:
            A[v] = 1 + sum_any + min(min(A[u], B[u]) - min(A[u], B[u], Cc[u], E[u]) for u in cs)
        else:
            A[v] = INF
        # v not in D: children must be dominated without v: states A or C
        sumAC = sum(min(A[u], Cc[u]) for u in cs)
        E[v] = sum(Cc[u] for u in cs) if cs else 0
        Cc[v] = sumAC + min(A[u] - min(A[u], Cc[u]) for u in cs) if cs else INF
        for d in (A, B, Cc, E):
            if d[v] > INF:
                d[v] = INF
    tot = 0
    for r in roots:
        val = min(A[r], Cc[r])
        if val >= INF:
            raise Undefined("isolated vertex")
        tot += val
    return tot


def tree_gamma(G):
    order, parent, ch, roots = _rooted(G)
    IN, DOM, ND = {}, {}, {}   # in D; out & dominated by child; out & not dominated
    for v in reversed(order):
        cs = ch[v]
        IN[v] = 1 + sum(min(IN[u], DOM[u], ND[u]) for u in cs)
        ND[v] = sum(DOM[u] for u in cs)
        if cs:
            base = sum(min(IN[u], DOM[u]) for u in cs)
            DOM[v] = base + min(IN[u] - min(IN[u], DOM[u]) for u in cs)
        else:
            DOM[v] = INF
        DOM[v] = min(DOM[v], INF)
    return sum(min(IN[r], DOM[r]) for r in roots)


def tree_gamma_2(G):
    """2-domination: v in D or >=2 neighbours in D."""
    order, parent, ch, roots = _rooted(G)
    # states: IN; OUT_c (c = number of children in D: 0,1,2+) ; OUT with c needs parent contribution
    IN, O0, O1, O2 = {}, {}, {}, {}
    for v in reversed(order):
        cs = ch[v]
        # v in D: child u may be IN, O1 (gets 2nd from v), O2; O0 needs 2 from parent+? only 1 -> not allowed
        IN[v] = 1 + sum(min(IN[u], O1[u], O2[u]) for u in cs)
        # v out: child u must be IN or O2 (u gets nothing from v)
        # count children in D (IN) : track 0,1,2+
        best = [0, INF, INF]
        for u in cs:
            a_in, a_out = IN[u], O2[u]
            nb = [INF, INF, INF]
            for c in range(3):
                if best[c] >= INF:
                    continue
                nb[c] = min(nb[c], best[c] + a_out)
                c2 = min(c + 1, 2)
                nb[c2] = min(nb[c2], best[c] + a_in)
            best = [min(x, INF) for x in nb]
        O0[v], O1[v], O2[v] = best
    return sum(min(IN[r], O2[r]) for r in roots)


def tree_alpha(G):
    order, parent, ch, roots = _rooted(G)
    a, b = {}, {}   # a: v in set, b: v not
    for v in reversed(order):
        a[v] = 1 + sum(b[u] for u in ch[v])
        b[v] = sum(max(a[u], b[u]) for u in ch[v])
    return sum(max(a[r], b[r]) for r in roots)


def tree_indep_dom(G):
    order, parent, ch, roots = _rooted(G)
    IN, DOM, ND = {}, {}, {}   # IN: v in S; DOM: v out dominated by child in S; ND: v out, needs parent in S
    for v in reversed(order):
        cs = ch[v]
        IN[v] = 1 + sum(min(DOM[u], ND[u]) for u in cs)
        ND[v] = sum(DOM[u] for u in cs)
        if cs:
            base = sum(min(IN[u], DOM[u]) for u in cs)
            DOM[v] = base + min(IN[u] - min(IN[u], DOM[u]) for u in cs)
        else:
            DOM[v] = INF
        DOM[v] = min(DOM[v], INF)
    return sum(min(IN[r], DOM[r]) for r in roots)


# ---------------------------------------------------------------- CP-SAT
def _solve(model, obj, maximize=False, time_limit=20):
    if maximize:
        model.Maximize(obj)
    else:
        model.Minimize(obj)
    s = cp_model.CpSolver()
    s.parameters.max_time_in_seconds = time_limit
    s.parameters.num_workers = 2
    st = s.Solve(model)
    if st != cp_model.OPTIMAL:
        raise Undefined(f"cp-sat not optimal: {s.StatusName(st)}")
    return int(round(s.ObjectiveValue()))


def cp_domination(G, S, kind):
    vs = list(bits(S))
    m = cp_model.CpModel()
    x = {v: m.NewBoolVar("") for v in vs}
    for v in vs:
        nb = [x[w] for w in bits(G.adj[v] & S)]
        if kind == "dom":
            m.AddBoolOr([x[v]] + nb)
        elif kind == "tdom":
            if not nb:
                raise Undefined("isolated")
            m.AddBoolOr(nb)
        elif kind == "dom2":
            m.Add(2 * x[v] + sum(nb) >= 2)
        elif kind == "idom":
            m.AddBoolOr([x[v]] + nb)
            for w in nb:
                m.AddBoolOr([x[v].Not(), w.Not()])
    return _solve(m, sum(x.values()))


def cp_alpha_k(G, S, k):
    vs = list(bits(S))
    m = cp_model.CpModel()
    x = {v: m.NewBoolVar("") for v in vs}
    big = len(vs)
    for v in vs:
        nb = [x[w] for w in bits(G.adj[v] & S)]
        if nb:
            m.Add(sum(nb) <= k - 1 + big * (1 - x[v]))
    return _solve(m, sum(x.values()), maximize=True)


# ---------------------------------------------------------------- install hooks
def install():
    orig = {name: getattr(Gr, name) for name in ["gamma_of", "gamma_t_of", "gamma_2_of", "i_of", "alpha_k_of", "alpha_of"]}

    def is_tree_set(G, S):
        return S == G.full and G.m == G.n - 1 and G.connected()

    def gamma_of(self, S):
        if is_tree_set(self, S) and self.n > 12:
            return self.memo(("gam", S), lambda: tree_gamma(self))
        if pc(S) > BIGN:
            return self.memo(("gam", S), lambda: cp_domination(self, S, "dom"))
        return orig["gamma_of"](self, S)

    def gamma_t_of(self, S):
        if is_tree_set(self, S) and self.n > 12:
            return self.memo(("gamt", S), lambda: tree_gamma_t(self))
        if pc(S) > BIGN:
            return self.memo(("gamt", S), lambda: cp_domination(self, S, "tdom"))
        return orig["gamma_t_of"](self, S)

    def gamma_2_of(self, S):
        if is_tree_set(self, S) and self.n > 12:
            return self.memo(("gam2", S), lambda: tree_gamma_2(self))
        if pc(S) > BIGN:
            return self.memo(("gam2", S), lambda: cp_domination(self, S, "dom2"))
        return orig["gamma_2_of"](self, S)

    def i_of(self, S):
        if is_tree_set(self, S) and self.n > 12:
            return self.memo(("idom", S), lambda: tree_indep_dom(self))
        if pc(S) > BIGN:
            return self.memo(("idom", S), lambda: cp_domination(self, S, "idom"))
        return orig["i_of"](self, S)

    def alpha_k_of(self, S, k):
        if pc(S) > BIGN:
            return self.memo(("alk", S, k), lambda: cp_alpha_k(self, S, k))
        return orig["alpha_k_of"](self, S, k)

    def alpha_of(self, S):
        if is_tree_set(self, S) and self.n > 12:
            return self.memo(("alpha", S), lambda: tree_alpha(self))
        return orig["alpha_of"](self, S)

    Gr.gamma_of, Gr.gamma_t_of, Gr.gamma_2_of, Gr.i_of, Gr.alpha_k_of, Gr.alpha_of = \
        gamma_of, gamma_t_of, gamma_2_of, i_of, alpha_k_of, alpha_of


if __name__ == "__main__":
    # self-test: tree DPs vs brute force; CP-SAT vs brute force
    import random
    import networkx as nx
    random.seed(7)
    bad = 0
    for t in range(400):
        n = random.randint(2, 16)
        T = nx.random_labeled_tree(n, seed=t)
        G = Gr.from_nx(T)
        ref = dict(gt=lib._lib.w_gamma_t(G._carr, G.full), g=lib._lib.w_gamma(G._carr, G.full),
                   g2=lib._lib.w_gamma_2(G._carr, G.full), a=lib._lib.w_alpha(G._carr, G.full),
                   i=lib._lib.w_indep_dom(G._carr, G.full))
        got = dict(gt=tree_gamma_t(G), g=tree_gamma(G), g2=tree_gamma_2(G), a=tree_alpha(G), i=tree_indep_dom(G))
        if ref != got:
            bad += 1
            print("tree mismatch", nx.to_graph6_bytes(T, header=False), ref, got)
    for t in range(60):
        n = random.randint(4, 14)
        g = nx.gnp_random_graph(n, random.uniform(0.2, 0.7), seed=t)
        if not nx.is_connected(g):
            continue
        G = Gr.from_nx(g)
        ref = dict(g=lib._lib.w_gamma(G._carr, G.full), gt=lib._lib.w_gamma_t(G._carr, G.full),
                   g2=lib._lib.w_gamma_2(G._carr, G.full), i=lib._lib.w_indep_dom(G._carr, G.full),
                   a2=lib._lib.w_alpha_k(G._carr, G.full, 2))
        got = dict(g=cp_domination(G, G.full, "dom"), gt=cp_domination(G, G.full, "tdom"),
                   g2=cp_domination(G, G.full, "dom2"), i=cp_domination(G, G.full, "idom"),
                   a2=cp_alpha_k(G, G.full, 2))
        if ref != got:
            bad += 1
            print("cpsat mismatch", ref, got)
    print("mismatches:", bad)
