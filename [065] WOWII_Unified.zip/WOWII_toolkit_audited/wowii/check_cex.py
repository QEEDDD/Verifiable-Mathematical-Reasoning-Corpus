"""Check a claimed counterexample: evaluate every reading of the conjecture (all, and gate-surviving),
and cross-check base invariants with the independent implementation in verify.py.

usage: python3 check_cex.py CID G6 [CID G6 ...]
"""
import json
import os
import sys

import networkx as nx

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lib import Gr, Undefined  # noqa: E402
import big  # noqa: E402
import conj as C  # noqa: E402
import verify  # noqa: E402

big.install()
with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "out/gate.json")) as stream:
    GATE = json.load(stream)


def evaluate(cid, s):
    G = Gr.from_g6(s)
    g = nx.from_graph6_bytes(s.encode())
    out = {"cid": cid, "g6": s, "n": G.n, "m": G.m, "connected": nx.is_connected(g),
           "is_tree": nx.is_tree(g), "hyp": None, "readings": []}
    try:
        out["hyp"] = bool(C.HYP[cid](G))
    except Undefined:
        out["hyp"] = "undefined"
    if C.DOMAIN[cid] == "tree" and not out["is_tree"]:
        out["hyp"] = False
    for kind, label, a, b in C.CONJ[cid](G):
        rec = {"label": label, "gate_survivor": label in GATE.get(cid, [])}
        try:
            if kind == "imp":
                p = a(); rec["premise"] = bool(p)
                if p:
                    q = b(); rec["conclusion"] = bool(q); rec["violated"] = not q
                else:
                    rec["violated"] = False
            else:
                rhs, lhs = b(), a()
                rec["lhs"], rec["rhs"] = str(lhs), str(rhs)
                rec["violated"] = not ((lhs <= rhs) if kind == "le" else (lhs >= rhs))
        except (Undefined, ZeroDivisionError) as e:
            rec["undefined"] = str(e)
        out["readings"].append(rec)
    candidates = set(GATE.get(cid, []))
    surv = [r for r in out["readings"] if r["gate_survivor"]]
    covered = {r["label"] for r in surv if "undefined" not in r}
    out["gate_scope"] = "empirical gate-selected executable readings"
    out["unevaluated_survivors"] = sorted(candidates - covered)
    eligible = out["hyp"] is True and out["connected"]
    out["violates_all_survivors"] = (eligible and bool(candidates) and covered == candidates
                                     and all(r.get("violated", False) for r in surv))
    out["violates_some_survivor"] = eligible and any(r.get("violated", False) for r in surv)
    if G.n <= 40:
        a_, b_ = verify.slow(g), verify.fast(G)
        out["independent_mismatch"] = {k: (a_[k], b_.get(k)) for k in a_ if a_[k] is not None and k in b_ and a_[k] != b_[k]}
    return out


if __name__ == "__main__":
    args = sys.argv[1:]
    for i in range(0, len(args), 2):
        r = evaluate(args[i], args[i + 1])
        print(json.dumps(r, ensure_ascii=False))
