"""Collect all evidence into one status table: sweeps (main, fam), local search, agents, claims, central results."""
import glob
import json
import os
import sys

W = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.join(os.path.dirname(W), "work")
sys.path.insert(0, W)
import conj as C  # noqa: E402


def load_json(p, default):
    try:
        return json.load(open(p))
    except Exception:
        return default


def load_jsonl(pattern):
    out = []
    for p in sorted(glob.glob(pattern)):
        for line in open(p):
            line = line.strip()
            if not line:
                continue
            try:
                d = json.loads(line)
                d["_file"] = os.path.basename(p)
                out.append(d)
            except Exception:
                pass
    return out


def main():
    gate = load_json(os.path.join(W, "out/gate.json"), {})
    corrupt = load_json(os.path.join(W, "out/corrupt.json"), {})
    sweeps = {}
    for name in ["main.json", "fam.json"]:
        s = load_json(os.path.join(W, "out", name), {})
        for c, v in s.items():
            if c.startswith("_") or not isinstance(v, dict):
                continue
            d = sweeps.setdefault(c, {"robust": [], "partial": {}})
            d["robust"] += v.get("robust", [])
            for k, r in v.get("readings", {}).items():
                if r["fail"] and k in gate.get(c, []):
                    d["partial"].setdefault(k, r["examples"][:1])
    ls = {}
    for d in load_jsonl(os.path.join(W, "out/ls_*.jsonl")):
        if d.get("best") is not None:
            from fractions import Fraction as Fr
            if d["cid"] not in ls or Fr(d["best"]) < Fr(ls[d["cid"]]["best"]):
                ls[d["cid"]] = d
    agents = {}
    for d in load_jsonl(os.path.join(WORK, "agent_*.jsonl")):
        agents.setdefault(str(d.get("id")), []).append(d)
    claims = {}
    for d in load_jsonl(os.path.join(WORK, "claims.jsonl")):
        claims.setdefault(str(d.get("id")), []).append(d)
    central = {"434a": "proved", "434b": "proved", "434c": "false-as-written(P4)/trivial-otherwise", "378": "refuted"}
    rows = []
    for cid in C.CONJ:
        r = {"id": cid, "domain": C.DOMAIN[cid]}
        if cid in central:
            r["central"] = central[cid]
        if cid in corrupt:
            r["gate_sample_counterexamples"] = {k: v["g6"] for k, v in corrupt[cid].items()}
            r["gate_scope"] = "empirical executable readings; source meaning requires separate audit"
        sw = sweeps.get(cid)
        if sw and sw["robust"]:
            r["robust_cex"] = [(e["g6"], e["n"]) for e in sw["robust"][:2]]
        if sw and sw["partial"]:
            r["partial_cex"] = {k: (v[0]["g6"], v[0]["n"]) for k, v in sw["partial"].items() if v}
        if cid in ls:
            r["ls_best"] = (ls[cid]["best"], ls[cid].get("n"), ls[cid].get("g6"))
        if cid in agents:
            r["agents"] = [(a.get("verdict"), a.get("confidence"), a["_file"]) for a in agents[cid]]
        if cid in claims:
            r["claims"] = [(c.get("type"), c.get("who"), c.get("url")) for c in claims[cid]]
        rows.append(r)
    with open(os.path.join(WORK, "status.json"), "w") as stream:
        json.dump(rows, stream, indent=1)
    for r in rows:
        print(json.dumps(r, ensure_ascii=False)[:400])


if __name__ == "__main__":
    main()
