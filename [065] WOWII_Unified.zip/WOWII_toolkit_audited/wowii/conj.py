"""Executable readings of the open WOWII conjectures.

Each conjecture function takes a Gr and yields readings:
  ("le", label, lhs, rhs)       claim lhs <= rhs
  ("ge", label, lhs, rhs)       claim lhs >= rhs
  ("imp", label, premise, concl) claim premise => concl
lhs/rhs/premise/concl are zero-argument callables (lazy).  Undefined -> reading skipped.
HYP[cid] = hypothesis predicate on G (beyond connectedness), DOMAIN[cid] = 'conn' or 'tree'.
"""
import math
from fractions import Fraction as Fr

from lib import Undefined, bits, pc

CONJ, HYP, DOMAIN = {}, {}, {}


def conj(cid, hyp=None, domain="conn"):
    def deco(fn):
        CONJ[cid] = fn
        HYP[cid] = hyp or (lambda G: True)
        DOMAIN[cid] = domain
        return fn
    return deco


def floor(x):
    return math.floor(x)


def ceil(x):
    return math.ceil(x)


def ceil_sqrt(x):  # ceil(sqrt(x)) for integer x >= 0
    x = int(x)
    if x <= 0:
        return 0
    r = math.isqrt(x)
    return r if r * r == x else r + 1


class Sq:
    """exact value sqrt(q) for rational q >= 0 supporting comparison with rationals and addition of rationals."""
    __slots__ = ("a", "q")

    def __init__(self, q, a=0):
        self.q, self.a = Fr(q), Fr(a)   # value = a + sqrt(q)

    def __add__(self, o):
        return Sq(self.q, self.a + Fr(o))
    __radd__ = __add__

    def _cmp(self, x):  # sign of (a + sqrt(q)) - x
        d = Fr(x) - self.a   # compare sqrt(q) with d
        if d < 0:
            return 1
        s = self.q - d * d
        return (s > 0) - (s < 0)

    def __le__(self, x): return self._cmp(x) <= 0
    def __ge__(self, x): return self._cmp(x) >= 0
    def __lt__(self, x): return self._cmp(x) < 0
    def __gt__(self, x): return self._cmp(x) > 0
    def __float__(self): return float(self.a) + math.sqrt(self.q)
    def __repr__(self): return f"{self.a}+sqrt({self.q})" if self.a else f"sqrt({self.q})"


def safe_div(a, b):
    if b == 0:
        raise Undefined("division by zero")
    return Fr(a) / Fr(b)


# ---------------- helpers ----------------
def n_gt(k):
    return lambda G: G.n > k


def D2(G):
    return G.deg_set(lambda d: d == 2)


def Le2(G):
    return G.deg_set(lambda d: d <= 2)


def Ge3(G):
    return G.deg_set(lambda d: d >= 3)


def comps(G, S):
    return G.ncomp(S)


def lam_max(G):
    return max(G.lams)


def lam_min(G):
    return min(G.lams)


def lam_avg(G):
    return Fr(sum(G.lams), G.n)


def freq(vals, x):
    return sum(1 for v in vals if v == x)


def edge_nbhd_sizes(G, closed=True):
    s = [G.Ne(u, v, closed) for u, v in G.edge_list()]
    if not s:
        raise Undefined("no edges")
    return s


def radial_orders(G):
    return [pc(G.radial(v)) for v in bits(G.C)]


def Delta_set(G, S, in_graph=None):
    """max degree (in G) among vertices of S."""
    H = in_graph or G
    if not S:
        raise Undefined("empty set")
    return max(H.degs[v] for v in bits(S))


def Delta_ind(G, S):  # max degree of the induced subgraph G[S]; empty -> 0
    return max(G.induced_degs(S), default=0)


def delta_ind(G, S):
    d = G.induced_degs(S)
    if not d:
        raise Undefined("empty")
    return min(d)


def T_min_set(G):
    t = G.tris
    mn = min(t)
    return G.setof(lambda v: t[v] == mn)


def maxlam_set(G):
    l = G.lams
    mx = max(l)
    return G.setof(lambda v: l[v] == mx)


def minlam_set(G):
    l = G.lams
    mn = min(l)
    return G.setof(lambda v: l[v] == mn)


def modemin_set(G):
    mm = G.mode_min
    return G.deg_set(lambda d: d == mm)


def q1_readings(G):
    s, n = G.sorted_degs, G.n
    out = {}
    out["ceil"] = s[max(1, math.ceil(n / 4)) - 1]
    out["floor"] = s[max(1, n // 4) - 1]
    return out


def L_readings(G):
    """readings of the undefined symbol L(G) in 258-261."""
    return {"Ls": G.Ls, "length": G.length, "leaves": G.f1}


# ======================= forest / tree / bipartite / alpha =======================
@conj("19")
def c19(G):
    yield ("ge", "b>=floor(ecc_avg+lam_max)", lambda: G.b, lambda: floor(G.ecc_avg + lam_max(G)))


@conj("40", n_gt(1))
def c40(G):
    yield ("ge", "f>=ceil((p+b+1)/2)", lambda: G.f, lambda: ceil(Fr(G.p + G.b + 1, 2)))


@conj("61")
def c61(G):
    yield ("ge", "f>=res+ceil(diam/3)", lambda: G.f, lambda: G.residue + ceil(Fr(G.diam, 3)))


@conj("66")
def c66(G):
    yield ("ge", "f>=2ceil(evenmodemin(bar)/degavg)", lambda: G.f,
           lambda: 2 * ceil(safe_div(G.comp.even_mode_min, G.deg_avg)))


@conj("72")
def c72(G):
    yield ("ge", "tree>=ceil(ecc_avg+lam_max/3)", lambda: G.tree_num, lambda: ceil(G.ecc_avg + Fr(lam_max(G), 3)))
    yield ("ge", "tree>=ceil((ecc_avg+lam_max)/3)", lambda: G.tree_num, lambda: ceil((G.ecc_avg + lam_max(G)) / 3))


@conj("76")
def c76(G):
    def rhs():
        t = G.tris
        return safe_div(freq(t, max(t)), floor(G.deg_avg))
    yield ("ge", "tree>=freq(Tmax)/floor(degavg)", lambda: G.tree_num, rhs)


@conj("84")
def c84(G):
    yield ("ge", "tree>=2rad/delta", lambda: G.tree_num, lambda: safe_div(2 * G.rad, G.delta))


@conj("96")
def c96(G):
    yield ("le", "alpha<=1+min_de*(lam_max-1)", lambda: G.alpha, lambda: 1 + min(G.dist_evens) * (lam_max(G) - 1))


@conj("108")
def c108(G):
    yield ("le", "alpha<=max_de+2floor(core/3)", lambda: G.alpha,
           lambda: max(G.dist_evens) + 2 * (pc(G.core) // 3))


@conj("111")
def c111(G):
    def rhs():
        Hc = G.comp
        S = Hc.M
        NS = Hc.N(S)
        return ceil(1 + pc(NS) * (lam_avg(G) - 1))
    yield ("le", "alpha<=ceil(1+|N_c(M_c)|(lam_avg-1))", lambda: G.alpha, rhs)


@conj("133")
def c133(G):
    def rhs():
        return G.rad + (lam_avg(G) if G.c4free else 1)
    yield ("ge", "path>=rad+lam_avg^chiC4", lambda: G.path_num, rhs)


# ======================= L_s =======================
@conj("154", n_gt(1))
def c154(G):
    def rhs():
        o = radial_orders(G)
        return Fr(1 + max(o), min(o))
    yield ("ge", "Ls>=(1+max|R|)/min|R|", lambda: G.Ls, rhs)


@conj("155", n_gt(1))
def c155(G):
    yield ("ge", "Ls>=1+#distinct|R|", lambda: G.Ls, lambda: 1 + len(set(radial_orders(G))))


@conj("157", n_gt(1))
def c157(G):
    def rhs():
        mx = max(G.edges_in(G.radial(v)) for v in bits(G.C))
        return Sq(2 * mx, G.f1)
    yield ("ge", "Ls>=f1+sqrt(2max|E(R)|)", lambda: G.Ls, rhs)


@conj("161", n_gt(1))
def c161(G):
    yield ("ge", "Ls>=lam_max(bar)", lambda: G.Ls, lambda: max(G.comp.lams))


@conj("162", n_gt(1))
def c162(G):
    yield ("ge", "Ls>=freq(lam_min)*floor(1/delta)", lambda: G.Ls,
           lambda: freq(G.lams, lam_min(G)) * floor(safe_div(1, G.delta)))


@conj("165", n_gt(1))
def c165(G):
    yield ("ge", "Ls>=ceil sqrt(2|N(M)-M|)", lambda: G.Ls, lambda: ceil_sqrt(2 * pc(G.N(G.M) & ~G.M)))


@conj("166", n_gt(1))
def c166(G):
    # Ls >= a/sqrt(r)  <=>  Ls^2 * r >= a^2
    def chk():
        a = pc(G.N(G.M) & ~G.M)
        return G.Ls ** 2 * G.rad >= a * a
    yield ("imp", "Ls>=|N(M)-M|/sqrt(rad)", lambda: True, chk)


@conj("169", n_gt(1))
def c169(G):
    yield ("ge", "Ls>=1+maxde-minde", lambda: G.Ls, lambda: 1 + max(G.dist_evens) - min(G.dist_evens))


@conj("171", n_gt(1))
def c171(G):
    yield ("ge", "Ls>=(maxde-1)/distavg(B)", lambda: G.Ls,
           lambda: safe_div(max(G.dist_evens) - 1, G.dist_avg_between(G.B)))


# ======================= L_s + b =======================
def Lb(G):
    return G.Ls + G.b


@conj("177", n_gt(1))
def c177(G):
    yield ("ge", "Ls+b>=2alpha+sigma", lambda: Lb(G), lambda: 2 * G.alpha + G.sigma)


@conj("179", n_gt(1))
def c179(G):
    yield ("ge", "Ls+b>=Delta+gamma+lam_max", lambda: Lb(G), lambda: G.Delta + G.gamma + lam_max(G))


@conj("180", n_gt(1))
def c180(G):
    yield ("ge", "Ls+b>=1+alpha+maxde", lambda: Lb(G), lambda: 1 + G.alpha + max(G.dist_evens))


@conj("182", n_gt(1))
def c182(G):
    S = G.sq
    yield ("ge", "Ls+b>=Delta_{G2}(B(G2))+diam", lambda: Lb(G), lambda: Delta_set(S, S.B) + G.diam)
    yield ("ge", "Ls+b>=Delta_G(B(G2))+diam", lambda: Lb(G), lambda: Delta_set(G, S.B) + G.diam)


@conj("183", n_gt(1))
def c183(G):
    S = G.sq
    yield ("ge", "Ls+b>=Delta(G2)+2rad(G2)", lambda: Lb(G), lambda: S.Delta + 2 * S.rad)


@conj("184", n_gt(1))
def c184(G):
    S = G.sq
    yield ("ge", "Ls+b>=Delta(G2)+2distavg_pairs(B(G2),V)", lambda: Lb(G), lambda: S.Delta + 2 * S.dist_avg_pairs(S.B))
    yield ("ge", "Ls+b>=Delta(G2)+2distavg_from(B(G2))", lambda: Lb(G), lambda: S.Delta + 2 * S.dist_avg_from(S.B))


@conj("185", n_gt(1))
def c185(G):
    S = G.sq
    yield ("ge", "Ls+b>=Delta(G2)+2distavg(G2)", lambda: Lb(G), lambda: S.Delta + 2 * S.dist_avg_graph)


@conj("186", n_gt(1))
def c186(G):
    S = G.sq
    yield ("ge", "Ls+b>=|N_{G2}(C2)|+2ecc_{G2}(C2)", lambda: Lb(G), lambda: pc(S.N(S.C)) + 2 * S.ecc_set(S.C))
    yield ("ge", "Ls+b>=|N_G(C2)|+2ecc_{G2}(C2)", lambda: Lb(G), lambda: pc(G.N(S.C)) + 2 * S.ecc_set(S.C))


# ======================= traceability =======================
@conj("189", n_gt(1))
def c189(G):
    yield ("imp", "maxde<=1+sigma => traceable", lambda: max(G.dist_evens) <= 1 + G.sigma, lambda: G.traceable)


@conj("190", n_gt(1))
def c190(G):
    yield ("imp", "(Ls+1)/2<=sigma => traceable", lambda: Fr(G.Ls + 1, 2) <= G.sigma, lambda: G.traceable)


@conj("199", n_gt(1))
def c199(G):
    yield ("imp", "tree-2<=kappa => traceable", lambda: G.tree_num - 2 <= G.kappa, lambda: G.traceable)


@conj("213", n_gt(1))
def c213(G):
    yield ("imp", "2+lowmed(bar)<=gamma2(bar) => traceable",
           lambda: 2 + G.comp.median_lower() <= G.comp.gamma_2, lambda: G.traceable)


# ======================= total domination lower bounds =======================
@conj("232")
def c232(G):
    yield ("ge", "gt>=(rad+ecc(B))/2", lambda: G.gamma_t, lambda: Fr(G.rad + G.ecc_set(G.B), 2))


@conj("233")
def c233(G):
    yield ("ge", "gt>=2/3(1+ecc(B))", lambda: G.gamma_t, lambda: Fr(2, 3) * (1 + G.ecc_set(G.B)))


@conj("235")
def c235(G):
    yield ("ge", "gt>=2/3ecc(B)+chibip", lambda: G.gamma_t, lambda: Fr(2, 3) * G.ecc_set(G.B) + G.bipartite)


@conj("241", domain="tree")
def c241(G):
    def da():
        try:
            return G.dist_avg_between(G.C)
        except Undefined:
            return 0
    yield ("ge", "gt>=floor(c(N[D2])+distavgC)", lambda: G.gamma_t, lambda: floor(comps(G, G.NN(D2(G))) + da()))


@conj("242", domain="tree")
def c242(G):
    yield ("ge", "gt>=(c(N[D2])+ecc_avg)/2", lambda: G.gamma_t, lambda: Fr(comps(G, G.NN(D2(G))) + G.ecc_avg) / 2)


@conj("247", lambda G: G.regular)
def c247(G):
    yield ("ge", "gt>=2p", lambda: G.gamma_t, lambda: 2 * G.p)


@conj("252", lambda G: G.c4free)
def c252(G):
    yield ("ge", "gt>=modemin", lambda: G.gamma_t, lambda: G.mode_min)


@conj("253", lambda G: G.girth >= 5)
def c253(G):
    tag = "[tree:girth=inf]" if G.is_tree else "[cyclic]"
    yield ("ge", "gt>=1+modemin" + tag, lambda: G.gamma_t, lambda: 1 + G.mode_min)


@conj("255", n_gt(1))
def c255(G):
    yield ("ge", "gt>=2|C|/maxN(e)", lambda: G.gamma_t, lambda: Fr(2 * pc(G.C), max(edge_nbhd_sizes(G))))
    yield ("ge", "gt>=2|C|/maxN(e)open", lambda: G.gamma_t, lambda: safe_div(2 * pc(G.C), max(edge_nbhd_sizes(G, False))))


@conj("256", n_gt(1))
def c256(G):
    yield ("ge", "gt>=2|N(A)|/maxN(e)", lambda: G.gamma_t, lambda: Fr(2 * pc(G.N(G.A)), max(edge_nbhd_sizes(G))))
    yield ("ge", "gt>=2|N(A)|/maxN(e)open", lambda: G.gamma_t, lambda: safe_div(2 * pc(G.N(G.A)), max(edge_nbhd_sizes(G, False))))


def _Lconj(G, num):
    yield ("ge", "gt>=2X/L[Ls]", lambda: G.gamma_t, lambda: safe_div(2 * num(), G.Ls))
    yield ("ge", "gt>=2X/L[leaves]", lambda: G.gamma_t, lambda: safe_div(2 * num(), G.f1))
    # length(G)=sqrt(sum d^2):  gt >= 2X/sqrt(s)  <=>  gt^2 * s >= 4X^2
    yield ("imp", "gt>=2X/L[length]", lambda: True,
           lambda: G.gamma_t ** 2 * sum(d * d for d in G.degs) >= 4 * num() ** 2)


@conj("258", n_gt(1))
def c258(G):
    yield from _Lconj(G, lambda: max(G.dist_evens))


@conj("259", n_gt(1))
def c259(G):
    yield from _Lconj(G, lambda: pc(G.N(G.M) & ~G.M))


@conj("260", n_gt(1))
def c260(G):
    yield from _Lconj(G, lambda: pc(G.N(G.B) & ~G.B))


@conj("261", n_gt(1))
def c261(G):
    yield from _Lconj(G, lambda: pc(G.N(D2(G)) & ~D2(G)))


@conj("267", lambda G: G.n > 1 and G.girth >= 5)
def c267(G):
    tag = "[tree:girth=inf]" if G.is_tree else "[cyclic]"
    yield ("ge", "gt>=ceil(distavg_pairs(A,V))" + tag, lambda: G.gamma_t, lambda: ceil(G.dist_avg_pairs(G.A)))
    yield ("ge", "gt>=ceil(distavg_from(A))" + tag, lambda: G.gamma_t, lambda: ceil(G.dist_avg_from(G.A)))


def _davgC(G):
    try:
        return G.dist_avg_between(G.C)
    except Undefined:
        return 0


@conj("268", n_gt(1))
def c268(G):
    yield ("ge", "gt>=floor(1+distavg(C))", lambda: G.gamma_t, lambda: floor(1 + _davgC(G)))


@conj("269", lambda G: G.n > 1 and G.c4free)
def c269(G):
    yield ("ge", "gt>=ceil(1+distavg(C))", lambda: G.gamma_t, lambda: ceil(1 + _davgC(G)))


@conj("271", n_gt(1))
def c271(G):
    def dm():
        try:
            return G.dist_max_set(G.M)
        except Undefined:
            return 0
    yield ("ge", "gt>=ceil sqrt(2distmax(M))", lambda: G.gamma_t, lambda: ceil_sqrt(2 * dm()))


# ======================= total domination upper bounds =======================
@conj("281", n_gt(2))
def c281(G):
    yield ("le", "gt<=freq(lammin(bar))+mu", lambda: G.gamma_t,
           lambda: freq(G.comp.lams, min(G.comp.lams)) + G.mu)


@conj("287", n_gt(2))
def c287(G):
    yield ("le", "gt<=HHk+mu(bar)", lambda: G.gamma_t, lambda: G.HH_k + G.comp.mu)


@conj("290", n_gt(2))
def c290(G):
    yield ("le", "gt<=HHk*Delta", lambda: G.gamma_t, lambda: G.HH_k * G.Delta)


@conj("298", n_gt(2))
def c298(G):
    yield ("le", "gt<=a+chiC4", lambda: G.gamma_t, lambda: G.annihilation + G.c4free)


@conj("299", n_gt(2))
def c299(G):
    yield ("le", "gt<=a+|D2|", lambda: G.gamma_t, lambda: G.annihilation + pc(D2(G)))


@conj("302", n_gt(2))
def c302(G):
    yield ("le", "gt<=minde+freq(lammax(bar))", lambda: G.gamma_t,
           lambda: min(G.dist_evens) + freq(G.comp.lams, max(G.comp.lams)))


@conj("304", n_gt(2))
def c304(G):
    Hc = G.comp
    yield ("le", "gt<=(freq(lammax(bar))+maxNbar(e))/2", lambda: G.gamma_t,
           lambda: Fr(freq(Hc.lams, max(Hc.lams)) + max(edge_nbhd_sizes(Hc)), 2))


@conj("305", n_gt(2))
def c305(G):
    Hc = G.comp
    yield ("le", "gt<=ceil(2/3 maxNbar(e))", lambda: G.gamma_t, lambda: ceil(Fr(2, 3) * max(edge_nbhd_sizes(Hc))))


@conj("308", n_gt(2))
def c308(G):
    Hc = G.comp
    yield ("le", "gt<=(maxine+minNbar(e))/2", lambda: G.gamma_t, lambda: Fr(G.maxine() + min(edge_nbhd_sizes(Hc)), 2))


@conj("310", n_gt(2))
def c310(G):
    yield ("le", "gt<=ceil(1+Tdistmin/3)", lambda: G.gamma_t, lambda: ceil(1 + Fr(min(G.tdists), 3)))


# ======================= well total domination =======================
def _wtd(G, premise, label):
    yield ("imp", label, premise, lambda: G.wtd)


@conj("317", n_gt(1))
def c317(G):
    yield from _wtd(G, lambda: G.tree_num >= G.comp.m, "tree>=|E(bar)| => wtd")


@conj("318", n_gt(1))
def c318(G):
    yield from _wtd(G, lambda: max(G.dist_evens) >= G.comp.m, "maxde>=|E(bar)| => wtd")


@conj("320", n_gt(1))
def c320(G):
    yield from _wtd(G, lambda: max(G.dist_evens) == min(G.tdists), "maxde=Tdistmin => wtd")


@conj("321", n_gt(1))
def c321(G):
    yield from _wtd(G, lambda: G.ecc_avg >= Fr(max(G.tdists), 3), "eccavg>=Tdistmax/3 => wtd")


@conj("323", n_gt(1))
def c323(G):
    yield from _wtd(G, lambda: max(edge_nbhd_sizes(G.comp)) <= 1 + max(G.dist_odd(v) - G.horizontal(v, 1) for v in range(G.n)),
                    "maxNbar(e)<=1+max(dodd-oddhor) => wtd")


@conj("324", n_gt(1))
def c324(G):
    yield from _wtd(G, lambda: max(edge_nbhd_sizes(G.comp)) <= 1 + G.residue, "maxNbar(e)<=1+res => wtd")


@conj("325", n_gt(1))
def c325(G):
    yield from _wtd(G, lambda: min(edge_nbhd_sizes(G.comp)) <= 1 + comps(G, G.NN(D2(G))), "minNbar(e)<=1+c(N[D2]) => wtd")


@conj("326", n_gt(1))
def c326(G):
    yield from _wtd(G, lambda: 3 * G.mu <= G.edges_in(D2(G)), "3mu<=|E(D2)| => wtd")


@conj("328", n_gt(1))
def c328(G):
    yield from _wtd(G, lambda: 4 * G.comp.mu <= freq(G.k4s, max(G.k4s)), "4mu(bar)<=freq(maxK4) => wtd")


# ======================= total domination of trees: upper =======================
def leaves(G):
    return G.P


@conj("340", domain="tree")
def c340(G):
    L = leaves(G)
    yield ("le", "gt<=c(N(L)uL)+modemin*gamma", lambda: G.gamma_t,
           lambda: comps(G, G.N(L) | L) + G.mode_min * G.gamma)


@conj("341", domain="tree")
def c341(G):
    yield ("le", "gt<=ceil(A/2)*sigma", lambda: G.gamma_t, lambda: ceil(Fr(G.annihilation, 2)) * G.sigma)


@conj("342", domain="tree")
def c342(G):
    yield ("le", "gt<=A(bar)+ceil(iso(S)/2)", lambda: G.gamma_t,
           lambda: G.comp.annihilation + ceil(Fr(G.isolates(G.Supp), 2)))


@conj("343", lambda G: D2(G) != 0, domain="tree")
def c343(G):
    yield ("le", "gt<=A(bar)+ceil(c(D2)/2)", lambda: G.gamma_t,
           lambda: G.comp.annihilation + ceil(Fr(comps(G, D2(G)), 2)))


@conj("344", domain="tree")
def c344(G):
    L = leaves(G)
    yield ("le", "gt<=A(bar)-1+c(N(L)uL)", lambda: G.gamma_t,
           lambda: G.comp.annihilation - 1 + comps(G, G.N(L) | L))


# ======================= total domination of trees: lower =======================
@conj("348", domain="tree")
def c348(G):
    d = D2(G)
    yield ("ge", "gt>=2/3|N(D2)-D2|", lambda: G.gamma_t, lambda: Fr(2, 3) * pc(G.N(d) & ~d))


@conj("351", domain="tree")
def c351(G):
    d = D2(G)
    yield ("ge", "gt>=c(SuL)+c(N(D2)uD2)", lambda: G.gamma_t,
           lambda: comps(G, G.Supp | G.P) + comps(G, G.N(d) | d))


@conj("353", domain="tree")
def c353(G):
    yield ("ge", "gt>=c(D2)+cL(M)/2", lambda: G.gamma_t, lambda: comps(G, D2(G)) + Fr(G.comp_largest(G.M), 2))


@conj("354", domain="tree")
def c354(G):
    yield ("ge", "gt>=|C|/2*c(N(D2))", lambda: G.gamma_t, lambda: Fr(pc(G.C), 2) * comps(G, G.N(D2(G))))


@conj("356", domain="tree")
def c356(G):
    yield ("ge", "gt>=|C|*distavg_between(L)", lambda: G.gamma_t, lambda: pc(G.C) * G.dist_avg_between(G.P))
    yield ("ge", "gt>=|C|*distavg_from(L)", lambda: G.gamma_t, lambda: pc(G.C) * G.dist_avg_from(G.P))


@conj("360", domain="tree")
def c360(G):
    yield ("ge", "gt>=c(SuL)+distavg_pairs(C,V)/2", lambda: G.gamma_t,
           lambda: comps(G, G.Supp | G.P) + G.dist_avg_pairs(G.C) / 2)
    yield ("ge", "gt>=c(SuL)+distavg_from(C)/2", lambda: G.gamma_t,
           lambda: comps(G, G.Supp | G.P) + G.dist_avg_from(G.C) / 2)


@conj("361", domain="tree")
def c361(G):
    yield ("ge", "gt>=iso(S)+|C|", lambda: G.gamma_t, lambda: G.isolates(G.Supp) + pc(G.C))


@conj("362", domain="tree")
def c362(G):
    yield ("ge", "gt>=c(SuL)+(1+rad)/3", lambda: G.gamma_t, lambda: comps(G, G.Supp | G.P) + Fr(1 + G.rad, 3))


@conj("363", domain="tree")
def c363(G):
    yield ("ge", "gt>=iso(S)+distavg_between(B)/2", lambda: G.gamma_t, lambda: G.isolates(G.Supp) + G.dist_avg_between(G.B) / 2)
    yield ("ge", "gt>=iso(S)+distavg_from(B)/2", lambda: G.gamma_t, lambda: G.isolates(G.Supp) + G.dist_avg_from(G.B) / 2)


@conj("364", domain="tree")
def c364(G):
    yield ("ge", "gt>=|S|+|E(D2)|/2", lambda: G.gamma_t, lambda: pc(G.Supp) + Fr(G.edges_in(D2(G)), 2))


@conj("365", domain="tree")
def c365(G):
    yield ("ge", "gt>=iso(S)+|E(D2)|/3", lambda: G.gamma_t, lambda: G.isolates(G.Supp) + Fr(G.edges_in(D2(G)), 3))


@conj("367", lambda G: 2 in G.modes, domain="tree")
def c367(G):
    yield ("ge", "gt>=4/3dd (2 among modes)", lambda: G.gamma_t, lambda: Fr(4, 3) * G.dd)
    if G.modes == [2]:
        yield ("ge", "gt>=4/3dd (2 unique mode)", lambda: G.gamma_t, lambda: Fr(4, 3) * G.dd)


@conj("369", domain="tree")
def c369(G):
    yield ("ge", "gt>=ddmode+(n mod 2)HHk", lambda: G.gamma_t, lambda: G.dd_mode + (G.n % 2) * G.HH_k)


@conj("372", domain="tree")
def c372(G):
    yield ("ge", "gt>=vc/(p-1)", lambda: G.gamma_t, lambda: safe_div(G.n - G.alpha, G.p - 1))


@conj("373", domain="tree")
def c373(G):
    yield ("ge", "gt>=2/3distavg_pairs(B,V)", lambda: G.gamma_t, lambda: Fr(2, 3) * G.dist_avg_pairs(G.B))
    yield ("ge", "gt>=2/3distavg_from(B)", lambda: G.gamma_t, lambda: Fr(2, 3) * G.dist_avg_from(G.B))


@conj("374", domain="tree")
def c374(G):
    yield ("ge", "gt>=distavg_between(B)+median", lambda: G.gamma_t, lambda: G.dist_avg_between(G.B) + G.median())
    yield ("ge", "gt>=distavg_from(B)+median", lambda: G.gamma_t, lambda: G.dist_avg_from(G.B) + G.median())


@conj("375", domain="tree")
def c375(G):
    yield ("ge", "gt>=ecc(B)+lowmedian", lambda: G.gamma_t, lambda: G.ecc_set(G.B) + G.median_lower())


@conj("376", domain="tree")
def c376(G):
    def rhs():
        t = G.tdists
        return G.isolates(G.M) + freq(t, min(t))
    yield ("ge", "gt>=iso(M)+|Dmintotal|", lambda: G.gamma_t, rhs)


@conj("377", domain="tree")
def c377(G):
    yield ("ge", "gt>=iso(M)+upmedian", lambda: G.gamma_t, lambda: G.isolates(G.M) + G.median_upper())


@conj("378", domain="tree")
def c378(G):
    d = D2(G)
    yield ("ge", "gt>=c(M)+distavg_between(D2)", lambda: G.gamma_t, lambda: comps(G, G.M) + G.dist_avg_between(d))
    yield ("ge", "gt>=c(M)+distavg_from(D2)", lambda: G.gamma_t, lambda: comps(G, G.M) + G.dist_avg_from(d) if d else (_ for _ in ()).throw(Undefined("no D2")))


@conj("379", domain="tree")
def c379(G):
    yield ("ge", "gt>=c(M)+dd/3", lambda: G.gamma_t, lambda: comps(G, G.M) + Fr(G.dd, 3))


@conj("380", domain="tree")
def c380(G):
    yield ("ge", "gt>=|Deven|/(ecc(C)-1)", lambda: G.gamma_t,
           lambda: safe_div(pc(G.deg_set(lambda d: d % 2 == 0)), G.ecc_set(G.C) - 1))


@conj("381", domain="tree")
def c381(G):
    S = G.Supp
    yield ("ge", "gt>=iso(N(S))/(Delta(S)-1)", lambda: G.gamma_t,
           lambda: safe_div(G.isolates(G.N(S)), Delta_set(G, S) - 1))


# ======================= 2-domination upper bounds =======================
def WPr(G):
    """readings of WP(bar G): Welsh-Powell chi-bound of the complement from G's degrees (name-consistent),
    and the literal formula applied to the complement's own degree sequence."""
    Hc = G.comp
    return {"WPchi": G.WP_bar(), "compdeg": Hc.WP(), "compdeg_noninc": Hc.WP_variant("own_noninc"),
            "owndeg_noninc": G.WP_variant("own_noninc")}


def A1set(G):
    nonmin = G.full & ~G.A
    return G.setof(lambda v: pc(G.adj[v] & nonmin) == 1)


@conj("382b", n_gt(2))
def c382b(G):
    yield ("le", "g2<=-1+alpha(delta+|A1|)", lambda: G.gamma_2, lambda: -1 + G.alpha * (G.delta + pc(A1set(G))))


@conj("382c", n_gt(2))
def c382c(G):
    yield ("le", "g2<=(alpha*eccavg(A)+|B|)/2", lambda: G.gamma_2, lambda: (G.alpha * G.ecc_avg_set(G.A) + pc(G.B)) / 2)


@conj("382d", n_gt(2))
def c382d(G):
    yield ("le", "g2<=diam(alpha+|X|)/2", lambda: G.gamma_2, lambda: Fr(G.diam * (G.alpha + pc(maxlam_set(G))), 2))


@conj("382e", n_gt(2))
def c382e(G):
    yield ("le", "g2<=maxine+gamma", lambda: G.gamma_2, lambda: G.maxine() + G.gamma)


@conj("384b", n_gt(2))
def c384b(G):
    yield ("le", "g2<=floor(n-|T|/2)", lambda: G.gamma_2, lambda: floor(G.n - Fr(len(set(G.tris)), 2)))


@conj("389a", n_gt(2))
def c389a(G):
    for k, q in q1_readings(G).items():
        yield ("le", f"g2<=|Mmode|(q1[{k}]+|A<=2|)-1", lambda: G.gamma_2,
               (lambda q=q: pc(modemin_set(G)) * (q + pc(Le2(G))) - 1))


@conj("392b", n_gt(2))
def c392b(G):
    A, d2 = G.A, D2(G)
    yield ("le", "g2<=mu(V-A)+|A|+|{v:|N(v)^A2|=1}|", lambda: G.gamma_2,
           lambda: G.mu_of(G.full & ~A) + pc(A) + sum(1 for v in range(G.n) if pc(G.adj[v] & d2) == 1))


@conj("392c", n_gt(2))
def c392c(G):
    A = G.A
    yield ("le", "g2<=mu(V-A)+|A|+#cutv", lambda: G.gamma_2, lambda: G.mu_of(G.full & ~A) + pc(A) + pc(G.cut_vertices))


@conj("392d", n_gt(2))
def c392d(G):
    NNP = G.N(G.N(G.P))
    yield ("le", "g2<=mu+mu(V-N(N(P)))+|A|", lambda: G.gamma_2, lambda: G.mu + G.mu_of(G.full & ~NNP) + pc(G.A))


@conj("392e", n_gt(2))
def c392e(G):
    yield ("le", "g2<=mu+mu(N(A2))+|A|", lambda: G.gamma_2, lambda: G.mu + G.mu_of(G.N(D2(G))) + pc(G.A))


@conj("392f", n_gt(2))
def c392f(G):
    NA = G.N(G.A)
    yield ("le", "g2<=mu+mu(N(A2))+|{v:|N(v)^N(A)|=1}|", lambda: G.gamma_2,
           lambda: G.mu + G.mu_of(G.N(D2(G))) + sum(1 for v in range(G.n) if pc(G.adj[v] & NA) == 1))


@conj("393a", n_gt(2))
def c393a(G):
    NNP = G.N(G.N(G.P))
    yield ("le", "g2<=|V-NNP|+mu(NNP)+|P|", lambda: G.gamma_2, lambda: pc(G.full & ~NNP) + G.mu_of(NNP) + pc(G.P))


@conj("393b", n_gt(2))
def c393b(G):
    NP = G.N(G.P)
    NNP = G.N(NP)
    yield ("le", "g2<=|V-NNP|+|E(N(P))|+|{v:|N(v)^N(P)|=1}|", lambda: G.gamma_2,
           lambda: pc(G.full & ~NNP) + G.edges_in(NP) + sum(1 for v in range(G.n) if pc(G.adj[v] & NP) == 1))


@conj("393c", n_gt(2))
def c393c(G):
    NP = G.N(G.P)
    NNP = G.N(NP)
    NcP = NP | G.P
    yield ("le", "g2<=|V-NNP|+|N(P)|+|{v:|N(v)^N[P]|=1}|", lambda: G.gamma_2,
           lambda: pc(G.full & ~NNP) + pc(NP) + sum(1 for v in range(G.n) if pc(G.adj[v] & NcP) == 1))


def M4set(G, empty_if_none):
    k = G.k4s
    mx = max(k)
    if mx == 0 and empty_if_none:
        return 0
    return G.setof(lambda v: k[v] == mx)


@conj("393d", n_gt(2))
def c393d(G):
    NNP = G.N(G.N(G.P))
    base = lambda: G.mu_of(G.full & ~NNP) + G.alpha_of(G.full & ~G.M)
    yield ("le", "g2<=mu(V-NNP)+alpha(V-M)+|M4|", lambda: G.gamma_2, lambda: base() + pc(M4set(G, False)))
    yield ("le", "g2<=...+|M4| (M4=0 if no K4)", lambda: G.gamma_2, lambda: base() + pc(M4set(G, True)))


@conj("394", n_gt(2))
def c394(G):
    yield ("le", "g2<=mu+|E(A2)|+|Mlammin|", lambda: G.gamma_2, lambda: G.mu + G.edges_in(D2(G)) + pc(minlam_set(G)))


@conj("395a", n_gt(2))
def c395a(G):
    yield ("le", "g2<=|Mmode|+mu(V-A)+mu(N(A2))", lambda: G.gamma_2,
           lambda: pc(modemin_set(G)) + G.mu_of(G.full & ~G.A) + G.mu_of(G.N(D2(G))))


@conj("395b", n_gt(2))
def c395b(G):
    def rhs():
        VA = G.full & ~G.A
        dv = delta_ind(G, VA) if VA else 0
        return pc(modemin_set(G)) + dv + pc(G.full & ~Ge3(G))
    yield ("le", "g2<=|Mmode|+delta(V-A)+|V-A3|", lambda: G.gamma_2, rhs)
    def rhs2():
        VA = G.full & ~G.A
        dv = min(G.degs[v] for v in bits(VA)) if VA else 0
        return pc(modemin_set(G)) + dv + pc(G.full & ~Ge3(G))
    yield ("le", "g2<=|Mmode|+delta_G(V-A)+|V-A3|", lambda: G.gamma_2, rhs2)


@conj("396", n_gt(2))
def c396(G):
    A3 = Ge3(G)
    yield ("le", "g2<=ddmode+|Mmode|+|E(A3,V-A3)|", lambda: G.gamma_2,
           lambda: G.dd_mode + pc(modemin_set(G)) + G.edges_between(A3, G.full & ~A3))


@conj("397c", n_gt(2))
def c397c(G):
    yield ("le", "g2<=|V-N(P)|+gamma(G2)", lambda: G.gamma_2, lambda: pc(G.full & ~G.N(G.P)) + G.sq.gamma)


@conj("398", n_gt(2))
def c398(G):
    NP = G.N(G.P)
    NNP = G.N(NP)
    W = G.full & ~NP
    yield ("le", "g2<=|E(V-NNP)|+|{v:|N(v)^(V-N(P))|=1}|+|E(P,V-P)|", lambda: G.gamma_2,
           lambda: G.edges_in(G.full & ~NNP) + sum(1 for v in range(G.n) if pc(G.adj[v] & W) == 1)
           + G.edges_between(G.P, G.full & ~G.P))


@conj("399a", n_gt(2))
def c399a(G):
    for k, wp in WPr(G).items():
        yield ("le", f"g2<=WP(bar)+floor(alpha(C)/2)[{k}]", lambda: G.gamma_2, (lambda wp=wp: wp + G.alpha_of(G.C) // 2))


@conj("399b", n_gt(2))
def c399b(G):
    for k, wp in WPr(G).items():
        yield ("le", f"g2<=WP(bar)+floor(3/alpha(A3))[{k}]", lambda: G.gamma_2,
               (lambda wp=wp: wp + floor(safe_div(3, G.alpha_of(Ge3(G))))))


@conj("399c", n_gt(2))
def c399c(G):
    for k, wp in WPr(G).items():
        yield ("le", f"g2<=2/3WP(bar)+2|Mlammin|[{k}]", lambda: G.gamma_2, (lambda wp=wp: Fr(2, 3) * wp + 2 * pc(minlam_set(G))))


@conj("400c", n_gt(2))
def c400c(G):
    yield ("le", "g2<=floor(3a/dispmin)", lambda: G.gamma_2, lambda: floor(safe_div(3 * G.annihilation, min(G.disps))))


@conj("401a", n_gt(2))
def c401a(G):
    yield ("le", "g2<=1+floor(Tdistmax/dispavg)", lambda: G.gamma_2,
           lambda: 1 + floor(safe_div(max(G.tdists), Fr(sum(G.disps), G.n))))


@conj("401b", n_gt(2))
def c401b(G):
    yield ("le", "g2<=floor(3Tdistmax/freq(Tmax))", lambda: G.gamma_2,
           lambda: floor(Fr(3 * max(G.tdists), freq(G.tris, max(G.tris)))))


@conj("402", n_gt(2))
def c402(G):
    AD = G.M
    yield ("le", "g2<=2(iso(A)+|{v:|N(v)^M|=1}|+gt)", lambda: G.gamma_2,
           lambda: 2 * (G.isolates(G.A) + sum(1 for v in range(G.n) if pc(G.adj[v] & AD) == 1) + G.gamma_t))


# ======================= H (union of maximum critical independent sets) =======================
def Hr(G):
    """readings of H: union of maximum critical independent sets, with the empty set allowed (literal
    definition) or with critical sets taken among nonempty independent sets."""
    return {"H": G.H, "H_nonempty": G.H_ne}


def hread(fn):
    def wrapped(G):
        for tag, HH in Hr(G).items():
            for kind, label, a, b in fn(G, HH):
                yield (kind, f"{label}[{tag}]", a, b)
    wrapped.__name__ = fn.__name__
    return wrapped


@conj("404", domain="tree")
@hread
def c404(G, HH):
    yield ("le", "peN(H)<=2(|S|-1)", lambda: G.peN(HH), lambda: 2 * (pc(G.Supp) - 1))


@conj("405", domain="tree")
@hread
def c405(G, HH):
    yield ("le", "peN(H)<=2alpha(V-L)", lambda: G.peN(HH), lambda: 2 * G.alpha_of(G.full & ~G.P))


@conj("406", domain="tree")
@hread
def c406(G, HH):
    yield ("le", "peN(H)<=peN(V-L)-2", lambda: G.peN(HH), lambda: G.peN(G.full & ~G.P) - 2)


@conj("407", domain="tree")
@hread
def c407(G, HH):
    yield ("le", "peN(H)<=2p", lambda: G.peN(HH), lambda: 2 * G.p)


def De_set(G, which):
    de = G.dist_evens
    t = max(de) if which == "max" else min(de)
    return G.setof(lambda v: de[v] == t)


@conj("410a", n_gt(2))
@hread
def c410a(G, HH):
    yield ("le", "|H|<=|V-A|+|V-M|+|E(De_max)|", lambda: pc(HH),
           lambda: pc(G.full & ~G.A) + pc(G.full & ~G.M) + G.edges_in(De_set(G, "max")))


@conj("410b", n_gt(2))
@hread
def c410b(G, HH):
    yield ("le", "|H|<=|V-A|+|V-M|+|E(De_min)|", lambda: pc(HH),
           lambda: pc(G.full & ~G.A) + pc(G.full & ~G.M) + G.edges_in(De_set(G, "min")))


@conj("412a", n_gt(2))
@hread
def c412a(G, HH):
    NP = G.N(G.P)
    yield ("ge", "|H|>=cL(N(P))", lambda: pc(HH), lambda: G.comp_largest(NP))
    if G.bipartite:
        yield ("ge", "bip:|H|>=cL(N(P))+alpha(V-NNP)", lambda: pc(HH),
               lambda: G.comp_largest(NP) + G.alpha_of(G.full & ~G.N(NP)))


@conj("412b", n_gt(2))
@hread
def c412b(G, HH):
    NP = G.N(G.P)
    yield ("ge", "|H|>=cL(N(P))", lambda: pc(HH), lambda: G.comp_largest(NP))
    if G.bipartite:
        yield ("ge", "bip:|H|>=cL(N(P))+alpha(A2)", lambda: pc(HH), lambda: G.comp_largest(NP) + G.alpha_of(D2(G)))


@conj("412d", lambda G: G.n > 2 and G.bipartite)
@hread
def c412d(G, HH):
    yield ("ge", "|H|>=gt", lambda: pc(HH), lambda: G.gamma_t)


@conj("412e", lambda G: G.n > 2 and G.bipartite)
@hread
def c412e(G, HH):
    NNP = G.N(G.N(G.P))
    yield ("ge", "|H|>=1+Delta(G[NNP])", lambda: pc(HH), lambda: 1 + Delta_ind(G, NNP))


@conj("412f", n_gt(2))
@hread
def c412f(G, HH):
    W = G.full & ~G.N(G.P)
    yield ("ge", "|H|>=mu(V-N(P))", lambda: pc(HH), lambda: G.mu_of(W))
    if G.bipartite:
        yield ("ge", "bip:|H|>=c(V-N(P))+mu(V-N(P))", lambda: pc(HH), lambda: comps(G, W) + G.mu_of(W))


@conj("413a", n_gt(2))
@hread
def c413a(G, HH):
    NNP = G.N(G.N(G.P))
    yield ("ge", "|H|>=kappa*alpha(V-A)+mu(NNP)", lambda: pc(HH),
           lambda: G.kappa * G.alpha_of(G.full & ~G.A) + G.mu_of(NNP))


@conj("413b", n_gt(2))
@hread
def c413b(G, HH):
    d = D2(G)
    yield ("ge", "|H|>=kappa*cL(N(A2)-A2)+|P|", lambda: pc(HH),
           lambda: G.kappa * G.comp_largest(G.N(d) & ~d) + pc(G.P))


@conj("415a", n_gt(2))
@hread
def c415a(G, HH):
    d = D2(G)
    yield ("ge", "|H|>=(peN(A2)-1)iso(N(A2))", lambda: pc(HH), lambda: (G.peN(d) - 1) * G.isolates(G.N(d)))


@conj("415b", n_gt(2))
@hread
def c415b(G, HH):
    d, b2 = D2(G), Le2(G)
    yield ("ge", "|H|>=(peN(A2)-1)iso(B2)", lambda: pc(HH), lambda: (G.peN(d) - 1) * G.isolates(b2))


@conj("415c", n_gt(2))
@hread
def c415c(G, HH):
    b2 = Le2(G)
    yield ("ge", "|H|>=(peN(B2)-1)iso(B2)", lambda: pc(HH), lambda: (G.peN(b2) - 1) * G.isolates(b2))


@conj("416", lambda G: G.n > 2 and G.diam <= 2)
@hread
def c416(G, HH):
    yield ("ge", "|H|>=iso(NNP)-2", lambda: pc(HH), lambda: G.isolates(G.N(G.N(G.P))) - 2)


# ======================= independent domination upper bounds =======================
@conj("418b", n_gt(3))
def c418b(G):
    A = G.A
    yield ("le", "i<=alpha(V-A)+|E(N(A))|p", lambda: G.i, lambda: G.alpha_of(G.full & ~A) + G.edges_in(G.N(A)) * G.p)


@conj("418c", n_gt(3))
def c418c(G):
    A = G.A
    base = lambda: G.alpha_of(G.full & ~A) + G.edges_in(G.N(A))
    yield ("le", "i<=alpha(V-A)+|E(N(A))|+|A^core|", lambda: G.i, lambda: base() + pc(A & G.core))
    yield ("le", "i<=...+|A^H|", lambda: G.i, lambda: base() + pc(A & G.H))
    yield ("le", "i<=...+|A| (weakest)", lambda: G.i, lambda: base() + pc(A))


@conj("420b", n_gt(3))
def c420b(G):
    yield ("le", "i<=alpha(V-N(S))+4(|E(N[A])|-1)", lambda: G.i,
           lambda: G.alpha_of(G.full & ~G.N(G.Supp)) + 4 * (G.edges_in(G.NN(G.A)) - 1))


@conj("420c", n_gt(3))
def c420c(G):
    yield ("le", "i<=alpha(V-N(S))+4(|Tmin|-1)", lambda: G.i,
           lambda: G.alpha_of(G.full & ~G.N(G.Supp)) + 4 * (pc(T_min_set(G)) - 1))


@conj("421b", n_gt(3))
def c421b(G):
    yield ("le", "i<=gamma*floor(maxN(e)/2-1)", lambda: G.i, lambda: G.gamma * floor(Fr(max(edge_nbhd_sizes(G)), 2) - 1))
    yield ("le", "i<=gamma*floor(maxN(e)open/2-1)", lambda: G.i, lambda: G.gamma * floor(Fr(max(edge_nbhd_sizes(G, False)), 2) - 1))


@conj("421c", n_gt(3))
def c421c(G):
    yield ("le", "i<=gamma(|N[Mlam]|-3)", lambda: G.i, lambda: G.gamma * (pc(G.NN(maxlam_set(G))) - 3))


@conj("422a", n_gt(3))
def c422a(G):
    M = G.M
    yield ("le", "i<=alpha(V-M)+2floor(|E(M)|/3)", lambda: G.i, lambda: G.alpha_of(G.full & ~M) + 2 * (G.edges_in(M) // 3))


@conj("422b", n_gt(3))
def c422b(G):
    M = G.M
    yield ("le", "i<=alpha(M)+gamma(V-M)^2", lambda: G.i, lambda: G.alpha_of(M) + G.gamma_of(G.full & ~M) ** 2)


@conj("422c", n_gt(3))
def c422c(G):
    A = G.setof(lambda v: 2 * G.degs[v] <= G.n)
    yield ("le", "i<=alpha(A_{<=n/2})+2floor(Delta(V-A)/3)", lambda: G.i,
           lambda: G.alpha_of(A) + 2 * (Delta_ind(G, G.full & ~A) // 3))


@conj("422d", n_gt(3))
def c422d(G):
    D = G.nbr_dominators()
    yield ("le", "i<=alpha(V-D)+floor((|E(D)|+1)/3)", lambda: G.i, lambda: G.alpha_of(G.full & ~D) + (G.edges_in(D) + 1) // 3)


@conj("423", n_gt(3))
def c423(G):
    A = G.A
    yield ("le", "i<=|E(M)|+alpha(N[A])alpha(V-A)", lambda: G.i,
           lambda: G.edges_in(G.M) + G.alpha_of(G.NN(A)) * G.alpha_of(G.full & ~A))


@conj("425d", n_gt(3))
def c425d(G):
    yield ("le", "i<=|Tmin|+sumK4+gamma(V-N(P))", lambda: G.i,
           lambda: pc(T_min_set(G)) + sum(G.k4s) + G.gamma_of(G.full & ~G.N(G.P)))


@conj("425e", n_gt(3))
def c425e(G):
    yield ("le", "i<=4|Tmin|+|E(D)|", lambda: G.i, lambda: 4 * pc(T_min_set(G)) + G.edges_in(G.nbr_dominators()))


@conj("426", n_gt(3))
def c426(G):
    yield ("le", "i<=n-gamma(N(M))", lambda: G.i, lambda: G.n - G.gamma_of(G.N(G.M)))


@conj("430c", n_gt(3))
def c430c(G):
    base = lambda: lam_max(G) * G.sq.residue
    yield ("le", "i<=lammax*res(G2)+Delta(G[M])", lambda: G.i, lambda: base() + Delta_ind(G, G.M))
    yield ("le", "i<=lammax*res(G2)+Delta(G[C])", lambda: G.i, lambda: base() + Delta_ind(G, G.C))


@conj("431a", n_gt(3))
def c431a(G):
    d = D2(G)
    yield ("le", "i<=res+peN(N(D2))+|Tmin|", lambda: G.i, lambda: G.residue + G.peN(G.N(d)) + pc(T_min_set(G)))


def dpB2(G):
    B = list(bits(G.B))
    return sum(1 for x in range(len(B)) for y in range(x + 1, len(B)) if G.dist[B[x]][B[y]] == 2)


@conj("431b", n_gt(3))
def c431b(G):
    d = D2(G)
    g = lambda: G.gamma_of(G.NN(G.A))
    yield ("le", "i<=res+gamma(N[A])*peN(N(D2))+dp", lambda: G.i, lambda: G.residue + g() * G.peN(G.N(d)) + dpB2(G))
    yield ("le", "i<=res+gamma(N[A])+peN(N(D2))+dp", lambda: G.i, lambda: G.residue + g() + G.peN(G.N(d)) + dpB2(G))


@conj("431c", n_gt(3))
def c431c(G):
    t = G.tris
    yield ("le", "i<=res*Tmax+dd", lambda: G.i, lambda: G.residue * max(t) + G.dd)
    yield ("le", "i<=res*freq(Tmax)+dd", lambda: G.i, lambda: G.residue * freq(t, max(t)) + G.dd)


@conj("432a", n_gt(3))
def c432a(G):
    yield ("le", "i<=a+min(de-do)", lambda: G.i, lambda: G.annihilation + min(G.dist_even(v) - G.dist_odd(v) for v in range(G.n)))


@conj("432b", n_gt(3))
def c432b(G):
    yield ("le", "i<=|V-N(P)|+min(de-do)*chibip", lambda: G.i,
           lambda: pc(G.full & ~G.N(G.P)) + min(G.dist_even(v) - G.dist_odd(v) for v in range(G.n)) * G.bipartite)


@conj("433", n_gt(3))
def c433(G):
    S = G.sq
    yield ("le", "i<=|N(M)|/2*floor(2sum1/deg_G2)", lambda: G.i,
           lambda: Fr(pc(G.N(G.M)), 2) * floor(2 * sum(Fr(1, d) for d in S.degs)))


def SWr(G):
    """readings of SW(complement): WOWII def (degeneracy) and classical Szekeres-Wilf (degeneracy+1)."""
    return {"degen": G.comp.SW, "degen+1": G.comp.SW1}


@conj("434a", n_gt(3))
def c434a(G):
    for k, sw in SWr(G).items():
        yield ("le", f"i<=|M|+2floor(SW/2)[{k}]", lambda: G.i, (lambda sw=sw: pc(G.M) + 2 * (sw // 2)))


@conj("434b", n_gt(3))
def c434b(G):
    for k, sw in SWr(G).items():
        yield ("le", f"i<=delta(G[M])+1+SW[{k}]", lambda: G.i, (lambda sw=sw: delta_ind(G, G.M) + 1 + sw))
        if G.diam > 2:
            yield ("le", f"diam>2: i<=delta(G[M])+SW[{k}]", lambda: G.i, (lambda sw=sw: delta_ind(G, G.M) + sw))
            yield ("le", f"diam>2: i<=delta_G(M)+SW[{k}]", lambda: G.i, (lambda sw=sw: G.Delta + sw))


@conj("434c", n_gt(3))
def c434c(G):
    W = G.full & ~G.M
    dmin_G = lambda: min(G.degs[v] for v in bits(W)) if W else 0
    dind = lambda: delta_ind(G, W) if W else 0
    for k, sw in SWr(G).items():
        yield ("le", f"i<=delta(G[V-M])+1+SW[{k}]", lambda: G.i, (lambda sw=sw: dind() + 1 + sw))
        if G.delta == 1:
            yield ("le", f"delta=1: i<=delta(G[V-M])+SW[{k}]", lambda: G.i, (lambda sw=sw: dind() + sw))
            yield ("le", f"delta=1: i<=delta_G(V-M)+SW[{k}]", lambda: G.i, (lambda sw=sw: dmin_G() + sw))


@conj("434d", n_gt(3))
def c434d(G):
    for k, sw in SWr(G).items():
        yield ("le", f"i<=SW-c(N[B])+2[{k}]", lambda: G.i, (lambda sw=sw: sw - comps(G, G.NN(G.B)) + 2))


@conj("434e", n_gt(3))
def c434e(G):
    for k, sw in SWr(G).items():
        yield ("le", f"i<=SW-ecc(C)+2[{k}]", lambda: G.i, (lambda sw=sw: sw - G.ecc_set(G.C) + 2))


# ======================= 2-independence upper bounds =======================
@conj("435", n_gt(3))
def c435(G):
    S = G.sq
    A2 = S.A
    e = lambda: S.edges_in(A2)
    for k, sw in SWr(G).items():
        yield ("le", f"a2<=SW+ceil((1+|E(G2[A])|)/3)[{k}]", lambda: G.alpha_2, (lambda sw=sw: sw + ceil(Fr(1 + e(), 3))))
        yield ("le", f"a2<=SW+ceil(1+|E(G2[A])|/3)[{k}]", lambda: G.alpha_2, (lambda sw=sw: sw + ceil(1 + Fr(e(), 3))))


@conj("436c", n_gt(3))
def c436c(G):
    for k, wp in WPr(G).items():
        yield ("le", f"a2<=HHk*WP(bar)+Delta(G[D])[{k}]", lambda: G.alpha_2,
               (lambda wp=wp: G.HH_k * wp + Delta_ind(G, G.nbr_dominators())))


@conj("438a", n_gt(3))
def c438a(G):
    A = G.A
    def rhs():
        W = G.full & ~A
        aW = G.sub(W).annihilation if W else 0
        return G.annihilation + aW + G.edges_in(A)
    yield ("le", "a2<=a+a(G[V-A])+|E(A)|", lambda: G.alpha_2, rhs)


@conj("439", n_gt(3))
def c439(G):
    yield ("le", "a2<=|N(M)|+floor(2(CW-1))", lambda: G.alpha_2, lambda: pc(G.N(G.M)) + floor(2 * (G.CW - 1)))


@conj("442", n_gt(3))
def c442(G):
    H3 = Ge3(G)
    yield ("le", "a2<=n-ceil(path(G[H3])/2)", lambda: G.alpha_2, lambda: G.n - ceil(Fr(G.path_num_of(H3) if H3 else 0, 2)))


@conj("443", n_gt(3))
def c443(G):
    yield ("le", "a2<=sum disp-|N(core)|-2", lambda: G.alpha_2, lambda: sum(G.disps) - pc(G.N(G.core)) - 2)


@conj("444", n_gt(3))
def c444(G):
    yield ("le", "a2<=n-floor(dd(K4)/2)", lambda: G.alpha_2, lambda: G.n - len(set(G.k4s)) // 2)


@conj("446", n_gt(3))
def c446(G):
    yield ("le", "a2<=pN(A)+|V-S|", lambda: G.alpha_2, lambda: G.pN(G.A) + pc(G.full & ~G.Supp))


def rho_readings(G):
    return {"packing": G.packing(), "radius": G.rad, "residue": G.residue}


@conj("448a", n_gt(3))
def c448a(G):
    Hn = G.setof(lambda v: 2 * G.degs[v] > G.n)
    for k, r in rho_readings(G).items():
        yield ("le", f"a2<=|Hn2|+|E(V-Hn2)|+rho[{k}]", lambda: G.alpha_2,
               (lambda r=r: pc(Hn) + G.edges_in(G.full & ~Hn) + r))


@conj("448b", n_gt(3))
def c448b(G):
    for k, r in rho_readings(G).items():
        yield ("le", f"a2<=|V-A|+|E(N(S))|+rho[{k}]", lambda: G.alpha_2,
               (lambda r=r: pc(G.full & ~G.A) + G.edges_in(G.N(G.Supp)) + r))


@conj("449", n_gt(3))
def c449(G):
    H3 = Ge3(G)
    yield ("le", "a2<=|V-H3|+ceil((|E(H3)|-1)/2)", lambda: G.alpha_2, lambda: pc(G.full & ~H3) + ceil(Fr(G.edges_in(H3) - 1, 2)))


@conj("450", n_gt(3))
def c450(G):
    H3 = Ge3(G)
    yield ("le", "a2<=pN(A2)+|V-S|+pN(V-H3)", lambda: G.alpha_2,
           lambda: G.pN(D2(G)) + pc(G.full & ~G.Supp) + G.pN(G.full & ~H3))


# ======================= path number lower bounds =======================
@conj("136", lambda G: G.n > 1 and G.girth != float("inf"))
def c136(G):
    def rhs():
        R = 0
        for v in bits(G.C):
            R |= G.radial(v)
        return Fr(1 + G.girth, Delta_set(G, R))
    yield ("ge", "path>=(1+girth)/Delta(R)", lambda: G.path_num, rhs)


@conj("137", n_gt(1))
def c137(G):
    yield ("ge", "path>=4/p(bar)", lambda: G.path_num, lambda: Fr(4, G.comp.p))


@conj("138", n_gt(1))
def c138(G):
    S = G.sq
    M2 = S.M
    yield ("ge", "path>=(2+u)distmin_G(M(G2))", lambda: G.path_num, lambda: (2 + G.u) * G.dist_min_set(M2))
    yield ("ge", "path>=(2+u)distmin_G2(M(G2))", lambda: G.path_num, lambda: (2 + G.u) * S.dist_min_set(M2))
