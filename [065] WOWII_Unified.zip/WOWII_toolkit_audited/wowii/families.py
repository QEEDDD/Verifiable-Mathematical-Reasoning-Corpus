"""Structured and random connected graphs for the second sweep (deduplicated by canonical form)."""
import itertools
import os
import random
import sys

import networkx as nx
import pynauty

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "db")


def cert(g):
    g = nx.convert_node_labels_to_integers(g)
    n = g.number_of_nodes()
    d = {v: list(g[v]) for v in g}
    return n, pynauty.certificate(pynauty.Graph(n, directed=False, adjacency_dict=d))


def blowup(Q, w):
    g = nx.Graph()
    blobs, s = [], 0
    for k in w:
        b = list(range(s, s + k)); s += k
        blobs.append(b)
        g.add_nodes_from(b)
        g.add_edges_from(itertools.combinations(b, 2))
    for u, v in Q.edges():
        g.add_edges_from((a, b) for a in blobs[u] for b in blobs[v])
    return g


def corona(g):
    h = nx.convert_node_labels_to_integers(g)
    n = h.number_of_nodes()
    for v in range(n):
        h.add_edge(v, n + v)
    return h


def spider(legs):
    g = nx.Graph(); g.add_node(0); nxt = 1
    for L in legs:
        prev = 0
        for _ in range(L):
            g.add_edge(prev, nxt); prev = nxt; nxt += 1
    return g


def caterpillar(spine, pend):
    g = nx.path_graph(spine); nxt = spine
    for i, k in enumerate(pend):
        for _ in range(k):
            g.add_edge(i, nxt); nxt += 1
    return g


def gen(seed=1, big=False):
    R = random.Random(seed)
    G = []
    add = G.append
    for n in range(2, 41):
        add(nx.path_graph(n))
    for n in range(3, 41):
        add(nx.cycle_graph(n))
    for n in range(2, 16):
        add(nx.complete_graph(n))
    for a in range(1, 13):
        for b in range(a, 16):
            add(nx.complete_bipartite_graph(a, b))
    for a in range(1, 13):
        for b in range(a, 13):
            g = nx.Graph(); g.add_edge(0, 1)
            for i in range(a): g.add_edge(0, 2 + i)
            for j in range(b): g.add_edge(1, 2 + a + j)
            add(g)
    for k in range(2, 7):
        for legs in itertools.combinations_with_replacement(range(1, 6), k):
            add(spider(legs))
    for _ in range(3000):
        sp = R.randint(2, 12)
        add(caterpillar(sp, [R.randint(0, 3) for _ in range(sp)]))
    for n in range(4, 22):
        add(nx.wheel_graph(n)); add(nx.star_graph(n - 1))
        add(corona(nx.cycle_graph(n - 1))); add(corona(nx.path_graph(n - 1)))
    for n in range(3, 14):
        add(nx.circular_ladder_graph(n)); add(nx.ladder_graph(n))
        add(nx.lollipop_graph(n, 3)); add(nx.barbell_graph(n, 2))
    for k in range(2, 9):
        add(nx.windmill_graph(k, 3))
    for a in range(2, 7):
        for b in range(a, 7):
            add(nx.grid_2d_graph(a, b)); add(nx.complete_multipartite_graph(a, b, 2))
            if a >= 3: add(nx.grid_2d_graph(a, b, periodic=True))
    named = [nx.petersen_graph(), nx.heawood_graph(), nx.moebius_kantor_graph(), nx.pappus_graph(),
             nx.desargues_graph(), nx.dodecahedral_graph(), nx.cubical_graph(), nx.octahedral_graph(),
             nx.icosahedral_graph(), nx.chvatal_graph(), nx.frucht_graph(), nx.truncated_tetrahedron_graph(),
             nx.truncated_cube_graph(), nx.hypercube_graph(4), nx.tutte_graph(), nx.mcgee_graph() if hasattr(nx, "mcgee_graph") else nx.null_graph(),
             nx.paley_graph(13).to_undirected(), nx.paley_graph(17).to_undirected(), nx.kneser_graph(6, 2),
             nx.kneser_graph(7, 2), nx.kneser_graph(7, 3), nx.bull_graph(), nx.house_graph(), nx.house_x_graph(),
             nx.diamond_graph(), nx.krackhardt_kite_graph(), nx.tetrahedral_graph(), nx.sedgewick_maze_graph(),
             nx.hoffman_singleton_graph() if big else nx.null_graph()]
    G += [g for g in named if g.number_of_nodes() > 0]
    for n in range(5, 20):
        for S in itertools.combinations(range(1, n // 2 + 1), 2):
            add(nx.circulant_graph(n, S))
    # clique blow-ups of paths / cycles / small graphs
    for k in range(3, 8):
        for Q in (nx.path_graph(k), nx.cycle_graph(k)):
            for w in itertools.product([1, 2, 3], repeat=k):
                if sum(w) <= 22:
                    add(blowup(Q, w))
    small = [nx.from_graph6_bytes(l.strip().encode()) for l in open(os.path.join(OUT, "conn5.g6"))]
    for Q in small:
        for w in itertools.product([1, 2, 4], repeat=5):
            if R.random() < 0.3:
                add(blowup(Q, w))
    for Q in small[:]:
        add(corona(Q))
    for l in open(os.path.join(OUT, "conn6.g6")):
        add(corona(nx.from_graph6_bytes(l.strip().encode())))
    # random graphs
    for n in range(10, 15):
        for p in (0.15, 0.25, 0.35, 0.5, 0.65, 0.8):
            for _ in range(150):
                g = nx.gnp_random_graph(n, p, seed=R.randint(0, 10**9))
                if nx.is_connected(g):
                    add(g)
    for d in (3, 4, 5):
        for n in range(d + 1, 19):
            if n * d % 2 == 0:
                for _ in range(20):
                    add(nx.random_regular_graph(d, n, seed=R.randint(0, 10**9)))
    for n in range(19, 61):
        for _ in range(60):
            add(nx.random_labeled_tree(n, seed=R.randint(0, 10**9)))
    for n in range(10, 15):
        for _ in range(300):
            g = nx.bipartite.random_graph(n // 2, n - n // 2, R.uniform(0.2, 0.6), seed=R.randint(0, 10**9))
            if nx.is_connected(g):
                add(g)
    return G


def main():
    big = len(sys.argv) > 2 and sys.argv[2] == "big"
    seen, out = set(), []
    for g in gen(big=big):
        g = nx.Graph(g)
        g.remove_edges_from(nx.selfloop_edges(g))
        if g.number_of_nodes() < 2 or not nx.is_connected(g):
            continue
        if g.number_of_nodes() <= 9 and not big:
            continue   # covered exhaustively
        c = cert(g)
        if c in seen:
            continue
        seen.add(c)
        g = nx.convert_node_labels_to_integers(g)
        out.append(nx.to_graph6_bytes(g, header=False).decode().strip())
    out.sort(key=len)
    with open(sys.argv[1], "w") as f:
        f.write("\n".join(out) + "\n")
    print("families:", len(out))


if __name__ == "__main__":
    main()
