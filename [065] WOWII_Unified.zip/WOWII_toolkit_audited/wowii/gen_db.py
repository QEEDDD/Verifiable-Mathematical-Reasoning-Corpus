"""Generate all graphs up to 9 vertices (canonical dedup with pynauty) and all trees up to 18 vertices."""
import os
import sys
import time

import networkx as nx
import pynauty
from networkx.generators.atlas import graph_atlas_g

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "db")
os.makedirs(OUT, exist_ok=True)


def to_adj(g):
    n = g.number_of_nodes()
    adj = [0] * n
    for u, v in g.edges():
        adj[u] |= 1 << v
        adj[v] |= 1 << u
    return tuple(adj)


def cert(n, adj):
    d = {v: [w for w in range(n) if adj[v] >> w & 1] for v in range(n)}
    return pynauty.certificate(pynauty.Graph(n, directed=False, adjacency_dict=d))


def connected(n, adj):
    seen = fr = 1
    while fr:
        nb = 0
        f = fr
        while f:
            b = f & -f
            nb |= adj[b.bit_length() - 1]
            f ^= b
        nb &= ~seen
        seen |= nb
        fr = nb
    return seen == (1 << n) - 1


def g6(n, adj):
    g = nx.Graph()
    g.add_nodes_from(range(n))
    for u in range(n):
        for v in range(u + 1, n):
            if adj[u] >> v & 1:
                g.add_edge(u, v)
    return nx.to_graph6_bytes(g, header=False).decode().strip()


def main(nmax=9):
    level = {}
    for g in graph_atlas_g():
        n = g.number_of_nodes()
        level.setdefault(n, []).append(to_adj(g))
    for n in range(1, 8):
        conn = [a for a in level[n] if connected(n, a)]
        with open(os.path.join(OUT, f"conn{n}.g6"), "w") as f:
            for a in conn:
                f.write(g6(n, a) + "\n")
        print(n, "all", len(level[n]), "connected", len(conn), flush=True)
    prev = level[7]
    for n in range(8, nmax + 1):
        t = time.time()
        seen = {}
        for adj in prev:
            for S in range(1 << (n - 1)):
                new = list(adj) + [S]
                for v in range(n - 1):
                    if S >> v & 1:
                        new[v] |= 1 << (n - 1)
                new = tuple(new)
                c = cert(n, new)
                if c not in seen:
                    seen[c] = new
        allg = list(seen.values())
        conn = [a for a in allg if connected(n, a)]
        with open(os.path.join(OUT, f"conn{n}.g6"), "w") as f:
            for a in conn:
                f.write(g6(n, a) + "\n")
        print(n, "all", len(allg), "connected", len(conn), f"{time.time()-t:.0f}s", flush=True)
        prev = allg
    for n in range(3, 19):
        t = time.time()
        with open(os.path.join(OUT, f"tree{n}.g6"), "w") as f:
            k = 0
            for T in nx.nonisomorphic_trees(n):
                f.write(nx.to_graph6_bytes(T, header=False).decode().strip() + "\n")
                k += 1
        print("trees", n, k, f"{time.time()-t:.0f}s", flush=True)


if __name__ == "__main__":
    main(int(sys.argv[1]) if len(sys.argv) > 1 else 9)
