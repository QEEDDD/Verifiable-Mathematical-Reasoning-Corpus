"""WOWII invariant library (own implementation).

Graph = vertices 0..n-1, adj[v] = int bitmask.  All set arguments are bitmasks.
Exact brute force via libwcore.so for NP-hard invariants (|U| <= ~24);
pure Python for polynomial ones.  Fractions for exact arithmetic.
"""
import ctypes
import itertools
import math
import os
from collections import Counter
from fractions import Fraction as Fr

import networkx as nx

_here = os.path.dirname(os.path.abspath(__file__))
_lib = ctypes.CDLL(os.path.join(_here, "libwcore.so"))
_u64 = ctypes.c_uint64
_P = ctypes.POINTER(_u64)
for name in ["w_gamma", "w_gamma_t", "w_gamma_2", "w_gamma_c", "w_indep_dom", "w_bip", "w_forest",
             "w_tree", "w_ipath", "w_icycle", "w_alpha", "w_traceable", "w_path_cover",
             "w_longest_path", "w_connected", "w_edges", "w_ncomp"]:
    f = getattr(_lib, name); f.argtypes = [_P, _u64]; f.restype = ctypes.c_int
_lib.w_alpha_k.argtypes = [_P, _u64, ctypes.c_int]; _lib.w_alpha_k.restype = ctypes.c_int
_lib.w_indsets.argtypes = [_P, _u64, ctypes.POINTER(ctypes.c_long), _P]; _lib.w_indsets.restype = None
_lib.w_minimal_tds.argtypes = [_P, _u64, ctypes.POINTER(ctypes.c_int)]; _lib.w_minimal_tds.restype = None

INF = float("inf")


def bits(S):
    while S:
        b = S & -S
        yield b.bit_length() - 1
        S ^= b


def pc(S):
    return S.bit_count()


class Undefined(Exception):
    """Invariant not defined for this graph (e.g. empty set average)."""


BRUTE_MAX = 24   # largest |U| for exhaustive subset enumeration


def _guard(S, lim=None):
    if S.bit_count() > (lim or BRUTE_MAX):
        raise Undefined("too large for brute force")


class Gr:
    __slots__ = ("n", "adj", "full", "_c", "_carr", "name")

    def __init__(self, n, adj, name=""):
        self.n = n
        self.adj = tuple(adj)
        self.full = (1 << n) - 1
        self._c = {}
        self._carr = (_u64 * max(n, 1))(*self.adj) if n else (_u64 * 1)(0)
        self.name = name

    # ---------------- construction ----------------
    @staticmethod
    def from_nx(g, name=""):
        g = nx.convert_node_labels_to_integers(g)
        n = g.number_of_nodes()
        adj = [0] * n
        for u, v in g.edges():
            if u != v:
                adj[u] |= 1 << v
                adj[v] |= 1 << u
        return Gr(n, adj, name)

    @staticmethod
    def from_g6(s, name=""):
        return Gr.from_nx(nx.from_graph6_bytes(s.encode() if isinstance(s, str) else s), name or s)

    def to_nx(self):
        g = nx.Graph()
        g.add_nodes_from(range(self.n))
        for u in range(self.n):
            for v in bits(self.adj[u] >> (u + 1) << (u + 1)):
                g.add_edge(u, v)
        return g

    def g6(self):
        return nx.to_graph6_bytes(self.to_nx(), header=False).decode().strip()

    def memo(self, key, fn):
        c = self._c
        if key in c:
            return c[key]
        v = fn()
        c[key] = v
        return v

    # ---------------- basic ----------------
    def deg(self, v):
        return pc(self.adj[v])

    @property
    def degs(self):
        return self.memo("degs", lambda: [pc(a) for a in self.adj])

    @property
    def m(self):
        return self.memo("m", lambda: sum(self.degs) // 2)

    def N(self, S):
        r = 0
        for v in bits(S):
            r |= self.adj[v]
        return r

    def NN(self, S):  # closed neighbourhood
        return self.N(S) | S

    def mask(self, it):
        r = 0
        for v in it:
            r |= 1 << v
        return r

    def setof(self, pred):
        return self.mask(v for v in range(self.n) if pred(v))

    def edges_in(self, S):
        return _lib.w_edges(self._carr, S)

    def edges_between(self, S, T):
        """number of edges with one end in S and the other in T (S, T disjoint)."""
        if S & T:
            raise ValueError("edges_between expects disjoint sets")
        return sum(pc(self.adj[v] & T) for v in bits(S))

    def ncomp(self, S):
        return _lib.w_ncomp(self._carr, S) if S else 0

    def components(self, S):
        out = []
        while S:
            st = S & -S
            seen, fr = st, st
            while fr:
                nb = self.N(fr) & S & ~seen
                seen |= nb
                fr = nb
            out.append(seen)
            S &= ~seen
        return out

    def comp_largest(self, S):
        cs = self.components(S)
        return max((pc(c) for c in cs), default=0)

    def isolates(self, S):
        return sum(1 for v in bits(S) if not (self.adj[v] & S))

    def connected(self, S=None):
        S = self.full if S is None else S
        return bool(_lib.w_connected(self._carr, S))

    def induced_degs(self, S):
        return [pc(self.adj[v] & S) for v in bits(S)]

    def delta_in(self, S):  # min degree of G[S]
        d = self.induced_degs(S)
        if not d:
            raise Undefined("delta of empty graph")
        return min(d)

    def Delta_in(self, S):
        d = self.induced_degs(S)
        if not d:
            raise Undefined("Delta of empty graph")
        return max(d)

    def sub(self, S):
        """Induced subgraph as a new relabelled Gr (cached)."""
        def mk():
            vs = list(bits(S))
            idx = {v: i for i, v in enumerate(vs)}
            adj = [0] * len(vs)
            for v in vs:
                for w in bits(self.adj[v] & S):
                    adj[idx[v]] |= 1 << idx[w]
            return Gr(len(vs), adj)
        return self.memo(("sub", S), mk)

    @property
    def comp(self):
        def mk():
            return Gr(self.n, [(~self.adj[v]) & self.full & ~(1 << v) for v in range(self.n)])
        return self.memo("comp", mk)

    @property
    def sq(self):  # G^2
        def mk():
            adj = []
            for v in range(self.n):
                a = self.adj[v]
                a2 = a | self.N(a)
                adj.append(a2 & ~(1 << v))
            return Gr(self.n, adj)
        return self.memo("sq", mk)

    # ---------------- degree statistics ----------------
    @property
    def delta(self):
        return min(self.degs)

    @property
    def Delta(self):
        return max(self.degs)

    @property
    def sorted_degs(self):
        return self.memo("sdegs", lambda: sorted(self.degs))

    @property
    def sigma(self):  # second smallest degree
        return self.sorted_degs[1]

    @property
    def Sigma(self):
        return self.sorted_degs[-2]

    @property
    def deg_avg(self):
        return Fr(2 * self.m, self.n)

    @property
    def modes(self):
        def mk():
            c = Counter(self.degs)
            mx = max(c.values())
            return sorted(d for d, k in c.items() if k == mx)
        return self.memo("modes", mk)

    @property
    def mode_min(self):
        return self.modes[0]

    @property
    def mode_max(self):
        return self.modes[-1]

    @property
    def dd_mode(self):
        return len(self.modes)

    @property
    def even_mode_min(self):
        c = Counter(d for d in self.degs if d % 2 == 0)
        if not c:
            raise Undefined("no even degree")
        mx = max(c.values())
        return min(d for d, k in c.items() if k == mx)

    @property
    def dd(self):
        return len(set(self.degs))

    def median_lower(self):
        s, n = self.sorted_degs, self.n
        return s[(n + 1) // 2 - 1] if n % 2 else s[n // 2 - 1]

    def median_upper(self):
        s, n = self.sorted_degs, self.n
        return s[(n + 1) // 2 - 1] if n % 2 else s[n // 2]

    def median(self):
        return Fr(self.median_lower() + self.median_upper(), 2)

    def freq_deg(self, k):
        return sum(1 for d in self.degs if d == k)

    @property
    def f1(self):
        return self.freq_deg(1)

    @property
    def length(self):
        return math.sqrt(sum(d * d for d in self.degs))

    # ---------------- named vertex sets ----------------
    @property
    def M(self):
        return self.memo("M", lambda: self.setof(lambda v: self.degs[v] == self.Delta))

    @property
    def A(self):
        return self.memo("A", lambda: self.setof(lambda v: self.degs[v] == self.delta))

    @property
    def P(self):
        return self.memo("P", lambda: self.setof(lambda v: self.degs[v] == 1))

    @property
    def Supp(self):
        return self.memo("Supp", lambda: self.N(self.P))

    def deg_set(self, pred):
        return self.setof(lambda v: pred(self.degs[v]))

    # ---------------- distances ----------------
    @property
    def dist(self):
        def mk():
            n = self.n
            D = []
            for s in range(n):
                row = [INF] * n
                row[s] = 0
                fr, seen, d = 1 << s, 1 << s, 0
                while fr:
                    d += 1
                    nb = self.N(fr) & ~seen
                    for v in bits(nb):
                        row[v] = d
                    seen |= nb
                    fr = nb
                D.append(row)
            return D
        return self.memo("dist", mk)

    def ecc(self, v):
        return max(self.dist[v])

    @property
    def eccs(self):
        return self.memo("eccs", lambda: [self.ecc(v) for v in range(self.n)])

    @property
    def rad(self):
        return min(self.eccs)

    @property
    def diam(self):
        return max(self.eccs)

    @property
    def C(self):
        return self.memo("C", lambda: self.setof(lambda v: self.eccs[v] == self.rad))

    @property
    def B(self):
        return self.memo("B", lambda: self.setof(lambda v: self.eccs[v] == self.diam))

    def dist_to_set(self, v, S):
        return min(self.dist[v][s] for s in bits(S))

    def ecc_set(self, S):
        """DeLaVina def 52: max over v in V-S of dist(v,S); 0 if S=V."""
        rest = self.full & ~S
        if not S:
            raise Undefined("ecc of empty set")
        return max((self.dist_to_set(v, S) for v in bits(rest)), default=0)

    def ecc_avg_set(self, S):
        if not S:
            raise Undefined("empty")
        return Fr(sum(self.eccs[v] for v in bits(S)), pc(S))

    @property
    def ecc_avg(self):
        return Fr(sum(self.eccs), self.n)

    def dist_avg_between(self, S):
        """average of nonzero dist(u,v), u,v in S (def: dist_avg(C), dist_avg(B), dist_avg(M), dist_avg(A))."""
        vs = list(bits(S))
        ds = [self.dist[u][v] for u, v in itertools.combinations(vs, 2)]
        if not ds:
            raise Undefined("fewer than two vertices")
        return Fr(sum(ds), len(ds))

    def dist_avg_from(self, S):
        """average of dist(S,v) > 0 over v (i.e. over v not in S) (def 'dist_avg(S)' average distance from a set)."""
        ds = [self.dist_to_set(v, S) for v in bits(self.full & ~S)]
        if not ds:
            raise Undefined("S = V")
        return Fr(sum(ds), len(ds))

    def dist_avg_pairs(self, S):
        """average of all nonzero dist(s,v), s in S, v in V (defs dist_avg(B,V), dist_avg(C,V), dist_avg(M,V))."""
        ds = [self.dist[s][v] for s in bits(S) for v in range(self.n) if v != s]
        if not ds:
            raise Undefined("empty")
        return Fr(sum(ds), len(ds))

    @property
    def dist_avg_graph(self):
        ds = [self.dist[u][v] for u, v in itertools.combinations(range(self.n), 2)]
        return Fr(sum(ds), len(ds))

    def dist_min_set(self, S):
        vs = list(bits(S))
        ds = [self.dist[u][v] for u, v in itertools.combinations(vs, 2)]
        if not ds:
            raise Undefined("fewer than two")
        return min(ds)

    def dist_max_set(self, S):
        vs = list(bits(S))
        ds = [self.dist[u][v] for u, v in itertools.combinations(vs, 2)]
        if not ds:
            raise Undefined("fewer than two")
        return max(ds)

    def tdist(self, v):
        return sum(self.dist[v])

    @property
    def tdists(self):
        return self.memo("tdists", lambda: [self.tdist(v) for v in range(self.n)])

    def dist_even(self, v):
        return sum(1 for d in self.dist[v] if d != INF and d % 2 == 0)

    def dist_odd(self, v):
        return sum(1 for d in self.dist[v] if d != INF and d % 2 == 1)

    @property
    def dist_evens(self):
        return self.memo("devens", lambda: [self.dist_even(v) for v in range(self.n)])

    def horizontal(self, v, parity=None):
        D = self.dist[v]
        c = 0
        for a in range(self.n):
            for b in bits(self.adj[a] >> (a + 1) << (a + 1)):
                if D[a] == D[b] and (parity is None or D[a] % 2 == parity):
                    c += 1
        return c

    def radial(self, v):
        r = self.rad
        return self.setof(lambda u: self.dist[v][u] == r)

    # ---------------- local structure ----------------
    def lam(self, v):  # local independence
        return self.alpha_of(self.adj[v])

    @property
    def lams(self):
        return self.memo("lams", lambda: [self.lam(v) for v in range(self.n)])

    def tri(self, v):
        a = self.adj[v]
        return sum(pc(self.adj[u] & a) for u in bits(a)) // 2

    @property
    def tris(self):
        return self.memo("tris", lambda: [self.tri(v) for v in range(self.n)])

    def k4(self, v):
        a = self.adj[v]
        c = 0
        for u in bits(a):
            b = a & self.adj[u] & ~((1 << (u + 1)) - 1)
            for w in bits(b):
                c += pc(b & self.adj[w] & ~((1 << (w + 1)) - 1))
        return c

    @property
    def k4s(self):
        return self.memo("k4s", lambda: [self.k4(v) for v in range(self.n)])

    def edge_list(self):
        return [(u, v) for u in range(self.n) for v in bits(self.adj[u] >> (u + 1) << (u + 1))]

    def Ne(self, u, v, closed=True):
        """|N(e)| for edge e=uv: vertices adjacent to u or v (includes u,v themselves since uv is an edge)."""
        s = self.adj[u] | self.adj[v]
        if not closed:
            s &= ~((1 << u) | (1 << v))
        return pc(s)

    def disp(self, v):
        return len(set(self.degs[u] for u in bits(self.adj[v])))

    @property
    def disps(self):
        return self.memo("disps", lambda: [self.disp(v) for v in range(self.n)])

    def nbr_dominators(self):
        """D = {v : N[v] contains N[u] for some u != v}."""
        def mk():
            cl = [self.adj[v] | (1 << v) for v in range(self.n)]
            return self.setof(lambda v: any(u != v and (cl[u] & ~cl[v]) == 0 for u in range(self.n)))
        return self.memo("nbrdom", mk)

    def peN(self, S):  # private external neighbours: vertices outside S with exactly one nbr in S
        return sum(1 for v in bits(self.full & ~S) if pc(self.adj[v] & S) == 1)

    def pN(self, S):  # vertices of V with exactly one neighbour in S
        return sum(1 for v in range(self.n) if pc(self.adj[v] & S) == 1)

    # ---------------- degree-sequence invariants ----------------
    @property
    def residue(self):
        def mk():
            s = sorted(self.degs, reverse=True)
            while s and s[0] > 0:
                d = s.pop(0)
                for i in range(d):
                    s[i] -= 1
                s.sort(reverse=True)
            return len(s)
        return self.memo("res", mk)

    @property
    def HH_k(self):
        """number of Havel-Hakimi iterations until a zero appears in the resulting sequence."""
        def mk():
            s = sorted(self.degs, reverse=True)
            if 0 in s:
                return 0
            k = 0
            while True:
                d = s.pop(0)
                for i in range(d):
                    s[i] -= 1
                s.sort(reverse=True)
                k += 1
                if not s or 0 in s:
                    return k
        return self.memo("hhk", mk)

    @property
    def annihilation(self):
        s = self.sorted_degs
        tot, k = 0, 0
        for d in s:
            if tot + d <= self.m:
                tot += d
                k += 1
            else:
                break
        return k

    def WP(self):
        """largest k with k + d_k <= n, degrees nondecreasing (1-indexed); 0 if none."""
        s = self.sorted_degs
        best = 0
        for k in range(1, self.n + 1):
            if k + s[k - 1] <= self.n:
                best = k
        return best

    def WP_bar(self):
        """Welsh-Powell bound of chi(complement) from G's degrees: largest k with k + d_k <= n (d nondecreasing)."""
        s = self.sorted_degs
        best = 0
        for k in range(1, self.n + 1):
            if k + s[k - 1] <= self.n:
                best = k
        return best

    def WP_variant(self, which):
        """largest k with k + d_k <= n for various orderings/sequences (reading variants of WP)."""
        if which == "own_nondec":
            s = self.sorted_degs
        elif which == "own_noninc":
            s = sorted(self.degs, reverse=True)
        else:
            raise ValueError(which)
        best = 0
        for k in range(1, self.n + 1):
            if k + s[k - 1] <= self.n:
                best = k
        return best

    @property
    def SW1(self):  # classical Szekeres-Wilf number = degeneracy + 1
        return self.SW + 1

    @property
    def SW(self):  # Szekeres-Wilf (WOWII def) = degeneracy
        if self.m == 0:
            return 0
        return max(nx.core_number(self.to_nx()).values())

    @property
    def CW(self):
        return sum(Fr(1, d + 1) for d in self.degs)

    def maxine(self):
        """largest independent set obtainable by repeatedly deleting a max-degree vertex (max over ties)."""
        memo = {}
        budget = [300000]

        def rec(U):
            if U in memo:
                return memo[U]
            budget[0] -= 1
            if budget[0] < 0:
                raise Undefined("maxine: tie-break search budget exceeded")
            ds = [(pc(self.adj[v] & U), v) for v in bits(U)]
            mx = max(d for d, _ in ds)
            if mx == 0:
                r = pc(U)
            else:
                r = max(rec(U & ~(1 << v)) for d, v in ds if d == mx)
            memo[U] = r
            return r
        return self.memo("maxine", lambda: rec(self.full))

    # ---------------- NP-hard (C core) ----------------
    def alpha_of(self, S):
        return self.memo(("alpha", S), lambda: _lib.w_alpha(self._carr, S))

    @property
    def alpha(self):
        return self.alpha_of(self.full)

    def gamma_of(self, S):
        return self.memo(("gam", S), lambda: _lib.w_gamma(self._carr, S))

    @property
    def gamma(self):
        return self.gamma_of(self.full)

    def gamma_t_of(self, S):
        def mk():
            r = _lib.w_gamma_t(self._carr, S)
            if r < 0:
                raise Undefined("isolated vertex: no TDS")
            return r
        return self.memo(("gamt", S), mk)

    @property
    def gamma_t(self):
        return self.gamma_t_of(self.full)

    def gamma_2_of(self, S):
        return self.memo(("gam2", S), lambda: _lib.w_gamma_2(self._carr, S))

    @property
    def gamma_2(self):
        return self.gamma_2_of(self.full)

    @property
    def gamma_c(self):
        def mk():
            _guard(self.full)
            return _lib.w_gamma_c(self._carr, self.full)
        return self.memo("gamc", mk)

    @property
    def is_forest(self):
        return self.m == self.n - self.ncomp(self.full)

    @property
    def Ls(self):
        """max number of leaves of a spanning tree (G connected)."""
        def mk():
            if self.n == 1:
                return 0
            if self.n == 2:
                return 2
            if self.m == self.n - 1:     # G is a tree: its only spanning tree is itself
                return self.f1
            return self.n - self.gamma_c
        return self.memo("Ls", mk)

    def i_of(self, S):
        return self.memo(("idom", S), lambda: _lib.w_indep_dom(self._carr, S))

    @property
    def i(self):
        return self.i_of(self.full)

    def alpha_k_of(self, S, k):
        return self.memo(("alk", S, k), lambda: _lib.w_alpha_k(self._carr, S, k))

    @property
    def alpha_2(self):
        return self.alpha_k_of(self.full, 2)

    @property
    def b(self):
        return self.memo("b", lambda: self.n if self.is_forest else (_guard(self.full), _lib.w_bip(self._carr, self.full))[1])

    @property
    def f(self):
        return self.memo("f", lambda: self.n if self.is_forest else (_guard(self.full), _lib.w_forest(self._carr, self.full))[1])

    @property
    def tree_num(self):
        return self.memo("tree", lambda: self.n if (self.is_forest and self.connected()) else (_guard(self.full), _lib.w_tree(self._carr, self.full))[1])

    def path_num_of(self, S):  # largest induced path (vertices)
        return self.memo(("ipath", S), lambda: (_guard(S), _lib.w_ipath(self._carr, S))[1])

    @property
    def path_num(self):
        if self.m == self.n - 1 and self.connected():   # tree: longest path is induced
            return self.diam + 1
        return self.path_num_of(self.full)

    @property
    def traceable(self):
        return self.memo("trace", lambda: (_guard(self.full), _lib.w_traceable(self._carr, self.full) == 1)[1])

    def _forest_path_cover(self, S):
        """exact path cover number of a forest G[S]: n - max linear-forest edges (greedy on rooted trees)."""
        used_edges = 0
        seen = 0
        for root in bits(S):
            if seen >> root & 1:
                continue
            # iterative DFS order
            order, parent = [], {root: -1}
            stack = [root]
            seen |= 1 << root
            while stack:
                v = stack.pop()
                order.append(v)
                for w in bits(self.adj[v] & S & ~seen):
                    seen |= 1 << w
                    parent[w] = v
                    stack.append(w)
            avail = {}
            for v in reversed(order):
                k = sum(1 for w in bits(self.adj[v] & S) if parent.get(w) == v and avail[w])
                take = min(k, 2)
                used_edges += take
                avail[v] = take < 2
        return pc(S) - used_edges

    def p_of(self, S):  # path covering number of G[S]
        def mk():
            if pc(S) == 0:
                return 0
            if self.edges_in(S) == pc(S) - self.ncomp(S):  # forest
                return self._forest_path_cover(S)
            if pc(S) <= 24 and self.connected(S) and _lib.w_traceable(self._carr, S) == 1:
                return 1
            _guard(S, 18)
            r = _lib.w_path_cover(self._carr, S)
            if r < 0:
                raise Undefined("too large for path cover DP")
            return r
        return self.memo(("pcov", S), mk)

    @property
    def p(self):
        return self.p_of(self.full)

    def mu_of(self, S):
        def mk():
            if pc(S) <= 1:
                return 0
            g = self.sub(S).to_nx()
            return len(nx.max_weight_matching(g, maxcardinality=True))
        return self.memo(("mu", S), mk)

    @property
    def mu(self):
        return self.mu_of(self.full)

    def indsets_info(self, S=None):
        S = self.full if S is None else S

        def mk():
            _guard(S, 30)
            out = (ctypes.c_long * 9)()
            out2 = (_u64 * 3)()
            _lib.w_indsets(self._carr, S, out, out2)
            return dict(alpha=out[0], nmax=out[1], dmax=out[2], alpha_crit=out[3], nmaximal=out[4],
                        i=out[5], amaxl=out[6], dmax_ne=out[7], alpha_crit_ne=out[8],
                        core=int(out2[0]), H=int(out2[1]), H_ne=int(out2[2]))
        return self.memo(("indinfo", S), mk)

    @property
    def H(self):  # union of all maximum critical independent sets
        return self.indsets_info()["H"]

    @property
    def H_ne(self):  # same, critical sets taken among NONEMPTY independent sets (alternative reading)
        return self.indsets_info()["H_ne"]

    @property
    def alpha_crit(self):
        return self.indsets_info()["alpha_crit"]

    @property
    def core(self):  # intersection of all maximum independent sets
        return self.indsets_info()["core"]

    @property
    def u(self):  # 1 iff unique maximum independent set
        return 1 if self.indsets_info()["nmax"] == 1 else 0

    def minimal_tds_range(self):
        def mk():
            _guard(self.full, 22)
            out = (ctypes.c_int * 2)()
            _lib.w_minimal_tds(self._carr, self.full, out)
            return out[0], out[1]
        return self.memo("mtds", mk)

    @property
    def wtd(self):
        mn, mx = self.minimal_tds_range()
        if mx < 0:
            raise Undefined("no TDS")
        return mn == mx

    @property
    def kappa(self):
        def mk():
            if self.n <= 1:
                return 0
            g = self.to_nx()
            if nx.is_isomorphic(g, nx.complete_graph(self.n)):
                return self.n - 1
            return nx.node_connectivity(g)
        return self.memo("kappa", mk)

    @property
    def cut_vertices(self):
        return self.memo("cutv", lambda: self.mask(nx.articulation_points(self.to_nx())))

    @property
    def girth(self):
        def mk():
            g = nx.girth(self.to_nx())
            return g  # inf for forests
        return self.memo("girth", mk)

    @property
    def c4free(self):
        """1 iff no C4 subgraph (not nec. induced): no two vertices share 2 common neighbours."""
        for u in range(self.n):
            for v in range(u + 1, self.n):
                if pc(self.adj[u] & self.adj[v]) >= 2:
                    return 0
        return 1

    @property
    def bipartite(self):
        return 1 if nx.is_bipartite(self.to_nx()) else 0

    @property
    def is_tree(self):
        return self.connected() and self.m == self.n - 1

    @property
    def regular(self):
        return self.delta == self.Delta

    def packing(self):
        """2-packing number: max set with pairwise distance >= 3."""
        def mk():
            sq = self.sq
            return sq.alpha
        return self.memo("pack", mk)
