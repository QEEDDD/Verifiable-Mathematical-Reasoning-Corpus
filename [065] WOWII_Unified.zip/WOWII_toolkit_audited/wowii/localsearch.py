"""Simulated-annealing counterexample search: minimise the largest slack over gate-surviving readings.

usage: python3 localsearch.py GATE.json OUT.jsonl cid[,cid...] [--n 10,12,14] [--iters 3000] [--restarts 4] [--seed 1]
A state is a connected graph (or a tree for tree-domain conjectures).  Moves: edge toggles / leaf regrafts.
"""
import json
import math
import os
import random
import sys
import time
from fractions import Fraction as Fr

import networkx as nx

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lib import Gr, Undefined  # noqa: E402
import big  # noqa: E402
import conj as C  # noqa: E402

big.install()
BIGSLACK = 50


def slack_of(cid, G, keep):
    """Max slack over all selected readings; None if any is unevaluated.

    A negative result certifies every empirically selected executable reading
    failed.  It makes no claim about the source's intended interpretation.
    """
    try:
        if not C.HYP[cid](G):
            return None
        rds = list(C.CONJ[cid](G))
    except (Undefined, ZeroDivisionError):
        return None
    if keep is not None and not set(keep).issubset({label for _, label, _, _ in rds}):
        return None
    vals = []
    for kind, label, a, b in rds:
        if keep is not None and label not in keep:
            continue
        try:
            if kind == "imp":
                if not a():
                    vals.append(Fr(BIGSLACK // 5))
                    continue
                vals.append(Fr(1) if b() else Fr(-1))
                continue
            rhs, lhs = b(), a()
        except (Undefined, ZeroDivisionError):
            return None
        fl = lambda x: Fr(x) if not hasattr(x, "q") else Fr(float(x)).limit_denominator(10 ** 6)
        lhs, rhs = fl(lhs), fl(rhs)
        vals.append((rhs - lhs) if kind == "le" else (lhs - rhs))
    return max(vals) if vals else None


def random_connected(n, R):
    while True:
        g = nx.gnp_random_graph(n, R.uniform(1.2, 4.0) / n * 1.0 + R.random() * 0.3, seed=R.randint(0, 10 ** 9))
        if nx.is_connected(g):
            return g


def mutate(g, R, tree):
    h = g.copy()
    n = h.number_of_nodes()
    if tree:
        # prune a random leaf-subtree edge and regraft it elsewhere
        u, v = R.choice(list(h.edges()))
        h.remove_edge(u, v)
        comps = list(nx.connected_components(h))
        A = comps[0] if u in comps[0] else comps[1]
        B = comps[1] if A is comps[0] else comps[0]
        a = R.choice(list(A)); b = R.choice(list(B))
        h.add_edge(a, b)
        return h
    for _ in range(20):
        k = R.random()
        if k < 0.45:
            u, v = R.sample(range(n), 2)
            if h.has_edge(u, v):
                h.remove_edge(u, v)
                if not nx.is_connected(h):
                    h.add_edge(u, v)
                    continue
            else:
                h.add_edge(u, v)
            return h
        elif k < 0.75:   # move an edge endpoint
            u, v = R.choice(list(h.edges()))
            w = R.randrange(n)
            if w in (u, v) or h.has_edge(u, w):
                continue
            h.remove_edge(u, v); h.add_edge(u, w)
            if nx.is_connected(h):
                return h
            h.remove_edge(u, w); h.add_edge(u, v)
        else:            # add a pendant-ish rewiring: detach a vertex and attach to random neighbours
            v = R.randrange(n)
            old = list(h[v])
            h.remove_edges_from([(v, x) for x in old])
            k2 = R.randint(1, 3)
            for x in R.sample([y for y in range(n) if y != v], k2):
                h.add_edge(v, x)
            if nx.is_connected(h):
                return h
            h.remove_edges_from(list(h.edges(v)))
            h.add_edges_from((v, x) for x in old)
    return h


def evaluable(cid, keep, n, R, tree, tries=3):
    for _ in range(tries):
        g = nx.random_labeled_tree(n, seed=R.randint(0, 10 ** 9)) if tree else random_connected(n, R)
        t = time.time()
        if slack_of(cid, Gr.from_nx(g), keep) is not None and time.time() - t < 2.0:
            return True
    return False


def anneal(cid, keep, n, iters, R, tree, deadline=None):
    g = nx.random_labeled_tree(n, seed=R.randint(0, 10 ** 9)) if tree else random_connected(n, R)
    cur = slack_of(cid, Gr.from_nx(g), keep)
    tries = 0
    while cur is None and tries < 50:
        g = nx.random_labeled_tree(n, seed=R.randint(0, 10 ** 9)) if tree else random_connected(n, R)
        cur = slack_of(cid, Gr.from_nx(g), keep)
        tries += 1
    if cur is None:
        return None, None
    best, bestg = cur, g
    T0 = 1.0
    for it in range(iters):
        if deadline is not None and time.time() > deadline:
            break
        T = T0 * (1 - it / iters) + 0.01
        h = mutate(g, R, tree)
        s = slack_of(cid, Gr.from_nx(h), keep)
        if s is None:
            continue
        d = float(s - cur)
        if d <= 0 or R.random() < math.exp(-d / T):
            g, cur = h, s
            if cur < best:
                best, bestg = cur, g
                if best < 0:
                    return best, bestg
    return best, bestg


def main():
    gate = json.load(open(sys.argv[1]))
    out = sys.argv[2]
    cids = sys.argv[3].split(",")
    ns, iters, restarts, seed, tlim, auto = [10, 12, 14], 3000, 4, 1, 600, False
    a = sys.argv[4:]
    for i, x in enumerate(a):
        if x == "--n": ns = [int(t) for t in a[i + 1].split(",")]
        if x == "--iters": iters = int(a[i + 1])
        if x == "--restarts": restarts = int(a[i + 1])
        if x == "--seed": seed = int(a[i + 1])
        if x == "--time": tlim = float(a[i + 1])
        if x == "--auto": auto = True
    R = random.Random(seed)
    with open(out, "a") as f:
        for cid in cids:
            keep = set(gate.get(cid, [])) or None
            tree = C.DOMAIN[cid] == "tree"
            t0 = time.time()
            res = {"cid": cid, "best": None, "g6": None, "n": None}
            if auto:
                big_ok = evaluable(cid, keep, 26 if not tree else 40, R, tree)
                if tree:
                    ns_c = [16, 26, 40] if big_ok else [12, 16, 20]
                else:
                    ns_c = [10, 14, 19, 26] if big_ok else [10, 12, 14, 16]
            else:
                ns_c = ns
            per = tlim / (len(ns_c) * restarts)
            for n in ns_c:
                for r in range(restarts):
                    if time.time() - t0 > tlim:
                        break
                    b, g = anneal(cid, keep, n, iters, R, tree, deadline=time.time() + per)
                    if b is None:
                        continue
                    if res["best"] is None or b < Fr(res["best"]):
                        res.update(best=str(b), g6=nx.to_graph6_bytes(nx.convert_node_labels_to_integers(g), header=False).decode().strip(), n=n)
                    if b < 0:
                        break
                if res["best"] is not None and Fr(res["best"]) < 0:
                    break
            res["secs"] = round(time.time() - t0, 1)
            f.write(json.dumps(res) + "\n"); f.flush()
            print(json.dumps(res), flush=True)


if __name__ == "__main__":
    main()
