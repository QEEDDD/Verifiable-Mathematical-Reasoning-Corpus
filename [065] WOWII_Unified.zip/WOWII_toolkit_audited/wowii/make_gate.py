"""Build an empirical reading filter from tested samples, not a source verdict.

Survival means only that a reading was evaluated at least once and no
counterexample was recorded in this run.  Skips supply no positive evidence.
The historical gate/corrupt JSON layouts are retained for existing callers.
"""
import json
import sys


def conjecture_stats(stats):
    return {cid: value for cid, value in stats.items()
            if not cid.startswith("_") and isinstance(value, dict)
            and isinstance(value.get("readings"), dict)}


def build_gate(stats):
    gate, refuted = {}, {}
    for cid, value in conjecture_stats(stats).items():
        readings = value["readings"]
        gate[cid] = [label for label, rd in readings.items()
                     if rd.get("fail", 0) == 0 and rd.get("tested", 0) > 0]
        # No survivor is not enough: every reading might simply be skipped.
        if readings and all(rd.get("fail", 0) > 0 for rd in readings.values()):
            refuted[cid] = {label: rd["examples"][0]
                            for label, rd in readings.items() if rd.get("examples")}
    return gate, refuted


def main():
    with open(sys.argv[1]) as stream:
        stats = json.load(stream)
    records = conjecture_stats(stats)
    gate, refuted = build_gate(stats)
    with open(sys.argv[2], "w") as stream:
        json.dump(gate, stream, indent=1)
    with open(sys.argv[3], "w") as stream:
        json.dump(refuted, stream, indent=1)
    print("Empirical reading filter; this does not determine intended source meanings.")
    print("conjectures:", len(records),
          " all recorded readings have counterexamples in this sample:", len(refuted))
    for cid, readings in refuted.items():
        print("  ", cid, {label: (e["g6"], e.get("lhs"), e.get("rhs"))
                         for label, e in readings.items()})
    print("readings omitted from filter (failed or never evaluated):")
    for cid, value in records.items():
        dropped = [label for label in value["readings"] if label not in gate[cid]]
        if dropped:
            print("  ", cid, dropped)


if __name__ == "__main__":
    main()
