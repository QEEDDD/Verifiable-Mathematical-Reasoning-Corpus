import json, sys
outs = [json.load(open(p)) for p in sys.argv[2:]]
M = {}
for s in outs:
    for c, v in s.items():
        if c.startswith("_"):
            if c == "_timeouts":
                M.setdefault(c, []).extend(v)
            continue
        m = M.setdefault(c, {"domain": v["domain"], "tested": 0, "skipped": 0,
                             "readings": {}, "robust": [], "errors": 0})
        m["tested"] += v["tested"]; m["errors"] += v["errors"]
        m["skipped"] += v.get("skipped", 0)
        for reason, count in v.get("skip_reasons", {}).items():
            reasons = m.setdefault("skip_reasons", {})
            reasons[reason] = reasons.get(reason, 0) + count
        if v.get("skipped_examples"):
            m["skipped_examples"] = (m.get("skipped_examples", []) + v["skipped_examples"])[:3]
        if v.get("errmsg"): m.setdefault("errmsg", []).extend(v["errmsg"])
        for k, r in v["readings"].items():
            mr = m["readings"].setdefault(k, {"tested": 0, "fail": 0, "examples": [],
                                            "skipped": 0, "skip_reasons": {},
                                            "skipped_examples": [], "premise_false": 0})
            mr["tested"] += r["tested"]; mr["fail"] += r["fail"]
            mr["skipped"] += r.get("skipped", 0)
            mr["premise_false"] += r.get("premise_false", 0)
            for reason, count in r.get("skip_reasons", {}).items():
                mr["skip_reasons"][reason] = mr["skip_reasons"].get(reason, 0) + count
            mr["skipped_examples"] = (mr["skipped_examples"] + r.get("skipped_examples", []))[:3]
            mr["examples"] = sorted(mr["examples"] + r["examples"], key=lambda e: (e["n"], e["m"]))[:3]
        m["robust"] = sorted(m["robust"] + v["robust"], key=lambda e: (e["n"], e["m"]))[:3]
json.dump(M, open(sys.argv[1], "w"), indent=1)
