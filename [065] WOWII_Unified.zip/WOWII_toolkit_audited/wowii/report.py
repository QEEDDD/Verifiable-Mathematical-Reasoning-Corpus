import json, sys
s = json.load(open(sys.argv[1]))
for c, v in s.items():
    if c.startswith("_"):
        continue
    fails = {k: r for k, r in v["readings"].items() if r["fail"]}
    if not fails and not v.get("skipped", 0):
        continue
    print(f"== {c} [{v['domain']}] tested={v['tested']} skipped={v.get('skipped', 0)} robust={len(v['robust'])}")
    for k, r in v["readings"].items():
        ex = r["examples"][0] if r["examples"] else None
        status = "FAIL" if r["fail"] else "UNTESTED" if r["tested"] == 0 else "no failure observed"
        print(f"   {status} {k}: {r['fail']}/{r['tested']} skipped={r.get('skipped', 0)}  {ex if ex else ''}")
        for reason, count in r.get("skip_reasons", {}).items():
            print(f"      skipped {count}: {reason}")
    for reason, count in v.get("skip_reasons", {}).items():
        print(f"   skipped before reading evaluation {count}: {reason}")
