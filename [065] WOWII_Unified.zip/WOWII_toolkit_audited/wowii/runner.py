"""Sweep conjecture readings over graph lists.

usage: python3 runner.py OUT.json SOURCE[,SOURCE...] [--only id,id | --only-file F] [--shard k/K] [--gate gate.json]
                         [--big] [--per-graph SECONDS] [--every N]
SOURCE: conn<n> | tree<n> | fam  (files in db/), or a path to a .g6 file.
Keeps, per conjecture: tested and skipped counts per reading, skip reasons,
first failures, and 'robust' failures only when every candidate reading was
evaluated and false.  A gate is an empirical reading filter, not a source audit.
Progress is printed and the JSON is dumped periodically; a per-graph alarm skips pathological graphs.
"""
import json
import os
import signal
import sys
import time
from fractions import Fraction as Fr

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lib import Gr, Undefined  # noqa: E402
import conj as C  # noqa: E402

DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "db")
MAXKEEP = 3


class GraphTimeout(Exception):
    pass


def _alarm(signum, frame):
    raise GraphTimeout()


def load(src):
    path = src if os.path.exists(src) else os.path.join(DB, src + ".g6")
    with open(path) as f:
        return [l.strip() for l in f if l.strip()]


def val(x):
    if isinstance(x, Fr):
        return str(x)
    if isinstance(x, bool):
        return x
    if isinstance(x, (int, float)):
        return x
    return repr(x)


def evaluate(cid, G, diagnostics=None):
    """Return the historical result list; optionally report unevaluated readings.

    ``diagnostics`` receives ``labels`` and ``skipped`` lists.  A skipped
    reading is never a passing or tested reading.  A None label means the
    hypothesis or reading generator could not be evaluated.
    """
    if diagnostics is None:
        diagnostics = {}
    diagnostics.setdefault("labels", [])
    diagnostics.setdefault("skipped", [])

    def skipped(label, exc, stage="reading"):
        diagnostics["skipped"].append({"label": label, "stage": stage,
                                       "reason": f"{type(exc).__name__}: {exc}"})

    try:
        if not C.HYP[cid](G):
            return None
    except (Undefined, ZeroDivisionError) as exc:
        skipped(None, exc, "hypothesis")
        return None
    res = []
    try:
        for kind, label, a, b in C.CONJ[cid](G):
            diagnostics["labels"].append(label)
            try:
                if kind == "imp":
                    prem = a()
                    if not prem:
                        res.append((label, True, None, "premise-false"))
                        continue
                    concl = b()
                    res.append((label, bool(concl), None, {"premise": True, "conclusion": val(concl)}))
                else:
                    rhs = b()
                    lhs = a()
                    ok = (lhs <= rhs) if kind == "le" else (lhs >= rhs)
                    res.append((label, bool(ok), None, {"lhs": val(lhs), "rhs": val(rhs)}))
            except (Undefined, ZeroDivisionError) as exc:
                skipped(label, exc)
            except GraphTimeout as exc:
                skipped(label, exc)
                raise
    except (Undefined, ZeroDivisionError) as exc:
        skipped(None, exc, "reading-generator")
    return res


def reading_stats(st, label):
    return st["readings"].setdefault(label, {
        "tested": 0, "fail": 0, "examples": [], "premise_false": 0,
        "skipped": 0, "skip_reasons": {}, "skipped_examples": [],
    })


def record_skips(st, G, g6, diagnostics):
    """Count blocked evaluations separately, including solver size guards."""
    for item in diagnostics.get("skipped", []):
        st["skipped"] = st.get("skipped", 0) + 1
        target = st if item["label"] is None else reading_stats(st, item["label"])
        if target is not st:
            target["skipped"] += 1
        reasons = target.setdefault("skip_reasons", {})
        reasons[item["reason"]] = reasons.get(item["reason"], 0) + 1
        examples = target.setdefault("skipped_examples", [])
        if len(examples) < MAXKEEP:
            examples.append({"g6": g6, "n": G.n, "m": G.m, **item})


def record_results(st, G, g6, results, diagnostics, gate_readings=None):
    """Record results, requiring full candidate coverage for a robust failure."""
    if not results:
        return
    st["tested"] += 1
    for label, ok, _, info in results:
        rd = reading_stats(st, label)
        rd["tested"] += 1
        if info == "premise-false":
            rd["premise_false"] += 1
        if not ok:
            rd["fail"] += 1
            if len(rd["examples"]) < MAXKEEP:
                rd["examples"].append({"g6": g6, "n": G.n, "m": G.m,
                                       **(info if isinstance(info, dict) else {})})

    candidates = set(diagnostics.get("labels", [])) if gate_readings is None else set(gate_readings)
    selected = [r for r in results if r[0] in candidates]
    blocked = any(item["label"] is None or item["label"] in candidates
                  for item in diagnostics.get("skipped", []))
    complete = candidates and not blocked and {r[0] for r in selected} == candidates
    if complete and all(not ok for _, ok, _, _ in selected):
        st["robust"].append({"g6": g6, "n": G.n, "m": G.m,
                             "scope": "all executable readings" if gate_readings is None
                                      else "empirical gate-selected executable readings",
                             "candidate_readings": sorted(candidates),
                             "detail": {lab: inf for lab, ok, _, inf in selected}})


def main():
    out = sys.argv[1]
    sources = sys.argv[2].split(",")
    only, shard, gate, per_graph, every = None, (0, 1), None, 60, 500
    args = sys.argv[3:]
    for i, a in enumerate(args):
        if a == "--only":
            only = set(args[i + 1].split(","))
        if a == "--only-file":
            only = set(open(args[i + 1]).read().strip().split(","))
        if a == "--shard":
            k, K = args[i + 1].split("/")
            shard = (int(k), int(K))
        if a == "--gate":
            gate = json.load(open(args[i + 1]))
        if a == "--big":
            import big
            big.install()
        if a == "--per-graph":
            per_graph = int(args[i + 1])
        if a == "--every":
            every = int(args[i + 1])
    ids = [c for c in C.CONJ if only is None or c in only]
    stats = {c: {"domain": C.DOMAIN[c], "tested": 0, "skipped": 0,
                 "readings": {}, "robust": [], "errors": 0} for c in ids}
    done_robust = set()
    timeouts = []
    signal.signal(signal.SIGALRM, _alarm)
    t0 = time.time()

    def dump():
        tmp = out + ".tmp"
        with open(tmp, "w") as f:
            json.dump({**stats, "_timeouts": timeouts}, f, indent=1)
        os.replace(tmp, out)

    def run_graph(G, s):
        is_tree = G.m == G.n - 1
        for cid in ids:
            if cid in done_robust:
                continue
            if C.DOMAIN[cid] == "tree" and (not is_tree or G.n < 3):
                continue
            diagnostics = {}
            try:
                r = evaluate(cid, G, diagnostics)
            except GraphTimeout:
                raise
            except Exception as e:  # bug guard
                stats[cid]["errors"] += 1
                if stats[cid]["errors"] <= 2:
                    stats[cid].setdefault("errmsg", []).append(f"{s}: {type(e).__name__}: {e}")
                continue
            finally:
                record_skips(stats[cid], G, s, diagnostics)
            st = stats[cid]
            keep = gate[cid] if gate is not None and cid in gate else None
            record_results(st, G, s, r, diagnostics, keep)
            if len(st["robust"]) >= MAXKEEP:
                done_robust.add(cid)

    k = 0
    for src in sources:
        gs = load(src)
        for gi, s in enumerate(gs):
            if gi % shard[1] != shard[0]:
                continue
            k += 1
            G = Gr.from_g6(s)
            signal.alarm(per_graph)
            try:
                run_graph(G, s)
            except GraphTimeout:
                timeouts.append(s)
            finally:
                signal.alarm(0)
            if k % every == 0:
                print(f"{src} {gi}/{len(gs)} {time.time()-t0:.0f}s timeouts={len(timeouts)}", flush=True)
                dump()
    dump()
    nfail = sum(1 for c in ids if any(r["fail"] for r in stats[c]["readings"].values()))
    nrob = sum(1 for c in ids if stats[c]["robust"])
    print(f"done {time.time()-t0:.0f}s: conjectures with some failing reading: {nfail}; "
          f"with robust counterexample: {nrob}; timeouts: {len(timeouts)}", flush=True)


if __name__ == "__main__":
    main()
