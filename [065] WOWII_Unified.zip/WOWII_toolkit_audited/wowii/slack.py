"""Slack statistics per gate-surviving reading: min slack, #tight, tight examples (for proof triage)."""
import json
import os
import sys
from fractions import Fraction as Fr

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lib import Gr, Undefined  # noqa: E402
import conj as C  # noqa: E402

DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "db")


def main():
    gate = json.load(open(sys.argv[1]))
    out = sys.argv[2]
    srcs = sys.argv[3].split(",")
    st = {}
    for src in srcs:
        for line in open(os.path.join(DB, src + ".g6")):
            s = line.strip()
            G = Gr.from_g6(s)
            is_tree = G.m == G.n - 1
            for cid, fn in C.CONJ.items():
                if C.DOMAIN[cid] == "tree" and (not is_tree or G.n < 3):
                    continue
                try:
                    if not C.HYP[cid](G):
                        continue
                    rds = list(fn(G))
                except Undefined:
                    continue
                for kind, label, a, b in rds:
                    if label not in gate.get(cid, []):
                        continue
                    rec = st.setdefault(cid, {}).setdefault(label, {"n": 0, "min": None, "tight": 0, "ex": [], "prem": 0})
                    try:
                        if kind == "imp":
                            p = a()
                            rec["n"] += 1
                            if p:
                                rec["prem"] += 1
                                if len(rec["ex"]) < 4:
                                    rec["ex"].append(s)
                            continue
                        rhs, lhs = b(), a()
                    except (Undefined, ZeroDivisionError):
                        continue
                    fl = lambda x: Fr(x) if not hasattr(x, "q") else Fr(float(x)).limit_denominator(10 ** 6)
                    lhs_, rhs_ = fl(lhs), fl(rhs)
                    sl = (rhs_ - lhs_) if kind == "le" else (lhs_ - rhs_)
                    rec["n"] += 1
                    if rec["min"] is None or sl < Fr(rec["min"]):
                        rec["min"] = str(sl)
                    if sl == 0:
                        rec["tight"] += 1
                        if len(rec["ex"]) < 4:
                            rec["ex"].append(s)
    json.dump(st, open(out, "w"), indent=1)


if __name__ == "__main__":
    main()
