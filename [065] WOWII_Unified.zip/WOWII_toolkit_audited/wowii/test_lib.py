"""Cross-check lib.py against slow independent Python/networkx implementations."""
import itertools
import random
import sys

import networkx as nx

sys.path.insert(0, __import__("os").path.dirname(__file__))
from lib import Gr, bits, pc  # noqa: E402


def subsets(n):
    for r in range(n + 1):
        for c in itertools.combinations(range(n), r):
            yield set(c)


def slow(g):
    n = g.number_of_nodes()
    V = set(range(n))
    N = {v: set(g[v]) for v in V}
    res = {}
    ind = [S for S in subsets(n) if all(not (N[v] & S) for v in S)]
    res["alpha"] = max(len(S) for S in ind)
    dom = lambda S: all(v in S or (N[v] & S) for v in V)
    res["gamma"] = min(len(S) for S in subsets(n) if dom(S))
    tds = [S for S in subsets(n) if all(N[v] & S for v in V)]
    res["gamma_t"] = min(len(S) for S in tds) if tds else None
    res["gamma_2"] = min(len(S) for S in subsets(n) if all(v in S or len(N[v] & S) >= 2 for v in V))
    maxl = [S for S in ind if dom(S)]
    res["i"] = min(len(S) for S in maxl)
    res["alpha_2"] = max(len(S) for S in subsets(n) if all(len(N[v] & S) <= 1 for v in S))
    sub = lambda S: g.subgraph(S)
    res["b"] = max(len(S) for S in subsets(n) if len(S) == 0 or nx.is_bipartite(sub(S)))
    res["f"] = max(len(S) for S in subsets(n) if len(S) == 0 or nx.is_forest(sub(S)))
    res["tree"] = max(len(S) for S in subsets(n) if S and nx.is_tree(sub(S)))
    res["ipath"] = max(len(S) for S in subsets(n) if S and nx.is_tree(sub(S)) and max(dict(sub(S).degree()).values()) <= 2)
    # spanning tree max leaves
    if nx.is_connected(g):
        if n == 1:
            res["Ls"] = 0
        elif n == 2:
            res["Ls"] = 2
        else:
            best = 0
            for T in nx.SpanningTreeIterator(g):
                best = max(best, sum(1 for v in T if T.degree(v) == 1))
            res["Ls"] = best
    # traceable
    res["trace"] = any(all(g.has_edge(p[i], p[i + 1]) for i in range(n - 1)) for p in itertools.permutations(range(n)))
    # path cover
    def is_tr(S):
        S = list(S)
        if len(S) == 1:
            return True
        return any(all(g.has_edge(p[i], p[i + 1]) for i in range(len(p) - 1)) for p in itertools.permutations(S))
    trace_sets = [frozenset(S) for S in subsets(n) if S and is_tr(S)]
    best = {frozenset(): 0}
    for S in sorted((frozenset(S) for S in subsets(n)), key=len):
        if not S:
            continue
        lo = min(S)
        best[S] = min(1 + best[S - T] for T in trace_sets if lo in T and T <= S)
    res["p"] = best[frozenset(V)]
    res["mu"] = len(nx.max_weight_matching(g, maxcardinality=True))
    # critical independence
    dvals = [((len(S) - len(set().union(*[N[v] for v in S]))) if S else 0, S) for S in ind]
    dmax = max(d for d, _ in dvals)
    crit = [S for d, S in dvals if d == dmax]
    ac = max(len(S) for S in crit)
    res["alpha_crit"] = ac
    res["H"] = set().union(*[S for S in crit if len(S) == ac])
    mis = [S for S in ind if len(S) == res["alpha"]]
    res["core"] = set.intersection(*mis)
    res["u"] = 1 if len(mis) == 1 else 0
    # wtd
    if tds:
        mins = [S for S in tds if all(not all(N[v] & (S - {x}) for v in V) for x in S)]
        res["wtd"] = len(set(len(S) for S in mins)) == 1
    return res


def fast(G):
    r = dict(alpha=G.alpha, gamma=G.gamma, gamma_2=G.gamma_2, i=G.i, alpha_2=G.alpha_2, b=G.b, f=G.f,
             tree=G.tree_num, ipath=G.path_num, trace=G.traceable, p=G.p, mu=G.mu,
             alpha_crit=G.alpha_crit, H=set(bits(G.H)), core=set(bits(G.core)), u=G.u)
    try:
        r["gamma_t"] = G.gamma_t
    except Exception:
        r["gamma_t"] = None
    if G.connected():
        r["Ls"] = G.Ls
    try:
        r["wtd"] = G.wtd
    except Exception:
        pass
    return r


if __name__ == "__main__":
    random.seed(1)
    bad = 0
    cnt = 0
    for trial in range(400):
        n = random.randint(1, 8)
        p = random.random()
        g = nx.gnp_random_graph(n, p, seed=random.randint(0, 10**9))
        G = Gr.from_nx(g)
        s, f = slow(g), fast(G)
        for k in s:
            if s[k] != f.get(k):
                bad += 1
                print("MISMATCH", k, s[k], f.get(k), nx.to_graph6_bytes(g, header=False))
        cnt += 1
    print("tested", cnt, "graphs; mismatches:", bad)
