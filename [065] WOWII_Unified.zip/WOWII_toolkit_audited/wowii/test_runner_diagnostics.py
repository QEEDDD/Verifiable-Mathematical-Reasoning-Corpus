"""Regression tests for skipped readings and empirical-gate accounting.

Run after compiling libwcore.so: python -m unittest test_runner_diagnostics -v
Requires the toolkit's networkx and ortools dependencies; no CP-SAT search is run.
"""
import json
import contextlib
import io
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import networkx as nx

import conj
import make_gate
import runner
from lib import Gr, Undefined

HERE = Path(__file__).resolve().parent


def empty_stats():
    return {"domain": "conn", "tested": 0, "skipped": 0,
            "readings": {}, "robust": [], "errors": 0}


def blocked():
    raise Undefined("deliberate solver limit")


class DiagnosticTests(unittest.TestCase):
    def setUp(self):
        self.G = Gr.from_nx(nx.path_graph(3))

    def synthetic(self, readings, gate=None):
        diag = {}
        with patch.dict(conj.CONJ, {"test": lambda G: iter(readings)}), \
             patch.dict(conj.HYP, {"test": lambda G: True}):
            result = runner.evaluate("test", self.G, diag)
        stats = empty_stats()
        runner.record_skips(stats, self.G, "test-graph", diag)
        runner.record_results(stats, self.G, "test-graph", result, diag, gate)
        return stats

    def test_kg73_guard_is_reported_and_old_signature_still_works(self):
        G = Gr.from_nx(nx.kneser_graph(7, 3))
        diag = {}
        self.assertEqual(runner.evaluate("108", G, diag), [])
        self.assertEqual(runner.evaluate("108", G), [])
        self.assertEqual(G.n, 35)
        self.assertEqual(len(diag["skipped"]), 1)
        self.assertIn("too large for brute force", diag["skipped"][0]["reason"])
        stats = empty_stats()
        runner.record_skips(stats, G, "kg73", diag)
        runner.record_results(stats, G, "kg73", [], diag)
        rd = next(iter(stats["readings"].values()))
        self.assertEqual((stats["tested"], rd["tested"], rd["fail"], rd["skipped"]), (0, 0, 0, 1))
        self.assertEqual(stats["robust"], [])

    def test_skipped_candidate_blocks_all_reading_failure(self):
        readings = [("le", "fails", lambda: 2, lambda: 1),
                    ("le", "blocked", lambda: 0, blocked)]
        stats = self.synthetic(readings)
        self.assertEqual(stats["readings"]["fails"]["fail"], 1)
        self.assertEqual(stats["readings"]["blocked"]["tested"], 0)
        self.assertEqual(stats["robust"], [])
        selected = self.synthetic(readings, ["fails"])
        self.assertEqual(len(selected["robust"]), 1)
        self.assertEqual(selected["robust"][0]["scope"], "empirical gate-selected executable readings")
        self.assertEqual(self.synthetic(readings, ["fails", "missing"])["robust"], [])

    def test_false_premise_is_a_pass_and_blocks_all_reading_failure(self):
        stats = self.synthetic([("le", "fails", lambda: 2, lambda: 1),
                                ("imp", "vacuous", lambda: False, blocked)])
        self.assertEqual(stats["readings"]["vacuous"]["premise_false"], 1)
        self.assertEqual(stats["robust"], [])

    def test_hypothesis_and_generator_skips_are_distinct(self):
        def bad_generator(G):
            yield ("le", "fails", lambda: 2, lambda: 1)
            raise Undefined("cannot generate remaining readings")
        diag = {}
        with patch.dict(conj.CONJ, {"test": bad_generator}), \
             patch.dict(conj.HYP, {"test": lambda G: True}):
            result = runner.evaluate("test", self.G, diag)
        self.assertEqual(diag["skipped"][0]["stage"], "reading-generator")
        stats = empty_stats()
        runner.record_skips(stats, self.G, "test-graph", diag)
        runner.record_results(stats, self.G, "test-graph", result, diag)
        self.assertEqual(stats["robust"], [])
        diag = {}
        with patch.dict(conj.HYP, {"test": lambda G: blocked()}):
            self.assertIsNone(runner.evaluate("test", self.G, diag))
        self.assertEqual(diag["skipped"][0]["stage"], "hypothesis")

    def test_gate_accepts_legacy_stats_but_not_skip_only_evidence(self):
        records = {"_timeouts": ["x"], "_meta": {"note": "metadata"},
                   "legacy": {"readings": {"pass": {"tested": 4, "fail": 0, "examples": []}}},
                   "unknown": {"readings": {"skip": {"tested": 0, "fail": 0, "skipped": 4, "examples": []}}}}
        gate, refuted = make_gate.build_gate(records)
        self.assertEqual(gate, {"legacy": ["pass"], "unknown": []})
        self.assertEqual(refuted, {})

    def test_local_search_and_certificate_require_all_selected_readings(self):
        import localsearch
        import check_cex
        readings = [("le", "fails", lambda: 2, lambda: 1),
                    ("le", "blocked", lambda: 0, blocked)]
        g6 = nx.to_graph6_bytes(nx.path_graph(3), header=False).decode().strip()
        with patch.dict(conj.CONJ, {"test": lambda G: iter(readings)}), \
             patch.dict(conj.HYP, {"test": lambda G: True}), \
             patch.dict(conj.DOMAIN, {"test": "conn"}), \
             patch.dict(check_cex.GATE, {"test": ["fails", "blocked"]}), \
             patch.object(check_cex.verify, "slow", return_value={}), \
             patch.object(check_cex.verify, "fast", return_value={}):
            self.assertIsNone(localsearch.slack_of("test", self.G, ["fails", "blocked"]))
            self.assertIsNone(localsearch.slack_of("test", self.G, ["fails", "missing"]))
            self.assertLess(localsearch.slack_of("test", self.G, ["fails"]), 0)
            result = check_cex.evaluate("test", g6)
            self.assertFalse(result["violates_all_survivors"])
            self.assertTrue(result["violates_some_survivor"])
            self.assertEqual(result["unevaluated_survivors"], ["blocked"])

    def test_collection_does_not_promote_empirical_gate_to_source_verdict(self):
        import collect
        with tempfile.TemporaryDirectory() as tmp:
            fixtures = {"gate.json": {"108": []},
                        "corrupt.json": {"108": {"reading": {"g6": "example"}}},
                        "main.json": {"_timeouts": ["example"], "108": empty_stats()},
                        "fam.json": {"_meta": {"note": "metadata"}}}
            with patch.object(collect, "WORK", tmp), \
                 patch.object(collect, "load_json", side_effect=lambda path, default: fixtures[Path(path).name]), \
                 patch.object(collect, "load_jsonl", return_value=[]), \
                 patch.dict(conj.CONJ, {"108": conj.CONJ["108"]}, clear=True), \
                 contextlib.redirect_stdout(io.StringIO()):
                collect.main()
            result = json.loads((Path(tmp) / "status.json").read_text())[0]
            self.assertIn("gate_sample_counterexamples", result)
            self.assertNotIn("false_as_written", result)

    def test_cli_metadata_pipeline_and_merged_skip_counts(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            graphs = tmp / "kg73.g6"
            graphs.write_bytes(nx.to_graph6_bytes(nx.kneser_graph(7, 3), header=False))
            stats, gate, refuted, merged = [tmp / name for name in ("stats.json", "gate.json", "refuted.json", "merged.json")]
            def run(script, *args):
                return subprocess.run([sys.executable, str(HERE / script), *map(str, args)],
                                      check=True, text=True, capture_output=True).stdout
            run("runner.py", stats, graphs, "--only", "108")
            raw = json.loads(stats.read_text())
            self.assertEqual(raw["_timeouts"], [])
            self.assertEqual(raw["108"]["skipped"], 1)
            output = run("make_gate.py", stats, gate, refuted)
            self.assertIn("Empirical reading filter", output)
            self.assertEqual(json.loads(gate.read_text()), {"108": []})
            self.assertEqual(json.loads(refuted.read_text()), {})
            run("merge.py", merged, stats, stats)
            joined = json.loads(merged.read_text())
            self.assertEqual(joined["108"]["skipped"], 2)
            self.assertEqual(next(iter(joined["108"]["readings"].values()))["skipped"], 2)
            output = run("report.py", merged)
            self.assertIn("UNTESTED", output)
            self.assertIn("too large for brute force", output)


if __name__ == "__main__":
    unittest.main()
