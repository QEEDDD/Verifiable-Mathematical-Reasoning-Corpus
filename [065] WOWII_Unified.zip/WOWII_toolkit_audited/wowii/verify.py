"""Independent re-computation of base invariants (networkx / itertools / own CP-SAT models),
to cross-check lib.py values on reported counterexample graphs.

usage: python3 verify.py G6 [G6 ...]     -> prints any disagreement with lib.py
"""
import itertools
import sys

import networkx as nx
from ortools.sat.python import cp_model

sys.path.insert(0, __import__("os").path.dirname(__file__))
import lib  # noqa: E402
import big  # noqa: E402

big.install()


def subsets_by_size(nodes, increasing=True):
    rng = range(len(nodes) + 1) if increasing else range(len(nodes), -1, -1)
    for r in rng:
        for c in itertools.combinations(nodes, r):
            yield set(c)


def min_set(g, pred, limit=16):
    nodes = list(g)
    if len(nodes) > limit:
        return None
    for S in subsets_by_size(nodes):
        if pred(S):
            return len(S)
    return None


def max_set(g, pred, limit=16):
    nodes = list(g)
    if len(nodes) > limit:
        return None
    for S in subsets_by_size(nodes, increasing=False):
        if pred(S):
            return len(S)
    return None


def cp_min(g, kind):
    m = cp_model.CpModel()
    x = {v: m.NewBoolVar(str(v)) for v in g}
    for v in g:
        nb = [x[u] for u in g[v]]
        if kind == "dom":
            m.Add(x[v] + sum(nb) >= 1)
        elif kind == "tdom":
            m.Add(sum(nb) >= 1)
        elif kind == "dom2":
            m.Add(2 * x[v] + sum(nb) >= 2)
        elif kind == "idom":
            m.Add(x[v] + sum(nb) >= 1)
    if kind == "idom":
        for u, v in g.edges():
            m.Add(x[u] + x[v] <= 1)
    m.Minimize(sum(x.values()))
    s = cp_model.CpSolver(); s.parameters.max_time_in_seconds = 300
    assert s.Solve(m) == cp_model.OPTIMAL
    return int(s.ObjectiveValue())


def cp_alpha2(g):
    m = cp_model.CpModel()
    x = {v: m.NewBoolVar(str(v)) for v in g}
    y = {}
    for u, v in g.edges():
        y[(u, v)] = m.NewBoolVar("")
        m.AddBoolAnd([x[u], x[v]]).OnlyEnforceIf(y[(u, v)])
        m.AddBoolOr([x[u].Not(), x[v].Not()]).OnlyEnforceIf(y[(u, v)].Not())
    for v in g:
        inc = [y[e] for e in y if v in e]
        if inc:
            m.Add(sum(inc) <= 1)
    m.Maximize(sum(x.values()))
    s = cp_model.CpSolver(); s.parameters.max_time_in_seconds = 300
    assert s.Solve(m) == cp_model.OPTIMAL
    return int(s.ObjectiveValue())


def slow(g):
    V = set(g)
    n = len(V)
    N = {v: set(g[v]) for v in g}
    r = {}
    comp = nx.complement(g)
    r["alpha"] = max(len(c) for c in nx.find_cliques(comp))
    dom = lambda S: all(v in S or N[v] & S for v in V)
    tdom = lambda S: all(N[v] & S for v in V)
    if n <= 16:
        r["gamma"] = min_set(g, dom)
        r["gamma_t"] = min_set(g, tdom)
        r["gamma_2"] = min_set(g, lambda S: all(v in S or len(N[v] & S) >= 2 for v in V))
        r["i"] = min(len(c) for c in nx.find_cliques(comp))
        r["alpha_2"] = max_set(g, lambda S: all(len(N[v] & S) <= 1 for v in S))
    else:
        r["gamma"] = cp_min(g, "dom"); r["gamma_t"] = cp_min(g, "tdom")
        r["gamma_2"] = cp_min(g, "dom2"); r["i"] = cp_min(g, "idom"); r["alpha_2"] = cp_alpha2(g)
    r["mu"] = len(nx.max_weight_matching(g, maxcardinality=True))
    r["residue"] = None
    seq = sorted((d for _, d in g.degree()), reverse=True)
    while seq and seq[0] > 0:
        d = seq.pop(0)
        seq = sorted([x - 1 if k < d else x for k, x in enumerate(seq)], reverse=True)
    r["residue"] = len(seq)
    r["SW"] = max(nx.core_number(g).values()) if g.number_of_edges() else 0
    r["SWbar"] = max(nx.core_number(comp).values()) if comp.number_of_edges() else 0
    if n <= 14:
        sub = g.subgraph
        r["b"] = max_set(g, lambda S: len(S) == 0 or nx.is_bipartite(sub(S)))
        r["f"] = max_set(g, lambda S: len(S) == 0 or nx.is_forest(sub(S)))
        r["tree"] = max_set(g, lambda S: len(S) > 0 and nx.is_tree(sub(S)))
        r["path"] = max_set(g, lambda S: len(S) > 0 and nx.is_tree(sub(S)) and max(dict(sub(S).degree()).values()) <= 2)
        if nx.is_connected(g) and n >= 3:
            r["gamma_c"] = min_set(g, lambda S: len(S) > 0 and dom(S) and nx.is_connected(sub(S)))
    return r


def fast(G):
    r = dict(alpha=G.alpha, gamma=G.gamma, gamma_t=G.gamma_t, gamma_2=G.gamma_2, i=G.i, alpha_2=G.alpha_2,
             mu=G.mu, residue=G.residue, SW=G.SW, SWbar=G.comp.SW)
    if G.n <= 14:
        r.update(b=G.b, f=G.f, tree=G.tree_num, path=G.path_num)
        if G.connected() and G.n >= 3:
            r["gamma_c"] = G.n - G.Ls if not (G.m == G.n - 1) else G.n - G.f1
    return r


if __name__ == "__main__":
    for s in sys.argv[1:]:
        g = nx.from_graph6_bytes(s.encode())
        a, b = slow(g), fast(lib.Gr.from_g6(s))
        bad = {k: (a[k], b.get(k)) for k in a if a[k] is not None and k in b and a[k] != b[k]}
        print(s, "n=%d" % g.number_of_nodes(), "OK" if not bad else f"MISMATCH {bad}")
