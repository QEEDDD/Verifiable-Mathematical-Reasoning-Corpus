"""Numerical re-test of every conjecture we claim as PROVED (this does not replace the proofs).

For each id, every reading that survived the small-graph gate (out/gate.json) is evaluated on
  - all connected graphs with n <= NMAX (db/conn*.g6 if present, else the networkx atlas, n <= 7),
  - all trees with n <= TMAX (db/tree*.g6 if present, else networkx nonisomorphic_trees),
  - RANDOM random connected graphs (10 <= n <= 16) and random trees (10 <= n <= 40).
Any violation is printed (there should be none).

usage: python3 verify_proved.py [--nmax 8] [--tmax 14] [--random 3000] [--ids 434a,434b,...]
"""
import json
import os
import random
import sys

import networkx as nx

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from lib import Gr, Undefined  # noqa: E402
import big  # noqa: E402
import conj as C  # noqa: E402

big.install()

PROVED = {
    # coordinator proofs (reviewed): see WOWII_proofs.md
    "434a": "coordinator, reviewed", "434b": "coordinator, reviewed",
    # agent proofs (written by sub-agents, NOT yet reviewed)
    "136": "agent", "137": "agent", "96": "agent (public proof also exists)",
    "157": "agent", "161": "agent", "162": "agent", "169": "agent",
    "318": "agent", "320": "agent (public proof also exists)", "321": "agent", "323": "agent",
    "324": "agent", "325": "agent", "326": "agent",
    "233": "agent", "235": "agent", "268": "agent", "290": "agent",
    "241": "agent", "356": "agent", "372": "agent", "377": "agent", "380": "agent",
    "421c": "agent", "432b": "agent",
}


def graphs(nmax, tmax, nrand, seed=2026):
    db = os.path.join(HERE, "db")
    if os.path.exists(os.path.join(db, "conn2.g6")):
        for n in range(2, nmax + 1):
            for l in open(os.path.join(db, f"conn{n}.g6")):
                yield l.strip()
        for n in range(3, tmax + 1):
            p = os.path.join(db, f"tree{n}.g6")
            if os.path.exists(p):
                for l in open(p):
                    yield l.strip()
    else:
        from networkx.generators.atlas import graph_atlas_g
        for g in graph_atlas_g():
            if g.number_of_nodes() >= 2 and nx.is_connected(g):
                yield nx.to_graph6_bytes(g, header=False).decode().strip()
        for n in range(8, tmax + 1):
            for T in nx.nonisomorphic_trees(n):
                yield nx.to_graph6_bytes(T, header=False).decode().strip()
    R = random.Random(seed)
    k = 0
    while k < nrand:
        n = R.randint(10, 16)
        g = nx.gnp_random_graph(n, R.uniform(0.12, 0.7), seed=R.randint(0, 10 ** 9))
        if nx.is_connected(g):
            k += 1
            yield nx.to_graph6_bytes(g, header=False).decode().strip()
    for _ in range(nrand):
        T = nx.random_labeled_tree(R.randint(10, 40), seed=R.randint(0, 10 ** 9))
        yield nx.to_graph6_bytes(T, header=False).decode().strip()


def check(cid, G, keep):
    try:
        if not C.HYP[cid](G):
            return []
        rds = list(C.CONJ[cid](G))
    except (Undefined, ZeroDivisionError):
        return []
    bad = []
    for kind, label, a, b in rds:
        if keep is not None and label not in keep:
            continue
        try:
            if kind == "imp":
                if a() and not b():
                    bad.append(label)
            else:
                rhs, lhs = b(), a()
                if not ((lhs <= rhs) if kind == "le" else (lhs >= rhs)):
                    bad.append(f"{label}: lhs={lhs} rhs={rhs}")
        except (Undefined, ZeroDivisionError):
            pass
    return bad


def main():
    nmax, tmax, nrand, ids = 8, 14, 3000, list(PROVED)
    a = sys.argv[1:]
    for i, x in enumerate(a):
        if x == "--nmax": nmax = int(a[i + 1])
        if x == "--tmax": tmax = int(a[i + 1])
        if x == "--random": nrand = int(a[i + 1])
        if x == "--ids": ids = a[i + 1].split(",")
    gate = json.load(open(os.path.join(HERE, "out", "gate.json")))
    tested = {c: 0 for c in ids}
    viol = {c: [] for c in ids}
    for s in graphs(nmax, tmax, nrand):
        G = Gr.from_g6(s)
        is_tree = G.m == G.n - 1
        for cid in ids:
            if C.DOMAIN[cid] == "tree" and (not is_tree or G.n < 3):
                continue
            b = check(cid, G, set(gate.get(cid, [])) or None)
            tested[cid] += 1
            if b and len(viol[cid]) < 3:
                viol[cid].append((s, b))
    for cid in ids:
        status = "OK" if not viol[cid] else f"VIOLATION {viol[cid]}"
        print(f"{cid:6s} [{PROVED.get(cid, '?')}] tested on {tested[cid]} graphs: {status}")


if __name__ == "__main__":
    main()
