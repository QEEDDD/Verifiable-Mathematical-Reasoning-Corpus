// Exact brute-force graph invariants on induced subgraphs G[U], vertices < 64.
// Every function takes (adj, U): adj[v] = neighbour bitmask, U = vertex subset.
// Intended for |U| <= ~24.  Returns -1 when the object does not exist.
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

typedef uint64_t u64;
#define PC(x) __builtin_popcountll(x)
#define CTZ(x) __builtin_ctzll(x)
#define LOW(x) ((x) & (~(x) + 1))

static inline u64 nbh(const u64 *adj, u64 S) {
    u64 r = 0;
    while (S) { r |= adj[CTZ(S)]; S &= S - 1; }
    return r;
}
static inline u64 reach(const u64 *adj, u64 S, u64 start) {
    u64 seen = start, fr = start;
    while (fr) { u64 nb = nbh(adj, fr) & S & ~seen; seen |= nb; fr = nb; }
    return seen;
}
int w_connected(const u64 *adj, u64 S) { return S ? reach(adj, S, LOW(S)) == S : 0; }
int w_edges(const u64 *adj, u64 S) {
    int e = 0; u64 t = S;
    while (t) { e += PC(adj[CTZ(t)] & S); t &= t - 1; }
    return e / 2;
}
int w_ncomp(const u64 *adj, u64 S) {
    int c = 0;
    while (S) { S &= ~reach(adj, S, LOW(S)); c++; }
    return c;
}
static inline int maxdeg_in(const u64 *adj, u64 S) {
    int m = 0; u64 t = S;
    while (t) { int d = PC(adj[CTZ(t)] & S); if (d > m) m = d; t &= t - 1; }
    return m;
}
static inline int independent(const u64 *adj, u64 S) {
    u64 t = S;
    while (t) { if (adj[CTZ(t)] & S) return 0; t &= t - 1; }
    return 1;
}
static int bipartite(const u64 *adj, u64 S) {
    u64 rem = S;
    while (rem) {
        u64 st = LOW(rem), seen = st, fr = st, A = st, B = 0; int par = 0;
        while (fr) {
            u64 nb = nbh(adj, fr) & S & ~seen;
            seen |= nb; fr = nb; par ^= 1;
            if (par) B |= nb; else A |= nb;
        }
        if (nbh(adj, A) & A) return 0;
        if (nbh(adj, B) & B) return 0;
        rem &= ~seen;
    }
    return 1;
}

// ---------- predicates P(adj,U,S,param) ----------
typedef int (*pred_t)(const u64 *, u64, u64, int);
static int p_dom(const u64 *a, u64 U, u64 S, int k) { (void)k; return ((S | nbh(a, S)) & U) == U; }
static int p_tdom(const u64 *a, u64 U, u64 S, int k) { (void)k; return (nbh(a, S) & U) == U; }
static int p_dom2(const u64 *a, u64 U, u64 S, int k) {
    (void)k; u64 t = U & ~S;
    while (t) { if (PC(a[CTZ(t)] & S) < 2) return 0; t &= t - 1; }
    return 1;
}
static int p_cdom(const u64 *a, u64 U, u64 S, int k) { return S && p_dom(a, U, S, k) && w_connected(a, S); }
static int p_idom(const u64 *a, u64 U, u64 S, int k) { return p_dom(a, U, S, k) && independent(a, S); }
static int p_kind(const u64 *a, u64 U, u64 S, int k) { (void)U; return maxdeg_in(a, S) <= k - 1; }
static int p_bip(const u64 *a, u64 U, u64 S, int k) { (void)U; (void)k; return bipartite(a, S); }
static int p_forest(const u64 *a, u64 U, u64 S, int k) { (void)U; (void)k; return w_edges(a, S) == PC(S) - w_ncomp(a, S); }
static int p_tree(const u64 *a, u64 U, u64 S, int k) { (void)U; (void)k; return S && w_connected(a, S) && w_edges(a, S) == PC(S) - 1; }
static int p_ipath(const u64 *a, u64 U, u64 S, int k) { return p_tree(a, U, S, k) && maxdeg_in(a, S) <= 2; }
static int p_icycle(const u64 *a, u64 U, u64 S, int k) {
    (void)U; (void)k;
    if (PC(S) < 3 || !w_connected(a, S)) return 0;
    u64 t = S;
    while (t) { if (PC(a[CTZ(t)] & S) != 2) return 0; t &= t - 1; }
    return 1;
}
static int p_indep(const u64 *a, u64 U, u64 S, int k) { (void)U; (void)k; return independent(a, S); }

static inline u64 expand(u64 comb, const int *verts) {
    u64 S = 0;
    while (comb) { S |= 1ULL << verts[CTZ(comb)]; comb &= comb - 1; }
    return S;
}
// smallest k (>= kmin) such that some k-subset S of U satisfies P; -1 if none
static int min_subset(const u64 *adj, u64 U, pred_t P, int param, int kmin) {
    int verts[64], m = 0; u64 t = U;
    while (t) { verts[m++] = CTZ(t); t &= t - 1; }
    for (int k = kmin; k <= m; k++) {
        if (k == 0) { if (P(adj, U, 0, param)) return 0; continue; }
        u64 comb = (1ULL << k) - 1, lim = 1ULL << m;
        while (comb < lim) {
            if (P(adj, U, expand(comb, verts), param)) return k;
            u64 c = comb & (~comb + 1), r = comb + c;
            comb = (((r ^ comb) >> 2) / c) | r;
        }
    }
    return -1;
}
static int max_subset(const u64 *adj, u64 U, pred_t P, int param) {
    int verts[64], m = 0; u64 t = U;
    while (t) { verts[m++] = CTZ(t); t &= t - 1; }
    for (int k = m; k >= 1; k--) {
        u64 comb = (1ULL << k) - 1, lim = 1ULL << m;
        while (comb < lim) {
            if (P(adj, U, expand(comb, verts), param)) return k;
            u64 c = comb & (~comb + 1), r = comb + c;
            comb = (((r ^ comb) >> 2) / c) | r;
        }
    }
    return 0;
}

int w_gamma(const u64 *a, u64 U)      { return min_subset(a, U, p_dom, 0, 0); }
int w_gamma_t(const u64 *a, u64 U)    { return min_subset(a, U, p_tdom, 0, 0); }
int w_gamma_2(const u64 *a, u64 U)    { return min_subset(a, U, p_dom2, 0, 0); }
int w_gamma_c(const u64 *a, u64 U)    { return min_subset(a, U, p_cdom, 0, 1); }
int w_indep_dom(const u64 *a, u64 U)  { return min_subset(a, U, p_idom, 0, 0); }
int w_alpha_k(const u64 *a, u64 U, int k) { return max_subset(a, U, p_kind, k); }
int w_bip(const u64 *a, u64 U)        { return max_subset(a, U, p_bip, 0); }
int w_forest(const u64 *a, u64 U)     { return max_subset(a, U, p_forest, 0); }
int w_tree(const u64 *a, u64 U)       { return max_subset(a, U, p_tree, 0); }
int w_ipath(const u64 *a, u64 U)      { return max_subset(a, U, p_ipath, 0); }
int w_icycle(const u64 *a, u64 U)     { return max_subset(a, U, p_icycle, 0); }

static int alpha_rec(const u64 *adj, u64 U) {
    if (!U) return 0;
    int bv = -1, bd = -1; u64 t = U;
    while (t) {
        int v = CTZ(t); int d = PC(adj[v] & U);
        if (d <= 1) return 1 + alpha_rec(adj, U & ~(adj[v] | (1ULL << v)));
        if (d > bd) { bd = d; bv = v; }
        t &= t - 1;
    }
    int x = alpha_rec(adj, U & ~(1ULL << bv));
    int y = 1 + alpha_rec(adj, U & ~(adj[bv] | (1ULL << bv)));
    return x > y ? x : y;
}
int w_alpha(const u64 *a, u64 U) { return alpha_rec(a, U); }

// ---------- enumeration of independent sets of G[U] ----------
// out[0]=alpha, out[1]=#maximum independent sets (capped), out2[0]=intersection mask of max ind sets
// crit: out[2]=d_max=max(|S|-|N(S)∩U|), out[3]=alpha' (largest critical), out2[1]=H (union of max critical)
// out[4]=#maximal independent sets, out[5]=min maximal (=i), out[6]=max maximal(=alpha)
void w_indsets(const u64 *adj, u64 U, long *out, u64 *out2) {
    int verts[64], m = 0; u64 t = U;
    while (t) { verts[m++] = CTZ(t); t &= t - 1; }
    // iterative DFS over independent sets: stack of (cand, cur)
    typedef struct { u64 cand, cur; } fr_t;
    fr_t *st = (fr_t *)malloc(sizeof(fr_t) * 70 * 2 + 1024);
    int sp = 0;
    long alpha = -1, cnt = 0, dmax = -1000000, crit = -1, nmax = 0, imin = 1000000, imax = -1;
    long dmax2 = -1000000, crit2 = -1;   /* same, over NONEMPTY independent sets */
    u64 inter = 0, H = 0, H2 = 0;
    st[sp].cand = U; st[sp].cur = 0; sp++;
    while (sp) {
        sp--; u64 cand = st[sp].cand, cur = st[sp].cur;
        if (!cand) {
            int s = PC(cur);
            if (s > alpha) { alpha = s; cnt = 1; inter = cur; }
            else if (s == alpha) { cnt++; inter &= cur; }
            long d = s - PC(nbh(adj, cur) & U);
            if (d > dmax) { dmax = d; crit = s; H = cur; }
            else if (d == dmax) { if (s > crit) { crit = s; H = cur; } else if (s == crit) H |= cur; }
            if (s > 0) {
                if (d > dmax2) { dmax2 = d; crit2 = s; H2 = cur; }
                else if (d == dmax2) { if (s > crit2) { crit2 = s; H2 = cur; } else if (s == crit2) H2 |= cur; }
            }
            if (((cur | nbh(adj, cur)) & U) == U) { nmax++; if (s < imin) imin = s; if (s > imax) imax = s; }
            continue;
        }
        int v = CTZ(cand);
        // exclude v
        st[sp].cand = cand & ~(1ULL << v); st[sp].cur = cur; sp++;
        // include v
        st[sp].cand = cand & ~((1ULL << v) | adj[v]); st[sp].cur = cur | (1ULL << v); sp++;
    }
    free(st);
    out[0] = alpha; out[1] = cnt; out[2] = dmax; out[3] = crit; out[4] = nmax; out[5] = imin; out[6] = imax;
    out[7] = dmax2; out[8] = crit2;
    out2[0] = inter; out2[1] = H; out2[2] = H2;
}

// ---------- Hamiltonian paths / path cover on G[U] (|U| <= 24) ----------
static uint32_t *hp_table(const u64 *adj, const int *verts, int m) {
    // dp[mask] = bitmask (index space) of possible endpoints of a Hamiltonian path of G[mask]
    uint32_t *dp = (uint32_t *)calloc((size_t)1 << m, sizeof(uint32_t));
    uint32_t nb[64];
    for (int i = 0; i < m; i++) {
        nb[i] = 0;
        for (int j = 0; j < m; j++) if (adj[verts[i]] >> verts[j] & 1ULL) nb[i] |= 1u << j;
        dp[1u << i] = 1u << i;
    }
    for (uint32_t mask = 1; mask < (1u << m); mask++) {
        if (!(mask & (mask - 1))) continue;
        uint32_t ends = 0, t = mask;
        while (t) {
            int v = __builtin_ctz(t);
            if (dp[mask & ~(1u << v)] & nb[v]) ends |= 1u << v;
            t &= t - 1;
        }
        dp[mask] = ends;
    }
    return dp;
}
int w_traceable(const u64 *adj, u64 U) {
    int verts[64], m = 0; u64 t = U;
    while (t) { verts[m++] = CTZ(t); t &= t - 1; }
    if (m == 0) return 0;
    if (m > 24) return -1;
    uint32_t *dp = hp_table(adj, verts, m);
    int r = dp[(1u << m) - 1] != 0;
    free(dp);
    return r;
}
int w_path_cover(const u64 *adj, u64 U) {
    int verts[64], m = 0; u64 t = U;
    while (t) { verts[m++] = CTZ(t); t &= t - 1; }
    if (m == 0) return 0;
    if (m > 22) return -1;
    uint32_t *dp = hp_table(adj, verts, m);
    uint8_t *best = (uint8_t *)malloc((size_t)1 << m);
    best[0] = 0;
    for (uint32_t mask = 1; mask < (1u << m); mask++) {
        uint32_t low = mask & (~mask + 1), rest = mask & ~low;
        int b = 255;
        // T = low | sub, sub subset of rest
        uint32_t sub = rest;
        while (1) {
            uint32_t T = low | sub;
            if (dp[T]) { int v = 1 + best[mask & ~T]; if (v < b) b = v; }
            if (!sub) break;
            sub = (sub - 1) & rest;
        }
        best[mask] = (uint8_t)b;
    }
    int r = best[(1u << m) - 1];
    free(best); free(dp);
    return r;
}
// longest path (number of vertices) in G[U] (not necessarily induced)
int w_longest_path(const u64 *adj, u64 U) {
    int verts[64], m = 0; u64 t = U;
    while (t) { verts[m++] = CTZ(t); t &= t - 1; }
    if (m == 0) return 0;
    if (m > 24) return -1;
    uint32_t *dp = hp_table(adj, verts, m);
    int b = 0;
    for (uint32_t mask = 1; mask < (1u << m); mask++) if (dp[mask] && __builtin_popcount(mask) > b) b = __builtin_popcount(mask);
    free(dp);
    return b;
}

// ---------- well total dominated: out[0]=min minimal TDS, out[1]=max minimal TDS ----------
void w_minimal_tds(const u64 *adj, u64 U, int *out) {
    int verts[64], m = 0; u64 t = U;
    while (t) { verts[m++] = CTZ(t); t &= t - 1; }
    int mn = 1000, mx = -1;
    for (u64 c = 0; c < (1ULL << m); c++) {
        u64 S = expand(c, verts);
        if ((nbh(adj, S) & U) != U) continue;
        int minimal = 1; u64 s = S;
        while (s) {
            int v = CTZ(s);
            if ((nbh(adj, S & ~(1ULL << v)) & U) == U) { minimal = 0; break; }
            s &= s - 1;
        }
        if (minimal) { int k = PC(S); if (k < mn) mn = k; if (k > mx) mx = k; }
    }
    out[0] = mx < 0 ? -1 : mn; out[1] = mx;
}
