#!/usr/bin/env python3
"""
Counterexamples to Written on the Wall II (Graffiti.pc) conjectures — standalone checker.

Each entry: the conjecture as stated on DeLaVina's WOWII page, the graph (graph6), and an
exact computation of both sides.  Exact solvers only (CP-SAT integer programs for the domination
type numbers, brute force over subsets where small).  Run:

    pip install networkx ortools
    python3 wowii_counterexamples.py            # all
    python3 wowii_counterexamples.py 402 393d   # selected

Notation (WOWII definitions): M = maximum-degree vertices, A = minimum-degree vertices,
P = pendant vertices, C = center, B = periphery, bar(G) = complement, G^2 = square,
lambda(v) = alpha(G[N(v)]), N(e) for an edge uv = N(u) | N(v), i = independent domination,
gamma_t = total domination, gamma_2 = 2-domination (every vertex outside D has >= 2 neighbours in D),
L_s = maximum number of leaves of a spanning tree, b = largest induced bipartite subgraph,
tree(G) = largest induced tree, path(G) = largest induced path, u(G) = 1 iff the maximum
independent set is unique, HH_k = number of Havel-Hakimi steps until a 0 appears.
"""
import itertools
import math
import sys
from fractions import Fraction as F

import networkx as nx
from ortools.sat.python import cp_model


# ----------------------------------------------------------------- exact solvers
def _solve(m, obj, maximize=False):
    (m.Maximize if maximize else m.Minimize)(obj)
    s = cp_model.CpSolver()
    s.parameters.max_time_in_seconds = 600
    st = s.Solve(m)
    assert st == cp_model.OPTIMAL, "solver did not prove optimality"
    return round(s.ObjectiveValue()), s


def dom_number(g, kind):
    """kind: 'dom' (gamma), 'tdom' (gamma_t), 'dom2' (gamma_2), 'idom' (i)."""
    m = cp_model.CpModel()
    x = {v: m.NewBoolVar(str(v)) for v in g}
    for v in g:
        nb = [x[u] for u in g[v]]
        if kind == "dom":
            m.Add(x[v] + sum(nb) >= 1)
        elif kind == "tdom":
            m.Add(sum(nb) >= 1)
        elif kind == "dom2":
            m.Add(2 * x[v] + sum(nb) >= 2)
        elif kind == "idom":
            m.Add(x[v] + sum(nb) >= 1)
    if kind == "idom":
        for u, v in g.edges():
            m.Add(x[u] + x[v] <= 1)
    return _solve(m, sum(x.values()))[0]


def alpha(g, nodes=None):
    h = g.subgraph(g if nodes is None else nodes)
    if h.number_of_nodes() == 0:
        return 0
    m = cp_model.CpModel()
    x = {v: m.NewBoolVar(str(v)) for v in h}
    for u, v in h.edges():
        m.Add(x[u] + x[v] <= 1)
    return _solve(m, sum(x.values()), maximize=True)[0]


def unique_max_independent_set(g):
    a = alpha(g)
    m = cp_model.CpModel()
    x = {v: m.NewBoolVar(str(v)) for v in g}
    for u, v in g.edges():
        m.Add(x[u] + x[v] <= 1)
    m.Add(sum(x.values()) == a)
    s = cp_model.CpSolver()
    assert s.Solve(m) == cp_model.OPTIMAL
    first = [v for v in g if s.Value(x[v])]
    m.Add(sum(x[v] for v in first) <= a - 1)          # forbid the first one
    st = cp_model.CpSolver().Solve(m)
    return 1 if st == cp_model.INFEASIBLE else 0


def mu(g, nodes=None):
    h = g.subgraph(g if nodes is None else nodes)
    return len(nx.max_weight_matching(h, maxcardinality=True))


def lam(g, v):
    return alpha(g, list(g[v]))


def degeneracy(g):
    return max(nx.core_number(g).values()) if g.number_of_edges() else 0


def havel_hakimi_k(g):
    s = sorted((d for _, d in g.degree()), reverse=True)
    if 0 in s:
        return 0
    k = 0
    while True:
        d = s.pop(0)
        s = sorted([x - 1 if j < d else x for j, x in enumerate(s)], reverse=True)
        k += 1
        if not s or 0 in s:
            return k


def bitmask_adj(g):
    nodes = list(g)
    idx = {v: i for i, v in enumerate(nodes)}
    adj = [0] * len(nodes)
    for u, v in g.edges():
        adj[idx[u]] |= 1 << idx[v]
        adj[idx[v]] |= 1 << idx[u]
    return nodes, adj


def _connected(adj, S):
    if not S:
        return False
    seen = fr = S & -S
    while fr:
        nb = 0
        t = fr
        while t:
            b = t & -t
            nb |= adj[b.bit_length() - 1]
            t ^= b
        nb &= S & ~seen
        seen |= nb
        fr = nb
    return seen == S


def _edges_in(adj, S):
    e, t = 0, S
    while t:
        b = t & -t
        e += (adj[b.bit_length() - 1] & S).bit_count()
        t ^= b
    return e // 2


def tree_number(g):
    """largest induced tree, exhaustive over all vertex subsets."""
    nodes, adj = bitmask_adj(g)
    n, best = len(nodes), 0
    for S in range(1, 1 << n):
        k = S.bit_count()
        if k > best and _edges_in(adj, S) == k - 1 and _connected(adj, S):
            best = k
    return best


def bipartite_number(g):
    nodes = list(g)
    for k in range(len(nodes), 0, -1):
        for S in itertools.combinations(nodes, k):
            if nx.is_bipartite(g.subgraph(S)):
                return k
    return 0


def leaf_number(g):
    """L_s(G) = n - (connected domination number) for connected G, n >= 3."""
    nodes, adj = bitmask_adj(g)
    n = len(nodes)
    full = (1 << n) - 1
    closed = [adj[i] | (1 << i) for i in range(n)]
    for k in range(1, n + 1):
        for comb in itertools.combinations(range(n), k):
            S = 0
            dom = 0
            for i in comb:
                S |= 1 << i
                dom |= closed[i]
            if dom == full and _connected(adj, S):
                return n - k
    raise ValueError


def minimal_tds_sizes(g):
    nodes, adj = bitmask_adj(g)
    n, full = len(nodes), (1 << len(nodes)) - 1

    def nb(S):
        r, t = 0, S
        while t:
            b = t & -t
            r |= adj[b.bit_length() - 1]
            t ^= b
        return r
    sizes = set()
    for S in range(1, 1 << n):
        if nb(S) != full:
            continue
        if all(nb(S & ~(1 << i)) != full for i in range(n) if S >> i & 1):
            sizes.add(S.bit_count())
    return sizes


def k4_count(g, v):
    return sum(1 for a, b, c in itertools.combinations(g[v], 3)
               if g.has_edge(a, b) and g.has_edge(a, c) and g.has_edge(b, c))


def maxdeg_set(g):
    D = max(d for _, d in g.degree())
    return {v for v in g if g.degree(v) == D}


def mindeg_set(g):
    d = min(d for _, d in g.degree())
    return {v for v in g if g.degree(v) == d}


def N(g, S):
    return set().union(*(set(g[v]) for v in S)) if S else set()


def show(label, lhs, op, rhs, holds):
    print(f"   {label}:  {lhs}  {op}  {rhs}   -> conjecture {'HOLDS' if holds else 'FAILS'}")
    return holds


# ----------------------------------------------------------------- counterexamples
CASES = {}


def case(cid, g6, statement):
    def deco(fn):
        CASES[cid] = (g6, statement, fn)
        return fn
    return deco


@case("76", "Q{CY?CBG??_BA???_?WG???C??W",
      "If G is a simple connected graph, then tree(G) >= freq[T_max(v)] / FLOOR[deg_avg(G)]")
def c76(g):
    t = nx.triangles(g)
    tmax = max(t.values())
    freq = sum(1 for v in t if t[v] == tmax)
    rhs = F(freq, math.floor(F(2 * g.number_of_edges(), g.number_of_nodes())))
    lhs = tree_number(g)
    return show("tree(G) >= freq(T_max)/floor(deg_avg)", lhs, ">=", rhs, lhs >= rhs)


@case("138", "RhCGGC@?G?_@?@??_?K??_????_?@?",
      "If G is a simple connected graph, then path(G) >= (2 + u(G)) * dist_min(M(G^2))")
def c138(g):
    assert nx.is_tree(g)
    lhs = nx.diameter(g) + 1            # in a tree the longest path is an induced path
    sq = nx.power(g, 2)
    M2 = maxdeg_set(sq)
    u = unique_max_independent_set(g)
    dmin_sq = min(nx.shortest_path_length(sq, a, b) for a, b in itertools.combinations(M2, 2))
    dmin_g = min(nx.shortest_path_length(g, a, b) for a, b in itertools.combinations(M2, 2))
    ok1 = show("distances in G^2", lhs, ">=", (2 + u) * dmin_sq, lhs >= (2 + u) * dmin_sq)
    ok2 = show("distances in G  ", lhs, ">=", (2 + u) * dmin_g, lhs >= (2 + u) * dmin_g)
    return ok1 or ok2


@case("166", "S`?AG?_E??G_B????KC@????@@G?o??QO",
      "If G is a simple connected graph, then L_s(G) >= |N(M) - M| / SQRT[rad(G)]")
def c166(g):
    M = maxdeg_set(g)
    a = len(N(g, M) - M)
    r = nx.radius(g)
    L = leaf_number(g)
    # L >= a/sqrt(r)  <=>  L^2 * r >= a^2
    return show("L_s >= |N(M)-M|/sqrt(rad)", L, ">=", f"{a}/sqrt({r}) = {a / math.sqrt(r):.4f}", L * L * r >= a * a)


@case("267", "QhCGGC@?GC?B?_?C_O??`?_??OG",
      "If G is a simple connected graph such that girth(G) >= 5, then gamma_t(G) >= CEIL[dist_avg(A,V)]")
def c267(g):
    assert nx.girth(g) >= 5 and not nx.is_tree(g)
    A = mindeg_set(g)
    d = dict(nx.all_pairs_shortest_path_length(g))
    pairs = [d[s][v] for s in A for v in g if v != s]
    frm = [min(d[s][v] for s in A) for v in g if v not in A]
    gt = dom_number(g, "tdom")
    ok1 = show("pairs average", gt, ">=", math.ceil(F(sum(pairs), len(pairs))), gt >= math.ceil(F(sum(pairs), len(pairs))))
    ok2 = show("distance-from-A average", gt, ">=", math.ceil(F(sum(frm), len(frm))), gt >= math.ceil(F(sum(frm), len(frm))))
    return ok1 or ok2


@case("281", "TpE?GE??G?o??@??_???@??M??w??G??K??F",
      "If G is connected, n > 2, then gamma_t(G) <= [frequency of lambda_min(bar(G))] + mu(G)")
def c281(g):
    h = nx.complement(g)
    lv = {v: lam(h, v) for v in h}
    lo = min(lv.values())
    rhs = sum(1 for v in lv if lv[v] == lo) + mu(g)
    gt = dom_number(g, "tdom")
    return show("gamma_t <= freq(lambda_min(bar G)) + mu", gt, "<=", rhs, gt <= rhs)


@case("287", "ZsaCCA?_??g??@G???G_???CG????GG????@?_?????_G?????@?G??????G",
      "If G is connected, n > 2, then gamma_t(G) <= k + mu(bar(G)), k = first Havel-Hakimi step with a zero")
def c287(g):
    rhs = havel_hakimi_k(g) + mu(nx.complement(g))
    gt = dom_number(g, "tdom")
    return show("gamma_t <= HH_k + mu(bar G)", gt, "<=", rhs, gt <= rhs)


@case("328", "K~~~~~~~~}^x",
      "Let G be connected, n > 1. If 4*mu(bar(G)) <= frequency of max{K_4(v)}, then G is well total dominated")
def c328(g):
    k4 = {v: k4_count(g, v) for v in g}
    mx = max(k4.values())
    freq = sum(1 for v in k4 if k4[v] == mx)
    prem = 4 * mu(nx.complement(g)) <= freq
    sizes = minimal_tds_sizes(g)
    print(f"   premise 4*mu(bar G) = {4 * mu(nx.complement(g))} <= freq(max K4) = {freq}: {prem}")
    print(f"   sizes of minimal total dominating sets: {sorted(sizes)}  (well total dominated iff one size)")
    holds = (not prem) or len(sizes) == 1
    print(f"   -> conjecture {'HOLDS' if holds else 'FAILS'}")
    return holds


@case("382d", "Z~~~y@@GXBg?O@C@a?y??O?CG?WO?y??@??@@??WG?Bg???O??@?_?@_O??w",
      "If G is connected, n > 2, then gamma_2 <= [diam(G)(alpha + |X|)]/2, X = vertices of maximum local independence")
def c382d(g):
    lv = {v: lam(g, v) for v in g}
    X = [v for v in g if lv[v] == max(lv.values())]
    rhs = F(nx.diameter(g) * (alpha(g) + len(X)), 2)
    g2 = dom_number(g, "dom2")
    return show("gamma_2 <= diam(alpha+|X|)/2", g2, "<=", rhs, g2 <= rhs)


@case("392c", "Vhe@?G@?g?_H@???_OG?@??cC????GC?C??@??@GG???",
      "If G is connected, n > 2, then gamma_2 <= mu(G[V - A]) + |A| + kappa_v(G) (A min-degree vertices, kappa_v = #cut vertices)")
def c392c(g):
    A = mindeg_set(g)
    rhs = mu(g, set(g) - A) + len(A) + len(list(nx.articulation_points(g)))
    g2 = dom_number(g, "dom2")
    return show("gamma_2 <= mu(G[V-A]) + |A| + #cut vertices", g2, "<=", rhs, g2 <= rhs)


@case("393d", "O~~coH??H??@C???`???@",
      "If G is connected, n > 2, then gamma_2 <= mu(G[V - N(N(P))]) + alpha(G[V-M]) + |M_4|")
def c393d(g):
    P = {v for v in g if g.degree(v) == 1}
    NNP = N(g, N(g, P))
    M = maxdeg_set(g)
    k4 = {v: k4_count(g, v) for v in g}
    M4 = [v for v in g if k4[v] == max(k4.values())]
    rhs = mu(g, set(g) - NNP) + alpha(g, set(g) - M) + len(M4)
    g2 = dom_number(g, "dom2")
    return show("gamma_2 <= mu(G[V-N(N(P))]) + alpha(G[V-M]) + |M_4|", g2, "<=", rhs, g2 <= rhs)


@case("402", "L{eC?KF@_K_o@`",
      "If G is connected, n > 2, then gamma_2 <= 2[isolates(G[A_delta]) + |{v: |N(v) & A_Delta| = 1}| + gamma_t]")
def c402(g):
    Ad, AD = mindeg_set(g), maxdeg_set(g)
    iso = sum(1 for v in Ad if not (set(g[v]) & Ad))
    one = sum(1 for v in g if len(set(g[v]) & AD) == 1)
    rhs = 2 * (iso + one + dom_number(g, "tdom"))
    g2 = dom_number(g, "dom2")
    return show("gamma_2 <= 2(iso(G[A_delta]) + #{|N(v)&A_Delta|=1} + gamma_t)", g2, "<=", rhs, g2 <= rhs)


@case("422a", "_~~~~{??G@_F?N?N_Fw@~?????G??W??[??N??Bw??^_?@~Bo{NBo~o@~_F_^w]?{?{NBoB~?F`w@wF`w]??",
      "If G is connected, n > 3, then i(G) <= alpha(G[V-M]) + 2*FLOOR[|E(G[M])|/3]")
def c422a(g):
    M = maxdeg_set(g)
    rhs = alpha(g, set(g) - M) + 2 * (g.subgraph(M).number_of_edges() // 3)
    i = dom_number(g, "idom")
    return show("i <= alpha(G[V-M]) + 2 floor(|E(G[M])|/3)", i, "<=", rhs, i <= rhs)


@case("422c", "X~~~~~~???_B?F?F_Bw?~?F{?^w?~w~@~b_~~?Ng~}?{^w@~FoP",
      "If G is connected, n > 3, A = vertices of degree at most n/2, then i(G) <= alpha(G[A]) + 2*FLOOR[Delta(G[V-A])/3]")
def c422c(g):
    n = g.number_of_nodes()
    A = {v for v in g if 2 * g.degree(v) <= n}
    rest = g.subgraph(set(g) - A)
    D = max((d for _, d in rest.degree()), default=0)
    rhs = alpha(g, A) + 2 * (D // 3)
    i = dom_number(g, "idom")
    return show("i <= alpha(G[A]) + 2 floor(Delta(G[V-A])/3)", i, "<=", rhs, i <= rhs)


# ---- partial (only some readings fail)
@case("72", "Q~~wGGC?w?_A?C?B_?G?B??[?@w",
      "If G is a simple connected graph, then tree(G) >= CEIL[average of ecc(v) + maximum of lambda(v)/3]")
def c72(g):
    ea = F(sum(nx.eccentricity(g).values()), g.number_of_nodes())
    lmax = max(lam(g, v) for v in g)
    t = tree_number(g)
    ok1 = show("Lean/formal-conjectures reading ceil(ecc_avg + lam_max/3)", t, ">=", math.ceil(ea + F(lmax, 3)), t >= math.ceil(ea + F(lmax, 3)))
    show("other reading ceil((ecc_avg + lam_max)/3) [true in general]", t, ">=", math.ceil((ea + lmax) / 3), t >= math.ceil((ea + lmax) / 3))
    return ok1


@case("186", "L@OtAA@R??@?CA",
      "If G is connected, n >= 2, then L_s(G) + b(G) >= |N(C(G^2))| + 2*ecc(C(G^2))")
def c186(g):
    sq = nx.power(g, 2)
    ecc2 = nx.eccentricity(sq)
    C2 = {v for v in sq if ecc2[v] == min(ecc2.values())}
    d2 = dict(nx.all_pairs_shortest_path_length(sq))
    ecc_set = max((min(d2[c][v] for c in C2) for v in sq if v not in C2), default=0)
    lhs = leaf_number(g) + bipartite_number(g)
    ok1 = show("N taken in G^2 (fails)", lhs, ">=", len(N(sq, C2)) + 2 * ecc_set, lhs >= len(N(sq, C2)) + 2 * ecc_set)
    show("N taken in G   (holds here)", lhs, ">=", len(N(g, C2)) + 2 * ecc_set, lhs >= len(N(g, C2)) + 2 * ecc_set)
    return ok1


def main():
    want = sys.argv[1:] or list(CASES)
    for cid in want:
        g6, st, fn = CASES[cid]
        g = nx.from_graph6_bytes(g6.encode())
        print(f"\nWOWII {cid}: {st}")
        print(f"   graph6 {g6}   n={g.number_of_nodes()} m={g.number_of_edges()} connected={nx.is_connected(g)}")
        fn(g)


if __name__ == "__main__":
    main()
