KEIO — WoWII Rounds 1–22: Consolidated Paper and Reproducibility Package
26 October 2026 — audited integration and extensions revision

MAIN DELIVERABLE
manuscript/ contains the complete English paper as one standalone TEX and PDF.
The TEX has its bibliography inline and uses no external input or figure files.
Author: KEIO. The current PDF/TEX incorporate the revision described below.

EXACT MATHEMATICAL SCOPE
Complete source-qualified conclusions: 14 original formulations.
Proofs: 434d, 434e, 298.
Refutations: 394, 392e, 392f, 395a, 382c, 269, 302, 171, 382e, 154, 354.
Item 354 refers only to the archived coefficient-1/2, open-neighborhood form.
The basic Feit construction and other prior contributions are credited.
The count is not a certification of worldwide novelty or curator acceptance.

Further complete proofs establish explicitly limited results for 40, 61, 133,
155, 165, 177, 180, 189, 199, 384b and 389a, plus supporting structural theorems.
133: the original unrounded inequality is proved for mean local independence
     <=5, also radius2/mean<=7 and radius3/mean<=6.
384b: a counterexample, if one exists, has a connected representative of
      order<=37 and 11..33 vertices of degree>=3. No exhaustive census
      through37 or full resolution is claimed.
199: split-graph reductions and the added independence/connectivity-gap
     cases do not settle all split graphs satisfying the original premise.
389a: the new 11-vertex counterexample addresses ONLY the lower-rank reading
      d_floor(n/4) of the unspecified degree quartile. It is not counted as
      an unqualified resolution of the original wording.
Other full conjectures remain outside the proved scope specified in the paper.

THIS REVISION
The added material includes a pendant-neighbor subclass for 40, support-graph extensions for 61; restricted
maximum-degree classes 3, 4 and 5 for 165; split-graph gap-two and gap-three
cases for 199; one fixed-h=33 restriction for 384b; the qualified 389a rounding
example; new triangle-free 394 modules and their deletion bounds; and
extensions of the independent-domination framework, including graphs without
isolated vertices and diameter bounds. A separate strict closed-neighborhood
containment theorem refines the credited connected-domination construction.
These refinements do not increase the 14-formulation closure count above.
The source-qualified 298 proof input was retrieved and independently read;
provenance/revision/298_primary_audit.md gives its primary URL, SHA-256,
the exact proof chain used, and the limitation that no Lean rebuild was run.

DIRECTORIES
source_archive/ preserves the original proof texts, code, data and audit notes
  extracted from the five supplied bundles. Original PDFs, nested ZIP copies,
  rendered images, build files and executable binaries are omitted to avoid
  redundancy. Binary certificate DATA such as permutation arrays are retained.
  Full original source hashes remain in provenance/source_manifest.json.
  No source_archive file was changed by this revision.
verification/ holds the copied/adapted verifier programs, exact companion data,
  and recorded outputs of the original consolidation reruns.
verification/extensions/ adds ten revision programs and their recorded data.
provenance/ holds the source manifest, main-paper index, claim audits, assembly
  and final-build records, and page-render audit. Historical records are preserved.
provenance/revision/ separates new audits, source mappings, run logs and
  validation results from those historical records. Its original_package_metadata/
  preserves the prior README, driver and 53-job manifest.
editorial_sources/ records the integrated fragments and editorial scripts.
  These scripts record the original workspace layout; they are provenance,
  not needed to compile the standalone TEX or run verify.py.

VERIFY THE PACKAGE
  python verify.py --validate
  python verify.py --list

RUN THE CHECKS
  python verify.py --group extensions
  python verify.py --group root
  python verify.py --group paired_384b
  python verify.py --group early
  python verify.py --group late
  python verify.py
The extension group contains 10 programs; the other four groups preserve
all original 53 programs. The last command runs all 63. Groups can be repeated
in one command. The original 53 successful recorded runs are historical;
the revision separately reruns and inspects all 10 extension programs.
These are program counts, not numbers of distinct instances or conjectures.
The higher-degree 165 checker imports and repeats the cubic checker's tests;
this overlap is explicit and is not counted as an additional program.
The driver copies the verification tree into a fresh runs/<UTC timestamp>/
directory, so the original package and its checksums are not overwritten.
Logs and JSON results are retained there. C++ programs are compiled locally.
The driver reports process exit status. The revision audit additionally
inspects each new log and its output certificates for actual passing checks.
No finite test suite is a replacement for the mathematical proofs.

RUNTIME
The consolidation used Python 3.12.14, NetworkX 3.7 and a C++17 compiler.
Supplemental early graph checks and the support, 165 and crosscheck extension
lanes require NetworkX. The other new lanes use the Python standard library.
The P8/P9 closed-certificate verifiers and incidence checks also use only the
standard library.
Install the optional Python dependency with:
  python -m pip install -r requirements.txt
A g++ compiler supporting -std=c++17 is needed for the C++ checks.
The optional historical builders have their own dependencies and are not run
by verify.py. Canonical labeling is not trusted by the closed-certificate
verifiers, which check every recorded permutation directly.

REBUILD THE PAPER
In manuscript/, run pdflatex on the TEX filename until references stabilize
(normally three passes). A TeX distribution with the standard AMS, Latin
Modern, microtype, hyperref, geometry, xurl, needspace, booktabs, longtable,
enumitem and fancyhdr packages is sufficient. No shell escape is required.

LIMITED ADAPTATIONS AND HISTORICAL RECORDS
The kappa3 split checker needed an original companion JSON restored from the
Round17 audit snapshot; its code was not changed.
The historical 298 independent checker omits only final metadata hashes for two prior
PDF/text snapshots absent from the supplied ZIPs. Its mathematical tests were
unchanged. Original/adapted hashes and the failed metadata-only attempt are
described in the audit. The paper gives the required credited antecedent
proof chain explicitly. The new primary-source retrieval audit supplements
that record; it does not rewrite the old run history. No Lean rebuild is claimed.

Finite sanity checks and exact finite proof certificates are distinguished
in the paper. Neither 53 historical runs nor 10 new runs means that many
conjectures were solved. Full conjectures, restricted results, supporting
lemmas, and convention-dependent statements are identified separately.
