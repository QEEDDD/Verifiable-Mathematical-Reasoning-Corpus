from pathlib import Path
import re,json,hashlib,collections

W=Path(__file__).resolve().parent
S=W/'sections'
OUT=W.parent/'output/pdf'
NAME='KEIO_WOWII_Rounds_01_22_Consolidated_2026-10-26'
parts=['frontmatter.tex','closed_early.tex','closed_late_structural.tex',
       'local_133.tex','paired_384b.tex','split_199.tex',
       'even_distance_189.tex','appendices.tex']
body='\n\n'.join('% Integrated source fragment: '+n+'\n'+(S/n).read_text() for n in parts)
aliases={'early:rows':'src:catalogue','late:archive':'src:catalogue',
         'early:definitions':'src:definitions',
         'late:382e:dlpw':'early:dpw-two'}
def replace_cite(m):
    keys=list(dict.fromkeys(aliases.get(k.strip(),k.strip()) for k in m[2].split(',')))
    return '\\cite'+(m[1] or '')+'{'+','.join(keys)+'}'
def alias_cites(t):return re.sub(r'\\cite(\[[^\]]*\])?\{([^}]+)\}',replace_cite,t)
body=alias_cites(body)
bib={}
for n in ['closed_early_bib.tex','closed_late_structural_bib.tex','paired_384b_bib.tex',
          'root_bib.tex','even_distance_189_bib.tex']:
    for m in re.finditer(r'\\bibitem\{([^}]+)\}(.*?)(?=\\bibitem|\Z)',(S/n).read_text(),re.S):
        key=aliases.get(m[1],m[1]);bib.setdefault(key,alias_cites(m[2].strip()))
bib['src:catalogue']=r'''E. DeLaVi\~na,
\emph{Written on the Wall II: Conjectures of Graffiti.pc}, original catalogue.
\url{http://cms.uhd.edu/faculty/delavinae/research/wowII/all.html}.
The source-qualified numbered formulations used in this paper are preserved
in the supplied round archives and in the pinned HTML-row transcription,
revision \texttt{3be380b4222f974bedbefb228c8e75fbd9a7b3ae}:
\url{https://gitlab.com/ai-village-agents/village/graffiti-verification/-/blob/3be380b4222f974bedbefb228c8e75fbd9a7b3ae/data/wow2_rows_html.json}.
These references identify the formulas, not a current curator decision.'''
bib['src:definitions']=r'''E. DeLaVi\~na,
\emph{Written on the Wall II: Original invariant definitions},
\texttt{wowIIdefs.js}, Internet Archive snapshot of 12 May 2024,
13:36:36 UTC.
\url{https://web.archive.org/web/20240512133636id_/http://cms.uhd.edu/faculty/delavinae/research/wowII/wowIIdefs.js}.'''
ordered=[]
def enqueue_cites(t):
    for m in re.finditer(r'\\cite(?:\[[^\]]*\])?\{([^}]+)\}',t):
        for key in m[1].split(','):
            key=key.strip()
            if key not in ordered:ordered.append(key)
enqueue_cites(body)
i=0
while i<len(ordered):
    key=ordered[i]
    if key not in bib:raise ValueError('Missing bibliography entry '+key)
    enqueue_cites(bib[key]);i+=1
bibliography='\n\n'.join('\\bibitem{'+k+'}\n'+bib[k] for k in ordered)

text=(W/'preamble.tex').read_text()+'\n\\begin{document}\n'+body+'\n'
text+='\\clearpage\n\\addcontentsline{toc}{section}{References}\n\\begin{thebibliography}{99}\n'+bibliography+'\n\\end{thebibliography}\n\\end{document}\n'
# A harmless prose reflow keeps a long contact list inside the measure.
text=text.replace('Take five consecutive diagonal-path vertices $x_0,\\dots,x_4$, with\ncontacts $c_i,c_{i+2},c_{i+4},c_{i+1},c_{i+3}$.',
                  'Take five consecutive vertices $x_0,\\dots,x_4$ of a diagonal path.\nTheir contacts, in order, are $c_i,c_{i+2},c_{i+4},c_{i+1},c_{i+3}$.')
labels=re.findall(r'\\label\{([^}]+)\}',text)
refs=re.findall(r'\\(?:ref|eqref|pageref|autoref)\{([^}]+)\}',text)
missing=sorted(set(refs)-set(labels))
duplicates=[k for k,n in collections.Counter(labels).items() if n>1]
if missing or duplicates:raise ValueError({'missing':missing,'duplicates':duplicates})
if re.search(r'\\(?:input|include|includegraphics)\b',text):
    raise ValueError('Unexpected external manuscript dependency')
if re.search(r'(?<!\\)\bq?quad\b',text):raise ValueError('Unescaped spacing command')
if any(ord(c)<32 and c not in '\n\t' for c in text):raise ValueError('Unexpected control character')
OUT.mkdir(parents=True,exist_ok=True)
dest=OUT/(NAME+'.tex');dest.write_text(text)
audit={'file':str(dest),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),
       'standalone':True,'fragments':parts,'labels':len(labels),
       'bibliography_entries':len(ordered),'lines':text.count('\n'),
       'missing_references':missing,'duplicate_labels':duplicates,
       'bib_aliases':aliases,'source_fragment_hashes':
       {n:hashlib.sha256((S/n).read_bytes()).hexdigest() for n in parts}}
(W/'audits/assembly.json').write_text(json.dumps(audit,indent=2)+'\n')
print(json.dumps({k:v for k,v in audit.items() if k not in ('source_fragment_hashes','fragments','bib_aliases')}))
