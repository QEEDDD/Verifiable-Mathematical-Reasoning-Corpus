from pathlib import Path
import json,re,hashlib,collections

W=Path(__file__).resolve().parent
INPUT=W.parent/'transfer22_work/inputs'
manifest=json.loads((W/'audits/source_manifest.json').read_text())
summary=manifest['summary']
topics={
1:'434d proof; 394 counterexamples',
2:'392e/f counterexamples; auxiliary 133 and 269 reductions',
3:'395a counterexamples',
4:'434e proof; 382c counterexamples',
5:'269 counterexamples; auxiliary 189 and 384b reductions',
6:'302 counterexamples; auxiliary 389a sufficient conditions',
7:'298 and the prescribed $4k$-cycle theorem',
8:'384b critical profiles, kernels, and alteration bounds',
9:'133 density and equality bounds; 384b refinement; 189/199 notes',
10:'177/180 claw-free cases; 384b refinement; matching padding',
11:'133 path restrictions; 171 counterexamples; 384b small kernels',
12:'133 radius four; 382e counterexamples; forest and residue results',
13:'133 dominating-five-cycle branch; 154 counterexamples',
14:'133 nondominating branch; historical 354 refutation; 384b core connectivity',
15:'133 global $P_7$-free density; 384b rank refinement',
16:'133 even-cycle classification; 384b refinements; unigraph inheritance',
17:'155 low-leaf case; 199 split cases; 384b refinement; 61 triangle-free equality',
18:'133 $P_8$ cores and radius five; 199 balanced case; 384b refinement',
19:'133 $P_9$ cores; 199 clique bound; 384b sampling/order; 61 apex forests',
20:'384b sampling/order refinements; 61 matching--geodesic case',
21:'199 Hall equality and exact factor; 384b order-37 representative',
22:'199 strict capacity and reach; 384b exclusion of $h=35$'
}
papers=[]
for p in INPUT.rglob('*.tex'):
    rel=p.relative_to(INPUT)
    if len(rel.parts)==3 and rel.parts[1] in ('paper','papers'):
        papers.append({'round':int(rel.parts[0][-2:]),'path':str(rel),
                       'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
papers.sort(key=lambda x:(x['round'],x['file']))
counts=collections.Counter(p['round'] for p in papers)

out=[r'''\appendix
\section{Archive provenance and coverage}
\label{app:provenance}
The five supplied outer archives were opened recursively through their
twenty-two round archives. Their extracted files were compared with the
original member bytes by SHA-256. All 1,333 compared files matched; all
51 main \LaTeX{} manuscripts were among the matched files. No original
source archive was edited. The main source corpus contains 15,798 lines
of \LaTeX{}, before consolidation. Supporting proof notes and supplemental
manuscripts are included separately in the source map.

\subsection{Outer-archive identity}
The following full SHA-256 values identify the exact supplied bundles.
The final ``(1)'' in each local upload name is only the supplied filename
suffix. Each digest is printed on two lines, with no character omitted.
\begin{longtable}{rp{0.20\linewidth}p{0.61\linewidth}}
\toprule
Rounds&Bytes&SHA-256\\\midrule
\endfirsthead
\toprule Rounds&Bytes&SHA-256\\\midrule
\endhead
''']
for a in summary['archives']:
    rr=re.search(r'Rounds_(\d+)_(\d+)',a['archive'])
    digest=a['sha256']
    out.append(f"{int(rr[1])}--{int(rr[2])}&{a['bytes']:,}&\\texttt{{{digest[:32]}}}\\newline\\texttt{{{digest[32:]}}}\\\\[5pt]\n")
out.append(r'''\bottomrule
\end{longtable}

\subsection{Round-by-round mathematical coverage}
The table maps all rounds to retained content. Repeated improvements
of the same item are integrated into their strongest terminal statement;
their reusable lemmas and exact certificate dependencies are retained.
\begin{longtable}{rrp{0.70\linewidth}}
\toprule
Round&Main papers&Retained subject matter\\\midrule
\endfirsthead
\toprule Round&Main papers&Retained subject matter\\\midrule
\endhead
''')
for r in range(1,23):out.append(f'{r}&{counts[r]}&{topics[r]}\\\\[3pt]\n')
out.append(r'''\bottomrule
\end{longtable}
The early low-average result for 133 is contained in the later
unrounded-average theorem. The Round 11--14 five-, six-, and seven-cycle
arguments are included in the full global $P_7$-free proof. The separate
radius-four attachment proof is replaced by the already proved general
even-cycle theorem at $k=3$, after the complete radius-four reduction;
this substitution introduces no circular dependency. The earlier 384b
representative bounds are superseded by 37, while their structural and
sampling lemmas are proved in the combined chain. The balanced 199 proof
is supplied once and then reused for padding and Hall equality.

\subsection{Main-manuscript index}
Each filename below is relative to the indicated round's original
\texttt{paper/} or \texttt{papers/} directory. A twelve-hex-character
digest prefix is printed for convenience; the full hashes and exact
paths are in \texttt{provenance/source\_manifest.json} in the package.
The original source files are preserved there for comparison.
\begin{longtable}{rp{0.64\linewidth}l}
\toprule
Round&Main manuscript&SHA-256 prefix\\\midrule
\endfirsthead
\toprule Round&Main manuscript&SHA-256 prefix\\\midrule
\endhead
''')
for p in papers:
    out.append(f"{p['round']}&\\nolinkurl{{{p['file']}}}&\\texttt{{{p['sha256'][:12]}}}\\\\\n")
out.append(r'''\bottomrule
\end{longtable}

\section{Verification and reproducibility}
\label{app:verification}
The accompanying package contains the standalone manuscript, the
unmodified source materials retained for the proof record, the exact
certificate data, and rerun outputs from this consolidation. The
machine-readable manifests distinguish original source hashes from
outputs newly generated by a verifier. Exploratory search histories
do not substitute for the proved extension, reduction, or coverage
arguments in the paper.

\subsection{What was rerun}
The verification work is organized into the following groups. A
program count is an execution count within the specified group, not
a count of solved conjectures or independent human reviews.
\begin{center}
\begin{tabular}{p{0.22\linewidth}rp{0.60\linewidth}}
\toprule
Group&Programs&Scope\\\midrule
Early conclusions&10&434d/e checks; exact 394, 392e/f, 395a, 382c,
269, and 302 constructions; 298 coloring and the credited antecedent
chain's finite checks\\[4pt]
Later structural work&6&171, 382e, 154, and 354 witnesses; exact 389a
parameter inequalities; matching-padding and weak-majorization checks\\[4pt]
384b&21&Small kernels and their independent input coverage; exact rank,
sampling, matching-repair, and representative-order certificates\\[4pt]
133, 189, and 199&16&The two closed core certificates; the general
even-cycle path checks; four 189 reduction/example guards; nine 199
incidence, closure, factor, capacity, and warning-example checks\\\bottomrule
\end{tabular}
\end{center}
All listed final runs passed. The original mathematical arguments,
rather than the breadth of these finite tests, justify the analytic
theorems. The finite proof dependencies are identified in the body.

The $P_8$ certificate has 192 graph states, maximum state order 25,
and 93,895 required one-vertex extensions. The $P_9$ certificate has
13,930 graph states, maximum state order 45, and 442,204 contact-tree
nodes. Both checks account for every permitted branch, with zero
unexplained frontier. The maximum state orders are observed properties
of closed certificates, not assumptions on target graph order. Their
standard-library verifiers check paths and permutations directly.

For 384b, the 21 reruns include coverage of the small graph kernels,
not merely arithmetic on a list of unspecified completeness. Exact
integer and rational checks verify the potentials used for the later
matching repairs. The $h=35$ computation uses exactly thirteen active
matching edges, with the correct conditioned probabilities; it does
not replace them by independent-edge probabilities. The final
representative theorem additionally uses the analytic low-vertex
trimming and simultaneous-omission lemmas.

\subsection{Restored dependencies and explicitly limited reruns}
Two packaging issues required particular care. The Round 17
$\kappa=3$ checker expected a companion family JSON file that was
absent from its main verification directory but present in that
round's independent-audit snapshot. That original file was restored
to the rerun directory, with its hash recorded; the checker was
unchanged and then passed.

The Round 7 independent checker completed its mathematical tests but
then attempted to hash two prior manuscript snapshots absent from
the supplied archives. In a separately recorded copy, only those
final metadata hash operations were omitted. The mathematical tests
were unchanged. The original and adapted checker hashes and this
limited adaptation are recorded in the audit. The absent Gebendorfer
PDF/text snapshots were not reconstructed or represented as retrieved;
the credited mathematical antecedent chain is instead proved in
Section~\ref{early:sec:298} from the archived detailed audit and the
stated classical transversal theorem.

No external Lean certificate was rebuilt. No claim is made that every
historical exploratory enumeration or discovery program was rerun.
In particular, a historical output's older residual range or
``pending'' label is not used as the terminal theorem's status when
the subsequent audited proof gives a stronger conclusion.

\subsection{Using the package}
The root-level \texttt{README.txt} identifies the paper, source archive,
verification groups, and exact commands. The companion
\texttt{verify.py} lists or runs the recorded checks and compiles the
small C++ verifiers when needed. Python code uses either the standard
library or the explicitly listed graph-library dependency; C++ checks
use the documented compiler options. The paper itself is a single
\LaTeX{} source file with its bibliography inline and no external
figure or input-file dependency. It can be rebuilt by running
\texttt{pdflatex} until the cross-references stabilize.

\section{Attribution and consolidation corrections}
\label{app:attribution}
The following distinctions are maintained throughout the paper.
The total-domination--annihilation antecedents are credited to the
research record attributed to Gebendorfer; the classical transversal
bound is credited to Chv\'atal and McDiarmid. The half-coefficient
354 counterexample modifies a construction credited to Feit. The
precursor for the Maxine mechanism is credited to Cao and Eppstein.
The common-neighbor observation used in the induced-forest discussion
is credited to Gunderson and collaborators, as corrected in the
later source audit. The triangle-free $P_8$ classification is credited
to Chudnovsky and Stacho, and the $Y$--$\Delta$--Heawood graph is a
known graph. Hall's theorem, Hamiltonian closure, elimination-sequence
majorization, and the published matching bounds retain their original
attributions.

The consolidated 133 statements explicitly restore the connectedness
assumption of the original deficit and equality theorems. The phrase
``distance-two dominating'' is used for distance at most two from a
cycle, to distinguish it from two-neighbor domination. The local triangle
count is denoted consistently by $t(v)$, while the total local
independence is $\Lambda$. Graph6 data strings were compared with the
source strings and preserved. The 199 incidence formulation states
that an induced tree with two clique vertices may use only exclusive
neighbors, and a maximum such tree uses all of them. These are
clarifications of scope and notation during integration, not new
conjecture conclusions.

The finished manuscript preserves every complete original-item
conclusion and the proved partial programs through Round 22. No
post-Round-22 search, transfer to unrelated conjectures, or unproved
cycle-elimination assertion is included in the mathematical ledger.
''')
(W/'sections/appendices.tex').write_text('\n'.join(out))
(W/'audits/main_paper_index.json').write_text(json.dumps(papers,indent=2)+'\n')
print(json.dumps({'rounds':len(counts),'main_papers':len(papers),'appendix_lines':sum(s.count('\n') for s in out)}))
