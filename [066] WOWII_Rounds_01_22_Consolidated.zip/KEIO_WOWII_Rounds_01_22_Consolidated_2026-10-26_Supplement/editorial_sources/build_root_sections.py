from pathlib import Path
import re, json

ROOT = Path(__file__).resolve().parent
INPUT = ROOT.parent / 'transfer22_work' / 'inputs'
OUT = ROOT / 'sections'

def source(round_no, filename):
    return (INPUT / f'KEIO_WOWII_Round_{round_no:02d}' / 'papers' / filename).read_text()

def cut(s, start, stop):
    a = s.index(start)
    b = s.index(stop, a)
    return s[a:b]

def linecut(s, start, stop):
    return ''.join(s.splitlines(keepends=True)[start-1:stop])

BIB = {}
COMMON = {
    'wowii':'catalogue', 'WOWII':'catalogue', 'defs':'definitions',
    'ess':'ess', 'hp':'hof', 'hof':'hof', 'camby':'camby',
    'cwxpre':'cwxpre', 'cwx':'cwx', 'chen':'cwx', 'cameron':'cameron',
    'bh':'bh', 'ghp':'ghp', 'cs':'cs', 'heawoodfamily':'heawoodfamily',
    'fajtlowicz':'fajtlowicz', 'dlpw':'dlpw', 'CE':'ce', 'BC':'bc',
    'Hall':'hall', 'hall':'hall', 'fordfulkerson':'fordfulkerson'
}

def collect_bib(s, extra=None):
    mapping = COMMON | (extra or {})
    if r'\begin{thebibliography}' not in s:
        return
    body = s[s.index(r'\begin{thebibliography}'):s.index(r'\end{thebibliography}')]
    for match in re.finditer(r'\\bibitem\{([^}]+)\}(.*?)(?=\\bibitem|\Z)',body,re.S):
        key, text = match.groups()
        if key in mapping and mapping[key] is not None:
            BIB.setdefault('src:'+mapping[key], text.strip())

def norm(s, prefix, *, local=False, cites=None, demote=True):
    mapping = COMMON | (cites or {})
    s = re.sub(r'\\(label|ref|eqref|pageref|autoref)\{([^}]+)\}',
               lambda m: '\\'+m[1]+'{'+prefix+':'+m[2]+'}',s)
    def cite(m):
        keys=[]
        for key in m[2].split(','):
            k=key.strip()
            if k not in mapping or mapping[k] is None:
                raise ValueError(f'Unhandled citation {prefix}:{k}')
            keys.append('src:'+mapping[k])
        return '\\cite'+(m[1] or '')+'{'+','.join(keys)+'}'
    s = re.sub(r'\\cite(\[[^\]]*\])?\{([^}]+)\}',cite,s)
    if demote:
        s = s.replace(r'\subsection',r'\subsubsection').replace(r'\section',r'\subsection')
    s = s.replace(r'\appendix','')
    for macro, repl in {'ellav':r'\ell','ind':r'\alpha','N':'N','loc':r'\lambda',
                       'dist':r'\operatorname{dist}','ecc':r'\operatorname{ecc}',
                       'Compat':r'\operatorname{Compat}', 'symdiff':r'\triangle',
                       'capc':r'\operatorname{cap}_2','kap':r'\kappa'}.items():
        s = re.sub(r'\\'+macro+r'(?![A-Za-z])',lambda m:repl,s)
    if local:
        # The total local independence uses Lambda throughout these sections;
        # other parts of the paper reserve L for maximum spanning-tree leaves.
        # Protect graph6 literals, where an initial L is data, not notation.
        protected = r'\\(?:texttt|label|ref|eqref|pageref|autoref|cite|url|nolinkurl)\{[^\n]*?\}'
        parts = re.split('('+protected+')',s)
        s = ''.join(p if re.fullmatch(protected,p) else re.sub(r'\bL\b',lambda m:r'\Lambda',p) for p in parts)
    return s

r9 = source(9,'KEIO_WOWII_R09_133.tex')
r15 = source(15,'KEIO_WOWII_R15_133.tex')
r16 = source(16,'KEIO_WOWII_R16_133_cycles.tex')
r18p = source(18,'133_p8.tex')
r18r = source(18,'133_radius5.tex')
r19 = source(19,'133_p9.tex')
for s in (r9,r15,r16,r18p,r18r,r19): collect_bib(s)

pieces = [r'''\section{Local independence and induced-path density: Conjecture 133}
\label{sec:local-density}
For this part, let $p(G)$ be the maximum \emph{vertex order} of an induced
path, $r(G)=\rad(G)$, and
\[
 \lambda_G(v)=\alpha(G[N_G(v)]),\qquad
 \Lambda(G)=\sum_v\lambda_G(v),\qquad \ell(G)=\Lambda(G)/|V(G)|.
\]
The average $\ell$ is never rounded. A graph is called $C_4$-free here
only when it has no four-cycle as an ordinary subgraph, including one
with chords; $P_j$-free means no induced path on $j$ vertices.
The archived formulation of Conjecture 133 is
\begin{equation}\label{local:target}
 p(G)\ge r(G)+\ell(G)^{\chi_{C_4}(G)},
\end{equation}
where $\chi_{C_4}=1$ exactly in the $C_4$-free case
\cite{src:catalogue,src:definitions}. If a four-cycle occurs, a geodesic
gives $p\ge r+1$; the substantive branch is $p\ge r+\ell$.
In a $C_4$-free graph every neighborhood is a matching plus isolates.
Writing $t(v)$ for the number of triangles through $v$, and $t$ for
the number of triangles, therefore gives
\begin{equation}\label{local:potential}
 \lambda(v)=d(v)-t(v),\quad \Lambda=2m-3t,\quad
 \Lambda(G)-\Lambda(G-v)=2\lambda(v)-t(v).
\end{equation}
The next results retain the sharper deficit and equality information
from the earlier rounds before proving the stronger global $P_7$-free
bound. A clique cutset is a clique whose removal disconnects a connected
graph, and an atom is a connected graph with no clique cutset.
''']
p = cut(r9,r'\section{\texorpdfstring{An elementary',r'\section{\texorpdfstring{A $P_7$')
p = p.replace('If $G$ is $C_4$-free and $P_6$-free',
              'If $G$ is connected, $C_4$-free, and $P_6$-free')
p = p.replace(r'\eqref{eq:local}',r'\eqref{LOCALPOTENTIAL}')
p = norm(p,'local9',local=True).replace('local9:LOCALPOTENTIAL','local:potential')
pieces.append(p)

# Preserve the earlier strict deficit result, with its credited published input.
p = cut(r9,r'\section{\texorpdfstring{A $P_7$',r'\section{\texorpdfstring{A sharp')
p = p.replace('If $G$ is $C_4$-free and $P_7$-free',
              'If $G$ is connected, $C_4$-free, and $P_7$-free')
p = p.replace('$q=q(v)$','$q=t(v)$')
p = p.replace(r'\eqref{eq:local}',r'\eqref{LOCALPOTENTIAL}')
pieces.append(norm(p,'local9',local=True).replace('local9:LOCALPOTENTIAL','local:potential'))

pieces.append(r'''\subsection{The stronger global bound without an induced seven-vertex path}
\begin{theorem}\label{local15:thm:general}
Every $C_4$-subgraph-free, $P_7$-free graph satisfies $\Lambda(G)\le3n$.
\end{theorem}
It suffices to treat connected graphs, since the two sides are additive
over components. The proof proceeds through dominating and
nondominating five-cycles, the branch with neither a five- nor a
seven-cycle, and finally seven-cycle contacts.
''')
p = cut(r15,'We begin with two five-cycle statements',r'\section{The precise consequence')
pieces.append(norm(p,'local15',local=True))

p = cut(r9,r'\section{\texorpdfstring{A sharp',r'\section{Coverage of original')
pieces.append(norm(p,'local9',local=True))

pieces.append(r'''\section{Radius classifications for Conjecture 133}
\label{sec:local-radius}
The classical induced-path radius inequality used in this section is
\begin{equation}\label{local:chung}
 p(G)\ge2r(G)-1.
\end{equation}
It is recorded by Erd\H{o}s--Saks--S\'os with credit to Fan Chung
\cite[Section II, pp.~64--65]{src:ess}. We first prove an arbitrary-cycle
attachment theorem, then use connected domination to obtain complete
radius-four and radius-five classifications. These are statements about
all finite graphs with the stated hypotheses, not bounded-order searches.
\subsection{Dominating even cycles}
''')
p = cut(r16,r'\begin{theorem}\label{thm:main}',r'Original WOWII133')
p += cut(r16,r'\section{Contact sets and radius witnesses}',r'\begin{proof}[Proof of Corollary')
pieces.append(norm(p,'local16',local=True))
pieces.append(r'''\begin{corollary}\label{local16:cor:wow}
For $k\ge3$, Conjecture 133 holds for every connected graph with a
dominating induced $C_{2k}$, radius $k+1$, and $\ell\le k+1$.
\end{corollary}
\begin{proof}
The four-cycle-present case follows from a geodesic. Otherwise
\eqref{local:chung} settles $\ell\le k$. If $k<\ell\le k+1$,
Theorem~\ref{local16:thm:main} excludes $P_{2k+2}$-freeness, since its
classified graphs have $\ell\le2<k$. Hence
$p\ge2k+2\ge(k+1)+\ell$.
\end{proof}
''')

p = cut(r15,r'\section{Radius four:',r'\subsection{Contact classes and radius witnesses}')
p = norm(p,'local15',local=True)
p += r'''
\begin{proof}[Completion of the radius-four classification]
Lemma~\ref{local15:r4:lem:cycle} leaves $C_8$ or a dominating induced
$C_6$. The latter is precisely the $k=3$ case of
Theorem~\ref{local16:thm:main}. That theorem supplies both the attachment
restrictions and their converse, including $\Lambda=2n-t$.
The conclusions for $C_8$ follow directly. This proves
Theorem~\ref{local15:r4:thm:main}.
\end{proof}
'''
pieces.append(p)

# Radius-five proof, with internal rather than self-bibliographical dependencies.
p = cut(r18r,'For an even cycle',r'\section{Related work, reproducibility, and limitations}')
p = p.replace('two-dominating','distance-two dominating').replace('two-domination','distance-two domination')
p = p.replace('Original WOWII133 \\cite{wowii} asks for\n\\[\n p(G)\\ge r(G)+\\ell(G)^{\\chi_{C_4}(G)},\n\\]\nwhere $\\chi_{C_4}(G)=1$ precisely when $G$ has no four-cycle as a\nsubgraph, and is zero otherwise.\n','')
p = p.replace('We use the following two precise earlier classification results\n\\cite{radiusfour,dominatingcycle}. These are mathematical dependencies;\nthe present paper supplies the complete new two-level argument.',
              'We use the following two classification results, already proved in\nTheorems~\\ref{R4INPUT} and~\\ref{EVENINPUT}. The remaining argument\nclassifies all possible second-layer attachments.')
p = p.replace(r'\eqref{eq:L}',r'\eqref{LOCALPOTENTIAL}')
p = norm(p,'local18r',local=True)
p = p.replace('local18r:R4INPUT','local15:r4:thm:main').replace('local18r:EVENINPUT','local16:thm:main').replace('local18r:LOCALPOTENTIAL','local:potential')
pieces.append(r'''\subsection{The radius-five classification}
In this subsection, a cycle is \emph{distance-two dominating} if every
vertex of the graph has distance at most two from the cycle. This
distance condition is distinct from the two-neighbor condition in the
parameter $\gamma_2$.
'''+p)
pieces.append(r'''
\paragraph{Antecedents.}
Equal-length pendant-arm cores are classical ciliates. Relevant antecedents
include Fajtlowicz's characterization of radius-critical graphs and the
results on induced ciliates and radius equality discussed by DeLaVi\~na,
Larson, Pepper, and Waller \cite{src:fajtlowicz,src:dlpw}.
The attachment proofs above use the explicitly stated connected-domination
theorems.
''')

# Low-average corollary now follows after all its radius dependencies.
p = cut(r15,r'\begin{lemma}\label{lem:small}',r'\section{Finite checks, antecedents, and limitations}')
p = p.replace('the appendix excludes', 'Lemma~\\ref{R3INPUT} excludes')
p = p.replace("the appendix's $P_8$-free classification",'Theorem~\\ref{R4INPUT}')
p = p.replace('the\nappendix excludes','Lemma~\\ref{R3INPUT} excludes')
p = p.replace(r'\eqref{eq:wow}',r'\eqref{TARGET}').replace(r'\eqref{eq:chung}',r'\eqref{CHUNG}')
p = norm(p,'local15',local=True)
p = p.replace('local15:R3INPUT','local15:r4:lem:p6').replace('local15:R4INPUT','local15:r4:thm:main').replace('local15:TARGET','local:target').replace('local15:CHUNG','local:chung')
pieces.append(r'''\subsection{The unrounded average range up to four}
\begin{corollary}\label{local15:cor:four}
Conjecture 133 holds for every connected graph with $\ell(G)\le4$.
\end{corollary}
'''+p)

pieces.append(r'''\section{Closed core certificates and the final range for Conjecture 133}
\label{sec:local-certificates}
The finite objects in this section are proof certificates: every permitted
extension is accounted for, and the extension lemmas give them force at
arbitrary graph order. Explicit paths and adjacency-preserving permutations
are checked directly. The certificate files and independent verifiers are
included in the accompanying reproducibility package.
\subsection{Four cores without an induced eight-vertex path}
''')
p = cut(r18p,'Let $H$ be the graph',r'\section{Density and exact conjecture coverage}')
p = norm(p,'local18p',local=True)
pieces.append(p)
# P8 density proof retained; obsolete coverage statements omitted.
p = cut(r18p,r'\begin{proof}[Proof of Corollary',r'Original WOWII133')
p = p.replace(r'\eqref{eq:potential}',r'\eqref{LOCALPOTENTIAL}')
pieces.append(norm(p,'local18p',local=True).replace('local18p:LOCALPOTENTIAL','local:potential'))

pieces.append(r'\subsection{Eleven cores without an induced nine-vertex path}'+'\n')
p = cut(r19,r'Table~\ref{tab:models}',r'Original WOWII133 \cite{wowii} asks for')
# Use the extension lemma already proved in the P8 section.
a=p.index(r'\begin{lemma}\label{lem:forced}')
b=p.index("The new vertex's contact set",a)
p=p[:a]+r'''The deficient-vertex extension rule is
Lemma~\ref{FORCEDINPUT}, whose proof uses only four-cycle exclusion.
'''+p[b:]
p=p.replace(r'\ref{lem:forced}',r'\ref{FORCEDINPUT}').replace(r'\eqref{eq:potential}',r'\eqref{LOCALPOTENTIAL}')
p=norm(p,'local19',local=True).replace('local19:FORCEDINPUT','local18p:lem:extension').replace('local19:LOCALPOTENTIAL','local:potential')
pieces.append(p)
pieces.append(r'''\subsection{Final consolidated consequence for the original conjecture}
\begin{theorem}\label{local:final}
The original, unrounded Conjecture 133 holds for every connected graph
with $\ell(G)\le5$.
It also holds in the additional ranges $r=2$, $\ell\le7$, and
$r=3$, $\ell\le6$.
\end{theorem}
\begin{proof}
A graph containing a four-cycle is covered by the geodesic bound.
Assume $C_4$-freeness. Corollary~\ref{local15:cor:four} settles
$\ell\le4$. For $4<\ell\le5$, Corollary~\ref{local19:cor:density}
forces $p\ge9$, sufficient when $r\le4$. At radius five,
Theorem~\ref{local18r:thm:main} excludes $P_{10}$-freeness because all
its graphs have $\ell\le2$. Thus $p\ge10\ge5+\ell$.
For $r\ge6$, inequality~\eqref{local:chung} gives
$p\ge2r-1\ge r+5\ge r+\ell$.
More generally, $\ell>4$ forces $p\ge9$, which also covers the stated
radius-two and radius-three extensions. Their lower-average endpoints
are already included in Corollary~\ref{local15:cor:four}.
\end{proof}
The unrestricted inequality remains outside the conclusions of this
paper. The eleven-core proof does not need an external graph
classification theorem. The preceding four-core result credits the
triangle-free theorem of Chudnovsky--Stacho, and its $Y$--$\Delta$--Heawood
graph is a classical member of the Heawood family
\cite{src:cs,src:heawoodfamily}. Individual known graphs and earlier
parameter ranges are not counted as additional resolutions of an
original catalogue item.
''')

(OUT/'local_133.tex').write_text('\n\n'.join(pieces))

# Save bibliographic entries after the 199 section builder appends its sources.
def save_bib():
    (OUT/'root_bib.tex').write_text('\n\n'.join('\\bibitem{'+k+'}\n'+v for k,v in BIB.items())+'\n')

s17 = source(17,'KEIO_WOWII_R17_199_split.tex')
s18 = source(18,'199_balanced.tex')
s19 = source(19,'199_clique_bound.tex')
s21 = source(21,'199_hall_equality.tex')
s22 = source(22,'199_strict_capacity.tex')
for s in (s17,s18,s19,s21,s22): collect_bib(s)

split = [r'''\section{Traceability in split graphs: Conjecture 199}
\label{sec:split-small}
This and the following two sections consolidate the split-graph results
of Rounds 17--22. All path conclusions refer to a Hamiltonian path.
The maximum induced-tree order is written $\tau$ here to distinguish
it from the maximum induced-forest order used elsewhere.
''']
p = cut(s17,r'\section{Definitions and the precise scope}',r'\section{What remains outside the result}')
split.append(norm(p,'split17'))

split.append(r'''\section{Balanced incidence and the clique-size bound}
\label{sec:split-bounds}
Continue with $V(G)=C\mathbin{\dot\cup}I$, $A_c=N(c)\cap I$,
$q=|C|$, $h=|I|$, row degrees $r_i$, and column sizes $s_c=|A_c|$.
The conditions in~\eqref{split17:eq:columns} may also be imposed with
an integer lower bound $k$ that is not necessarily the minimum row
degree. We use that slightly more general incidence formulation below.
''')
p = cut(s19,r'\begin{theorem}\label{thm:graph}',r'\section{Split incidence inequalities')
p = p.replace(r'\eqref{eq:original}',r'\eqref{ORIGINAL}')
p = norm(p,'split19').replace('split19:ORIGINAL','split17:eq:original')
split.append(p)
split.append(r'''For a missing incidence $ic$, the full degree of the
clique vertex is $q-1+s_c$. The path-closure rule of
Lemma~\ref{split17:lem:closure} therefore permits its addition whenever
\begin{equation}\label{split19:eq:threshold}
 r_i+s_c\ge h.
\end{equation}
Only incidences are added, and degrees never decrease.
''')
p = cut(s19,r'\section{The main incidence theorem}',r'\section{Scope of the remaining problem}')
p += cut(s19,r'\section{Proof of the balanced deficit dependency}',r'\begin{thebibliography}')
p = p.replace('included in Appendix~\\ref{sec:balanced}', 'included in Subsection~\\ref{sec:balanced}')
p = norm(p,'split19')
for old,new in {'split19:lem:setup':'split17:lem:setup','split19:lem:closure':'split17:lem:closure',
                'split19:eq:incidence':'split17:eq:columns'}.items(): p=p.replace(old,new)
split.append(p)
split.append(r'''\subsection{Padding the independent side}
\begin{corollary}\label{split:padding}
Suppose the incidence conditions~\eqref{split17:eq:columns} hold, and let
$m=\max_c|A_c|$. If $0\le b=q+1-h\le k+1-m$, the associated split graph
is traceable.
\end{corollary}
\begin{proof}
Add $b$ independent vertices, each adjacent to every clique vertex.
Every column size becomes at most $m+b\le k+1$, while all pairwise
symmetric differences are unchanged. Old rows retain degree at least
$k$, and new rows have degree $q\ge k$. The new graph has $q+1$ rows,
so Lemma~\ref{split19:lem:balanced} gives a spanning path.
Delete the added independent vertices from that path. Each internal
deletion is spliced through the edge between its two clique neighbors;
an endpoint deletion shortens the path. Added rows are pairwise
nonadjacent, so these operations leave a simple path through every
original vertex exactly once.
\end{proof}
''')

split.append(r'''\section{Hall equality, exact factors, and alternating reach}
\label{sec:split-capacity}
We now identify the residual incidence obstruction after all the
traceability cases above. An induced tree of a split graph contains
at most two clique vertices: with one it is a star; with two it may
use only their exclusive independent neighbors, and a maximum such
tree uses all of them.
Consequently
\[
 \tau(G)=\max\bigl(\{1\}\cup\{1+|A_c|:c\in C\}
 \cup\{2+|A_c\triangle A_d|:c\ne d\}\bigr),
\]
omitting an empty collection of pairs. Thus the original premise is
captured exactly by the following incidence bounds when
$k=\kappa(G)=\min_i r_i$; the matrix results permit any lower bound $k$:
\begin{equation}\label{split21:H}
\begin{gathered}
 k\ge1,\quad \varnothing\ne A_c\subseteq I,\quad
 r_i:=|\{c:i\in A_c\}|\ge k,\\
 |A_c|\le k+1,\qquad |A_c\triangle A_d|\le k\quad(c\ne d).
\end{gathered}
\end{equation}
For $S\subseteq I$, write $N(S)=\{c:A_c\cap S\ne\varnothing\}$.
''')
p = cut(s21,r'\section{Hall inequalities and equality}',r'\section{Traceability consequences and their explicit dependencies}')
split.append(norm(p,'split21'))
split.append(r'''\subsection{Eliminating every nonempty Hall-equality set}
\begin{proposition}\label{split21:inputs}
Under~\eqref{split21:H}, the split graph is traceable if $h\le q\le2k$
or $h=q+1$. When $h=q$, the hypotheses imply $q\le2k$.
\end{proposition}
\begin{proof}
These are Theorem~\ref{split19:thm:matrix} and
Lemmas~\ref{split19:lem:balanced} and~\ref{split19:lem:side-size},
whose complete proofs appear above.
\end{proof}
''')
p = cut(s21,r'\begin{corollary}\label{tighttrace}',r'\section{Remaining scope}')
p = p.replace(r'\ref{inputs}(1)',r'\ref{inputs}')
split.append(norm(p,'split21'))

# The last round: replace prior-manuscript citations by exact internal references.
p = cut(s22,r'\section{Hypotheses and explicit inputs}',r'\section{Scope and reproducibility}')
p = p.replace(r'\cite{hallequality}',r'(Theorem~\ref{FACTORINPUT} and Corollary~\ref{STRICTINPUT})')
p = p.replace(r'\cite{cliquebound}',r'(Theorem~\ref{MATRIXINPUT})')
p = p.replace('The earlier degree-two factor theorem', 'The degree-two factor theorem')
p = p.replace('A second earlier\ninput', 'A second\ninput')
p = norm(p,'split22')
p = p.replace('split22:FACTORINPUT','split21:factor').replace('split22:STRICTINPUT','split21:strict').replace('split22:MATRIXINPUT','split19:thm:matrix')
p = p.replace('The Hall-equality reduction in (Theorem~\\ref{split21:factor} and Corollary~\\ref{split21:strict})',
              'Corollary~\\ref{split21:strict}')
split.append(p)
split.append(r'''\subsection{The precise unresolved step}
Combining the preceding results, a nontraceable split graph satisfying
the original premise would have $k\ge4$, $q\ge2k+1$, $h\le q-1$,
strict Hall on every nonempty subset of $I$, and
\[
 \operatorname{cap}_2(S)\ge2|S|+1
 \qquad(\varnothing\ne S\subseteq I).
\]
It has a factor with degree exactly two on $I$ and at most two on $C$,
and each cycle in such a factor has a directed alternating route to
unused clique-side capacity. The displayed twelve-vertex example
shows why an arbitrary shortest switch cannot be assumed to lower the
number of cycles. A proof that suitable switches eliminate all cycles
has not been supplied. Hence these results resolve explicit split
subclasses and strengthen the residual obstruction; they do not resolve
all split graphs or unrestricted Conjecture 199.
''')
(OUT/'split_199.tex').write_text('\n\n'.join(split))

save_bib()
print(json.dumps({'local_133_lines':sum(p.count('\n') for p in pieces),
                  'split_199_lines':sum(p.count('\n') for p in split),
                  'root_bib_entries':len(BIB)}))
