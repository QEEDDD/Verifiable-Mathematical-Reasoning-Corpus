from pathlib import Path

ROOT = Path('/workspace/scratch/c40d72ef0af2')
B = ROOT / 'tmp/round12/build'
parts = [r'''\section{Further partial results and a formulation-dependent counterexample}
\label{revision:research}
This section records the further results obtained while revising the
consolidation. The original-item ledger remains at fourteen conclusions.
The new theorems enlarge proved subclasses of 40, 61, 165, and 199,
restrict the residual profile of 384b, and refine a connected-domination
equality case. For 389a a complete counterexample is obtained only after
specifying the lower-rank quartile convention; it is kept separate from
an unqualified resolution of the archived statement. None of the
restricted-class results is asserted to settle its unrestricted entry.

''']
sources = [
    'induced/support_graph_extension.tex',
    'induced/pathcover40_corollary.tex',
    'leaf/partial165.tex',
    '199/alpha_gap_two.tex',
    '199/alpha_gap_three.tex',
    '384/h33_restriction.tex',
    '189/quartile_leaf_extension.tex',
    '189/389a_rounding_counterexample.tex',
    'crosscheck/strict_containment.tex',
]
for rel in sources:
    s = (ROOT / 'tmp/round12' / rel).read_text()
    if rel.endswith('pathcover40_corollary.tex'):
        s = s.replace('have a vertex cover $C$ of size $k$',
                      'have a nonempty vertex cover $C$ of size $k$')
    if rel.endswith('partial165.tex'):
        s = s.replace(r'\section{', r'\subsection{', 1)
        s = s.replace('used there in the proof of statement 155 for $L(G)\\leq3$.',
                      'used in the proof of Theorem~\\ref{late:leaves:main}.')
    if rel.endswith('alpha_gap_three.tex'):
        s = s.split('% Add to the integrated manuscript')[0]
    if rel.endswith('h33_restriction.tex'):
        s = s.replace('\\[\n\\begin{array}{c|rrrrrrrr}',
                      '\\begingroup\\setlength{\\arraycolsep}{2pt}\n\\[\n\\begin{array}{c|rrrrrrrr}')
        s = s.replace('\\end{array}\n\\]\nand the unmatched',
                      '\\end{array}\n\\]\n\\endgroup\nand the unmatched')
    if rel.endswith('quartile_leaf_extension.tex'):
        s = r'''\subsection{The first-quartile-one case of 389a}
\label{revision:389q1}
Retain the notation and source distinction of Section~\ref{late:389a}.
The following bounds treat the small quartile value analytically.
'''+s
        s = s.replace('Use the existing cut bound',
                      'Use the cut bound of Lemma~\\ref{late:389a:cut}')
    parts.append(s+'\n\n')
(B / 'accepted_research.tex').write_text(''.join(parts))
print('Assembled', len(sources), 'audited research fragments')
