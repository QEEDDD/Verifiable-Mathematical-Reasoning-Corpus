from pathlib import Path
import re,json,hashlib
ROOT=Path('/workspace/scratch/c40d72ef0af2'); B=ROOT/'tmp/round12/build'
BASE=ROOT/'upload/KEIO_WOWII_Rounds_01_22_Consolidated_2026-10-26(1).tex'
OUT=ROOT/'output/pdf/wowii_merged/KEIO_WOWII_Rounds_01_22_Consolidated_2026-10-26.tex'
s=BASE.read_text()
def replace_once(a,b):
 global s
 assert s.count(a)==1,(a[:80],s.count(a));s=s.replace(a,b)
replace_once(r'\large An integrated account of Rounds 1--22}',r'\large An integrated account of Rounds 1--22 with structural extensions}')
replace_once(r'\date{26 October 2026}',r'\date{26 October 2026\\[3pt]\small Revised integrated edition}')
replace_once('Statement 392e fails on $G_r$ with deficit $r-1$ and on $J_r$ with\ndeficit $r-2$.  Statement 392f fails on $J_r$ with deficit $r-3$.',
'''Statement 392e fails on $G_r$ for every $r\\geq2$, with deficit $r-1$,
and on $J_r$ for every $r\\geq3$, with deficit $r-2$.
Statement 392f fails on $J_r$ for every $r\\geq4$, with deficit $r-3$.
The displayed deficit formulas remain valid at the smaller defined values
of $r$, but a zero or negative deficit is not a counterexample.''')
a='''The prior PDF and text snapshots named
in that audit are absent from the supplied ZIPs; the reconstruction
uses the mathematical arguments recorded in the audit, and every
needed step is proved here.  No Lean rebuild or live validation of
the linked repository record is claimed.'''
b='''The prior PDF and text snapshots named in that audit were absent from
the supplied ZIPs. During preparation of this revised edition, the primary
manuscript archive was independently retrieved from the attachment to
issue 7242. Its SHA-256 digest matched the recorded value, and its six-page
written proof was read against the required dependency chain. The
reconstruction below was checked against that primary text; every needed
step is also proved here. No Lean rebuild is claimed.'''
replace_once(a,b)
a='''The absent Gebendorfer
PDF/text snapshots were not reconstructed or represented as retrieved;
the credited mathematical antecedent chain is instead proved in
Section~\\ref{early:sec:298} from the archived detailed audit and the
stated classical transversal theorem.'''
b='''That limited adaptation belongs to the original consolidation record.
For the revised edition, the primary manuscript archive was independently
retrieved and the written proof checked. The archive digest is
\\begin{center}\\small\\texttt{d067e88bdbf41f4fd4405b61e7cc71acfc9e4a6a6e64d7ca8d55f35b289d2afc}\\end{center}
The source URL, retrieval record, and dependency audit are retained in
\\nolinkurl{provenance/revision/298_primary_audit.md}. The classical
transversal bound and all author attributions remain unchanged.'''
replace_once(a,b)
# Additional independent-domination corollaries are placed with their parent proofs.
ext=(ROOT/'tmp/round11/inddom/extensions.tex').read_text()
ext=ext.replace('finite simple graph without isolated vertices','nonempty finite simple graph without isolated vertices').replace('d(\\overline G)','d_*(\\overline G)')
ext=ext.replace('The complement-core proof of the distance-four packing theorem uses','The complement-core proof of Theorem~\\ref{early:thm:434d-packing} uses')
ext=ext.replace('The local-cover proof gives','Corollary~\\ref{early:cor:center-degree} gives').replace('in that proof','in the proof of Theorem~\\ref{early:thm:center-local}')
ext='''\\subsection{Further consequences of the packing and cover arguments}
The following two consequences extend the preceding arguments. They do
not add catalogue identifiers to the fourteen-item ledger.
'''+ext+'\n'
anchor=r'\section{Rooted constructions for two-domination counterexamples}'
replace_once(anchor,ext+anchor)
# New394 structural chapter.
new=(ROOT/'tmp/round11/twodom/extension394.tex').read_text()
new=new.replace('\\section{Further structure of the already refuted statement 394}',r'\section{Triangle-free obstructions and the bipartite boundary of 394}')
new=new.replace('The supplied Round 1 already refutes WOWII 394. The following results are\nextensions of that refutation, not newly resolved numbered entries.',
'''The clique module in Corollary~\\ref{early:cor:394} already refutes 394.
We now show that failure persists without triangles, while bipartiteness
suffices for validity. These are extensions of the same refutation, not
newly resolved numbered entries.''')
new=new.replace('Its violation of 394 is $r-1$. In particular $r=2$ gives a',
'''Its deficit in 394 is $r-1$, so every $r\\ge2$ is a counterexample.
In particular $r=2$ gives a''')
new=new.replace('Thus 394 fails by $r-1$. At $r=2$', 'Thus the deficit is $r-1$, so 394 fails for every $r\\ge2$. At $r=2$')
new=new.replace('The standard-library checker supplied with this chapter',r'The standard-library checker \nolinkurl{verification/extensions/module394/verify_extension394.py}')
anchor=r'\section{Total domination and distances between centers: statement 269}'
replace_once(anchor,new+'\n\n'+anchor)
# Clarify inclusion beyond the original22rounds without changing the ledger.
a='''fourteen source-qualified conclusions were reached by Round 14; later
rounds strengthen partial results without increasing that count.'''
b='''fourteen source-qualified conclusions were reached by Round 14; later
rounds strengthen partial results without increasing that count.
This revised edition also proves triangle-free counterexample families
for 394, its validity on bipartite graphs, and an exact bound using an
odd-cycle transversal, together with further independent-domination
corollaries.'''
replace_once(a,b)
anchor=r'\subsection{The strongest retained partial results}'
text='''\\subsection{Structural extensions in the revised edition}
Section~\\ref{r11td:extension} allows arbitrary internal graphs of minimum
degree at least two in the 394 spoke construction, gives triangle-free
counterexamples on 15 and 19 vertices and corresponding infinite families,
proves 394 on bipartite graphs, and derives an odd-cycle-transversal bound
attained by both new families. The independent-domination section also
extends the packing inequality to nonempty graphs without isolated vertices
and proves $\\diam(G)\\leq2(d_*(\\overline G)+1-i(G))+3$ for connected
nontrivial graphs. These are stronger structural results for already
counted entries. They do not increase the fourteen-item count.

'''
replace_once(anchor,text+anchor)
# Update the terminal partial-result ledger to include the revised scope.
replace_once('The last two regimes give the stronger difference bound\n$f-\\res\\ge\\lceil\\diam/2\\rceil$.&\n\\S\\ref{late:equality}, \\ref{late:apex}, \\ref{late:geodesic}',
'''The last two regimes give $f-\\res\\ge\\lceil\\diam/2\\rceil$.
In addition, all support-graph expansions with private leaves in
Theorem~\\ref{r12support:main}, without a triangle-free assumption.&
\\S\\ref{late:equality}, \\ref{late:apex}, \\ref{late:geodesic},
\\ref{r12support:section}''')
replace_once('61&Triangle-free graphs',
'''40&Graphs with a nonempty vertex cover whose every vertex has at least
two pendant neighbors.&Proposition~\\ref{r12support:forty}\\\\[5pt]
61&Triangle-free graphs''')
replace_once('177, 180&All connected claw-free graphs',
'''165&Maximum degree at most two; or independent maximum-degree set
$M$, $3\\le\\Delta\\le5$, with every vertex outside $M$ of degree
at most two. The latter class satisfies $L\\ge2+|N(M)\\setminus M|/4$.&
\\S\\ref{r12leaf:sec165}\\\\[5pt]
177, 180&All connected claw-free graphs''')
replace_once('directed alternating reach.&\nSections~\\ref{sec:split-small}--\\ref{sec:split-capacity}',
'''directed alternating reach. The revision also proves
$\\alpha\\le\\kappa+3$ under the original premise, using the
Tan--Hung classification for the last boundary.&
\\S\\ref{sec:split-small}--\\ref{sec:split-capacity},
\\ref{r12:199:gap-three}''')
replace_once('a connected representative has order at most 37 and $11\\le h\\le33$.&\nTheorem~\\ref{paired:terminal}',
'''a connected representative has order at most 37 and $11\\le h\\le33$.
At $h=33$, a counterexample has exactly two cubic vertices with triangle
counts two and three, and the stated attachment restrictions.&
Theorem~\\ref{paired:terminal}; \\S\\ref{r12:384h33}''')
replace_once('of low-degree vertices, and a specified third-quartile convention.\nThe original ambiguity at nonintegral quartile ranks is retained.&\nSection~\\ref{late:389a}',
'''of low-degree vertices, and a specified first-quartile convention.
The upper-rank quartile-one case holds. An explicit eleven-vertex
counterexample refutes the lower-rank reading; the source ambiguity
is retained and no unqualified closure is counted.&
\\S\\ref{late:389a}, \\ref{revision:389q1}, \\ref{r12:389a:rounding}''')
replace_once('corollaries.\n',
'''corollaries. Further restricted results concern 40, 61, 165, 199, and
384b. An eleven-vertex counterexample refutes the lower-rank quartile
reading of 389a, while the upper-rank quartile-one case is proved;
neither result is counted as an unqualified resolution of 389a.
''')
replace_once(r'\begin{thebibliography}{99}',r'''\begin{thebibliography}{99}
\bibitem{TanHung2004}
N. D. Tan and L. X. Hung,
Hamilton cycles in split graphs with large minimum degree,
\emph{Discussiones Mathematicae Graph Theory} 24 (2004), 23--40.
\url{https://doi.org/10.7151/dmgt.1210}.
''')
a='''The finished manuscript preserves every complete original-item
conclusion and the proved partial programs through Round 22. No
post-Round-22 search, transfer to unrelated conjectures, or unproved
cycle-elimination assertion is included in the mathematical ledger.'''
b='''The revised manuscript preserves every complete original-item conclusion
and the proved partial programs through Round 22. The subsequent structural
extensions are identified separately. No unproved cycle-elimination claim,
finite failure to find a counterexample, or exploratory search is promoted
to a full resolution. The 392e/f family statement now explicitly restricts
``fails'' to positive-deficit parameters: $r\\ge3$ and $r\\ge4$ respectively
for $J_r$; the original principal witnesses are unchanged.'''
replace_once(a,b)
# Revisionverification summary; append only research items actually accepted.
extra=B/'accepted_research.tex'
if extra.exists():
 content=extra.read_text()
 anchor=r'\section{Archive provenance and coverage}'
 # Insert before appendix, so it remains a mathematical section.
 before=s.index(r'\appendix')
 s=s[:before]+content+'\n'+s[before:]
anchor=r'\subsection{Using the package}'
text='''\\subsection{Checks added for the revised edition}
The original 53-program verification record remains a historical record
of the supplied consolidation. In this edition the additional 394 checker
was rerun on the triangle-free 15- and 19-vertex witnesses, enumerating
all $2^{15}$ and $2^{19}$ vertex subsets respectively and independently
checking maximum matching, local independence, and odd-cycle-transversal
numbers. The new results have direct written proofs for arbitrary family
size. Additional independent checks and research-specific certificates are
identified under the \\texttt{extensions} verification group. Original
proof-certificate data and source texts are preserved.

'''
replace_once(anchor,text+anchor)
# Avoid dangling claims of originalPDF absence outside its historical context.
OUT.parent.mkdir(parents=True,exist_ok=True);OUT.write_text(s)
labels=re.findall(r'\\label\{([^}]+)\}',s);refs=re.findall(r'\\(?:ref|eqref|pageref)\{([^}]+)\}',s)
assert len(labels)==len(set(labels)), 'duplicate labels'
assert set(refs)<=set(labels),set(refs)-set(labels)
assert not re.search(r'\\(?:input|include|includegraphics|bibliography)\{',s),'external input'
(B/'integration_record.json').write_text(json.dumps({'source_tex_sha256':hashlib.sha256(BASE.read_bytes()).hexdigest(),'revised_tex_sha256':hashlib.sha256(OUT.read_bytes()).hexdigest(),'source_lines':len(BASE.read_text().splitlines()),'revised_lines':len(s.splitlines()),'added_394_section':True,'added_inddom_corollaries':True,'recovered_primary298':True,'corrected_392ef_thresholds':True,'extra_research_file_present':extra.exists()},indent=2))
print(OUT,len(s),'characters')
