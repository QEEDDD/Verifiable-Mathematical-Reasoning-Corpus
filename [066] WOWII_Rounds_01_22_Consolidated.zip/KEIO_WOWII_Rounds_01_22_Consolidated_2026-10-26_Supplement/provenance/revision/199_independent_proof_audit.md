# Independent audit of the new 199 boundary

Read `tmp/round12/199/alpha_gap_two.tex` in full.

Verdict: PASS for the written near-balanced row-degree criterion and its application to split instances of WOWII199 with alpha <= kappa+2. This is a restricted-class theorem, not a resolution of unrestricted199.

Checks:
1. A missing incidence ic has total degree sum rowdeg(i)+(q-1)+coldeg(c). Thus the incidence closure threshold h is exactly the path-closure threshold n-1.
2. In a closed graph each nonempty column of size at least2 is universal, since every row still has degree at least h-2.
3. Universal columns and singleton columns partition C. For u<=h-4 each row has two private columns; concatenating clique-ended length2 paths is valid.
4. For u=h-3, replacing the first and third row gaps by two-private-column gaps consumes exactly four private columns and leaves exactly h-3 ordinary gaps, one per universal column. This includes h=4 correctly.
5. For u=h-2, proper Hall forces private columns at two different rows. The stated prepend x,cx,cy,y followed by an alternating path covers all rows without repetition.
6. For u>=h-1, an ordinary alternating path covers all rows. Every unused clique vertex has some neighbor i in I. Since i is on the path and every incident path edge at i goes to C, insertion into such an edge is valid, including when i is an endpoint.
7. The corollary's maximal independent partition has no empty column. Its row degrees are at least kappa. At alpha=kappa+2 these are exactly the lemma's h-2 threshold; the previously proved proper-Hall lemma supplies the remaining hypothesis.
8. In the example with h=k+2, q=2k+1, k+1 columns missing x and k other columns missing distinct other rows, x has degree k and all other rows have degree >=2k. Removing N(x) disconnects x; removing fewer than k vertices cannot disconnect the split graph. Thus kappa=k. Each column has k+1 neighbors in I; any induced tree has at most two clique vertices, and for two such vertices the leaf contribution is at most the symmetric difference size2. Hence tau=k+2. Every proper subset of at least2 rows meets every column, so strict Hall holds. The family lies outside the listed small-clique/padding/small-connectivity branches.

No additional finite computation was needed for this independent audit. The author's separate computations should be described as checks, not as the universal proof.

## Gap-three application: independent PASS

Read `tmp/round12/199/alpha_gap_three.tex` and the original manuscript's `split21:strict` corollary. Independently opened the author-uploaded Tan--Hung article and inspected Theorem 1 (article page 24) and Table 1 (page 27):
https://www.researchgate.net/publication/254863724_Hamilton_cycles_in_split_graphs_with_large_minimum_degree

The source requires its neighborhood inequality only for subsets of the stated independent part with cardinality between m-2 and min(m,n-1). Its exceptional cases for m>=6 are precisely spanning subgraphs of G^m_n. Table 1 gives h-3 independent vertices sharing a neighborhood of at most h-2 vertices.

All hypotheses are met: strict Hall in G implies |C|>=h+1, adding a universal vertex raises all row degrees to at least h-2, and raises the neighborhood lower bound to |S|+2. Clique degrees are at least h+1. The exceptional h-3 vertices would violate this lower bound. This remains valid even if an exceptional graph isomorphism does not preserve the chosen partition: any exceptional low-degree row has degree at most h-2 and therefore cannot belong to our clique, whose vertices have degree at least h+1. Thus its obstructing set is necessarily contained in our I.

Removing the added universal vertex from a Hamilton cycle leaves a spanning path. In the WOWII199 application, the earlier strict-Hall corollary is exactly applicable to a hypothetical nontraceable split graph under the original premise. The new boundary h=k+3 gives row degrees at least h-3. Hence alpha<=kappa+3 is established, leaving alpha>=kappa+4 for any residual nontraceable split instance. This is a new application within the manuscript, not a new Hamiltonicity classification or a complete resolution of 199.

The displayed gap-three family also checks algebraically: row 0 has degree k; row 1 has degree k; every other row has at least 2k-1 neighbors. All columns have k+1 neighbors and distinct omitted pairs. An induced tree with one clique vertex has at most k+2 vertices; with two clique vertices it has at most six, which is at most k+2 for k>=4. Thus tau=k+2. Removing fewer than k vertices cannot disconnect, while deleting the neighborhood of row 0 isolates it, so kappa=k. Singletons have at least k neighbors, every pair has at least 2k neighbors, and any larger row set meets all 2k+1 columns; these give strict Hall, including the full row set because 2k+1>=k+4 for k>=3.
