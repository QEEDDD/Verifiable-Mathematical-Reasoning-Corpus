# Independent audit: supplied WOWII 269, 298, and 302

Date: 26 October 2026. Auditor: round11_totaldom.

## Verdict

**PASS for all three mathematical arguments, on the source conventions explicitly stated in their manuscripts.**

- 269: the original ceiling lower bound is false; the supplied infinite C4-free family is valid.
- 298: the exact four-cycle-indicator upper bound follows from the supplied prescribed-4k-cycle proof and the explicitly credited prior theorem of Gebendorfer. I retrieved and read that prior manuscript in full and checked its required proof chain.
- 302: the original upper bound is false; the supplied family has unbounded additive deficit.

This audit does not claim historical priority, publication acceptance, or a Lean rebuild. These are supplied results being integrated, not newly discovered closures in this audit.

## 269

Read the complete R05 TeX. The C4-freeness argument is sound: the undecorated carrier has only 6- and 8-cycles, and each triangle vertex is attached to a distinct original edge. Adding one cannot create a 4-cycle because the original edge endpoints have no third common neighbor.

The four listed neighborhoods are pairwise disjoint, proving gamma_t >= 4; the four hubs form a total dominating set, proving equality. The complete distance tables imply radius = diameter = 4 and every vertex central. Their histograms, Wiener sum and excess polynomial are correct. In the minimum-within-family calculation, 4N^2-524N-119 is convex and has equal negative values at N=0,131, so it is negative throughout that interval. This is only family-relative minimality, correctly stated.

Independent program `audit.py` reconstructs four parameter pairs, including (62,35), without importing supplied builders/checkers. It checks all BFS distances, all vertex-pair common-neighbor counts, exact total domination by a branch-and-bound open-neighborhood hitting-set solver, and the symbolic histogram formulas.

At (62,35): n=268, m=433, gamma_t=4, histogram (N1,N2,N3,N4)=(433,9070,16333,9942), mean=17890/5963=3+1/5963. Thus the source target is 4 >= 5, false.

## 302

Read the complete R06 TeX. The two-case total-domination lower bound is valid. Omitting some t_i forces every b_j, then a w_h and an additional neighbor of w_h, hence q+2 vertices. Selecting every t_i requires one additional vertex in each of their disjoint open neighborhoods, hence 2r vertices. Both displayed upper-bound sets are valid.

The even-distance table is correct, including the column/row overlap and exceptional t_j contribution for l_ij. The only large clique is Q, and v is the only vertex anticomplete to Q, proving complement-local-independence frequency exactly one. The formula uses local independence, not spectral multiplicity.

`audit.py` independently checks five pairs through (r,q)=(6,10), with up to 84 vertices. It computes full distances, exact clique numbers of every induced nonneighborhood using maximal clique enumeration, all table entries, and exact total domination using its own hitting-set solver. All pass. At (4,6), n=40,m=85,gamma_t=8,min_even=6,frequency=1.

## 298 new deduction

Read the complete R07 TeX. All additional arguments are sound:

1. At cutoff degree two, a(G)=floor((m+l)/2).
2. Removing an edge with a degree-at-least-three endpoint cannot increase annihilation at this cutoff. The exchange proof has the correct budget m-1 after deletion and handles the only problematic degree sum m+1.
3. In a unicyclic graph with 4k-cycle, the restricted open-neighborhood incidence graph is a subgraph of two copies of G. Alternating its 2k cycle variables and extending along incidence trees gives two valid total dominating sets S union Q_i. This proves gamma_t <= floor((n+|S|)/2).
4. Every connected non-unicyclic graph with a specified cycle has a nonbridge edge outside that cycle with an endpoint of degree at least three. The proof covers intersecting and disjoint extra cycles.
5. The minimum-edge argument preserves the prescribed 4k-cycle and connectivity, and uses gamma_t(G)<=gamma_t(G-e)<=a(G-e)<=a(G) in the correct direction.

The high-cutoff and global a+1 results are prior input, not original results of R07.

## Independently retrieved prior input

Primary issue: https://github.com/google-deepmind/formal-conjectures/issues/7242
Created 2026-10-12T21:47:03Z.
Primary attachment: https://github.com/user-attachments/files/33357596/Total_Domination_Annihilation_Intake_2026-10-12.zip
SHA256: d067e88bdbf41f4fd4405b61e7cc71acfc9e4a6a6e64d7ca8d55f35b289d2afc

The Web tool could not fetch GitHub, but direct urllib retrieval succeeded. The source is preserved in `prior/prior.zip`, `prior/source/paper.pdf`, and `prior/paper.txt`; issue metadata/body is `prior/issue7242.json`.

Read all six manuscript pages, not just its abstract. The required chain is valid:

- Lemma 2: mixed-hypergraph potential induction, including the 2-edge endpoint reduction and degree-one shortening.
- Lemma 3: selecting smallest high-degree vertices gives the annihilation degree budget.
- Proposition 4: strong-support deletion; then support/core partition, open-neighborhood hypergraph, and exact accounting. Adjacent supports are permitted and handled.
- Corollary 5: gamma_t <= a at cutoff >= 3.
- Lemma 7: incidence-forest coloring for trees.
- Lemma 8: low-cutoff cycle deletion and exchange, plus explicit pure-cycle sets.
- Theorem 9: global gamma_t <= a+1.

Its only external inequality is the classical Chvatal-McDiarmid 3-uniform bound tau(H)<=(n_H+m_H)/4. The exact statement and multiset convention were verified in the primary paper Henning-Lowenstein, arXiv:1401.4851v1, Section 1:
https://arxiv.org/html/1401.4851v1
(Web reference turn529view0, lines39 and45-49.)

The source archive's original proof-assistant certificate was not rebuilt. The ordinary written proof is sufficient for this audit's mathematical verdict.

## Scope correction

WOWII299 is already a consequence of Gebendorfer: if n2>=1 use gamma_t<=a+1<=a+n2; if n2=0 then connected n>2 implies cutoff>=3, and use gamma_t<=a. Do not count299 as a new closure.

## Output

`independent_results.json` records the independent exact reconstructions. `audit.py` depends only on Python standard library and NetworkX; it imports no supplied mathematical checker.
