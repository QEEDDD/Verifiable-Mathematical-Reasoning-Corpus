# Additional 384b result, 26 October 2026

No complete new numbered conjecture was resolved.

A new structural exclusion at h=33 was proved by adapting the Round22 finite-capacity fixed-active matching sampler. Choose12of16matchingedges, orient each activeedge uniformly, and select the unmatchedvertex with probability2/5. The rational potential certificate gives B=16.179532552 for selected high vertices after repair.

Every h=33 counterexample must:
1. Have exactly two vertices of full degree3, with triangle counts2and3. The latter induces a K4 with its neighbors.
2. Have no pendanttriangle.
3. Have no ordinary lowtriangle whose high-root edge occurs in every maximum matching of H.

Proof cases yield high bounds15.804532552(pendanttriangle),15.958439874(essentialedge),15.942593164(atmostone cubic after promoting a rank-profile3 to4), each below the critical threshold16.

Full written proof: h33_restriction.tex.
Standalone exact verifier: verify_h33_restriction.py.
Output: fixed_active_h33_restriction.json.

Verified36,985feasible patterns,36unordered typepairs, all unmatched double-neighbor placements.333small direct controls comprising17,664sampling outcomes match the generating-function computations. All arithmetic in final verifier is integer/Fraction; SciPy was used only to discover rational potentials, not as a proof dependency. Its implementation adapts the supplied Round22 h35 checker with the new parameters and explicit rational constants.

Exploration scan_fixed.py/log and fixed33_scan.py/log describe unsuccessful direct closure attempts. Even the optimized generic bound minus one lowtriangle credit remains16.0398009>16, so the generic sampling argument alone does not exclude allh33. No claim of a complete h33 exclusion, improved global order37bound, or new closed WOWIIidentifier is made. No worldwide-priority assertion is made for the method or restriction.
