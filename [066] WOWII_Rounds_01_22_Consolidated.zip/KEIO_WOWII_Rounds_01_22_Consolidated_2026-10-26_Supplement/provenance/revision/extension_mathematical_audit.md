# Independent audit of the integrated post-Round-22 extensions

26 October 2026. Scope: mathematical arguments in `tmp/round11/build/new394.tex`, checked against the 148-page consolidated source. This is not a claim of global historical priority or a reproof of the entire 148-page manuscript.

## Verdict

PASS for the arbitrary-internal-graph 394 module theorem, both triangle-free families, bipartite validity, the odd-cycle-transversal deletion bound and its equality cases, disconnected no-isolates 434d, and the diameter bound in terms of complement-degeneracy slack.

The additional strict closed-neighborhood containment refinement of the DeLaVina-Waller construction is also valid. A self-contained version relative to the consolidated paper's already proved rooted growth construction is in `strict_containment.tex`.

## Detail checks

- Arbitrary internal F_i: minimum degree >=2 ensures k_i>=3, internal q-degrees>=3 and root degrees>=3. The domination lower bound does not incorrectly use the externally affected root constraint; every omitted nonroot t forces both its neighbors. If a root is omitted all t are selected and an internal q must be selected. The upper set p+roots+all q meets every requirement. Matching upper and lower certificates are exact. Only p has local independence one.
- C4 module: spokes create no triangles, but an internal edge and two spokes create a five-cycle. The graph is triangle-free, not bipartite. The error r-1 is positive only for r>=2. For the r=1 boundary write 'deficit' rather than 'violation'.
- Seven-vertex rigid module: its degree-two vertices {2,5,6} are independent. For zero/one/two/three selected such vertices the displayed four-case proof forces four selections, even with the root domination requirement omitted. The root-avoiding matching {12,35,46} is valid. Each attached root has degree>=4. All local independence numbers equal degrees by triangle-freeness; p is the unique leaf.
- Odd-cycle transversal: after deleting P union X, a minimum vertex cover of the bipartite residual has size equal to its matching number. Every unselected original vertex has degree>=2 and all neighbors selected. This also handles isolated residual vertices and empty residual graphs. The r disjoint five-cycles force transversal size>=r; the proposed deletions give a matching bipartite upper certificate of exactly r.
- Disconnected 434d: the original complement-core proof only needs a neighbor for each packing vertex, hence no isolates suffice. Different-component distances are infinite, and the disjoint closed balls remain anticomplete. The statement must exclude the empty graph, as the current version does.
- Diameter: h>=0 follows from i<=alpha<=degen(complement)+1. When h=0 the packing bound forces diameter<=3. At h>=1, q(R)=0 gives ecc(v)<=2 and diameter<=4; q(R)>0 gives the base dominating tree diameter<=2q(R)+1, hence graph diameter<=2q(R)+3<=2h+3. Use the base tree T0, not the prescribed-vertex enlargement T, to retain the sharper constant.
- Strict containment: start the first maximal bipartite piece with an induced u-v-x where N[u] properly contained in N[v]. Bipartiteness forces u to be a tree leaf. Delete u and another spanning-tree leaf. Any external vertex that would lose its last neighbor must be adjacent to u and therefore to retained v; this is impossible. The usual later-piece construction then saves two instead of one overall. Singleton later pieces are correctly handled by the retained connector.

## Additional-number search

No new complete original-number resolution was obtained in this audit lane. The zero-slack route for 182/183 still needs to rule out the specified unique vertex outside a closed distance-two ball. Strict containment excludes one more structural possibility, but does not by itself exclude that residual class. A bounded line-graph search, if retained, is discovery screening only.

## Fresh check

`verify_extensions.py` uses only NetworkX for the catalogue and independently computes all invariants by direct subsets, elementary degeneracy peeling, BFS, and exact matching recursion. It checks all no-isolate atlas graphs of orders two through seven, every nonempty closed-neighborhood input set, every deletion set leaving a bipartite residual, and all strict containment pairs in connected graphs. See `extension_checks.json` for counts. Finite checks supplement the written universal proofs.
