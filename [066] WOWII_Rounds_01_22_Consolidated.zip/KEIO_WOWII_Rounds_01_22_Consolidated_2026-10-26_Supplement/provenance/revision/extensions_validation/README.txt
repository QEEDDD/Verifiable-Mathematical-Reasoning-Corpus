Fresh extension-group run, 26 October 2026.
All 10 processes returned zero; all 10 logs and their nonempty check counts were inspected.
See inspection.json for exact counts and scope, outputs/ for newly generated result records,
and the ten extensions__*.log files for complete standard output.
summary.json retains the original temporary execution path as provenance.
The redundant working-copy verification tree was removed after archiving this evidence.
The original 53 historical program runs were preserved, not rerun by this revision.
