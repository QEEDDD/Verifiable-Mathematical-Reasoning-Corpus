KEIO — WoWII Rounds 1–22: Consolidated Paper and Reproducibility Package
26 October 2026

MAIN DELIVERABLE
manuscript/ contains the complete English paper as one standalone TEX and PDF.
The TEX has its bibliography inline and uses no external input or figure files.
Author: KEIO. The PDF has 148 pages in the final verified build.

EXACT MATHEMATICAL SCOPE
Complete source-qualified conclusions: 14 original formulations.
Proofs: 434d, 434e, 298.
Refutations: 394, 392e, 392f, 395a, 382c, 269, 302, 171, 382e, 154, 354.
Item 354 refers only to the archived coefficient-1/2, open-neighborhood form.
The basic Feit construction and other prior contributions are credited.
The count is not a certification of worldwide novelty or curator acceptance.

Further complete proofs establish explicitly limited results for 61, 133,
155, 177, 180, 189, 199, 384b and 389a, plus supporting structural theorems.
133: the original unrounded inequality is proved for mean local independence
     <=5, also radius2/mean<=7 and radius3/mean<=6.
384b: a counterexample, if one exists, has a connected representative of
      order<=37 and 11..33 vertices of degree>=3. No exhaustive census
      through37 or full resolution is claimed.
199: the split-graph reductions do not eliminate all cycles of the factor.
Other full conjectures remain outside the proved scope specified in the paper.

DIRECTORIES
source_archive/ preserves the original proof texts, code, data and audit notes
  extracted from the five supplied bundles. Original PDFs, nested ZIP copies,
  rendered images, build files and executable binaries are omitted to avoid
  redundancy. Binary certificate DATA such as permutation arrays are retained.
  Full original source hashes remain in provenance/source_manifest.json.
verification/ holds the copied/adapted verifier programs, exact companion data,
  and recorded outputs of the consolidation reruns.
provenance/ holds the source manifest, main-paper index, claim audits, assembly
  and final-build records, and page-render audit.
editorial_sources/ records the integrated fragments and editorial scripts.
  These scripts record the original workspace layout; they are provenance,
  not needed to compile the standalone TEX or run verify.py.

VERIFY THE PACKAGE
  python verify.py --validate
  python verify.py --list

RUN THE RECORDED CHECKS
  python verify.py --group root
  python verify.py --group paired_384b
  python verify.py --group early
  python verify.py --group late
  python verify.py
The last command runs all 53 programs. Groups can be repeated in one command.
The driver copies the verification tree into a fresh runs/<UTC timestamp>/
directory, so the original package and its checksums are not overwritten.
Logs and JSON results are retained there. C++ programs are compiled locally.

RUNTIME
The consolidation used Python 3.12.14, NetworkX 3.7 and a C++17 compiler.
Only supplemental early graph checks require NetworkX; the P8/P9 closed
certificate verifiers and the incidence checks use the Python standard library.
Install the optional Python dependency with:
  python -m pip install -r requirements.txt
A g++ compiler supporting -std=c++17 is needed for the C++ checks.
The optional historical builders have their own dependencies and are not run
by verify.py. Canonical labeling is not trusted by the closed-certificate
verifiers, which check every recorded permutation directly.

REBUILD THE PAPER
In manuscript/, run pdflatex on the TEX filename until references stabilize
(normally three passes). A TeX distribution with the standard AMS, Latin
Modern, microtype, hyperref, geometry, xurl, needspace, booktabs, longtable,
enumitem and fancyhdr packages is sufficient. No shell escape is required.

LIMITED ADAPTATIONS
The kappa3 split checker needed an original companion JSON restored from the
Round17 audit snapshot; its code was not changed.
The 298 independent checker omits only final metadata hashes for two prior
PDF/text snapshots absent from the supplied ZIPs. Its mathematical tests were
unchanged. Original/adapted hashes and the failed metadata-only attempt are
described in the audit. The paper gives the required credited antecedent
proof chain explicitly. No Lean rebuild is claimed.

Finite sanity checks and exact finite proof certificates are distinguished
in the paper. The 53 successful program runs are not 53 conjecture solutions.
No post-Round22 conjecture hunt or transfer to unrelated conjectures is included.
