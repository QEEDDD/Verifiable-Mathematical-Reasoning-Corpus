#!/usr/bin/env python3
"""Portable driver for the verification programs accompanying the WoWII paper."""
from pathlib import Path
from datetime import datetime, timezone
import argparse,hashlib,json,shutil,subprocess,sys

ROOT=Path(__file__).resolve().parent

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--list',action='store_true',help='List checks without running them')
    parser.add_argument('--validate',action='store_true',help='Check package SHA-256 manifest only')
    parser.add_argument('--group',action='append',choices=['early','late','paired_384b','root'],
                        help='Run only the selected group(s); repeat to combine groups')
    args=parser.parse_args()
    manifest=json.loads((ROOT/'verification_jobs.json').read_text())
    jobs=[j for j in manifest if not args.group or j['group'] in args.group]
    if args.list:
        for j in jobs: print(j['id'],':',j['source'])
        print(f'{len(jobs)} checks listed. No checker was run.')
        return 0
    if args.validate:
        expected=json.loads((ROOT/'CHECKSUMS.json').read_text())
        errors=[]
        for name,digest in expected.items():
            p=ROOT/name
            if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=digest:
                errors.append(name)
        print(json.dumps({'files_checked':len(expected),'mismatches':errors},indent=2))
        return int(bool(errors))
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
    destination=ROOT/'runs'/stamp
    working=destination/'verification'
    # Checkers can write outputs next to themselves. Work on a fresh copy so
    # the original package and its integrity manifest remain unchanged.
    shutil.copytree(ROOT/'verification',working)
    results=[]
    for job in jobs:
        path=destination/job['source']
        log=destination/(job['id'].replace('/','__')+'.log')
        compile_result=None
        if job['kind']=='cpp':
            executable=path.with_suffix('.repro-exec')
            compile_cmd=['g++','-O3','-std=c++17',path.name,'-o',executable.name]
            compiled=subprocess.run(compile_cmd,cwd=path.parent,stdout=subprocess.PIPE,
                                    stderr=subprocess.STDOUT,text=True)
            compile_result=compiled.returncode
            log.with_suffix('.compile.log').write_text(compiled.stdout)
            if compiled.returncode:
                item={'id':job['id'],'compile_returncode':compiled.returncode,'returncode':None}
                results.append(item);print(json.dumps(item),flush=True)
                continue
            command=[str(executable),*job.get('args',[])]
        else:
            command=[sys.executable,path.name,*job.get('args',[])]
        completed=subprocess.run(command,cwd=path.parent,stdout=subprocess.PIPE,
                                 stderr=subprocess.STDOUT,text=True)
        log.write_text(completed.stdout)
        item={'id':job['id'],'returncode':completed.returncode,
              'compile_returncode':compile_result,'log':log.name}
        results.append(item)
        (destination/'results.json').write_text(json.dumps(results,indent=2)+'\n')
        print(json.dumps(item),flush=True)
    passed=sum(x.get('returncode')==0 for x in results)
    report={'programs':len(jobs),'passed':passed,'results_directory':str(destination),
            'results':results}
    (destination/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='results'},indent=2))
    return int(passed!=len(jobs))

if __name__=='__main__':raise SystemExit(main())
