# Revision supplement preparation

Package root:
`tmp/round12/package/KEIO_WOWII_Rounds_01_22_Consolidated_2026-10-26_Supplement`

Result: **PASS — all 10 fresh extension programs returned zero, and all 10 logs plus their output records were inspected for actual checks and passing assertions.** The package now lists 63 jobs: the original 53, preserved without being represented as new runs, and 10 extension jobs.

| Extension program | Fresh checks |
|---|---|
| Support graphs | 248 instances, maximum order 30 |
| Support trees | 280 general instances and 5 branching instances |
| Restricted 165, cubic case | 134 graphs, including 27 atlas graphs |
| Restricted 165, higher-degree cases | 127 graphs; its sibling import also repeats the cubic 134 |
| Split 199, gap two | 100,504 column multisets; 29,178 qualifying/certified; 761 independent DP checks; 500 random accepted; 72 terminal cases; 9 boundary paths |
| Split 199, gap three | 130 independent DP checks and 7 original-premise boundary paths |
| Fixed-h=33 restriction | 36,985 patterns; 333 controls; 17,664 direct sampling outcomes; all three exact rational margins positive |
| Qualified 389a lower-rank reading | All 2,048 subsets; gamma2=6, lower-rank RHS=5, upper-rank RHS=9 |
| Structural extensions | 1,043 no-isolate atlas graphs, including 48 disconnected; 121,297 closed-neighborhood checks, 995 diameter checks, 85,094 bipartizing-deletion checks, 4,419 strict-containment pairs |
| New 394 modules | Orders 15 and 19; all 32,768 and 524,288 domination masks, plus 128 local-module masks |

The higher-degree 165 import overlap is explicitly disclosed. Finite checks are not represented as proofs of universal statements, and these extensions do not increase the existing 14 complete source-qualified formulation count. The 389a example remains qualified by the lower-rank quartile interpretation.

## Preservation

All 1,586 original files under `source_archive/`, `verification/` and historical `provenance/` remained byte-identical. All 53 original job records remained exactly equal. Original README, driver, and job manifest were copied to `provenance/revision/original_package_metadata/`. Every added source/data file matched its recorded source SHA-256 after the run.

## New records

- `provenance/revision/extensions_manifest.json`: jobs, original-to-package source mapping, hashes and dependency/import notes.
- `provenance/revision/extensions_validation/inspection.json`: exact check counts and independent output inspection.
- `provenance/revision/extensions_validation/`: ten complete fresh logs, process results and summary.
- `provenance/revision/extensions_validation/outputs/`: freshly generated JSON results.
- `provenance/revision/historical_files_preserved.json`: byte-preservation baseline.
- `provenance/revision/298_primary_audit.md`: copied primary retrieval and full proof-chain audit, including the primary URL and SHA-256.
- Additional extension, split-199 input and fixed-384b audits are alongside these files.

The fresh run was `20261026T125200.388585Z`. Its redundant working copy of the verification tree was removed after the logs and newly generated result records were archived. This does not remove any historical records.

## Finalization still owned by parent

The final manuscript was not changed. No final PDF or TeX was copied, no CHECKSUMS manifest was regenerated, and no final ZIP was created. Install the final compiled PDF/TeX first, then generate the complete checksum manifest and ZIP.

Workspace scripts documenting this work are `tmp/round12/crosscheck/update_supplement.py` and `tmp/round12/crosscheck/audit_packaged_runs.py`. They are packaging/audit provenance, not required by the portable verification driver.
