# Independent mathematical review of the proposed counterexample to WOWII 394

The reviewing process rebuilt the fifteen-vertex graph from its textual definition, rather than importing the researcher's graph constructor. The standard-library checker independently enumerates all 32768 vertex subsets for 2-domination, all subsets of each open neighborhood for local independence, and computes maximum matching by exact deletion recursion.

Results: connected order 15 and size 20; gamma_2 = 9; matching number = 7; the minimum-local-independence vertex set is precisely the pendant vertex; the degree-two vertices form an independent set. Hence the original proposed upper bound is 8 and is false.

## Review of the general construction

Let H be any connected graph with r vertices and k >= 3. At every vertex c_i attach a fresh k-clique Q_i, and k independent vertices t_ij, with edges c_i t_ij and t_ij q_ij only. Add one pendant vertex p at c_1. Core edges are exactly those of H.

Each module requires at least k+1 members of a 2-dominating set: if c_i is selected, each pair {t_ij,q_ij} contributes at least one; if c_i is absent, all t_ij must be selected, and at least one q_ij must also be selected. The pendant vertex is forced. Selecting all centers, all Q_i, and p attains the lower bound. Thus gamma_2 = r(k+1)+1.

Any matching has at most k edges internal to each odd-order module; all other edges form a matching of H with its added pendant vertex. Conversely the k edges t_ij q_ij in every module leave all centers free to realize such a core matching. Thus mu = rk + mu(H+p).

All q vertices have local independence 2, as do all t vertices. Every center has at least k independent t neighbors. Only p has local independence 1. The only degree-two vertices are the t vertices, and there are no edges among them. Thus the deficit in the asserted inequality is r - mu(H+p). For a star H centered at c_1, H+p is also a star, so its matching number is 1 and the deficit equals r-1.

No domain restriction of the original connected n>2 statement is violated. No assertion of smallest possible counterexample is made. The finite check supports but does not substitute for the proof. This is a second internal derivation/check, not peer review or formal proof verification. Priority must be assessed separately from mathematical correctness.
