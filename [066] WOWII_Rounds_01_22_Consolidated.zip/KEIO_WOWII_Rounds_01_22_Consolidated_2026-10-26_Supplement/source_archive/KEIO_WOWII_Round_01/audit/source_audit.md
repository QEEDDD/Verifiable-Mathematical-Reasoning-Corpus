# Round 01: source and prior-status audit

Audit date: **2026-10-26 UTC**. This is a bounded public-source audit, not a certification of worldwide novelty or of global unresolved status. The mathematical verification of this round's proposed results is recorded in the other round directories.

## Useful conclusions

- All **30** Appendix-K candidates have exact archived statement HTML, source annotations, definition references, normalized readings, interpretation warnings, and current public-record observations in the retained research inventory; the delivery includes a compact status index.
- The latest accessible **Graffiti verification** commit is still `e4f890b23a62ed8086269e52afee684db86755b3`, committed **2026-10-23 16:39:59 −07:00**. It is the same current revision already cited by the baseline; this audit found no newer upstream update.
- **Formal Conjectures** has advanced to `039378b7951df701428aa5c6732a94a149a077e1`, committed **2026-10-25 21:38:40 UTC**. Its files for **40, 61, 133, 189, 199** still carry `research open`. None of the other 25 candidates has a separate file in its current WOWII directory. Absence is not proof of openness.
- No prior full resolution of **394** or **434d** was located in the sources checked below. That finding supports the limited description **“a resolution of a source-listed-open target; no prior public resolution found in the documented search”**, not “first ever.”
- **178 is excluded**: the preserved original annotation already credits Austin Stubbs with a proof dated **23 July 2026**. Nothing about a stale alternative transcription can restore it as a new target.

## Source integrity

The original site at `https://cms.uhd.edu/faculty/delavinae/research/wowII/all.html` was not available for direct confirmation: browser retrieval timed out; a separate normal HTTP request returned **503 Service Unavailable**. No permission or authentication bypass was attempted.

The preserved original HTML rows were obtained from [the public archive](https://gitlab.com/ai-village-agents/village/graffiti-verification/-/blob/3be380b4222f974bedbefb228c8e75fbd9a7b3ae/data/wow2_rows_html.json). The downloaded latest JSON's Git blob identifier is `2ca7ecb0a02b28eb3c1f4485123e7f1c8878ccc9`, exactly matching the repository tree. The archival introduction commit is dated **1 September 2026**. The rows themselves retain older statement dates and annotations; neither the preservation date nor the `O` label establishes that there has been no later resolution.

`INVARIANT-GLOSSARY.md` is a pinned secondary transcription of the original `wowIIdefs.js` definitions, not a fresh download of that original JavaScript. Its **quoted definitions** are distinguished from editorial computational hints. Several hints are unreliable: in particular, the pair average `dist_avg(B,V)` must not be replaced by average distance to the set, and Maxine must not silently become one tie-broken greedy execution.

`source_manifest.json` records URLs, retrieval date, byte counts and SHA-256 values. The complete third-party downloads are retained as research inputs, not redistributed in this ZIP. URLs and hashes allow source retrieval.

## Focused audit: WOWII 394

The original archived HTML states, for connected graphs of order greater than two,

\[
\gamma_2(G)\leq\mu(G)+|E(G[A_2])|+|M|,
\]

where `A_2` is the set of vertices of degree **exactly two**, and `M` is the set attaining minimum **local independence**, namely `alpha(G[N(v)])`. The row is dated **January 2010** and carries historical status `O`.

There is a real transcription trap: the archive's cleaned `statement_text` changes the uppercase Symbol-font `M` in the cardinality into `mu`. The preserved **HTML** and the immediately following prose identify `M` unambiguously. The matching term preceding it is lowercase Symbol-font `m`, i.e. Greek `mu`.

### Evidence checked

1. Exact original archived row and the separately pinned c5-k4 transcription: no resolution annotation.
2. Current [verification README](https://gitlab.com/ai-village-agents/village/graffiti-verification/-/blob/e4f890b23a62ed8086269e52afee684db86755b3/README.md) and [counting ledger](https://gitlab.com/ai-village-agents/village/graffiti-verification/-/blob/e4f890b23a62ed8086269e52afee684db86755b3/verify/ledger.tsv): no WOWII-394 resolution. Numerical occurrences of 394 in the README concern other corpora, page numbers or counts.
3. Current Formal Conjectures WOWII directory: no GraphConjecture394 file.
4. [The 2010 author manuscript](https://math1um.github.io/Research/r07.pdf), *Graffiti.pc on the 2-domination number of a graph*: its theorem and concluding-conjecture text contains neither an identified resolution of 394 nor this minimum-local-independence-set bound. This does not exclude indirect implications elsewhere in the literature.
5. [The public July-2026 Codex worklog](https://gist.github.com/siddhantdubey/22f22a7a23db5174ee59e32eaa8724aa): no 394 result in the downloaded full text.
6. Exact-number searches using WOWII / Written on the Wall II / Graffiti.pc, formula searches combining 2-domination, minimum local independence and matching, and construction searches involving subdivided K4 / seven-vertex modules did not locate an earlier exact result.

The already public **399c** family has a complete multipartite core, paired degree-two attachments and a pendant. It is not the round's seven-vertex triangle/spoke module construction and was published against a different inequality. It is relevant background, not an established priority collision. No exhaustive graph-isomorphism search of all prior databases was possible or claimed.

GitHub's unscoped numeric-394 issue searches returned unrelated issue-number matches and were **not used as negative evidence**; this failed query is explicitly excluded from the status conclusion.

## Focused audit: WOWII 434d

The archived row, dated **8 December 2010**, states for connected `G` on more than three vertices, with `B` its maximum-eccentricity vertices,

\[
i(G)\leq SW(G^c)-c(G[N[B]])+2.
\]

`N[B]` is the **closed union neighborhood**. The component count is taken in the induced graph on that set. The relevant source convention `SW` is **degeneracy without adding one**. A proof under that convention also implies a variant with coloring number in its place.

### Evidence checked

1. The original row remains historically `O`; there is no full-resolution annotation.
2. The current verification ledger has no 434d resolution. Its README mentions 434d only in positive-control and convention-audit discussions, not as a theorem. Sections 7bo and 7hx distinguish the degeneracy and coloring-number conventions; the neighboring 434c counterexample is a different target.
3. Current Formal Conjectures has no 434d file.
4. [DeLaViña–Pepper–Waller's author PDF](https://www.uhd.edu/documents/academics/sciences/dpw-cn2011.pdf), *Graffiti.pc on the Independent-Domination Number of a Graph*, was inspected through the browser's cached PDF text. It defines degeneracy and presents sibling **434e** as Conjecture 3.2; it contains no identified 434d proof or the round's proposed packing-plus-independent-domination inequality. The direct PDF download returned 403; cached text was accessible normally. The full browser evidence record is `web_dpw2011_web.json`.
5. Searches for exact 434d, independent domination with Szekeres–Wilf/degeneracy of the complement, distance-at-least-four packings, and minimum maximal clique terminology found no matching prior theorem.

Again, the conclusion is limited to **no prior exact resolution located**. This audit does not independently establish the round's proposed theorem and does not certify historical priority.

## Important retained-entry cautions

- **133:** The latest Lean statement is **unrounded**, with real average local independence raised to the C4-free indicator. Older floor readings are stale or alternate interpretations. The original HTML uses brackets, while explicit floor elsewhere is written `FLOOR`; keep this distinction visible.
- **182–186:** `L_s` is maximum spanning-tree leaves, not induced-tree size. The square-graph ambient degrees, distances and neighborhood operators cannot be interchanged. The baseline already handles some readings of 186 but retains others.
- **189:** `sigma` is the second-smallest degree. [Easwar–Johari](https://arxiv.org/abs/2609.11719v1), submitted **10 September 2026**, gives partial cases, not full closure. Its current arXiv version is still v1.
- **269:** The ceiling statement is not implied by the already-proved floor statement 268. The verification README records failed searches and some small-parameter theorems, not a full resolution.
- **298–299:** [Jakovac](https://arxiv.org/abs/2609.10795v2), revised **11 September 2026**, proves the minimum-degree-two bound `gamma_t <= a+1`. It does not settle all degree-one cases, and it is not automatically the stronger 298 bound `gamma_t <= a` when a C4 is present.
- **302:** A public claimed refutation was **retracted on 1 September 2026**. Its error was treating lambda as an eigenvalue rather than local independence. The current ledger says `retracted`.
- **389a:** The current verification record adopts `q=d_floor(n/4)` and records finite checks, not a proof. The row explicitly uses vertices of degree **at most** two; nearby rows use degree **exactly** two.
- **395a:** The Symbol-font `m` inside `G[V-A_delta]` means matching number, not edge count.

## Search limits and allowed language

The original live catalogue was unavailable, scholarly indexing is incomplete, and unindexed/private manuscripts and correspondence were not accessible. Repository absence, old `O` labels, finite tests, and unsuccessful keyword searches do not prove that a conjecture remains globally unsolved. Use the exact source-scoped mathematical claim and the documented priority qualification. Do not increment new-result counts for already-attributed classical consequences, ambiguous readings already treated in the baseline, or finite nonexistence checks.
