import itertools,json
names=[];edges=[]
for j in range(2):
 c=f'c{j}'; qs=[f'q{j}{k}' for k in range(3)]; ts=[f't{j}{k}' for k in range(3)]
 names += [c]+qs+ts
 edges+= list(itertools.combinations(qs,2))
 edges+= [(c,t) for t in ts]+list(zip(qs,ts))
names+=['p']; edges += [('c0','c1'),('c0','p')]
n=len(names);adj=[0]*n
for a,b in edges:
 u,v=names.index(a),names.index(b);adj[u]|=1<<v;adj[v]|=1<<u
full=(1<<n)-1
valid=[]
for s in range(1<<n):
 if all((s>>v&1) or (s&adj[v]).bit_count()>=2 for v in range(n)): valid.append(s)
gamma=min(s.bit_count() for s in valid)
li=[]
for u in range(n):
 best=0;s=adj[u]
 while True:
  if all(not(s&adj[v]) for v in range(n) if s>>v&1):best=max(best,s.bit_count())
  if s==0:break
  s=(s-1)&adj[u]
 li.append(best)
A2=[v for v in range(n) if adj[v].bit_count()==2]
M=[v for v in range(n) if li[v]==min(li)]
from functools import lru_cache
@lru_cache(None)
def matching(s):
 if s==0:return 0
 u=(s&-s).bit_length()-1;rest=s^(1<<u);best=matching(rest)
 for v in range(n):
  if (rest&adj[u])>>v&1:best=max(best,1+matching(rest^(1<<v)))
 return best
mu=matching(full);e2=sum(1 for u,v in itertools.combinations(A2,2) if adj[u]>>v&1)
report={'n':n,'edges':edges,'degree':dict(zip(names,[s.bit_count() for s in adj])),'local_independence':dict(zip(names,li)),'M':[names[v] for v in M],'A2':[names[v] for v in A2],'A2_edges':e2,'matching':mu,'gamma2':gamma,'RHS':mu+e2+len(M),'witness':[names[v] for v in range(n) if next(s for s in valid if s.bit_count()==gamma)>>v&1],'checked_subsets':1<<n}
assert gamma==9 and mu==7 and e2==0 and len(M)==1
print(json.dumps(report,indent=2))
