import networkx as nx, itertools,random,json
rng=random.Random(434)
counts={'atlas':0,'trees':0,'random':0};largest_c=0

def check(G,kind):
 global largest_c
 G=nx.convert_node_labels_to_integers(G);n=len(G);H=nx.complement(G)
 i=min(map(len,nx.find_cliques(H)))
 d=max(nx.core_number(H).values())
 dist=dict(nx.all_pairs_shortest_path_length(G))
 P=nx.Graph();P.add_nodes_from(G);P.add_edges_from((u,v) for u,v in itertools.combinations(G,2) if dist[u][v]>=4)
 S=max(nx.find_cliques(P),key=len);c=len(S);largest_c=max(largest_c,c)
 assert i+c-2<=d,(kind,n,i,c,d)
 for z in range(3):
  T=[rng.choice(list(G[s])) for s in S]
  U={x for x in G if any(all(x==T[a] or not G.has_edge(x,T[a]) for a in range(c) if a!=j) for j in range(c))}
  assert set(S)<=U
  assert min(dict(H.subgraph(U).degree()).values())>=i+c-2,(kind,n,S,T,i,c,d,U)
 B={v for v in G if max(dist[v].values())==nx.diameter(G)}
 NB=B|set().union(*(set(G[v]) for v in B))
 components=nx.number_connected_components(G.subgraph(NB))
 assert i<=d-components+2
 counts[kind]+=1
for G in nx.graph_atlas_g():
 if len(G)>=2 and nx.is_connected(G):check(G,'atlas')
for n in range(8,13):
 for G in nx.nonisomorphic_trees(n):check(G,'trees')
for z in range(300):
 n=rng.randrange(8,15);G=nx.gnp_random_graph(n,rng.uniform(.08,.85),seed=rng.randrange(2**32))
 if nx.is_connected(G):check(G,'random')
print(json.dumps({'status':'PASS','counts':counts,'largest_packing':largest_c,'neighbor_selections_per_graph':3,'seed':434,'networkx':nx.__version__},indent=2))
