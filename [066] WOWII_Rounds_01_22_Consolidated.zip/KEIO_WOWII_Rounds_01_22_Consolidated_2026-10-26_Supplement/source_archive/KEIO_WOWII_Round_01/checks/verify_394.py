#!/usr/bin/env python3
"""Standard-library exact verifier for a WOWII 394 counterexample family.
Run: python verify_394.py --output certificate_394.json
Full subset enumeration is performed on the order-15 witness; larger family
instances are checked by explicit certificates and local obstruction enumeration.
"""
import argparse
from functools import lru_cache
import hashlib
import json
from pathlib import Path


def build(r=2, k=3, core="clique"):
    assert r >= 2 and k >= 3
    names = [f'c{i+1}' for i in range(r)]
    names += [f'q{i+1}_{j+1}' for i in range(r) for j in range(k)]
    names += [f't{i+1}_{j+1}' for i in range(r) for j in range(k)]
    names += ['p']
    index = {name:i for i,name in enumerate(names)}
    edge_names = []
    def edge(u,v): edge_names.append((u,v))
    for i in range(r):
        for j in range(i+1,r):
            if core == 'clique' or (core == 'star' and i == 0) or (core == 'path' and j == i+1):
                edge(f'c{i+1}',f'c{j+1}')
        for j in range(k):
            edge(f'c{i+1}',f't{i+1}_{j+1}')
            edge(f't{i+1}_{j+1}',f'q{i+1}_{j+1}')
            for h in range(j+1,k): edge(f'q{i+1}_{j+1}',f'q{i+1}_{h+1}')
    edge('p','c1')
    adj = [0] * len(names)
    edges = []
    for u,v in edge_names:
        a,b = sorted((index[u],index[v]))
        assert not (adj[a] >> b & 1)
        adj[a] |= 1 << b
        adj[b] |= 1 << a
        edges.append((a,b))
    return names, adj, sorted(edges)


def connected(adj):
    reached = 1
    old = 0
    while old != reached:
        old = reached
        for v in range(len(adj)):
            if reached >> v & 1: reached |= adj[v]
    return reached == (1 << len(adj))-1


def dominates2(adj,D):
    return all(D >> v & 1 or (adj[v] & D).bit_count() >= 2 for v in range(len(adj)))


def exact_gamma2(adj):
    best = len(adj)+1
    witness = None
    valid = 0
    for D in range(1 << len(adj)):
        if dominates2(adj,D):
            valid += 1
            if D.bit_count() < best:
                best,witness=D.bit_count(),D
    return best,witness,valid


def exact_matching(adj):
    @lru_cache(None)
    def solve(S):
        if not S: return 0
        b=S & -S;v=b.bit_length()-1;rest=S ^ b
        ans=solve(rest)
        cand=adj[v] & rest
        while cand:
            x=cand & -cand;cand ^= x
            ans=max(ans,1+solve(rest ^ x))
        return ans
    return solve((1 << len(adj))-1)


def exact_alpha(adj,S):
    @lru_cache(None)
    def solve(R):
        if not R:return 0
        b=R & -R;v=b.bit_length()-1
        return max(solve(R ^ b),1+solve((R ^ b) & ~adj[v]))
    return solve(S)


def named_matching(r,k,core):
    result=[(f't{i+1}_{j+1}',f'q{i+1}_{j+1}') for i in range(r) for j in range(k)]
    result.append(('p','c1'))
    if core != 'star':
        for i in range(2,r,2): result.append((f'c{i}',f'c{i+1}'))
    return result


def check_certificates(r,k,full=False,core="clique"):
    names,adj,edges=build(r,k,core);n=len(names);index={x:i for i,x in enumerate(names)}
    assert connected(adj)
    Dnames=['p']+[f'c{i+1}' for i in range(r)]+[f'q{i+1}_{j+1}' for i in range(r) for j in range(k)]
    D=sum(1 << index[x] for x in Dnames)
    assert dominates2(adj,D)
    assert len(Dnames)==r*(k+1)+1
    pairs=named_matching(r,k,core)
    used=set()
    for x,y in pairs:
        u,v=index[x],index[y]
        assert adj[u] >> v & 1
        assert u not in used and v not in used
        used.update([u,v])
    core_mu=1 if core=='star' else (r+1)//2
    assert len(pairs)==r*k+core_mu
    degree2=[i for i,a in enumerate(adj) if a.bit_count()==2]
    degree2mask=sum(1 << i for i in degree2)
    assert all(adj[v] & degree2mask==0 for v in degree2)
    local_alpha=[exact_alpha(adj,a) for a in adj]
    min_set=[names[v] for v,a in enumerate(local_alpha) if a==min(local_alpha)]
    assert min_set==['p']
    rhs=len(pairs)+1
    deficit=len(Dnames)-rhs
    assert deficit==r-core_mu and deficit>0
    ans=dict(r=r,k=k,core=core,n=n,m=len(edges),gamma2_by_proof=len(Dnames),matching_number=len(pairs),
             degree_two_edge_count=0,min_local_independence=1,min_local_independence_vertices=min_set,
             rhs394=rhs,violation=deficit,dominating_set=Dnames,matching=pairs)
    if full:
        gamma,witness,valid=exact_gamma2(adj)
        assert gamma==len(Dnames)
        assert exact_matching(adj)==len(pairs)
        ans.update(gamma2_exhaustive=gamma,subsets_checked=1 << n,valid_2dominating_sets=valid,
                   exhaustive_witness=[names[v] for v in range(n) if witness >> v & 1],
                   vertex_order=names,edges=edges,degree_sequence=[x.bit_count() for x in adj],
                   local_independences=local_alpha)
    return ans


def check_module_obstruction(k):
    # Outside edges are allowed only at c. Check all subsets and only require
    # vertices q_j,t_j to be 2-dominated. This is weaker than global domination,
    # hence an exact lower bound obtained here remains valid in every host graph.
    n=1+2*k;adj=[0]*n
    def edge(u,v):adj[u] |= 1<<v;adj[v] |= 1<<u
    for j in range(k):
        edge(0,1+k+j);edge(1+j,1+k+j)
        for h in range(j+1,k):edge(1+j,1+h)
    best=n
    for D in range(1<<n):
        if all(D>>v&1 or (D&adj[v]).bit_count()>=2 for v in range(1,n)):
            best=min(best,D.bit_count())
    assert best==k+1
    return dict(k=k,minimum=best,subsets_checked=1<<n)


def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path);args=p.parse_args()
    report={'result':'PASS','claim':'WOWII394 is false',
            'smallest_in_this_family':check_certificates(2,3,True),
            'family_certificate_checks':[check_certificates(r,k,core=core) for core in ['star','clique','path'] for r in range(2,9) for k in range(3,8)],
            'module_exhaustion':[check_module_obstruction(k) for k in range(3,8)],
            'scope':'Exhaustion certifies the order-15 witness; the written proof, not finite tests, establishes the unbounded family.'}
    out=json.dumps(report,indent=2)+'\n'
    if args.output:args.output.write_text(out)
    print(out)

if __name__=='__main__':main()
