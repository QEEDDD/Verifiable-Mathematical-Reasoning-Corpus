// Exact checks for the distance-four packing theorem and WOWII 434d.
// No third-party libraries. Build: g++ -O3 -std=c++17 verify_434d.cpp -o verify_434d
// Run: ./verify_434d 7
// Graph order 7 means every labelled graph, not merely a random sample.
#include <algorithm>
#include <cassert>
#include <chrono>
#include <cstdlib>
#include <iostream>
#include <vector>
using namespace std;
using Mask = unsigned;
int pc(Mask x) { return __builtin_popcount(x); }
int first(Mask x) { assert(x); return __builtin_ctz(x); }
struct Counts { long long graphs=0, packings=0, witnesses=0, tight=0, tight_original=0; };

bool connected(const vector<Mask>& a, Mask s) {
  if (!s) return false;
  Mask seen=s&-s, todo=seen;
  while(todo) {
    int v=first(todo); todo&=todo-1;
    Mask more=a[v]&s&~seen; seen|=more; todo|=more;
  }
  return seen==s;
}
int components(const vector<Mask>& a, Mask s) {
  int c=0;
  while(s) {
    Mask seen=s&-s,todo=seen;
    while(todo) {int v=first(todo);todo&=todo-1;Mask more=a[v]&s&~seen;seen|=more;todo|=more;}
    s&=~seen;++c;
  }
  return c;
}
int independent_domination(const vector<Mask>& a) {
  int n=a.size(), best=n; Mask all=(1u<<n)-1;
  vector<bool> ind(1u<<n); vector<Mask> dom(1u<<n);ind[0]=true;
  for(Mask s=1;s<=all;++s) {
    int v=first(s);Mask rest=s&(s-1);
    ind[s]=ind[rest] && !(a[v]&rest);
    dom[s]=dom[rest]|a[v]|(1u<<v);
    if(ind[s] && dom[s]==all) best=min(best,pc(s));
  }
  return best;
}
int degeneracy(const vector<Mask>& a) {
  Mask left=(1u<<a.size())-1;int result=0;
  while(left) {
    int v=-1,m=1000;
    for(Mask z=left;z;z&=z-1) {int x=first(z),d=pc(a[x]&left);if(d<m){v=x;m=d;}}
    result=max(result,m);left&=~(1u<<v);
  }
  return result;
}
vector<vector<int>> distances(const vector<Mask>& a) {
  int n=a.size();vector<vector<int>> d(n,vector<int>(n,1000));
  for(int s=0;s<n;++s) {
    vector<int> q(1,s);d[s][s]=0;
    for(size_t h=0;h<q.size();++h) {
      int v=q[h];
      for(Mask z=a[v];z;z&=z-1) {int w=first(z);if(d[s][w]==1000){d[s][w]=d[s][v]+1;q.push_back(w);}}
    }
  }
  return d;
}
void check_witness(const vector<Mask>& a,const vector<Mask>& h,Mask S,const vector<int>& t,int k,Counts& count) {
  const int n=a.size(),c=pc(S);Mask T=0;for(int x:t)T|=1u<<x;
  assert(pc(T)==c && !(S&T));
  vector<int> ss;for(Mask z=S;z;z&=z-1)ss.push_back(first(z));
  Mask U=0;
  for(int x=0;x<n;++x)for(int j=0;j<c;++j) {
    Mask base=T&~(1u<<t[j]);
    if(!(base&~(h[x]|(1u<<x)))) U|=1u<<x;
  }
  assert((S&U)==S);
  int minimum=n;
  for(Mask z=U;z;z&=z-1) {
    int x=first(z),j=-1;
    for(int l=0;l<c;++l)if((a[ss[l]]|(1u<<ss[l]))&(1u<<x)){assert(j==-1);j=l;}
    if(j==-1)for(int l=0;l<c;++l)if(!((T&~(1u<<t[l]))&~(h[x]|(1u<<x)))){j=l;break;}
    assert(j>=0);
    Mask Q=(T&~(1u<<t[j]))|(1u<<x);
    for(int y=0;y<n;++y)if(!(Q&(1u<<y)) && !(Q&~h[y]))Q|=1u<<y;
    assert(pc(Q)>=k && !(Q&~U));
    for(int y=0;y<n;++y)if(!(Q&(1u<<y))) assert(Q&~h[y]); // Q maximal.
    Mask extra=S&~(1u<<ss[j]);
    assert(!(Q&extra) && !(extra&~h[x]));
    int degree=pc(h[x]&U);assert(degree>=pc(Q)-1+c-1);minimum=min(minimum,degree);
  }
  assert(minimum>=k+c-2);++count.witnesses;
}
void neighbor_choices(const vector<Mask>& a,const vector<Mask>& h,Mask S,const vector<int>& ss,int j,vector<int>& t,int k,Counts& count) {
  if(j==(int)ss.size()){check_witness(a,h,S,t,k,count);return;}
  for(Mask z=a[ss[j]];z;z&=z-1){t.push_back(first(z));neighbor_choices(a,h,S,ss,j+1,t,k,count);t.pop_back();}
}
void check(const vector<Mask>& a,Counts& count,bool all_neighbors=true) {
  int n=a.size();Mask all=(1u<<n)-1;if(!connected(a,all))return;
  ++count.graphs;vector<Mask> h(n);for(int v=0;v<n;++v)h[v]=all&~a[v]&~(1u<<v);
  int k=independent_domination(a),d=degeneracy(h);auto ds=distances(a);
  vector<Mask> far(n);vector<int> ecc(n);
  int diameter=0;
  for(int v=0;v<n;++v)for(int w=0;w<n;++w){if(ds[v][w]>=4)far[v]|=1u<<w;ecc[v]=max(ecc[v],ds[v][w]);diameter=max(diameter,ds[v][w]);}
  vector<bool> pack(1u<<n);pack[0]=true;int p4=1;
  for(Mask S=1;S<=all;++S) {
    int v=first(S);Mask rest=S&(S-1);pack[S]=pack[rest] && !(rest&~far[v]);
    if(!pack[S])continue;int c=pc(S);p4=max(p4,c);assert(k+c-2<=d);
    if(c<2)continue;++count.packings;
    vector<int> ss,t;for(Mask z=S;z;z&=z-1)ss.push_back(first(z));
    if(all_neighbors)neighbor_choices(a,h,S,ss,0,t,k,count);
    else{for(int s:ss)t.push_back(first(a[s]));check_witness(a,h,S,t,k,count);}
  }
  if(k+p4-2==d)++count.tight;
  Mask NB=0;for(int v=0;v<n;++v)if(ecc[v]==diameter)NB|=a[v]|(1u<<v);
  int c=components(a,NB);assert(k<=d-c+2);if(k==d-c+2)++count.tight_original;
}
int main(int argc,char**argv) {
  int maxn=argc>1?atoi(argv[1]):6;assert(2<=maxn && maxn<=7);
  auto start=chrono::steady_clock::now();Counts total;
  cout<<"{\n  \"result\": \"PASS\",\n  \"range\": \"all labelled connected graphs\",\n  \"orders\": [\n";
  for(int n=2;n<=maxn;++n) {
    vector<pair<int,int>> es;for(int u=0;u<n;++u)for(int v=u+1;v<n;++v)es.emplace_back(u,v);
    Counts ct;
    for(unsigned long long code=0;code<(1ull<<es.size());++code) {
      vector<Mask> a(n);
      for(size_t e=0;e<es.size();++e)if(code>>e&1){auto[u,v]=es[e];a[u]|=1u<<v;a[v]|=1u<<u;}
      check(a,ct);
    }
    cout<<"    {\"n\": "<<n<<", \"graphs\": "<<ct.graphs<<", \"packings_size_at_least_2\": "<<ct.packings<<", \"core_witnesses_all_neighbor_choices\": "<<ct.witnesses<<", \"tight_packing_bound\": "<<ct.tight<<", \"tight_434d\": "<<ct.tight_original<<"}"<<(n<maxn?",":"")<<"\n";
    total.graphs+=ct.graphs;total.packings+=ct.packings;total.witnesses+=ct.witnesses;
  }
  cout<<"  ],\n  \"total_graphs\": "<<total.graphs<<",\n  \"total_core_witnesses\": "<<total.witnesses<<",\n  \"seconds\": "<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"\n}\n";
}
