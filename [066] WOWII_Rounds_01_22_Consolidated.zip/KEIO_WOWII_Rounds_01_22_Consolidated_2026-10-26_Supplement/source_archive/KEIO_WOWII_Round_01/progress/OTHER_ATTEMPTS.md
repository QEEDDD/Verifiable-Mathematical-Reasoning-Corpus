# Other investigations in round 01

No additional complete numbered resolution is claimed.

- Total domination 269, 298, 299, 302: exact source and existing literature were reviewed. Searches of 100000 specially generated C4-free equality-case graphs for269 and 2000000 sparse/block candidates for298/299 found no counterexample; these are finite experiments, not proofs. The C4-containing minimum-degree-two case of298 is not automatically covered by the known annihilation bound.
- Spanning-tree leaves154,155,165,171,177,180,182,183,184,185,186: equality structure explored with exact atlas tests. A proposed overly broad structural implication was contradicted at eight vertices; zero slack itself remains unresolved.
- Induced-subgraph40,61,133 and Hamiltonian189,199: prior work checked; a seeded search of25000 path-blowup instances for61 found no counterexample. Unrounded133 must not be confused with older floor formulations. No current full closure claimed.
- 434e is distinct from434d and remains unresolved.

These explorations guide the next round; they are not additions to the full-resolution count.
