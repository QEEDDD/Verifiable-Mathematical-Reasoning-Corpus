# Round 02 source/status audit: WOWII 392e and 392f

Checked 2026-10-26 UTC. **The original formulas agree with the formulas refuted by the Round 02 witnesses. No prior full resolution was located in the public sources and bounded searches described below. This is not a certification of worldwide priority or of universal absence of earlier work.** The mathematical proof and independent verification are separate from this source audit.

## 1. Exact statements and notation

Both original rows assume a connected graph with more than two vertices, are dated January 2010, and carry the historical label `O`.

* **392e:** `gamma_2(G) <= mu(G) + mu(G[N(A_2)]) + |A_delta|`, where `A_delta` is the set of minimum-degree vertices and `A_2` is the set of vertices of degree exactly two.
* **392f:** `gamma_2(G) <= mu(G) + mu(G[N(A_2)]) + |{v : |N(v) intersect N(A)| = 1}|`, where `A` is the set of minimum-degree vertices and `A_2` again means degree exactly two.

Here `gamma_2` is ordinary 2-domination: only vertices outside the selected set must have at least two selected neighbors. Both occurrences of `mu` are matching numbers. `N(S)` is the union of the open neighborhoods of the vertices of `S`, not a distance-two layer. It may in general intersect `S`. `G[T]` is the induced subgraph. The raw HTML uses a Symbol-font intersection character in 392f; an empty subscript after `N(A)` is formatting residue, not a complement, bar, or additional subscript. Neither row contains an overline. Each row links definitions 90, 100, 2, 46, and 66.

The original notes that the minimum-degree-at-least-three case follows from 392a. That note is not a proof of either statement when leaves or degree-two vertices occur.

Exact archived HTML, cleaned text, definitions, source URLs, and status fields are retained in [`statements_392ef.json`](statements_392ef.json). The source is the [archived original catalogue rows](https://gitlab.com/ai-village-agents/village/graffiti-verification/-/blob/3be380b4222f974bedbefb228c8e75fbd9a7b3ae/data/wow2_rows_html.json), introduced into that repository on 2026-09-01. The [pinned invariant glossary](https://github.com/Kuberwastaken/c5-k4/blob/2455820ef9b925c0746cfb72561bca61105b1aa2/data/INVARIANT-GLOSSARY.md) transcribes the original definition links; its computational hints are not substituted for the definitions. Direct access to the original UHD catalogue failed during the Round 01 retrieval; this audit therefore does not call its historical `O` labels freshly verified live statuses.

## 2. Current public status checks

* The public [graffiti-verification README](https://gitlab.com/ai-village-agents/village/graffiti-verification/-/blob/e4f890b23a62ed8086269e52afee684db86755b3/README.md) and [verification ledger](https://gitlab.com/ai-village-agents/village/graffiti-verification/-/blob/e4f890b23a62ed8086269e52afee684db86755b3/verify/ledger.tsv) were checked at commit `e4f890b23a62ed8086269e52afee684db86755b3`, committed 2026-10-23T16:39:59-07:00. A Round 02 API refresh confirmed this remained the latest commit. No WOWII 392e/f resolution entry was found. Occurrences of `A.392` are unrelated AutoGraphiX statements; a bare `392e` substring in a SHA256 is not evidence about conjecture 392e.
* The [Formal Conjectures repository](https://github.com/google-deepmind/formal-conjectures/tree/039378b7951df701428aa5c6732a94a149a077e1/FormalConjectures/WrittenOnTheWallII) was checked at `039378b7951df701428aa5c6732a94a149a077e1`, dated 2026-10-25T21:38:40Z. Neither target has an individual file in that snapshot. File absence does not prove openness.
* The [2010 author-hosted 2-domination paper](https://math1um.github.io/Research/r07.pdf) and [July 2026 public worklog](https://gist.github.com/siddhantdubey/22f22a7a23db5174ee59e32eaa8724aa) contain no numbered resolution of 392e/f. The worklog does refute different neighboring statements, which must not be conflated with these targets.
* The supplied 155-page baseline establishes restricted sufficient conditions for these two rows, not a full proof. The new claimed disproofs are not being credited as pre-existing public resolutions.

Refresh responses and SHA256 hashes of consulted local evidence are included beside this report. Bulky third-party sources are referenced and hashed rather than duplicated in the Round 02 package.

## 3. Prior-resolution search and closest leads

The search batches in [`search_log.json`](search_log.json) covered exact WOWII/Graffiti.pc identifiers, the matching/degree-two-neighborhood formulation, and the structural description of the nine-vertex module: one edge of `K_3,3` replaced by a path of length four, rooted at its middle subdivision vertex. No located source gives a full proof, counterexample, or a matching equivalent result for either exact target.

Related results were screened rather than treated as resolutions:

1. The author-uploaded [2012 k-independence paper](https://www.researchgate.net/publication/281573028_Graffitipc_on_the_k-independence_number_of_a_graph) discusses a different neighborhood-matching formula, associated with 441a, not 392e/f.
2. Henning and Rall, [On graphs with disjoint dominating and 2-dominating sets](https://pure.uj.ac.za/en/publications/on-graphs-with-disjoint-dominating-and-2-dominating-sets/), Discussiones Mathematicae Graph Theory 33 (2013), 139–146, DOI 10.7151/dmgt.1652, concerns disjoint domination/2-domination sets. Its exceptional `K_3,3` discussion does not supply either target resolution.
3. Yue, Zhang, Zhu, Klavzar, and Shi, [The annihilation number does not bound the 2-domination number from the above](https://users.fmf.uni-lj.si/klavzar/preprints/gamma.pdf), gives unbounded counterexamples to the different inequality `gamma_2 <= a + 1`. Their family has cycles attached to a common hub with leaves on their remaining cycle vertices, not the subdivided-`K_3,3` modules used here. That result is prior art for a different inequality, not evidence that 392e/f are settled.

Search-engine coverage, numbering variants, unpublished work, and unavailable sources limit any negative search. The supportable language is **“no prior full resolution found in the checked sources as of 2026-10-26”**, not “proved previously unsolved everywhere” or an unconditional novelty claim.

## 4. Compatibility of the proposed witnesses with the source

The final construction uses disjoint nine-vertex modules, joins each root to a new external hub `x`, and adds either `x-p` or `x-s-p`. There are no direct root-root edges. The final certificate reports:

| Target | Modules | Vertices | gamma_2 | mu(G) | mu(G[N(A_2)]) | Target correction | RHS |
|---|---:|---:|---:|---:|---:|---:|---:|
| 392e | 2 | 20 | 11 | 9 | 0 | 1 | 10 |
| 392f | 4 | 39 | 22 | 18 | 1 | 2 | 21 |

In both, the unique minimum-degree vertex is `p`. For 392f, `N(A)={s}` and the correction set is exactly `{x,p}`. The degree-two set is independent, so here the open-union and external-neighborhood conventions happen to coincide. Thus neither proposed violation relies on the usual neighborhood or minimum-degree ambiguities. These numerical values are attributed to `../checks/certificate_392ef.json`; their proof and independent audit belong to the mathematical verification files, not to the literature search.
