import itertools,json
import networkx as nx
base_edges=[(0,1),(0,2),(1,3),(2,4),(3,5),(3,7),(4,6),(4,8),(5,6),(6,7),(7,8),(8,5)]
a=[0]*9
for u,v in base_edges:a[u]|=1<<v;a[v]|=1<<u
local=[]
for mask in range(512):
 if all((mask>>v&1) or (mask&a[v]).bit_count()>=2 for v in range(1,9)):local.append(mask)
assert min(s.bit_count() for s in local)==5
assert all(min(s.bit_count() for s in local if (s&1)==c)==5 for c in [0,1])
def construct(r,tail):
 G=nx.Graph();G.add_nodes_from(range(9*r+1+tail));x=9*r
 for i in range(r):
  G.add_edges_from((9*i+u,9*i+v) for u,v in base_edges);G.add_edge(x,9*i)
 prev=x
 for j in range(tail):G.add_edge(prev,x+1+j);prev=x+1+j
 return G
out=[]
for r,tail in [(2,1),(4,2),(3,1),(5,2),(8,1),(8,2)]:
 G=construct(r,tail);n=len(G);adj=[sum(1<<v for v in G[u]) for u in G]
 D2={v for v in G if G.degree(v)==2};A={v for v in G if G.degree(v)==min(dict(G.degree()).values())}
 N2=set().union(*(set(G[v]) for v in D2));NA=set().union(*(set(G[v]) for v in A));B={v for v in G if len(set(G[v])&NA)==1}
 mu=len(nx.max_weight_matching(G,maxcardinality=True));muN=len(nx.max_weight_matching(G.subgraph(N2),maxcardinality=True))
 # exact boundary-state enumeration from the 512 local subsets, all center choices retained
 best=n+1
 x=9*r
 for ext in range(1<<(tail+1)):
  extset={x+j for j in range(tail+1) if ext>>j&1}
  if any(v not in extset and len(set(G[v])&extset)<2 for v in range(x+1,n)):continue
  for centers in range(1<<r):
   chosen={9*i for i in range(r) if centers>>i&1};cost=len(extset);possible=True
   if x not in extset and len(set(G[x])&(chosen|extset))<2:continue
   for i in range(r):
    options=[s.bit_count() for s in local if (s&1)==int(bool(centers>>i&1)) and ((s&1) or ((s&a[0]).bit_count()+int(x in extset)>=2))]
    if not options:possible=False;break
    cost+=min(options)
   if possible:best=min(best,cost)
 expected=5*r+tail
 assert best==expected and mu==4*r+tail and muN==tail-1
 rhs=mu+muN+(len(A) if tail==1 else len(B))
 assert best>rhs
 out.append({'r':r,'tail':tail,'order':n,'size':G.number_of_edges(),'gamma2_exact_boundary_enumeration':best,'matching':mu,'matching_N2':muN,'min_degree_set':sorted(A),'single_NA_neighbors':sorted(B),'rhs':rhs,'defect':best-rhs,'graph6':nx.to_graph6_bytes(G,header=False).decode().strip()})
print(json.dumps({'status':'PASS','module_subsets_checked':512,'module_minimum_ignoring_center':5,'examples':out},indent=2))
