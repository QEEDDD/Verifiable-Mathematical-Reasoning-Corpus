#!/usr/bin/env python3
"""Standard-library certificates refuting original WOWII392e and392f.
Order20 is exhaustively checked over all2^20 subsets. Order39 is exactly
solved by enumerating all512 local module states and all8 external-core states.
No integer-programming package or floating-point optimizer is used here.
"""
import argparse
from functools import lru_cache
import itertools
import json
from pathlib import Path

MODULE_NAMES=['c','t1','t2','q1','q2','w1','w2','w3','w4']
MODULE_EDGES=[(0,1),(0,2),(1,3),(2,4),(3,5),(3,7),(4,6),(4,8),(5,6),(6,7),(7,8),(8,5)]

def adjacency(n,edges):
    a=[0]*n
    for u,v in edges:
        assert u!=v and not(a[u]>>v&1)
        a[u]|=1<<v;a[v]|=1<<u
    return a

def build(r,tail):
    assert r>=2 and tail in [1,2]
    names=[];edges=[]
    for i in range(r):
        names += [f'{x}_{i+1}' for x in MODULE_NAMES]
        edges += [(u+9*i,v+9*i) for u,v in MODULE_EDGES]
    hub=len(names);names.append('x')
    edges += [(hub,9*i) for i in range(r)]
    previous=hub
    for label in (['p'] if tail==1 else ['s','p']):
        nxt=len(names);names.append(label);edges.append((previous,nxt));previous=nxt
    return names,adjacency(len(names),edges),sorted(tuple(sorted(e)) for e in edges)

def bitvertices(mask):
    while mask:
        b=mask&-mask;mask^=b;yield b.bit_length()-1

def nbd(adj,S):
    result=0
    for v in bitvertices(S):result |= adj[v]
    return result

def is2dom(adj,D):
    return all(D>>v&1 or (D&adj[v]).bit_count()>=2 for v in range(len(adj)))

def exact_gamma_exhaustive(adj):
    best=len(adj)+1;witness=None;count=0
    for D in range(1<<len(adj)):
        if is2dom(adj,D):
            count+=1
            if D.bit_count()<best:best=D.bit_count();witness=D
    return best,witness,count

def exact_matching(adj,subset=None):
    @lru_cache(None)
    def rec(S):
        if not S:return 0
        b=S&-S;v=b.bit_length()-1;rest=S^b
        ans=rec(rest)
        for w in bitvertices(adj[v]&rest):ans=max(ans,1+rec(rest^(1<<w)))
        return ans
    if subset is None:subset=(1<<len(adj))-1
    return rec(subset),rec.cache_info().currsize

def module_states():
    adj=adjacency(9,MODULE_EDGES);table={};valid=[]
    for D in range(1<<9):
        if all(D>>v&1 or (D&adj[v]).bit_count()>=2 for v in range(1,9)):
            c=D&1
            need=0 if c else max(0,2-(D&adj[0]).bit_count())
            key=(c,need);size=D.bit_count()
            table[key]=min(size,table.get(key,100))
            valid.append((c,need,size,D))
    assert min(x[2] for x in valid)==5
    assert all(x[2]>=5 for x in valid)
    return table,valid

def exact_gamma_by_blocks(r,tail):
    # Each module state records whether its center is selected, how many
    # additional selected neighbors that center needs, and its exact cost.
    # All noncenter conditions are already tested exhaustively. The only
    # outside neighbor of a center is x, so remaining conditions are explicit.
    table,_=module_states();best=10**9;best_state=None;count=0
    for core in itertools.product([0,1],repeat=tail+1):
        x=core[0]
        # External tail is x-p or x-s-p.
        if not core[-1]:continue # p has degree1
        if tail==2 and not core[1] and core[0]+core[2]<2:continue
        options=[(c,need,cost) for (c,need),cost in table.items() if need<=x]
        for states in itertools.product(options,repeat=r):
            count+=1
            centers=sum(z[0] for z in states)
            if not x and centers+core[1]<2:continue
            cost=sum(core)+sum(z[2] for z in states)
            if cost<best:best=cost;best_state=(core,states)
    assert best==5*r+tail
    return best,best_state,count

def check(r,tail,exhaust=False):
    names,adj,edges=build(r,tail);n=len(names);idx={x:i for i,x in enumerate(names)}
    reached=1
    while True:
        new=reached|nbd(adj,reached)
        if new==reached:break
        reached=new
    assert reached==(1<<n)-1
    degrees=[a.bit_count() for a in adj]
    A2=sum(1<<v for v,d in enumerate(degrees) if d==2)
    N2=nbd(adj,A2)
    Amin=sum(1<<v for v,d in enumerate(degrees) if d==min(degrees))
    NAmin=nbd(adj,Amin)
    B=sum(1<<v for v,a in enumerate(adj) if (a&NAmin).bit_count()==1)
    gamma,block_state,block_count=exact_gamma_by_blocks(r,tail)
    mu,mu_states=exact_matching(adj)
    muN,muN_states=exact_matching(adj,N2)
    assert mu==4*r+tail
    assert muN==tail-1
    assert Amin==1<<idx['p']
    assert B.bit_count()==(r+1 if tail==1 else 2)
    # Explicit upper witnesses, derived from construction but checked directly.
    Dnames=['p']+(['x'] if tail==2 else [])
    for i in range(1,r+1):Dnames += [f'{v}_{i}' for v in ['c','q1','q2','w1','w3']]
    D=sum(1<<idx[v] for v in Dnames)
    assert len(Dnames)==gamma and is2dom(adj,D)
    matching=[]
    for i in range(r):
        matching += [(9*i+1,9*i+3),(9*i+2,9*i+4),(9*i+5,9*i+6),(9*i+7,9*i+8)]
    if tail==1:matching.append((idx['x'],idx['p']))
    else:matching += [(idx['s'],idx['p']),(idx['x'],idx['c_1'])]
    used=set()
    for u,v in matching:
        assert adj[u]>>v&1 and u not in used and v not in used
        used.update([u,v])
    assert len(matching)==mu
    rhs_e=mu+muN+Amin.bit_count();rhs_f=mu+muN+B.bit_count()
    ans=dict(r=r,tail=tail,n=n,m=len(edges),gamma2=gamma,matching_number=mu,matching_N_degree_two=muN,
             minimum_degree_set=[names[v] for v in bitvertices(Amin)],
             correction_392f=[names[v] for v in bitvertices(B)],rhs392e=rhs_e,rhs392f=rhs_f,
             deficit392e=gamma-rhs_e,deficit392f=gamma-rhs_f,
             exact_block_combinations_checked=block_count,exact_matching_DP_states=mu_states,
             exact_neighbor_matching_DP_states=muN_states,dominating_set=Dnames,
             maximum_matching=[[names[u],names[v]] for u,v in matching],
             degree_two_vertices=[names[v] for v in bitvertices(A2)],
             neighbors_of_degree_two=[names[v] for v in bitvertices(N2)])
    if exhaust:
        brute,Ds,valid=exact_gamma_exhaustive(adj);assert brute==gamma
        ans.update(exhaustive_gamma2=brute,vertex_subsets_checked=1<<n,valid_2dominating_sets=valid)
    if r<=4:
        ans.update(vertex_order=names,edges=edges,degrees=degrees)
    return ans

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path);args=p.parse_args()
    table,valid=module_states()
    report=dict(result='PASS',claim='Original WOWII392e and392f are false',
                module=dict(subsets_checked=512,minimum_noncenter_2domination_cost=5,
                            compressed_table=[dict(center_selected=c,center_extra_neighbors_needed=need,cost=cost)
                                              for (c,need),cost in sorted(table.items())]),
                witness392e=check(2,1,True),witness392f=check(4,2),
                family_checks=[check(r,tail) for tail in [1,2] for r in range(2,9)],
                scope='The20vertex graph is exhaustively checked. The39vertex graph is exactly solved by exhaustive block-state transfer and independent matching DP. Universal families rest on the written proof.')
    assert report['witness392e']['deficit392e']==1
    assert report['witness392f']['deficit392f']==1
    out=json.dumps(report,indent=2)+'\n'
    if args.output:args.output.write_text(out)
    print(out)

if __name__=='__main__':main()
