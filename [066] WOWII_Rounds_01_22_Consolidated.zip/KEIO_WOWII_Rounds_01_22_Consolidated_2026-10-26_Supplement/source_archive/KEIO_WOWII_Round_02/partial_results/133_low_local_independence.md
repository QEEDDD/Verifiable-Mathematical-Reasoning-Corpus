# WOWII 133 for average local independence at most three

**Status: partial theorem, not a full numbered resolution.** The proof invokes
established theorems and is not represented as an independently novel general
result. The exact original, unrounded reading is used throughout.

## Theorem

Every finite connected simple graph G with average local independence

    ell(G) = (1/n) sum_v alpha(G[N(v)]) <= 3

satisfies WOWII 133. In particular, every connected subcubic graph satisfies
it. The C4-present branch is immediate, irrespective of ell, since its exponent
is zero. For the remaining C4-free branch the asserted inequality is

    p(G) >= r(G) + ell(G),

where p is maximum induced-path vertex order and r is radius.

## Two explicitly attributed ingredients

1. Erdős, Saks and Sós (1986), with the radius argument credited to Fan Chung:
   every connected graph has an induced path on at least 2r-1 vertices.
   https://users.renyi.hu/~sos/1986_Maximum_Induced_Trees_in_Graphs.pdf
2. Van 't Hof and Paulusma, *A new characterization of P6-free graphs*, Theorem
   6: every connected P6-free graph has a dominating induced C6 or a dominating
   (not necessarily induced) complete bipartite subgraph.
   Primary author manuscript: https://pimvanthof.github.io/p6free.pdf
   Institutional record:
   https://durham-repository.worktribe.com/output/1517209/a-new-characterization-of-p6-free-graphs

The lemmas below spell out exactly how these established results are used.

## Local independence identity

If G has no C4 as a subgraph, each open neighborhood induces a matching:
two incident neighborhood edges would, with its center, form a C4. Thus
lambda(v)=d(v)-t(v), where t(v) counts triangles through v. If t is the total
number of triangles, then

    n ell(G) = 2m - 3t.                                      (1)

Triangles are edge-disjoint: two distinct triangles sharing an edge already
contain a C4 as a non-induced subgraph.

## Lemma A: connected C4-free P4-free graphs have radius at most one

If G is complete this is immediate. Otherwise choose an induced P3, a-b-c.
For an exterior vertex x with a neighbor on this P3, P4-freeness excludes a
single contact at a or c, while C4-freeness excludes simultaneous contacts at
a and c. The possible nonempty contact sets are therefore {b}, {a,b}, {b,c};
in every case x is adjacent to b.

Suppose a vertex lies outside the closed neighborhood of {a,b,c}. Choose a
shortest path from that vertex to {a,b,c}; let y,x be its last two exterior
vertices, with x contacting the P3 and y not contacting it. As just shown,
x is adjacent to b and to at most one of a,c. Choose z in {a,c} nonadjacent
to x. Then y-x-b-z is an induced P4, a contradiction. Hence every exterior
vertex contacts the P3 and is adjacent to b, making b universal.

In particular, a C4-free graph of radius two contains an induced P4.

## Lemma B: a connected C4-free P5-free graph has ell at most two

Suppose G contains an induced C5. If G has an exterior vertex, connectedness
provides one, x, with a neighbor on that C5. No two neighbors of x on the
cycle can be at cycle-distance two, because that would create a C4. Thus its
cycle neighborhood consists of one vertex or two adjacent vertices. With
one contact, append x to four successive cycle vertices. With adjacent
contacts, start at one contact and traverse away from the other. Either way
there is an induced P5. Consequently G=C5, and ell=2.

If there is no induced C5, every chordless cycle is a triangle: induced cycles
of order at least six contain a P5, and C4 is forbidden. Every cycle can be
split along chords into triangles. Hence the triangle vectors span the cycle
space. Their supports are edge-disjoint, so they are independent and t equals
the cycle-space dimension m-n+1. Equation (1) gives

    n ell = 2(n-1+t)-3t = 2n-2-t < 2n.

This proves the lemma. Equivalently, ell>2 forces an induced P5.

## Lemma C: a connected C4-free P6-free graph of radius three is C6

Apply the van 't Hof–Paulusma theorem. A complete bipartite subgraph in a
C4-free graph must be a star (or a single vertex). If such a subgraph is
dominating, its center has eccentricity at most two. This is incompatible
with radius three.

Thus there is a dominating induced cycle v0,v1,...,v5. Any exterior vertex x
has a neighbor on this cycle. C4-freeness forbids a pair of contacts at cycle
distance two, and consequently permits at most two contacts. A single
contact produces an induced P6 by appending x to five consecutive cycle
vertices. Two adjacent contacts produce the same P6 by traversing away from
the other contact. Since G is P6-free, every exterior vertex therefore has
exactly two opposite contacts.

If an exterior vertex x exists, relabel its contacts as v0,v3. Then every
cycle vertex is at distance at most two from v0, using x to reach v3.
Every other exterior vertex y contacts an opposite pair, and every opposite
pair meets {v5,v0,v1}; hence d(v0,y)<=2. Thus v0 has eccentricity at most two,
again a contradiction. No exterior vertex exists, and G=C6.

## Completion of the partial theorem

We may suppose G is C4-free. The singleton is immediate. If r=1, take a
universal vertex c. Its neighborhood is a disjoint union of edges and single
vertices. Every noncentral vertex has lambda=1, and lambda(c) is the number
of those components. If there is only one component then G is K2 or K3,
and p=2=r+ell. Otherwise p>=3 and ell<2, so the conclusion holds.

Now let r=2. Lemma A gives p>=4. If ell<=2 this suffices. If 2<ell<=3,
Lemma B gives p>=5>=r+ell.

Let r=3. The classical radius bound gives p>=5, which suffices for ell<=2.
If 2<ell<=3 and p<=5, Lemma C forces G=C6, whose ell is 2, a contradiction.
Thus p>=6>=r+ell.

Finally, for r>=4 the classical bound yields

    p >= 2r-1 >= r+3 >= r+ell.

All cases are covered. QED.

## Residual scope, without inflating the closure count

Any counterexample to the original unrounded WOWII 133 must therefore be
C4-free, have ell>3, have maximum degree at least four, and satisfy

    r <= ceil(ell),

since r>=ceil(ell)+1 is already covered by p>=2r-1. The general case is not
settled. The cubic direct-prefix proof is retained separately as a
self-contained verification and a transparent repair of the older rounded
partial proof.
