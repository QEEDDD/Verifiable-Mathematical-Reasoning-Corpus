# WOWII 269: a proposed reduction to radius four

**Status:** coordinator-reviewed partial theorem, prepared 26 October 2026. The independent audit accepted the argument after clarification that the even-path midpoint claim concerns only the central quotient adjacency. This is not a proof of the full conjecture. Novelty and worldwide priority remain uncertified. The unresolved case is explicitly retained below.

## Claim

Let G be a finite simple connected graph of order at least two containing no (not necessarily induced) 4-cycle. Write t = gamma_t(G), r = rad(G), and let C be its center. Then WOWII 269,

`average_{distinct x,y in C} d_G(x,y) <= t-1`,

holds whenever `t=r>=6`. Together with the baseline's previous reductions, **only `t=r=4` remains**.

Distances for a singleton center are assigned average zero. The asserted inequality is equivalent to the ceiling formulation because t is an integer.

## Previously proved input

We use the supplied baseline Proposition 38.1 and its proof, not a new claim of these facts. If `gamma_t(G)=rad(G)=t`, then t=2k is even. Every minimum total dominating set D induces k disjoint edges. Every vertex outside D has neighbors in exactly one such edge. The resulting k parts have a connected simple quotient Q which is a path, a cycle, or one vertex.

For any choice of attachment of each outside vertex to a neighboring member of D, and any choice of interpart edges realizing a spanning tree of Q, the resulting spanning tree T preserves D as a minimum total dominating set. It has diameter `2t-1`. Every diametral path contains all of D, with membership pattern `0,1,1,0` repeated; its middle edge consists of centers of G.

For clarity, the radius lower bound and induced-matching consequence originate in DeLaVina–Liu–Pepper–Waller–West, *Some conjectures of Graffiti.pc on total domination*, Congressus Numerantium 185 (2007), 81–95. The stronger quotient assertion is supplied in the baseline, pp. 80–81.

## 1. Contact orientation at an internal quotient vertex

Consider a part with two distinct neighboring parts. Select one cross edge to each neighbor and a quotient spanning tree containing both selected quotient edges. In the corresponding D-preserving tree, the path through the neighboring parts must pass through both vertices of the present D-edge. Consequently its two attachment vertices attach to different endpoints of that edge.

The choices of the cross edges and of their attachments were arbitrary. It follows that all contacts toward one neighbor have exactly one D-neighbor, the same endpoint a; all contacts toward the other neighbor have exactly one D-neighbor, the other endpoint b. A vertex adjacent to both a and b cannot be a cross-edge endpoint. This applies to every part of a cyclic quotient and every internal part of a path quotient.

## 2. Cyclic quotients with k>=3

Label the D-edges `a_i b_i`, cyclically, so contacts to the preceding part are attached to a_i and contacts to the following part to b_i. Choose one cross edge per quotient adjacency. Together with the D-edges and attachment edges, they form a simple cycle Z of length 4k containing all 2k vertices of D. Distinct incoming and outgoing contact vertices in each part ensure simplicity.

### Centers supplied by the preserving trees

Delete any selected cross edge of Z and attach all remaining vertices to a chosen D-neighbor. This is a D-preserving spanning tree; its central edge on `Z minus the selected cross edge` is a pair of centers of G.

- If k is odd, this central edge is a D-edge. Varying the deleted quotient adjacency shows that **every member of D is a center**.
- If k is even, the central edge is the cross edge opposite the deleted adjacency. Its choice was arbitrary. Hence **every endpoint of every interpart edge is a center**. In particular `|C|>=2k`, using the chosen 4k-cycle.

### Circle-metric bound

For m points on a metric circle of circumference L, allowing repetition,

`sum_{ordered x,y} d_circle(x,y) <= L m^2/4`.

To prove this, parameterize antipodal pairs of cutting points over a half-circle. For a cut let s points lie in one open semicircle and m-s in the other (endpoint coincidences have measure zero). The number of ordered pairs separated by that cut is `2s(m-s)<=m^2/2`. A fixed ordered pair is separated for a set of parameters of length exactly its circular distance. Integrating over a parameter interval of length L/2 proves the bound.

Apply the lemma with L=4k. For each x in C choose a neighboring D-vertex p(x), except set p(x)=x when x is itself in D. Put m=|C| and s=|C intersect D|. By the triangle inequality and the cycle Z,

`sum_{ordered distinct x,y in C} d_G(x,y) <= k m^2 + 2(m-s)(m-1)`.

Therefore

`mean <= k m/(m-1) + 2 - 2s/m`.

For odd k>=3, s=2k and m>=2k, giving

`mean <= k+2 + k/(m-1) - 4k/m <= k+2 <= 2k-1`.

For even k>=4, discard the nonpositive last term and use m>=2k:

`mean <= k+2 + k/(2k-1) <= 2k-1`.

The last inequality holds already at k=4 and strengthens thereafter. This completes the cyclic case. Notably, this part of the argument does not use C4-freeness.

## 3. Path quotients with k>=3

Label the parts 1,...,k. Orient every internal D-edge `a_i b_i` so contacts to part i-1 attach only to a_i and contacts to part i+1 only to b_i.

### Endpoint contacts also have a uniform orientation

Suppose part 1 has contacts at both endpoints of its D-edge. Since part 2 is internal, all its left contacts attach to a_2. Thus a_2 is within distance three of both D-vertices in part 1, and within distance four of every vertex of part 1.

Choose one cross edge along each adjacency from part 2 to part k. The path through these parts has the usual coordinates `a_i=4i-3`, `b_i=4i-2`; its contact vertices have the intermediate integer coordinates. Choose the existing vertex v at coordinate 2k. Since k>=3, a_2 has coordinate 5 and is to the left of v. Every vertex outside part 1 is adjacent to a D-vertex in parts 2,...,k, so along the selected path its distance from v is at most

`max(2k-5+1, (4k-2)-2k+1) = 2k-1`.

Every vertex in part 1 is at distance at most

`d(v,a_2)+4 = (2k-5)+4 = 2k-1`.

This contradicts radius 2k. Hence all endpoint-1 contacts attach to only one endpoint, which we call b_1. No contact may be adjacent to both D-endpoints, by the same argument. Orient the other endpoint so contacts attach only to a_k.

### Global coordinates

Use coordinates `a_i=4i-3`, `b_i=4i-2` (i=1,...,k). Assign a vertex adjacent only to a_i coordinate `4i-4`; one adjacent only to b_i coordinate `4i-1`; and a vertex adjacent to both coordinate `4i-5/2`.

Within one part, an edge between an a-side and a b-side vertex would produce a 4-cycle through a_i b_i. An edge from a common neighbor to a private-side vertex similarly produces a 4-cycle. There can be at most one common neighbor of a_i,b_i. Cross edges join the b-side of part i, at coordinate 4i-1, to the a-side of part i+1, at coordinate 4i. Thus every edge changes coordinate by at most one. The coordinate function is 1-Lipschitz for graph distance.

There must be an a_1-private neighbor z of coordinate 0. Otherwise, construct the preserving tree using one cross edge per adjacency, and attach a possible common neighbor of a_1,b_1 to b_1. The vertex at coordinate 2k has distance at most 2k-1 from every vertex of this tree: a_1 is at distance 2k-1 but has no attached leaf; every other D-vertex and its attached leaves satisfy the same bound. This contradicts radius 2k. Symmetrically a b_k-private neighbor w of coordinate 4k-1 exists.

For any center x, the inequalities `d(x,z)<=2k` and `d(x,w)<=2k`, together with the 1-Lipschitz coordinates, imply

`2k-1 <= coordinate(x) <= 2k`.

If k is odd, this interval contains only the middle D-edge and its possible common neighbor. These vertices form a clique, so the mean center distance is at most one.

If k is even, the interval contains only the outgoing side of part k/2 and the incoming side of part k/2+1. A center on the first side must have a cross edge: its distance to w already equals the coordinate gap 2k, so a path of length at most 2k must increase coordinate by one at every step, starting with a cross edge. The symmetric assertion holds on the other side. Every endpoint of an edge joining parts k/2 and k/2+1 is a center, by the preserving-tree midpoint argument. This statement concerns only the central quotient adjacency, not every cross edge of a path quotient.

Two centers on the same side have distance at most two through their common D-neighbor. For centers x,y on opposite sides, take a cross neighbor z of x. Then `x,z,a_{k/2+1},y` is a walk of length three. Therefore the center has diameter at most three and mean at most three, which is at most `2k-1`.

This proves the path case for k>=3.

## Remaining gap

For k=2, the quotient is a single edge, but cross edges can use several contact orientations between the two D-edges. The endpoint-orientation argument above explicitly requires the second part to be internal and therefore **does not apply**. C8 already exhibits two opposite orientations. The argument does not prove the needed center-average bound in this radius-four case.

No full resolution of 269 is claimed. The intended new outcome is solely reduction of the baseline residual family to `gamma_t=rad=4`.

## Computational corroboration

`check_reduction269.cpp` completed with seed 20261026: 18,199 quotient-path and 56,731 quotient-cycle graphs at t=6,8,10 passed the claimed center properties. An additional 25,070 radius-four graphs were generated but are outside the partial theorem. This construction-based sample is not exhaustive; the proof above does not depend on it. Logs are included.
