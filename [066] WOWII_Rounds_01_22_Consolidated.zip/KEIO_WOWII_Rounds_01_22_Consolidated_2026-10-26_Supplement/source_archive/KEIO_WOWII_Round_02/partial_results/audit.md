# Independent audit of the two Round 02 partial theorems

**Date:** 26 October 2026.  
**Scope:** mathematical validity and exact invoked primary results, not worldwide novelty, priority, or a new numbered closure. No finite test is treated as a proof.

## Disposition

| Item | Status | Exact disposition |
|---|---|---|
| WOWII 133, average local independence at most three | **PROVED** | Accepted on the stated unrounded domain. Detailed audit: `check133.md`. |
| WOWII 269, equality case `gamma_t=rad>=6` | **PROVED, with the wording correction below** | Every substantive step checks; together with the supplied baseline, only equality radius four remains. |
| Unqualified sentence “All cross-edge endpoints are centers” in the path/even-k paragraph | **REJECTED literally** | True only for edges across the central quotient adjacency. Its intended local version is proved below. |
| Full WOWII 269 at equality radius four | **GAP retained** | The argument explicitly does not cover the two-part quotient. No closure is claimed. |
| Full WOWII 133 beyond the partial domain | **GAP retained** | The argument leaves the stated ell>3 residual. No closure is claimed. |

The one rejected literal sentence is a local scope error, not a missing step in the partial theorem. It should be repaired before publication.

## Files audited

* `../domination/reduction269.md`, SHA-256 at initial audit: `67fc1e29bf6683c9b7d955b95f1f4ce27f48f5dae54a6d48fb1e6e0a2771632c`.
* `../induced/low_local_independence_133.md`, SHA-256 at initial audit: `94570747f6d39359bf2469db3653a78c6f1fca2e762c6f0b55d13d88d68a81ec`.
* `../../sources/baseline.txt`, SHA-256: `56aa534de7a985a30ef862a2af4af358054b3a77bbda0d2958c994252dd7fd1f`.

## 1. Accepted wording for WOWII 269

> Let G be a finite simple connected graph of order at least two with no 4-cycle as a subgraph. If `gamma_t(G)=rad(G)>=6`, then the mean distance in G over distinct vertices of its center is at most `gamma_t(G)−1`. Consequently, using the supplied baseline's already proved cases, any remaining counterexample to WOWII 269 must satisfy `gamma_t(G)=rad(G)=4`. This is a partial reduction, not a resolution of the numbered conjecture.

Replace the sentence in the path/even-k paragraph by:

> Every endpoint of an interpart edge joining parts `k/2` and `k/2+1` is a center, by choosing that edge in a preserving tree and applying the midpoint argument. No assertion is made here about cross edges at other quotient adjacencies.

A literal counterexample to the unqualified wording is P16 on vertices 0,...,15. Its radius is eight and `{1,2,5,6,9,10,13,14}` is a minimum total dominating set (the radius lower bound proves minimality). Its quotient is P4. Edge 3–4 is an interpart edge but neither endpoint is a center: the centers are 7 and 8. The corrected sentence applies only to edge 7–8.

## 2. Baseline and preserving-tree input — PROVED

The audit reread baseline Lemma 18.2, Proposition 38.1 and Corollary 38.2, rather than treating the summary as a new independent assumption.

For any permitted attachment choices and quotient spanning tree, the constructed graph T is indeed a spanning tree: the k disjoint connected part trees have n−k edges, and k−1 interpart edges connect them according to a tree. D totally dominates T, and a total dominating set of T also dominates G. Thus `gamma_t(T)=gamma_t(G)=t`.

A diametral path P has at most `2t` vertices: every path vertex is adjacent to D, and each member of D has at most two neighbors on the tree path. Since `rad(G)=t <= rad(T)=ceil(diam(T)/2)` and `diam(T)<=2t−1`, one gets exactly `diam(T)=2t−1`. (Diameter `2t−2` would give tree radius `t−1`, not t.) Equality in the counting forces every member of D to occur internally on P, with exactly two path neighbors, and every vertex of P to have exactly one D-neighbor. The repeated pattern is `0,1,1,0`; hence t is even and `|D|=2k`.

The baseline's induced-matching and unique-part deductions follow from the freedom of attachment and spanning-tree choice. Contracting parts of a preserving tree maps P to a path visiting all quotient vertices, so every quotient spanning tree is a path and the simple quotient has maximum degree two. The middle edge of every diametral P has endpoints of eccentricity t in T. Their eccentricities in G are at most t and therefore exactly t. They are genuine G-centers; this conclusion does not require P to be geodesic in G.

## 3. Internal contact orientation — PROVED

At a quotient vertex with two neighbors, any selected pair of incident quotient edges is a forest and extends to a quotient spanning tree, including when the quotient is a 3-cycle. The diametral path contains both D-vertices from every part and therefore traverses the two selected cross edges. Within the present part its unique tree subpath must traverse the D-edge. Its two contacts consequently are distinct and attached to opposite endpoints of that D-edge.

This reasoning applies for *every* selected cross edge and *every* attachment choice. Fixing one contact on one side forces every contact on the other side to have a unique D-neighbor, and then fixes all contacts on the first side as well. In particular no common neighbor of the D-edge can be a cross-edge endpoint at such an internal quotient vertex. There is no unjustified transition from an existential choice to uniform orientation.

## 4. Cyclic quotient, k>=3 — PROVED

### Selected cycle and center membership

The two oriented contacts in each part are distinct private neighbors, so the chosen D-edges, attachment edges and one edge per quotient adjacency give a simple 4k-cycle Z. Removing one selected cross edge leaves a path with exactly 4k vertices. Attaching the remaining graph vertices to D yields a preserving tree containing that path; its diameter is exactly `4k−1`, so this path is diametral.

Label its vertices 0,...,4k−1. The membership pattern in D gives its middle positions `2k−1,2k`:

* For odd k these form a D-edge. Varying the deleted adjacency makes each D-edge the middle edge; all 2k members of D are centers.
* For even k these form the selected cross edge opposite the deletion. Given any interpart edge, select it and delete the opposite adjacency. Both its endpoints are centers. The k selected cross edges have distinct endpoints, so `|C|>=2k`.

These arguments require no C4 restriction in the cyclic branch.

### Circle-metric average

For m points, including repetitions, on a circle of circumference L, antipodal cuts are parametrized modulo L/2. For each cut, the number of separated ordered pairs is `2s(m−s)<=m²/2`. A fixed ordered pair at circular distance d is separated on a parameter set of length d, including the antipodal case. Integrating gives the bound `sum d <= Lm²/4`. The measure-zero boundary cases do not affect the result.

Project each center to an adjacent D-vertex, with D-centers fixed. All projections are on Z. If `m=|C|` and `s=|C intersect D|`, the triangle inequality and circle bound give

`sum_(x!=y) d_G(x,y) <= k m² + 2(m−s)(m−1)`.

The repeated projections cause no problem; the circle lemma permits repetitions. Diagonal terms vanish. Dividing by `m(m−1)` yields

`mean <= k+2+k/(m−1)−2s/m`.

For odd k, `s=2k`, `m>=2k`, and `k/(m−1)−4k/m<=0`; hence the mean is at most `k+2<=2k−1` for k>=3. For even k>=4, discard the negative s term and use `m>=2k`; then `k+2+k/(2k−1)<=2k−1`, already strictly at k=4. Thus there is no lost finite-size correction in the mean estimate.

## 5. Path quotient, k>=3 — PROVED

### Uniform endpoint orientation

Suppose contacts from part 1 use both endpoints of its D-edge, including the possibility of a common contact adjacent to both. Part 2 is internal, so all its incoming contacts are adjacent to a2. Hence a2 is within three steps of each D-vertex in part 1 and within four of every vertex of that part.

Select one cross edge along each adjacency from part 2 to part k. At the terminal part, temporarily call the chosen incoming contact's D-neighbor a_k, with its D-mate b_k; this labeling is legitimate even before endpoint uniformity is proved. The resulting path contains every D-vertex in parts 2,...,k, with coordinates 5 through `4k−2` and the stated intermediate contacts. It contains a vertex v at coordinate 2k since k>=3.

Every vertex outside part 1 is adjacent to a D-vertex on this path, so its distance to v is at most `2k−1`. The distance to any vertex of part 1 is at most `(2k−5)+4=2k−1`. This contradicts radius 2k. Thus every endpoint-part contact uses one common D-endpoint only, and none is a common D-neighbor. The reflected argument handles part k. This argument genuinely needs k>=3 and does not silently include k=2.

### Coordinate function

The coordinate assignments are exhaustive because the baseline gives exactly one D-edge per outside vertex. The no-C4 assumption excludes private-a / private-b edges, common / private edges, and two common neighbors of a D-edge. Same-private-side edges have coordinate difference zero; D-attachment edges have difference one or one-half; D-edges have difference one. Every cross edge has endpoints at `4i−1` and `4i`. Thus every graph edge changes coordinate by at most one and the coordinate function is 1-Lipschitz for graph distance.

### Extreme private neighbors

If a1 had no private neighbor, take a preserving tree with any selected cross edges and attach a possible common neighbor to b1. Its core path contains every D-vertex at coordinates 1 through `4k−2`. No off-core vertex is attached to a1. For the core vertex v at coordinate 2k, a1 is at distance `2k−1`; every other D-vertex is at distance at most `2k−2`, and every off-core vertex is an attached leaf. Hence every vertex is within `2k−1` of v in T and also in G, a contradiction. Therefore a private neighbor z of a1 exists at coordinate 0. Reflection gives a private neighbor w of b_k at coordinate `4k−1`.

The source does not assume these extreme neighbors in order to prove their existence.

### Center interval and odd k

A center x is within 2k of both z and w. The Lipschitz property forces `2k−1 <= f(x) <= 2k`. For odd k, only the middle D-edge and its possible unique common neighbor have coordinates in this interval. They form a clique, giving center mean at most one.

### Center interval and even k

For even k, the interval consists exactly of the outgoing private side in part k/2 and incoming private side in part k/2+1. A center on the first side has coordinate gap 2k from w. A shortest path of length at most 2k therefore has every coordinate increment exactly one; its first step must be a cross edge to the second side. The reflected argument applies to a center on the second side.

For completeness, the **corrected** center assertion follows as well. Select any edge across this central adjacency in a preserving tree. The extreme vertices z,w and selected contacts form a path of length `4k−1`, which is diametral. Its middle edge is the selected central cross edge, so both endpoints are centers. This does not put endpoints of other cross edges in the center.

Any two same-side centers share a D-neighbor and are at distance at most two. For opposite-side centers x,y, a cross neighbor u of x exists; u and y share the incoming D-neighbor of the next part, giving a walk of length three from x to y. Thus the entire center has diameter at most three, and its mean is at most three, certainly at most `2k−1`.

## 6. WOWII 133 — PROVED on its partial domain

The complete independent audit is saved separately in `check133.md`. In particular, the delicate Lemma C is valid: the [van 't Hof–Paulusma author manuscript](https://pimvanthof.github.io/p6free.pdf), Theorem 6, has precisely the unqualified P6-free hypothesis used; the subsequent C4-free contact argument correctly forces an exterior vertex of a dominating C6 to contact an opposite pair and thereby forces radius at most two. The [Erdős–Saks–Sós primary paper](https://users.renyi.hu/~sos/1986_Maximum_Induced_Trees_in_Graphs.pdf) confirms the induced-path vertex-order radius bound and the Fan Chung proof attribution. Neither a rounding substitution nor an induced-only C4 interpretation is used.

## Final accounting

The audited outcome is **two partial-domain results, not two new numbered closures**. After the local central-cross-edge wording repair, neither partial proof has an unfilled mathematical gap identified by this audit. Equality radius four for 269 and the stated ell>3 residual for 133 remain unproved here. This audit establishes no novelty or priority claim.
