# Independent mathematical audit: WOWII 133 partial theorem

**Audit date:** 26 October 2026.  
**Status: PROVED on the stated domain.** This is not a full resolution of WOWII 133 and does not establish novelty or priority.

Audited source: `../induced/low_local_independence_133.md`, SHA-256 `94570747f6d39359bf2469db3653a78c6f1fca2e762c6f0b55d13d88d68a81ec`.

## Exact accepted statement

Every finite simple connected graph whose average open-neighborhood independence number is at most three satisfies the original unrounded WOWII 133. In the branch with no C4 as a **subgraph**, the established inequality is `p(G) >= rad(G) + ell(G)`, where p counts vertices of a longest induced path. Every subcubic graph is included. In the C4-present branch the required inequality is simply `p >= rad+1`, valid by a shortest path to a farthest vertex.

## Primary-source verification

The author manuscript of [van 't Hof and Paulusma, A new characterization of P6-free graphs](https://pimvanthof.github.io/p6free.pdf), printed page 3, Theorem 6, was independently opened on 26 October 2026. It asserts the dominating-induced-C6 / dominating-complete-bipartite alternative for every connected induced subgraph of a P6-free graph. The complete bipartite subgraph need not be induced, and **no triangle-free hypothesis is imposed**. The paper's standing nontriviality convention is harmless when radius is three.

The primary [Erdős–Saks–Sós paper, Maximum Induced Trees in Graphs](https://users.renyi.hu/~sos/1986_Maximum_Induced_Trees_in_Graphs.pdf), printed pages 62 and 64–65, independently confirms the bound `p >= 2 rad−1`; the proof in Section II credits Fan Chung. Here p is induced-path **vertex order**, not edge length.

## Step-by-step findings

1. **Local identity — PROVED.** If a neighborhood contained two incident edges, those edges together with their neighborhood center would form a non-induced C4. Thus the neighborhood is a disjoint union of singletons and edges, giving `lambda(v)=d(v)−t(v)`. Summing counts every triangle three times, so `n ell = 2m−3t`. Two triangles sharing an edge likewise create a C4; their edge supports are disjoint.
2. **Lemma A — PROVED.** For an induced `a-b-c`, an exterior vertex contacting the path has contact set `{b}`, `{a,b}`, or `{b,c}`. Single endpoint contact creates P4; simultaneous endpoint contacts create C4. If a vertex does not contact the path, the last two exterior vertices on a shortest connecting path give the displayed induced P4. Consequently b is universal. Connectedness supplies an induced P3 whenever the graph is not complete.
3. **Lemma B, induced C5 branch — PROVED.** A contacting exterior vertex can have only one cycle neighbor or two adjacent cycle neighbors: every other pair is at cycle-distance two and creates C4. In either permitted case, that vertex followed by four cycle vertices avoiding the other contact gives an induced P5. Connectedness therefore forces the entire graph to be C5.
4. **Lemma B, no induced C5 branch — PROVED.** A chordless cycle of length at least six contains P5; a chordless 4-cycle is forbidden. Recursive splitting at chords expresses every cycle vector over F2 as a sum of triangle vectors. The edge-disjoint triangle vectors are independent, giving `t=m−n+1`. The claimed identity becomes `n ell=2n−2−t<2n`.
5. **Lemma C, bipartite alternative — PROVED.** A complete bipartite subgraph without C4 is a star. If dominating, its center reaches every graph vertex in at most two steps, contradicting radius three.
6. **Lemma C, cycle alternative — PROVED.** A dominating C6 means every exterior vertex has a nonempty cycle contact set. The forbidden distance-two pairs form two disjoint triangles on the six cycle vertices, so such a contact set has size at most two. One contact or adjacent contacts gives an induced P6 by taking five cycle vertices and omitting the unwanted second contact. Hence every exterior vertex must contact an opposite pair. If one x contacts v0 and v3, all cycle vertices are within two steps of v0 (use x for v3); every opposite pair meets `{v5,v0,v1}`, so every other exterior vertex is also within two steps of v0. Thus no exterior vertex can exist at radius three, and the graph is C6.
7. **Completion — PROVED.** K1 is harmless. At radius one, the universal vertex's neighborhood matching gives all other local independence numbers one and `ell<2`; the single-component cases K2 and K3 have p=2 and ell=1, and the remaining cases have p>=3. For radius two, Lemmas A/B give p>=4 or p>=5 as required. For radius three, the classical bound gives p>=5; if ell>2 and p<=5, Lemma C gives C6, contradicting ell>2. For radius at least four, `2r−1 >= r+3 >= r+ell`.
8. **Residual wording — PROVED.** A counterexample must have no C4 subgraph, ell>3, maximum degree at least four, and `r <= ceil(ell)`. The last assertion follows because `r >= ceil(ell)+1` makes the classical radius bound sufficient.

## Gaps / rejected claims

No gap or rejected mathematical claim was found in this partial theorem. The proof must retain the stronger meaning “C4 absent as a subgraph”; replacing it by merely induced-C4-free would invalidate several local arguments. The general case ell>3 remains open here. No finite verification was substituted for these arguments.
