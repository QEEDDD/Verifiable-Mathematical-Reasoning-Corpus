#!/usr/bin/env python3
"""Independent finite guard checks for the partial WOWII 133 theorem.
Standard library only; checked graph edge lists are included beside this file.
This computation does not replace the mathematical proof.
"""
import json, itertools, collections, time
from pathlib import Path

def adjacency(n,edges):
 a=[0]*n
 for u,v in edges:
  assert u!=v and not(a[u]>>v&1)
  a[u]|=1<<v;a[v]|=1<<u
 return a

def bits(s):
 while s:
  b=s&-s;yield b.bit_length()-1;s-=b

def distances(a,s):
 d=[-1]*len(a);d[s]=0;q=collections.deque([s])
 while q:
  u=q.popleft()
  for v in bits(a[u]):
   if d[v]<0:d[v]=d[u]+1;q.append(v)
 return d

def independent_number(a,S):
 if not S:return 0
 v=(S&-S).bit_length()-1;R=S&~(1<<v)
 return max(independent_number(a,R),1+independent_number(a,R&~a[v]))

def path_at_least(a,k):
 if k<=1:return [0]
 def dfs(path,used,forbidden):
  if len(path)>=k:return path
  last=path[-1]
  candidates=a[last]&~used&~forbidden
  for v in bits(candidates):
   z=dfs(path+[v],used|(1<<v),forbidden|a[last])
   if z:return z
  return None
 for v in range(len(a)):
  z=dfs([v],1<<v,0)
  if z:return z
 return None

def run():
 data=json.loads(Path(__file__).with_name('guard_graphs.json').read_text())
 counts=collections.Counter();start=time.monotonic();witness=[]
 for row in data:
  a=adjacency(row['n'],row['edges']);n=len(a)
  assert all(x>=0 for x in distances(a,0))
  if any((a[u]&a[v]).bit_count()>1 for u in range(n) for v in range(u)):
   counts['C4_present_controls']+=1;continue
  counts['C4_free']+=1
  rad=min(max(distances(a,v)) for v in range(n))
  S=sum(independent_number(a,a[v]) for v in range(n))
  triangles=sum((a[u]&a[v]).bit_count() for u in range(n) for v in bits(a[u]))//6
  m=sum(x.bit_count() for x in a)//2
  assert S==2*m-3*triangles
  p4=path_at_least(a,4);p5=path_at_least(a,5);p6=path_at_least(a,6)
  if not p4:
   counts['lemma_A_instances']+=1;assert rad<=1
  if not p5:
   counts['lemma_B_instances']+=1;assert S<=2*n
  if not p6 and rad==3:
   counts['lemma_C_instances']+=1;assert n==6 and all(x.bit_count()==2 for x in a)
  if S<=3*n:
   target=rad+(S+n-1)//n
   p=path_at_least(a,target)
   assert p,(row,rad,S,target)
   # Verify the returned certificate by a different direct pair test.
   assert len(set(p))==len(p)
   assert all(bool(a[p[i]]>>p[j]&1)==(j==i+1) for i in range(len(p)) for j in range(i+1,len(p)))
   counts['partial_theorem_instances']+=1
  else:counts['outside_partial_theorem_scope']+=1
 counts['input_graphs']=len(data)
 result={'status':'PASS','counts':dict(counts),'seconds':round(time.monotonic()-start,3),
         'scope':'finite proof guards only; no full conjecture resolution or exhaustive large-order claim'}
 Path(__file__).with_name('guard_results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':run()
