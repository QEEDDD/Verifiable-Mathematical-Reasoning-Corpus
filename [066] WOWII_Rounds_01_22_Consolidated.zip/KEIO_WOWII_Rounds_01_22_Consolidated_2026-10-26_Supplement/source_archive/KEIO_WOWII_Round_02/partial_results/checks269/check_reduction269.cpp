#include <bits/stdc++.h>
using namespace std; mt19937 rng(20261026);
struct G{int n;vector<vector<int>> a; G(int n):n(n),a(n,vector<int>(n)){} void e(int u,int v){a[u][v]=a[v][u]=1;} vector<vector<int>> dist(){auto d=a;for(int i=0;i<n;i++)for(int j=0;j<n;j++)d[i][j]=i==j?0:a[i][j]?1:999;for(int k=0;k<n;k++)for(int i=0;i<n;i++)for(int j=0;j<n;j++)d[i][j]=min(d[i][j],d[i][k]+d[k][j]);return d;} bool c4(){for(int i=0;i<n;i++)for(int j=0;j<i;j++){int c=0;for(int k=0;k<n;k++) c+=a[i][k]&&a[j][k];if(c>1)return true;}return false;} int rad(){auto d=dist();int r=n;for(auto &v:d)r=min(r,*max_element(v.begin(),v.end()));return r;}};
int main(){int counts[20]={}; double maxavg[20]={}; int paths=0,cycles=0;for(int it=0;it<100000;it++){int t=4+2*(rng()%4),n=2*t+rng()%15;G g(n);vector<int>D;for(int i=0;i<2*t-1;i++)g.e(i,i+1);for(int i=0;i<2*t;i++)if(i%4==1||i%4==2)D.push_back(i);if(rng()%2)g.e(0,2*t-1);for(int i=2*t;i<n;i++)g.e(i,D[rng()%D.size()]);if(g.rad()!=t)continue;for(int s=0;s<70;s++){int x=rng()%n,y=rng()%n;if(x==y||g.a[x][y])continue;g.e(x,y);if(g.c4()||g.rad()!=t)g.a[x][y]=g.a[y][x]=0;}if(g.c4())continue;auto d=g.dist();vector<int>C;for(int i=0;i<n;i++)if(*max_element(d[i].begin(),d[i].end())==t)C.push_back(i);if(t>=6){
 int k=t/2; vector<int> part(n,-1); for(int j=0;j<k;j++)part[D[2*j]]=part[D[2*j+1]]=j;
 for(int x=0;x<n;x++)if(part[x]<0)for(int z:D)if(g.a[x][z]){if(part[x]>=0&&part[x]!=part[z]){cerr<<"MULTIPART ATTACHMENT"<<endl;return 3;}part[x]=part[z];}
 vector<vector<int>>q(k,vector<int>(k));for(int x=0;x<n;x++)for(int y=0;y<x;y++)if(g.a[x][y]&&part[x]!=part[y])q[part[x]][part[y]]=q[part[y]][part[x]]=1;
 int qe=0;for(auto &r:q)for(int x:r)qe+=x;qe/=2;
 if(qe==k){cycles++; if(k%2){for(int z:D)if(find(C.begin(),C.end(),z)==C.end()){cerr<<"D NOT CENTRAL"<<endl;return 4;}}else for(int x=0;x<n;x++)for(int y=0;y<x;y++)if(g.a[x][y]&&part[x]!=part[y])if(find(C.begin(),C.end(),x)==C.end()||find(C.begin(),C.end(),y)==C.end()){cerr<<"CROSS NOT CENTRAL"<<endl;return 5;}}
 else if(qe==k-1){paths++;for(int x:C)for(int y:C)if(d[x][y]>(k%2?1:3)){cerr<<"PATH CENTER DIAMETER FAILURE "<<t<<endl;return 6;}}
 else {cerr<<"QUOTIENT TYPE FAILURE"<<endl;return 7;}
}
int sum=0;for(int x:C)for(int y:C)sum+=d[x][y];double av=C.size()>1?(double)sum/C.size()/(C.size()-1):0;counts[t]++;if(av>maxavg[t]){maxavg[t]=av;cerr<<"t "<<t<<" n "<<n<<" centers "<<C.size()<<" avg "<<av<<endl;}if(av>t-1+1e-6){cout<<"COUNTEREXAMPLE "<<t<<" "<<n<<endl;for(int i=0;i<n;i++)for(int j=0;j<i;j++)if(g.a[i][j])cout<<i<<" "<<j<<endl;return 1;}}
cout<<"Checked quotient path graphs "<<paths<<", cycle graphs "<<cycles<<endl;for(int t=4;t<=10;t+=2)cout<<t<<" "<<counts[t]<<" "<<maxavg[t]<<endl;
}
