# Round 03 source/status audit: WOWII 395a

Checked 2026-10-26 UTC. **The proposed formula is the original statement, and original definition 45 explicitly resolves mode ties by taking the smallest mode. No prior full resolution was located in the checked sources.** This last conclusion is a bounded search result, not a worldwide priority certificate.

## Original statement

For connected `G` with `n > 2`, the January 2010 row asserts

`gamma_2(G) <= |M| + mu(G[V - A_delta]) + mu(G[N(A_2)])`,

where `M` is the set of vertices of `mode_min` degree, `A_delta` is the set of minimum-degree vertices, and `A_2` is the set of vertices of degree exactly two. Its archived status is `O`, a historical label rather than a fresh certification of openness. The [archived original row](https://gitlab.com/ai-village-agents/village/graffiti-verification/-/blob/3be380b4222f974bedbefb228c8e75fbd9a7b3ae/data/wow2_rows_html.json) is preserved with raw HTML in `statement_395a.json`.

**Both matching symbols are Greek mu.** The original HTML encloses each ASCII `m` in a `font face="Symbol"` tag. A cleaned transcription leaves the first as an ordinary `m`, but that loss of font information does not turn it into edge count. Original definition 2 identifies the Symbol-font character with the maximum number of pairwise vertex-disjoint edges.

## Original definition file recovered

The original [wowIIdefs.js archived on 2024-05-12 at 13:36:36](https://web.archive.org/web/20240512133636id_/http://cms.uhd.edu/faculty/delavinae/research/wowII/wowIIdefs.js) was retrieved successfully, HTTP 200, 64,913 bytes. The initial replay request for 2024-07-26 redirected to that May snapshot; the actual snapshot is reported here. The full original JavaScript is retained as a research input; this ZIP includes selected definitions, source URL, hashes and retrieval status, not the complete third-party document.

* **Definition 45:** a mode is a degree of maximum frequency; if several degree values tie, `mode_min` is their smallest value and `mode_max` their largest.
* **Definition 2:** `mu` is matching number, not edge count.
* **Definition 90:** a selected set is 2-dominating when every vertex outside it has at least two neighbors inside it; no condition is imposed on a selected vertex.
* **Definition 46:** `N(S)` consists of vertices adjacent to some vertex of `S`. This is a union of open neighborhoods and can in general intersect `S`.
* **Definitions 66 and 100:** set difference and induced subgraph, respectively.

The row's linked definition IDs are 90, 45, 100, 11, and 66. Definition 2 is the global glossary entry fixing the matching glyph, even though it is not one of this row's five linked IDs. Selected verbatim original JavaScript entries are also included in `statement_395a.json`. The successfully recovered primary definition file independently supports the previously consulted [pinned glossary transcription](https://github.com/Kuberwastaken/c5-k4/blob/2455820ef9b925c0746cfb72561bca61105b1aa2/data/INVARIANT-GLOSSARY.md).

## Current public-status and priority checks

Round 03 refreshed the latest public verification commit and obtained `e4f890b23a62ed8086269e52afee684db86755b3`, committed 2026-10-23T16:39:59-07:00. Its [README](https://gitlab.com/ai-village-agents/village/graffiti-verification/-/blob/e4f890b23a62ed8086269e52afee684db86755b3/README.md) and [ledger](https://gitlab.com/ai-village-agents/village/graffiti-verification/-/blob/e4f890b23a62ed8086269e52afee684db86755b3/verify/ledger.tsv) contain no 395a resolution entry. The README does resolve other mode-based conjectures, including 340 and 396; those are different inequalities and are not resolutions of 395a.

The latest [Formal Conjectures snapshot](https://github.com/google-deepmind/formal-conjectures/tree/039378b7951df701428aa5c6732a94a149a077e1/FormalConjectures/WrittenOnTheWallII) remained `039378b7951df701428aa5c6732a94a149a077e1`, dated 2026-10-25T21:38:40Z. No individual 395a file is present. File absence does not prove openness. The [2010 author-hosted 2-domination paper](https://math1um.github.io/Research/r07.pdf), [July 2026 public worklog](https://gist.github.com/siddhantdubey/22f22a7a23db5174ee59e32eaa8724aa), and supplied baseline were checked: no prior full resolution of 395a was identified; the baseline has restricted sufficient conditions.

Exact-number, naming-variant, degree-mode, and matching-formula search batches are logged in `search_log.json`. Searches frequently returned irrelevant uses of “mode,” “domination,” or the number 395; those were not treated as evidence. The Round 02 search of the same subdivided-K3,3 module and adjacent 2-domination literature also found no equivalent prior counterexample. The known annihilation-number disproof uses a different inequality and construction, as documented in `../../round_02/source_audit/AUDIT_392EF.md`.

Supportable priority wording: **“No prior full resolution found in the checked sources as of 2026-10-26.”** The unsuccessful live UHD retrieval and limitations of search indexing remain reasons not to claim an exhaustive worldwide history.

## Witness/source compatibility

For the proposed external-hub construction with `r` nine-vertex modules and `L >= 7r` pendant vertices, the degree frequencies are `L` at degree 1, `2r` at degree 2, `7r` at degree 3, and one at degree `L+r` (in the counterexample range `r >= 2`). Thus original definition 45 gives `mode_min = 1`; `M` and `A_delta` are exactly the pendant set. At `L > 7r`, degree 1 is the unique mode.

The reported witnesses are source-compatible:

| r | L | Order | Mode interpretation | gamma_2 | Original RHS |
|---:|---:|---:|---|---:|---:|
| 2 | 14 | 33 | tie between 1 and 3; choose 1 | 24 | 23 |
| 2 | 15 | 34 | unique mode 1 | 25 | 24 |

The 34-vertex version is a useful tie-independent presentation. The mathematical claims `gamma_2 = 5r+L`, `mu(G[V-A_delta]) = 4r+1`, and `mu(G[N(A_2)]) = 0` are proved and checked in `../twodomination/verify_395a.py` and `../twodomination/certificate_395a.json`, not established by the literature audit itself.
