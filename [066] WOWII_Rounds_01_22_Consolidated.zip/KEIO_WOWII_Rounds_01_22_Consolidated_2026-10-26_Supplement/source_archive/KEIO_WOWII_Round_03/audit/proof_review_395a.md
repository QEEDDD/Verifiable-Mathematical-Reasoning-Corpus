# Independent mathematical audit of WOWII 395a

The nine-vertex rooted module is the same explicit graph analyzed in Round 02. Its nonroot vertices force at least five selected vertices in any 2-dominating set, regardless of the external neighbors of the root. This fact was independently verified on all 512 module subsets and proved by the two-part four-cycle argument. The proof is also reproduced in this round's manuscript, so the article does not depend on access to the previous article.

For r>=2 modules and an external hub x with L>=7r pendant neighbors, every pendant is forced. The lower bound is therefore 5r+L, attained by the explicit five-set in every module and all pendants. Omitted x has at least two selected pendant neighbors. This is an exact optimum, not just the cost of one feasible solution.

The degree histogram is precisely 1:L, 2:2r, 3:7r, (L+r):1. The four degrees are distinct. Thus the minimum degree set is the pendant set, and the smallest modal degree is1 when L>=7r. For L>7r the modal degree is unique. The conjecture uses only the cardinality of the modal class, so even a different tied-mode choice would have the same cardinality at L=7r.

Deleting the pendant vertices leaves r odd modules and an external hub adjacent only to their roots. Internal matching contributes at most4r, external matching at most1; both bounds are jointly attained by root-avoiding internal perfect matchings plus xc1. Thus the exact remaining matching number is4r+1. The degree-two vertices are exactly the module t vertices; their open-neighborhood union consists of roots and q vertices with no induced edges. Its matching number is0.

Consequently the source RHS is L+4r+1 and the true optimum is L+5r, giving defect r-1. All connectedness, order and exact-degree restrictions are met. The original archived definitions confirm matching numbers (not edge counts) and the mode convention. No domain reinterpretation is needed.

A separately written Python/NetworkX checker reconstructed the graph, enumerated local and external boundary states exactly, and independently computed degree classes and both matching terms. The tied33-vertex witness gives24>23; the unique-mode34-vertex witness gives25>24. Seven family instances passed. The standard-library supplied verifier was also rerun successfully. These are internal checks, not formal proof verification or external peer review, and imply no minimal-order or priority claim.
