import json,itertools,collections
import networkx as nx
E=[(0,1),(0,2),(1,3),(2,4),(3,5),(3,7),(4,6),(4,8),(5,6),(6,7),(7,8),(8,5)]
a=[0]*9
for u,v in E:a[u]|=1<<v;a[v]|=1<<u
local=[s for s in range(512) if all((s>>v&1) or (s&a[v]).bit_count()>=2 for v in range(1,9))]
assert min(s.bit_count() for s in local)==5
out=[]
for r,L in [(2,14),(2,15),(3,21),(3,22),(5,35),(5,36),(8,56)]:
 G=nx.Graph();G.add_nodes_from(range(9*r+1+L));x=9*r
 for i in range(r):G.add_edges_from((u+9*i,v+9*i) for u,v in E);G.add_edge(x,9*i)
 G.add_edges_from((x,j) for j in range(x+1,len(G)))
 degrees=dict(G.degree());freq=collections.Counter(degrees.values());mode=min(d for d,c in freq.items() if c==max(freq.values()))
 A={v for v,d in degrees.items() if d==min(degrees.values())};M={v for v,d in degrees.items() if d==mode};A2={v for v,d in degrees.items() if d==2};N2=set().union(*(set(G[v]) for v in A2))
 mu_res=len(nx.max_weight_matching(G.subgraph(set(G)-A),maxcardinality=True));muN=len(nx.max_weight_matching(G.subgraph(N2),maxcardinality=True))
 best=len(G)+1
 for hub_selected in [0,1]:
  for centermask in range(1<<r):
   cost=L+hub_selected
   # x is dominated by all L forced leaves if omitted
   for i in range(r):
    options=[s.bit_count() for s in local if bool(s&1)==bool(centermask>>i&1) and ((s&1) or (s&a[0]).bit_count()+hub_selected>=2)]
    cost+=min(options)
   best=min(best,cost)
 rhs=len(M)+mu_res+muN
 assert mode==1 and len(A)==L and M==A and best==5*r+L and mu_res==4*r+1 and muN==0 and best-rhs==r-1
 out.append({'r':r,'L':L,'n':len(G),'m':G.number_of_edges(),'gamma2_exact_boundary':best,'degree_frequencies':dict(freq),'mode_min':mode,'M_size':len(M),'matching_after_min_degree_deletion':mu_res,'matching_NA2':muN,'RHS':rhs,'defect':best-rhs})
print(json.dumps({'status':'PASS','local_states_exhausted':512,'examples':out},indent=2))
