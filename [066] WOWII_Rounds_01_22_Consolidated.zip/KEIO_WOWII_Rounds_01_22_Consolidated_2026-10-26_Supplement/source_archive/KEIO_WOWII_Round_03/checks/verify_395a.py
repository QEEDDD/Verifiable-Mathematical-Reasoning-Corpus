#!/usr/bin/env python3
"""Exact standard-library certificate for WOWII395a.
No optimizer and no network connection required. The module lower bound is
verified over all512 local subsets; the full graph is solved by exact boundary
state transfer. Matching is independently optimized by integer subset DP.
"""
import argparse
from functools import lru_cache
import itertools,json
from collections import Counter
from pathlib import Path

MODULE_NAMES=['c','t1','t2','q1','q2','w1','w2','w3','w4']
MODULE_EDGES=[(0,1),(0,2),(1,3),(2,4),(3,5),(3,7),(4,6),(4,8),(5,6),(6,7),(7,8),(8,5)]

def adjacency(n,edges):
    a=[0]*n
    for u,v in edges:
        assert u!=v and not(a[u]>>v&1)
        a[u]|=1<<v;a[v]|=1<<u
    return a

def build(r,leaves):
    assert r>=2 and leaves>=7*r
    names=[];edges=[]
    for i in range(r):
        names += [f'{v}_{i+1}' for v in MODULE_NAMES]
        edges += [(u+9*i,v+9*i) for u,v in MODULE_EDGES]
    hub=len(names);names.append('x')
    edges += [(hub,9*i) for i in range(r)]
    for j in range(leaves):
        v=len(names);names.append(f'p{j+1}');edges.append((hub,v))
    return names,adjacency(len(names),edges),edges

def bitvertices(mask):
    while mask:
        b=mask&-mask;mask^=b;yield b.bit_length()-1

def nbd(adj,S):
    result=0
    for v in bitvertices(S):result |= adj[v]
    return result

def is2dom(adj,D):
    return all(D>>v&1 or (D&adj[v]).bit_count()>=2 for v in range(len(adj)))

def exact_gamma_exhaustive(adj):
    best=len(adj)+1;witness=None;count=0
    for D in range(1<<len(adj)):
        if is2dom(adj,D):
            count+=1
            if D.bit_count()<best:best=D.bit_count();witness=D
    return best,witness,count

def exact_matching(adj,subset=None):
    @lru_cache(None)
    def rec(S):
        if not S:return 0
        b=S&-S;v=b.bit_length()-1;rest=S^b
        ans=rec(rest)
        for w in bitvertices(adj[v]&rest):ans=max(ans,1+rec(rest^(1<<w)))
        return ans
    if subset is None:subset=(1<<len(adj))-1
    return rec(subset),rec.cache_info().currsize

def module_states():
    adj=adjacency(9,MODULE_EDGES);table={};valid=[]
    for D in range(1<<9):
        if all(D>>v&1 or (D&adj[v]).bit_count()>=2 for v in range(1,9)):
            c=D&1
            need=0 if c else max(0,2-(D&adj[0]).bit_count())
            key=(c,need);size=D.bit_count()
            table[key]=min(size,table.get(key,100))
            valid.append((c,need,size,D))
    assert min(x[2] for x in valid)==5
    assert all(x[2]>=5 for x in valid)
    return table,valid

def exact_gamma_blocks(r,leaves):
    table,_=module_states();best=10**9;cases=0
    for x in [0,1]:
        options=[(c,need,cost) for (c,need),cost in table.items() if need<=x]
        for states in itertools.product(options,repeat=r):
            cases+=1
            if not x and leaves+sum(z[0] for z in states)<2:continue
            best=min(best,leaves+x+sum(z[2] for z in states))
    return best,cases

def check(r,leaves):
    names,adj,edges=build(r,leaves);n=len(names);idx={v:i for i,v in enumerate(names)}
    degrees=[a.bit_count() for a in adj];freq=Counter(degrees)
    modal_frequency=max(freq.values());mode_min=min(d for d in freq if freq[d]==modal_frequency)
    minimum=min(degrees);A=sum(1<<v for v,d in enumerate(degrees) if d==minimum)
    M=sum(1<<v for v,d in enumerate(degrees) if d==mode_min)
    A2=sum(1<<v for v,d in enumerate(degrees) if d==2);N2=nbd(adj,A2)
    assert minimum==mode_min==1 and A==M and A.bit_count()==leaves
    assert freq[2]==2*r and freq[3]==7*r and freq[r+leaves]==1
    assert all((adj[v]&N2)==0 for v in bitvertices(N2))
    residual=((1<<n)-1)^A
    mu,states=exact_matching(adj,residual);muN,statesN=exact_matching(adj,N2)
    assert mu==4*r+1 and muN==0
    gamma,cases=exact_gamma_blocks(r,leaves);assert gamma==5*r+leaves
    Dnames=[v for v in names if v.startswith('p')]
    for i in range(1,r+1):Dnames += [f'{v}_{i}' for v in ['c','q1','q2','w1','w3']]
    D=sum(1<<idx[v] for v in Dnames);assert len(Dnames)==gamma and is2dom(adj,D)
    matching=[]
    for i in range(r):matching += [(9*i+1,9*i+3),(9*i+2,9*i+4),(9*i+5,9*i+6),(9*i+7,9*i+8)]
    matching.append((idx['x'],idx['c_1']));used=set()
    for u,v in matching:
        assert residual>>u&1 and residual>>v&1 and adj[u]>>v&1
        assert u not in used and v not in used
        used.update([u,v])
    assert len(matching)==mu
    rhs=M.bit_count()+mu+muN;deficit=gamma-rhs;assert deficit==r-1 and deficit>0
    ans=dict(r=r,leaves=leaves,n=n,m=len(edges),gamma2=gamma,mode_min_degree=mode_min,
             degree_frequencies=dict(sorted(freq.items())),modal_frequency=modal_frequency,
             minimum_degree_count=A.bit_count(),matching_after_minimum_degree_deletion=mu,
             matching_of_neighbors_degree_two=muN,rhs395a=rhs,violation=deficit,
             boundary_cases_checked=cases,matching_DP_states=states,
             dominating_set=Dnames,matching=[[names[u],names[v]] for u,v in matching])
    if r==2 and leaves==14:ans.update(vertex_order=names,edges=edges,degrees=degrees)
    return ans

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path);args=p.parse_args()
    table,_=module_states()
    report=dict(result='PASS',claim='Original WOWII395a is false',
                module=dict(subsets_checked=512,minimum_cost=5,table=[dict(center=c,need=need,cost=cost) for (c,need),cost in sorted(table.items())]),
                witness=check(2,14),unique_mode_witness=check(2,15),family=[check(r,leaves) for r in range(2,9) for leaves in [7*r,7*r+1,9*r]],
                scope='Exact module/boundary transfer, not global2^33 enumeration. Independent exact matching DP. The written proof establishes the infinite family.')
    out=json.dumps(report,indent=2)+'\n'
    if args.output:args.output.write_text(out)
    print(out)

if __name__=='__main__':main()
