# Round 04 source/status audit: WOWII 382c and 434e

Checked 2026-10-26 UTC. **Both proposed resolutions address the original statements with the original invariant conventions. No prior full resolution was located in the checked public sources and bounded searches.** This is not a worldwide priority certificate. Mathematical verification is recorded separately in the proof and independent-audit directories.

## 382c: exact averaging and scope

The [original archived catalogue row](https://gitlab.com/ai-village-agents/village/graffiti-verification/-/blob/3be380b4222f974bedbefb228c8e75fbd9a7b3ae/data/wow2_rows_html.json) assumes connected `G` with `n>2` and asserts

`gamma_2(G) <= (alpha(G)*ecc_avg(A)+|B|)/2`,

where `A` is the minimum-degree vertex set and `B` is the periphery. It is dated January 2010 and has historical label `O`.

The [original definition file](https://web.archive.org/web/20240512133636id_/http://cms.uhd.edu/faculty/delavinae/research/wowII/wowIIdefs.js), recovered in Round 03, fixes the meanings:

* Definition **108**, explicitly linked by 382c, averages the eccentricities of the vertices in the specified set. Definition **36** independently gives the same definition as the mean of `ecc(v)` over `v in A`; definition **21** computes eccentricity using distances in the ambient graph. This is **not** eccentricity of a set and **not** distance inside `G[A]`.
* Definition **5** defines `alpha` as the maximum independent-set cardinality.
* Definition **55** defines `B` as vertices of maximum eccentricity, not a different graph-boundary notion.
* Definition **90** is ordinary 2-domination: only vertices outside the selected set need two selected neighbors.

The source has square brackets around the **numerator**, followed by division by two; it does not print FLOOR or CEIL. For the proposed family that numerator is already an integer. The 24-vertex witness also has integer final RHS, so its failure is unaffected even by a hypothetical rounding of the final bound.

For `G=(K_r join 2K_1) corona K_2`, the reported values are `alpha=r+2`, `gamma_2=2r+4`, `|B|=4`, and `ecc_avg(A)=(3r+8)/(r+2)`. Thus the RHS is `(3r+12)/2`, with deficit `(r-4)/2`. The source-compatible examples are `14 > 27/2` at `r=5` and `16 > 15` at `r=6`. These values are proved and verified in `../twodomination/` and `../independent_audit/`, not inferred from the literature search.

### Construction prior art is not target-resolution prior art

Triangle coronas already occur in the supplied baseline's work on a different target, 393d. Ordinary graph coronas and their 2-domination numbers are also explicitly studied by Domoloan and Canoy, [2-Domination and Restrained 2-Domination in Graphs](https://www.m-hikari.com/ams/ams-2015/ams-113-116-2015/p/canoyAMS113-116-2015.pdf), Applied Mathematical Sciences **9** (2015), no. 114, 5651–5659, DOI 10.12988/ams.2015.54332, published 2015-09-03. That paper contains no occurrence of 382, eccentricity, periphery, or Graffiti in the extracted full text. It is prior art for the construction and associated parameter calculations, **not a located resolution of 382c**. Its displayed Corollary 3.2 has an apparent typographical discrepancy between `1+n*gamma(H)` and the proof's `n*(1+gamma(H))`; the present direct triangle argument does not rely on that display. Do not claim the graph operation or the basic corona calculation is new.

## 434e: exact original inequality and independent author source

The catalogue row, dated 2010-12-08 with historical label `O`, assumes connected `G` of order greater than three and asserts

`i(G) <= SW(complement(G)) - ecc_G(C) + 2`,

where `C` is the center. Definition **7** gives `i` as the minimum size of an independent dominating set, definition **64** defines the center, and definition **119** gives `SW` as degeneracy, **without adding one**.

There is independent primary confirmation: DeLaVina, Pepper, and Waller, [Graffiti.pc on the Independent-Domination Number of a Graph](https://www.uhd.edu/documents/academics/sciences/dpw-cn2011.pdf), **Conjecture 3.2, printed page 8**, states exactly this inequality using `d(G^c)`. Its preceding paragraph defines `d` as degeneracy and defines center eccentricity as the maximum distance to the nearest center vertex. Thus `ecc_G(C)=max_x min_{c in C} dist_G(x,c)`, using the standard zero convention when every vertex is central; it is not automatically the radius. The author paper presents the statement as an open conjecture at publication, not as a proof.

The current verification README's §7hx treats 434e as a **finite-range control** in an SW convention audit; it gives no full proof. Such control evidence must not be upgraded to a resolution. The supplied baseline covers special cases, including the zero-slack boundary, but not the complete positive-slack regime now addressed in the Round 04 manuscript. The new proof's upper-minimal-vertex-cover metric bound was included in the bounded equivalent-result search; no equivalent full resolution was located. This audit does not independently certify historical novelty of each proof lemma.

## Current public records and search limits

Round 04 refreshed both repository heads:

* Public [verification README](https://gitlab.com/ai-village-agents/village/graffiti-verification/-/blob/e4f890b23a62ed8086269e52afee684db86755b3/README.md) and [ledger](https://gitlab.com/ai-village-agents/village/graffiti-verification/-/blob/e4f890b23a62ed8086269e52afee684db86755b3/verify/ledger.tsv): `e4f890b23a62ed8086269e52afee684db86755b3`, committed 2026-10-23T16:39:59-07:00. Neither target has a resolution entry.
* [Formal Conjectures](https://github.com/google-deepmind/formal-conjectures/tree/039378b7951df701428aa5c6732a94a149a077e1/FormalConjectures/WrittenOnTheWallII): `039378b7951df701428aa5c6732a94a149a077e1`, dated 2026-10-25T21:38:40Z. Neither target has an individual file. Absence does not prove openness.

The 2010 author-hosted 2-domination paper, July 2026 public worklog, archived original statements, and supplied baseline were also checked. Exact-number, formula, center-eccentricity, upper-cover, and corona searches are recorded in `search_log.json`. Searches returning other conjectures or unrelated uses of the numbers were not counted as target evidence. Live UHD catalogue access previously failed; historical `O` labels are therefore explicitly distinguished from current verification.

**Recommended priority wording:** “No prior full resolution found in the checked sources as of 2026-10-26.” Exact original rows and selected definitions are in `statements_382c_434e.json`; retrieval versions and file hashes are recorded alongside this report.
