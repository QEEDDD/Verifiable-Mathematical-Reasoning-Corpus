# Independent audit: the upper-cover metric lemma and WOWII 434e

**Date:** 26 October 2026.  
**Role:** independent mathematical audit and independent implementation, separate from the initial proof draft.  
**Finding:** the metric lemma in the initial draft is correct. Together with the already established equality-case theorem (baseline Theorem 40.7), it proves the full printed 434e inequality. The finite computations below corroborate the proof; they are not its premises. No worldwide-priority claim is made here.

## 1. Definitions

For any graph F, including the empty graph, let i(F) be the minimum size of a maximal independent set, with i(empty)=0, and put q(F)=|V(F)|-i(F). Complementation of a maximal independent set inside V(F) is a minimal vertex cover, so q(F) is the **maximum cardinality of an inclusion-minimal vertex cover**, not the minimum vertex-cover number. The parameter q is additive over connected components; isolated components contribute zero.

For connected G, let C(G) be its center and rho(G)=max_u dist_G(u,C(G)). Let d be the degeneracy of the complement, not its coloring number.

## 2. Independently verified metric lemma

For every vertex v of every connected graph G of order at least two, write A=N_G(v), R=G-N_G[v], and q=q(R). Then

    rho(G) <= max{2,q+1}.

If q=0, R is independent: any edge yields a nonempty minimal vertex cover. Every vertex of R therefore has a neighbor in A by connectivity. Consequently ecc_G(v)<=2, and rho(G)<=rad(G)<=2.

Assume q>=1. Fix an **arbitrary prescribed vertex u**. We construct a dominating tree T of G containing u and having diameter at most 2q+2. Here “tree of G” means a tree subgraph, not necessarily an induced tree.

### A. Covers rooted at the boundary

For each nontrivial component F_j of R, choose b_j in F_j having a neighbor a_j in A. Such a b_j exists by connectivity of G. Choose a neighbor w_j of b_j inside F_j. Extend {w_j} to a maximal independent set I_j of F_j, and set Q_j=V(F_j)\I_j. Then Q_j is a minimal vertex cover and contains b_j. Put r_j=|Q_j|. We have r_j>=1 and

    sum_j r_j <= sum_j q(F_j) = q(R) = q.

The covers need not have maximum cardinality; the proof only needs this upper bound.

### B. The rooted trees inside components

Take any tree connecting Q_j inside the connected graph F_j, then remove leaves not in Q_j until none remain. The resulting tree T_j contains Q_j, contains b_j, and has all its leaves in Q_j. Its vertices outside Q_j form an independent set because Q_j is a vertex cover of the whole component.

If r_j=1, T_j is the single vertex b_j. Otherwise a longest path of T_j has both endpoints among its leaves, hence in Q_j. Its Q_j vertices number at most r_j, and the independent non-Q_j vertices number at most one less than the number of Q_j vertices on that path. Therefore

    diam(T_j) <= 2r_j-2.

In particular dist_Tj(b_j,x)<=2r_j-2 for every vertex x of T_j.

**Audit caution:** for an arbitrary path, one cannot simply assume both endpoints belong to Q_j. The diameter argument above works because diameter endpoints are leaves. The root-to-arbitrary-vertex estimate then follows from the diameter bound. This resolves the only endpoint-count subtlety in the informal sketch.

### C. Connecting the components

Start with the star on {v} union A, join every T_j by the edge a_j b_j, and call the resulting tree T_0. Components F_j are disjoint, so these joins cannot create a cycle. Put s=sum_j r_j<=q.

Every vertex outside T_0 has a neighbor in T_0. A vertex omitted from a nontrivial component has a neighbor in its cover Q_j. A singleton component of R has a neighbor in A. Hence T_0 dominates G.

The distance bounds are as follows:

* two star vertices: at most 2;
* two vertices in one T_j: at most 2r_j-2;
* a vertex in T_j and a star vertex: at most (2r_j-2)+2+1=2r_j+1;
* vertices in distinct T_j,T_l: at most (2r_j-2)+2+2+(2r_l-2)=2(r_j+r_l)<=2s.

Thus diam(T_0)<=max{2,2s+1}<=2q+1. If u already belongs to T_0, set T=T_0. Otherwise attach u by one edge to a vertex of T_0 that dominates it. The resulting T remains a dominating tree, contains u, and satisfies diam(T)<=2q+2.

### D. Recovering the graph center rather than merely a radius bound

A center z of the tree T has tree eccentricity ceil(diam(T)/2)<=q+1. Since T dominates G,

    ecc_G(z) <= q+2,
    dist_G(u,z) <= q+1.

Therefore rad(G)<=q+2. If rad(G)<=q+1, every fixed graph center is within q+1 of every vertex. Otherwise rad(G)=q+2, and the constructed z is a graph center. Since u was arbitrary, in both cases rho(G)<=q+1.

The second case is essential. An attempted replacement by the stronger claim rad(G)<=q+1 is not justified and is not needed.

## 3. Deduction of 434e

Choose v of maximum degree Delta. An independent dominating set of R together with v independently dominates G. Hence i(R)>=i(G)-1 and

    q(R) = n-1-Delta-i(R)
         <= n-Delta-i(G)
         = delta(complement G)+1-i(G)
         <= d+1-i(G).

Write h=d+1-i(G)>=0. If h>=1, the metric lemma gives

    rho(G) <= max{2,q(R)+1} <= h+1,

which is equivalent to i(G)<=d-rho(G)+2. If h=0, the already established baseline Theorem 40.7 states that the graph center is dominating, so rho(G)<=1=h+1. Thus 434e follows on its full printed domain, indeed for all connected graphs of order at least two.

The metric lemma additionally yields the generally stronger but clipped bound

    rho(G) <= max{2,n-Delta(G)-i(G)+1}.

The clipping at 2 cannot simply be removed: atlas graph EiGO has n=6, Delta=3, i=3, and rho=2. Its complement degeneracy is 3, so it is not in the zero-slack equality case of 434e.

## 4. Independent executable audit

`verify_metric_lemma.cpp` is an independent standard C++17 implementation. It enumerates all labeled connected graphs of orders 2 through the requested maximum (up to 7), and checks:

1. the metric lemma for every possible root v;
2. q(R) by exact maximal-independent-set enumeration, including empty R;
3. the full 434e inequality and its zero-slack case;
4. the clipped maximum-degree strengthening;
5. for every root with q(R)>0, the actual construction for every prescribed u;
6. cover minimality by constructing complements of maximal independent sets;
7. the cover budget, all rooted component-tree depth and diameter estimates, domination, the base-tree diameter, final tree connectivity and edge count, final diameter and radius, and transfer of its center to a center of G in the extremal-radius case.

The implementation chooses one valid boundary, cover, and pruned BFS tree deterministically for each component. It does **not** exhaust every valid choice; the written argument above applies to every such choice. The graph/root/prescribed-vertex ranges are exhaustive.

Reproduce:

    g++ -O3 -std=c++17 verify_metric_lemma.cpp -o verify_metric_lemma
    ./verify_metric_lemma 7 > exhaustive_results.json

The completed process exited with code 0 and returned PASS in `exhaustive_results.json`. It checked **1,893,731** connected labeled graphs, **13,227,822** graph/root cases, and **67,714,976** actual dominating-tree constructions. Recorded runtime: 55.6373 seconds. These are finite corroborating checks, not a replacement for the unrestricted proof.

## 5. Source and scope preservation

This audit uses the preserved baseline at `sources/baseline.txt`, especially Theorem 40.7 and the exact remaining-slack formulation following Corollary 40.8. It does not alter any source file or historical status label. The originating proof and its manuscript are maintained by the independence workstream; this directory is a separate audit. A current-status/priority audit, if needed for a publication claim, belongs to the source-audit workstream.
