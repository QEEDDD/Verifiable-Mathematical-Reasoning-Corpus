import networkx as nx,json,itertools
from fractions import Fraction
out=[]
for r in [5,6,7,10,20]:
 m=r+2;G=nx.Graph();G.add_nodes_from(range(3*m));G.add_edges_from(itertools.combinations(range(r),2));G.add_edges_from((a,b) for a in range(r) for b in [r,r+1])
 for i in range(m):G.add_edges_from([(i,m+2*i),(i,m+2*i+1),(m+2*i,m+2*i+1)])
 dist=dict(nx.all_pairs_shortest_path_length(G));ecc={v:max(dist[v].values()) for v in G};A={v for v in G if G.degree(v)==min(dict(G.degree()).values())};B={v for v in G if ecc[v]==max(ecc.values())};avg=Fraction(sum(ecc[v] for v in A),len(A));alpha=max(map(len,nx.find_cliques(nx.complement(G)))) if r<=7 else m
 gamma=2*m
 rhs=(alpha*avg+len(B))/2
 assert len(A)==2*m and len(B)==4 and avg==Fraction(3*r+8,r+2) and rhs==Fraction(3*r+12,2) and gamma>rhs
 # Verify universal local minimum2 for every private triangle's nonroot constraints.
 for selected in range(8):
  valid=all((selected>>j&1) or sum(selected>>k&1 for k in range(3) if k!=j)>=2 for j in [1,2])
  if valid:assert selected.bit_count()>=2
 direct=None
 if r==5:
  adj=[sum(1<<v for v in G[u]) for u in G];best=len(G)
  for s in range(1<<len(G)):
   cost=s.bit_count()
   if cost>=best:continue
   if all((s>>v&1) or (s&adj[v]).bit_count()>=2 for v in G):best=cost
  assert best==gamma;direct={'subsets':1<<len(G),'gamma2':best}
 out.append({'r':r,'n':len(G),'m':G.number_of_edges(),'alpha':alpha,'gamma2':gamma,'A_size':len(A),'B':sorted(B),'ecc_A_average':str(avg),'RHS':str(rhs),'defect':str(gamma-rhs),'direct_exhaustion':direct})
print(json.dumps({'status':'PASS','examples':out},indent=2))
