import networkx as nx,random,json
rng=random.Random(43420261026);counts={'atlas':0,'trees':0,'random':0};vertex_checks=0;h0=0;maxrho=0

def idom(G):return min(map(len,nx.find_cliques(nx.complement(G)))) if len(G) else 0

def check(G,kind):
 global vertex_checks,h0,maxrho
 G=nx.convert_node_labels_to_integers(G);ds=dict(nx.all_pairs_shortest_path_length(G));ecc={v:max(ds[v].values()) for v in G};rad=min(ecc.values());C=[v for v in G if ecc[v]==rad];rho=max(min(ds[v][c] for c in C) for v in G)
 i=idom(G);db=max(nx.core_number(nx.complement(G)).values());h=db+1-i
 assert h>=0 and rho<=h+1,(kind,len(G),i,db,rho)
 if h==0:h0+=1;assert rho<=1
 maxrho=max(maxrho,rho)
 for v in G:
  R=G.subgraph(set(G)-set(G[v])-{v});q=len(R)-idom(R)
  assert rho<=max(2,q+1),(kind,len(G),v,q,rho)
  vertex_checks+=1
 counts[kind]+=1
for G in nx.graph_atlas_g():
 if len(G)>=2 and nx.is_connected(G):check(G,'atlas')
for n in range(8,13):
 for G in nx.nonisomorphic_trees(n):check(G,'trees')
for z in range(1000):
 n=rng.randrange(8,19);G=nx.gnp_random_graph(n,rng.uniform(.06,.8),seed=rng.randrange(2**32))
 if nx.is_connected(G):check(G,'random')
print(json.dumps({'status':'PASS','counts':counts,'vertex_lemma_checks':vertex_checks,'zero_slack_graphs':h0,'maximum_center_distance':maxrho,'seed':43420261026,'networkx':nx.__version__},indent=2))
