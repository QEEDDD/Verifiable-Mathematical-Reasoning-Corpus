#!/usr/bin/env python3
"""Exact standard-library counterexample to WOWII382c.
Full enumeration of all2^21 vertex subsets on the r=5 witness.
"""
import argparse,json
from fractions import Fraction
from functools import lru_cache
from pathlib import Path

def build(r):
    assert r>=1
    m=r+2;n=3*m;names=[f'a{i+1}' for i in range(r)]+['u','v']
    names += [f'p{i+1}_{j+1}' for i in range(m) for j in range(2)]
    edges=[]
    for i in range(r):
        for j in range(i+1,m):edges.append((i,j))
    for i in range(m):
        p=m+2*i;q=p+1;edges += [(i,p),(i,q),(p,q)]
    adj=[0]*n
    for u,v in edges:
        assert u!=v and not (adj[u]>>v&1)
        adj[u]|=1<<v;adj[v]|=1<<u
    return names,adj,edges

def alpha(adj):
    @lru_cache(None)
    def rec(S):
        if not S:return 0
        b=S&-S;v=b.bit_length()-1
        return max(rec(S^b),1+rec((S^b)&~adj[v]))
    return rec((1<<len(adj))-1)

def is2dom(adj,D):
    return all(D>>v&1 or (D&adj[v]).bit_count()>=2 for v in range(len(adj)))

def exhaustive_gamma(adj):
    best=len(adj);witness=None;valid=0
    for D in range(1<<len(adj)):
        if is2dom(adj,D):
            valid+=1
            if D.bit_count()<best:best=D.bit_count();witness=D
    return best,witness,valid

def distances(adj):
    n=len(adj);out=[]
    for s in range(n):
        d=[None]*n;d[s]=0;q=[s]
        for v in q:
            for w in range(n):
                if adj[v]>>w&1 and d[w] is None:d[w]=d[v]+1;q.append(w)
        assert None not in d
        out.append(d)
    return out

def check_module():
    adj=[6,5,3];valid=[]
    for D in range(8):
        if all(D>>v&1 or (D&adj[v]).bit_count()>=2 for v in [1,2]):valid.append(D)
    assert min(D.bit_count() for D in valid)==2
    return dict(subsets_checked=8,minimum_nonroot_domination_cost=2,valid_masks=valid)

def check(r,full=False):
    names,adj,edges=build(r);n=len(adj);m=r+2
    deg=[a.bit_count() for a in adj];A=[i for i,d in enumerate(deg) if d==min(deg)]
    dist=distances(adj);ecc=[max(row) for row in dist];B=[i for i,e in enumerate(ecc) if e==max(ecc)]
    al=alpha(adj);mean=Fraction(sum(ecc[i] for i in A),len(A));rhs=(al*mean+len(B))/2
    D=sum(1<<v for v in range(m,n));gamma=2*m
    assert len(A)==2*m and all(v>=m for v in A)
    assert al==m and len(B)==4 and max(ecc)==4
    assert mean==Fraction(3*r+8,r+2)
    assert is2dom(adj,D) and D.bit_count()==gamma
    assert rhs==Fraction(3*r+12,2)
    assert gamma-rhs==Fraction(r-4,2)
    # Exact disjoint-module state transfer: each module needs2, and the
    # union of privatepairs attains it. The local table was exhausted above.
    result=dict(r=r,n=n,m_edges=len(edges),gamma2=gamma,independence_number=al,
                minimum_degree=min(deg),minimum_degree_count=len(A),
                eccentricity_sum_on_minimum_degree_set=sum(ecc[i] for i in A),
                mean_eccentricity=str(mean),periphery_size=len(B),rhs382c=str(rhs),
                deficit=str(gamma-rhs),dominating_set=[names[v] for v in range(m,n)],
                independent_set=[names[m+2*i] for i in range(m)])
    if full:
        brute,W,valid=exhaustive_gamma(adj);assert brute==gamma
        result.update(exhaustive_gamma2=brute,vertex_subsets_checked=1<<n,valid_2dominating_sets=valid,
                      vertex_order=names,edges=edges,degrees=deg,eccentricities=ecc,
                      minimum_degree_set=[names[v] for v in A],periphery=[names[v] for v in B],
                      distance_matrix=dist)
    return result

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path);args=p.parse_args()
    result=dict(result='PASS',claim='Original WOWII382c is false',module=check_module(),
                witness=check(5,True),integer_rhs_witness=check(6),family_checks=[check(r) for r in range(1,21)],
                scope='All2^21 subsets checked for witness. Exact rational invariants. Written proof gives infinite family; r<=4 are nonviolating boundary controls.')
    assert Fraction(result['witness']['deficit'])>0
    out=json.dumps(result,indent=2)+'\n'
    if args.output:args.output.write_text(out)
    print(out)
if __name__=='__main__':main()
