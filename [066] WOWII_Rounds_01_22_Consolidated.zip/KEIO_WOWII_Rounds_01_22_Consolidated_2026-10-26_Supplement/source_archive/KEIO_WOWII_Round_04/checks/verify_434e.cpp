// Standalone C++17 exact verification of the metric lemma and WOWII 434e.
// g++ -O3 -std=c++17 verify_434e.cpp -o verify_434e
// ./verify_434e 7 6  (all labelled graphs through 7; construct trees through 6)
#include <algorithm>
#include <cassert>
#include <chrono>
#include <cstdlib>
#include <iostream>
#include <vector>
using namespace std;using Mask=unsigned;
int pc(Mask x){return __builtin_popcount(x);}int first(Mask x){assert(x);return __builtin_ctz(x);}
Mask reach(const vector<Mask>&a,Mask S,int r){Mask seen=1u<<r,todo=seen;while(todo){int v=first(todo);todo&=todo-1;Mask z=a[v]&S&~seen;seen|=z;todo|=z;}return seen;}
vector<vector<int>> distances(const vector<Mask>&a,Mask S){int n=a.size();vector<vector<int>>ds(n,vector<int>(n,1000));for(Mask z=S;z;z&=z-1){int r=first(z);vector<int>q(1,r);ds[r][r]=0;for(size_t head=0;head<q.size();++head){int v=q[head];for(Mask zz=a[v]&S;zz;zz&=zz-1){int w=first(zz);if(ds[r][w]==1000){ds[r][w]=ds[r][v]+1;q.push_back(w);}}}}return ds;}
int degen(const vector<Mask>&a){Mask S=(1u<<a.size())-1;int d=0;while(S){int v=-1,m=1000;for(Mask z=S;z;z&=z-1){int w=first(z),deg=pc(a[w]&S);if(deg<m){m=deg;v=w;}}d=max(d,m);S&=~(1u<<v);}return d;}
struct Counts{long long graphs=0,roots=0,rooted_trees=0,zero_slack=0,positive_slack=0,tight=0;};
void construct(const vector<Mask>&a,int v,int qr,int radius,Mask C,Counts&ct){
 int n=a.size();Mask all=(1u<<n)-1,A=a[v],R=all&~(A|(1u<<v)),vertices=A|(1u<<v),Q=0;
 vector<Mask>t(n);auto edge=[&](int x,int y){assert(a[x]>>y&1);t[x]|=1u<<y;t[y]|=1u<<x;};
 for(Mask z=A;z;z&=z-1)edge(v,first(z));
 Mask left=R;
 while(left){Mask F=reach(a,R,first(left));left&=~F;if(pc(F)==1)continue;
  int b=-1;for(Mask z=F;z;z&=z-1){int x=first(z);if(a[x]&A){b=x;break;}}assert(b>=0);
  int w=first(a[b]&F);Mask I=1u<<w;
  for(Mask z=F;z;z&=z-1){int x=first(z);if(!(I>>x&1)&&!(a[x]&I))I|=1u<<x;}
  Mask Qj=F&~I;assert(Qj>>b&1);Q|=Qj;
  vector<Mask>tj(n);vector<int>todo(1,b);Mask seen=1u<<b;
  for(size_t head=0;head<todo.size();++head){int x=todo[head];for(Mask z=a[x]&F&~seen;z;z&=z-1){int y=first(z);seen|=1u<<y;todo.push_back(y);tj[x]|=1u<<y;tj[y]|=1u<<x;}}
  assert(seen==F);Mask keep=F;bool change=true;
  while(change){change=false;for(Mask z=keep&~Qj;z;z&=z-1){int x=first(z);if(pc(tj[x]&keep)<=1){keep&=~(1u<<x);change=true;}}}
  assert((keep&Qj)==Qj);vertices|=keep;
  for(Mask z=keep;z;z&=z-1){int x=first(z);t[x]|=tj[x]&keep;}
  edge(b,first(a[b]&A));
 }
 assert(pc(Q)<=qr);
 for(int u=0;u<n;++u){auto tt=t;Mask V=vertices;
  if(!(V>>u&1)){Mask targets=a[u]&Q;if(!targets)targets=a[u]&A;assert(targets);int w=first(targets);tt[u]|=1u<<w;tt[w]|=1u<<u;V|=1u<<u;}
  assert(reach(tt,V,first(V))==V);int twice_edges=0;Mask dominated=V;
  for(Mask z=V;z;z&=z-1){int x=first(z);twice_edges+=pc(tt[x]);dominated|=a[x];}
  assert(twice_edges==2*(pc(V)-1)&&dominated==all);
  auto ds=distances(tt,V);int diam=0,rad=1000,center=-1;
  for(Mask z=V;z;z&=z-1){int x=first(z),ecc=0;for(Mask zz=V;zz;zz&=zz-1)ecc=max(ecc,ds[x][first(zz)]);diam=max(diam,ecc);if(ecc<rad){rad=ecc;center=x;}}
  assert(diam<=2*qr+2 && rad<=qr+1);assert(ds[u][center]<=qr+1);
  if(radius==qr+2)assert(C>>center&1);
  ++ct.rooted_trees;
 }
}
void check(const vector<Mask>&a,bool construction,Counts&ct){
 int n=a.size();Mask all=(1u<<n)-1;if(reach(a,all,0)!=all)return;++ct.graphs;
 vector<int>i(1u<<n);for(Mask S=1;S<=all;++S){i[S]=n;for(Mask z=S;z;z&=z-1){int v=first(z);i[S]=min(i[S],1+i[S&~(a[v]|(1u<<v))]);}}
 vector<Mask>h(n);for(int v=0;v<n;++v)h[v]=all&~(a[v]|(1u<<v));int d=degen(h),k=i[all],slack=d+1-k;assert(slack>=0);
 auto ds=distances(a,all);vector<int>ecc(n);int radius=n;for(int v=0;v<n;++v){ecc[v]=*max_element(ds[v].begin(),ds[v].end());radius=min(radius,ecc[v]);}
 Mask C=0;for(int v=0;v<n;++v)if(ecc[v]==radius)C|=1u<<v;
 int rho=0;for(int v=0;v<n;++v){int toC=n;for(Mask z=C;z;z&=z-1)toC=min(toC,ds[v][first(z)]);rho=max(rho,toC);}
 for(int v=0;v<n;++v){Mask R=all&~(a[v]|(1u<<v));int qr=pc(R)-i[R];assert(qr>=0);assert(rho<=max(2,qr+1));assert(i[R]>=k-1);++ct.roots;
  if(construction&&qr>=1)construct(a,v,qr,radius,C,ct);
 }
 assert(rho<=slack+1);assert(k<=d-rho+2);if(k==d-rho+2)++ct.tight;
 if(slack==0){assert(rho<=1);++ct.zero_slack;}else ++ct.positive_slack;
}
int main(int argc,char**argv){int maxn=argc>1?atoi(argv[1]):6,construction=argc>2?atoi(argv[2]):6;assert(2<=maxn&&maxn<=7);auto start=chrono::steady_clock::now();Counts total;
 cout<<"{\n  \"result\": \"PASS\",\n  \"domain\": \"all labelled connected graphs\",\n  \"construction_through_order\": "<<construction<<",\n  \"orders\": [\n";
 for(int n=2;n<=maxn;++n){vector<pair<int,int>>es;for(int u=0;u<n;++u)for(int v=u+1;v<n;++v)es.emplace_back(u,v);Counts ct;
  for(unsigned long long code=0;code<(1ull<<es.size());++code){vector<Mask>a(n);for(size_t e=0;e<es.size();++e)if(code>>e&1){auto[u,v]=es[e];a[u]|=1u<<v;a[v]|=1u<<u;}check(a,n<=construction,ct);}
  cout<<"    {\"n\": "<<n<<", \"graphs\": "<<ct.graphs<<", \"metric_lemma_vertex_choices\": "<<ct.roots<<", \"constructed_rooted_dominating_trees\": "<<ct.rooted_trees<<", \"zero_slack_graphs\": "<<ct.zero_slack<<", \"positive_slack_graphs\": "<<ct.positive_slack<<", \"tight_434e\": "<<ct.tight<<"}"<<(n<maxn?",":"")<<"\n";
  total.graphs+=ct.graphs;total.roots+=ct.roots;total.rooted_trees+=ct.rooted_trees;
 }
 cout<<"  ],\n  \"total_graphs\": "<<total.graphs<<",\n  \"total_vertex_choices\": "<<total.roots<<",\n  \"total_rooted_trees\": "<<total.rooted_trees<<",\n  \"seconds\": "<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"\n}\n";
}
