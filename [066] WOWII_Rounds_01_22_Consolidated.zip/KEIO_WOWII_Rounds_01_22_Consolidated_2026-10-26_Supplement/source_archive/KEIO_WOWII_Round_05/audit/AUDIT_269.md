# Round 05 source/status audit: WOWII 269

Checked 2026-10-26 UTC. **The proposed counterexample addresses the original conjecture, including its ceiling, distinct-center-pair average, and prohibition of all 4-cycles. No prior full resolution was located in the checked public records and bounded searches.** This is not a worldwide priority certificate. Mathematical verification is recorded separately in `../checks/` and `./`.

## Exact original target

The [archived original catalogue row](https://gitlab.com/ai-village-agents/village/graffiti-verification/-/blob/3be380b4222f974bedbefb228c8e75fbd9a7b3ae/data/wow2_rows_html.json), dated 23 February 2007, asserts for a simple connected C4-free graph:

`gamma_t(G) >= CEIL[1 + dist_avg(C)]`,

where C is the center. The row has the historical label O. That label is not a current verification certificate.

The [original definition file](https://web.archive.org/web/20240512133636id_/http://cms.uhd.edu/faculty/delavinae/research/wowII/wowIIdefs.js), recovered in Round 03, fixes the potentially decisive conventions:

* **16 and 22:** CEIL and FLOOR are distinct operations. The ceiling in 269 must not be replaced by the floor in adjacent conjecture 268.
* **61:** average distance is taken over nonzero distances between center vertices. Diagonal zero distances are excluded. Ordered and unordered distinct-pair averages agree.
* **21 and 64:** center vertices minimize ordinary eccentricity, measured in the ambient graph.
* **73:** C4-freeness excludes a 4-cycle even when it has chords. Triangles are not excluded. Checking only induced 4-cycles would be insufficient.
* **94:** total domination requires every vertex, including selected vertices, to have a selected neighbor.

Exact row data and the selected definition records are preserved in `statement_269.json`. The construction has all vertices central, so no convention about averaging a singleton center is relevant.

## Fit of the proposed counterexample to the source

The certificate in `../checks/certificate269.json` reports the member with Y=62 plain paths and Z=35 triangle-decorated paths. It has order 268, size 433, radius and diameter four, center size 268, and total domination number four. It explicitly checks absence of every 4-cycle using common-neighbor counts.

The reported unordered distance histogram is `(433, 9070, 16333, 9942)` at distances one through four. Thus there are 35,778 distinct pairs with total distance 107,340, giving

`dist_avg(C) = 17890/5963 = 3 + 1/5963`.

Consequently the original RHS is five, while gamma_t is four. The corresponding floor RHS would be four: this example refutes 269, **not 268**. These numerical and structural claims are proved and independently checked in the mathematical directories; the source audit verifies that they use the intended quantities.

The Round 02 reduction explicitly left `gamma_t=radius=4` unresolved, so this example does not contradict that partial result. No claim of global minimum counterexample order is made. Any minimum-order assertion for the displayed two-parameter family must be kept separate from global minimality.

## Current public record: a stale overstatement is not a proof

The [verification README](https://gitlab.com/ai-village-agents/village/graffiti-verification/-/blob/e4f890b23a62ed8086269e52afee684db86755b3/README.md), section 7ft.10, includes the sentence **“They are not refutable”** about the distance-average block. Its actual evidence does not establish a full theorem for 269. The section gives negative finite searches through orders five to seven and unsuccessful searches at orders eleven to thirteen. Its proof addresses the special case gamma_t=radius=2; the accompanying argument also handles gamma_t=3. Neither addresses the present radius-four example. Its center-average estimate by the radius alone is insufficient for the ceiling inequality. No 269 resolution entry occurs in the checked ledger. This audit therefore treats the universal-sounding rhetoric as an unsupported extrapolation, not a prior accepted resolution.

Both public repository heads were refreshed for this round:

* Verification repository: `e4f890b23a62ed8086269e52afee684db86755b3`, committed 2026-10-23T16:39:59-07:00; the [ledger](https://gitlab.com/ai-village-agents/village/graffiti-verification/-/blob/e4f890b23a62ed8086269e52afee684db86755b3/verify/ledger.tsv) has no 269 entry.
* [Formal Conjectures](https://github.com/google-deepmind/formal-conjectures/tree/039378b7951df701428aa5c6732a94a149a077e1/FormalConjectures/WrittenOnTheWallII): `039378b7951df701428aa5c6732a94a149a077e1`, dated 2026-10-25T21:38:40Z; no individual 269 file appears in the checked directory. Absence is not proof of openness.

## Related primary literature checked, and why it is not a resolution

1. DeLaVina, Liu, Pepper, Waller, and West, [Some conjectures of Graffiti.pc on total domination](https://www.uhd.edu/documents/academics/sciences/total-dom-2007.pdf), Congressus Numerantium 185 (2007), 81–95. Theorem 3 proves the radius lower bound associated with WOWII 230. Its center-set-eccentricity bound is also a different invariant from average distance between centers. Neither proves the additional ceiling step in 269.
2. DeLaVina, Pepper, and Waller, [A note on dominating sets and average distance](https://www.uhd.edu/documents/academics/sciences/dominationavgdistmay23.pdf), Discrete Mathematics 309 (2009), 2615–2619, DOI 10.1016/j.disc.2008.03.018. Theorem 4 proves `gamma_t > average_distance(V) - 1/2`; the sharpness examples are binary stars, not the present self-centered family. This theorem is compatible with gamma_t=4 and average distance just above three. It is not a resolution of 269.
3. Henning and Yeo, [A new lower bound for the total domination number in graphs proving a Graffiti.pc Conjecture](https://pure.uj.ac.za/en/publications/a-new-lower-bound-for-the-total-domination-number-in-graphs-provi/), Discrete Applied Mathematics 173 (2014), 45–52, DOI 10.1016/j.dam.2014.03.013. The authors' institutional publication record explicitly identifies the resolved target as **233**, involving periphery eccentricity, not 269. The similar title is not evidence of a prior resolution of this target.

Exact-number, formula, self-centered graph, and average-distance searches are recorded in `search_log.json`. No exact prior counterexample or full proof of 269 was located. This does not establish that the construction, every proof ingredient, or the result is historically new.

**Recommended status wording:** “A counterexample to the original WOWII 269, with no prior full resolution found in the checked sources as of 2026-10-26.” The mathematical validity and reproducibility of the counterexample are separate from the bounded nature of the priority search.
