# Independent audit of the counterexample to WOWII 269

The original statement uses total domination and the ceiling of one plus the mean of distances between distinct central vertices. It assumes absence of every four-cycle as a subgraph. The construction meets that stronger condition.

## Construction and four-cycle check

The undecorated core has four named vertices a,b,c,d, edges ab and cd, and internally disjoint length-three paths from a to d and from b to c. Suppressing internal degree-two vertices leaves only a four-vertex multigraph with parallel a-d and b-c edges. Its simple cycles lift to length six (parallel paths) or length eight (one path of each type and ab,cd). Thus the undecorated graph has neither triangles nor four-cycles.

Each triangle decoration adds a vertex adjacent exactly to the endpoints of a distinct previously triangle-free base edge. A new four-cycle would require a previous common neighbor of those endpoints. None exists: the base was triangle-free and decorations of different edges have different endpoint sets. No four-cycle is introduced.

## Exact total domination and eccentricity

The named four-set totally dominates. The four open neighborhoods of u1,v1,p1,q1 are disjoint, so any total dominating set needs at least four members. This directly proves the exact value four, independently of the radius theorem used in earlier partial work.

All entries in the manuscript's ten-type distance table were checked. Added triangle vertices cannot shorten old distances, because a two-edge passage through one can be replaced by its base edge. Their distances therefore follow from minimum endpoint distances. Every type has a distance-four partner, and no pair distance exceeds four. Hence every vertex is central and both radius and diameter are four.

## Exact pair counting

The unordered distance contributions are:
- six named pairs:16;
- plain paths within:5Y^2−4Y;
- decorated paths within:21Z^2−11Z;
- plain versus decorated:28YZ;
- named versus plain:16Y;
- named versus decorated:36Z.
Their sum is W=5Y^2+28YZ+21Z^2+12Y+25Z+16. Subtracting3*binom(4+2Y+4Z,2) gives−Y^2+4YZ−3Z^2−9Y−17Z−2. This count is algebraic, not inferred merely from interpolation. A separately generated finite interpolation was used only as a diagnostic and gives the same coefficients.

At(Y,Z)=(62,35), independent graph reconstruction and all-pairs BFS give n268, no4-cycle, all268 eccentricities4, and mean17890/5963=3+1/5963. Thus ceil(1+mean)=5 while gamma_t=4. The supplied standard-library checker was rerun, including rejection of every subset of size at most3 as a total dominating set.

For Y=7s,Z=4s the excess is15s^2−131s−2, positive for every integer s>=9; its value at9 is34 and it is increasing thereafter. Thus the counterexample family is infinite. The center mean tends to91/30. This does not assert an unbounded additive violation of the ceiling inequality: its violated lower bound is5 while gamma_t remains4.

The within-family minimum-order argument also checks: with N=Y+2Z the excess is at most(4N^2−524N−119)/60, negative for0<=N<=131, and n=4+2N. The n268 member attains positive excess6. This is minimum order only within the stated family, not globally.

## Scope

This counterexample lies exactly in the radius-four case left by the Round02 partial theorem; it does not contradict that theorem for equality radius at least6. The older floor version268 remains separate. Current-source and priority checks are documented separately. Internal mathematical/code review is not external peer review or formal verification.
