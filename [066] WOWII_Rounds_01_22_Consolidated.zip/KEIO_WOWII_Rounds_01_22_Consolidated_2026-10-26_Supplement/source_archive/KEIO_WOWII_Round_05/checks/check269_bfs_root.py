import networkx as nx,itertools,json
from fractions import Fraction
out=[]
for Y,Z in [(62,35),(63,36),(100,60),(1,1)]:
 G=nx.Graph();G.add_edges_from([('a','b'),('c','d')])
 for i in range(Y):
  u,v=f'u{i}',f'v{i}';G.add_edges_from([('a',u),(u,v),(v,'d')])
 for j in range(Z):
  p,q,x,y=[f'{s}{j}' for s in 'pqxy'];G.add_edges_from([('b',p),(p,q),(q,'c'),('b',x),(x,p),('c',y),(y,q)])
 cf=all(len(set(G[u])&set(G[v]))<=1 for u,v in itertools.combinations(G,2))
 ds=dict(nx.all_pairs_shortest_path_length(G));ecc={u:max(d.values()) for u,d in ds.items()};rad=min(ecc.values());C=[u for u in G if ecc[u]==rad];av=Fraction(sum(ds[u][v] for u,v in itertools.combinations(C,2)),len(C)*(len(C)-1)//2)
 D={'a','b','c','d'};assert all(set(G[v])&D for v in G)
 lower3=None
 if len(G)<100:
  lower3=not any(all(set(G[v])&set(S) for v in G) for k in range(1,4) for S in itertools.combinations(G,k))
 out.append(dict(Y=Y,Z=Z,n=len(G),C4free=cf,radius=rad,center=len(C),mean=str(av),margin=str(av-3),no_total_domination_size3=lower3))
print(json.dumps(out,indent=2))
