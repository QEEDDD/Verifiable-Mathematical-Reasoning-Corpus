#!/usr/bin/env python3
"""Exact verifier of the two-track decorated cycle family for WOWII 269."""
from collections import deque, Counter
from fractions import Fraction
from itertools import combinations
import json
import sys

def build(Y,Z):
    assert Y>=1 and Z>=1
    n=4+2*Y+4*Z
    adj=[set() for _ in range(n)]
    def edge(a,b): adj[a].add(b);adj[b].add(a)
    edge(0,1);edge(2,3)
    blocks=[];i=4
    for _ in range(Y):
        u,v=i,i+1;i+=2
        for a,b in [(0,u),(u,v),(v,3)]:edge(a,b)
        blocks.append(('plain',u,v))
    for _ in range(Z):
        p,q,x,y=range(i,i+4);i+=4
        for a,b in [(1,p),(p,q),(q,2),(1,x),(p,x),(2,y),(q,y)]:edge(a,b)
        blocks.append(('decorated',p,q,x,y))
    return adj,blocks

def inspect(Y,Z,td_check=True):
    adj,blocks=build(Y,Z);n=len(adj)
    c4_witness=None
    for i in range(n):
        for j in range(i):
            common=adj[i]&adj[j]
            if len(common)>=2:c4_witness=[i,j,*list(common)[:2]];break
        if c4_witness:break
    assert c4_witness is None
    dist=[]
    for v in range(n):
        d=[-1]*n;d[v]=0;q=deque([v])
        while q:
            x=q.popleft()
            for y in adj[x]:
                if d[y]<0:d[y]=d[x]+1;q.append(y)
        assert -1 not in d
        dist.append(d)
    ecc=[max(d) for d in dist];rad=min(ecc)
    center=[i for i in range(n) if ecc[i]==rad]
    assert rad==4 and max(ecc)==4 and len(center)==n
    hist=Counter(dist[i][j] for i in center for j in center if i<j)
    W=sum(d*c for d,c in hist.items());pairs=len(center)*(len(center)-1)//2
    mean=Fraction(W,pairs)
    assert W==5*Y*Y+28*Y*Z+21*Z*Z+12*Y+25*Z+16
    assert hist[1]==2+3*Y+7*Z
    assert hist[2]==Y*Y+3*Y+4*Z*Z+4*Z
    assert hist[4]==4*Y*Z+Z*Z+Z+2
    masks=[sum(1<<j for j in a) for a in adj];allv=(1<<n)-1
    assert masks[0]|masks[1]|masks[2]|masks[3]==allv
    small_checks={}
    if td_check:
        for size in (1,2,3):
            count=0
            for S in combinations(range(n),size):
                union=0
                for i in S:union|=masks[i]
                assert union!=allv,("small total dominating set",S)
                count+=1
            small_checks[size]=count
    result={'Y':Y,'Z':Z,'order':n,'size':sum(map(len,adj))//2,
            'C4_free':True,'radius':rad,'diameter':max(ecc),
            'center_size':len(center),'center_distance_histogram':dict(sorted(hist.items())),
            'center_distance_sum':W,'center_pairs':pairs,
            'center_mean':str(mean),'excess_over_3':str(mean-3),
            'WOWII269_violated':mean>3,
            'total_domination_number':4 if td_check else 'at most 4, certified set [0,1,2,3]',
            'TDS':[0,1,2,3],'rejected_total_dominating_subsets':small_checks}
    return result

if __name__=='__main__':
    Y=int(sys.argv[1]) if len(sys.argv)>1 else 62
    Z=int(sys.argv[2]) if len(sys.argv)>2 else 35
    print(json.dumps(inspect(Y,Z),indent=2))
