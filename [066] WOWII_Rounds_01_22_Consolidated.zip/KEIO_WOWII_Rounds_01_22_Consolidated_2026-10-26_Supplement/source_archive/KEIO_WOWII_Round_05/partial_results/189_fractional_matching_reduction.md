# An independent-set obstruction theorem for WOWII 189

**Status: a precisely scoped reduction, not a proof of traceability.**

Let G be a finite connected simple graph on n>1 vertices, let s=d2 be its
second-smallest degree (multiplicity included), and assume the original 189
hypothesis

    |Even(v)| <= s+1 for every vertex v.                 (H)

Even(v) includes v itself. Since G is connected, s>=1, and at most one vertex
has degree below s. This note proves that a counterexample cannot be explained
by an independent-set neighborhood deficiency. More strongly, every possible
counterexample has a perfect fractional matching / perfect 2-matching.

## Saturation lemma

Suppose A is an independent set of s+1 vertices contained in N(c) for some
vertex c. Then A is a dominating set.

**Proof.** For any a in A, every other member of A is nonadjacent to a and
shares neighbor c with a. Therefore A is contained in Even(a). Hypothesis
(H) and |A|=s+1 give Even(a)=A.

Consider a component K of G-A. Connectedness ensures that some vertex of K
has a neighbor a in A. If x,y are adjacent vertices of K and x is adjacent
to a, then y must also be adjacent to a: otherwise d(a,y)=2, contradicting
Even(a)=A because y is outside A. Adjacency to this a propagates along K,
so every vertex of K has a neighbor in A. This holds for every component.
Hence A dominates G. QED.

In fact the proof shows that, for every component K of G-A and every a in A,
a is either complete or anticomplete to K.

## Neighborhood-deficiency theorem

If an independent set I satisfies |N(I)|<|I|, then necessarily

    |I|=s+1, |N(I)|=s, n=2s+1,

and all but at most one vertex of I are adjacent to every vertex of N(I).
Moreover, G has an explicit Hamiltonian path.

**Proof.** Write t=|I| and q=|N(I)|. The empty set is not deficient. If t=1,
connectedness gives q>=1. If 2<=t<=s, then I contains a vertex of degree at
least s, so q>=s>=t.

Suppose t=s+1. At least s members of I have degree at least s. Since q<t,
we must have q=s; all those at least s vertices are complete to N(I). Let
x be the possible remaining exceptional vertex; connectedness gives it a
neighbor c in N(I). If there is no exceptional vertex, designate any member
as x and choose one of its neighbors c. The vertex c is adjacent to all of I.
The saturation lemma applies to A=I and shows that I dominates G. Thus
V(G)=I disjoint-union N(I), and n=2s+1.

Enumerate N(I) as c1,...,cs with c1 adjacent to x, and enumerate I minus x
as a1,...,as. Each ai is complete to N(I), so

    x,c1,a1,c2,a2,...,cs,as

is a Hamiltonian path, independently of any edges within N(I).

Finally suppose t>=s+2. No vertex can have at least s+1 neighbors in I:
otherwise choose s+1 of them as A. The saturation lemma would make A
dominating, contradicting the existence of the independent vertex in I-A.
Thus every vertex in N(I) has at most s neighbors in I. Counting edges
between I and N(I) gives

    s q >= sum_{a in I} degree(a)
        >= s(t-1)+1 > s(t-1).

The second inequality uses the positive degree of the possible single
exceptional vertex. Since s>=1 and q,t are integers, q>=t, a contradiction.
All cases are covered. QED.

## Perfect fractional matching consequence

If n != 2s+1, then every independent set I satisfies |N(I)|>=|I|. The same
conclusion holds for any nontraceable graph satisfying (H), even if its order
is 2s+1, because the only deficient case above is explicitly traceable.

For completeness, the standard Hall reduction yields the factor consequence
without hiding any additional structural assumption. For an arbitrary set
S, let J=S minus N(S), the vertices having no neighbor within S. Then J is
independent, N(J) is disjoint from S, and

    |N(S)| >= |S intersect N(S)| + |N(J)|
            >= |S intersect N(S)| + |J| = |S|.

Construct the bipartite double cover with a left and right copy of V(G),
joining u_L to v_R exactly when uv is an edge of G. The inequality above is
Hall's condition, so the double cover has a perfect matching. It defines a
permutation pi with v adjacent to pi(v). Its directed cycles have no fixed
points. A two-cycle gives a single matching edge, an odd directed cycle gives
an odd cycle, and an even directed cycle can be replaced by alternating
matching edges. We obtain a spanning subgraph whose components are K2's and
odd cycles: a perfect 2-matching. Giving weight one to each K2 edge and one
half to each odd-cycle edge gives a perfect fractional matching.

This factor characterization is classical (Tutte); the proof here is included
only to make the implication used in this reduction self-contained.

## Consequences and exact limits

1. Every graph satisfying (H) has alpha(G)<=ceil(n/2). Indeed a larger
   independent set is deficient because its neighborhood lies in its
   complement, while the exceptional theorem gives only |I|=(n+1)/2.
2. Every counterexample to 189 has a perfect 2-matching, so none can be
   produced by an independent set I with |N(I)|<|I|.
3. The entire weighted-quotient search grammar based on
   |I|>|V-I|+1 is ruled out by this theorem, with no bound on quotient order
   or bag weights. The 13,061 numerical LP rejections in the accompanying
   exploratory log are therefore not being substituted for a proof.
4. A perfect fractional matching is not a Hamiltonian path. The remaining
   problem includes compatibility and connection of the factor components;
   this note does not assert that they can always be joined.

## Source and prior-result distinction

The exact original row is preserved in round_01/source_audit/
`baseline_candidate_rows.json`, entry 189. Easwar and Johari's 2026 primary
paper proves the conjecture under diameter/order/connectivity alternatives:
https://arxiv.org/abs/2609.11719 . Its residual case is 2-connected, diameter
at least three, and n>=2d2+4 (linear in the second-smallest degree, not
quadratic). Those alternatives are attributed prior work, not added results
of this note. No worldwide-priority claim is made for the reduction above.
