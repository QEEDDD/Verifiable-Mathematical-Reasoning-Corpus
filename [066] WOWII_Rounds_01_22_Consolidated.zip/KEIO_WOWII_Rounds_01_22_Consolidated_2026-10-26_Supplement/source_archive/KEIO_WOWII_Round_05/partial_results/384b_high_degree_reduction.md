# WOWII 384b: a residual-class reduction, not a resolution

Date: 2026-10-26. No new closed conjecture is claimed by this note.

Let `h` be the number of vertices of degree at least3, and let `t` be the number of distinct triangle-incidence counts among all vertices. The original 384b inequality is

\[
\gamma_2(G)\leq\lfloor n-t/2\rfloor=n-\lceil t/2\rceil.
\]

## A constructive bound

For every finite graph,

\[
\gamma_2(G)\leq n-\lceil h/2\rceil.
\]

Take a cut locally maximal under single-vertex flips. Each vertex has at least half of its incident edges across the cut; therefore every vertex of degree at least3 has at least two crossing neighbors. One side contains at least `ceil(h/2)` high-degree vertices. Omit exactly those vertices and select all others. Every omitted vertex has at least two selected neighbors across the cut, proving the bound. This is a direct form of the classical maximum-cut proof of the minimum-degree-three half-order bound, not a new claim to that method.

A vertex of degree at most2 lies in either zero or one triangle. Hence `t≤h+2`. The conjecture therefore follows immediately whenever `ceil(t/2)≤ceil(h/2)`. The only residual numerical profiles are:

1. `t=h+1` with `h` even;
2. `t=h+2` with either parity of `h`.

The improvement needed in each residual profile is exactly one additional omitted vertex beyond the high-degree cut bound. This identifies a gap; it does not fill it.

## Additional low-high-count cases

The conjecture holds when `h≤2`.

- If `h=0`, a connected graph on more than two vertices is a path or cycle, and all vertices have one common triangle count (zero, except for the triangle itself). Thus `t=1`; omitting any degree-two vertex proves the desired bound.
- If `h=2`, any pair of high-degree vertices can be omitted simultaneously: each loses at most one neighbor inside that pair, leaving at least two selected neighbors. Since `t≤4`, this suffices.
- If `h=1`, only `t=3` needs more than one omitted vertex. Let `c` be the unique high-degree vertex. The other triangle counts must be0 and1, while `c` lies in at least two triangles. Every triangle must contain `c`, since an all-degree-two triangle would be a connected component. Two triangles through `c` cannot share another vertex: that shared vertex would have degree at least3 and be a second high-degree vertex. Thus two such triangles have disjoint private pairs. Omit one private vertex from each; each omitted vertex retains its two triangle neighbors, so the complement is2-dominating.

For the second residual profile, `t=h+2`, all high-degree vertices have pairwise distinct triangle counts, each at least2; both low counts0 and1 occur. This is a useful structural restriction.

## What does not follow

One cannot simply assert that a graph containing a triangle has one extra omitted vertex beyond the high-degree half bound: `K4` has `h=4` and `n−gamma2=2`, with no extra vertex. Nor can every prescribed degree-two triangle vertex be made good in a maximum cut. A degree-two vertex attached to the endpoints of one edge of `K3,3` is bad in every maximum cut: the remaining bipartite core forces those endpoints to opposite sides. These observations do not refute384b, since the corresponding triangle-count spectra have repeated values and lie outside the critical residual profiles.

## Other retained targets

No full proof or counterexample was obtained here for384b,382e, or389a. For382e, the source-faithful Maxine means the largest survivor count over all maximum-degree-deletion tie choices, not one deterministic labeling-dependent execution. A prior [bounded trial](https://github.com/Kuberwastaken/c5-k4/blob/main/results/expansion/method_v02_382e.md) already examined connected order-eight graphs and selected twin substitutions without finding a violation. For389a, the degree-at-most-two set in its correction must not be confused with the exactly-degree-two sets in392e/f and395a; the original quartile definition has an indexing convention requiring explicit handling before a claimed refutation.
