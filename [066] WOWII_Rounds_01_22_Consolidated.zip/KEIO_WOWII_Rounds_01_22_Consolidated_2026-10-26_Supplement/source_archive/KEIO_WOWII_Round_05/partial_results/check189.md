# Independent audit: WOWII 189 fractional-matching reduction

**Audit date:** 26 October 2026.  
**Verdict: the stated partial reduction is proved; no mathematical gap found.**
This is **not** a resolution of WOWII 189, does **not** increase the full-closure
count, and does **not** certify novelty or worldwide priority.

Audited note: `../../round_03/induced/189_fractional_matching_reduction.md`,
SHA-256 `907e75f70be0ed0c455c639a675c0bfff08ae0f8685f5ffd5c5235e5db27bbf3`.
Supporting source extracts and hashes are in `check189_sources.json`.

## Accepted statement

Let G be a finite connected simple graph on n > 1 vertices. Let s = d₂ be
the second entry of its nondecreasing degree sequence, and suppose
`|Even(v)| <= s+1` for every vertex v, including v in Even(v).

If an independent set I has `|N(I)| < |I|`, then
`|I| = s+1`, `|N(I)| = s`, and `n = 2s+1`. All but at most one member of I
are complete to N(I), and the note explicitly constructs a Hamiltonian path.
Consequently every nontraceable graph satisfying the hypothesis has a
perfect fractional matching, equivalently a spanning factor consisting of
single edges and odd cycles. Also `alpha(G) <= ceil(n/2)` for every graph
satisfying the hypothesis.

## Source fit

The preserved original row 189 in
`../../round_01/source_audit/baseline_candidate_rows.json` has hypothesis
`max dist_even(v) <= 1 + sigma(G)`, concludes a Hamiltonian path, and links
definitions 3, 10, 65, and 85. Its historical O label is not a new live-status
certification.

The archived author JavaScript is preserved in
`../../round_03/source_audit/archive_defs.txt`; its retrieval provenance is in
that directory's `definition_retrieval_log.json`:

* **Definition 65, line 413:** sigma is the second entry of the sorted degree
  sequence, not the second distinct degree. Multiplicity is retained.
* **Definition 10, line 358:** all vertices at even integer distance are
  counted, without excluding the starting vertex. Since `d(v,v)=0`, v is
  included. This also appears explicitly in the primary paper below.
* **Definition 85, line 433:** Hamiltonian path means visiting every vertex
  exactly once, agreeing with the construction in the audited note.

The [archived primary definition file](https://web.archive.org/web/20240512133636id_/http://cms.uhd.edu/faculty/delavinae/research/wowII/wowIIdefs.js)
therefore supports the exact conventions used. The archived source, not a
new successful access to the live UHD site, is the evidence used here.

## Mathematical review

1. **Degree bookkeeping.** Connectedness and n > 1 give s >= 1 and positive
   degree at every vertex. By the definition of the second-smallest degree,
   at most one vertex has degree below s. This remains correct for s = 1.

2. **Saturation lemma.** If A is an independent set of s+1 vertices in N(c),
   distinct vertices of A have distance exactly two, while each vertex has
   distance zero to itself. Thus A is contained in Even(a) for every a in A,
   and the hypothesis forces equality. If x,y are adjacent outside A and
   ax is an edge but ay is not, the length-two walk a,x,y makes y an
   even-distance vertex outside A, a contradiction. Hence adjacency to any
   fixed a propagates through each component of G-A. Every such component
   has some edge to A by connectedness. Therefore A dominates G. No
   diameter assumption or induced-subgraph assumption is hidden here.

3. **Small deficient sets.** I empty is not deficient. For |I| = 1,
   connectedness gives a nonempty neighborhood. For `2 <= |I| <= s`, at
   least one member has degree at least s, so `|N(I)| >= s >= |I|`.

4. **The exceptional size.** If `|I| = s+1` and I is deficient, at least s
   members have degree at least s. The inequalities force `|N(I)| = s`,
   and those s members are complete to N(I). The possible remaining member
   x has a neighbor c by connectedness, making c adjacent to all of I.
   Saturation applied to I makes I dominating, hence
   `V(G) = I disjoint-union N(I)`. Listing N(I) as c₁,...,cₛ with c₁
   adjacent to x and listing I-x as a₁,...,aₛ gives the path
   `x,c₁,a₁,c₂,a₂,...,cₛ,aₛ`. It visits all 2s+1 vertices exactly once.
   Edges inside N(I) are irrelevant. If no exceptional low-degree member
   exists, choosing any x works. The case s = 1 gives the same valid path.

5. **Larger independent sets.** If `t = |I| >= s+2`, no vertex has s+1
   neighbors in I: such a subset would be dominating by saturation, whereas
   any member of I outside the subset has no neighbor in it. Thus every
   vertex of N(I) has at most s neighbors in I. Because I is independent,
   every edge incident with I goes to N(I), and counting these edges gives
   `s|N(I)| >= sum(deg(a): a in I) >= s(t-1)+1 > s(t-1)`.
   Division by positive s and integrality imply `|N(I)| >= t`. This is a
   contradiction to deficiency. The positive-degree exceptional vertex is
   correctly included; dropping its contribution would lose the strict
   inequality.

6. **Hall reduction.** Suppose there is no deficient independent set. For
   arbitrary S, put `J = S minus N(S)`, with N(S) the union of all open
   neighborhoods. J is independent, and N(J) is disjoint from S. The
   disjoint sets `S intersect N(S)` and N(J) are both contained in N(S),
   so `|N(S)| >= |S intersect N(S)| + |N(J)| >= |S|`. This is precisely
   Hall's condition for the bipartite double cover. It is valid even when
   S itself is not independent.

7. **Factor extraction.** A perfect matching in the double cover gives a
   permutation whose arrows are graph edges and which has no fixed points.
   Its disjoint cycles cover all vertices. Two-cycles become single edges;
   each even cycle is replaced by alternating edges; odd cycles are kept.
   Weight 1 on each resulting single edge and weight 1/2 on each odd-cycle
   edge give incident weight exactly 1 at every vertex. These components
   are vertex-disjoint, so no compatibility issue occurs in this factor
   construction. Compatibility would matter for connecting them into one
   spanning path, which has not been proved.

8. **Independence-number consequence.** An independent set larger than
   `ceil(n/2)` has fewer neighbors than its size, because its neighborhood
   lies in its complement. The only deficient case above has size exactly
   `(n+1)/2 = ceil(n/2)`, so it cannot be such a set. In particular the
   search obstruction `|I| > |V-I|+1` is excluded without a bound on graph
   order or quotient-bag weights.

## Prior result and correct residual threshold

[Easwar and Johari, arXiv:2609.11719v1](https://arxiv.org/html/2609.11719v1)
was independently opened on the audit date. Its preliminary definitions
explicitly include v in Even(v). Theorem B proves traceability under any of
four alternatives: diameter at most two; n at most 2d₂+2; n = 2d₂+3 with
2-connectivity; or absence of 2-connectivity.

Taking their complement, a remaining counterexample must be **2-connected,
have diameter at least three, and satisfy `n >= 2d₂+4`**. The expression is
**linear in d₂, not quadratic**. These restrictions are attributed prior
results, not new results of the audited reduction. The [arXiv record](https://arxiv.org/abs/2609.11719)
showed version 1 dated 10 September 2026 at the time of this audit.

Neither checking this paper nor finding no occurrence of fractional-matching
terminology there establishes novelty of the present argument. No such
novelty conclusion is made.

## Computational replay

The supplied standard-library checker was rerun with:

```text
python3 wowii_rounds/round_03/induced/check189_reduction.py
```

Result: **PASS**, copied to `repeated189.json`.

| Guard statistic | Count |
| --- | ---: |
| Input graphs | 1,071 |
| Graphs satisfying the hypothesis | 369 |
| Independent sets checked in those graphs | 19,609 |
| Deficient sets / exceptional graphs | 56 / 56 |
| Nondeficient graphs with a double-cover perfect matching | 313 |
| Input graphs failing the hypothesis | 702 |

The generator contains the 995 connected graph-atlas entries of orders
2 through 7, 72 nearly complete bipartite exceptional-case controls, and
four clique blowups of C7; the largest guard has order 35. The rerun checks
the claimed sizes and path edges in each deficient case and constructs a
double-cover perfect matching otherwise. These are finite regression
guards, not an independent exhaustive proof for arbitrary graphs. The
mathematical audit above, not their pass count, supports the theorem.

## Exact remaining gap

There is **no identified gap in the partial theorem**. The unresolved step
for WOWII 189 is substantially stronger: a perfect fractional matching or
an edge/odd-cycle factor need not in general yield a Hamiltonian path.
The audited note has no proof that its factor components can always be
connected under the even-distance hypothesis. Thus the correct package
classification remains **validated partial research, zero full closures**.
