#!/usr/bin/env python3
"""Standard-library exact guards for the 189 independent-set theorem."""
from pathlib import Path
import collections,itertools,json,time

def bits(s):
 while s:
  b=s&-s;yield b.bit_length()-1;s-=b

def adj(n,edges):
 a=[0]*n
 for u,v in edges:a[u]|=1<<v;a[v]|=1<<u
 return a

def dist(a,s):
 d=[-1]*len(a);d[s]=0;q=collections.deque([s])
 while q:
  u=q.popleft()
  for v in bits(a[u]):
   if d[v]<0:d[v]=d[u]+1;q.append(v)
 return d

def independent_sets(a,available=None,chosen=0):
 if available is None:available=(1<<len(a))-1
 if not available:
  yield chosen;return
 v=(available&-available).bit_length()-1;R=available&~(1<<v)
 yield from independent_sets(a,R,chosen)
 yield from independent_sets(a,R&~a[v],chosen|1<<v)

def matching_double_cover(a):
 mate=[-1]*len(a)
 def dfs(v,seen):
  for u in bits(a[v]):
   if seen[u]:continue
   seen[u]=True
   if mate[u]<0 or dfs(mate[u],seen):mate[u]=v;return True
  return False
 for v in range(len(a)):
  if not dfs(v,[False]*len(a)):return None
 pi=[-1]*len(a)
 for right,left in enumerate(mate):pi[left]=right
 assert all(a[v]>>pi[v]&1 for v in range(len(a)))
 return pi

def main():
 rows=json.loads(Path(__file__).with_name('guard189_graphs.json').read_text());counts=collections.Counter();start=time.monotonic()
 for row in rows:
  a=adj(row['n'],row['edges']);n=len(a);degrees=sorted(x.bit_count() for x in a);s=degrees[1]
  dd=[dist(a,v) for v in range(n)];assert min(dd[0])>=0
  ev=[sum(x%2==0 for x in d) for d in dd]
  counts['graphs']+=1
  if max(ev)>s+1:counts['hypothesis_fails']+=1;continue
  counts['hypothesis_holds']+=1;deficient=0
  for I in independent_sets(a):
   counts['independent_sets_checked']+=1
   N=0
   for v in bits(I):N|=a[v]
   assert not(I&N)
   if N.bit_count()<I.bit_count():
    deficient+=1;counts['deficient_sets']+=1
    assert n==2*s+1 and I.bit_count()==s+1 and N.bit_count()==s
    low=[v for v in bits(I) if a[v]!=N];assert len(low)<=1
    x=low[0] if low else next(bits(I));c=next(bits(a[x]))
    C=[c]+[v for v in bits(N) if v!=c];A=[v for v in bits(I) if v!=x]
    path=[x]
    for u,v in zip(C,A):path += [u,v]
    assert len(path)==n and len(set(path))==n
    assert all(a[u]>>v&1 for u,v in zip(path,path[1:]))
  if deficient:counts['exceptional_graphs']+=1
  else:
   assert matching_double_cover(a) is not None
   counts['perfect_2_matching_graphs']+=1
 out=dict(status='PASS',counts=dict(counts),seconds=round(time.monotonic()-start,3),scope='finite guards, not proof or unrestricted conjecture resolution')
 Path(__file__).with_name('guard189_results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
