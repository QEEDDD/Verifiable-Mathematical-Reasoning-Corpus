#!/usr/bin/env python3
"""Finite checks of a384b reduction; NOT a proof of the open residual cases.
All connected labeled graphs of orders3 through6; no dependencies.
"""
from collections import Counter
from itertools import combinations
from pathlib import Path
import argparse,json

def bits(S):
    while S:
        b=S&-S;S^=b;yield b.bit_length()-1

def connected(adj):
    S=1
    while True:
        R=S
        for v in bits(S):R|=adj[v]
        if R==S:return S==(1<<len(adj))-1
        S=R

def gamma(adj):
    n=len(adj);best=n
    for D in range(1<<n):
        if D.bit_count()>=best:continue
        if all(D>>v&1 or (D&adj[v]).bit_count()>=2 for v in range(n)):best=D.bit_count()
    return best

def cut_certificate(adj):
    n=len(adj);S=0
    while True:
        flipped=False
        for v in range(n):
            same=(adj[v]&S).bit_count() if S>>v&1 else (adj[v]&~S).bit_count()
            if 2*same>adj[v].bit_count():S^=1<<v;flipped=True;break
        if not flipped:break
    H=sum(1<<v for v,a in enumerate(adj) if a.bit_count()>=3)
    R=max([H&S,H&~S],key=int.bit_count)
    D=((1<<n)-1)^R
    assert R.bit_count()>=(H.bit_count()+1)//2
    assert all(D>>v&1 or (D&adj[v]).bit_count()>=2 for v in range(n))
    return D.bit_count()

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path);args=p.parse_args()
    cnt=Counter();profiles=Counter();violations=[]
    for n in range(3,7):
        pairs=list(combinations(range(n),2))
        for E in range(1<<len(pairs)):
            adj=[0]*n
            for j,(u,v) in enumerate(pairs):
                if E>>j&1:adj[u]|=1<<v;adj[v]|=1<<u
            if not connected(adj):continue
            cnt[str(n)]+=1
            h=sum(a.bit_count()>=3 for a in adj)
            triangles=[sum((adj[v]&adj[w]).bit_count() for w in bits(adj[v]))//2 for v in range(n)]
            t=len(set(triangles));g=gamma(adj)
            assert t<=h+2
            assert g<=cut_certificate(adj)<=n-(h+1)//2
            residual=(t==h+2 or (t==h+1 and h%2==0))
            if residual:profiles[f'h={h},t={t}']+=1
            else:assert g<=n-(t+1)//2
            if h<=2:assert g<=n-(t+1)//2
            if g>n-(t+1)//2:violations.append(dict(n=n,edge_mask=E,h=h,t=t,gamma2=g))
    assert sum(cnt.values())==27474
    report=dict(result='PASS',meaning='Finite checks of the proven reduction, not a closure of384b',
                connected_labeled_counts=dict(cnt),residual_profiles=dict(profiles),
                conjecture_violations_in_checked_range=violations)
    out=json.dumps(report,indent=2)+'\n'
    if args.output:args.output.write_text(out)
    print(out)
if __name__=='__main__':main()
