# Round 06 source/status audit: WOWII 302

Checked 2026-10-26 UTC. **The proposed counterexample uses the original statement and invariant meanings. No surviving prior full resolution was located in the bounded search.** Mathematical proof and verification are separate in `../domination/` and `../independent_audit/`; this audit is not a global novelty certificate.

## Exact statement and conventions

The [archived original row](https://gitlab.com/ai-village-agents/village/graffiti-verification/-/blob/3be380b4222f974bedbefb228c8e75fbd9a7b3ae/data/wow2_rows_html.json), dated 1 March 2007, asserts for a simple connected graph of order greater than two:

`gamma_t(G) <= min_v dist_even(v) + |{x : lambda_complement(G)(x) = lambda_max(complement(G))}|`.

Its raw HTML displays the complement overline. The linked original definitions are 94, 10, 4, and 31. Their [primary archived definitions](https://web.archive.org/web/20240512133636id_/http://cms.uhd.edu/faculty/delavinae/research/wowII/wowIIdefs.js) specify total domination, count of even-distance vertices, neighborhood independence, and graph complement respectively. In particular:

* Distance zero is an even integer, so the counted vertices include v itself. No positive-distance restriction is present.
* Local independence at x is the independence number of its open neighborhood in the graph under discussion: here the complement.
* Frequency counts vertices attaining that maximum. It is not eigenvalue multiplicity.
* Every vertex, including each selected vertex, must have a selected neighbor in a total dominating set.

The exact row and selected definitions are in `statement_302.json`. The supplied baseline settles diameter at most two only; it does not establish the full statement.

## The earlier claimed disproof was explicitly withdrawn

The current [verification README](https://gitlab.com/ai-village-agents/village/graffiti-verification/-/blob/e4f890b23a62ed8086269e52afee684db86755b3/README.md), section 7hv, records a same-day retraction on **1 September 2026**. Its alleged counterexamples used the multiplicity of the complement's largest eigenvalue instead of local-independence frequency. The corrected values satisfy 302. The [ledger](https://gitlab.com/ai-village-agents/village/graffiti-verification/-/blob/e4f890b23a62ed8086269e52afee684db86755b3/verify/ledger.tsv) marks the exact target `retracted`. Therefore neither old announcements nor the withdrawn witness certify an earlier refutation. No later surviving 302 resolution was found in the checked README.

The public verification snapshot is commit `e4f890b23a62ed8086269e52afee684db86755b3`, committed 2026-10-23T16:39:59-07:00. The current checked Formal Conjectures directory, commit `039378b7951df701428aa5c6732a94a149a077e1` dated 2026-10-25T21:38:40Z, has no individual 302 file. File absence is not proof of openness.

## Neighboring theorem is not this conjecture

DeLaVina, Liu, Pepper, Waller, and West, [Some conjectures of Graffiti.pc on total domination](https://www.uhd.edu/documents/academics/sciences/total-dom-2007.pdf), Congressus Numerantium 185 (2007), 81–95, **Theorem 10**, explicitly resolves WOWII **301**. Its bound is `gamma_t <= omega(G)+|A|`, with the same complement-local-independence maximum set A. Replacing the clique-number term by the minimum even-distance count is exactly the distinct issue in 302. This paper is relevant earlier background, not a located resolution of 302.

Exact-number, local-independence, even-distance, frequency, and complement queries are preserved in `search_302.json`. They found the known retraction and neighboring statements, not an earlier correct full proof or counterexample for 302. The July public worklog supplies no 302 resolution. Historical O labels and negative searches remain limited evidence.

**Recommended wording:** “A counterexample to the original WOWII 302; no prior full resolution found in the checked sources as of 2026-10-26.”
