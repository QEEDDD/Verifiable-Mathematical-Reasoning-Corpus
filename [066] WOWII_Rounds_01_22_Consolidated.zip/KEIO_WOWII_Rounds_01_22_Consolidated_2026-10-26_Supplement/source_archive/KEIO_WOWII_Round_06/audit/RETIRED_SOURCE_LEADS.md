# Source-status corrections

Historical O/O* annotations and research-open tags were not accepted as proofs of current openness. Expanded checks located prior exact results for19,96,314,430a,438b,450 and reading-specific prior work on72. The newly examined404--407 have an earlier exact simultaneous resolution: Jonas J. Gebendorfer, 31 August2026, DOI10.5281/zenodo.22209538, The Corona of a Graph Is2-Dominating. These numbers are excluded from new-closure counts. No claim of a new result follows from rediscovering their standard exchange or matching arguments.

This record does not alter the present302 source-specific counterexample. The older public302 spectral refutation was retracted, and the valid2007Theorem10 proves the different301 clique-number bound. Remaining source-open records require further focused checks and are not certified globally open.
