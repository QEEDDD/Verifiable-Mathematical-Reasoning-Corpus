# Independent mathematical review of WOWII 302

The graph has a clique Q={a,b1,...,bq}, an anticomplete vertex v, pairs wi,ti with edges v-wi-a and wi-ti-bi, and vertices lij adjacent exactly to ti and bj. The parameter range q>=max(r,3),r>=2 is essential and is retained.

If some ti is absent from a total dominating set, every lij forces bj selected. The vertex v requires one wi selected, and that selected wi requires a neighbor in{v,a,ti}, outside all bj and wi. Thus this branch costs at least q+2. If all ti are selected, their open neighborhoods are pairwise disjoint and contain no ti, requiring r additional vertices. The two explicit sets in the manuscript attain q+2 and2r, respectively. Hence the exact optimum is min(2r,q+2).

All distances are at most three. The displayed even-distance formulas were checked by enumerating distance-two neighbors by type. For lij these are wi, the q clique vertices other than bj, its q-1 other row vertices, its r-1 other column vertices, and tj precisely when j<=r and j!=i. Adding the vertex itself gives2q+r plus the stated indicator. The other formulas follow in the same way. In particular v has count r+2 and uniquely minimizes it.

The source local independence in the complement equals the clique number in the original induced nonneighborhood. Q has order q+1>=4 and is the unique clique of that size. Every clique with a noncore vertex has at most three vertices. Only v is anticomplete to Q. Therefore the frequency of maximum complement local independence is exactly1; no spectral parameter is involved.

For q=2r-2,r>=4, the exact total domination is2r and the source RHS isr+3, a deficit r-3. The40-vertex member gives8>7. This family attains equality in the earlier valid bound gamma_t<=omega+f (WOWII301), so it does not refute that theorem.

A separately written exact neighborhood-hitting-set solver, independent clique enumeration, and all-pairs BFS rebuilt the examples with parameters(4,6),(4,7),(5,8),(6,10). All returned the exact formulas. The40-vertex independent dynamic program uses62 memoized uncovered-set states; this differs from the supplied branch-and-bound program's1700 nodes. Neither count is a claim of2^40 full subset enumeration. The written infinite-family proof is separate from the finite computations. No global minimal-order or worldwide-priority claim is made.
