import networkx as nx,itertools,json
from functools import lru_cache
out=[]
for r,s in [(4,6),(4,7),(5,8),(6,10)]:
 names=['a']+[f'b{j}' for j in range(s)]+['v']+[f'w{i}' for i in range(r)]+[f't{i}' for i in range(r)]+[f'l{i}_{j}' for i in range(r) for j in range(s)]
 G=nx.Graph();G.add_nodes_from(names);G.add_edges_from(itertools.combinations(names[:s+1],2))
 for i in range(r):
  G.add_edges_from([('v',f'w{i}'),('a',f'w{i}'),(f'w{i}',f't{i}'),(f't{i}',f'b{i}')])
  for j in range(s):G.add_edges_from([(f't{i}',f'l{i}_{j}'),(f'l{i}_{j}',f'b{j}')])
 ds=dict(nx.all_pairs_shortest_path_length(G));even={v:sum(d%2==0 for d in ds[v].values()) for v in G};N=set(G)
 local={}
 for v in G:
  R=G.subgraph(N-set(G[v])-{v});local[v]=max((len(c) for c in nx.find_cliques(R)),default=0)
 freq=sum(x==max(local.values()) for x in local.values())
 adj=[sum(1<<names.index(v) for v in G[u]) for u in names];n=len(G);full=(1<<n)-1
 @lru_cache(None)
 def solve(U):
  if not U:return 0
  u=min((i for i in range(n) if U>>i&1),key=lambda i:adj[i].bit_count())
  return 1+min(solve(U&~adj[v]) for v in range(n) if adj[u]>>v&1)
 gamma=solve(full)
 witness=[f't{i}' for i in range(r)]+['b0']+[f'w{i}' for i in range(1,r)]
 assert all(set(G[v])&set(witness) for v in G)
 assert gamma==min(2*r,s+2) and even['v']==r+2 and freq==1 and min(even.values())+freq<gamma
 out.append({'r':r,'s':s,'n':n,'m':G.number_of_edges(),'gamma_t_exact_hitting_set':gamma,'minimum_even_count':min(even.values()),'even_at_v':even['v'],'complement_max_local_independence':max(local.values()),'frequency':freq,'frequency_attainers':[v for v in G if local[v]==max(local.values())],'RHS':min(even.values())+freq,'defect':gamma-min(even.values())-freq,'states':solve.cache_info().currsize,'witness':witness})
print(json.dumps({'status':'PASS','examples':out},indent=2))
