#!/usr/bin/env python3
"""Exact standard-library verifier for the WOWII 302 counterexample family."""
from collections import deque
from fractions import Fraction
import json,sys

def build(s,q=None):
    if q is None:q=2*s-2
    assert s>=2 and q>=max(s,3)
    names=['v','a']+[f'b{j}' for j in range(1,q+1)]
    names += [f'w{i}' for i in range(1,s+1)]+[f't{i}' for i in range(1,s+1)]
    names += [f'l{i}_{j}' for i in range(1,s+1) for j in range(1,q+1)]
    ix={x:i for i,x in enumerate(names)};n=len(names);adj=[set() for _ in names]
    def edge(x,y):x,y=ix[x],ix[y];adj[x].add(y);adj[y].add(x)
    Q=['a']+[f'b{j}' for j in range(1,q+1)]
    for i,x in enumerate(Q):
        for y in Q[:i]:edge(x,y)
    for i in range(1,s+1):
        for x,y in [('v',f'w{i}'),('a',f'w{i}'),(f'w{i}',f't{i}'),(f't{i}',f'b{i}')]:edge(x,y)
        for j in range(1,q+1):
            edge(f'l{i}_{j}',f't{i}');edge(f'l{i}_{j}',f'b{j}')
    return names,ix,adj

def clique_number(masks,vs):
    best=0
    def rec(P,k):
        nonlocal best
        if k+P.bit_count()<=best:return
        while P:
            if k+P.bit_count()<=best:return
            bit=P&-P;P^=bit;v=bit.bit_length()-1
            rec(P&masks[v],k+1)
        best=max(best,k)
    rec(vs,0);return best

def minimum_total_domination(masks,upper):
    n=len(masks);allv=(1<<n)-1;best=upper;nodes=0
    def dfs(covered,available,size):
        nonlocal best,nodes
        nodes+=1
        if size>=best:return
        if covered==allv:best=size;return
        uncovered=allv^covered;choices=0;cnt=n+1
        while uncovered:
            bit=uncovered&-uncovered;uncovered^=bit;v=bit.bit_length()-1
            c=masks[v]&available;k=c.bit_count()
            if k==0:return
            if k<cnt:cnt=k;choices=c
            if k==1:break
        order=[]
        while choices:
            bit=choices&-choices;choices^=bit;v=bit.bit_length()-1
            order.append((-(masks[v]&~covered).bit_count(),v))
        order.sort()
        for _,v in order:
            bit=1<<v
            dfs(covered|masks[v],available^bit,size+1)
            available^=bit
    dfs(0,allv,0);return best,nodes

def inspect(s=4,q=None):
    if q is None:q=2*s-2
    names,ix,adj=build(s,q);n=len(names);allv=(1<<n)-1
    masks=[sum(1<<j for j in a) for a in adj]
    even=[];distances=[]
    for v in range(n):
        d=[-1]*n;d[v]=0;qu=deque([v])
        while qu:
            x=qu.popleft()
            for y in adj[x]:
                if d[y]<0:d[y]=d[x]+1;qu.append(y)
        assert -1 not in d
        distances.append(d);even.append(sum(x%2==0 for x in d))
    local=[clique_number(masks,allv^masks[v]^(1<<v)) for v in range(n)]
    k=max(local);att=[names[v] for v in range(n) if local[v]==k]
    witness=[ix[f't{i}'] for i in range(1,s+1)]+[ix['b1']]+[ix[f'w{i}']for i in range(2,s+1)]
    if q+2<len(witness):witness=[ix[f'b{j}']for j in range(1,q+1)]+[ix['a'],ix['w1']]
    union=0
    for x in witness:union|=masks[x]
    assert union==allv
    gamma,nodes=minimum_total_domination(masks,len(witness))
    assert even[ix['v']]==s+2
    assert even[ix['a']]==s*q+s+2
    for i in range(1,s+1):
        assert even[ix[f'w{i}']]==2*q+s
        assert even[ix[f't{i}']]==q+s+1
        for j in range(1,q+1):
            assert even[ix[f'l{i}_{j}']]==2*q+s+int(j<=s and j!=i)
    for j in range(1,q+1):assert even[ix[f'b{j}']]==s*q+s+1-int(j<=s)
    assert min(even)==s+2 and [names[i]for i in range(n)if even[i]==min(even)]==['v']
    assert k==q+1 and att==['v']
    assert gamma==min(2*s,q+2)
    # Independently verify the structural lower-bound certificates.
    target_neighborhoods=[masks[ix[f't{i}']] for i in range(1,s+1)]
    assert all(not target_neighborhoods[i]&target_neighborhoods[j] for i in range(s)for j in range(i))
    assert all(not (target_neighborhoods[i]>>ix[f't{j}']&1) for i in range(s)for j in range(1,s+1))
    for i in range(1,s+1):
        for j in range(1,q+1):
            assert adj[ix[f'l{i}_{j}']]=={ix[f't{i}'],ix[f'b{j}']}
    return {'s':s,'q':q,'order':n,'size':sum(map(len,adj))//2,'connected':True,
            'gamma_t':gamma,'TDS':[names[x]for x in witness],
            'total_domination_search_nodes':nodes,'even_distance_min':min(even),
            'even_distance_minimizers':[names[x]for x in range(n)if even[x]==min(even)],
            'even_distance_at_v':even[ix['v']],
            'vertices_even_distance_from_v':[names[x]for x in range(n)if distances[ix['v']][x]%2==0],
            'max_local_independence_complement':k,'attaining_vertices':att,'frequency':len(att),
            'source_RHS':min(even)+len(att),'deficit':gamma-min(even)-len(att),
            'WOWII302_violated':gamma>min(even)+len(att)}

if __name__=='__main__':
    s=int(sys.argv[1])if len(sys.argv)>1 else 4
    q=int(sys.argv[2])if len(sys.argv)>2 else None
    print(json.dumps(inspect(s,q),indent=2))
