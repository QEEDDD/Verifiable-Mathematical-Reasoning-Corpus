# Source reading and conventions

The original row 389a asserts, for a connected graph on $n>2$ vertices, $$\label{eq:conj}
\gamma_2(G)\leq |M|(q+|A_2|)-1,$$ where $A_2$ here means the set of vertices of degree *at most* two, $M$ is the vertex class of mode-min degree, and $q$ is the first-quartile degree. This $A_2$ differs from the exactly-degree-two notation used in 392e, 392f, and 395a. We write $a=|A_2|$ and $f=|M|$. Since all modal classes have the same size, $f$ is simply the largest degree frequency.

The original JavaScript definition 96 orders the degrees nondecreasingly and specifies the degree with index $n/4$; it does not state how to round that index when $4$ does not divide $n$. We therefore make our hypotheses explicit rather than infer an unrecorded rounding rule. For $n\geq4$, the results below apply to every positive integer $q$ for which at least $\lfloor n/4\rfloor$ vertices have degree at most $q$. In particular they apply to either the lower or upper rank interpretation, and to the literal source definition when $4\mid n$. The strongest case is the lower-rank choice $d_{\lfloor n/4\rfloor}$. The $n=3$ graphs satisfy the original inequality directly under any positive degree choice.

Since the graph is connected, its degrees lie in $\{1,\ldots,n-1\}$. Thus $f\geq2$ by the pigeonhole principle, and $a\leq2f$. For $q\geq3$, the quartile condition implies $$\label{eq:rank}
\lfloor n/4\rfloor\leq a+f(q-2),\qquad
n\leq4a+4f(q-2)+3.$$

# Two elementary bounds

::: {#lem:cut .lemma}
**Lemma 1** (High-degree cut bound). *For every graph with $a$ vertices of degree at most two, $$\gamma_2(G)\leq\left\lfloor\frac{n+a}{2}\right\rfloor.$$*
:::

::: proof
*Proof.* Take a cut locally maximal under single-vertex flips. Every vertex of degree at least three has at least two crossing neighbors. One side contains at least $\lceil(n-a)/2\rceil$ such high-degree vertices. Omit exactly those vertices and select every other vertex. Each omitted vertex has at least two selected crossing neighbors, giving the stated bound. ◻
:::

::: {#lem:random .lemma}
**Lemma 2** (Frequency-sensitive alteration bound). *For every graph without isolated vertices, with $a$ vertices of degree at most two and maximum degree frequency $f$, and every $0<p<1$, $$\label{eq:prob-general}
\gamma_2(G)\leq pn+(1-p)a+
 f(1-p)^3\left(1+\frac2p\right).$$ In particular, $$\label{eq:prob-six}
\gamma_2(G)\leq\frac n6+\frac{5a}{6}+\frac{1625f}{216}.$$*
:::

::: proof
*Proof.* Select each vertex independently with probability $p$, obtaining a set $S$. Then add every vertex outside $S$ that has fewer than two neighbors in $S$. The resulting set is 2-dominating. Write $z=1-p$. A vertex of degree $d$ is added with probability $$z^{d+1}+dpz^d.$$ For degree one this equals $z$, and for degree two it is $z^2(1+p)\leq z$. There are at most $f$ vertices of each degree $d\geq3$. Hence the expected size of the final set is at most $$pn+za+f\sum_{d=3}^{\infty}\bigl(z^{d+1}+dpz^d\bigr).$$ The convergent geometric-series calculation gives $$\sum_{d=3}^{\infty}\bigl(z^{d+1}+dpz^d\bigr)
=3z^3+\frac{2z^4}{p}=z^3\left(1+\frac2p\right).$$ Some outcome has size at most its expectation, proving [\[eq:prob-general\]](#eq:prob-general){reference-type="eqref" reference="eq:prob-general"}. Taking $p=1/6$ yields [\[eq:prob-six\]](#eq:prob-six){reference-type="eqref" reference="eq:prob-six"}. ◻
:::

These arguments are elementary versions of standard cut and probabilistic alteration methods. No novelty is claimed for the methods themselves.

# Explicit sufficient conditions

::: {#thm:criteria .theorem}
**Theorem 1**. *Assume $q\geq3$. The original inequality [\[eq:conj\]](#eq:conj){reference-type="eqref" reference="eq:conj"} holds if either $$\begin{aligned}
f(a+4-q)&>\frac{5a+3}{2},\label{eq:C}\\
f\left(\frac q3-\frac{1337}{216}\right)
+a\left(f-\frac32\right)&>\frac12.\label{eq:P}
\end{aligned}$$*
:::

::: proof
*Proof.* By Lemma [1](#lem:cut){reference-type="ref" reference="lem:cut"} and [\[eq:rank\]](#eq:rank){reference-type="eqref" reference="eq:rank"}, $$\gamma_2(G)\leq\frac{5a+4f(q-2)+3}{2}.$$ Under [\[eq:C\]](#eq:C){reference-type="eqref" reference="eq:C"}, this is strictly less than the integer $f(q+a)$. Since $\gamma_2(G)$ is an integer, [\[eq:conj\]](#eq:conj){reference-type="eqref" reference="eq:conj"} follows.

Similarly, Lemma [2](#lem:random){reference-type="ref" reference="lem:random"} and [\[eq:rank\]](#eq:rank){reference-type="eqref" reference="eq:rank"} give $$\label{eq:prob-rank}
\gamma_2(G)\leq\frac{2fq}{3}+\frac{3a}{2}
 +\frac{1337f}{216}+\frac12.$$ Condition [\[eq:P\]](#eq:P){reference-type="eqref" reference="eq:P"} says precisely that this upper bound is strictly less than $f(q+a)$, so integrality again gives [\[eq:conj\]](#eq:conj){reference-type="eqref" reference="eq:conj"}. ◻
:::

::: {#cor:largeq .corollary}
**Corollary 1**. *The original inequality holds whenever $q\geq20$.*
:::

::: proof
*Proof.* The left side of [\[eq:P\]](#eq:P){reference-type="eqref" reference="eq:P"} minus $1/2$ is $$f\left(\frac q3-\frac{1337}{216}\right)
+a\left(f-\frac32\right)-\frac12.$$ For $q\geq20$, $f\geq2$, and $a\geq0$, this is at least $$2\left(\frac{20}{3}-\frac{1337}{216}\right)-\frac12
=\frac{49}{108}>0.$$ ◻
:::

::: {#cor:a .corollary}
**Corollary 2**. *The original inequality holds whenever $a\geq7$.*
:::

::: proof
*Proof.* First suppose $q\geq3$. Since $a\leq2f$, we have $f\geq4$. Criterion [\[eq:C\]](#eq:C){reference-type="eqref" reference="eq:C"} is equivalent to $q<U$, where $$U=a+4-\frac{5a+3}{2f},$$ and [\[eq:P\]](#eq:P){reference-type="eqref" reference="eq:P"} is equivalent to $q>L$, where $$L=\frac{1337}{72}-3a+\frac{9a+3}{2f}.$$ Their overlap satisfies $$U-L=4a-\frac{1049}{72}-\frac{7a+3}{f}
\geq 28-\frac{1049}{72}-13=\frac{31}{72}>0.$$ The inequality follows by monotonicity for $a\geq7,f\geq4$: the expression increases with $f$, and at fixed $f\geq4$ its coefficient of $a$ is $4-7/f>0$. Thus every real $q$ satisfies $q<U$ or $q>L$.

For $q=2$, the separate argument in Corollary [3](#cor:smallq){reference-type="ref" reference="cor:smallq"} below applies. For $q=1$, let $\ell$ be the number of leaves. The quartile condition implies $n\leq4\ell+3$, and $f\geq\ell$. A connected graph with $n>2$ has a degree-at-least-two vertex, which can be omitted, so $\gamma_2\leq n-1\leq4\ell+2$. Since $a\geq7$ and $\ell\geq1$, $$f(a+1)-1\geq\ell(a+1)-1\geq4\ell+2.$$ This proves the result also for $q=1$. ◻
:::

::: {#cor:smallq .corollary}
**Corollary 3**. *The original inequality holds for every case $q=2$, and for $q=3$ with $f\geq3$ (also for $q=3,f=2,a=0$).*
:::

::: proof
*Proof.* If $q=2$, then $n\leq4a+3$, and Lemma [1](#lem:cut){reference-type="ref" reference="lem:cut"} gives $\gamma_2\leq\lfloor(5a+3)/2\rfloor$. For $a=1,2,3,4$, this upper bound is respectively $4,6,9,11$, whereas $f(a+2)-1\geq2(a+2)-1$ is respectively $5,7,9,11$. For $a\geq5$, use $f\geq a/2$ and $$\frac{a(a+2)}2-1-\frac{5a+3}2
=\frac{a^2-3a-5}{2}>0.$$ The quartile hypothesis ensures $a\geq1$ when $n\geq4$.

For $q=3$, criterion [\[eq:C\]](#eq:C){reference-type="eqref" reference="eq:C"} reduces to $f(a+1)>(5a+3)/2$, which holds for $f\geq3$ and $a\geq0$, and also for $f=2,a=0$. ◻
:::

# What remains unresolved

Within the stated integer-quartile convention, any counterexample must have $a\leq6$ and $q\leq19$, avoid the cases proved above, and fail both criteria whenever $q\geq3$. This is a reduction, not a resolution. For $q\geq3$, the failures can be written $$f(a+4-q)\leq\frac{5a+3}{2},\qquad
f\left(a+\frac q3-\frac{1337}{216}\right)
\leq\frac{3a+1}{2}.$$ If either coefficient of $f$ is positive, these give a finite upper bound on $f$, and [\[eq:rank\]](#eq:rank){reference-type="eqref" reference="eq:rank"} then bounds $n$. Both coefficients can be nonpositive only in the following ranges: $$\begin{array}{c|c}
a&\text{possibly unbounded-frequency range}\\\hline
0&4\leq q\leq18\\
1&5\leq q\leq15\\
2&6\leq q\leq12\\
3&7\leq q\leq9.
\end{array}$$ All other surviving parameter profiles have explicit finite bounds. This observation does not constitute an exhaustive graph search in those profiles. In particular, no claim is made that their graphical realizations have been fully tested.

The attached `check_389a_parameters.py` uses exact rational arithmetic to verify the algebra on a stated parameter grid and produce these residual profiles. It tests inequalities between parameters, not all graphs realizing them. The proofs above establish the universal partial results.

#### Primary sources.

The original 389a row is preserved at [the pinned HTML archive](https://gitlab.com/ai-village-agents/village/graffiti-verification/-/blob/3be380b4222f974bedbefb228c8e75fbd9a7b3ae/data/wow2_rows_html.json). Definitions 45 (mode), 90 (2-domination), and 96 (quartile) were checked in the recovered original `wowIIdefs.js`, preserved in the 12 May 2024 Wayback snapshot. Their exact source text is included in the accompanying source-reading file. The source's missing nonintegral-rank rounding convention is retained as a qualification, not silently repaired. No full resolution or worldwide-priority claim is made in this note.
