# Mathematical review of the partial degree-quartile reduction

The proof is accepted under its explicit integer-rank hypothesis: q is a positive integer and at least floor(n/4) vertices have degree at most q. This includes either lower or upper rank interpretation and the literal original when n is divisible by4. The source does not fix nonintegral-rank rounding. No claim is made for an unstated interpolation convention.

The maximum-cut construction yields gamma2<=floor((n+a)/2). The probabilistic alteration is valid: selecting each vertex with probability p, then adding every unselected vertex with fewer than two selected neighbors, produces a2-dominating set. With z=1-p, the added-vertex probability at degree d is z^(d+1)+d*p*z^d. The sum over d>=3 equals z^3*(1+2/p). Since each degree occurs at most f times, the stated expectation bound follows; degree1 and2 contributions are bounded by z per vertex. Substituting p=1/6 gives1625f/216.

For q>=3, the rank condition yields n<=4a+4f(q-2)+3. Substitution into the cut and probabilistic bounds gives exactly the two stated strict sufficient criteria. Since f(q+a) is an integer, strict inequality implies the conjecture's minus-one bound; no rounding step is missing.

For q>=20, the worst-case probability criterion at f=2,a=0 equals49/108>0 after subtracting1/2. For a>=7 and q>=3, the two real q intervals overlap: their gap is4a-1049/72-(7a+3)/f, at least31/72 for a>=7,f>=4, with monotonicity as written. The q1 and q2 cases are separately justified; q3,f>=3 also follows from the cut criterion. The n3 boundary can be checked directly.

The remaining parameter profiles with unbounded possible f are computed from both nonpositive coefficients and are exactly those listed. This does not exclude graphical realizations in the residual ranges. The supplied exact-rational parameter program was rerun; its checks concern parameter inequalities, not exhaustive graph search. The result is a partial theorem, not a full resolution or a priority claim.
