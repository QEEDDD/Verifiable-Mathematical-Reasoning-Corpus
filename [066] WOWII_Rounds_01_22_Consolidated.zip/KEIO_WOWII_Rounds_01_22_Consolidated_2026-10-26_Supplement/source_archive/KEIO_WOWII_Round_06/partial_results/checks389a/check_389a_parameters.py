#!/usr/bin/env python3
"""Exact parameter checks for a partial389a theorem, not graph exhaustion."""
from fractions import Fraction as F
from pathlib import Path
import argparse,json

def cut(a,f,q):return f*(a+4-q)>F(5*a+3,2)
def prob(a,f,q):return f*(F(q,3)-F(1337,216))+a*(f-F(3,2))>F(1,2)

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path);args=p.parse_args()
    checked=0
    for f in range(2,101):
        for a in range(2*f+1):
            for q in range(3,61):
                checked+=1
                nmax=4*a+4*f*(q-2)+3
                Ucut=F(nmax+a,2)
                Uprob=F(nmax,6)+F(5*a,6)+F(1625*f,216)
                assert cut(a,f,q)==(Ucut<f*(q+a))
                assert prob(a,f,q)==(Uprob<f*(q+a))
                if q>=20:assert prob(a,f,q)
                if a>=7:assert cut(a,f,q) or prob(a,f,q)
                if q==3 and f>=3:assert cut(a,f,q)
    assert 2*(F(20,3)-F(1337,216))-F(1,2)==F(49,108)
    assert 28-F(1049,72)-F(52,4)==F(31,72)
    residual=[];unbounded=[];maxfinite_n=0
    for a in range(7):
        for q in range(3,20):
            fmin=max(2,(a+1)//2)
            limits=[]
            c=a+4-q
            if c>0:limits.append(F(5*a+3,2*c))
            c=F(a)+F(q,3)-F(1337,216)
            if c>0:limits.append(F(3*a+1,2)/c)
            if not limits:
                unbounded.append(dict(a=a,q=q,minimum_frequency=fmin))
                continue
            lim=min(limits);fmax=lim.numerator//lim.denominator
            if fmax>=fmin:
                nmax=4*a+4*fmax*(q-2)+3
                residual.append(dict(a=a,q=q,minimum_frequency=fmin,maximum_frequency=fmax,order_upper_bound=nmax))
                maxfinite_n=max(maxfinite_n,nmax)
    groups={str(a):[x['q'] for x in unbounded if x['a']==a] for a in range(4)}
    assert groups=={'0':list(range(4,19)),'1':list(range(5,16)),'2':list(range(6,13)),'3':list(range(7,10))}
    out=dict(result='PASS',status='PARTIAL_ONLY_NO_CLOSED_CONJECTURE',parameter_triples_checked=checked,
             grid=dict(f=[2,100],a='0 through2f',q=[3,60]),
             proved_regions=['q>=20','a>=7','q=2','q=3 andf>=3','either explicit criterion'],
             exact_minimum_largeq_gap='49/108',exact_minimum_largea_threshold_overlap='31/72',
             unbounded_frequency_residual_groups=groups,finite_frequency_residual_profiles=residual,
             maximum_order_bound_among_finite_profiles=maxfinite_n,
             warning='This checks algebraic parameter profiles, not all graphs. The remaining profiles are not claimed resolved.')
    s=json.dumps(out,indent=2)+'\n'
    if args.output:args.output.write_text(s)
    print(s)
if __name__=='__main__':main()
