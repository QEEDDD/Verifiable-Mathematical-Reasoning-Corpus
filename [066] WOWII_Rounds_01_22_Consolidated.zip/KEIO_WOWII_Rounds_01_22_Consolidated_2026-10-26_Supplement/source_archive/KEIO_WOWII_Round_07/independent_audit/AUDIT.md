# Independent mathematical audit: WOWII 298 and the prescribed 4k-cycle theorem

**Verdict: PASS. No mathematical gap found in the candidate or its required prior proof chain.**

The argument establishes, in ordinary mathematical proof, that every finite
simple connected graph containing a cycle of length divisible by four satisfies
`gamma_t(G) <= a(G)`. With the independently audited prior global bound, it
establishes the stated four-cycle-indicator inequality. This verdict is not
conditional on an unproved conjecture, an unaudited AI-generated assertion, a
finite enumeration, or an external Lean certificate. It uses one standard
classical theorem: the Chvatal--McDiarmid 3-uniform transversal bound.

This is a separate-agent mathematical audit and independent finite
verification, not peer-review acceptance, proof-assistant verification, or
worldwide priority certification. The exact catalogue/source-priority audit is
being handled separately; this report does not duplicate or certify it.

## Evidence and scope

- Candidate `round_08/domination/proof298.md`, frozen as
  `audited_candidate_snapshot.md`.
- Its publication source `round_08/domination/proof298.tex`, read in full and
  frozen as `audited_publication_snapshot.tex`.
- Gebendorfer's complete six-page manuscript text and PDF, frozen as
  `audited_prior_paper.txt` and `audited_prior_paper.pdf`. All required proofs
  were read, not merely their statements: Lemmas 2, 3, 7, 8, Proposition 4,
  Corollary 5 and Theorem 9. Proposition 6 was also checked, though it is not
  needed for the conclusion. PDF pages 2--5 were rendered and visually checked.
- The classical theorem's precise statement and multiset convention were
  checked in Section 1 of Henning--Lowenstein,
  [arXiv:1401.4851v1](https://arxiv.org/html/1401.4851v1).
  The original Chvatal--McDiarmid article's authors, title, journal, year, pages,
  and DOI were verified at its
  [publisher record](https://link.springer.com/article/10.1007/BF01191201).
  That publisher page offers the original full article only as subscription
  content; this audit does not claim to have read its full 1992 proof. The exact
  standard theorem needed here is openly and explicitly stated in the cited
  research paper, so this does not leave a missing hypothesis or uncertain
  mathematical dependency.
- The candidate's Python coloring checker and C++ exact graph checker were
  inspected. The Python checker was rerun; the C++ 2,093,730-instance run was
  not independently rerun by this auditor. A separate checker written for this
  audit imports neither candidate checker nor the prior manuscript's checker.

The auditor wrote only within this audit directory. Source manuscript files
were not edited. Snapshot and program hashes appear in the JSON results and
`SHA256SUMS`.

## A. New deduction

### A1. Annihilation transfer

**Valid, with the correct inequality direction.** Let `m=|E(G)|`,
`H=G-uv`, and choose an optimum-cardinality annihilation set A of H. Restoring
one edge raises its degree sum by at most two. The only problematic case is
therefore a degree sum exactly `m+1`, with both u and v in A. It is important
that the budget of H was `m-1`, not m; the proof handles this correctly.

At cutoff two, the first `a(G)+1` degrees lie in `L_2={x:d_G(x)<=2}` and their
sum is an integer greater than m. Hence `sum(d_G(x):x in L_2)>=m+1`.
If A contained all of L_2 as well as its degree-at-least-three vertex v, its
sum would be at least `m+4`, a contradiction. A missing low-degree vertex w
exists, and replacement of v by w preserves cardinality and reduces the sum
by at least one. Thus `a(H)<=a(G)`. No optimum-degree ordering of A, no
connectivity of H for this lemma, and no assumed monotonicity of annihilation
under arbitrary edge deletion is being smuggled into this argument.

### A2. Unicyclic incidence coloring

**Valid, including domination of selected supports and selected variables.**
Put `Q=V\S`, `U=V\N(S)`, with N an open-neighborhood union. If `u in U`,
then it has no support neighbor, all its neighbors lie in Q, and it cannot
be a leaf. Its incidence row therefore has degree at least two. Row and
variable copies of the same original vertex are distinct; the construction
does not identify them.

A connected unicyclic graph with an even cycle is bipartite. The full
row-variable neighborhood graph splits into the two graphs on `(rows X,
variables Y)` and `(rows Y, variables X)`, each isomorphic to the original
graph. Restricting rows and variables cannot create a cycle. Each component
of the restricted graph is consequently a tree or unicyclic, and any
surviving cycle has exactly the original length 4k.

Every nonempty tree component has a variable vertex, since row degrees are
at least two. Rooting at a variable makes each row have a parent variable and
at least one child variable. Giving one child the opposite color satisfies
that row without revisiting a previously colored child. An isolated variable
is harmless. In a cyclic component, exactly 2k cycle vertices are variables;
alternating their colors closes consistently precisely because 2k is even.
Each cycle row already sees both colors. Rooting each off-cycle branch at
its cycle attachment reduces the extension to the tree rule. There are no
multiple attachment conflicts in a unicyclic component.

For each color i, `S union Q_i` dominates every vertex of N(S) via S and
every vertex of its complement U via a color-i neighbor. These two domains
partition the entire vertex set, not merely its unselected vertices. Thus
this is total domination, not just ordinary domination. The two costs sum
to `2|S|+|Q|=n+|S|`; their minimum is at most its half rounded down. Distinct
supports have disjoint nonempty leaf-neighbor sets, so `|S|<=l`.

The proof still works when S is empty (the pure cycle case), when supports
are adjacent, when the incidence graph has two cyclic components, and when
some variables are isolated in the restricted incidence graph. The text
correctly credits the tree part to the prior manuscript; only its indicated
unicyclic extension is being used as the additional deduction.

### A3. Low-cutoff unicyclic completion

**Valid.** A connected graph of order at least three has distinct leaf edges,
so `l<=m` and the set of all leaves is affordable. Therefore cutoff one is
impossible. At cutoff two, both the first a and the first a+1 degrees consist
of all l ones followed by twos. The defining inequalities are

`2a-l <= m < 2(a+1)-l`,

which give exactly `a=floor((m+l)/2)`, rather than just one side of that
identity. For a unicyclic graph m=n; the coloring bound now gives `gamma_t<=a`.
The high-cutoff case is supplied by the prior result audited in Part B.

### A4. A removable edge outside an arbitrary prescribed cycle

**Valid.** A connected graph with a cycle C that is not unicyclic has some
different cycle C'. Two different simple cycles cannot have the same edge
set, so C' has an edge outside C.

If C' meets C, traverse it starting at an intersection and use the first
edge not belonging to C. Its tail is a vertex of C. This remains true if
the two cycles meet only in vertices and share no edge. The two C-edges and
this third edge are distinct, so the tail has degree at least three. If C'
is disjoint from C, take a shortest path between the two vertex sets; its
endpoint on C' has a neighbor outside C', hence degree at least three. Any
incident C'-edge at that endpoint is outside C. In either case the selected
edge belongs to C', and hence is nonbridge.

The candidate's wording about an appropriate boundary is adequate. Using
"the first edge outside C" and "a shortest path between the cycles" makes
the same argument especially explicit, but no repair is needed.

### A5. Minimal-counterexample conclusion

**Valid.** A nonempty family of finite counterexamples has a member of
minimum edge count. Fix a 4k-cycle in that member. Its order is at least
four. The audited high-cutoff theorem and the affordable-leaf argument force
cutoff two. The unicyclic corollary excludes cyclomatic number one. The
removable-edge lemma supplies an edge outside the fixed cycle, so H=G-e is
still connected and retains exactly the witness needed for minimality.

No assumption about the cutoff of H is required. Minimality applies to all
graphs with the prescribed property, not just low-cutoff ones. Total
domination is monotone in the correct direction upon restoring edges; the
annihilation transfer gives the other required comparison. Consequently

`gamma_t(G) <= gamma_t(H) <= a(H) <= a(G)`.

For the final indicator target, a four-cycle need only be a subgraph. The
proof does not accidentally assume it is induced. The complementary branch
uses the already proved global `a+1` result, not a new assertion of that
global theorem. The TeX sharpness remarks for `C_(4k)` and `C_(4k+2)` are
correct for simple cycles (k>=1).

## B. Audit of the needed prior proof, not just its citation

### B1. Classical 3-uniform bound and repeated edges

The exact input is `4 tau(H) <= n_H+m_H`. The cited open research paper
defines its edge collection as a finite multiset and explicitly gives the
k=3 specialization. Even if one starts with a simple-hypergraph formulation,
the multiset case follows by deleting duplicate edges: tau is unchanged and
the right side can only decrease before duplicates are restored. Isolated
vertices are harmless. Thus there is no hidden simplicity, connectivity,
linearity, or minimum-degree hypothesis in the required invocation.

### B2. Mixed edge-size bound (prior Lemma 2)

**Valid.** Minimize the nonnegative integer
`Phi=2n+4e_1+2e_2+e_3`. Isolated vertices can be removed. Selecting v and
removing its incident edges lowers Phi by at least six whenever
`4d_1(v)+2d_2(v)+d_3(v)>=4`, with transversal cost at most one. A minimum
counterexample therefore has no 1-edge, at most one 2-edge at a vertex,
and at most one 3-edge at any vertex incident with a 2-edge.

For a 2-edge uv, if neither endpoint has a 3-edge, delete both endpoints
and uv after selecting one endpoint: potential decrease six. Otherwise
select u lying on a 3-edge f, delete u, uv and f: decrease five. If v
becomes isolated, deleting it raises the decrease to seven. Otherwise v
lies in exactly one remaining 3-edge g, different from f. Remove v from g
and from the vertex set. Since v occurs in no other edge, this shrinking
preserves tau: a selected v can be exchanged for any other vertex of g.
Its additional potential decrease is one, making the total six. The lift
with selected u hits every removed edge and every shrunken edge correctly.

With 2-edges excluded, the hypergraph is 3-uniform of maximum degree at
most three, so `m<=n`. The standard bound gives

`6 tau <= (3/2)(n+m) <= 2n+m=Phi`.

The PDF visibly contains the factor **3/2**. The plain-text extraction's
merged fraction is not a mathematical error. The last inequality is exactly
equivalent to m<=n. Every reduction lowers Phi and retains nonempty edges.

### B3. Annihilation budget (prior Lemma 3)

**Valid.** At cutoff at least three, all degree-one and degree-two vertices
are in the affordable prefix, so `l+2b<=m`. For the r high-degree vertices
with degree sum E, `E>=l+2b` and `E>=3r>0`. Thus

`t=floor(r/2-r(l+2b)/(2E))`

is a valid integer between zero and r. The t smallest high degrees sum to
at most t times their overall average E/r. Adjoining them to all low-degree
vertices gives sum at most m, hence a set of size l+b+t. Expanding this
size and using `r/E<=1/3` gives

`a >= floor(n/2+l/3+b/6)`.

The floor direction, t=0 case, and nonzero divisor are all correct.

### B4. Total-domination bound (prior Proposition 4)

**Valid; in particular, adjacent supports do not cause a gap.** The proposed
bound is `6 gamma_t <= 3n+2l+b`.

Stars are checked directly, including P3, whose degree-two center makes
`3n+2l+b=14`. For a non-star strong support v, connectivity forces a nonleaf
neighbor in addition to its at least two leaf neighbors. Deleting one leaf
therefore does not create a new leaf. Its center remains a forced support,
so any total dominating set of the smaller graph still works after the leaf
is restored. The order drops by one, l drops by one, and b increases by at
most one; the potential drops by at least four. The induction is sound.

With no strong support, leaves and supports correspond bijectively, s=l,
and the leaf-deleted core K is connected with at least two vertices. A
vertex in K can have degree one only if it is a support of original degree
two. Let S2 and S3 be supports of original degree two and three. Taking
`T=N_K(S2)\S`, `c=|T|`, and `D0=S union T` ensures every S2 vertex is
already dominated, including when its core neighbor is another support.
Also T and S2 are disjoint subsets of `N_K(D0)`, giving `t0>=c+s2`.

For any undominated core vertex u, every core neighbor lies outside D0 and
there are at least two. Its neighborhood, truncated to three if needed,
is therefore a legitimate 2- or 3-edge on `Q0=V(K)\D0`. A transversal X
together with D0 dominates all of K. In particular, an added vertex not
already dominated by D0 is itself among these neighborhood rows, so it has
a neighbor in X. Leaves are dominated by their forced supports. This
explicitly handles total rather than ordinary domination.

A size-two row comes only from a non-support of original degree two, or a
support in S3. The S2 vertices are not rows, so `h2<=b-s2+s3`. Substitution
into the mixed bound yields the chain

`6 gamma_t <= 3n+s+4c-t0+h2`

`             <= 3n+s+b+3c-2s2+s3`

`             <= 3n+s+b+s2+s3 <= 3n+2s+b`.

All counts and inequalities are valid, including c=0, s=0, an empty Q0,
an empty row set, and adjacent supports. Since s=l, Proposition 4 follows.
Combining it with B3 proves Corollary 5 without any remaining conjectural
assumption.

### B5. Trees, low cutoff, and global theorem (prior Lemmas 7--8, Theorem 9)

**Valid.** The tree incidence graph is a forest because the full neighborhood
incidence graph consists of two copies of the bipartite tree. The coloring
and total-domination argument are exactly the forest case checked in A2.
At cutoff two, `m+l<=2a+1`. For a tree `n=m+1`, its support/leaf bound gives
`gamma_t<=floor((m+l+1)/2)<=a+1`.

The prior manuscript's explicit selected pairs on cycles work for every
residue class modulo four, including C3. For a connected graph neither a
tree nor a cycle, some cycle vertex has degree at least three: otherwise
the vertices of any cycle would form an entire connected component. Delete
an incident cycle edge. It is nonbridge. The function `f=n+3m+l` drops by
at least one, since at most two new leaves arise. The annihilation transfer
is precisely A1. Minimality then contradicts a low-cutoff counterexample
to the global `a+1` bound. A minimum counterexample would therefore have
high cutoff, where Corollary 5 already gives the stronger bound `gamma_t<=a`.

The proof chain terminates in the verified classical theorem B1; it does
not appeal to a conjectural leaf case, to its finite checks, or to its
claimed external formal certificate. The earlier global theorem, the
high-cutoff result, and their reductions remain credited prior work.

## C. Independent finite checks

Run `python3 check_independent298.py` from this directory or any other.
The program uses unrestricted enumeration of all vertex subsets for exact
transversal/total-domination minima and directly sorts degrees for a.

Completed with status **PASS**:

- All **27,475 connected labeled graphs of orders 2 through 6**:
  1, 4, 38, 728, and 26,704 at the respective orders.
- **16,523** simple hypergraphs of rank at most three on fixed vertex sets
  of orders zero through four, including empty edge families.
- **10,000** fixed-seed hyperedge-multiset instances of order at most eight.
- **600** fixed-seed unicyclic instances with cycle lengths 4, 8 or 12 and
  order at most 14, in addition to those in the exhaustive graph census.
- Across the graph inputs: **26,055** explicit Proposition 4 constructions
  and **578,265** transversal lifts, **16,574** applicable edge transfers,
  and **261,291** checks of the removable-edge lemma for prescribed cycles.
- **1,743** unicyclic 4k-cycle instances checked by unrestricted variable
  2-color enumeration, both total dominating sets, and the support bound.
- Candidate constructive-coloring checker independently rerun: **7,000**
  instances, cycle lengths 4, 8, 12, 16, 20, 40, 100, maximum order 500;
  every row constraint and both total dominating sets verified.

Counts in the middle bullets include the added 600 random graph inputs and
need not count distinct isomorphism classes. The random generator seed for
the independent checker is 2986282026. Full machine-readable results are
`independent_results.json` and `candidate_coloring_rerun.json`. Finite checks
are corroboration only and are not used to prove any universal claim.

## Conclusion and remaining limits

No required repair was identified. The candidate and its publication source
give a complete ordinary proof of the 4k-cycle strengthening, and the
required prior global/high-cutoff input has itself been independently
audited down to a precisely verified classical theorem. The mathematical
audit therefore passes without a dependency-uncertain qualification.

Separate limitations remain honestly stated: no external Lean certificate
was rebuilt, this is not independent human peer review, the 1992 theorem's
full original proof was not reproved here, and no worldwide novelty claim
is certified. None of those is an uncovered step in the supplied
mathematical deduction.
