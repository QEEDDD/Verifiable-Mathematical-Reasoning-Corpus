# A cycle-divisibility theorem implying WOWII Conjecture 298

**Status: candidate complete deduction, submitted for independent audit.**
No new-closure claim is made until mathematical and primary-source audits finish.
The main result is derived from an explicitly credited prior total-domination–annihilation theorem; it is not a claim to that earlier global theorem.

## 1. Definitions and credited input

All graphs are finite and simple. A total dominating set contains a neighbor of every vertex, including each of its own members. Its minimum size is `gamma_t(G)`.

For a graph with `m` edges and sorted degrees `d_1 <= ... <= d_n`, its annihilation number is

`a(G)=max{k: d_1+...+d_k <= m}`.

For a connected graph of order at least two, `a<n`; write `d*=d_(a+1)` for the cutoff degree, and let `l` denote the number of leaves.

We use the following **prior results**, not new results of this note:

**Prior theorem (Gebendorfer, 11 October 2026).**

1. Every connected graph of order at least two satisfies `gamma_t <= a+1`.
2. If its order is at least three and its annihilation cutoff is at least three, then `gamma_t <= a`.

These are Theorem 9 and Corollary 5, respectively, in Jonas J. Gebendorfer, *A mixed transversal bound and the total-domination–annihilation conjecture*, manuscript dated 11 October 2026. The source is the archive attached to [GitHub issue 7242](https://github.com/google-deepmind/formal-conjectures/issues/7242), posted 12 October 2026. The manuscript explicitly does not claim the stronger four-cycle-indicator target. The archive SHA256 is `d067e88bdbf41f4fd4405b61e7cc71acfc9e4a6a6e64d7ca8d55f35b289d2afc`. A later [PR 7388](https://github.com/google-deepmind/formal-conjectures/pull/7388) links an immutable Lean certificate for the global statement; that external certificate has not been rebuilt in this work. The manuscript's graph constructions and inequalities have been inspected, but citation does not assert peer acceptance or exhaustive priority.

## 2. An annihilation transfer lemma

The following is the cycle-edge transfer used in the prior manuscript's Lemma 8, with its needed argument reproduced for clarity and attributed there to the earlier Bujtás–Jakovac reduction.

**Lemma 1.** Suppose `d*(G)=2`, and let `e=uv` be an edge with `d_G(v)>=3`. Then

`a(G-e) <= a(G)`.

**Proof.** Write `H=G-e` and `m=|E(G)|`. Choose an annihilation set `A` of `H` having size `a(H)`. Its degree sum in `H` is at most `m-1`. If it contains at most one endpoint of `e`, its degree sum in `G` is at most `m`, so it is already an annihilation set of `G`.

The only remaining case has `u,v in A` and degree sum in `G` exactly `m+1`. Let `L_2` be the vertices of degree at most two in `G`. The cutoff condition implies

`sum_{x in L_2} d_G(x) >= d_1+...+d_(a(G)+1) >= m+1`.

Because `v` has degree at least three and belongs to `A`, the set `A` cannot contain all of `L_2`: otherwise its degree sum would be at least `m+4`. Choose `w in L_2\A`. Replacing `v` by `w` decreases the degree sum by at least one, without changing the cardinality. The resulting set is an annihilation set of `G`, proving `a(H)<=a(G)`. QED.

## 3. A two-coloring for unicyclic graphs

The tree-component coloring below is the neighborhood-incidence forest argument already used in Lemma 7 of Gebendorfer. It is credited prior work. The additional step is extending it to unicyclic incidence components whose cycles have an even number of variable nodes. The standard pure-cycle total-domination formula is likewise not claimed as new.

**Lemma 2.** Let `G` be a connected unicyclic graph whose unique cycle has length divisible by four. Let `S` be its support vertices and let `l` be its number of leaves. Then

`gamma_t(G) <= floor((n+|S|)/2) <= floor((n+l)/2)`.

**Proof.** Put `Q=V(G)\S` and `U=V(G)\N(S)`, where `N(S)` is the union of the open neighborhoods of the supports. For every `u in U`, the set `N(u)` is contained in `Q` and has at least two vertices. Indeed, `u` has no neighbor in `S`, and a leaf would have its support as such a neighbor.

Form the incidence graph `I` with a variable copy of `Q`, a row copy of `U`, and an edge from row `u` to variable `v` exactly when `uv` is an edge of `G`. Since `G` is bipartite, its full open-neighborhood incidence graph consists of two disjoint copies of `G`: if `X,Y` are the bipartition classes, these copies have vertex sets `(rows X, variables Y)` and `(rows Y, variables X)`. The restricted incidence graph `I` is a subgraph of their disjoint union.

Every component of `I` is therefore a tree or is unicyclic. Any cycle in it has the same length `4k` as the unique cycle of `G`. Each row vertex of `I` has degree at least two.

We color the variable vertices red and blue so that every row has a neighbor of each color. For an acyclic component, root it at a variable vertex. At each row, its parent is a variable and at least one of its children is a variable; color one child opposite to the parent, then continue away from the root. All other variable children may be colored arbitrarily. Isolated variables may also be colored arbitrarily.

For a component containing a cycle, first alternate colors on the `2k` variable vertices of that cycle. This is consistent because `2k` is even, and every cycle row then has two differently colored cycle neighbors. Extend into each tree attached to the cycle by the preceding rule. At a cycle row its noncycle variable children may be given arbitrary initial colors, since that row already has both colors. There is no conflict because every off-cycle branch is a tree.

Let `Q_1,Q_2` be the two color classes. Each `S union Q_i` is a total dominating set: `S` dominates `N(S)`, and the row condition gives every vertex of `U` a neighbor in `Q_i`. This includes all selected vertices. The two set sizes sum to

`2|S|+|Q|=n+|S|`.

The smaller is at most `floor((n+|S|)/2)`. Different support vertices have disjoint nonempty sets of leaf neighbors, so `|S|<=l`. QED.

**Corollary 3.** A connected unicyclic graph whose unique cycle has length divisible by four satisfies `gamma_t <= a`.

**Proof.** If its cutoff is at least three, use the credited prior theorem. Otherwise the cutoff is two: all leaves fit the annihilation budget, since their distinct incident edges give `l<=m`, so cutoff one is impossible. At cutoff two, the first `a+1` degrees consist of all leaves followed by twos. Hence

`a=floor((m+l)/2)=floor((n+l)/2)`,

because a connected unicyclic graph has `m=n`. Lemma 2 proves the claim. QED.

## 4. Preserving a prescribed cycle

**Lemma 4.** Let `G` be connected, let `C` be a cycle of `G`, and suppose that `G` is not unicyclic. There is a nonbridge edge `e` outside `E(C)` with an endpoint of degree at least three.

**Proof.** There is another cycle `C'` with an edge outside `C`. If `C'` meets `C`, follow `C'` from a common vertex until it leaves the edge set of `C`; at an appropriate boundary there is an edge of `C'\C` incident with a vertex of `C`. That vertex has its two cycle edges of `C` and the extra edge, so it has degree at least three.

If `C'` is vertex-disjoint from `C`, connectedness gives a vertex of `C'` incident with a path toward `C` outside `C'`; that vertex has degree at least three. Either incident edge of `C'` is outside `C`.

In both cases the chosen edge belongs to `C'`, so it is not a bridge. QED.

## 5. Main theorem and the exact WOWII target

**Theorem 5.** If a connected graph contains a cycle whose length is divisible by four, then

`gamma_t(G) <= a(G)`.

**Proof.** If this fails, choose a counterexample having the fewest edges and fix such a cycle `C`. The graph has order at least four. By the prior high-cutoff theorem, its cutoff is not at least three. As above, all leaves fit the annihilation budget, so its cutoff is two.

It cannot be unicyclic, by Corollary 3. Choose the edge `e` given by Lemma 4. The graph `H=G-e` is connected and still contains `C`. By the minimal choice of `G`,

`gamma_t(H) <= a(H)`.

Every total dominating set of `H` also totally dominates `G`, and Lemma 1 gives `a(H)<=a(G)`. Therefore

`gamma_t(G) <= gamma_t(H) <= a(H) <= a(G)`,

a contradiction. QED.

**Corollary 6 (WOWII Conjecture 298).** Every connected simple graph of order greater than two satisfies

`gamma_t(G) <= a(G)+chi_C4(G)`,

where `chi_C4(G)=1` if `G` has no four-cycle as a subgraph, and is zero otherwise.

**Proof.** If a four-cycle occurs, Theorem 5 gives `gamma_t<=a`; the four-cycle need not be induced. If no four-cycle occurs, the credited prior global theorem gives `gamma_t<=a+1`. QED.

## 6. Scope of the conclusion

The new deduction asserted here is the divisible-by-four cycle strengthening and its consequence for the exact four-cycle-indicator statement. The prior global annihilation-plus-one theorem, its high-cutoff strengthening, the degree-budget edge-transfer idea, and the incidence-forest coloring for trees are explicitly credited; they must not be counted as new results.

The bounded all-state GitHub audit found no earlier full result under target `298`, `four-cycle annihilation`, or the global annihilation issue's related records. This is not worldwide priority certification. An expanded keyword and primary-manuscript audit is pending, along with independent checking of Lemmas 2 and 4 and the preservation/minimality argument.
