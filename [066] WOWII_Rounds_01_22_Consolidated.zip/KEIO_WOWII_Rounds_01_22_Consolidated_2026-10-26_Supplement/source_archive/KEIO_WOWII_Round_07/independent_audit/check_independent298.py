#!/usr/bin/env python3
"""Independent finite audit; standard library, unrestricted subset minima.

No candidate/prior checker is imported. Finite checks are not proof premises.
"""
from collections import Counter
from itertools import combinations
from pathlib import Path
import hashlib
import json
import random
import time


def bits(x):
    while x:
        b = x & -x
        yield b.bit_length() - 1
        x ^= b


def connected(adj):
    seen = 1
    old = 0
    while old != seen:
        old = seen
        for v in bits(old):
            seen |= adj[v]
    return seen == (1 << len(adj)) - 1


def annihilation(adj):
    degrees = sorted(x.bit_count() for x in adj)
    budget = sum(degrees) // 2
    total = 0
    for i, d in enumerate(degrees):
        if total + d > budget:
            return i
        total += d
    return len(adj)


def transversal(n, edges):
    best = n
    for mask in range(1 << n):
        if mask.bit_count() < best and all(mask & edge for edge in edges):
            best = mask.bit_count()
    return best


def cycles(adj):
    """Each undirected simple cycle exactly once, smallest vertex first."""
    for start in range(len(adj)):
        def visit(path, used):
            last = path[-1]
            if len(path) >= 3 and adj[last] & (1 << start) and path[1] < last:
                yield tuple(path)
            for nxt in bits(adj[last] & ~used):
                if nxt > start:
                    yield from visit(path + [nxt], used | (1 << nxt))
        yield from visit([start], 1 << start)


def deleted(adj, u, v):
    out = list(adj)
    out[u] ^= 1 << v
    out[v] ^= 1 << u
    return out


def supports(adj):
    return {next(bits(adj[v])) for v in range(len(adj)) if adj[v].bit_count() == 1}


def bicoloring_exists(adj):
    n = len(adj)
    S = supports(adj)
    smask = sum(1 << x for x in S)
    dominated = 0
    for x in S:
        dominated |= adj[x]
    rows = [v for v in range(n) if not dominated & (1 << v)]
    qmask = ((1 << n) - 1) ^ smask
    for v in rows:
        assert adj[v] & smask == 0 and adj[v].bit_count() >= 2
    mask = qmask
    while True:
        other = qmask ^ mask
        if all(adj[v] & mask and adj[v] & other for v in rows):
            D1, D2 = smask | mask, smask | other
            assert all(D1 & neighborhood and D2 & neighborhood for neighborhood in adj)
            assert min(D1.bit_count(), D2.bit_count()) <= (n + len(S)) // 2
            return True
        if mask == 0:
            return False
        mask = (mask - 1) & qmask


def check_prop4_construction(adj, stats):
    n = len(adj)
    deg = [x.bit_count() for x in adj]
    P = {v for v in range(n) if deg[v] == 1}
    S = supports(adj)
    if len(P) != len(S):
        return
    # The unique star without strong support is excluded by n >= 3.
    smask = sum(1 << v for v in S)
    pmask = sum(1 << v for v in P)
    kmask = ((1 << n) - 1) ^ pmask
    s2 = {v for v in S if deg[v] == 2}
    s3 = {v for v in S if deg[v] == 3}
    T = 0
    for v in s2:
        T |= adj[v] & kmask & ~smask
    D0 = smask | T
    dominated = 0
    for v in bits(D0):
        dominated |= adj[v] & kmask
    rows = kmask & ~dominated
    qmask = kmask & ~D0
    edges = []
    for v in bits(rows):
        edge = adj[v] & kmask
        assert edge & D0 == 0 and edge.bit_count() >= 2
        truncated = sum(1 << x for x in list(bits(edge))[:3])
        assert truncated & ~qmask == 0
        edges.append(truncated)
    h2 = sum(edge.bit_count() == 2 for edge in edges)
    assert dominated.bit_count() >= T.bit_count() + len(s2)
    assert h2 <= sum(d == 2 for d in deg) - len(s2) + len(s3)
    # Enumerate every transversal in Q0, not just a guessed minimum cover.
    best = n
    mask = qmask
    while True:
        if all(mask & edge for edge in edges):
            D = D0 | mask
            assert all(D & neighborhood for neighborhood in adj)
            best = min(best, mask.bit_count())
            stats['proposition4_transversal_lifts'] += 1
        if mask == 0:
            break
        mask = (mask - 1) & qmask
    assert 6 * best <= 2 * qmask.bit_count() + len(edges) + h2
    assert 6 * (D0.bit_count() + best) <= 3 * n + 2 * len(P) + sum(d == 2 for d in deg)
    stats['proposition4_constructions'] += 1


def check_graph(adj, stats, cycle_checks=True):
    n = len(adj)
    deg = [x.bit_count() for x in adj]
    m = sum(deg) // 2
    a = annihilation(adj)
    gt = transversal(n, adj)
    assert gt <= a + 1
    if n == 2:
        return
    l = deg.count(1)
    b = deg.count(2)
    assert 6 * gt <= 3 * n + 2 * l + b
    cutoff = sorted(deg)[a]
    assert cutoff >= 2
    if cutoff >= 3:
        assert a >= (3 * n + 2 * l + b) // 6 and gt <= a
        stats['high_cutoff'] += 1
    else:
        assert a == (m + l) // 2
        for u in range(n):
            for v in bits(adj[u]):
                if u < v and max(deg[u], deg[v]) >= 3:
                    assert annihilation(deleted(adj, u, v)) <= a
                    stats['edge_transfers'] += 1
    check_prop4_construction(adj, stats)
    if not cycle_checks:
        return
    all_cycles = list(cycles(adj))
    divisible = [C for C in all_cycles if len(C) % 4 == 0]
    if divisible:
        assert gt <= a
        stats['graphs_with_4k_cycle'] += 1
    if m == n and divisible:
        assert len(all_cycles) == 1
        assert gt <= (n + len(supports(adj))) // 2 <= (n + l) // 2
        assert bicoloring_exists(adj)
        stats['unicyclic_4k_coloring'] += 1
    if m > n:
        eligible = []
        for u in range(n):
            for v in bits(adj[u]):
                if u < v and max(deg[u], deg[v]) >= 3 and connected(deleted(adj, u, v)):
                    eligible.append((u, v))
        for C in all_cycles:
            Cedges = {tuple(sorted((C[i], C[(i + 1) % len(C)]))) for i in range(len(C))}
            assert any(edge not in Cedges for edge in eligible)
            stats['prescribed_cycle_edge_lemmas'] += 1


def main():
    start = time.monotonic()
    stats = Counter()
    by_order = {}
    for n in range(2, 7):
        edges = list(combinations(range(n), 2))
        count = 0
        for mask in range(1 << len(edges)):
            adj = [0] * n
            for j in bits(mask):
                u, v = edges[j]
                adj[u] |= 1 << v
                adj[v] |= 1 << u
            if connected(adj):
                check_graph(adj, stats)
                count += 1
        by_order[n] = count
        print(f'completed connected graphs n={n}: {count}', flush=True)
    hypergraphs = 0
    for n in range(0, 5):
        candidates = [x for x in range(1, 1 << n) if x.bit_count() <= 3]
        for mask in range(1 << len(candidates)):
            edges = [candidates[j] for j in bits(mask)]
            weight = 2 * n + sum({1: 4, 2: 2, 3: 1}[e.bit_count()] for e in edges)
            assert 6 * transversal(n, edges) <= weight
            hypergraphs += 1
    rng = random.Random(2986282026)
    multiset_checks = 10000
    for _ in range(multiset_checks):
        n = rng.randrange(1, 9)
        candidates = [x for x in range(1, 1 << n) if x.bit_count() <= 3]
        edges = [rng.choice(candidates) for _ in range(rng.randrange(25))]
        weight = 2 * n + sum({1: 4, 2: 2, 3: 1}[e.bit_count()] for e in edges)
        assert 6 * transversal(n, edges) <= weight
    # In particular include 8- and 12-cycles, which small exhaustive graph tests lack.
    random_unicyclic = 600
    for _ in range(random_unicyclic):
        c = rng.choice([4, 8, 12])
        n = rng.randrange(c, 15)
        adj = [0] * n
        def add(u, v):
            adj[u] |= 1 << v
            adj[v] |= 1 << u
        for v in range(c):
            add(v, (v + 1) % c)
        for v in range(c, n):
            add(v, rng.randrange(v))
        check_graph(adj, stats)
    here = Path(__file__).resolve().parent
    result = {
        'status': 'PASS',
        'method': 'independently implemented exact unrestricted subset minima; no imported candidate checker',
        'exhaustive_connected_labeled_graphs': by_order,
        'exhaustive_graph_total': sum(by_order.values()),
        'exhaustive_simple_rank_at_most_3_hypergraphs_order_at_most_4': hypergraphs,
        'fixed_seed_multiset_hypergraphs_order_at_most_8': multiset_checks,
        'fixed_seed_unicyclic_graphs_cycle_lengths_4_8_12_order_at_most_14': random_unicyclic,
        'seed': 2986282026,
        'checks': dict(stats),
        'elapsed_seconds': round(time.monotonic() - start, 3),
        'scope': 'Finite sanity checks only; not premises of the mathematical proof.',
        'sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in [
            here / 'audited_candidate_snapshot.md',
            here / 'audited_prior_paper.txt',
            here / 'audited_prior_paper.pdf',
            Path(__file__).resolve(),
        ]},
    }
    (here / 'independent_results.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
