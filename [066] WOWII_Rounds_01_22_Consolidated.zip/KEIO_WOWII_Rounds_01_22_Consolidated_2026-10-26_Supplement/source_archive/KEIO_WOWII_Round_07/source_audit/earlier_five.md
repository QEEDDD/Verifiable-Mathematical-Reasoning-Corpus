# Retrospective primary-source audit: 394, 392e, 392f, 395a, 382c

Checked **26 October 2026 UTC**, after discovering the missed prior 412d submission. **No prior exact full resolution was found for any of these five targets in this expanded audit.** Their earlier bounded-priority conclusions are retained; this is not a worldwide novelty certificate.

## Newly checked primary channel

The GitHub Search API returned **188** upstream issues/pull requests matching `repo:google-deepmind/formal-conjectures WOWII`; both result pages were retrieved, deduplicated and searched, including unmerged submissions. Unrestricted-within-repository target queries and family-number queries were also retrieved. The complete responses are retained locally and their hashes recorded. Unlike a merged-directory inventory, this channel finds the October submissions that resolved412d.

| Target | Exact-number query hits | Actual target-resolution hits | Finding |
|---|---:|---:|---|
|394|14|0|Only WOWII-context hit is348 PR7512;394 is a bibliography page number. Other hits concern Erdős problems.|
|392e|0|0|No exact target submission; family392 query has13 unrelated hits.|
|392f|0|0|Same family check; no full target submission.|
|395a|0|0|Nearby395b and396 submissions checked individually; their formulas differ.|
|382c|0|0|Family382 query has7 unrelated Erdős hits.|

No candidate-matching proof/certificate was located, so there is no third-party target proof whose dependencies could be replayed. This report does not imply that all188 submissions are valid; it uses them as a primary current-priority inventory.

## Nearby claims distinguished explicitly

- [PR7512](https://github.com/google-deepmind/formal-conjectures/pull/7512), opened21October2026, proves the tree total-domination inequality numbered348. Its body cites journal page394. It does not discuss2-domination conjecture394.
- [Issue7330](https://github.com/google-deepmind/formal-conjectures/issues/7330) and [PR7337](https://github.com/google-deepmind/formal-conjectures/pull/7337), both opened14October2026, concern **395b**: `gamma_2 <= |M|+delta(G[V-A_delta])+|V-A_3|`. They publish a15-vertex graph with `gamma_2=6>5`. This is not395a's sum of two matching terms and modal cardinality.
- [Issue7308](https://github.com/google-deepmind/formal-conjectures/issues/7308) and [PR7320](https://github.com/google-deepmind/formal-conjectures/pull/7320), opened14October2026, concern **396**: `gamma_2 <= dd_mode+|M|+|E(A_3,V-A_3)|`. The39-vertex clique-chain witness and certificate target this different formula. Neither body claims the five targets audited here.

The exact five source formulas, domains, raw original HTML and scoped conclusions appear in `RETROSPECTIVE_FIVE.json`. Both `mu` symbols in395a are matching numbers, not edge counts; its primary Symbol-font interpretation remains unchanged.392f uses an intersection and open neighborhood union.382c uses average vertex eccentricity over the minimum-degree set.394's correction is the cardinality of the minimum-local-independence vertex set. Earlier exact-definition audits remain operative.

Eight additional numbered/family web queries found no exact target resolution. The previously examined author-hosted2-domination paper, baseline partials, public verification README and ledger remain additional checked evidence, not substitutes for this newly added unmerged-submission channel.

## Limits and correction discipline

The earlier412d negative was wrong as a current conclusion because an unmerged primary proof already existed. It has been explicitly corrected in Round07. That collision is not extrapolated to unrelated targets without evidence. Conversely, absence from this bounded search is not a proof of historical uniqueness. Search indexing, differently numbered theorems, other repositories and inaccessible literature remain limitations. No external repository or status page was modified.
