# Retrospective priority re-audit: WOWII 434d, 434e, 269, 302

Audit date: 26 October 2026, approximately 01:56–02:05 UTC. Scope: the newly identified primary GitHub issue/PR channel, including unmerged and closed submissions, plus their relevant linked written evidence. No original manuscript was changed.

## Outcome

**No exact prior resolution or proof collision was located for these four delivered statements in the bounded channel audited here.** This is not a worldwide-priority determination, and is not a claim that a historical `O` marker establishes present openness. It supplies no basis to retract these four as already resolved. The independently discovered 412d collision is a different statement and must not be generalized to them.

| Delivered target | Exact target inspected | Channel result |
|---|---|---|
| 434d (round 01) | `i(G) <= degen(complement G) - comp(G[N[B]]) + 2`; delivered strengthening `i(G)+p4(G)-2 <= degen(complement G)` | No prior resolution located |
| 434e (round 04) | `i(G) <= degen(complement G) - ecc(C(G)) + 2`; delivered local-cover/dominating-tree strengthening | No prior resolution located |
| 269 (round 05) | C4-free connected graphs: `gamma_t(G) >= ceil(1 + avg_distance_between_centers(G))`; 268-vertex counterexample and infinite family | No prior resolution located |
| 302 (round 06) | `gamma_t(G) <= min_even_distance_count(G) + frequency_of_max_local_independence(complement G)`; 40-vertex counterexample and unbounded family | No prior resolution located |

The exact delivered files were read from `round_01/independence/manuscript.tex`, `round_04/independence/manuscript.tex`, `round_05/main269/counterexample269.tex`, and `round_06/domination/counterexample302.tex`.

## Retrieval coverage and limitations

GitHub REST search was used directly, not merely web-search snippets. With no `is:open`, `is:closed`, `is:issue`, or `is:pr` filter, `search/issues` covers issue and pull-request records across their states. Full JSON responses retain URLs, authors, creation/update timestamps, state, and complete returned bodies. Search is not a guarantee against unindexed material, renamed formulations, or evidence published elsewhere.

- `repo:google-deepmind/formal-conjectures 434d`: **0** results; `incomplete_results=false`.
- Same repository, `434e`: **0** results; incomplete false.
- Same repository, `269`: **16** results. These are Erdős 269, the unrelated PR numbered 269, incidental numerical occurrences, and unrelated references; none is WOWII 269.
- Same repository, `302`: **8** results. These concern Erdős 302, the unrelated PR numbered 302, and incidental occurrences; none is WOWII 302.
- Same repository, `WOWII`: **188** records, both pages fetched; all returned bodies searched for the target numbers and equivalent invariant terminology. Relevant candidate bodies were read fully.
- Same repository, `Gebendorfer`: **111** records, both pages fetched and searched.
- Formula/terminology queries: independent domination (71), degeneracy (18), total domination (52), center eccentricity (11), local independence (15), even distance (13), Szekeres (20), vertex cover (20), and distance-four (11). Their relevant graph candidates were compared at statement level, not classified by title alone.
- Global `434d WOWII` and `434e WOWII` searches returned zero. **Global numerical `269 WOWII` and `302 WOWII` responses were not treated as usable negative evidence**: the service produced large sets of unrelated issues numbered 269/302. Their raw responses are retained only to disclose this search behavior.
- A complete recursive tree response for `RhudeJJJJ/formal-conjectures` main had 2,052 entries and `truncated=false`; no WOWII 434d/e/269/302-named proof file was present. This is auxiliary evidence only, not proof of absence on all branches.

## Relevant sources and mathematical exclusions

### 434d and 434e: degeneracy material is not a collision

[PR 3821](https://github.com/google-deepmind/formal-conjectures/pull/3821), created **22 April 2026, 13:51:33 UTC**, was inspected through both its full body and actual changed-file patches (`pull3821.json`). Its `GraphDegeneracy.lean` states the classical coloring bound `chi <= degeneracy+1` and clique lower bound `degeneracy >= clique_number-1`. It does not state the packing/component correction in 434d, the center-eccentricity correction in 434e, or their delivered strengthenings. Its local-independence frequency file is WOWII 209, not 302.

The other independent-domination candidates concern distinct quantities: e.g. [issue 7272](https://github.com/google-deepmind/formal-conjectures/issues/7272) (13 October 2026, 07:59:24 UTC) proves a cut bound involving two ordinary independence numbers (WOWII 423); [issue 7274](https://github.com/google-deepmind/formal-conjectures/issues/7274) (13 October 2026, 08:02:04 UTC) refutes a maximum-degree/square-degree reading of WOWII 433. Their complete bodies and explicit mathematical arguments do not supply either requested 434d/e correction. Nearby center-based [issue 4912](https://github.com/google-deepmind/formal-conjectures/issues/4912) / [PR 4913](https://github.com/google-deepmind/formal-conjectures/pull/4913) concern a Caro–Wei correction (430a), not complement degeneracy.

### 269: nearby averages and C4-free witnesses checked beyond their titles

[Issue 7305](https://github.com/google-deepmind/formal-conjectures/issues/7305), created **14 October 2026, 06:59:58 UTC**, and [PR 7321](https://github.com/google-deepmind/formal-conjectures/pull/7321), created **14 October 2026, 11:04:50 UTC**, concern WOWII 360. The attached complete **13 October 2026** paper `proof360.pdf` was read. Its average is center-to-**all vertices**, denominator `|C|(n-1)`, with an additional support/leaf component term. It is not the average **between pairs of centers** appearing in 269. Its trees have two adjacent centers, so their center-pair average is one.

[Issue 7306](https://github.com/google-deepmind/formal-conjectures/issues/7306), created **14 October 2026, 07:02:17 UTC**, concerns WOWII 373. The complete attached **13 October 2026** paper `gebendorfer-wowii373.pdf` was read. Its average is **periphery-to-all vertices** with coefficient 2/3, not center-pair average. The replacement diameter bound in that paper also does not refute 269. These tree families are not the delivered self-centered C4-free construction.

[Issue 7235](https://github.com/google-deepmind/formal-conjectures/issues/7235), created **12 October 2026, 21:22:52 UTC**, and [PR 7303](https://github.com/google-deepmind/formal-conjectures/pull/7303), created **14 October 2026, 06:37:56 UTC**, prove the different square-root lower bound in terms of maximum-degree-vertex diameter (WOWII 271). The full body gives a positive theorem, not a prior center-average counterexample.

The two closest C4-free counterexample sources were investigated at full-paper and exact-witness level:

- [Issue 7262](https://github.com/google-deepmind/formal-conjectures/issues/7262), **13 October 2026, 07:31:11 UTC**, and [PR 7366](https://github.com/google-deepmind/formal-conjectures/pull/7366): WOWII 252; attached paper dated **8 September 2026**, 30 vertices and 58 edges.
- [Issue 7263](https://github.com/google-deepmind/formal-conjectures/issues/7263), **13 October 2026, 07:32:38 UTC**, and [PR 7367](https://github.com/google-deepmind/formal-conjectures/pull/7367): WOWII 253; attached paper **undated**, public no later than the issue creation, 30 vertices and 53 edges.

Both full PDFs were read, including complete constructions, domination lower certificates, and girth checks. `check_nearby_witnesses.py` independently reconstructs them from their displayed formulas, without importing the downloaded programs. Exact BFS and rational center averages give:

| Prior witness | gamma_t | Center-pair average | 269 RHS | Refutes 269? |
|---|---:|---:|---:|---|
| 252 witness | 6 | 28/15 | 3 | No |
| 253 witness | 6 | 7/4 | 3 | No |

Thus these earlier C4-free graphs are not overlooked counterexamples to the exact delivered target.

### 302: even-distance/local-independence material is distinct

[Issue 4931](https://github.com/google-deepmind/formal-conjectures/issues/4931) and [PR 4932](https://github.com/google-deepmind/formal-conjectures/pull/4932), **13 August 2026**, concern WOWII 309: an even-distance-minus-horizontal-edge correction plus a complement edge-neighborhood minimum, on `C5[K_k]`. Their full bodies give a different inequality and different family; they do not resolve 302. [PR 4592](https://github.com/google-deepmind/formal-conjectures/pull/4592), **23 July 2026**, uses the same carrier for induced forest/bipartite bounds 63 and 85, not 302. In that vertex-transitive family every vertex attains the same complement local-independence value, so its frequency term is the full graph order, not the unique maximizer central to the delivered 302 counterexample.

[PR 4508](https://github.com/google-deepmind/formal-conjectures/pull/4508), **21 July 2026**, is a Hamiltonian-path implication involving frequency of maximum local independence of G itself, not complement frequency plus minimum even count. [PR 4430](https://github.com/google-deepmind/formal-conjectures/pull/4430), **14 July 2026**, proves a conditional two-vertex minimal-total-domination result (322), again not 302.

The independently reconstructed 252/253 witnesses above both have minimum even-distance count 12 and complement maximum-local-independence frequency 30. Both therefore satisfy 302 as `6 <= 42`; they do not hide an earlier counterexample to 302.

## Attachments inspected

- `new_six.zip`: complete six-manuscript intake attached to 7305/7306 and related issues, including the fully read 360 and 373 proofs.
- `new_seven.zip`: seven-manuscript intake attached to 7330–7336 and related PRs; filenames, READMEs and extracted proof texts searched for the four targets/equivalent terms. It contains 395b/397c/379/381 and other unrelated targets, not the four in this audit.
- `wowii252.zip`, `wowii253.zip`: complete relevant papers read and witnesses independently checked as above.
- Full issue/PR search bodies and timestamps remain in the JSON snapshots. All 13 number-search hits reporting nonzero issue-comment counts were additionally fetched; their complete comment snapshots are retained as `comments_<number>.json`. No target collision was found there.

## Appropriate conclusion

Use **“no prior resolution located in the expanded bounded audit”**, not “confirmed worldwide new” or “definitely still open before our work.” The priority check and mathematical correctness review are separate. No exact-collision correction is presently supported for these four; retain the already stated caution about global priority. No fresh user-facing closure claim was made by this auditing agent.
