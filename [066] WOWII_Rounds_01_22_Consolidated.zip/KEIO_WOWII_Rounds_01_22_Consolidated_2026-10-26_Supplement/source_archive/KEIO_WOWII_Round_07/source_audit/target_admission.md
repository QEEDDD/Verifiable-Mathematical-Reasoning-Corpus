# Remaining-target admission audit

Checked 26 October 2026 (UTC). **This is a bounded prior-result audit, not a certificate of worldwide openness or novelty.** Mathematical proof verification is separate.

## Outcome

| Target | Expanded public-source outcome | Important admission condition |
|---|---|---|
| 382e | No prior full resolution found | Use **best** Maxine over all allowed greedy ties; the known alpha + gamma bound is weaker. |
| 384b | No prior full resolution found | T counts distinct vertex triangle-incidence counts, including zero when realized. |
| 389a | No prior full resolution found | A2 means degree **at most** two; smallest tied mode; the primary quartile index lacks a rounding rule when 4 does not divide n. |
| 298 | No prior full resolution of its C4-containing branch found | The newly located global a+1 theorem proves only its C4-free branch. Chi_C4 is an indicator, not a chromatic number. |
| 154, 155 | No additional prior full resolution found | Baseline radius-at-most-two results remain prior partials; do not promote a degenerate-order convention issue to a new closure. |
| 182, 183 | No additional prior full resolution found | Preserve baseline degree/ambient readings and its already proved residual restrictions. |
| 186 | **Interpretation-qualified only** | Baseline already refutes its square-neighborhood reading. The omitted ambient subscripts remain substantive. |
| 299 | **Retire from new targets** | Gebendorfer's 11 October theorem and high-cutoff corollary already imply it in full. |

These findings justify continued *source-scoped* work, not an assertion that an exhaustive worldwide search established unsolved status. Exact original row text, HTML, definition entries, prior snapshot information and limitations are in `target_admission_audit.json`.

## Expanded channel and query scope

The pass reuses the complete cached **188** WOWII issue/PR hits and **111** Gebendorfer hits, includes both open and closed items, and does not depend on merge status. Deduplicated full-body matching is recorded in `inventory_target_hits.json`; all target-number occurrences in that inventory were inspected. The numeric false positives refer to other conjectures or bibliographic page numbers.

Separate repository API queries used each target ID and semantic combinations: Maxine, quartile, triangles/domination, radial, leaves/bipartite, leaves/square, annihilation, and four-cycle/annihilation. See `search_summary.json`, `semantic_api_summary.json` and their raw response files. Exact letter-suffixed queries 382e, 384b and 389a returned zero hits. The semantic annihilation query exposed the decisive prior 7242/7388 result that a target-number-only search missed.

All-repository phrase queries and focused C4k queries supplement this. The final C4k batch returned 58 annihilation/divisible hits and 63 annihilation/4k hits (all unrelated after invariant/context inspection), zero annihilation/unicyclic hits, and exactly one total-domination/cycle/four/annihilation hit: issue 7242. See `c4k_summary.json` and raw responses. **Caution:** an unqualified numeric GitHub search can preferentially match issue numbers, and broad word searches can return noisy/incomplete first pages. Such raw exploratory responses are retained but not used to claim exhaustive coverage. The quoted `"WOWII 298" in:title,body` query returned zero; the annihilation/total-domination phrase query returned the relevant 7242/7388 pair and unrelated results, whose bodies were inspected. The full cached source-corpus scan is stronger than these numeric negative queries.

Targeted web searches also used the actual invariants rather than solely numbers: Maxine and two-domination; distinct incident-triangle counts and two-domination; first quartile/modal degree; radial circles and spanning-tree leaves; square-graph center/periphery plus induced bipartite order; and annihilation/total domination with four-cycle, C4, 4k, even/unicyclic cycles, modulo and divisible-by-four language. Raw result snapshots are retained as `web_*.json`. Only primary mathematical papers/author repositories were used for positive status conclusions.

## #298: focused equivalent-theorem comparison

The exact source is

> For simple connected G with n > 2, gamma_t(G) <= a(G) + chi_C4(G).

Primary definition 73 explicitly gives chi_C4=1 if G is C4-free, **not necessarily induced**, and 0 otherwise. Definition 89 is the usual annihilation degree-sum invariant; definition 94 is total domination including selected vertices.

### Closest prior full general theorem

Jonas J. Gebendorfer, *A mixed transversal bound and the total-domination–annihilation conjecture*, manuscript **11 October 2026**:

- [Issue 7242](https://github.com/google-deepmind/formal-conjectures/issues/7242), created **12 October 2026, 21:47:03 UTC**.
- [PR 7388](https://github.com/google-deepmind/formal-conjectures/pull/7388), created **15 October 2026, 22:20:49 UTC**.
- [Primary manuscript/checks attachment](https://github.com/user-attachments/files/33357596/Total_Domination_Annihilation_Intake_2026-10-12.zip).

Theorem 9 proves gamma_t <= a+1 for every connected nontrivial graph. Corollary 5 proves gamma_t <= a when the first excluded annihilation degree is at least three. Issue 7242 expressly excludes claiming the stronger four-cycle-indicator variant. Thus neither its title nor its general theorem alone closes exact #298.

Its prior Lemma 7 contains the tree incidence-forest coloring argument. Its Lemma 8 contains cycle-edge annihilation transfer and pure-cycle constructions, including C_(4q). These are **prior ingredients** and must be attributed. The full manuscript does not state the proposed unicyclic C4k incidence-coloring extension or the all-connected prescribed-cycle strengthening. The in-thread proof's distinct additional step must be judged mathematically on that basis, not represented as a new global annihilation theorem.

### Earlier class-specific results

Csilla Bujtás and Marko Jakovac, *Relating the total domination number and the annihilation number of cactus graphs and block graphs*, Ars Mathematica Contemporanea **16 (2019), 183–202**, [DOI](https://doi.org/10.26493/1855-3974.1378.11d), [author manuscript](https://omr.fnm.um.si/wp-content/uploads/2018/03/TD-Annihilation-Cactus-Block-6.pdf).

The full author manuscript was retrieved and read. Main Theorems 3 and 4 prove only gamma_t <= a+1 for cactus and block graphs. The explicit C4 deletion case in Lemma 6 also retains +1. Lemma 5(i) is the credited earlier source of the cycle-edge reduction. These class results therefore do not supply a full gamma_t <= a theorem for graphs containing C4 or a cycle of length divisible by four.

The subsequent minimum-degree-two result (Jakovac, arXiv:2609.10795v2) and related quasi-tree/composite-graph a+1 results do not, by their stated conclusions, supply the stronger low-cutoff C4-containing branch. The current Oct11 general result subsumes the a+1 branch.

**Bounded conclusion:** no earlier full exact #298 resolution or all-connected C4k-containing gamma_t <= a theorem was found in the checked issue/PR bodies, their linked prior manuscript, the 2019 class paper, or focused equivalent-formula literature queries. This does not certify global priority. Parent/native agents independently audit the new proof; this file does not count or certify a new closure.

## #299 priority retirement

The prior global theorem handles #299 whenever the number n2 of degree-two vertices is at least one. If n2=0, connected n>2 graphs have annihilation cutoff at least three, so the prior high-cutoff corollary gives gamma_t <=a. Together these imply gamma_t <=a+n2, the full source statement. The primary paper and immutable formalization materials are preserved at `../../round_08/domination/source_priority/`; `priority_audit_299.json` there supplies the full proof-location and hash record. External Lean was not rerun in this source audit.

## Other safeguards

The original catalogue's January/March 2010 #382e note and [DeLaVina–Larson–Pepper author manuscript](https://math1um.github.io/Research/r07.pdf) prove the weaker alpha+gamma bound. The [c5-k4 382e trial](https://github.com/Kuberwastaken/c5-k4/blob/main/results/expansion/method_v02_382e.md) explicitly reports HOLD_BOUNDED finite searches, not a full theorem. Neither is a priority collision with the printed best-Maxine statement.

For #389a, the current verification README's adopted floor index is a computational convention; it does not resolve the missing original quartile rounding rule. A multiple-of-four witness would avoid that issue.

For #186, the source's N and ecc lack ambient graph subscripts. Baseline already gives a square-neighborhood counterexample and retains a different ambient reading. No unqualified new number should be counted on this evidence.
