#!/usr/bin/env python3
"""Constructive finite checks of the unicyclic coloring in proof298.md.
Uses only the Python standard library. Random checks are not a proof.
"""
import collections
import json
import random


def color_and_cover(adj):
    n = len(adj)
    leaves = {v for v in range(n) if len(adj[v]) == 1}
    supports = {next(iter(adj[v])) for v in leaves}
    variables = set(range(n)) - supports
    dominated = set().union(*(adj[v] for v in supports)) if supports else set()
    rows = set(range(n)) - dominated
    inc = {v: set() for v in variables}
    inc.update({n+v: set() for v in rows})
    for v in rows:
        assert len(adj[v]) >= 2 and adj[v] <= variables
        for w in adj[v]:
            inc[n+v].add(w)
            inc[w].add(n+v)
    colors = {}
    seen = set()
    for first in sorted(inc):
        if first in seen:
            continue
        comp = {first}
        queue = collections.deque([first])
        while queue:
            v = queue.popleft()
            for w in inc[v] - comp:
                comp.add(w)
                queue.append(w)
        seen |= comp
        deg = {v: len(inc[v]) for v in comp}
        queue = collections.deque(v for v in comp if deg[v] <= 1)
        core = set(comp)
        while queue:
            v = queue.popleft()
            if v not in core:
                continue
            core.remove(v)
            for w in inc[v] & core:
                deg[w] -= 1
                if deg[w] == 1:
                    queue.append(w)
        if core:
            assert all(len(inc[v] & core) == 2 for v in core)
            firstvar = min(v for v in core if v < n)
            cycle = [firstvar]
            prev, cur = None, firstvar
            while True:
                nxt = min((inc[cur] & core) - ({prev} if prev is not None else set()))
                if nxt == firstvar:
                    break
                cycle.append(nxt)
                prev, cur = cur, nxt
            assert set(cycle) == core
            cyclevars = [v for v in cycle if v < n]
            assert len(cyclevars) % 2 == 0
            for i, v in enumerate(cyclevars):
                colors[v] = i % 2
            roots = sorted(core)
        else:
            roots = [min(v for v in comp if v < n)]
            colors[roots[0]] = 0
        parent = {v: None for v in roots}
        queue = collections.deque(roots)
        while queue:
            v = queue.popleft()
            children = [w for w in sorted(inc[v]) if w not in parent]
            for w in children:
                parent[w] = v
                queue.append(w)
            if v >= n:
                if v in core:
                    for w in children:
                        colors[w] = 0
                else:
                    assert parent[v] is not None and children
                    for w in children:
                        colors[w] = 0
                    colors[children[0]] = 1-colors[parent[v]]
        assert set(parent) == comp
    assert set(colors) == variables
    for v in rows:
        assert {colors[w] for w in adj[v]} == {0, 1}
    classes = [{v for v in variables if colors[v] == i} for i in (0, 1)]
    covers = [supports | part for part in classes]
    assert all(all(adj[v] & cover for v in range(n)) for cover in covers)
    cover = min(covers, key=lambda x: (len(x), sorted(x)))
    assert len(cover) <= (n+len(supports))//2 <= (n+len(leaves))//2
    return len(cover)


def make(cycle_len, extra, rng):
    n = cycle_len+extra
    adj = [set() for _ in range(n)]
    def edge(u, v):
        adj[u].add(v)
        adj[v].add(u)
    for v in range(cycle_len):
        edge(v, (v+1) % cycle_len)
    for v in range(cycle_len, n):
        edge(v, rng.randrange(v))
    return adj


def main():
    rng = random.Random(29820261026)
    counts = {}
    max_order = 0
    for cycle_len in (4, 8, 12, 16, 20, 40, 100):
        for _ in range(1000):
            extra = rng.randrange(401)
            adj = make(cycle_len, extra, rng)
            color_and_cover(adj)
            max_order = max(max_order, len(adj))
        counts[cycle_len] = 1000
    print(json.dumps({
        'status': 'PASS', 'seed': 29820261026,
        'unicyclic_graphs_checked': sum(counts.values()),
        'by_cycle_length': counts, 'maximum_order': max_order,
        'checks': ['incidence components and even variable cycles',
                   'both colors in every residual neighborhood',
                   'both constructed sets totally dominate all vertices',
                   'smaller-set bound including support and leaf counts'],
        'scope': 'Fixed-seed generated instances; not an exhaustive graph-class proof'
    }, indent=2))


if __name__ == '__main__':
    main()
