# Independent audit addendum: final counterexample-order bound 67

**Verdict: PASS for `addendum67.tex` / `addendum67.md`. Not a full closure.**

Read together with `AUDIT.md`, the final audited Round 08 conclusion is:

- the original conjecture holds for **h <= 8 or h >= 44**;
- any counterexample has **9 <= h <= 43**;
- any counterexample has a connected counterexample representative of
  **order at most 67** (at most 65 when h is even).

The intermediate bounds 153 and 132 are superseded. No graph census through
order 67, no resolution of the residual h range, and no new proof of the
already published domination bounds is being claimed.

## 1. Exact prior input and proof audit

The source is DeLaVina, Goddard, Henning, Pepper and Vaughan,
*Bounds on the k-Domination Number of a Graph*, Applied Mathematics Letters
24(6) (2011), 996--998. Its
[publisher record](https://www.sciencedirect.com/science/article/pii/S0893965911000188)
confirms the publication metadata. The locally retrieved author manuscript,
dated 5 January 2011, was read in full; PDF pages 2--4 were visually checked.
The source and its hashes are recorded in `prior2011_provenance.json`, without
redistributing the full third-party paper.

The required specialization of Theorem 5 is
`gamma_2 <= (n+alpha(G[L]))/2`, where L consists of vertices of degree at
most two. Its hypothesis excludes adjacent vertices of degree below two.
Connectedness and n>2 satisfy it: there are no isolates or adjacent leaves.

The needed k=2 proof was audited, including its implicit gadget
normalization. Each attached K3,3 requires at least three selected gadget
vertices. More than three can be replaced by one full part and its
attachment vertex without increasing cost. With exactly three and the
attachment vertex unselected, a full part is forced; if it is selected,
replacement by a full part is harmless. Hence the required one selected
gadget neighbor can be arranged. The remaining degree-deficit comparisons
and cardinality subtraction are valid. The minimum-degree-three half-order
input also follows directly from maximum cut. Theorem 3's alternating-path
construction was checked: its bipartite vertex cover has the matching's
size, and adjoining L supplies the required selected neighbors.

Thus neither theorem is being accepted merely because it appears in a
paper. The addendum uses the precise 2011 hypotheses and correctly credits
both results.

## 2. Independent connected-case confirmation of the low-degree bound

For additional independence from the compressed gadget argument, the bound
needed here has the following elementary verification. This is an audit
cross-check of a credited bound, not a claim of a new theorem or method.

Assume h>0. The induced graph G[L] is a disjoint union of paths, because
an all-degree-two cycle would be a whole connected component. Start with
a maximum cut and keep the high-degree vertices' sides fixed. A low-degree
path with p>=2 vertices has either one leaf endpoint and one high-degree
attachment, or two high-degree attachments. It cannot have two leaf
endpoints, which would be the whole connected graph and give h=0.

In the first case, alternate along the path, making all its edges,
including the edge to the high vertex, cross. All p-1 nonleaf path vertices
then have two crossing neighbors. In the second case, the fixed boundary
colors allow either every edge to cross or all but one to cross. If one
uncut edge is necessary, place it at a high-degree boundary. At least p-1
low vertices then have two crossing neighbors. These choices maximize the
number of crossing edges in that path for the fixed high-vertex colors.
The old global maximum cut already attained that local maximum, so all
these reorientations preserve global maximality. Isolated low vertices
require no contribution.

Each p-vertex path has vertex-cover number floor(p/2), at most p-1 for
p>=2. Thus at least `tau(G[L])` low-degree vertices can simultaneously be
made to have two crossing neighbors. Every high-degree vertex still has
two crossing neighbors by global cut maximality. The eligible vertices on
either cut side are omittable, giving

`k >= ceil((h+tau(G[L]))/2)`.

This independently confirms exactly the low-degree consequence required
for all residual graphs, whose h is at least nine.

## 3. Low-degree consequences and the credited matching condition

Using `alpha(G[L])=|L|-tau(G[L])` in the prior bound gives
`tau(G[L])<=2k-h`. There is no reversal of an inequality or confusion
between vertex-cover number and triangle count. Counterexample parity
therefore gives zero in the even case and at most one in the odd case.

For even h, L is independent. All degree-two vertices are simultaneously
omittable, so `n_2<=k`, and every leaf has a high-degree neighbor.

For odd h, deleting at most one low-degree cover vertex leaves at least
`n_2-1` independent degree-two vertices, so `n_2<=k+1`. There can be at
most one leaf adjacent to a degree-two vertex. Two such low-degree edges
would either be disjoint, requiring a cover of size two, or share their
degree-two endpoint. The latter gives a whole P3 component; sharing a
leaf is impossible. Both alternatives contradict the stated scope.

The additional matching condition is also valid. Theorem 3 gives
`k>=h-mu(H)`. With `k=ceil(h/2)` and the trivial
`mu(H)<=floor(h/2)`, equality follows. No minimum-degree condition on H
has been assumed. A perfect/near-perfect core matching is a credited
necessary condition, not a new closure and not a premise silently used
in the earlier kernel enumeration.

## 4. The stronger leaf deletion: why k is preserved

**Valid, and materially different from retaining two leaves everywhere.**
For any deleted leaves, every omission set of the smaller graph remains
omittable in the original graph after the deleted vertices are restored
as selected. Therefore `k(G')<=k(G)`.

In the proposed deletion, h is explicitly preserved. The maximum-cut bound
then gives `k(G')>=ceil(h/2)=k(G)` for a hypothetical counterexample.
Hence k is unchanged. Preservation of k is derived, not assumed from the
old two-leaf trimming lemma. Preserving T consequently preserves
`|T|>2k`. The remaining graph is connected and has at least h>=9 vertices,
so the original target's connectivity and order conditions remain valid.

Deleting a leaf changes no triangle at any remaining vertex. The only
triangle-count value that can disappear from T is zero, so retaining a
single zero witness whenever necessary is sufficient.

## 5. Odd case: at most one leaf and order at most 67

All h high-degree vertices have triangle count at least two. Two distinct
triangles at a vertex require at least three distinct neighbors belonging
to triangles, hence at least three nonleaf neighbors. Deleting every
high-adjacent leaf therefore leaves each of these vertices high-degree.
No degree-two vertex loses an incident edge in this deletion.

There is at most one degree-two-supported leaf. If it exists, it already
retains zero in T. If none exists, either some surviving vertex already
has triangle count zero or one high-adjacent leaf can be retained as its
witness. Thus at most one leaf remains in total, not one leaf in addition
to a degree-two-supported leaf.

Connectedness, h, n_2 and T are preserved; Section 4 supplies k preservation.
The resulting counterexample has

`n <= h+n_2+1 <= h+k+2 <= 43+22+2 = 67`.

## 6. Even case: at most two leaves and order at most 65

At least h-1 high-degree vertices have triangle count at least two, so
all their leaf neighbors can be deleted while retaining degree at least
three. There is at most one exceptional high vertex x. It has at least
one nonleaf neighbor: otherwise it and its leaf neighbors would form the
whole connected graph, a star with h=1. Thus retaining only enough leaves
to keep x's degree at least three requires at most two leaves.

There are no degree-two-supported leaves. If any leaves are retained at
x, they already preserve the value zero; no additional zero-witness leaf
is needed. If none are retained, at most one leaf elsewhere is needed.
Thus the total is at most two, not three. No high vertex is reclassified
as degree two, and no original degree-two vertex changes degree.

The same monotonicity/cut argument preserves the counterexample, and

`n <= h+n_2+2 <= h+k+2 <= 42+21+2 = 65`.

Combining the two parities proves equivalence to the restriction n<=67.
It does not prove that the remaining finite restriction is true.

## 7. Independent controls and final status

`check_addendum_independent.py` checked both prior numerical bounds by
unrestricted omission/independent-set searches and a separate exact
matching recursion on **27,474** connected labeled graphs of orders 3--6
and **300** fixed-seed leaf extensions. It also verified:

- **8,777** applicable extremal low-cover structures;
- **24,221** degree-preserving minimal leaf deletions;
- **8,480** extremal cases where deletion preserves k by the cut bound;
- **5,579** even and **4,531** odd triangle-count shape cases with the
  claimed final leaf bound;
- all **54** locally feasible K3,3 gadget selections, confirming the
  normalization used when auditing the prior proof;
- the final parity maxima **65** and **67** over 9<=h<=43.

These are controls, not a finite substitute for the above universal
arguments. The output is `independent_addendum_results.json`.

**Final audit status: PASS, partial progress only, representative bound 67.**
No new kernel sweep is necessary: the h range is unchanged and the new
argument only simplifies a hypothetical counterexample after that range
has already been established. No remaining gap or dependency uncertainty
was found in the final addendum.
