# Independent audit: partial WOWII 384b reduction, frozen Round 08 version

**Later audited strengthening:** read this frozen 217-bound report together
with `ADDENDUM67_AUDIT.md`. The final representative-order bound is **67**;
the unresolved range remains 9<=h<=43. Neither document claims full closure.

**Verdict: PASS for the stated partial results. This is NOT a full closure of 384b.**

The audited manuscript proves the original inequality for every connected
simple graph of order greater than two with **h <= 8 or h >= 44**, where h
counts vertices of degree at least three. Any counterexample therefore has
**9 <= h <= 43**, and has a leaf-trimmed counterexample representative with
**n <= 217**. No exhaustive search of that residual finite problem is
performed or implied.

No mathematical or enumeration-completeness gap was found. The small-core
part is a computer-assisted proof, not a hand classification. This audit
independently recomputed its complete finite kernel verification using a
different certificate algorithm, and independently recomputed all exact
probabilistic margins. It is not proof-assistant verification, human peer
review, or worldwide priority certification.

## Frozen evidence and independence

The authoritative object is `round_08/twodomination/manuscript.tex`, frozen
here as `snapshots/manuscript217.tex`, with its corresponding Markdown
snapshot. The earlier Round 06 universal reduction and Round 07 h=7 proof
were read and preserved as separate snapshots. The original source row
384b and invariant definition 90 agree with the manuscript's use of
2-domination and the number of distinct vertex triangle counts.

The candidate implementations read in full were:

- `check_384b_kernels.py` (h <= 6);
- `certify_core7_coverage.cpp`, `verify_384b_h7.py`;
- `verify_384b_h8.cpp`;
- `check_384b_alteration.py`, `check_384b_hypergeometric.py`.

The audit's two new programs import none of these implementations. All
author-supplied kernel counts and exact margins were reproduced. The mask
file actually checked is copied into this directory and has SHA-256
`de8140ae11b1d575d725febccb6140aefaea77bbce7880d78283bb63b9e5486a`, identical
to the Round 07 and Round 08 copies and the h=7 result's recorded hash.
Complete artifact hashes appear in `SHA256SUMS`.

The frozen version stops at n <= 217. Proposed later structural extensions
are outside this audit, avoiding a moving target.

## 1. Original target, maximum cut, and counterexample parity

**Valid.** A set S can be omitted from a 2-dominating set precisely when
every vertex in S has at least two neighbors outside S. Thus its maximum
size is `k=n-gamma_2`, and the original target is exactly `t<=2k`.

In a maximum cut, moving one vertex cannot increase the cut, so each vertex
has at least half its neighbors across it. Each degree-at-least-three
vertex consequently has at least two crossing neighbors. The high-degree
vertices on either side form an omittable set; choosing the larger side
gives `k>=ceil(h/2)`. Every other vertex has triangle count zero or one,
so `t<=h+2`.

Together with `2k<t`, these bounds force:

- even h: `k=h/2`, with `t=h+1` or `h+2`;
- odd h: `k=(h+1)/2`, with `t=h+2`.

In the odd case all h high-degree triangle counts are distinct and at
least two. In the even case at least h-1 high-degree vertices have
pairwise distinct triangle counts at least two. These are the precise
frequency facts used later; no assumption that all graphs must have
repeated triangle counts is made.

For h=0, connectedness and n>2 leave a path or cycle. All vertex triangle
counts are equal, so t=1; a degree-two vertex exists and can be omitted.
This handles the degenerate core case separately and correctly.

## 2. Triangle kernel and certificate lifting

**Valid.** When h>0, a triangle with three degree-two vertices would be an
entire connected component, impossible here. A triangle not wholly inside
H therefore has exactly one of the two stated forms: two private
degree-two vertices at one high-degree root, or one private degree-two
vertex at an edge of H. A degree-two vertex in a triangle has no unused
incident edge, so different attachment gadgets cannot overlap in their
private vertices or have unaccounted cross-edges.

Omitting one private vertex per pendant triangle and every edge-attachment
vertex gives `P+Q<=k`. The induced kernel has order
`h+2P+Q<=h+2k`; for a counterexample h<=2k, this is at most 4k.

For a high-degree kernel vertex, the actual degree is at least
`b(v)=max(3,d_K(v))`; a private vertex has degree exactly two. With all
outside-kernel vertices selected, any S satisfying

`b(v)-|N_K(v) intersect S| >= 2` for every v in S

is omittable in the original graph. Thus b is a safe lower bound, not an
assumed equality or an unproved realizability assertion. The core itself
need not be connected. Enumerating abstract kernels that cannot occur in
a real counterexample only adds cases and is safe.

All excluded vertices have triangle count zero. Consequently the set of
high-degree counts together with zero and, when attachments exist, one is
a superset of the original triangle-count set. The use of `t*` as a
necessary-condition filter has the correct direction even if zero is not
actually present in a particular graph.

## 3. Even extremality forces matching attachments

**Valid.** With h even and k=h/2, each side of any maximum cut contains
exactly k high-degree vertices. A degree-two vertex cannot have two
crossing neighbors: adjoining it to the k high-degree vertices on its
side would give an omittable set of size k+1. Local cut optimality gives
at least one crossing neighbor, so it has exactly one.

A pendant triangle can be reoriented at its two private vertices while
keeping the root fixed. A maximum cut must already cut two of its edges;
orienting one private vertex with the root and the other alone still cuts
two edges and changes no other edge. The lone private vertex would have
two crossing neighbors, a contradiction.

The roots of every edge attachment must be on opposite cut sides. If a
high-degree vertex a met two attachment vertices x,y, let R be the k
high-degree vertices on a's side. The set `(R minus {a}) union {x,y}`
is omittable: x,y retain both high-degree neighbors, and neither is
adjacent to a remaining vertex of R. The old omissions lose no selected
neighbor; selecting a can only help them. Its size is k+1. This proves
that attachments have distinct endpoints, including exclusion of multiple
attachments on the same core edge.

The argument concerns the triangle attachments only. The stronger
all-degree-two assertion under discussion for a later round is not used.

## 4. Exhaustive certification of h <= 8

### Coverage and filters

**Valid and independently recomputed.** For h<=6, every one of the
`2^(h choose 2)` labeled cores is enumerated. Odd h permits every multiset
of at most k attachment types (vertices or present edges); even h requires
every core matching. The odd-h sum filter is necessary: distinct counts
at least two have sum at least `h(h+3)/2`, while each attachment increases
the sum of high-degree triangle counts by at most two. No other unproved
pruning criterion is used.

For h=7, the supplied 1,044 masks were independently relabeled by every
permutation, explicitly covering all **2,097,152** labeled 7-cores in
**5,261,760** permutation images. Nonisomorphism and the source catalogue's
completeness are not assumed.

For h=8, delete any vertex of any 8-core. Its remaining 7-core is isomorphic
to a covered representative; after that relabeling its deleted vertex has
one of 128 possible neighborhoods. Thus all 133,632 enumerated extensions
cover every 8-core up to isomorphism. Duplicates do not threaten coverage.
Relabeling preserves attachments, triangle counts, b, and the certificate.

### A different exact certificate algorithm

The independent C++ audit does not repeat the candidate's full-kernel
subset search. For a subset R of high-degree vertices, put

`c(v)=max(3,d_K(v))-2`.

If every v in R has at most c(v) core neighbors in R, then the largest
valid omission set with high-degree part R has size

`|R| + number of pendant attachments whose root avoids R`

`    + number of edge attachments whose two roots avoid R`.

Indeed, an omitted private degree-two vertex cannot neighbor an omitted
root. From a pendant attachment at most one private vertex can be omitted,
and one can always be omitted when its root avoids R. An edge-attachment
vertex can be omitted exactly when both roots avoid R. All eligible
choices are mutually compatible and add no omitted neighbor to R.
Conversely, no valid omission with high part R can include more private
vertices. This proves the formula exactly.

The audit enumerates all at most 256 high subsets R and uses this formula.
A size at least k+1 suffices, because omission feasibility is hereditary
under taking subsets. The candidate enumerates explicit size-(k+1)
subsets of the whole kernel instead. The independent implementation also
counts triangles by direct triples, rather than common-neighbor sums,
and generates matchings by increasing edge indices plus disjointness,
rather than the candidate's first-remaining-vertex recursion.

### Reproduced counts

| h | Core inputs | Attachment patterns | Critical patterns | Failures |
|---|---:|---:|---:|---:|
| 1 | 1 | 2 | 0 | 0 |
| 2 | 2 | 3 | 0 | 0 |
| 3 | 8 | 0 | 0 | 0 |
| 4 | 64 | 304 | 0 | 0 |
| 5 | 1,024 | 24,416 | 1,800 | 0 |
| 6 | 32,768 | 708,608 | 25,920 | 0 |
| 7 | 1,044 | 2,446,446 | 61,253 | 0 |
| 8 | 133,632 | 17,150,528 | 857,204 | 0 |

For h=7, 170 representatives pass the sum filter. The zero h=3 pattern
count is correct: its maximum possible core triangle-count sum is three,
and `3+2k=7<9`. All **946,177** critical patterns across the rows admit
the required certificate. These computations, coupled to the universal
reduction, constitute the computer-assisted h<=8 proof. They are not an
exhaustive graph search through any particular total order.

The original implementations' bit shifts and counters also stay within
their types: h=8 kernels have at most 12 vertices, their high triangle
counts at most 22, and the mask coverage uses 21 bits. No floating-point
test, optimization oracle, or trusted graph-catalogue classification is
needed.

## 5. Independent-sampling alteration and h >= 52

**Valid.** Initially select all low-degree vertices and independently
select each high-degree vertex with probability p. Add every initially
unselected vertex with fewer than two selected neighbors. Any vertex not
added already had two initially selected neighbors, so simultaneous repair
produces a 2-dominating set.

For an unselected high-degree vertex of degree d, forcing its low-degree
neighbors selected only reduces repair probability compared with d
independent neighbors. Its unconditional repair probability is at most
`g_d=z^(d+1)+dpz^d`, where z=1-p. Hence
`k>=zh-sum(g_d)`. The identity
`g_d-g_(d+1)=d p^2 z^d>0` is correct. The elementary bound
`tau(v)<=(d(v) choose 2)` gives the required lower degree rho(tau(v)).

The odd/even triangle-count orderings from Section 1 justify precisely
the sums A_h and `B_h=g_3+A_(h-1)`. No independence between repair events
is required; linearity of expectation suffices.

For p=3/8, the audit independently used the expanded expression
`g_d=(5+3d)5^d/8^(d+1)` and recomputed

- `E_52 = 3607919267/34359738368 > 0`;
- `O_53 = 3547612629/34359738368 > 0`;
- uniform two-step increase at least
  `3367232921/17179869184 > 0`.

When h increases by two, the two new rho indices are at least 53, hence
rho>=11. Therefore the displayed positive increment proves every larger
case by parity induction. This is a universal proof, not an inference from
checking finitely many large h values.

## 6. Fixed-cardinality alteration and h = 44,...,51

**Valid, including the potentially delicate forced-neighbor comparison.**
Conditioned on v not being selected, the s selected high-degree vertices
are a uniform s-subset of the other h-1 high vertices. If degree d<=h-1,
replace each forced-selected low neighbor, for comparison only, with a
different high-degree nonneighbor. There are enough nonneighbors because
`d<=h-1`. For every sampled set, the actual number of selected neighbors
is at least the comparison number. Thus the hypothetical d-high-neighbor
hypergeometric repair probability is a valid upper bound.

If d>=h-1, write a for the number of high neighbors and r=d-a for forced
low neighbors. At most h-1-a selected high vertices can be nonneighbors,
so the selected-neighbor count is at least

`s-(h-1-a)+r = s+d-(h-1) >= s >= 2`.

The repair probability is zero, exactly as the capped formula states.
At the boundary d=h-1 the two arguments agree. Monotonicity follows by
coupling nested comparison neighbor sets; the cap then remains zero.

The audit independently simplified the unconditional repair probability to

`[C(h-1-d,s)+d C(h-1-d,s-1)] / C(h,s)` for d<h-1,

and zero otherwise. This is algebraically equivalent to the candidate's
conditional formula but was computed separately with exact integers.
Applying the triangle-count ordering and summing expectations gives all
eight claimed strict margins exactly:

| h | s | Strict margin |
|---|---:|---|
| 44 | 16 | 1745160/12198197 |
| 45 | 16 | 1763081/12198197 |
| 46 | 17 | 36171337/109383285 |
| 47 | 17 | 479277388/1339779509 |
| 48 | 17 | 16780745963/32154708216 |
| 49 | 18 | 337323149/617148728 |
| 50 | 18 | 75018443/101504725 |
| 51 | 18 | 78679171/101504725 |

The thresholds are h/2 for even h and (h-1)/2 for odd h. They are the
numbers of selected high vertices corresponding to the alleged
counterexample's k. A strictly smaller expectation guarantees some
outcome with more than k omissions, a contradiction. Rounding or equality
at the threshold is not being used incorrectly.

## 7. Degree-two bound, leaf trimming, and n <= 217

**Valid.** When h>0, the degree-two induced subgraph has maximum degree
two and cannot have a cycle, because such a cycle would be an entire
connected component. It is a disjoint union of paths and isolated
vertices. Its larger bipartition class is independent of size at least
`ceil(n_2/2)` and is omittable, proving `n_2<=2k`.

Leaves can never be omitted. At a high-degree vertex retaining two leaves,
those leaves alone already provide its two selected neighbors whenever
the vertex is omitted. Deleting any additional leaves therefore preserves
feasibility of every omission subset of the remaining nonleaf vertices,
in both directions. Thus k, not merely one inequality for k, is preserved.

With h>=2, a high-degree leaf support has a nonleaf neighbor; otherwise the
whole connected graph is a star with h=1. Keeping two leaves consequently
keeps its degree at least three. No other nonleaf degree changes, so h and
n_2 are preserved. Triangles are unchanged, and if zero-count leaves are
deleted, some remain, preserving the distinct count set T. Connectedness
also remains. A degree-two vertex has at most one leaf neighbor in this
scope, giving at most `2h+n_2` leaves after trimming.

Any counterexample now has `9<=h<=43`, `k=ceil(h/2)<=22`, and `n_2<=44`.
The trimmed graph is still a counterexample and satisfies

`n <= h+n_2+(2h+n_2) <= 3h+4k <= 3*43+4*22 = 217`.

Although deleting mandatory selected leaves changes both n and gamma_2,
their difference k is preserved, which is exactly what the original
inequality needs. Therefore reduction to order at most 217 is a genuine
logical equivalence, not an assumption about a smallest graph's shape.

## 8. Additional independent sanity checks and reproduction

`check_reductions_independent.py` exhaustively checked all **27,474**
connected labeled graphs of orders 3 through 6, plus **300** fixed-seed
leaf-extension inputs. It independently computed maximum omissions by
unrestricted subsets and triangle counts by triples. Results include:

- **27,263** comparisons of the full-kernel optimum with the independent
  high-subset formula;
- **1,457** applicable even-extremality matching checks;
- **24,221** leaf-trimming checks, including **284** actual deletions;
- **44,688** exact local comparisons of forced-low-neighbor repair
  probabilities with the claimed fixed-size upper bound.

These extra graph/local tests are corroboration, not substitutes for the
universal arguments. The exhaustive abstract-kernel checks in Section 4
are, by contrast, the finite part of the computer-assisted theorem.

From this directory:

```sh
g++ -O2 -std=c++17 check_kernels_independent.cpp -o /tmp/audit384b
/tmp/audit384b core7_masks.txt
python3 check_reductions_independent.py
```

The audit run used GCC 14.2.0 and Python 3.12.14, standard libraries only.
Machine-readable results are `independent_kernel_results.json` and
`independent_reduction_results.json`; the kernel error log is empty.

## Final status

**Accepted as independently audited partial progress:** h<=8, h>=44, and
the counterexample representative bound n<=217. There is no uncovered
mathematical dependency or failed finite certificate in this frozen chain.

**Still unresolved in this work:** the residual cases 9<=h<=43. The full
original conjecture is not closed, and the finite-order reduction must not
be reported as if all connected graphs through order 217 were enumerated.
