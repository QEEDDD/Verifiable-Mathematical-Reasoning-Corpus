#!/usr/bin/env python3
"""Independent small-graph controls for the final 67-vertex addendum.
Imports only this audit's own earlier utilities, not candidate code.
"""
from collections import Counter
from itertools import combinations
from pathlib import Path
import json
import random
from check_reductions_independent import bits, connected, induced, max_omission, triangle_counts


def matching_number(adj):
    def search(remaining):
        if not remaining:
            return 0
        v = next(bits(remaining))
        rest = remaining & ~(1 << v)
        return max([search(rest)] + [1 + search(rest & ~(1 << w)) for w in bits(adj[v] & rest)])
    return search((1 << len(adj)) - 1)


def check(adj, stats):
    n = len(adj)
    deg = [x.bit_count() for x in adj]
    high = [v for v in range(n) if deg[v] >= 3]
    low = [v for v in range(n) if deg[v] <= 2]
    H, L = induced(adj, high), induced(adj, low)
    h = len(H)
    alpha = 0
    for S in range(1 << len(L)):
        if S.bit_count() > alpha and all(not (L[v] & S) for v in bits(S)):
            alpha = S.bit_count()
    cover = len(L) - alpha
    k = max_omission(adj)
    mu = matching_number(H)
    assert 2 * (n - k) <= n + alpha
    assert k >= h - mu
    assert cover <= 2 * k - h
    stats['prior_bounds_checked'] += 1
    if h and k == (h + 1) // 2:
        assert mu == h // 2
        n2 = deg.count(2)
        low_neighbor_leaves = sum(deg[next(bits(adj[v]))] == 2 for v in range(n) if deg[v] == 1)
        if h % 2 == 0:
            assert cover == 0 and n2 <= k and low_neighbor_leaves == 0
        else:
            assert cover <= 1 and n2 <= k + 1 and low_neighbor_leaves <= 1
        stats['extremal_low_cover_structures'] += 1
    if h < 2:
        return
    delete = set()
    for v in high:
        leaves = [w for w in bits(adj[v]) if deg[w] == 1]
        delete.update(leaves[2:])
    B = induced(adj, [v for v in range(n) if v not in delete])
    degree = [x.bit_count() for x in B]
    double_supports = [v for v, d in enumerate(degree) if d >= 3 and sum(degree[w] == 1 for w in bits(B[v])) == 2]
    Q = sum(1 << v for v in double_supports)
    assert all(degree[v] - (B[v] & Q).bit_count() >= 2 for v in double_supports)
    q = len(double_supports)
    assert q <= k
    high_leaves = sum(degree[next(bits(B[v]))] >= 3 for v, d in enumerate(degree) if d == 1)
    assert high_leaves <= h + q <= h + k
    stats['double_leaf_support_sets'] += 1
    if k == (h + 1) // 2:
        assert len(B) <= 2 * h + 2 * k + (2 if h % 2 else 0)
        stats['final_parity_order_bounds'] += 1
    # Stronger deletion: retain only the leaves needed to preserve high degree,
    # then restore one deleted leaf if that is necessary to preserve count zero.
    remove = set()
    for v in high:
        leaves = [w for w in bits(adj[v]) if deg[w] == 1]
        nonleaf_degree = deg[v] - len(leaves)
        needed = max(0, 3 - nonleaf_degree)
        assert needed <= len(leaves)
        remove.update(leaves[needed:])
    old_triangle_counts = triangle_counts(adj)
    remaining = [v for v in range(n) if v not in remove]
    if 0 in old_triangle_counts and all(old_triangle_counts[v] != 0 for v in remaining):
        assert remove
        remove.remove(min(remove))
        remaining = [v for v in range(n) if v not in remove]
    trimmed = induced(adj, remaining)
    newdegree = [x.bit_count() for x in trimmed]
    newk = max_omission(trimmed) if remove else k
    assert connected(trimmed)
    assert sum(d >= 3 for d in newdegree) == h
    assert newdegree.count(2) == deg.count(2)
    assert set(triangle_counts(trimmed)) == set(old_triangle_counts)
    assert newk <= k
    stats['minimal_degree_preserving_leaf_trims'] += 1
    if k == (h + 1) // 2:
        assert newk == k
        stats['extremal_k_preservation_after_strong_trim'] += 1
    if h % 2 and all(old_triangle_counts[v] >= 2 for v in high) and cover <= 1:
        assert newdegree.count(1) <= 1
        assert len(trimmed) <= h + k + 2
        stats['odd_critical_shape_leaf_bounds'] += 1
    if h % 2 == 0 and sum(old_triangle_counts[v] >= 2 for v in high) >= h - 1 and cover == 0:
        assert newdegree.count(1) <= 2
        assert len(trimmed) <= h + k + 2
        stats['even_critical_shape_leaf_bounds'] += 1


def gadget_controls():
    # F=K3,3 with attachment x adjacent to vertices 0 and 3.
    feasible = 0
    for selected_x in (False, True):
        for mask in range(64):
            selected = mask.bit_count()
            def neighbors(v):
                opposite = 56 if v < 3 else 7
                return (opposite & mask).bit_count() + (selected_x and v in (0,3))
            if not all(mask & (1 << v) or neighbors(v) >= 2 for v in range(6)):
                continue
            feasible += 1
            assert selected >= 3
            if selected == 3 and not selected_x:
                assert mask in (7, 56)
            # Replacing with a full part, adding x only if needed, never costs more.
            normalized_x = selected_x or selected > 3
            assert 3 + int(normalized_x) <= selected + int(selected_x)
    return feasible


def main():
    stats = Counter()
    by_order = {}
    for n in range(3, 7):
        edges = list(combinations(range(n), 2))
        count = 0
        for mask in range(1 << len(edges)):
            adj = [0] * n
            for i in bits(mask):
                u, v = edges[i]
                adj[u] |= 1 << v
                adj[v] |= 1 << u
            if connected(adj):
                check(adj, stats)
                count += 1
        by_order[n] = count
    rng = random.Random(384820261026)
    for _ in range(300):
        core_n = rng.randrange(2, 6)
        edges = [(v, rng.randrange(v)) for v in range(1, core_n)]
        for u, v in combinations(range(core_n), 2):
            if rng.randrange(3) == 0:
                edges.append((u, v))
        n = core_n
        for root in [0, 1]:
            for _ in range(rng.randrange(2, 5)):
                edges.append((root, n))
                n += 1
        adj = [0] * n
        for u, v in edges:
            adj[u] |= 1 << v
            adj[v] |= 1 << u
        check(adj, stats)
    parity_bounds = {'even': max(h+h//2+2 for h in range(9,44) if h%2==0),
                     'odd': max(h+(h+1)//2+2 for h in range(9,44) if h%2==1)}
    assert parity_bounds == {'even':65, 'odd':67}
    result = {'status':'PASS_PARTIAL_NOT_FULL_CLOSURE', 'connected_labeled_graphs_by_order':by_order,
              'leaf_extension_inputs':300, 'checks':dict(stats), 'feasible_local_gadget_states':gadget_controls(),
              'final_parity_bounds':parity_bounds, 'residual_h':[9,43], 'representative_order_bound':67,
              'finite_checks_are_controls_not_universal_proof':True}
    path = Path(__file__).with_name('independent_addendum_results.json')
    path.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__ == '__main__':
    main()
