// Independent WOWII 384b finite audit. No candidate implementation is imported.
// Triangle counts use triples; certificates enumerate only high-vertex subsets.
#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <numeric>
#include <stdexcept>
#include <vector>
using Mask = unsigned;
using Count = std::uint64_t;
struct Stats { Count cores=0, kept=0, patterns=0, critical=0, failures=0; };
struct Checker {
  int h, k;
  std::vector<Mask> adj, types, attachments, subsets;
  std::vector<int> base;
  Stats stats;
  explicit Checker(int order): h(order), k((order+1)/2), adj(order), base(order) {
    for(Mask r=0;r<(1u<<h);++r) subsets.push_back(r);
    std::sort(subsets.begin(),subsets.end(),[](Mask a,Mask b){
      return __builtin_popcount(a)>__builtin_popcount(b);
    });
  }
  bool certificate() {
    std::vector<int> capacity(h);
    for(int v=0;v<h;++v){
      int degree=__builtin_popcount(adj[v]);
      for(Mask roots:attachments) if(roots&(1u<<v))
        degree += (__builtin_popcount(roots)==1 ? 2 : 1);
      capacity[v]=std::max(3,degree)-2;
    }
    for(Mask r:subsets){
      int available=__builtin_popcount(r);
      for(Mask roots:attachments) if((r&roots)==0) ++available;
      if(available<k+1) continue;
      bool feasible=true;
      for(int v=0;v<h;++v) if((r&(1u<<v)) && __builtin_popcount(adj[v]&r)>capacity[v]){
        feasible=false; break;
      }
      if(feasible) return true;
    }
    return false;
  }
  void pattern(){
    ++stats.patterns;
    auto triangles=base;
    for(Mask roots:attachments) for(int v=0;v<h;++v) if(roots&(1u<<v)) ++triangles[v];
    std::uint64_t values=attachments.empty()?1u:3u;
    for(int x:triangles) values |= std::uint64_t(1)<<x;
    if(__builtin_popcountll(values)<=2*k) return;
    ++stats.critical;
    if(!certificate()){
      ++stats.failures;
      std::cerr<<"FAIL h="<<h<<" core";
      for(auto a:adj)std::cerr<<' '<<a;
      std::cerr<<" roots";for(auto a:attachments)std::cerr<<' '<<a;std::cerr<<'\n';
    }
  }
  // Nondecreasing attachment-type indices enumerate multisets exactly once.
  void multisets(std::size_t next){
    pattern();
    if(attachments.size()==static_cast<std::size_t>(k)) return;
    for(std::size_t j=next;j<types.size();++j){
      attachments.push_back(types[j]);multisets(j);attachments.pop_back();
    }
  }
  // Increasing edge indices with a disjointness test enumerate all matchings.
  void matchings(std::size_t next,Mask used){
    pattern();
    for(std::size_t j=next;j<types.size();++j) if((used&types[j])==0){
      attachments.push_back(types[j]);matchings(j+1,used|types[j]);attachments.pop_back();
    }
  }
  void run_core(const std::vector<Mask>& a){
    adj=a;++stats.cores;std::fill(base.begin(),base.end(),0);
    for(int u=0;u<h;++u)for(int v=u+1;v<h;++v)for(int w=v+1;w<h;++w)
      if((adj[u]&(1u<<v))&&(adj[u]&(1u<<w))&&(adj[v]&(1u<<w))){
        ++base[u];++base[v];++base[w];
      }
    if((h%2) && std::accumulate(base.begin(),base.end(),0)+2*k<h*(h+3)/2) return;
    ++stats.kept;types.clear();attachments.clear();
    if(h%2)for(int v=0;v<h;++v)types.push_back(1u<<v);
    for(int u=0;u<h;++u)for(int v=u+1;v<h;++v)if(adj[u]&(1u<<v))types.push_back((1u<<u)|(1u<<v));
    if(h%2)multisets(0);else matchings(0,0);
  }
  void print(){
    std::cout<<"{\"h\":"<<h<<",\"cores\":"<<stats.cores<<",\"cores_after_filter\":"<<stats.kept
      <<",\"patterns\":"<<stats.patterns<<",\"critical\":"<<stats.critical
      <<",\"failures\":"<<stats.failures<<"}";
  }
};
std::vector<Mask> graph(int h,Mask m){
  std::vector<Mask>a(h);unsigned bit=0;
  for(int u=0;u<h;++u)for(int v=u+1;v<h;++v,++bit)if(m&(1u<<bit)){a[u]|=1u<<v;a[v]|=1u<<u;}
  return a;
}
int main(int argc,char**argv){
  if(argc!=2) return 2;
  std::ifstream f(argv[1]);if(!f)return 2;
  std::vector<Mask> representatives;Mask x;
  while(f>>x){if(x>=(1u<<21))return 3;representatives.push_back(x);}
  if(!f.eof() || representatives.empty())return 3;
  // Coverage is checked without assuming representatives are distinct or exhaustive.
  std::vector<bool> covered(1u<<21,false);Count images=0;
  for(Mask r:representatives){
    auto a=graph(7,r);std::array<int,7> permutation{0,1,2,3,4,5,6};
    do{
      Mask out=0;int b=0;
      for(int u=0;u<7;++u)for(int v=u+1;v<7;++v,++b)
        if(a[permutation[u]]&(1u<<permutation[v])) out|=1u<<b;
      covered[out]=true;++images;
    }while(std::next_permutation(permutation.begin(),permutation.end()));
  }
  Count coverage=std::count(covered.begin(),covered.end(),true);
  if(coverage!=(1u<<21)){std::cerr<<"Incomplete coverage: "<<coverage<<'\n';return 4;}
  std::cout<<"{\n\"coverage\":{\"representatives\":"<<representatives.size()<<",\"permutation_images\":"<<images
    <<",\"labeled_cores\":"<<coverage<<"},\n\"records\":[\n";
  bool pass=true;
  for(int h=1;h<=8;++h){
    Checker c(h);
    if(h<=6){
      for(Mask m=0;m<(1u<<(h*(h-1)/2));++m)c.run_core(graph(h,m));
    } else if(h==7){
      for(Mask m:representatives)c.run_core(graph(7,m));
    } else {
      for(Mask m:representatives){
        auto base=graph(7,m);base.push_back(0);
        for(Mask neighborhood=0;neighborhood<128;++neighborhood){
          auto a=base;a[7]=neighborhood;
          for(int v=0;v<7;++v)if(neighborhood&(1u<<v))a[v]|=128;
          c.run_core(a);
        }
      }
    }
    c.print();std::cout<<(h==8?"\n":",\n")<<std::flush;
    pass=pass && !c.stats.failures;
  }
  std::cout<<"],\n\"status\":\""<<(pass?"PASS":"FAIL")<<"\",\n"
    <<"\"certificate_method\":\"high-vertex subsets plus all eligible private attachments\",\n"
    <<"\"scope\":\"h<=8 partial theorem, not full WOWII 384b closure\"\n}\n";
  return pass?0:1;
}
