#!/usr/bin/env python3
"""Independent rational and small-graph checks for the partial 384b reduction.
No candidate code is imported. Finite tests do not replace universal proofs.
"""
from collections import Counter
from fractions import Fraction as F
from itertools import combinations
from math import comb, isqrt
from pathlib import Path
import hashlib
import json
import random
import time


def bits(mask):
    while mask:
        b = mask & -mask
        yield b.bit_length() - 1
        mask ^= b


def connected(adj):
    seen, old = 1, 0
    while old != seen:
        old = seen
        for v in bits(old):
            seen |= adj[v]
    return seen == (1 << len(adj)) - 1


def max_omission(adj, lower=None):
    degrees = lower if lower is not None else [x.bit_count() for x in adj]
    best = 0
    for mask in range(1 << len(adj)):
        if mask.bit_count() > best and all(degrees[v] - (adj[v] & mask).bit_count() >= 2 for v in bits(mask)):
            best = mask.bit_count()
    return best


def triangle_counts(adj):
    t = [0] * len(adj)
    for a, b, c in combinations(range(len(adj)), 3):
        if adj[a] & (1 << b) and adj[a] & (1 << c) and adj[b] & (1 << c):
            t[a] += 1
            t[b] += 1
            t[c] += 1
    return t


def induced(adj, vertices):
    return [sum(1 << j for j, w in enumerate(vertices) if adj[v] & (1 << w)) for v in vertices]


def check_graph(adj, counters):
    n = len(adj)
    degree = [x.bit_count() for x in adj]
    H = [v for v in range(n) if degree[v] >= 3]
    h = len(H)
    k = max_omission(adj)
    triangles = triangle_counts(adj)
    t = len(set(triangles))
    assert 2 * k >= 2 * ((h + 1) // 2)
    assert t <= h + 2 and t <= 2 * k
    if not h:
        assert t == 1 and k >= 1
        return
    high = set(H)
    private = [v for v in range(n) if degree[v] == 2 and triangles[v] == 1]
    attachments = []
    for v in private:
        neighbors = list(bits(adj[v]))
        roots = [x for x in neighbors if x in high]
        if len(roots) == 2:
            attachments.append(tuple(roots))
        else:
            assert len(roots) == 1
            other = next(x for x in neighbors if x not in high)
            assert degree[other] == 2
            if v < other:
                attachments.append(tuple(roots))
    assert len(attachments) <= k
    assert degree.count(2) <= 2 * k
    vertices = H + private
    K = induced(adj, vertices)
    lower = [max(3, x.bit_count()) if i < h else 2 for i, x in enumerate(K)]
    actual_kernel_max = max_omission(K, lower)
    assert actual_kernel_max <= k
    # Independently validate the accelerated high-subset certificate formula.
    index = {v: i for i, v in enumerate(H)}
    root_masks = [sum(1 << index[v] for v in roots) for roots in attachments]
    high_formula_max = 0
    for R in range(1 << h):
        if all((K[v] & R).bit_count() <= lower[v] - 2 for v in bits(R)):
            high_formula_max = max(high_formula_max, R.bit_count() + sum(not (R & roots) for roots in root_masks))
    assert actual_kernel_max == high_formula_max
    counters['full_kernel_vs_high_subset_formula'] += 1
    if h % 2 == 0 and k == h // 2:
        assert all(len(roots) == 2 for roots in attachments)
        used = [v for roots in attachments for v in roots]
        assert len(used) == len(set(used))
        counters['even_extremal_matching_checks'] += 1
    if h >= 2:
        remove = set()
        for v in H:
            leaves = [w for w in bits(adj[v]) if degree[w] == 1]
            remove.update(leaves[2:])
        remaining = [v for v in range(n) if v not in remove]
        trimmed = induced(adj, remaining)
        newdegrees = [x.bit_count() for x in trimmed]
        assert connected(trimmed)
        assert sum(d >= 3 for d in newdegrees) == h
        assert newdegrees.count(2) == degree.count(2)
        assert set(triangle_counts(trimmed)) == set(triangles)
        if remove:
            assert max_omission(trimmed) == k
            counters['nontrivial_leaf_trims'] += 1
        assert newdegrees.count(1) <= 2 * h + newdegrees.count(2)
        counters['leaf_trim_checks'] += 1


def C(n, r):
    return comb(n, r) if 0 <= r <= n else 0


def rho(j):
    d = (1 + isqrt(1 + 8 * j)) // 2
    return max(3, d + (d * (d - 1) // 2 < j))


def bernoulli(d):
    # Expanded integer expression, independently of the candidate p/z code.
    return F((5 + 3 * d) * 5 ** d, 8 ** (d + 1))


def fixed(h, s, degree):
    if degree >= h - 1:
        return F(0)
    # Direct unconditional probability: denominator counts all s-subsets of H.
    return F(C(h - 1 - degree, s) + degree * C(h - 1 - degree, s - 1), C(h, s))


def arithmetic_checks():
    B52 = bernoulli(3) + sum((bernoulli(rho(j)) for j in range(2, 53)), F(0))
    A53 = sum((bernoulli(rho(j)) for j in range(2, 55)), F(0))
    E52 = F(52, 8) - B52
    O53 = F(53, 8) - A53 - F(1, 2)
    step = F(1, 4) - 2 * bernoulli(11)
    assert E52 == F(3607919267, 34359738368) > 0
    assert O53 == F(3547612629, 34359738368) > 0
    assert step == F(3367232921, 17179869184) > 0
    records = []
    for h, s in [(44,16), (45,16), (46,17), (47,17), (48,17), (49,18), (50,18), (51,18)]:
        lower_degrees = [rho(j) for j in range(2, h + 2)] if h % 2 else [3] + [rho(j) for j in range(2, h + 1)]
        expected = s + sum((fixed(h, s, d) for d in lower_degrees), F(0))
        threshold = h // 2
        margin = threshold - expected
        assert margin > 0
        records.append({'h': h, 's': s, 'threshold': threshold, 'expectation_bound': str(expected), 'margin': str(margin)})
    local_tests = 0
    for h in range(3, 21):
        for s in range(2, h):
            for a in range(h):
                for low in range(h + 3):
                    degree = a + low
                    if degree < 3:
                        continue
                    # Direct count for the actual a high and low forced neighbors.
                    bad = sum(C(a, q) * C(h - 1 - a, s - q) for q in range(s + 1) if q + low < 2)
                    actual = F(bad, C(h, s))
                    assert actual <= fixed(h, s, degree)
                    local_tests += 1
    return {'bernoulli_even_base': str(E52), 'bernoulli_odd_base': str(O53),
            'bernoulli_uniform_increment': str(step), 'fixed_cardinality': records,
            'exact_local_forced_neighbor_comparisons': local_tests}


def main():
    started = time.monotonic()
    counters = Counter()
    by_order = {}
    for n in range(3, 7):
        edges = list(combinations(range(n), 2))
        checked = 0
        for mask in range(1 << len(edges)):
            adj = [0] * n
            for i in bits(mask):
                u, v = edges[i]
                adj[u] |= 1 << v
                adj[v] |= 1 << u
            if connected(adj):
                check_graph(adj, counters)
                checked += 1
        by_order[n] = checked
        print(f'Completed n={n}: {checked}', flush=True)
    rng = random.Random(384820261026)
    # Force nontrivial leaf trimming while keeping exact enumeration inexpensive.
    for trial in range(300):
        core_n = rng.randrange(2, 6)
        edges = [(v, rng.randrange(v)) for v in range(1, core_n)]
        for u, v in combinations(range(core_n), 2):
            if rng.randrange(3) == 0:
                edges.append((u, v))
        n = core_n
        for root in [0, 1]:
            for _ in range(rng.randrange(2, 5)):
                edges.append((root, n))
                n += 1
        adj = [0] * n
        for u, v in edges:
            adj[u] |= 1 << v
            adj[v] |= 1 << u
        check_graph(adj, counters)
    here = Path(__file__).resolve().parent
    result = {'status': 'PASS', 'connected_labeled_graphs_by_order': by_order,
              'connected_graph_total': sum(by_order.values()), 'additional_leaf_extension_inputs': 300,
              'seed': 384820261026, 'checks': dict(counters), 'arithmetic': arithmetic_checks(),
              'audited_partial_scope': {'proved_h': 'h <= 8 or h >= 44', 'residual_h': [9,43], 'counterexample_order_bound': 217},
              'not_full_closure': True, 'elapsed_seconds': round(time.monotonic() - started, 3),
              'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (here / 'independent_reduction_results.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
