# Round 08 — focused source audit and applicable prior bounds

Checked 26 October 2026. This is a bounded primary-source audit, not a worldwide novelty certificate. The finite-order reduction and new kernel computations are assessed separately by the mathematical auditors. No earlier full #384b resolution was found in the checked exact-target/equivalent-invariant searches; old O labels alone are not evidence of current openness.

## Attribution ready for the manuscript

**E. DeLaViña, C. E. Larson, R. Pepper and B. Waller**, *Graffiti.pc on the 2-domination number of a graph*, **Congressus Numerantium 203 (2010), 15–32**. [Author manuscript](https://math1um.github.io/Research/r07.pdf).

Its Theorem 11 states the bound

`gamma_2(G) <= (n + alpha(G[S_2]))/2`,

where **n is the total order of G** and **S_2 contains every vertex of G of degree at most two, including all leaves**. Degrees are taken in G, not in the low-degree induced subgraph. This theorem is credited there to a 2010 manuscript of DeLaViña, Pepper and Vaughan. The author manuscript states n≥3; for an unambiguous fully proved later source use the following publication.

**E. DeLaViña, W. Goddard, M. A. Henning, R. Pepper and E. R. Vaughan**, *Bounds on the k-domination number of a graph*, **Applied Mathematics Letters 24(6) (2011), 996–998**, [DOI](https://doi.org/10.1016/j.aml.2011.01.013), [author manuscript](https://people.computing.clemson.edu/~goddard/papers/kDomination.pdf), dated 5 January 2011.

- **Lemma 7** gives the standard maximum-cut partition: every vertex has at least half of its neighbors across the partition. It is explicitly described as folklore. Thus the maximum-cut omission argument should not be presented as a new method.
- **Theorem 3:** for any positive integer k, with L={v:d_G(v)<2k−1}, `gamma_k(G) <= mu(G−L)+|L|`. The graph is finite simple; there is no minimum-degree assumption on G−L.
- **Theorem 5:** if no two vertices of degree less than 2k−2 are adjacent, then `gamma_k(G) <= (n+alpha(G[L]))/2`, with the same L. For **k=2 and connected n>2**, this extra hypothesis is automatic: two adjacent degree-one vertices would form a separate K2 component. It therefore supplies the exact low-degree bound needed here.
- **Corollary 4:** minimum degree at least 2k−1 implies `gamma_k(G)<=mu(G)`.

These are existing results, not new numbered closures.

## Direct consequences for the #384b residual kernel

Write H=G[{v:d_G(v)≥3}], h=|H|, L=V(G)\H and q=n−gamma_2(G). The residual extremality being used in this round has q=ceil(h/2).

1. Theorem 3 implies `q>=h−mu(H)`. Therefore a counterexample core must have `mu(H)=floor(h/2)` — a perfect matching when h is even and a near-perfect matching when h is odd. **No minimum-degree assumption on H is required.**
2. Theorem 5 implies `q>=ceil((h+tau(G[L]))/2)`, where tau is the ordinary vertex-cover number. Hence `tau(G[L])=0` for even h and `tau(G[L])<=1` for odd h. In the latter case all low-degree induced edges share a vertex; in particular at most one pendant triangle is possible. The worker may already derive or sharpen this structurally; attribute the underlying bound regardless.

These deductions are stated as applications of prior theorems. They are not an independent verification of the round's full finite-order equivalence.

## Bounds stronger than uniform random alteration in applicable cores

**C. Bujtás and S. Jaskó**, *Bounds on the 2-domination number*, **Discrete Applied Mathematics 242 (2018), 4–15**, [DOI](https://doi.org/10.1016/j.dam.2017.05.014), [primary preprint](https://arxiv.org/abs/1612.08301).

Theorem 1 supplies an explicit weight-assignment/linear-inequality certificate, with 41 families of inequalities; Corollary 1 gives:

| Global minimum degree of input graph | Upper bound on gamma_2 / order |
|---|---:|
| at least 6 | 456883/918298 < 0.498 |
| at least 7 | 140835095/301690439 < 0.467 |
| at least 8 | 292954593/665571713 < 0.441 |
| at least 9 | 60805963517/145812382205 < 0.418 |

The proof explicitly permits delta(G)≥d, not only regular graphs or connected graphs. These bounds cannot be applied using only original degrees of core vertices: **the induced graph being supplied must itself meet the minimum-degree hypothesis.**

A valid application is to H itself, keeping V(G)\H selected: `q>=h−gamma_2(H)`. Thus the published bounds exclude even-h extremal cores with delta(H)≥6; they also exclude odd h≥17 with delta(H)≥7, and odd h≥9 with delta(H)≥8. These are safe sufficient pruning conditions, not a resolution of all 9≤h≤51.

Caro–Pepper's *Degree Sequence Index Strategy*, [arXiv:1210.1805](https://arxiv.org/abs/1210.1805), Theorem 5.2 includes an upper index bound, but its index depends on extrema over **minimum k-dominating sets**. Its tractable Theorem 5.3 is a **lower** bound. It should not be mistaken for the requested ready-to-use degree-sequence upper bound.

Hoppen–Mansan's *Minimum 2-dominating sets in regular graphs*, Discrete Applied Mathematics 323 (2022), 268–285, [DOI](https://doi.org/10.1016/j.dam.2022.01.002), is asymptotic for random regular graphs and extends to sufficiently large girth. It is not a universal bound for the triangle-rich arbitrary kernels here.

## Triangle-degree structure and limitations

**Z. Berikkyzy et al.**, *Triangle-degree and triangle-distinct graphs*, **Discrete Mathematics 347(1) (2024), 113695**, [DOI](https://doi.org/10.1016/j.disc.2023.113695), [arXiv:2308.10978v2](https://arxiv.org/abs/2308.10978v2), 30 August 2023.

For a graph whose **every vertex has a different triangle count**, Theorem 5 gives Delta>sqrt(2n), delta≤n−1−(2n/3)^(1/3); if d-regular, also d≤n−sqrt(2n/3). Theorem 8 gives asymptotic lower edge bound (sqrt(2)/3)n^(3/2)(1−o(1)) and upper bound binom(n,2)−omega(n). Its lower-bound argument uses the cap `#{v:d(v)≤d}≤binom(d,2)+1`, essentially the degree-profile estimate already present in the alteration calculation.

**Do not apply full triangle-distinct theorems directly to H:** high-degree triangle counts in G include attachment contributions, and distinctness in G need not imply distinct triangle counts in H. The paper gives structural filters, not a #384b proof.

Current regular-case primary records were also verified: [Stevanović et al., arXiv:2401.10971](https://arxiv.org/abs/2401.10971) constructs regular examples of orders 21–27; [Hak–Kozerenko–Serdiuk, arXiv:2609.37978v3](https://arxiv.org/abs/2609.37978v3), revised **20 October 2026**, excludes regularity 8; [Zhang, arXiv:2610.08478](https://arxiv.org/abs/2610.08478), **6 October 2026**, gives existence at every regularity at least nine. None addresses the general attachment-offset residual kernel.

## Remaining #133/#189/#199: new prior partial, no full closure found

- **189:** [jomplox PR70](https://github.com/umaia1234/agentic-conjectures/pull/70), opened **25 October 2026, 09:45:49 UTC**, explicitly claims **partial** progress. At immutable head `8c4288df412f8aecadfb6998d0182abb42c21aea`, its written details give `n<=2 sigma+1+floor((sigma+1)^2/4)`, diameter≤2 and exact finite searches for sigma≤4 and n≤11. The diameter-two theorem is credited to Easwar–Johari, arXiv:2609.11719. The issue distinguishes Lean-checked bounds from unformalized search completeness and disclaims a full resolution. No Lean build or census rerun was performed in this source audit. Do not claim those order bounds or small-sigma computations as newly discovered here.
- **133:** July 2026 DomTheDeveloper [PR8](https://github.com/DomTheDeveloper/test-expo-app/pull/8) and [PR4](https://github.com/DomTheDeveloper/test-expo-app/pull/4) expressly retain the large-local-independence C4-free branch. Their C4-present branch and floor-average≤1 result are prior partials. The source's naked-square-bracket/floor ambiguity remains; these do not establish the unrounded version.
- **199:** the primary 2007 DeLaViña–Pepper–Waller paper [*Independence, Radius and Hamiltonian Paths*](https://www.uhd.edu/documents/academics/sciences/ind-radius-hamiltonian-pathsdec.pdf) states the exact induced-tree/connectivity conjecture as Conjecture 3. Expanded issue/PR and equivalent-formula searches found no full later solution. This bounded negative is not a global openness certificate.

Raw API responses, source retrieval hashes and primary-PDF extracts are saved beside this note for internal audit. **For the user bundle, include this note and the compact provenance records, not the full third-party papers.**
