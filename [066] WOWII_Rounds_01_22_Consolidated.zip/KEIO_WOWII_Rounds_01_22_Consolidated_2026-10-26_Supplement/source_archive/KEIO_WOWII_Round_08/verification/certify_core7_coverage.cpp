// Independent certificate: all 2^21 labeled graphs occur among relabelings
// of the supplied core masks. No graph-catalogue completeness is assumed.
#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <vector>
int main(int argc,char**argv){
 if(argc!=2){std::cerr<<"usage: certify_core7_coverage core7_masks.txt\n";return 2;}
 std::ifstream in(argv[1]);if(!in)return 2;
 std::vector<uint32_t> reps;uint32_t m;while(in>>m){if(m>=(1u<<21))return 3;reps.push_back(m);}
 int id[7][7];std::vector<std::pair<int,int>> edges;
 for(int i=0;i<7;i++)for(int j=i+1;j<7;j++){id[i][j]=id[j][i]=edges.size();edges.push_back({i,j});}
 std::vector<unsigned char> seen(1u<<21,0);std::array<int,7> p={0,1,2,3,4,5,6};
 uint64_t relabelings=0;
 do{
  uint32_t trans[21];
  for(int j=0;j<21;j++)trans[j]=1u<<id[p[edges[j].first]][p[edges[j].second]];
  for(uint32_t r:reps){uint32_t rr=0,b=r;while(b){int j=__builtin_ctz(b);b&=b-1;rr|=trans[j];}seen[rr]=1;relabelings++;}
 }while(std::next_permutation(p.begin(),p.end()));
 uint64_t covered=0;for(auto s:seen)covered+=s;
 std::cout<<"{\"representatives\":"<<reps.size()<<",\"relabelings\":"<<relabelings<<",\"labeled_cores_covered\":"<<covered<<",\"required\":"<<(1u<<21)<<",\"status\":\""<<(covered==(1u<<21)?"PASS":"FAIL")<<"\"}\n";
 return covered==(1u<<21)?0:1;
}
