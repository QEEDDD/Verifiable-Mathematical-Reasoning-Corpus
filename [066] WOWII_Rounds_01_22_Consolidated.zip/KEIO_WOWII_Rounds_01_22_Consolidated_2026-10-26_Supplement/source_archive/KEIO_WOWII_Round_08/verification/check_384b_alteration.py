#!/usr/bin/env python3
"""Exact rational checks for the universal 384b h>=52 alteration proof.
The induction, kernel reduction, and leaf trimming are mathematical proofs,
not claims that a finite parameter grid verifies infinitely many graphs.
"""
from fractions import Fraction as F
from pathlib import Path
import json
p=F(3,8);z=1-p

def g(d):return z**(d+1)+d*p*z**d

def rho(t):
    d=3
    while d*(d-1)//2<t:d+=1
    return d

def A(h):return sum((g(rho(t)) for t in range(2,h+2)),F(0))
def B(h):return g(3)+A(h-1)
E52=F(52,8)-B(52)
O53=F(53,8)-A(53)-F(1,2)
step=F(1,4)-2*g(11)
assert E52==F(3607919267,34359738368)>0
assert O53==F(3547612629,34359738368)>0
assert step==F(3367232921,17179869184)>0
assert B(52)==F(219730380125,34359738368)
assert A(53)==F(206905784875,34359738368)
for d in range(3,100):assert g(d)-g(d+1)==d*p*p*z**d>0
# Additional finite checks of the formulas, not the justification for induction.
checks=[]
for h in range(52,201):
    c=A(h) if h%2 else B(h)
    margin=F(h,8)-c-(F(1,2) if h%2 else 0)
    assert margin>0
    checks.append({'h':h,'margin':str(margin)})
result={'status':'PASS','scope':'Exact base cases and strictly positive parity-induction increment for all h>=52; no full resolution of 384b.', 'p':str(p),'even_base_h':52,'even_base_margin':str(E52),'odd_base_h':53,'odd_base_margin':str(O53),'uniform_two_step_margin_increment':str(step),'residual_h':[7,51],'counterexample_representative_order_bound':257,'supplementary_finite_h_checks':len(checks)}
Path(__file__).with_name('384b_alteration_checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
