#!/usr/bin/env python3
"""Exact fixed-cardinality alteration bounds; no graph search or rounding."""
from fractions import Fraction as F
from math import comb
from pathlib import Path
import json

def C(n,k):return comb(n,k) if n>=0 and 0<=k<=n else 0

def rho(t):
    d=3
    while d*(d-1)//2<t:d+=1
    return d

def repair(h,s,d):
    assert 2<=s<h
    d=min(d,h-1)
    return F(h-s,h)*F(C(h-1-d,s)+d*C(h-1-d,s-1),C(h-1,s))

expected=[F(1745160,12198197),F(1763081,12198197),F(36171337,109383285),F(479277388,1339779509),F(16780745963,32154708216),F(337323149,617148728),F(75018443,101504725),F(78679171,101504725)]
records=[]
for i,(h,s) in enumerate([(44,16),(45,16),(46,17),(47,17),(48,17),(49,18),(50,18),(51,18)]):
    vals=[rho(j) for j in range(2,h+2)] if h%2 else [3]+[rho(j) for j in range(2,h+1)]
    total=F(s)+sum((repair(h,s,d) for d in vals),F(0))
    threshold=F(h-1,2) if h%2 else F(h,2)
    margin=threshold-total
    assert margin==expected[i]>0
    assert all(repair(h,s,d)>=repair(h,s,d+1) for d in range(3,h))
    records.append(dict(h=h,selected_high_vertices=s,expected_selected_high_after_repair_upper_bound=str(total),forbidden_counterexample_threshold=str(threshold),strict_margin=str(margin)))
result={'status':'PASS','scope':'Universal sufficient bounds for each h=44,...,51; combined with the independent h>=52 proof excludes all h>=44. No full closure.','records':records,'combined_residual_h':[9,43],'counterexample_representative_order_bound':217}
Path(__file__).with_name('384b_hypergeometric_checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
