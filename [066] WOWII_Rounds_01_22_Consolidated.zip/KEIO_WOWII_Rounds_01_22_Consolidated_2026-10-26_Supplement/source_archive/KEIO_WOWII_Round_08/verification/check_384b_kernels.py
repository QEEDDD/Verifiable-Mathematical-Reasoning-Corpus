#!/usr/bin/env python3
"""Exhaust finite triangle kernels; proves infinite h<=6 classes via stated reduction.
No graph library, MILP, or floating point is used. See 384b_kernel_partial.tex.
"""
import itertools as it
import json
from pathlib import Path

def graph(h,mask):
    es=list(it.combinations(range(h),2));adj=[0]*h
    for i,(u,v) in enumerate(es):
        if mask>>i&1:adj[u]|=1<<v;adj[v]|=1<<u
    return adj

def tc(adj):
    return [sum((adj[v]&adj[w]).bit_count() for w in range(len(adj)) if adj[v]>>w&1)//2 for v in range(len(adj))]

def matchings(adj, remaining=None, edges=()):
    if remaining is None:remaining=(1<<len(adj))-1
    if not remaining:
        yield edges;return
    b=remaining&-remaining;u=b.bit_length()-1;rem=remaining^b
    yield from matchings(adj,rem,edges)
    ns=adj[u]&rem
    while ns:
        bv=ns&-ns;ns^=bv;v=bv.bit_length()-1
        yield from matchings(adj,rem^bv,edges+((u,v),))

def kernel(core,attachments):
    a=core[:]
    def edge(u,v):a[u]|=1<<v;a[v]|=1<<u
    for pair in attachments:
        if len(pair)==1:
            u=pair[0];v=len(a);a.extend([0,0]);edge(u,v);edge(u,v+1);edge(v,v+1)
        else:
            u,v=pair;w=len(a);a.append(0);edge(u,w);edge(v,w)
    return a

def omitted_set(adj,h,size):
    lower=[max(3,a.bit_count()) if v<h else a.bit_count() for v,a in enumerate(adj)]
    for vv in it.combinations(range(len(adj)),size):
        m=sum(1<<v for v in vv)
        if all(lower[v]-(adj[v]&m).bit_count()>=2 for v in vv):return list(vv)
    return None

def check(h):
    k=(h+1)//2;stats=dict(h=h,k=k,cores=0,attachment_patterns=0,critical_patterns=0,failures=[],examples=[])
    for mask in range(1<<(h*(h-1)//2)):
        core=graph(h,mask);base=tc(core);stats['cores']+=1
        if h%2:
            # A critical odd-h graph needs h distinct high counts, all at least 2.
            # Even if every attachment is on an edge, it adds at most two to their sum.
            if sum(base)+2*k<h*(h+3)//2:continue
            types=[(u,) for u in range(h)]+[(u,v) for u in range(h) for v in range(u+1,h) if core[u]>>v&1]
            patterns=(a for b in range(k+1) for a in it.combinations_with_replacement(types,b))
        else:patterns=matchings(core)
        for attachments in patterns:
            stats['attachment_patterns']+=1
            high=base[:]
            for pair in attachments:
                for v in pair:high[v]+=1
            t=len(set(high)|({0,1} if attachments else {0}))
            if t<=2*k:continue
            stats['critical_patterns']+=1
            adj=kernel(core,attachments)
            witness=omitted_set(adj,h,k+1)
            record=dict(core_mask=mask,attachments=[list(x) for x in attachments],high_triangle_counts=high,omitted=witness)
            if witness is None:stats['failures'].append(record)
            elif len(stats['examples'])<5:stats['examples'].append(record)
    stats['status']='PASS' if not stats['failures'] else 'UNRESOLVED_KERNELS'
    return stats

if __name__=='__main__':
    records=[]
    for h in (1,2,3,4,5,6):
        r=check(h);records.append(r)
        print(h,r['cores'],r['attachment_patterns'],r['critical_patterns'],len(r['failures']),flush=True)
    result={'scope':'All connected simple graphs with at most six vertices of degree at least three, subject to the proved kernel reduction; not all graphs.','status':'PASS' if all(r['status']=='PASS' for r in records) else 'UNRESOLVED_KERNELS','records':records}
    path=Path(__file__).with_name('384b_kernel_checks.json');path.write_text(json.dumps(result,indent=2)+'\n')
