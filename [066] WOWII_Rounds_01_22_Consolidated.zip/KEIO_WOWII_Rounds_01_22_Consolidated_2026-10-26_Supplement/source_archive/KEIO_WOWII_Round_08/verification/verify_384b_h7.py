#!/usr/bin/env python3
"""Verify triangle kernels for h=7 after independent representative coverage.
No graph library, MILP, or floating point is used. See 384b_kernel_partial.tex.
"""
import itertools as it
import json
from pathlib import Path

def graph(h,mask):
    es=list(it.combinations(range(h),2));adj=[0]*h
    for i,(u,v) in enumerate(es):
        if mask>>i&1:adj[u]|=1<<v;adj[v]|=1<<u
    return adj

def tc(adj):
    return [sum((adj[v]&adj[w]).bit_count() for w in range(len(adj)) if adj[v]>>w&1)//2 for v in range(len(adj))]

def matchings(adj, remaining=None, edges=()):
    if remaining is None:remaining=(1<<len(adj))-1
    if not remaining:
        yield edges;return
    b=remaining&-remaining;u=b.bit_length()-1;rem=remaining^b
    yield from matchings(adj,rem,edges)
    ns=adj[u]&rem
    while ns:
        bv=ns&-ns;ns^=bv;v=bv.bit_length()-1
        yield from matchings(adj,rem^bv,edges+((u,v),))

def kernel(core,attachments):
    a=core[:]
    def edge(u,v):a[u]|=1<<v;a[v]|=1<<u
    for pair in attachments:
        if len(pair)==1:
            u=pair[0];v=len(a);a.extend([0,0]);edge(u,v);edge(u,v+1);edge(v,v+1)
        else:
            u,v=pair;w=len(a);a.append(0);edge(u,w);edge(v,w)
    return a

def omitted_set(adj,h,size):
    lower=[max(3,a.bit_count()) if v<h else a.bit_count() for v,a in enumerate(adj)]
    for vv in it.combinations(range(len(adj)),size):
        m=sum(1<<v for v in vv)
        if all(lower[v]-(adj[v]&m).bit_count()>=2 for v in vv):return list(vv)
    return None


def verify_h7():
    import hashlib
    h=7;k=4
    raw=Path(__file__).with_name('core7_masks.txt').read_bytes()
    reps=list(map(int,raw.split()))
    stats=dict(h=h,k=k,representatives=len(reps),source_sha256=hashlib.sha256(raw).hexdigest(),cores_after_triangle_sum_filter=0,attachment_patterns=0,critical_patterns=0,failed_kernels=[])
    for mask in reps:
        core=graph(h,mask);base=tc(core)
        if sum(base)+2*k<h*(h+3)//2:continue
        stats['cores_after_triangle_sum_filter']+=1
        types=[(u,) for u in range(h)]+[(u,v) for u in range(h) for v in range(u+1,h) if core[u]>>v&1]
        for b in range(k+1):
            for attachments in it.combinations_with_replacement(types,b):
                stats['attachment_patterns']+=1
                high=base[:]
                for pair in attachments:
                    for v in pair:high[v]+=1
                t=len(set(high)|({0,1} if attachments else {0}))
                if t<=2*k:continue
                stats['critical_patterns']+=1
                adj=kernel(core,attachments)
                witness=omitted_set(adj,h,k+1)
                if witness is None:stats['failed_kernels'].append(dict(core_mask=mask,attachments=attachments,high_triangle_counts=high))
    stats['status']='PASS' if not stats['failed_kernels'] else 'FAIL'
    return stats

if __name__=='__main__':
    stats=verify_h7()
    Path(__file__).with_name('384b_h7_kernel_checks.json').write_text(json.dumps(stats,indent=2)+'\n')
    print(json.dumps(stats,indent=2))
    assert stats['status']=='PASS'
