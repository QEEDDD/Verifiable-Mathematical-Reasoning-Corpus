// Exhaust all 8-vertex core extensions of the independently covered 7-cores,
// then all matchings of triangle attachments (even-parity extremality lemma).
#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <vector>
using U=uint32_t;
uint64_t cores=0,patterns=0,critical=0,failed=0;
std::array<U,8> core;std::array<int,8> triangles;
std::vector<std::pair<int,int>> matching;
bool omission(std::vector<U>&adj){
 int n=adj.size();U all=1u<<n;
 std::vector<int> degree(n);for(int i=0;i<n;i++)degree[i]=std::max(i<8?3:2,__builtin_popcount(adj[i]));
 // Gosper iteration over all cardinality-five masks.
 for(U s=31;s<all;){
  bool ok=true;U b=s;
  while(b){int v=__builtin_ctz(b);b&=b-1;if(degree[v]-__builtin_popcount(adj[v]&s)<2){ok=false;break;}}
  if(ok)return true;
  U c=s&-s,r=s+c;if(r>=all)break;s=(((r^s)>>2)/c)|r;
 }
 return false;
}
void visit(){
 patterns++;auto t=triangles;U vals=1u; // zero from possibly present low vertices
 if(!matching.empty())vals|=2u;
 for(auto e:matching){t[e.first]++;t[e.second]++;}
 for(int x:t)vals|=1u<<x;
 if(__builtin_popcount(vals)<=8)return;
 critical++;
 std::vector<U>a(core.begin(),core.end());
 for(auto [u,v]:matching){int w=a.size();a.push_back((1u<<u)|(1u<<v));a[u]|=1u<<w;a[v]|=1u<<w;}
 if(!omission(a)){
  failed++;
  if(failed<=5){std::cerr<<"UNRESOLVED core:";for(U b:core)std::cerr<<' '<<b;std::cerr<<" matching:";for(auto [u,v]:matching)std::cerr<<' '<<u<<','<<v;std::cerr<<'\n';}
 }
}
void match(U remaining){
 if(!remaining){visit();return;}
 int u=__builtin_ctz(remaining);U rem=remaining&~(1u<<u);match(rem);
 U ns=core[u]&rem;
 while(ns){int v=__builtin_ctz(ns);ns&=ns-1;matching.push_back({u,v});match(rem&~(1u<<v));matching.pop_back();}
}
int main(int argc,char**argv){
 if(argc!=2)return 2;std::ifstream in(argv[1]);if(!in)return 2;U mask;
 while(in>>mask){
  std::array<U,8>a{};int i=0;
  for(int u=0;u<7;u++)for(int v=u+1;v<7;v++,i++)if(mask>>i&1){a[u]|=1u<<v;a[v]|=1u<<u;}
  for(U hood=0;hood<128;hood++){
   cores++;core=a;core[7]=hood;for(int u=0;u<7;u++)if(hood>>u&1)core[u]|=128;
   for(int u=0;u<8;u++){int sum=0;for(int v=0;v<8;v++)if(core[u]>>v&1)sum+=__builtin_popcount(core[u]&core[v]);triangles[u]=sum/2;}
   match(255);
  }
 }
 std::cout<<"{\"h\":8,\"core_extensions\":"<<cores<<",\"matching_patterns\":"<<patterns<<",\"critical_patterns\":"<<critical<<",\"unresolved_kernels\":"<<failed<<",\"status\":\""<<(failed?"UNRESOLVED":"PASS")<<"\"}\n";
 return failed?1:0;
}
