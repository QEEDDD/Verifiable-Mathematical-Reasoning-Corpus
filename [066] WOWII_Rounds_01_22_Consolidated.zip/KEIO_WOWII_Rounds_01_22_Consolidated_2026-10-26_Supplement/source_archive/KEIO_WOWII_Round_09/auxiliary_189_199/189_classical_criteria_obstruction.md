# A small exact witness against two automatic proof routes

**Not a counterexample to WOWII 189.** The graph below is taken from the
previously public σ=4 Hamiltonian-path certificates of
[PR70](https://github.com/umaia1234/agentic-conjectures/pull/70), pinned at
`8c4288df412f8aecadfb6998d0182abb42c21aea`. Its graph6 identifier is
`K?BELqwptrvN`; the explicit edge list is in `repro/criterion_witness.json`.

The independent standard-library checker reconstructs that edge list and
computes all parameters from scratch:

* n=12, second-smallest degree σ=4;
* even-distance counts, including distance zero:
  (5,5,5,5,5,5,5,5,5,5,4,4), so the original 189 premise holds;
* α=5, attained by {0,1,2,3,4};
* κ=2, with minimum separating set {0,9}; hence α>κ+1;
* {2,3,4} is independent, and each of its vertices has the same neighborhood
  {7,8,10,11}, of size four. Therefore

      d(2)+d(3)+d(4)−|N(2)∩N(3)∩N(4)| = 8 < n−1 = 11.

Thus neither the Chvátal–Erdős traceability sufficient condition α≤κ+1 nor
the Flandrin–Jung–Li modified independent-triple sufficient condition is an
automatic consequence of the 189 hypothesis. For the latter condition and
the distinction between ordinary degree sum and degree sum minus the triple
intersection, see the statement in
[Bensmail, *A σ₃ condition for arbitrarily partitionable graphs* (2024)](https://geodesic.mathdoc.fr/item/DMGT_2024_44_2_a17/),
which attributes it to Flandrin, Jung and Li,
[*Hamiltonism, degree sum and neighborhood intersections* (1991)](https://doi.org/10.1016/0012-365X(91)90094-I).

The supplied path

    1,5,6,0,8,2,7,3,10,4,11,9

visits all twelve vertices and uses only edges. It is independently checked,
so this graph is explicitly traceable.

The broader discovery pass on the 2,243 two-connected n=12–13 graphs in the
credited certificate list found 220 failures of α≤κ+1 and 39 failures of the
modified-triple threshold. Those counts concern that source list only;
neither its exhaustive completeness nor a Lean proof of its enumeration is
claimed here. The single explicit graph suffices for both negative logical
conclusions, without reliance on census completeness.

Run `python repro/check189_criterion_witness.py`. It enumerates all independent
subsets and vertex cuts for this one graph, performs BFS from every vertex,
and verifies the displayed spanning path. No external library or download is
required.
