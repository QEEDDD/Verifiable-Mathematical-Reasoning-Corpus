# A tight even-distance family that defeats a connectivity–independence shortcut

**Not a counterexample to WOWII 189; no full conjecture closure or priority
claim.** This family was recognized by generalizing the structure of a graph
in the credited sigma=4 certificate list accompanying PR70.

For each integer s>=2, take disjoint cliques

    A={a0,a1,...,as},   B={b0,b1,...,bs},

and an independent set Z={z1,...,z_(s-1)}. Join every vertex of Z to every
vertex in A-{a0} and B-{b0}, and to neither a0 nor b0. There are no A-B edges.
Call the graph J_s.

## Exact parameters

- The order is n=3s+1.
- The two special vertices a0,b0 have degree s. Every ordinary clique vertex
  has degree 2s-1, and every Z vertex has degree 2s. Therefore the source's
  second-smallest degree, with multiplicity, is exactly s.
- Every vertex has exactly s+1 vertices at even distance, counting itself:
  - From a0, the even-distance vertices are a0 itself, all s-1 vertices of Z
    at distance two, and b0 at distance four. The case of b0 is symmetric.
  - From an ordinary A vertex, the even-distance vertices are itself and the
    s ordinary B vertices, at distance two. The case of B is symmetric.
  - From a Z vertex, they are itself, the other s-2 Z vertices, and a0,b0,
    all nonself listed vertices at distance two.
  Thus the original 189 hypothesis holds with equality at **every** vertex.
- The connectivity is s-1. Deleting Z disconnects the two cliques. Deleting
  fewer than s-1 vertices leaves a Z vertex, an ordinary vertex in each clique,
  and connected surviving clique pieces; these all connect through the
  surviving Z vertex. Every other surviving Z vertex also has an ordinary
  clique neighbor, so the remaining graph is connected.
- The independence number is s+1. Taking all of Z with a0,b0 attains this.
  An independent set containing a Z vertex can use at most the two specials
  from A union B; one containing no Z vertex has at most one vertex per clique.

Consequently, for every s>=3 the graph is 2-connected, has diameter four,
and has n>=2s+4, so it belongs to the unresolved-by-Easwar–Johari parameter
region. Yet

    alpha(J_s)=s+1=kappa(J_s)+2.

Therefore the original 189 hypothesis, even in that residual region, does not
imply the Chvatal–Erdos sufficient condition alpha<=kappa+1. A proof by deriving
that condition cannot work without additional cases.

## Explicit Hamiltonian path

Start with a0. For i=1,...,s-2, append ai,zi. Then append

    a_(s-1), as, z_(s-1), b1, b0, b2,...,bs.

Every consecutive pair is an edge, and every vertex occurs once. For s=2,
the initial loop is empty and the same terminal list gives

    a0,a1,a2,z1,b1,b0,b2.

Thus all J_s are traceable, as required by 189; they are not counterexamples.

## Relation to the current prior partial results

[PR70](https://github.com/umaia1234/agentic-conjectures/pull/70), head
`8c4288df412f8aecadfb6998d0182abb42c21aea`, records the quadratic **order upper
bound** n<=2s+1+floor((s+1)^2/4) under the hypothesis, and reports unformalized
exhaustive traceability checks for s<=4 and n<=11. The order bound is not itself
a traceability theorem below that threshold.

Its DETAILS note conjectural-looking data n<=3s+1 for s<=4 and supplies an
extremal circulant for even s. The family J_s attains 3s+1 for every s>=2,
including odd s. In particular J_5 has n=16 and second degree five. This is a
construction, not a proof of the proposed upper bound and not a new result
count in the original conjecture ledger.

The credited sigma4 list was used as input to `check189_ce_route.py`.
On its 2,243 two-connected graphs of orders12–13, independently computed alpha
and kappa violate alpha<=kappa+1 in 220 cases. Those finite calculations are
only the discovery aid; the infinite family above is verified by its direct
parameter proofs.

The self-contained finite guard is `repro/check189_extremal_family.py`. The cited broad certificate-list calculation is a discovery aid, not needed to verify the displayed family.
