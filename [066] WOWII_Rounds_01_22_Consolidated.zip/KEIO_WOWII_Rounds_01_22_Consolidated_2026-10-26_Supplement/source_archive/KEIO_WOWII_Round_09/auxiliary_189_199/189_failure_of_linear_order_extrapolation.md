# A Hamiltonian family beyond the auxiliary order bound n<=3sigma+1

**Scope: this refutes an auxiliary extrapolation, not WOWII 189 and not any
proved theorem in the cited prior work.** The prior sigma<=4 data attain
n=3sigma+1; that pattern cannot be extended to all sigma.

For every integer t>=2, replace the seven vertices of C7, in cyclic order, by
cliques of sizes

    (t,t,t,2t-1,2t-1,2t-1,t).

Join two bags completely exactly when the corresponding cycle vertices are
adjacent. Write G_t for the resulting graph.

## Exact verification of the original 189 hypothesis

The graph is connected and simple, with

    n = 10t-3.

A vertex in bag i has degree w_(i-1)+w_i+w_(i+1)-1. The seven bag degrees are

    (3t-1, 3t-1, 4t-2, 5t-3, 6t-4, 5t-3, 4t-2).

The first two bags each contain t>=2 vertices, so the second-smallest degree
with multiplicity is

    sigma = 3t-1.

Vertices in one bag are adjacent. For distinct bags, distances are the C7
quotient distances. The only positive even quotient distance is two. Hence a
vertex of bag i has exactly 1+w_(i-2)+w_(i+2) even-distance vertices, including
itself. The seven even-distance counts are

    (3t,3t,3t,3t,2t+1,3t,3t).

Since 2t+1<=3t for t>=1, max dist_even=3t=sigma+1. Thus G_t satisfies the exact
original premise of 189.

However,

    n-(3sigma+1) = (10t-3)-(9t-2) = t-1 > 0.

The violation is unbounded, with n/sigma tending to 10/3. At t=2, the graph
has n=17, sigma=5, and maximum even-distance count6; it exceeds 3sigma+1=16.
At t=3 it has n=27, sigma=8, and maximum even-distance count9.

## These graphs are Hamiltonian

List all vertices of bag0, then bag1, and so on through bag6. Consecutive
vertices inside a bag are adjacent, successive bags are completely joined,
and the last vertex of bag6 is adjacent to the first vertex of bag0. Thus
this order is a Hamiltonian cycle. None of these graphs is a counterexample
to 189.

## Prior-result distinction

The current prior [PR70](https://github.com/umaia1234/agentic-conjectures/pull/70),
head `8c4288df412f8aecadfb6998d0182abb42c21aea`, proves the quadratic order bound
n<=2sigma+1+floor((sigma+1)^2/4) and reports computational traceability results
for sigma<=4 and n<=11. Its DETAILS file observes n<=3sigma+1 in those low-sigma
data and discusses a possible improvement to that bound. The family above
starts at sigma5, so it contradicts neither the reported low-sigma data nor
the proved quadratic bound. It only prevents the unproved linear extrapolation
from being used in a full proof.

The first member was found by a numerical LP grammar, but the displayed
integer degree/distance formulas and Hamiltonian cycle prove every assertion
for the entire family without relying on the solver.

Run `python repro/check189_order_family.py` to independently reconstruct the graphs
for t=2,...,30, check every distance by BFS, and verify the spanning cycle.
No third-party Python library is needed. No novelty or full-closure claim is
made for this auxiliary observation.
