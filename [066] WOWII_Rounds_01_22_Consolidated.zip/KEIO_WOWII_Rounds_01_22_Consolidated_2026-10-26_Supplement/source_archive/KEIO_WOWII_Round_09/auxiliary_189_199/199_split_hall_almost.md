# A Hall-almost reduction for split graphs satisfying WOWII 199

**Status: proved necessary structural condition, not a proof of 199, even for
split graphs. No novelty claim. See ROOT_REVIEW.md for the separate coordinator review.**

Let G be a connected, noncomplete split graph with a fixed partition V=C∪I,
where C is a clique and I is independent. Let k=κ(G), and let τ(G) be the
maximum **vertex order** of an induced tree. Assume the original 199 premise
τ(G)≤k+2. Then

> For every J⊆I, |N_C(J)|≥|J|−1.

Equivalently, the bipartite incidence graph between I and C has a matching
covering all but at most one vertex of I. The equivalence follows by adding
one new vertex on the C side adjacent to every I vertex and applying Hall's
marriage theorem.

## 1. Exact split-graph parameters

Put A_c=N(c)∩I. Since G is connected and noncomplete,

    k = min_{i∈I} |N_C(i)| ≥ 1.

For the lower bound, deleting fewer than this many vertices leaves a clique
vertex and leaves every surviving I vertex with a clique neighbor. For the
upper bound, delete the neighborhood of a minimum-degree I vertex. This
separates it from another surviving vertex, except in the excluded complete
graph case.

An induced tree has at most two vertices of C, because three would form a
triangle. If it has one clique vertex c, its maximum possible order is
1+|A_c|. If it has two, c,d, its independent vertices are exactly a subset
of A_c△A_d: a common neighbor would create a triangle, and a vertex adjacent
to neither would disconnect it. All of A_c△A_d can be included, yielding a
double star. Consequently

    τ(G) = max({1} ∪ {1+|A_c|:c∈C}
                      ∪ {2+|A_c△A_d|:c,d∈C, c≠d}).

The empty maximum over pairs is simply omitted. The premise therefore gives

    |A_c|≤k+1,       |A_c△A_d|≤k.

## 2. Counting proof of the Hall-almost condition

Fix a nonempty J⊆I, and write h=|J| and q=|N_C(J)|. For each c∈N_C(J), put
B_c=A_c∩J. Then |B_c|≤k+1 and |B_c△B_d|≤k. Every i∈J belongs to
r_i=|N_C(i)| of these q sets, so k≤r_i≤q. Put E=Σ_i r_i. Counting incidences
gives

    kh ≤ E ≤ (k+1)q.                                      (1)

Counting, for each i, the pairs of sets in which i occurs in exactly one gives

    Σ_{c<d} |B_c△B_d| = Σ_{i∈J} r_i(q−r_i).

Because r_i≥k and q−r_i≥0, the right side is at least

    kΣ_i(q−r_i) = k(qh−E) ≥ kq(h−k−1).

The left side is at most kq(q−1)/2. Dividing by kq>0 yields

    h−k−1 ≤ (q−1)/2.                                    (2)

If h≥q+2, then (1) implies q≥2k, whereas (2) implies q≤2k−3.
This contradiction proves h≤q+1. The case J=∅ is immediate. ∎

## 3. What remains missing

A matching covering all but one I vertex does **not** by itself construct a
Hamiltonian path. In a spanning path, most independent vertices need two
distinct clique neighbors, and independently obtained matching or 2-matching
components must be joined without repeating vertices. No argument completing
those steps from the displayed symmetric-difference restrictions is supplied.

For a concrete warning, take three disjoint pairs C₁,C₂,C₃ whose union C is
a clique. For each j, add two independent vertices adjacent exactly to C_j.
There is a perfect I–C matching and |N_C(J)|≥|J| for every J⊆I, but there is
no spanning path. For each two-vertex module I_j, if neither I_j vertex is a
path endpoint, its four required incidences exhaust the total path-degree
capacity of the two C_j vertices; the module cannot connect to the rest.
Thus a spanning path would require at least one endpoint in each of three
modules, which is impossible. This warning graph does not satisfy 199:
κ=2 and τ=6>κ+2. It establishes only that the Hall conclusion alone cannot
close the remaining gap.

The direct finite guard `repro/check199_split_hall.py` checks the parameter
formula against induced-subset enumeration and checks the conclusion on
small incidence matrices. Those finite checks are not the proof above.
