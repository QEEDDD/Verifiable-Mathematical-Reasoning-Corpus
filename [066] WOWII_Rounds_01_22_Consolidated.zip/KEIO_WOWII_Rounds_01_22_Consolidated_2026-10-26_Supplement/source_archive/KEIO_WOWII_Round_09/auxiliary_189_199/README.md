# Round 09 — induced-subgraph / traceability checkpoint

## Outcome

**No original WOWII conjecture is closed by this checkpoint. Both 189 and 199
remain unresolved here.** The contents are proved auxiliary constructions,
a precisely scoped structural reduction, and reproducible obstructions to
specific proposed shortcuts. No worldwide novelty claim is made.

| Item | Exact conclusion | Limitation |
|---|---|---|
| C₇ clique blowups | For every t≥2, an 189-premise Hamiltonian graph has n=10t−3 and σ=3t−1; hence n−(3σ+1)=t−1>0. | Refutes only the unproved linear-order extrapolation, not 189 or PR70's quadratic theorem. |
| Two cliques plus independent connector set | For every σ≥2, an 189-premise traceable graph has n=3σ+1 and α=κ+2. For σ≥3 it is 2-connected and has diameter four. | Rules out automatically deriving α≤κ+1. |
| Exact prior 12-vertex graph | Satisfies 189, but fails both α≤κ+1 and the modified-triple threshold n−1. | Graph and its path are credited to the earlier PR70 certificate list. |
| Split-graph 199 reduction | The original 199 premise implies |N_C(J)|≥|J|−1 for all independent-side subsets J. | Matching almost all independent vertices does not yet construct a spanning path. |

The split-graph lemma and the symbolic families have received the separate
coordinator review in ROOT_REVIEW.md; the author-supplied checks were rerun. The
infinite-family statements are supported by direct formulas, not merely by
finite tests.

## Files

* `189_failure_of_linear_order_extrapolation.md`: the C₇ family, full formulas,
  and explicit Hamiltonian cycle.
* `189_extremal_family_and_ce_obstruction.md`: the J_σ family, exact α and κ,
  even-distance sets, and explicit Hamiltonian path.
* `189_classical_criteria_obstruction.md`: a fully explicit credited witness
  against two sufficient-condition routes.
* `199_split_hall_almost.md`: parameter derivation and double-counting proof,
  followed by the remaining gap.
* `sources.json`: exact source rows, definitions, prior-result attribution,
  and scope of the status search.
* `repro/`: four standard-library checks and their saved JSON outputs.
* `search_logs/`: optional numerical exploration scripts and terminal logs.
  **Negative numerical LP outputs are not formal impossibility certificates.**
* `verification_manifest.json`: hashes of the checkpoint files and status.

## Reproduce the exact guards

From this directory, with Python 3:

```sh
python repro/check189_order_family.py
python repro/check189_extremal_family.py
python repro/check189_criterion_witness.py
python repro/check199_split_hall.py
```

All four passed. Each infinite family is reconstructed for parameter values
2 through 30. The split guard examines 6,535 connected noncomplete incidence
matrices with 1≤|C|,|I|≤4 and total order at most seven; 763 satisfy the
premise, and all their 5,544 independent-side subsets satisfy the lemma.
For those 763 graphs, exhaustive induced-subset enumeration also verifies the
stated maximum-induced-tree formula.

Optional numerical search scripts require NetworkX, NumPy and SciPy. They are
included for method reproducibility, not as proof objects, and can take
minutes. Terminal runs found no cut obstruction in:

* 595,268 LP instances from 524 two-connected Atlas quotients of orders 6–7;
* 5,100 LP instances from 420 four-branch/two-separator quotients;
* 22,669 LP instances from 1,622 accepted seeded three-/four-separator path
  quotients, out of 2,000 attempted quotients.

All three use bag weights between 1 and 20 and include the single possible
low-degree exception required by the **second**-smallest degree. Their scope
is the displayed grammar only. Nothing here excludes all nontraceable graphs.

## Prior-result handling

PR70 is credited for the previously public diameter-two partial result,
quadratic order upper bound, and reported σ≤4 and n≤11 computations. Its
quadratic order bound is **not** a traceability theorem for every order below
that number. This checkpoint does not rerun or certify the prior Lean build.
The original 189/199 status search is bounded, not a claim that every possible
equivalent theorem in the literature has been ruled out.

Earlier independently rediscovered 412d and 404–407 results are excluded from
new-closure counts because exact public prior results were found. No such
claim is revived in this checkpoint.
