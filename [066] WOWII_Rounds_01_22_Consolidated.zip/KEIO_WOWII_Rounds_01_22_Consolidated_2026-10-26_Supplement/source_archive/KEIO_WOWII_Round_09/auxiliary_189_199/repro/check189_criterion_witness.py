#!/usr/bin/env python3
"""Exact, standard-library verification of one credited prior graph."""
from pathlib import Path
from collections import deque
from itertools import combinations
import json

base=Path(__file__).parent
x=json.loads((base/'criterion_witness.json').read_text())
n=x['n']; adj=[set() for _ in range(n)]
for u,v in x['edges']:
    adj[u].add(v); adj[v].add(u)

def connected(removed):
    rem=set(range(n))-set(removed)
    if len(rem)<2: return True
    seen={next(iter(rem))}; stack=list(seen)
    while stack:
        for v in adj[stack.pop()] & rem-seen:
            seen.add(v); stack.append(v)
    return seen==rem

even=[]; diameter=0
for root in range(n):
    dist=[-1]*n; dist[root]=0; queue=deque([root])
    while queue:
        u=queue.popleft()
        for v in adj[u]:
            if dist[v]<0:
                dist[v]=dist[u]+1; queue.append(v)
    assert min(dist)>=0
    even.append(sum(d%2==0 for d in dist)); diameter=max(diameter,max(dist))
sigma=sorted(map(len,adj))[1]
assert sigma==4 and max(even)==5

independent=[]
for mask in range(1<<n):
    vertices=[i for i in range(n) if mask>>i&1]
    if len(vertices)>len(independent) and all(v not in adj[u] for u,v in combinations(vertices,2)):
        independent=vertices
assert len(independent)==5
cut=None
for size in range(n-1):
    cut=next((list(S) for S in combinations(range(n),size) if not connected(S)),None)
    if cut is not None: break
assert len(cut)==2 and len(independent)>len(cut)+1

triple=[2,3,4]
assert all(v not in adj[u] for u,v in combinations(triple,2))
common=set.intersection(*(adj[v] for v in triple))
quantity=sum(len(adj[v]) for v in triple)-len(common)
assert quantity==8<n-1
path=x['prior_hamiltonian_path']
assert len(path)==len(set(path))==n
assert all(v in adj[u] for u,v in zip(path,path[1:]))

out=dict(status='PASS',n=n,sigma=sigma,even_counts=even,diameter=diameter,
         alpha=len(independent),maximum_independent_set=independent,
         kappa=len(cut),minimum_vertex_cut=cut,independent_triple=triple,
         triple_degrees=[len(adj[v]) for v in triple],common_neighbors=sorted(common),
         modified_triple_quantity=quantity,traceability_threshold=n-1,
         verified_hamiltonian_path=path,
         scope='Counterexample to automatic sufficient-condition applicability, not to WOWII189.')
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
