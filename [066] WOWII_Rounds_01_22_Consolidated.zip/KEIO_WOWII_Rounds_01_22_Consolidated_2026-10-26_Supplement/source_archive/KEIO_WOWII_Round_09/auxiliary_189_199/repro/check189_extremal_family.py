#!/usr/bin/env python3
"""Standard-library verification of the explicit J_s family and spanning paths."""
from pathlib import Path
from collections import deque
import itertools,json
rows=[]
for s in range(2,31):
 n=3*s+1;A=list(range(s+1));B=list(range(s+1,2*s+2));Z=list(range(2*s+2,n));adj=[set() for _ in range(n)]
 def edge(u,v):adj[u].add(v);adj[v].add(u)
 for C in [A,B]:
  for u,v in itertools.combinations(C,2):edge(u,v)
 for z in Z:
  for v in A[1:]+B[1:]:edge(z,v)
 ev=[]
 for root in range(n):
  d=[-1]*n;d[root]=0;q=deque([root])
  while q:
   u=q.popleft()
   for v in adj[u]:
    if d[v]<0:d[v]=d[u]+1;q.append(v)
  assert min(d)>=0;ev.append(sum(x%2==0 for x in d))
 assert set(ev)=={s+1};assert sorted(map(len,adj))[1]==s
 I=Z+[A[0],B[0]];assert len(I)==s+1 and all(v not in adj[u] for u,v in itertools.combinations(I,2))
 P=[A[0]]
 for i in range(1,s-1):P.extend([A[i],Z[i-1]])
 P.extend([A[s-1],A[s],Z[-1],B[1],B[0]]+B[2:])
 assert len(P)==len(set(P))==n and all(v in adj[u] for u,v in zip(P,P[1:]))
 rows.append(dict(s=s,n=n,max_even=max(ev),second_degree=s,hamiltonian_path=P))
out=dict(status='PASS',cases=len(rows),smallest_case=rows[0],sigma5_case=rows[3],largest_case=rows[-1],scope='finite guards for the universally proved family; not a counterexample or closure of189')
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
