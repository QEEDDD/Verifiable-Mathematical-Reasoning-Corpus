#!/usr/bin/env python3
"""Exact standard-library reconstruction of the C7 clique-blowup family."""
from pathlib import Path
from collections import deque
from itertools import combinations,product
import json
rows=[]
for t in range(2,31):
 w=[t,t,t,2*t-1,2*t-1,2*t-1,t];bags=[];z=0
 for wi in w:bags.append(list(range(z,z+wi)));z+=wi
 a=[set() for _ in range(z)]
 def edge(u,v):a[u].add(v);a[v].add(u)
 for B in bags:
  for u,v in combinations(B,2):edge(u,v)
 for i in range(7):
  for u,v in product(bags[i],bags[(i+1)%7]):edge(u,v)
 ev=[]
 for root in range(z):
  d=[-1]*z;d[root]=0;Q=deque([root])
  while Q:
   u=Q.popleft()
   for v in a[u]:
    if d[v]<0:d[v]=d[u]+1;Q.append(v)
  assert min(d)>=0;ev.append(sum(x%2==0 for x in d))
 s=sorted(map(len,a))[1]
 assert z==10*t-3 and s==3*t-1 and max(ev)==s+1 and z-(3*s+1)==t-1
 cycle=sum(bags,[]);assert len(set(cycle))==z
 assert all(v in a[u] for u,v in zip(cycle,cycle[1:]+cycle[:1]))
 rows.append(dict(t=t,n=z,sigma=s,max_even=max(ev),linear_bound_excess=z-3*s-1,bag_degrees=[len(a[B[0]]) for B in bags],bag_even_counts=[ev[B[0]] for B in bags]))
out=dict(status='PASS',cases=rows,scope='auxiliary n<=3sigma+1 extrapolation fails; every example satisfies189 and is explicitly Hamiltonian')
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'status':out['status'],'count':len(rows),'first':rows[0],'last':rows[-1]},indent=2))
