#!/usr/bin/env python3
"""Direct finite guard: connected split incidence matrices, total order <=7."""
from pathlib import Path
from itertools import combinations
import json

tested=qualified=subsets_checked=0
for a in range(1,5):
  for b in range(1,5):
    if a+b>7: continue
    n=a+b
    for matrix in range(1<<(a*b)):
      rows=[{c for c in range(a) if matrix>>(i*a+c)&1} for i in range(b)]
      if any(not R for R in rows): continue
      if b==1 and len(rows[0])==a: continue # complete graph
      cols=[{i for i in range(b) if c in rows[i]} for c in range(a)]
      k=min(map(len,rows))
      formula=max([1]+[1+len(C) for C in cols]+[2+len(cols[c]^cols[d]) for c,d in combinations(range(a),2)])
      tested+=1
      if formula>k+2: continue
      qualified+=1
      adj=[set() for _ in range(n)]
      for c,d in combinations(range(a),2): adj[c].add(d); adj[d].add(c)
      for i,R in enumerate(rows):
        for c in R: adj[c].add(a+i); adj[a+i].add(c)
      exact=1
      for mask in range(1,1<<n):
        V={i for i in range(n) if mask>>i&1}
        if sum(len(adj[i]&V) for i in V)!=2*(len(V)-1): continue
        seen={next(iter(V))}; stack=list(seen)
        while stack:
          for v in adj[stack.pop()]&V-seen:
            seen.add(v); stack.append(v)
        if seen==V: exact=max(exact,len(V))
      assert exact==formula
      for mask in range(1<<b):
        J=[i for i in range(b) if mask>>i&1]
        neighborhood=set().union(*(rows[i] for i in J))
        assert len(neighborhood)>=len(J)-1
        subsets_checked+=1
out=dict(status='PASS',connected_noncomplete_incidence_matrices=tested,
         premise_satisfying_matrices=qualified,independent_subsets_checked=subsets_checked,
         scope='1<=|C|,|I|<=4; |C|+|I|<=7; exact induced-tree formula checked on premise-satisfying inputs only; finite guards, not proof')
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
