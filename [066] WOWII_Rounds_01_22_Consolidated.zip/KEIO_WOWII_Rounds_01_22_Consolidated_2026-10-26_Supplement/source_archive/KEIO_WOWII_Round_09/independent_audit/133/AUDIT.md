# Independent audit: WOWII 133, Round09 partial results

**Verdict: PASS — partial theorems only. No full closure and no novelty certification.**

Audited on 26 October 2026 by a separate proof-review agent. The principal
P6 density theorem, its atom classification, exceptional-atom extension
argument, and clique-cutset induction are valid. Independent computation
corroborates every finite assertion tested. The audit also found elementary
replacements for both uses of Brandstädt–Hoàng, so the final P6 argument
does not depend on the unavailable original 2007 proof.

The P7 and bipartite refinements are audited separately in
`P7_AND_BIPARTITE_AUDIT.md`. Together with previously established coverage,
the verified new partial scope is radius two with ell≤5, radius three at
ell=4, and all bipartite graphs with ell≤4 (see `BIPARTITE_P8_AUDIT.md`). These are not a resolution of
the original conjecture for all graphs.

## 1. Objects, conventions, and exact statement

Reviewed `round_09/domination133/p6_density133.md`, the two author finite
scripts, their data, the exact original formal statement in
`round_01/source_audit/formal/GraphConjecture133.lean`, and the relevant
earlier low-local-independence proof in Round02.

The C4 exclusion is **as a subgraph**, not merely an induced subgraph.
The parameter p counts path vertices; ell is the unrounded average of
alpha(G[N(v)]). In the C4-free branch the original target is p≥r+ell.
There is no hidden floor or ceiling in the claimed partial consequences.

For connected C4-subgraph-free, induced-P6-free G, the candidate proves
ell≤3, with equality only for the Petersen graph P. The stronger invariant
D=3n−2m+3t has values 3 on K1, 0 on P, and 3 on P−v; it is at least 4
otherwise, and at least 6 whenever a triangle is present. These precise
exceptions matter in the gluing argument and have been checked.

## 2. Universal proof audit

### 2.1 Local identity

Every neighborhood induces a matching: two incident neighborhood edges
together with the center give a four-cycle, even if the cycle has chords.
Consequently lambda(v)=d(v)−t(v), and summing yields n ell=2m−3t. This
identity is exact, not an inequality, including isolated K1.

### 2.2 The two structural inputs can be proved directly here

An exterior vertex contacting an induced C5 has one cycle contact or two
adjacent contacts. Two contacts at distance two create a C4, and any set
of three cycle vertices contains such a pair. If a C5 is not dominating,
connectedness supplies adjacent exterior vertices y,x, with y having no
cycle contact and x having a contact. Select four consecutive cycle
vertices starting at a contact of x and directed away from its other
contact, if present. Prepending y,x gives an induced P6. Thus every C5 is
dominating, without any atom hypothesis or external theorem.

In a connected graph with no induced C5, an induced C6 cannot have any
exterior vertex. Otherwise connectedness supplies an exterior neighbor x
of that C6. No two contacts are at cycle distance two; there are at most
two contacts, and two must be adjacent or opposite. Singleton or adjacent
contacts yield P6; opposite contacts yield an induced C5. This proves the
needed C6 conclusion without first assuming domination.

The author incorporated these replacements, and the final revised text was checked.
The historical source remains relevant context but is no longer a proof
dependency of the specialized P6 density theorem.

### 2.3 C5 atom classification

The Ai/Bi partition is exhaustive once domination is known. All four
restriction groups were checked directly against their proposed C4/P6
witnesses. In particular:

* Ai is anticomplete to adjacent-index A classes and complete to the two
  opposite-index classes.
* Bi has size at most one; neighboring B classes cannot coexist; all
  distinct B classes are anticomplete.
* Ai can contact only Bi+2, and at most one member of Ai can do so.
* The singleton Ai argument correctly uses the atom hypothesis. If a
  member has no neighbor outside Ai∪{ci}, its neighborhood is a clique
  whose deletion separates it from remaining cycle vertices. If |Ai|≥2,
  the opposite A classes are empty, leaving too few possible outside
  neighbors. No unsupported uniform-adjacency assumption is needed.

With a B class present, its necessary A neighbor excludes the relevant
other A/B classes, and the final two possible A classes either both occur
or both do not. Their joint occurrence gives the displayed P6. This leaves
the unique seven-vertex triangular atom T.

With no B classes, the chosen indices induce a subset of a five-cycle
(the pentagram) with no isolated vertex. The only possibilities are the
empty set, an edge, P3, P4, and C5. Their orders, edge counts and triangle
counts give the five stated rows.

If there is no C5, a nonchordal graph has an induced C6 (a longer hole
contains P6); the preceding elementary argument forces the whole graph to
be C6. A connected noncomplete chordal graph has a clique separator, so a
chordal atom here is K1, K2, or K3. One may justify the chordal fact by
taking a minimal separator between nonadjacent vertices: two nonadjacent
separator vertices and paths through its two full components would form
a chordless cycle. Thus the separator must be a clique.

### 2.4 Exceptional atoms cannot be attached through a clique

The six P5 sequences in Lemma 4 are induced paths in the stated
six-cycle-plus-three-vertices representation of P−v and P. Each begins at
one contact, avoids the other contact if it exists, and covers every
vertex/edge type under cycle rotation. Prepending the exterior vertex
therefore gives an induced P6. There are no larger clique contacts because
both exceptional graphs are triangle-free.

For a proper clique-cutset side, connectedness supplies an exterior vertex
adjacent to the separator. Its contacts with that side are nonempty and
contained in the separator, so the one-vertex extension lemma applies.
This is the needed bridge from the local extension assertion to induction.

### 2.5 Gluing and equality

For connected proper sides G1,G2 overlapping in clique K,
D(G)=D(G1)+D(G2)−D(K), because all triangles are contained in a side.
Each side has at least two vertices and cannot be P or P−v. The inductive
lower bound 4 on both sides gives 5 for |K|=1 and 4 for |K|=2. For |K|=3,
both sides contain a triangle; their lower bound 6 gives 6 after gluing.
If the whole graph contains a triangle with |K|≤2, one side has bound 6,
giving 7 or 6. These simultaneously prove all strengthened assertions.

Equality ell=3 can therefore occur only at P. The final KG(5,2) argument
also verifies attainment analytically: nonadjacent vertices have one common
neighbor and adjacent vertices have none. An induced six-vertex path has
six vertex pairs at path-distance at least three. Their common neighbors
must lie outside the path. Any exterior vertex can contact at most two
path vertices, whose indices differ by at least three, and can cover at
most one such pair. Four exterior vertices cannot cover all six pairs.
Thus P is P6-free, as well as cubic, triangle-free and C4-subgraph-free.

## 3. Independent finite certification

The auditor wrote `check_independent133.cpp` without importing the author's
code or data. It uses induced-subset degree patterns plus connectivity for
P6 detection, rather than the author's path-extension DFS. Clique cutsets
are checked over all vertex subsets. Triangle counts are direct triple
counts, and local independence is exhaustively recomputed.

The output `independent_results.json` records:

* Every connected labeled graph of orders 1 through 7 checked: counts
  1, 1, 4, 38, 728, 26704, 1866256.
* 111844 C4-subgraph-free graphs checked for the exact local identity;
  all P6-free members satisfy the deficit assertions and the possible
  small atom signatures.
* **2,097,689 C5 attachment candidates**, allowing repeated A/B types and
  every exterior edge set, not assuming the candidate's singleton or
  exterior adjacency lemmas. Among them, 15499 are C4-free and 1327 are
  also P6-free. Exactly 22 are atoms, with the six claimed signatures and
  multiplicities 1,5,5,5,5,1.
* P and P−v constructed independently as KG(5,2) and a deletion. Both
  have the required forbidden-subgraph and atom properties.
* All 46 nonempty clique-contact extensions (21 for P−v, 25 for P) contain
  P6.

The C5 census stops at five exterior vertices and is **not** a universal
classification by itself. Its role is corroboration; the universal
singleton/atom argument is the proof. Similarly, the small labeled census
does not settle the original conjecture.

Reproduction from the workspace root:

```sh
g++ -std=c++17 -O3 wowii_rounds/round_09/independent_audit/133/check_independent133.cpp -o /tmp/audit133
/tmp/audit133
```

The author scripts were separately inspected. Their restricted census
correctly reflects the already-proved Ai/Bi restrictions, their DFS tests
induced rather than arbitrary paths, and the extension script covers all
clique contacts for one representative of each exceptional isomorphism
type. Neither script is being substituted for a universal proof.

## 4. Source audit and scope

The exact Brandstädt–Hoàng statement was checked in the primary STACS2018
paper, Theorem 9, page 35:8, including visual PDF inspection. It gives C5
domination in induced-(C4,P6)-free atoms and a Petersen-blowup-plus-clique
description when a C6 fails to dominate. Source definitions confirm
induced exclusion and nonempty clique bags. Both uses in the original
candidate were sound. The original 2007 full proof was not obtained and
is not represented as read. The elementary replacements above remove
that limitation from the final P6 proof chain.

The new radius-two implication uses only the earlier elementary radius-two
ell≤3 proof: C4-free P4-free graphs have a universal vertex, and C4-free
P5-free graphs have ell≤2. For 3<ell≤4, the present theorem forces P6,
so p≥6≥2+ell. No conclusion for arbitrary radius or ell is inferred.

**No unresolved mathematical gap found.** Worldwide priority has not been
certified by this proof audit. The accepted artifact is a partial theorem,
not a newly closed numbered WOWII conjecture.
