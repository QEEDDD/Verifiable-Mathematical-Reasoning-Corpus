# Independent audit: sharp bipartite P8-free density bound

**PASS — elementary partial theorem, not full WOWII133.**

Reviewed the complete `bipartite_p8_density133.md` argument and equality
case on 26 October 2026. No structural-literature assumption is required
for this density theorem. The final all-radius conjecture consequence
also uses the previously attributed classical induced-path/radius bound.

## Universal proof

1. A shortest cycle is even and induced. C4 exclusion and P8 exclusion
   leave girth 6 or 8. At girth 8, an exterior neighbor of a shortest C8
   has at most one contact: two same-parity contacts yield C4 or C6.
   Its unique contact, followed by seven cycle vertices, gives P8.
   Connectedness therefore forces the whole graph to be C8.

2. In the remaining case fix an induced C6. Every distance-one vertex
   has exactly one cycle contact by bipartiteness and C4 exclusion. A
   shortest three-edge path to C6, followed by four further cycle
   vertices, would be induced P8. Thus there are only layers A and B.

3. Edges within A join opposite contact classes and form a matching.
   Both assertions follow from the specified C4 witnesses. B is
   independent: for bb' in B, choose x in A adjacent to b. Bipartiteness
   excludes b'x; neither B vertex contacts the cycle; x has one cycle
   contact. Thus the displayed bb'x-plus-cycle sequence is induced P8.

4. A B vertex meets A classes of only one parity and at most one vertex
   in each class. The forced-contact P8 witness is valid: if b meets
   Ai but misses a vertex of Ai+4, the stated eight vertices induce a
   path. No x–y chord is possible because those A classes have the same
   parity. Reversing direction covers Ai+2.

5. If at least two same-parity A classes are nonempty and a B vertex
   uses that parity, the forced-contact rule makes all these classes
   singletons. Every B vertex of the parity meets all of them, so a
   second B vertex would create C4. Hence a=q∈{2,3}, b=1, e=q and
   R=a+3b−2e=3−q. In the nonspecial case b=0 or each B vertex has
   degree one, so R≥a. There are no unassigned B vertices: membership
   in the second distance layer guarantees an A neighbor.

6. Direct counting yields 3n−2m=6+R0+R1−2k. If neither parity is
   special, the matching property gives a0+a1≥2k, yielding deficit
   at least 6. If exactly one is special, k≤3 and the other R≥k,
   giving deficit at least 3. If both are special, the deficit is
   12−q0−q1−2k≥0, with equality only at q0=q1=k=3.

Every possible case is covered and the inequality average degree≤3
follows. The zero-deficit configuration has exactly the listed 14 vertices
and 21 edges; there are no free additional edge choices.

## Heawood equality and sharpness

The equality edge list is cubic and bipartite. Direct common-neighbor
checking verifies C4 exclusion and identifies it as the incidence graph
of the order-two projective plane, i.e. the Heawood graph. In either part,
every pair has exactly one common neighbor.

In a hypothetical induced P8 v0,...,v7, v6 needs common neighbors with
both v0 and v2. Both common neighbors lie outside the path: any candidate
inside introduces a chord. They are distinct, since v0 and v2 already
share v1 and cannot have a second common neighbor. These two outside
neighbors plus v5,v7 contradict cubicity. Hence the equality graph is
indeed P8-free; sharpness is not merely inferred from a necessary equality
configuration.

## Independent finite controls

`check_bipartite_p8.cpp` uses only the auditor's earlier graph primitives.
It enumerates all bipartite adjacency matrices with fixed part sizes
p≤q, p+q=2,...,9. Isomorphic repetitions across different part sizes or
labelings are intentionally retained. For every connected C4-free,
P8-free input it verifies the strict small-order density inequality and,
whenever a C6 exists, checks every layer property used in the proof.
It separately builds the 14-vertex equality edge list and tests every
eight-vertex induced subset, all same-part common-neighbor pairs, and
the existence of P7. The recorded maximum induced-path order is 7.

Full reproducible counts are in `bipartite_p8_results.json`. These finite
checks corroborate the analytic proof and are not its universal premise.

```sh
g++ -std=c++17 -O3 wowii_rounds/round_09/independent_audit/133/check_bipartite_p8.cpp -o /tmp/audit133_bip8
/tmp/audit133_bip8
```

## Consequence and boundary

For bipartite graphs ell is average degree. If 3<ell≤4 and C4 is absent,
the theorem forces p≥8. This suffices when r≤4. When r≥5, the classical
bound p≥2r−1 gives p≥r+4≥r+ell. Together with the earlier all-radius
ell≤3 theorem and the immediate C4-present branch, this proves the
original unrounded WOWII133 assertion for **all bipartite graphs with
ell≤4**.

The general nonbipartite case and bipartite ell>4 remain open in this
audit. No full numbered closure or worldwide novelty is certified.
