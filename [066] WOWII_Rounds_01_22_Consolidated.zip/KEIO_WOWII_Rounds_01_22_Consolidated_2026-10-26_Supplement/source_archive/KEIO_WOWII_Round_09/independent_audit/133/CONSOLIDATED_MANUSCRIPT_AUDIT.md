# Frozen consolidated manuscript review

**PASS.** The frozen `round_09/domination133/manuscript.tex` was compared
with the separately audited P6, P7 and bipartite P8 notes on 26 October
2026. Its proof bodies, equality cases and partial-coverage table preserve
the audited statements. The exact frozen file is included in `snapshots/`.

The compressed earlier-coverage lemma `lem:old` also passes. Its complete
P4-free case is immediate; otherwise connectedness supplies the induced
P3 used there. Its P5-free cycle-space argument remains valid. In the
radius-three P6-free step, the complete bipartite alternative must be a
star under C4-subgraph exclusion, so a dominating such subgraph would
have a center of eccentricity at most two. In the dominating-C6 alternative,
forbidden distance-two cycle contacts bound every exterior contact set by
two; P6 exclusion leaves only opposite pairs. One exterior opposite-pair
vertex would then give a center of eccentricity at most two. Hence the
radius-three graph is C6. All radius cases and the singleton boundary
are correctly handled; no rounding was introduced.

Both classical statements were rechecked directly in the primary sources:

* Erdős–Saks–Sós, *Maximum Induced Trees in Graphs* (1986), printed p.62
  defines p as induced-path vertex order. Section II, printed pp.64–65,
  gives p≥2 rad−1 and credits the displayed proof to Fan Chung. That
  short radius proof was also checked: delete a noncutvertex in a
  minimal counterexample, take a center of the remaining graph, and join
  its distance-r path to the deleted vertex with an appropriate shortest
  path of length r−2 or r−1; the only possible extra chord is removed
  by deleting their common initial vertex. This yields at least 2r−1
  induced-path vertices.
  https://users.renyi.hu/~sos/1986_Maximum_Induced_Trees_in_Graphs.pdf
* Van ’t Hof–Paulusma, *A new characterization of P6-free graphs*, author
  manuscript, Theorem 6, printed p.3 (proof via Theorem 7 on p.7): the
  dominating induced C6 / dominating complete bipartite alternative is
  asserted for every connected induced subgraph, without requiring
  triangle-freeness or inducedness of the complete bipartite subgraph.
  Its standing nontriviality convention is harmless at radius three.
  The exact established theorem is the external input; this audit does
  not claim to rederive the entire constructive Theorem 7 algorithm.
  https://pimvanthof.github.io/p6free.pdf

The reported 70,804 connected P6-free checks and 109,324 connected P7-free
checks agree with sums in the independent audit outputs. This final
consolidation adds no new coverage beyond the three audited notes, and
still does not close original WOWII133.
