# Independent audit: P7 and bipartite refinements of WOWII 133

**Verdict: PASS, partial results only.** Read with `AUDIT.md` and the exact
candidate snapshots. No worldwide novelty or full-conjecture claim is made.

## 1. P7-free density theorem

The candidate proves, for connected C4-subgraph-free, induced-P7-free G,
with L=2m−3t and F=4n−L:

* F≥8 if G is noncomplete;
* F≥9 if G contains a triangle;
* F=4,6,9 on K1,K2,K3 respectively.

In particular ell=L/n<4. The simultaneous strengthening is needed for
clique-cutset gluing; a positive atom bound alone would not prove this.

### Exact external theorem and provenance

Ran Chen, Di Wu and Baogang Xu, *Structure and coloring of some
(P7,C4)-free graphs*, arXiv:2302.11115v1 (22 February 2023), Theorem 1.3,
states that a connected induced-(P7,C4,gem)-free atom is a clique blowup
of the Petersen graph or has a bisimplicial vertex. The exact statement
and definition of bisimplicial were checked in text and visually on PDF
page 3. Clique bags are nonempty by the source's definition on page 2.

The journal publication is *Structure of some (P7,C4)-free graphs with
application to colorings*, Discrete Applied Mathematics 357 (15 November
2024), 14–23, DOI 10.1016/j.dam.2024.05.038. The publisher's primary abstract
also explicitly confirms the needed structural extension. The exact
numbered statement audited here is the fixed arXiv v1 version.

Sources:

* https://arxiv.org/pdf/2302.11115v1
* https://www.sciencedirect.com/science/article/abs/pii/S0166218X24002336

The source's Section 4 proof was read. Its C7-containing argument derives
the required vertex from explicit cycle-contact classes; its C7-free
branch invokes Choudum–Karthick–Belavadi (2021), Lemma 4.1 as restated
there. That earlier structural theorem was not independently reproved in
this audit. Thus this is a proof using a precisely verified established
literature theorem, not a claim of a self-contained redevelopment of all
its antecedent structure theory. No mismatch or unexplained hypothesis
was found.

### Application and induction

The hypothesis transfer is valid: a gem contains a C4 as a non-induced
subgraph, so the stronger exclusion here implies all three induced
exclusions required by the source. A Petersen clique blowup satisfying
the stronger exclusion has only singleton bags: two vertices in one bag
and one vertex in each of two neighboring bags already form a four-cycle.
The only exceptional atom is consequently P, with F=10 and no triangles.

Otherwise a bisimplicial vertex v has lambda(v)≤2. Writing q for its
triangle count, deletion gives exactly

    F(G)−F(G−v)=4−2d(v)+3q=4−2lambda(v)+q≥0.

A noncomplete atom has at least four vertices and no cutvertex, so H=G−v
is connected and has at least three vertices. The inductive lower bound
F(H)≥8 applies even when H is complete, because its only possible complete
case is K3 and F(K3)=9. If a triangle survives deletion, the triangle
induction gives 9. If all triangles use v, then q≥1 increases the deletion
margin to at least 1 and again gives 9.

For a clique separator K, the exact inclusion–exclusion identity is
F(G)=F(G1)+F(G2)−F(K). The K1 case has sides of order at least 2 and
deficits at least 6, yielding 8. If a triangle occurs, one side contributes
at least 9, yielding 11. The K2 case has sides of order at least 3 and
deficits at least 8, yielding 10 or, with a triangle, 11. The K3 case has
two triangular sides, yielding 9+9−9=9. Every induction boundary and
complete-graph exception is accounted for. No gap was found.

### Independent computation

`check_p7_independent.cpp` reuses only this auditor's graph primitives,
not the author code. It detects P7 using seven-vertex subsets and tests
bisimpliciality by direct partition of the neighborhood into two cliques.

The recorded output `p7_independent_results.json` verifies:

* all connected labeled C4-subgraph-free, P7-free graphs of orders 1–7:
  counts 1,1,4,28,302,4776,104212;
* all 14 possible single-vertex contact types with an induced C7, and
  **157025** attachment candidates with up to four exterior vertices,
  repeated contact types permitted and all exterior edges allowed;
* 85 surviving C7 attachment graphs and the independent Petersen model;
* altogether 109410 graph occurrences, 80259 triangle-bound checks, and
  2621 atom checks, with no failures.

This bounded attachment test is only corroboration, not an exhaustive
classification of P7-free atoms of arbitrary order.

Reproduction:

```sh
g++ -std=c++17 -O3 wowii_rounds/round_09/independent_audit/133/check_p7_independent.cpp -o /tmp/audit133_p7
/tmp/audit133_p7
```

## 2. Elementary bipartite P7-free refinement

Reviewed `bipartite_p7_density133.md`. Its stronger cyclic inequality
3n−2m≥6 is valid and has no structural-literature dependency.

A shortest cycle must be an induced C6: bipartiteness excludes odd cycles,
C4 is excluded, and an induced cycle of order at least eight contains P7.
An exterior vertex has at most one contact with this C6, because its
contacts lie in a single parity class and any two such cycle vertices
are at distance two. If C6 were not dominating, the two-vertex exterior
tail followed by five cycle vertices would be an induced P7. Thus every
exterior vertex has exactly one contact.

An exterior edge can only join opposite cycle-contact classes. Same
parity is excluded by bipartiteness and adjacent classes would give C4.
Each exterior vertex has exterior degree at most one, since two neighbors
in the opposite class share a cycle contact and form a four-cycle with
it. Therefore the exterior graph is a matching plus isolated vertices.
If their counts are k and s, then n=6+2k+s and m=6+3k+s, giving the exact
identity 3n−2m=6+s. Trees separately have average degree below two.

## 3. Exact partial consequences and remaining scope

Combining the P6 and P7 density theorems with the previously established
ell≤3 partial theorem gives the original unrounded WOWII133 inequality
for radius two and ell≤5:

* ell≤3: earlier coverage;
* 3<ell≤4: P6 is forced, so p≥6≥2+ell;
* 4<ell≤5: P7 is forced, so p≥7≥2+ell.

The P7 theorem also gives the boundary r=3, ell=4. Its finite-order form
forces P7 whenever a noncomplete C4-free graph has ell>4−8/n.

For bipartite graphs, ell is exactly the average degree. The elementary
P7 refinement forces P7 already when ell≥3, proving radius-three coverage
through ell≤4 when combined with the previous ell≤3 theorem. The latter
earlier all-radius result and its attributed radius/dominating-subgraph
inputs are not newly claimed as discoveries here.

These results do not settle general nonbipartite r=3, 3<ell<4, nor all
larger ell at r=2, and do not by themselves give any P8-free theorem.
