// Independent finite controls for the elementary bipartite P8 theorem.
#define main p6_audit_main
#include "check_independent133.cpp"
#undef main
bool induced_path(const Graph&a,int k){
  if(int(a.size())<k)return false;
  for(Mask s=0;s<(1u<<a.size());++s)if(pc(s)==k){
    int ends=0;bool ok=true;
    for(unsigned v=0;v<a.size();++v)if(s&(1u<<v)){
      int d=pc(a[v]&s);if(d==1)++ends;else if(d!=2){ok=false;break;}
    }if(ok&&ends==2&&connected(a,s))return true;
  }return false;
}
Count layer_checks=0;
void check_layers(const Graph&a){
  unsigned n=a.size();Mask C=0;
  for(Mask s=0;s<(1u<<n);++s)if(pc(s)==6&&connected(a,s)){
    bool ok=true;for(unsigned v=0;v<n;++v)if((s&(1u<<v))&&pc(a[v]&s)!=2)ok=false;
    if(ok){C=s;break;}
  }if(!C)return;
  ++layer_checks;
  std::vector<int> cy;cy.push_back(__builtin_ctz(C));
  while(cy.size()<6){int v=cy.back();Mask poss=a[v]&C;
    for(int w:cy)poss&=~(1u<<w);require(poss,"C6 traversal failed");cy.push_back(__builtin_ctz(poss));}
  Mask A=0;for(int v:cy)A|=a[v];A&=~C;Mask B=((1u<<n)-1)&~(A|C);
  std::vector<int> contact(n,-1),part(n,-1);int aa[2]={},bb[2]={},ee[2]={},qq[2]={};
  int classes[6]={};
  for(unsigned v=0;v<n;++v)if(A&(1u<<v)){
    require(pc(a[v]&C)==1,"Unique C6 contact failed");
    for(int i=0;i<6;++i)if(a[v]&(1u<<cy[i]))contact[v]=i;
    ++classes[contact[v]];++aa[contact[v]%2];require(pc(a[v]&A)<=1,"A matching failed");
  }
  for(int i=0;i<6;++i)if(classes[i])++qq[i%2];
  for(unsigned v=0;v<n;++v)if(A&(1u<<v))for(unsigned w=0;w<n;++w)
    if((a[v]&A)&(1u<<w))require((contact[v]+3)%6==contact[w],"Opposite-class A edge failed");
  for(unsigned v=0;v<n;++v)if(B&(1u<<v)){
    require(a[v]&A,"Distance two bound failed");require(!(a[v]&B),"B independence failed");
    int x=__builtin_ctz(a[v]&A),p=contact[x]%2;part[v]=p;++bb[p];ee[p]+=pc(a[v]&A);
    for(unsigned w=0;w<n;++w)if(A&(1u<<w)){
      if(a[v]&(1u<<w))require(contact[w]%2==p,"B parity failed");
      if(contact[w]%2==p&&contact[w]!=contact[x])require(a[v]&(1u<<w),"Forced B contact failed");
    }
  }
  for(int p=0;p<2;++p){
    if(qq[p]>=2&&bb[p])require(aa[p]==qq[p]&&bb[p]==1&&ee[p]==qq[p],"Special parity failed");
    else require(aa[p]+3*bb[p]-2*ee[p]>=aa[p],"Nonspecial contribution failed");
  }
}
int main(){
  Count inputs=0,connected_c4free=0,p8free=0;std::vector<Count> counts;
  for(int n=2;n<=9;++n){Count byorder=0;
    for(int p=1;p<=n/2;++p){int q=n-p;
      for(Mask mask=0;mask<(1u<<(p*q));++mask){
        ++inputs;Graph a(n);for(int u=0;u<p;++u)for(int v=0;v<q;++v)if(mask&(1u<<(u*q+v)))edge(a,u,p+v);
        if(!connected(a,(1u<<n)-1)||c4(a))continue;++connected_c4free;
        if(induced_path(a,8))continue;++p8free;++byorder;
        auto [order,m,t]=signature(a);require(2*m<3*n,"Unexpected small equality or density failure");check_layers(a);
      }
    }counts.push_back(byorder);
  }
  Graph H(14);for(int i=0;i<6;++i){edge(H,i,(i+1)%6);edge(H,i,6+i);edge(H,12+i%2,6+i);}
  for(int i=0;i<3;++i)edge(H,6+i,9+i);
  require(!c4(H)&&connected(H,(1u<<14)-1),"Heawood C4/connectivity failed");
  for(auto s:H)require(pc(s)==3,"Heawood cubicity failed");
  require(!induced_path(H,8)&&induced_path(H,7),"Heawood induced path order failed");check_layers(H);
  // Verify the incidence-design property directly for every pair in each part.
  Mask left=0;std::vector<int> color(14,-1);color[0]=0;
  for(int round=0;round<14;++round)for(int v=0;v<14;++v)if(color[v]>=0)for(int w=0;w<14;++w)if(H[v]&(1u<<w)){
    if(color[w]<0)color[w]=1-color[v];else require(color[w]!=color[v],"Heawood bipartiteness failed");}
  for(int v=0;v<14;++v)if(color[v]==0)left|=1u<<v;require(pc(left)==7,"Heawood partition order failed");
  for(int v=0;v<14;++v)for(int w=0;w<v;++w)if(color[v]==color[w])require(pc(H[v]&H[w])==1,"Heawood common-neighbor property failed");
  std::cout<<"{\"status\":\"PASS\",\"bipartite_matrix_inputs\":"<<inputs<<",\"connected_C4_free\":"<<connected_c4free
    <<",\"also_P8_free\":"<<p8free<<",\"P8_free_counts_orders_2_to_9\":[";
  for(unsigned i=0;i<counts.size();++i){if(i)std::cout<<',';std::cout<<counts[i];}
  std::cout<<"],\"layer_structure_checks\":"<<layer_checks<<",\"Heawood_max_induced_path_order\":7,\"Heawood_common_neighbor_pairs\":42,\"scope\":\"Finite corroboration of elementary universal proof, not full WOWII133\"}\n";
}
