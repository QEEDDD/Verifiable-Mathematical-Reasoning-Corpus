// Independent finite audit of the analytic C4-subgraph-free/P6-free theorem.
// No candidate code/data is imported. P6 is tested by induced subset degrees.
#include <algorithm>
#include <cstdint>
#include <iostream>
#include <map>
#include <set>
#include <tuple>
#include <vector>
#include <stdexcept>
using Mask=unsigned;using Graph=std::vector<Mask>;using Count=std::uint64_t;
int pc(Mask x){return __builtin_popcount(x);}
void edge(Graph& a,int u,int v){a[u]|=1u<<v;a[v]|=1u<<u;}
bool connected(const Graph& a,Mask vertices){
  if(!vertices)return true;
  Mask seen=vertices&-vertices,old=0;
  while(seen!=old){old=seen;for(unsigned v=0;v<a.size();++v)if(old&(1u<<v))seen|=a[v]&vertices;}
  return seen==vertices;
}
bool c4(const Graph& a){
  for(unsigned u=0;u<a.size();++u)for(unsigned v=0;v<u;++v)if(pc(a[u]&a[v])>=2)return true;
  return false;
}
bool p6(const Graph& a){
  if(a.size()<6)return false;
  for(Mask s=0;s<(1u<<a.size());++s)if(pc(s)==6){
    int ends=0;bool valid=true;
    for(unsigned v=0;v<a.size();++v)if(s&(1u<<v)){
      int d=pc(a[v]&s);if(d==1)++ends;else if(d!=2){valid=false;break;}
    }
    if(valid&&ends==2&&connected(a,s))return true;
  }
  return false;
}
bool clique(const Graph&a,Mask s){
  for(unsigned v=0;v<a.size();++v)if((s&(1u<<v))&&pc(a[v]&s)!=pc(s)-1)return false;
  return true;
}
bool clique_cutset(const Graph& a){
  Mask all=(1u<<a.size())-1;
  for(Mask s=1;s<=all;++s)if(clique(a,s)&&!connected(a,all^s))return true;
  return false;
}
std::tuple<int,int,int> signature(const Graph&a){
  int n=a.size(),m=0,t=0;
  for(auto v:a)m+=pc(v);m/=2;
  for(int u=0;u<n;++u)for(int v=u+1;v<n;++v)for(int w=v+1;w<n;++w)
    if((a[u]&(1u<<v))&&(a[u]&(1u<<w))&&(a[v]&(1u<<w)))++t;
  return {n,m,t};
}
const std::set<std::tuple<int,int,int>> expected={{1,0,0},{2,1,0},{3,3,1},{5,5,0},{6,6,0},
  {7,8,0},{7,9,1},{8,10,0},{9,12,0},{10,15,0}};
Count all_graphs[8]{},free_graphs[8]{},free_p6_graphs[8]{};
std::map<std::tuple<int,int,int>,Count> small_atoms,cycle_atoms;
Count local_identities=0,pattern_inputs=0,pattern_c4_free=0,pattern_p6_free=0;
void require(bool b,const char*why){if(!b)throw std::runtime_error(why);}
void check_small(const Graph&a){
  unsigned n=a.size();++all_graphs[n];if(c4(a))return;++free_graphs[n];
  auto [order,m,t]=signature(a);
  int sumalpha=0;
  for(unsigned v=0;v<n;++v){
    int alpha=0;Mask s=a[v];
    while(true){
      bool indep=true;for(unsigned u=0;u<n;++u)if((s&(1u<<u))&&(a[u]&s)){indep=false;break;}
      if(indep)alpha=std::max(alpha,pc(s));
      if(!s)break;s=(s-1)&a[v];
    }
    sumalpha+=alpha;
  }
  require(sumalpha==2*m-3*t,"Local independence identity failed");++local_identities;
  if(p6(a))return;++free_p6_graphs[n];
  int D=3*n-2*m+3*t;
  require((n==1&&D==3)||(n>1&&D>=4),"Deficit failed on small graph");
  require(!t||D>=6,"Triangle deficit failed");
  if(!clique_cutset(a)){
    require(expected.count({order,m,t}),"Unexpected small atom signature");++small_atoms[{order,m,t}];
  }
}
std::vector<int> types;
void attachment_patterns(int q){
  Graph base(5+q);for(int v=0;v<5;++v)edge(base,v,(v+1)%5);
  for(int j=0;j<q;++j){int type=types[j];edge(base,5+j,type%5);if(type>=5)edge(base,5+j,(type+1)%5);}
  std::vector<std::pair<int,int>> optional;
  for(int u=0;u<q;++u)for(int v=u+1;v<q;++v)optional.push_back({5+u,5+v});
  for(Mask choices=0;choices<(1u<<optional.size());++choices){
    ++pattern_inputs;Graph a=base;
    for(unsigned j=0;j<optional.size();++j)if(choices&(1u<<j))edge(a,optional[j].first,optional[j].second);
    if(c4(a))continue;++pattern_c4_free;
    if(p6(a))continue;++pattern_p6_free;
    if(clique_cutset(a))continue;
    // This census did not assume the singleton lemma or any exterior edge restriction.
    std::set<int> distinct(types.begin(),types.end());
    require(distinct.size()==types.size(),"A or B multiplicity in atom");
    auto sig=signature(a);require(expected.count(sig),"Unexpected C5 atom signature");++cycle_atoms[sig];
  }
}
void type_multisets(int total,int first=0){
  if(static_cast<int>(types.size())==total){attachment_patterns(total);return;}
  for(int t=first;t<10;++t){types.push_back(t);type_multisets(total,t);types.pop_back();}
}
Graph petersen(){
  std::vector<Mask> subsets;for(Mask s=0;s<32;++s)if(pc(s)==2)subsets.push_back(s);
  Graph a(10);for(int u=0;u<10;++u)for(int v=u+1;v<10;++v)if(!(subsets[u]&subsets[v]))edge(a,u,v);
  return a;
}
void printmap(const std::map<std::tuple<int,int,int>,Count>&data){
  std::cout<<'[';bool first=true;for(auto [sig,count]:data){auto [n,m,t]=sig;if(!first)std::cout<<',';first=false;
    std::cout<<"{\"n\":"<<n<<",\"m\":"<<m<<",\"triangles\":"<<t<<",\"D\":"<<3*n-2*m+3*t<<",\"count\":"<<count<<'}';}
  std::cout<<']';
}
int main(){
  for(int n=1;n<=7;++n){
    std::vector<std::pair<int,int>> edges;for(int u=0;u<n;++u)for(int v=u+1;v<n;++v)edges.push_back({u,v});
    for(Mask mask=0;mask<(1u<<edges.size());++mask){
      Graph a(n);for(unsigned j=0;j<edges.size();++j)if(mask&(1u<<j))edge(a,edges[j].first,edges[j].second);
      if(connected(a,(1u<<n)-1))check_small(a);
    }
  }
  for(int q=0;q<=5;++q)type_multisets(q);
  Count atom_total=0;for(auto [sig,count]:cycle_atoms)atom_total+=count;require(atom_total==22,"Expected 22 C5 atoms");
  Count extensions=0;std::vector<int> extension_counts;
  Graph P=petersen();require(!c4(P)&&!p6(P)&&!clique_cutset(P),"Petersen structure failed");
  for(int order:{9,10}){
    Graph a(order);for(int u=0;u<order;++u)a[u]=P[u]&((1u<<order)-1);
    require(!c4(a)&&!p6(a)&&!clique_cutset(a),"Exceptional atom failed");
    auto [n,m,t]=signature(a);require(3*n-2*m+3*t==(order==9?3:0),"Exceptional deficit failed");
    int count=0;
    for(Mask s=1;s<(1u<<order);++s)if(clique(a,s)){
      Graph b=a;b.push_back(s);for(int v=0;v<order;++v)if(s&(1u<<v))b[v]|=1u<<order;
      require(p6(b),"Clique-contact extension has no P6");++extensions;++count;
    }
    extension_counts.push_back(count);
  }
  std::cout<<"{\n\"status\":\"PASS\",\n\"small_graphs\":[";
  for(int n=1;n<=7;++n){if(n>1)std::cout<<',';std::cout<<"{\"n\":"<<n<<",\"connected\":"<<all_graphs[n]<<",\"C4_subgraph_free\":"<<free_graphs[n]<<",\"also_P6_free\":"<<free_p6_graphs[n]<<'}';}
  std::cout<<"],\n\"local_independence_identities\":"<<local_identities<<",\n\"small_atom_counts\":";printmap(small_atoms);
  std::cout<<",\n\"C5_pattern_inputs_unrestricted_exterior_edges\":"<<pattern_inputs
    <<",\n\"C5_pattern_C4_free\":"<<pattern_c4_free<<",\n\"C5_pattern_also_P6_free\":"<<pattern_p6_free
    <<",\n\"C5_atoms\":";printmap(cycle_atoms);
  std::cout<<",\n\"C5_atom_total\":"<<atom_total<<",\n\"exceptional_clique_extensions\":"<<extensions
    <<",\n\"extension_counts_P_minus_v_P\":["<<extension_counts[0]<<','<<extension_counts[1]
    <<"],\n\"scope\":\"Finite corroboration of an analytic partial theorem; not full WOWII 133\"\n}\n";
  return 0;
}
