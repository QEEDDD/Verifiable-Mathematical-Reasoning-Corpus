// Independent P7 finite corroboration. Reuses only this auditor's graph oracles.
#define main p6_audit_main
#include "check_independent133.cpp"
#undef main
bool path7(const Graph& a){
  if(a.size()<7)return false;
  for(Mask s=0;s<(1u<<a.size());++s)if(pc(s)==7){
    int ends=0;bool ok=true;
    for(unsigned v=0;v<a.size();++v)if(s&(1u<<v)){
      int d=pc(a[v]&s);if(d==1)++ends;else if(d!=2){ok=false;break;}
    }
    if(ok&&ends==2&&connected(a,s))return true;
  }
  return false;
}
bool bisimplicial(const Graph&a,int v){
  // Directly partition N(v) into two cliques; no degree/triangle formula used.
  Mask s=a[v];while(true){
    if(clique(a,s)&&clique(a,a[v]^s))return true;
    if(!s)break;s=(s-1)&a[v];
  }return false;
}
Count checked=0,triangle_checked=0,atoms_checked=0,c7_inputs=0,c7_valid=0;
void check(const Graph&a){
  auto [n,m,t]=signature(a);int F=4*n-2*m+3*t;
  if(m!=n*(n-1)/2)require(F>=8,"P7 noncomplete deficit failed");
  if(t){require(F>=9,"P7 triangle deficit failed");++triangle_checked;}
  require(F>0,"P7 strict density failed");++checked;
  if(!clique_cutset(a)){
    bool b=false;for(int v=0;v<n;++v)b|=bisimplicial(a,v);
    require(b||(n==10&&m==15&&t==0),"P7 atom structure failed");++atoms_checked;
  }
}
std::vector<Mask> contact_types;
std::vector<int> assigned;
void patterns(){
  int q=assigned.size();Graph base(7+q);for(int i=0;i<7;++i)edge(base,i,(i+1)%7);
  for(int i=0;i<q;++i)for(int j=0;j<7;++j)if(contact_types[assigned[i]]&(1u<<j))edge(base,7+i,j);
  std::vector<std::pair<int,int>> optional;
  for(int i=0;i<q;++i)for(int j=i+1;j<q;++j)optional.push_back({7+i,7+j});
  for(Mask mask=0;mask<(1u<<optional.size());++mask){
    ++c7_inputs;Graph a=base;
    for(unsigned i=0;i<optional.size();++i)if(mask&(1u<<i))edge(a,optional[i].first,optional[i].second);
    if(c4(a)||path7(a))continue;++c7_valid;check(a);
  }
}
void multisets(int q,int first=0){
  if(int(assigned.size())==q){patterns();return;}
  for(int i=first;i<int(contact_types.size());++i){assigned.push_back(i);multisets(q,i);assigned.pop_back();}
}
int main(){
  std::vector<Count> counts;
  for(int n=1;n<=7;++n){
    Count count=0;std::vector<std::pair<int,int>> es;
    for(int u=0;u<n;++u)for(int v=u+1;v<n;++v)es.push_back({u,v});
    for(Mask mask=0;mask<(1u<<es.size());++mask){
      Graph a(n);for(unsigned j=0;j<es.size();++j)if(mask&(1u<<j))edge(a,es[j].first,es[j].second);
      if(!connected(a,(1u<<n)-1)||c4(a)||path7(a))continue;
      check(a);++count;
    }counts.push_back(count);
  }
  for(Mask s=1;s<128;++s){
    Graph a(8);for(int i=0;i<7;++i)edge(a,i,(i+1)%7);for(int i=0;i<7;++i)if(s&(1u<<i))edge(a,i,7);
    if(!c4(a)&&!path7(a))contact_types.push_back(s);
  }
  for(int q=0;q<=4;++q)multisets(q);
  Graph P=petersen();require(!path7(P),"Petersen P7 check failed");check(P);
  std::cout<<"{\"status\":\"PASS\",\"small_C4_subgraph_free_P7_free_counts\":[";
  for(unsigned i=0;i<counts.size();++i){if(i)std::cout<<',';std::cout<<counts[i];}
  std::cout<<"],\"C7_single_contact_types\":"<<contact_types.size()<<",\"C7_attachment_inputs\":"<<c7_inputs
    <<",\"C7_valid_inputs\":"<<c7_valid<<",\"graphs_checked_including_repetitions\":"<<checked
    <<",\"triangle_checks\":"<<triangle_checked<<",\"atom_checks\":"<<atoms_checked
    <<",\"scope\":\"Finite corroboration only; not an exhaustive universal atom classification or full WOWII133\"}\n";
}
