# Independent audit: WOWII 384b, the h=9 extension

**Verdict: PASS — complete finite certification of the h=9 subcase,
not a full resolution of WOWII 384b.**

Audited on 26 October 2026. Authoritative candidates are
`attachment_stability.tex` and `h9_certified_extension.tex`, with their
Markdown exports, the core lists, explicit permutation certificate, and
the C++ h=9 checker. Exact reviewed snapshots and hashes accompany this
report. No mathematical gap or computational failure was found.

Combined with the separately audited Round08 results, verified coverage
is **h≤9 or h≥44**. The remaining high-degree orders are **10,...,43**,
and the previous representative-order bound **n≤67** is unchanged. The
residual finite family has not been exhausted. No new full numbered
conjecture closure or worldwide novelty is certified.

## 1. Universal reduction

Let k=n−gamma2(G), the maximum size of a set in which every omitted vertex
retains at least two selected neighbors. A maximum cut gives at least
ceil(h/2) omittable high vertices: each high vertex has at least two
crossing neighbors. Low vertices have triangle counts 0 or 1, so |T|≤h+2.
For h=9, a counterexample would therefore have k=5 and |T|=11. All nine
high triangle counts must be distinct and at least 2, and both low values
0 and 1 must occur. This is the exact unrounded triangle-value set used
by the original conjecture; the floor in its domination formulation is
equivalent to |T|≤2k.

### 1.1 Maximum-cut stability

The accompanying structural theorem was checked independently of the
finite catalogue tests.

**Even h=2k.** Every maximum cut has k high vertices on each side. A good
degree-two vertex (both neighbors across the cut) would augment the k
high omissions on its side, so no such vertex exists. Every degree-two
vertex has precisely one crossing neighbor and can be flipped without
changing cut size. A degree-two/leaf edge would then create a leaf with
no crossing edge in another maximum cut. A degree-two/degree-two edge
would make the neighbor have crossing degree 0 or 2, both impossible.
Thus the low graph is independent. Each degree-two vertex has two high
neighbors on opposite sides. If a high vertex had two incident attachment
vertices, replacing that high vertex in its k-element side by the two
attachments gives k+1 omissions. This proves the simple-matching claim,
including exclusion of parallel incidence edges.

**Odd h=2k−1.** Label the high sides A,B with sizes k,k−1. No good low
vertex can lie on A's side, and at most one can lie on B's side. Two good
vertices on one side are independent and have all their neighbors across
the cut, so adjoining them to that side's high set is indeed safe.

Every nontrivial component of the low graph is a path between high
endpoints or a pendant path ending in a leaf. A low cycle would be a
whole connected component, contradicting h>0. With endpoints fixed, a
path between high vertices is optimally cut with all edges crossing or
all but one crossing, and the single noncrossing edge can be placed at
an end. Three or more internal degree-two vertices would then give
consecutive good vertices on opposite sides. Pendant paths with two or
more degree-two vertices have the same obstruction. These reorientations
change no outside edges and preserve global maximality. They also cover
the case where the two high endpoints coincide.

Hence a nontrivial low component is one edge. For a degree-two pair
a−x−y−b, endpoint colors must both be A: opposite endpoint colors make
both low vertices good on opposite sides; both B colors permit a good
vertex on A's side. With both endpoints A, an optimal orientation gives
a good vertex on B's side. A leaf/degree-two pair likewise has a good
degree-two vertex on B's side. Two such components can be reoriented
independently, contradicting the one-good-vertex limit. Thus the low
graph has at most one edge.

For the high-endpoint incidence multigraph J, no edge lies within B and
at most one lies within A. For crossing edges, each A vertex has incidence
degree at most 1 (replace one A vertex by two attachments); each B vertex
has degree at most 2 (replace one B vertex by three). Two B vertices of
degree 2 are impossible by a simultaneous replacement. If an A−A edge
exists, its good low vertex fills B to k omissions; this reduces every
crossing B incidence degree to 1. The only possible larger component
after adding the A−A edge would be a P4, but replacing its two A vertices
by its three attachments gives k+1 omissions. Thus J is a simple matching
plus at most one P3 component. If a low edge exists, its good vertex fills
B to size k and the same argument rules out both an A−A edge and a
degree-two B center, leaving a matching.

All exchanges preserve selected-neighbor counts of retained high vertices:
the newly omitted degree-two vertices are adjacent among the old omitted
high set only to vertices explicitly removed from that set. When a good
low vertex is retained in the omission set, it has no high neighbor on
its own cut side and cannot be adjacent to a high-high attachment vertex.

### 1.2 Triangle kernels and component observation

A triangle containing a low vertex is either a pendant triangle with two
degree-two vertices or one degree-two vertex on a high core edge. An
all-low triangle would be a whole component and cannot occur for h=9.
The structural theorem therefore leaves exactly the over-enumerated
families used by the checker:

1. any core-edge matching, with zero or one pendant triangle at any root;
2. one core-edge P3 and any matching on its remaining six vertices, with
   no pendant triangle.

Offsets from core triangle counts are 0 or 1, with at most one offset 2.
Nontriangle low vertices are kept selected and need not be enumerated.

The separate claim that an odd critical core component has order at least
5 is also valid. Orders 1 or 2 cannot supply every high count≥2; order 3
cannot give three distinct such counts with the offset restriction; an
order-4 component with a core count 3 is K4, yielding at most three final
values, while otherwise core counts≤2 yield at most the values 2,3 and
one exceptional 4. This corollary is **not required by the h=9 coverage**,
which explicitly includes disconnected cores.

## 2. Pruning and omission certificate

### 2.1 Sorted offsets

The sorting lemma is safe. Given bases ai≤aj but assigned final values
xi>xj, exchanging the final values preserves nonnegative offsets. For
equal bases it merely exchanges offsets. For strictly increasing bases,
both new offsets are at most 1, since xi≤ai+2 and values are integral.
Thus inversion removal preserves the limit of one offset 2. For sorted
final values, the candidate greedy sequence is componentwise minimal.
Any offset exceeding 2, or two offsets equal to 2, therefore certifies
infeasibility; no possible counterexample is pruned.

As an independent check, the audit implementation uses a dynamic program
over (previous final value, number of offsets equal to 2), not the
candidate's greedy rejection rule. It gets exactly the same surviving
core count, across 28880 distinct sorted base signatures.

### 2.2 Witness lifting

The guaranteed degree bound is

    d*(v)=max(3, d_H(v)+2p(v)+deg_Q(v)).

For high omissions R, every additional omitted attachment is chosen only
if all its high roots lie outside R. Thus none removes a selected neighbor
of an omitted high vertex. Each omitted low vertex retains its two actual
neighbors outside the omitted set. A pendant triangle contributes at most
one omitted low vertex; the other is selected. Therefore the candidate's
feasibility test and score really construct an omission set of size≥6 in
the original graph. Unlisted low vertices can all remain selected. The
core-only early exit is safe because attachments can only add selected
neighbors when kept selected.

The independent verifier additionally materializes each critical kernel
as a simple graph, adds selected leaves only as needed to represent the
guaranteed lower degree 3, constructs an explicit omitted vertex set, and
checks every omitted vertex directly for two neighbors in its complement.
These auxiliary leaves are a conservative representation of guaranteed
selected-neighbor capacity, not an assumption that actual leaves exist.
The lifting inequality above is the justification for their use.

## 3. Independent completeness certificate

`check_coverage_independent.cpp` does not trust the compression generator.
It independently reads the masks and:

* applies all 7! permutations to each of the 1044 seven-core masks,
  obtaining 5261760 images and marking all **2097152=2^21** labeled graphs;
* checks the binary certificate's exact length and each encoded bijection;
* reconstructs every eight-vertex image with the **inverse** permutation
  and confirms that its mask belongs to the 12346-element destination set;
* verifies all **133632** eighth-vertex extensions, with no missing or
  trailing certificate data.

Deleting a vertex from any eight-vertex graph, then restoring its arbitrary
neighborhood, proves eight-core coverage. Repeating this argument for a
ninth vertex proves that the **3160576** ninth extensions cover every
nine-vertex graph up to isomorphism. No unverified catalogue or claim of
canonical labeling is used. Extra or duplicate isomorphism representatives
would not invalidate this argument.

## 4. Independent kernel execution

`check_h9_independent.cpp` imports no author implementation. Its triangle
counts use explicit triples; its offset filter is the dynamic program
above; its matching enumeration adds increasing edge indices rather than
recursing on the smallest unused vertex; its P3 enumeration selects pairs
of incident edges; and its final checks use materialized graph adjacency.

All candidate totals were reproduced exactly:

| Quantity | Independent result |
|---|---:|
| Ninth-vertex extensions | 3,160,576 |
| Offset-compatible cores | 342,889 |
| Safe with high omissions alone | 340,059 |
| Attachment patterns | 20,064,253 |
| Critical patterns | 296,450 |
| Explicit omission witnesses validated | 296,450 |
| Unresolved critical patterns | **0** |

The structural sanity checker is independent as well. It enumerates all
**1893730** connected labeled graphs of orders 3–7. Of **455367** tight
high-cut-bound graphs (39477 even and 415890 odd), all satisfy the universal
stability conclusions. This includes 5742 odd low-edge cases and 18240
odd P3-incidence cases. The sanity census is not a premise of the universal
proof; it is a separate consistency check.

## 5. Reproduction and status

From the workspace root:

```sh
d=wowii_rounds/round_09/independent_audit/384b
g++ -std=c++17 -O3 "$d/check_coverage_independent.cpp" -o /tmp/cover384b
/tmp/cover384b "$d/core7_masks.txt" "$d/core8_masks.txt" "$d/core8_cover_permutations.bin"
g++ -std=c++17 -O3 "$d/check_h9_independent.cpp" -o /tmp/h9_384b
/tmp/h9_384b "$d/core8_masks.txt"
g++ -std=c++17 -O3 "$d/check_stability_independent.cpp" -o /tmp/stability384b
/tmp/stability384b
```

Compare the three JSON result files. All executions terminated normally
with status PASS and no stderr diagnostics. The finite h=9 theorem is
fully certified subject to the ordinary reproducible integer computation,
not merely sampled from an external connected-graph catalogue. Discovery
catalogue scans are not required for the proof.

**No unresolved blocker.** Full WOWII384b remains open in the stated
residual range; the final order-67 reduction from Round08 is preserved,
not represented as an exhaustive search.
