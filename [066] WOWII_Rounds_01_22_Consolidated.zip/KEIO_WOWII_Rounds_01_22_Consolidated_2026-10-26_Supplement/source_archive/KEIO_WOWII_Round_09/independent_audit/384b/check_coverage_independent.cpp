// Separate verifier: explicit 7-core orbit coverage, then inverse-permutation
// checking for every 8-core certificate. The canonicalizer is not trusted.
#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <set>
#include <stdexcept>
#include <vector>
using U=unsigned;
void require(bool ok,const char*s){if(!ok)throw std::runtime_error(s);}
std::vector<U> read(const char*name,int bits){
 std::ifstream f(name);require(bool(f),"Missing masks");std::vector<U> r;U m;
 while(f>>m){require(m<(1u<<bits),"Invalid mask");r.push_back(m);}require(f.eof()&&!r.empty(),"Malformed masks");return r;
}
std::vector<U> graph(int n,U m){std::vector<U>a(n);int bit=0;
 for(int u=0;u<n;++u)for(int v=u+1;v<n;++v,++bit)if(m&(1u<<bit)){a[u]|=1u<<v;a[v]|=1u<<u;}return a;
}
int main(int argc,char**argv){
 require(argc==4,"usage: core7 core8 permutations");auto r7=read(argv[1],21),r8=read(argv[2],28);
 std::vector<bool> covered(1u<<21);std::uint64_t images=0;
 for(U mask:r7){auto a=graph(7,mask);std::array<int,7> p{0,1,2,3,4,5,6};
  do{U im=0;int bit=0;for(int u=0;u<7;++u)for(int v=u+1;v<7;++v,++bit)if(a[p[u]]&(1u<<p[v]))im|=1u<<bit;
   covered[im]=true;++images;
  }while(std::next_permutation(p.begin(),p.end()));
 }
 auto count7=std::count(covered.begin(),covered.end(),true);require(count7==(1u<<21),"Incomplete 7-core orbit cover");
 std::set<U> destinations(r8.begin(),r8.end());require(destinations.size()==r8.size(),"Duplicate destination masks");
 std::ifstream f(argv[3],std::ios::binary);require(bool(f),"Missing permutation certificate");std::uint64_t maps=0;
 for(U mask:r7)for(U hood=0;hood<128;++hood){
  auto a=graph(7,mask);a.push_back(hood);for(int v=0;v<7;++v)if(hood&(1u<<v))a[v]|=128;
  U code=0;for(int i=0;i<4;++i){int ch=f.get();require(ch!=EOF,"Truncated certificate");code|=U(ch)<<(8*i);}
  require(code<(1u<<24),"Unexpected extra certificate bits");
  std::array<int,8> inverse;inverse.fill(-1);
  for(int old=0;old<8;++old){int now=(code>>(3*old))&7;require(inverse[now]<0,"Not a permutation");inverse[now]=old;}
  U image=0;int bit=0;for(int u=0;u<8;++u)for(int v=u+1;v<8;++v,++bit)
   if(a[inverse[u]]&(1u<<inverse[v]))image|=1u<<bit;
  require(destinations.count(image),"Certified image absent from 8-core list");++maps;
 }
 require(f.get()==EOF,"Trailing certificate bytes");
 std::cout<<"{\"status\":\"PASS\",\"seven_representatives\":"<<r7.size()<<",\"seven_permutation_images\":"<<images
 <<",\"seven_labeled_graphs_covered\":"<<count7<<",\"eight_explicit_isomorphisms_verified\":"<<maps
 <<",\"eight_core_masks\":"<<r8.size()<<",\"implied_ninth_vertex_extensions\":"<<r8.size()*256
 <<",\"generator_trusted\":false}\n";
}
