// Independent h=9 finite verifier. Triangle counts use direct triples.
// Offset feasibility uses a small dynamic program, not the candidate greedy.
// Omission witnesses are validated on explicitly materialized kernel graphs,
// with selected leaves supplying only the guaranteed degree lower bound 3.
#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <unordered_map>
#include <vector>
using U=unsigned;using W=std::uint64_t;using Count=std::uint64_t;
void require(bool b,const char*s){if(!b)throw std::runtime_error(s);}
int pc(W x){return __builtin_popcountll(x);}
std::array<U,9> core;std::array<int,9> triangles;
std::vector<U> edge_roots,chosen;std::vector<U> high_subsets;
std::unordered_map<W,bool> offset_cache;
Count cores=0,compatible=0,safe=0,patterns=0,critical=0,witnesses=0,dp_patterns=0;
Count witness_tests=0,leaf_padding=0;
bool offset_possible(){
 auto a=triangles;std::sort(a.begin(),a.end());W key=0;
 for(int i=0;i<9;++i)key|=W(a[i])<<(5*i);
 auto it=offset_cache.find(key);if(it!=offset_cache.end())return it->second;
 ++dp_patterns;
 // State (previous final count, number of offsets equal to 2).
 bool state[32][2]{};state[1][0]=true;
 for(int x:a){
  bool next[32][2]{};
  for(int last=1;last<32;++last)for(int used=0;used<2;++used)if(state[last][used])
   for(int inc=0;inc<=2;++inc){int y=x+inc,z=used+(inc==2);if(y>last&&y<32&&z<=1)next[y][z]=true;}
  for(int y=0;y<32;++y)for(int z=0;z<2;++z)state[y][z]=next[y][z];
 }
 bool possible=false;for(auto&r:state)possible|=r[0]||r[1];
 offset_cache[key]=possible;return possible;
}
void add_edge(std::vector<W>&g,int u,int v){g[u]|=W(1)<<v;g[v]|=W(1)<<u;}
bool certificate(int pendant){
 std::vector<W> g(9);for(int v=0;v<9;++v)g[v]=core[v];
 std::vector<std::pair<U,int>> private_vertices;
 if(pendant>=0){
  int x=g.size();g.resize(x+2);add_edge(g,pendant,x);add_edge(g,pendant,x+1);add_edge(g,x,x+1);
  private_vertices.push_back({1u<<pendant,x});
 }
 for(U roots:chosen){int x=g.size();g.push_back(0);for(int v=0;v<9;++v)if(roots&(1u<<v))add_edge(g,v,x);
  private_vertices.push_back({roots,x});
 }
 for(int v=0;v<9;++v)while(pc(g[v])<3){int x=g.size();require(x<63,"Kernel too large");g.push_back(0);add_edge(g,v,x);++leaf_padding;}
 for(U r:high_subsets){
  W omit=r;for(auto [roots,v]:private_vertices)if(!(r&roots))omit|=W(1)<<v;
  if(pc(omit)<6)continue;++witness_tests;
  bool valid=true;W scan=omit;
  while(scan){int v=__builtin_ctzll(scan);scan&=scan-1;if(pc(g[v]&~omit)<2){valid=false;break;}}
  if(valid)return true;
 }
 return false;
}
void pattern(int pendant){
 ++patterns;auto t=triangles;
 if(pendant>=0)++t[pendant];
 for(U roots:chosen)for(int v=0;v<9;++v)if(roots&(1u<<v))++t[v];
 auto sorted=t;std::sort(sorted.begin(),sorted.end());if(sorted[0]<2)return;
 if(std::adjacent_find(sorted.begin(),sorted.end())!=sorted.end())return;
 ++critical;require(certificate(pendant),"Unresolved independent h9 kernel");++witnesses;
}
// Increasing edge indices enumerate all matchings; this differs from the
// candidate's smallest-unmatched-vertex recursion.
void matchings(int first,U used,bool pendant_allowed){
 pattern(-1);if(pendant_allowed)for(int v=0;v<9;++v)pattern(v);
 for(int j=first;j<int(edge_roots.size());++j)if(!(edge_roots[j]&used)){
  chosen.push_back(edge_roots[j]);matchings(j+1,used|edge_roots[j],pendant_allowed);chosen.pop_back();
 }
}
void check_core(){
 ++cores;triangles.fill(0);
 for(int u=0;u<9;++u)for(int v=u+1;v<9;++v)if(core[u]&(1u<<v))for(int w=v+1;w<9;++w)
  if((core[u]&(1u<<w))&&(core[v]&(1u<<w))){++triangles[u];++triangles[v];++triangles[w];}
 if(!offset_possible())return;++compatible;chosen.clear();
 if(certificate(-1)){++safe;return;}
 edge_roots.clear();for(int u=0;u<9;++u)for(int v=u+1;v<9;++v)if(core[u]&(1u<<v))edge_roots.push_back((1u<<u)|(1u<<v));
 matchings(0,0,true);
 // Choose two distinct incident edges for the unique possible P3 component.
 for(int i=0;i<int(edge_roots.size());++i)for(int j=i+1;j<int(edge_roots.size());++j)
  if(pc(edge_roots[i]&edge_roots[j])==1){
   chosen={edge_roots[i],edge_roots[j]};matchings(0,edge_roots[i]|edge_roots[j],false);chosen.clear();
  }
}
int main(int argc,char**argv){
 require(argc==2,"usage: core8_masks.txt");std::ifstream f(argv[1]);require(bool(f),"Missing core8 list");
 for(U r=0;r<512;++r)high_subsets.push_back(r);
 std::sort(high_subsets.begin(),high_subsets.end(),[](U a,U b){return pc(a)>pc(b);});
 U mask;Count n8=0;while(f>>mask){require(mask<(1u<<28),"Bad core8 mask");++n8;std::array<U,9> a{};int bit=0;
  for(int u=0;u<8;++u)for(int v=u+1;v<8;++v,++bit)if(mask&(1u<<bit)){a[u]|=1u<<v;a[v]|=1u<<u;}
  for(U hood=0;hood<256;++hood){core=a;core[8]=hood;for(int v=0;v<8;++v)if(hood&(1u<<v))core[v]|=256;check_core();}
 }
 require(f.eof(),"Malformed core8 data");
 std::cout<<"{\"status\":\"PASS\",\"eight_core_masks\":"<<n8<<",\"nine_core_extensions\":"<<cores
 <<",\"offset_compatible_DP\":"<<compatible<<",\"DP_base_signatures\":"<<dp_patterns
 <<",\"safe_before_attachments\":"<<safe<<",\"attachment_patterns\":"<<patterns<<",\"critical_patterns\":"<<critical
 <<",\"explicit_omission_witnesses_validated\":"<<witnesses<<",\"witness_trials\":"<<witness_tests
 <<",\"selected_leaf_padding_occurrences\":"<<leaf_padding<<",\"unresolved\":0,\"scope\":\"h=9 partial theorem only, not full WOWII384b\"}\n";
}
