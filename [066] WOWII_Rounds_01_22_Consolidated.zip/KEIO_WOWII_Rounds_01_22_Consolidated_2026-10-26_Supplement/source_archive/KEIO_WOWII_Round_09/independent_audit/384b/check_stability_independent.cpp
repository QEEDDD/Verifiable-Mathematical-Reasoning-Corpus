#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <set>
#include <stdexcept>
#include <vector>
using U=unsigned;using Count=std::uint64_t;
void require(bool b,const char*s){if(!b)throw std::runtime_error(s);}
int pc(U x){return __builtin_popcount(x);}
bool connected(const std::vector<U>&a){U seen=1,old=0;while(old!=seen){old=seen;for(int v=0;v<int(a.size());++v)if(old&(1u<<v))seen|=a[v];}return seen==(1u<<a.size())-1;}
bool omittable(const std::vector<U>&a,U s){for(int v=0;v<int(a.size());++v)if((s&(1u<<v))&&pc(a[v]&~s)<2)return false;return true;}
int main(){
 Count all=0,has_high=0,tight=0,even=0,odd=0,lowedge=0,p3=0;
 for(int n=3;n<=7;++n){
  std::vector<std::pair<int,int>> edges;for(int u=0;u<n;++u)for(int v=u+1;v<n;++v)edges.push_back({u,v});
  std::vector<std::vector<U>> subsets(n+1);for(U s=0;s<(1u<<n);++s)subsets[pc(s)].push_back(s);
  for(U m=0;m<(1u<<edges.size());++m){
   std::vector<U>a(n);for(int j=0;j<int(edges.size());++j)if(m&(1u<<j)){auto[u,v]=edges[j];a[u]|=1u<<v;a[v]|=1u<<u;}
   if(!connected(a))continue;++all;U H=0;for(int v=0;v<n;++v)if(pc(a[v])>=3)H|=1u<<v;
   int h=pc(H);if(!h)continue;++has_high;int k=(h+1)/2;
   bool large=false;for(U s:subsets[k+1])if(omittable(a,s)){large=true;break;}if(large)continue;
   bool lower=false;for(U s:subsets[k])if(omittable(a,s)){lower=true;break;}require(lower,"Cut lower bound failed");
   ++tight;if(h%2)++odd;else++even;
   U L=((1u<<n)-1)^H;int low=0;for(auto[u,v]:edges)if((L&(1u<<u))&&(L&(1u<<v))&&(a[u]&(1u<<v)))++low;
   std::set<U> incidence;std::array<int,7> degree{};
   for(int x=0;x<n;++x)if(pc(a[x])==2){
    if((a[x]&H)==a[x]){require(incidence.insert(a[x]).second,"Parallel incidence edges");for(int v=0;v<n;++v)if(a[x]&(1u<<v))++degree[v];}
    else require(h%2,"Even degree-two vertex not high-high");
   }
   int maxdegree=*std::max_element(degree.begin(),degree.end());int centers=std::count(degree.begin(),degree.end(),2);
   if(h%2){require(low<=1,"Odd low graph has multiple edges");require(maxdegree<=2&&centers<=1,"Odd incidence not matching plus P3");
    if(low){require(maxdegree<=1,"Low edge but incidence not matching");++lowedge;}if(centers)++p3;
   }else{require(!low&&maxdegree<=1,"Even stability failed");}
  }
 }
 std::cout<<"{\"status\":\"PASS\",\"connected_labeled_graphs_n3_to_n7\":"<<all<<",\"with_high_vertices\":"<<has_high
 <<",\"tight_cut_bound_graphs\":"<<tight<<",\"even_tight\":"<<even<<",\"odd_tight\":"<<odd
 <<",\"odd_low_edge_cases\":"<<lowedge<<",\"odd_P3_cases\":"<<p3<<",\"scope\":\"Finite sanity check of separately audited universal theorem\"}\n";
}
