# Bounded primary-source priority audit: Round 09 / WOWII 133

Checkpoint: 26 October 2026, 03:19 UTC. This is a source/prior-scope audit, not a mathematical certificate or worldwide priority certification. No worker manuscript was modified.

## Findings

- **No exact prior statement of the three claimed density consequences was located in this bounded pass:** (i) connected, induced-P6-free, C4-subgraph-free graphs have mean local independence at most 3, equality only for Petersen; (ii) the corresponding P7-free mean is strictly below 4; (iii) connected bipartite P8-free C4-free graphs have average degree at most 3, equality only for Heawood. This negative finding is bounded and does not establish novelty.
- **Established structural work is essential context, not new work here.** Brandstädt–Hoàng (2007), as restated in Gaspers–Huang–Paulusma (2018), Theorem 9, gives the dominating-C5 / Petersen-blowup structure of (induced-C4, P6)-free atoms. The narrower C4-**subgraph**-free specialization and its deficit consequences must not be presented as a new general atom theorem.
- **Chen–Wu–Xu's prior Theorem 1.3 was checked directly** in arXiv:2302.11115v1: a connected (P7,C4,gem)-free graph with no clique cutset is a clique blowup of Petersen or has a bisimplicial vertex. Their convention forbids induced copies. Round09 uses the stronger C4-subgraph-free hypothesis, which also excludes a gem. The P7 argument is a consequence of this credited prior structural input, not a new structural decomposition.
- **Additional prior result newly located:** Chudnovsky–Stacho, *3-colorable subclasses of P8-free graphs*, author manuscript dated 1 October 2017, Theorem 1: a connected P8-free graph of girth at least 5 is Petersen, Heawood, Heawood with one edge contracted, or has a vertex of degree at most 2. In the bipartite case, Heawood is the only listed minimum-degree-at-least-3 exception. This theorem alone does **not** supply average degree at most 3: deleting and then restoring a degree-two vertex can increase `2m-3n` by one. It is relevant prior structure, not an established collision with the exact Round09 density/equality theorem.
- Petersen being P6-free and Heawood being P8-free are old facts; both appear explicitly in Hammersen–Randerath (2013), Section 4. Their use as sharpness examples is not a new graph discovery.

## Primary references

1. A. Brandstädt and C. T. Hoàng, *On clique separators, nearly chordal graphs, and the Maximum Weight Stable Set Problem*, Theoretical Computer Science **389** (2007), 295–306. https://doi.org/10.1016/j.tcs.2007.09.031 . The inspected primary restatement is S. Gaspers, S. Huang, D. Paulusma, *Colouring Square-Free Graphs without Long Induced Paths*, STACS 2018, Article 35, Theorem 9: https://doi.org/10.4230/LIPIcs.STACS.2018.35 .
2. R. Chen, D. Wu, B. Xu, *Structure and coloring of some (P7,C4)-free graphs*, arXiv:2302.11115v1 (22 February 2023), Theorem 1.3: https://arxiv.org/abs/2302.11115v1 . Journal version: *Structure of some (P7,C4)-free graphs with application to colorings*, Discrete Applied Mathematics **357** (2024), 14–23, https://doi.org/10.1016/j.dam.2024.05.038 . The inspected theorem numbering is the v1 preprint numbering.
3. M. Chudnovsky and J. Stacho, *3-colorable subclasses of P8-free graphs*, author manuscript dated 1 October 2017, Theorem 1: https://web.math.princeton.edu/~mchudnov/p8free1.pdf .
4. K. Hammersen and B. Randerath, *On mirror nodes in graphs without long induced paths*, Australasian Journal of Combinatorics **55** (2013), 263–272, Section 4: https://ajc.maths.uq.edu.au/pdf/55/ajc_v55_p263.pdf .

## Search scope and limitations

Primary papers above were read at the relevant statements. Focused web searches included `P6-free C4-free Petersen degree`, `P8-free Heawood bipartite`, `P7-free average degree 4`, `P8-free average degree`, and `P6-free Petersen edges`. Previously downloaded all-state public WOWII/Gebendorfer issue/PR bodies were searched, together with fresh GitHub issue searches for P8-free/Heawood and P6-free/Petersen (both zero hits). Exact-number search is not treated as exhaustive evidence. Existing public #133 partials and the original naked-square-bracket ambiguity remain as previously recorded; this audit does not certify either a full #133 resolution or an unambiguous floor convention.

Only this note and `compact_provenance.json` need be included in the delivered ZIP; third-party PDFs are research cache, not requested redistributions.
