import json,itertools
exec(open('wowii_rounds/round_09/domination133/classify_atoms133.py').read().split('for am in range(32):')[0])
for x in json.load(open('wowii_rounds/round_09/domination133/atoms133.json')):
 if x['am'] not in [15,31]:continue
 a=x['adj'];n=len(a);valid=[]
 for k in [1,2,3]:
  for ss in itertools.combinations(range(n),k):
   if any(not(a[u]>>v&1) for u,v in itertools.combinations(ss,2)):continue
   aa=a+[sum(1<<s for s in ss)]
   for s in ss:aa[s]|=1<<n
   if any((aa[u]&aa[v]).bit_count()>1 for u in range(n+1) for v in range(u)):continue
   if not hasp(aa,6):valid.append(ss)
 print(x['n'], 'valid clique-contact extensions',valid)
