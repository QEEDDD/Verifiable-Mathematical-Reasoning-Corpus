#include <bits/stdc++.h>
using namespace std;
using U=uint64_t;
long long c4free_count=0,connected_count=0,p6_count=0,p7_count=0;
struct G{int n;vector<U>a;G(int n):n(n),a(n){}
 bool connected(){U seen=1,old=0,full=(1ull<<n)-1;while(seen!=old){old=seen;for(int i=0;i<n;i++)if(seen>>i&1)seen|=a[i];}return seen==full;}
 bool path(int k){function<bool(int,U,U,int)>f=[&](int v,U used,U ban,int len){if(len==k)return true;U z=a[v]&~(used|ban);while(z){int w=__builtin_ctzll(z);z&=z-1;if(f(w,used|(1ull<<w),ban|a[v],len+1))return true;}return false;};for(int i=0;i<n;i++)if(f(i,1ull<<i,0,1))return true;return false;}
 bool allow(int u,int v){U z=a[u];while(z){int w=__builtin_ctzll(z);z&=z-1;if(a[w]&a[v])return false;}return true;}
 void check(){c4free_count++;if(!connected())return;connected_count++;int deg=0,tr6=0;for(int u=0;u<n;u++){deg+=__builtin_popcountll(a[u]);U z=a[u];while(z){int v=__builtin_ctzll(z);z&=z-1;tr6+=__builtin_popcountll(a[u]&a[v]);}}int t=tr6/6,L=deg-3*t;bool complete=(deg==n*(n-1));if(!path(6)){p6_count++;int D=3*n-L;assert(n==1?D==3:D>=4);if(t)assert(D>=6);}if(!path(7)){p7_count++;int F=4*n-L;if(!complete)assert(F>=8);if(t)assert(F>=9);assert(L<4*n);}}
};
int main(){for(int n=1;n<=7;n++){G g(n);vector<pair<int,int>>e;for(int u=0;u<n;u++)for(int v=0;v<u;v++)e.emplace_back(u,v);function<void(int)>rec=[&](int i){if(i==(int)e.size()){g.check();return;}rec(i+1);auto[u,v]=e[i];if(g.allow(u,v)){g.a[u]|=1ull<<v;g.a[v]|=1ull<<u;rec(i+1);g.a[u]^=1ull<<v;g.a[v]^=1ull<<u;}};rec(0);cerr<<"through n="<<n<<" connected="<<connected_count<<" p6="<<p6_count<<" p7="<<p7_count<<endl;}cout<<"{\"status\":\"PASS\",\"max_order\":7,\"c4free_labeled_graphs\":"<<c4free_count<<",\"connected_c4free_graphs\":"<<connected_count<<",\"p6_free_checked\":"<<p6_count<<",\"p7_free_checked\":"<<p7_count<<"}"<<endl;}
