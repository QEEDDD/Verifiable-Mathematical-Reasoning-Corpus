import itertools,json,collections
out=[]
def bititer(x):
 while x:
  b=x&-x;x-=b;yield b.bit_length()-1
def conn(a,mask):
 if not mask:return True
 seen=mask&-mask;old=0
 while seen!=old:
  old=seen
  for v in bititer(seen):seen|=a[v]&mask
 return seen==mask
def hasp(a,k,root=None):
 n=len(a)
 def dfs(v,used,ban,depth):
  if depth>=k:return True
  for w in bititer(a[v]&~used&~ban):
   if dfs(w,used|(1<<w),ban|a[v],depth+1):return True
  return False
 return any(dfs(v,1<<v,0,1) for v in (range(n) if root is None else [root]))
def clique_cut(a):
 n=len(a);full=(1<<n)-1
 for k in range(1,4):
  for ss in itertools.combinations(range(n),k):
   mask=sum(1<<s for s in ss)
   if all((a[s]&mask).bit_count()==k-1 for s in ss) and not conn(a,full^mask):return True
 return False
for am in range(32):
 for bm in range(32):
  if any((bm>>i&1) and (bm>>((i+1)%5)&1) for i in range(5)):continue
  poss=[i for i in range(5) if (am>>i&1) and (bm>>((i+2)%5)&1)]
  for xm in range(1<<len(poss)):
   names=list(range(5))+['a'+str(i) for i in range(5) if am>>i&1]+['b'+str(i) for i in range(5) if bm>>i&1]
   idx={s:i for i,s in enumerate(names)};n=len(names);a=[0]*n
   def edge(x,y):
    u,v=idx[x],idx[y];a[u]|=1<<v;a[v]|=1<<u
   for i in range(5):
    edge(i,(i+1)%5)
    if am>>i&1:
     edge('a'+str(i),i)
     if am>>((i+2)%5)&1:edge('a'+str(i),'a'+str((i+2)%5))
    if bm>>i&1:
     edge('b'+str(i),i);edge('b'+str(i),(i+1)%5)
   for j,i in enumerate(poss):
    if xm>>j&1:edge('a'+str(i),'b'+str((i+2)%5))
   if any((a[i]&a[j]).bit_count()>1 for i in range(n) for j in range(i)):continue
   if hasp(a,6) or clique_cut(a):continue
   m=sum(x.bit_count() for x in a)//2
   tri=sum((a[i]&a[j]).bit_count() for i in range(n) for j in bititer(a[i]))//6
   L=2*m-3*tri;D=3*n-L
   roots=[max(k for k in range(1,6) if hasp(a,k,v)) for v in range(n)]
   out.append(dict(am=am,bm=bm,xm=xm,n=n,m=m,t=tri,L=L,D=D,roots=roots,names=names,adj=a))
print('labeled cases',len(out))
print('n,m,t,D multiplicities',collections.Counter((x['n'],x['m'],x['t'],x['D']) for x in out))
print('minimum D',min(x['D'] for x in out))
for x in out:
 if x['D']<5:print({k:v for k,v in x.items() if k not in ['adj','names']})
json.dump(out,open('wowii_rounds/round_09/domination133/atoms133.json','w'),indent=2)
