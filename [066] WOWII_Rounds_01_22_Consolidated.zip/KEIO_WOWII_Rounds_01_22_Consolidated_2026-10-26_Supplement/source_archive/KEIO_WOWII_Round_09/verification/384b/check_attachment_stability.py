#!/usr/bin/env python3
"""Finite sanity tests for proved structural lemmas, NOT a universal graph proof.
Uses independently covered seven-vertex masks from Round08; connected cases only.
"""
from pathlib import Path
from collections import Counter
import itertools as it,json
source=Path(__file__).resolve().parents[2]/'round_08/twodomination/core7_masks.txt'
es=list(it.combinations(range(7),2));counts=Counter();examples={}
for mask in map(int,source.read_text().split()):
    a=[0]*7
    for i,(u,v) in enumerate(es):
        if mask>>i&1:a[u]|=1<<v;a[v]|=1<<u
    reached=1
    while True:
        new=reached
        for v in range(7):
            if reached>>v&1:new|=a[v]
        if new==reached:break
        reached=new
    if reached!=127:continue
    counts['connected_cores_tested']+=1
    degree=[x.bit_count() for x in a];H={v for v in range(7) if degree[v]>=3};h=len(H)
    if not h:continue
    k=max(s.bit_count() for s in range(128) if all(degree[v]-(a[v]&s).bit_count()>=2 for v in range(7) if s>>v&1))
    if k!=(h+1)//2:continue
    counts['tight_high_cut_bound_graphs']+=1
    counts['odd' if h%2 else 'even']+=1
    D2={v for v in range(7) if degree[v]==2};L={v for v in range(7) if degree[v]<=2}
    J=[];P=0
    for x in D2:
        nn=[v for v in range(7) if a[x]>>v&1]
        if set(nn)<=H:J.append(tuple(nn))
        for y in nn:
            if y in D2 and x<y:
                common=(a[x]&a[y])
                if any(common>>v&1 for v in H):P+=1
    assert len(set(J))==len(J)
    jdeg=Counter(v for edge in J for v in edge)
    max_jdeg=max(jdeg.values(),default=0)
    low_edges=[(u,v) for u,v in es if u in L and v in L and a[u]>>v&1]
    if h%2:
        assert max_jdeg<=2
        assert sum(d==2 for d in jdeg.values())<=1
        assert P<=1
        if P:assert max_jdeg<=1
        assert len(low_edges)<=1
    else:
        assert max_jdeg<=1
        assert not low_edges
        assert all(set(v for v in range(7) if a[x]>>v&1)<=H for x in D2)
    key=('odd' if h%2 else 'even')+('_P3' if max_jdeg==2 else '_matching')
    if key not in examples:examples[key]=dict(mask=mask,h=h,k=k,J=J,P=P,low_edges=low_edges)
result={'status':'PASS','scope':'Finite sanity check only; universal proof is separate.','counts':dict(counts),'examples':examples}
Path(__file__).with_name('attachment_stability_checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
