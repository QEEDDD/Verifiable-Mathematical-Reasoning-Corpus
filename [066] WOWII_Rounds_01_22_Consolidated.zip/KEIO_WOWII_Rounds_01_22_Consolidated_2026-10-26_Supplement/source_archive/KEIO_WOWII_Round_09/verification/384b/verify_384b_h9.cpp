// All ninth-vertex neighborhoods of the independently covered eight-cores.
// Uses the proved odd attachment stability: a matching, possibly with one
// pendant triangle, or a matching plus one disjoint P3 of triangle attachments.
#include <array>
#include <vector>
#include <fstream>
#include <iostream>
#include <algorithm>
#include <cstdint>
using U=uint32_t;
std::array<U,9>a;std::array<int,9>base;
std::vector<std::pair<int,int>>Q;int P=-1;
uint64_t cores=0,filtered=0,core_safe=0,pats=0,crit=0,bad=0;
bool omission(){
 std::array<int,9>b;for(int v=0;v<9;v++)b[v]=__builtin_popcount(a[v])+(v==P?2:0);
 for(auto [u,v]:Q){b[u]++;b[v]++;}for(auto&x:b)x=std::max(x,3);
 for(U r=0;r<512;r++){
  int score=__builtin_popcount(r)+(P>=0 && !(r>>P&1));
  for(auto [u,v]:Q)if(!(r&(1u<<u))&&!(r&(1u<<v)))score++;
  if(score<6)continue;
  bool ok=true;for(int v=0;v<9;v++)if(r>>v&1)if(b[v]-__builtin_popcount(a[v]&r)<2){ok=false;break;}
  if(ok)return true;
 }
 return false;
}
void visit(){
 pats++;auto t=base;if(P>=0)t[P]++;for(auto[u,v]:Q){t[u]++;t[v]++;}
 U vals=0;for(int x:t){if(x<2)return;vals|=1u<<x;}if(__builtin_popcount(vals)!=9)return;
 crit++;if(!omission()){bad++;if(bad<=5){std::cerr<<"UNRESOLVED core";for(U x:a)std::cerr<<' '<<x;std::cerr<<" P "<<P<<" Q";for(auto[u,v]:Q)std::cerr<<' '<<u<<','<<v;std::cerr<<'\n';}}
}
void match(U rem,bool allowP){
 if(!rem){P=-1;visit();if(allowP)for(P=0;P<9;P++)visit();P=-1;return;}
 int u=__builtin_ctz(rem);rem&=~(1u<<u);match(rem,allowP);
 U ns=a[u]&rem;while(ns){int v=__builtin_ctz(ns);ns&=ns-1;Q.push_back({u,v});match(rem&~(1u<<v),allowP);Q.pop_back();}
}
void core(){
 cores++;
 for(int v=0;v<9;v++){int x=0;for(int u=0;u<9;u++)if(a[v]>>u&1)x+=__builtin_popcount(a[v]&a[u]);base[v]=x/2;}
 auto t=base;std::sort(t.begin(),t.end());int prev=1,twos=0;
 for(int x:t){int y=std::max(x,prev+1),inc=y-x;if(inc>2)return;if(inc==2)twos++;prev=y;}
 if(twos>1)return;filtered++;
 P=-1;Q.clear();if(omission()){core_safe++;return;}
 match(511,true);
 for(int v=0;v<9;v++)for(int u=0;u<9;u++)if(a[v]>>u&1)for(int w=u+1;w<9;w++)if(a[v]>>w&1){Q={{v,u},{v,w}};match(511&~((1u<<u)|(1u<<v)|(1u<<w)),false);Q.clear();}
}
int main(int argc,char**argv){if(argc!=2)return 2;std::ifstream in(argv[1]);if(!in)return 2;U mask;
 while(in>>mask){std::array<U,9>g{};int i=0;for(int u=0;u<8;u++)for(int v=u+1;v<8;v++,i++)if(mask>>i&1){g[u]|=1u<<v;g[v]|=1u<<u;}
  for(U hood=0;hood<256;hood++){a=g;a[8]=hood;for(int u=0;u<8;u++)if(hood>>u&1)a[u]|=256;core();}
 }
 std::cout<<"{\"h\":9,\"core_extensions\":"<<cores<<",\"offset_compatible\":"<<filtered<<",\"safe_before_attachments\":"<<core_safe<<",\"attachment_patterns\":"<<pats<<",\"critical_patterns\":"<<crit<<",\"unresolved_kernels\":"<<bad<<",\"status\":\""<<(bad?"UNRESOLVED":"PASS")<<"\"}\n";
 return bad?1:0;}
