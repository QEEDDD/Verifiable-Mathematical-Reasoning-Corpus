#!/usr/bin/env python3
"""Independent coverage certificate for all 8-vertex cores.
The canonicalization/compression generator is NOT trusted: every supplied
mapping is checked as an actual vertex permutation and graph isomorphism.
Completeness of the seven-core source is independently checked by the bundled C++ tool.
"""
from pathlib import Path
import itertools as it,struct,json,hashlib
root=Path(__file__).resolve().parent
raw7=(root/'core7_masks.txt').read_bytes();raw8=(root/'core8_masks.txt').read_bytes();rawp=(root/'core8_cover_permutations.bin').read_bytes()
r7=list(map(int,raw7.split()));r8=set(map(int,raw8.split()))
assert all(0<=m<1<<28 for m in r8)
assert len(rawp)==len(r7)*128*4
perms=iter(struct.iter_unpack('<I',rawp))
edges7=list(it.combinations(range(7),2));edges8=list(it.combinations(range(8),2));eid={e:i for i,e in enumerate(edges8)}
count=0
for m in r7:
    ee=[e for i,e in enumerate(edges7) if m>>i&1]
    for hood in range(128):
        code=next(perms)[0];p=[code>>(3*v)&7 for v in range(8)]
        assert sorted(p)==list(range(8))
        image=0
        for u,v in ee+[(u,7) for u in range(7) if hood>>u&1]:
            x,y=sorted((p[u],p[v]));image|=1<<eid[(x,y)]
        assert image in r8
        count+=1
result={'status':'PASS','scope':'All eighth-vertex neighborhoods of independently covered seven-cores map to supplied eight-core masks by explicitly verified permutations.','source7_masks':len(r7),'extensions_covered':count,'destination8_masks':len(r8),'sha256_core7':hashlib.sha256(raw7).hexdigest(),'sha256_core8':hashlib.sha256(raw8).hexdigest(),'sha256_permutations':hashlib.sha256(rawp).hexdigest()}
(root/'core8_coverage.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
