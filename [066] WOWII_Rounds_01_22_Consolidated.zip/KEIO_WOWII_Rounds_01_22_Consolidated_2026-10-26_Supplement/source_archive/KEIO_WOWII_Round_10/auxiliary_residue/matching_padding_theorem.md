# Weak majorization of Havel–Hakimi elimination sequences by matching padding

## Result and exact scope

Let `A` and `B` be graphical degree lists, sorted in nonincreasing order. Pad by zeros when comparing lists of different lengths. Suppose every degree prefix of `A` has sum at least the corresponding prefix of `B`; equality of total sums is **not** assumed. Then every prefix of the canonical Havel–Hakimi elimination sequence `E(A)` has sum at least the corresponding prefix of `E(B)`.

This supplies the numerical `DegreePrefixNoResidualOvershootBridge` sought in the current c5-k4 61 proof-extraction notes, **on graphical inputs**. It is a short corollary of an established theorem of Triesch (1996), with a matching-padding argument. It is **not a full proof of WOWII 61**: the separate forest/diameter augmentation remains open. It is also not a Lean formalization; no claim is made about arbitrary nongraphical lists accepted by a recursive Lean function.

## Established theorem used

Triesch's elimination-sequence majorization theorem states that if two graphical degree sequences have equal total sum and one majorizes the other, their Havel–Hakimi elimination sequences have the same majorization order.

Primary research source inspected: Michaela Hiller, *On the Domination Order among Elimination Sequences*, arXiv:2206.05820, **Theorem 1.6**, explicitly credited there to Triesch:

<https://arxiv.org/html/2206.05820>

Original reference: E. Triesch, *Degree sequences of graphs and dominance order*, Journal of Graph Theory 22 (1996), 89–93. This existing theorem is credited rather than represented as proved here.

## Definitions

For a descending graphical list `d`, one Havel–Hakimi step deletes its largest entry `h`, subtracts one from the next `h` entries, and sorts again. Its elimination sequence consists of the deleted positive heads in order, followed by enough zeros to restore the original length. This sequence is nonincreasing. Its total sum is one half of the original degree sum.

Write `P_k(d)` for the sum of the first `k` entries, with zero padding. The hypothesis is `P_k(A)>=P_k(B)` for every `k`.

First add zeros so that `A` and `B` have a common length `n`. Since both are graphical, the difference of their total sums is an even nonnegative integer. Write it as `2m`.

Define

\[
A'=A\cup 0^{2m},\qquad B'=B\cup 1^{2m},
\]

sorting the merged lists. `A'` is realized by adding `2m` isolated vertices to a realization of `A`; `B'` is realized by adding `m` disjoint edges to a realization of `B`. The two lists are graphical, have equal length, and have equal total sum.

## Lemma 1 The padded degree lists have ordinary majorization

Let `p` be the number of positive entries of `A`.

For `k<=p`, any selection of `k` entries from `B'` uses some `q<=k` entries from `B` and `k-q` appended ones. Its sum is at most

\[
P_q(B)+(k-q)
\le P_q(A)+(k-q)
\le P_k(A).
\]

The last inequality holds because the first `k` entries of `A` are all positive integers. In particular this applies to a maximum-sum selection of `k` entries, proving `P_k(B')<=P_k(A')`.

For `k>p`, `P_k(A')` is already the total sum of `A'`, which equals the total sum of `B'`, and therefore dominates every prefix of `B'`. Thus `A'` majorizes `B'` in the ordinary equal-sum sense.

## Lemma 2 Disjoint matching padding has an exact elimination identity

For every graphical `B` and every `m>=0`,

\[
E(B\cup1^{2m})
=\operatorname{sort}\bigl(E(B)\cup1^m\cup0^m\bigr).
\]

To prove this, follow the canonical reductions of the `B` portion before processing the appended matching. At a positive head `h` of the current `B` portion, graphicality guarantees at least `h` positive entries after the head: these are the degrees of the head vertex's distinct neighbors in a realization. Every entry selected by `B`'s own Havel–Hakimi step is therefore at least one. The appended ones can only tie with, never strictly displace, the selected original entries. Resolve these ties in favor of the `B` entries. This is a legitimate canonical reduction of the combined degree multiset and leaves all appended ones untouched.

Continue until the `B` portion consists of zeros. The appended `2m` ones then produce exactly `m` eliminated heads equal to one and `m` further terminal zeros. Sorting ties does not affect any degree multiset or subsequent head. The claimed identity follows.

Likewise, adding isolated vertices merely appends zeros to an elimination sequence.

## Theorem Weak degree-prefix order implies weak elimination-prefix order

Apply Triesch's established equal-sum theorem to `A'` and `B'` from Lemma 1. For every `k`,

\[
P_k(E(A'))\ge P_k(E(B')).
\]

Adding isolates leaves `P_k(E(A'))=P_k(E(A))`. By Lemma 2, the multiset defining `E(B')` contains `E(B)` and additional nonnegative entries, so its largest `k` entries have sum at least `P_k(E(B))`. Consequently

\[
\boxed{P_k(E(A))\ge P_k(E(B))\quad\text{for every }k.}
\]

This proves the claimed extension from equal-sum to weak majorization, including lists of different lengths after zero padding.

## Residual-gap consequence

Let `A_k,B_k` be the residual degree lists after `k` canonical steps, padding completed histories by zero heads. Write `gap_k=sum(A_k)-sum(B_k)`. Each eliminated head `h` removes exactly `2h` degree-sum units, so

\[
\operatorname{gap}_k
=\operatorname{gap}_0
-2\bigl(P_k(E(A))-P_k(E(B))\bigr)
\le\operatorname{gap}_0.
\]

This is exactly the no-residual-overshoot conclusion on graphical inputs. It does not assert the false stronger claim that the entire residual lists retain their initial prefix-dominance relation after every step.

## Relationship to WOWII 61

The external gap report is:

<https://raw.githubusercontent.com/Kuberwastaken/c5-k4/main/results/expansion/method_v28_61_residual_overshoot.md>

The earlier scope report explicitly stops before graph deletion and Maxine induction:

<https://raw.githubusercontent.com/Kuberwastaken/c5-k4/main/results/expansion/method_v04_61_transfer.md>

Thus the result above proves only the graphical-input specialization of the auxiliary sequence-side statement. In particular, it must not be described as closing the original inequality `f>=residue+ceil(diameter/3)`. The classical residue/Maxine facts used in this round's structural reduction were already available independently of this extension. A graph-level selection or augmentation argument is still needed.

## Reproducible checks

`verify_matching_padding.cpp` generates every descending graphical degree sequence through order eight using the Erdős–Gallai criterion. It checks:

1. weak elimination-prefix order for every weakly ordered pair;
2. the equal-sum degree-prefix padding step for each such pair;
3. the exact matching-padding elimination identity for every generated sequence and every `0<=m<=n(n-1)/2`.

Compile and run:

```bash
g++ -O3 -std=c++17 verify_matching_padding.cpp -o verify_matching_padding
./verify_matching_padding 8 > matching_padding_results.json
```

These finite checks guard the formulation and padding arithmetic. The proof is the argument above using the credited Triesch theorem, not the finite test.
