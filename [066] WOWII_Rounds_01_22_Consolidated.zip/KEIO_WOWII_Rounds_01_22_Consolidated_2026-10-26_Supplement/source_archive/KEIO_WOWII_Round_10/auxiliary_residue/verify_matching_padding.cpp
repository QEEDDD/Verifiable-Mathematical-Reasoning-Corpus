// C++17 exact checks for the matching-padding weak-majorization argument.
#include <bits/stdc++.h>
using namespace std;
bool graphical(const vector<int>&d){int n=d.size(),sum=accumulate(d.begin(),d.end(),0);if(sum%2)return false;int lhs=0;for(int k=1;k<=n;++k){lhs+=d[k-1];int rhs=k*(k-1);for(int j=k;j<n;++j)rhs+=min(k,d[j]);if(lhs>rhs)return false;}return true;}
vector<int> elimination(vector<int>d){int n=d.size();vector<int>e;while(!d.empty()&&d[0]){int x=d[0];e.push_back(x);d.erase(d.begin());assert(x<=(int)d.size());for(int j=0;j<x;++j){assert(d[j]>0);--d[j];}sort(d.rbegin(),d.rend());}while((int)e.size()<n)e.push_back(0);return e;}
bool dominates(const vector<int>&a,const vector<int>&b){int x=0,y=0;for(size_t k=0;k<max(a.size(),b.size());++k){if(k<a.size())x+=a[k];if(k<b.size())y+=b[k];if(x<y)return false;}return true;}
void gen(int n,int maxd,vector<int>&cur,vector<vector<int>>&out){if((int)cur.size()==n){if(graphical(cur))out.push_back(cur);return;}for(int d=maxd;d>=0;--d){cur.push_back(d);gen(n,d,cur,out);cur.pop_back();}}
int main(int argc,char**argv){int N=argc>1?atoi(argv[1]):8;long long pairs=0,matching=0;cout<<"{\"result\":\"PASS\",\"orders\":[";for(int n=1;n<=N;++n){vector<vector<int>>ds;vector<int>cur;gen(n,n-1,cur,ds);vector<vector<int>>es;vector<int>sums;for(auto&d:ds){es.push_back(elimination(d));sums.push_back(accumulate(d.begin(),d.end(),0));}
long long p=0,mct=0;for(size_t i=0;i<ds.size();++i){for(int m=0;m<=n*(n-1)/2;++m){auto b=ds[i];b.insert(b.end(),2*m,1);sort(b.rbegin(),b.rend());auto expected=es[i];expected.insert(expected.end(),m,1);expected.insert(expected.end(),m,0);sort(expected.rbegin(),expected.rend());assert(elimination(b)==expected);++mct;}
for(size_t j=0;j<ds.size();++j){if(!dominates(ds[i],ds[j]))continue;++p;assert(dominates(es[i],es[j]));int m=(sums[i]-sums[j])/2;assert(m>=0);auto a=ds[i],b=ds[j];a.insert(a.end(),2*m,0);b.insert(b.end(),2*m,1);sort(b.rbegin(),b.rend());assert(a.size()==b.size());assert(accumulate(a.begin(),a.end(),0)==accumulate(b.begin(),b.end(),0));assert(dominates(a,b));}}
if(n>1)cout<<",";cout<<"{\"n\":"<<n<<",\"graphical_sequences\":"<<ds.size()<<",\"weakly_ordered_pairs\":"<<p<<",\"matching_identity_checks\":"<<mct<<"}";pairs+=p;matching+=mct;}
cout<<"],\"total_weakly_ordered_pairs\":"<<pairs<<",\"total_matching_identity_checks\":"<<matching<<"}\n";}
