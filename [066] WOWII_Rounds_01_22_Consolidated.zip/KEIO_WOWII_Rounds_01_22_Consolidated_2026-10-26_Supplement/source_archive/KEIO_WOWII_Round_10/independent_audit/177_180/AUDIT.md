# Independent audit: claw-free subclasses of WOWII 177 and 180

**Verdict: PASS for both claw-free subclass theorems. Neither original
numbered conjecture is fully closed.**

Reviewed on 26 October 2026. The authoritative consolidated candidate is
`round_10/leaves/clawfree_177_180.md`, with its matching TeX version.
The initial #180 note, final #177 extraction, and author sanity scripts
were also inspected. The final proof includes all needed rooted-domination,
simplicial-vertex and weaker-Waller-bound arguments; acceptance does not
rest on blindly citing the supplied AI baseline.

No mathematical gap or finite-check failure was found. Priority of these
subclass consequences is not certified. The arbitrary connected graphs
containing induced claws remain outside the proved class.

## 1. Exact definitions and small cases

The pinned primary-row transcription confirms:

* 177: L+b≥2 alpha+sigma, where sigma is the **second-smallest degree
  with multiplicity**, not minimum degree or second distinct degree.
* 180: L+b≥1+alpha+max_v |E(v)|, where even distance includes zero.
* Both original rows concern connected graphs of order at least two.

The bipartite number b is maximum **induced** bipartite vertex order;
the bipartite subgraph need not be connected. The leaf number L is the
maximum over spanning trees, not a number of leaves in the graph itself.

For n≥3, L=n−gamma_c: internal vertices of a spanning tree form a connected
dominating set, while a spanning tree on a connected dominating set can
be extended by attaching every remaining vertex as a leaf. Hence with
eta=b−gamma_c−1, the exact targets are

    n+1+eta≥2 alpha+sigma,
    eta≥alpha−min_v |O(v)|.

There is no rounding change. K2 is correctly separated: L=2, b=2,
alpha=sigma=1 and max |E(v)|=1, so both original inequalities hold.

## 2. Foundational construction and dependency audit

The required DeLaViña–Waller method and weaker 177 inequality are published
in *Spanning Trees with Many Leaves and Average Distance*, Electronic
Journal of Combinatorics 15 (2008), R33, DOI 10.37236/757. The publisher
metadata was verified, and the local published PDF/text was read at
Theorems 3–5, especially the full construction on printed pp.10–12.
Printed p.11 was visually inspected. Source provenance and hashes are
recorded separately; no third-party full PDF is duplicated in this packet.

The final candidate gives a sufficiently explicit, independently checkable
version of that method:

1. Start with a maximal connected induced bipartite piece containing the
   prescribed root and a neighbor. Each later piece is grown entirely
   outside the previous pieces and their neighborhoods, so all pieces
   are pairwise anticomplete. Their union is induced bipartite.
2. If the union does not dominate, connectedness supplies a distance-two
   root and a connector to an earlier piece. At most one connector is
   added per later piece; repetitions only improve the count.
3. For any final uncolored vertex, its first contacted piece was built
   while that vertex was eligible. Maximality forces contacts with both
   colors of this connected piece. Thus a singleton can never be its
   first contacted piece. Connectors remain uncolored permanently because
   they already neighbor an earlier piece.
4. Delete a spanning-tree leaf different from the attachment root from
   every nonsingleton piece. Delete a later singleton altogether. The
   first piece retains the prescribed root. Each surviving later piece
   retains its root and connects through its connector to a retained
   vertex of an earlier piece. A connector's first piece cannot be a
   deleted singleton. Keeping all connectors preserves connectivity,
   even when a later piece vanishes.
5. Every uncolored vertex retains a neighbor in its first piece; every
   deleted nonsingleton leaf has a retained tree neighbor; every deleted
   singleton root has its retained connector. The resulting set is
   connected dominating and has order at most |B|+k−(k+1)≤b−1.

This proves the rooted bound and eta≥0. At eta=0 it places every prescribed
vertex in a minimum connected dominating set. If such a vertex is
simplicial, removing it from a nonsingleton minimum set preserves
connectivity and domination: a retained neighbor dominates all its private
outside neighbors. The singleton minimum-set case makes the graph complete.
Thus a noncomplete zero-slack graph has no simplicial vertex, and delta≥2.
No separate no-cutvertex theorem is needed in the final #177 proof.

For a maximal odd induced bipartite path as the initial piece, delete both
same-color endpoints. The retained path is nonempty and connected and
contains the entire opposite color class. All first-piece contacts and
connectors therefore retain a neighbor. Later pieces are handled exactly
as above, giving gamma_c≤|B|−2≤b−2. This refinement is universal, not
restricted to claw-free graphs. The singleton/repeated-connector cases
are not omitted.

The weaker Waller inequality L+b≥2 alpha+1 is also reproved correctly.
For maximum independent I, let m be the number of components of V\I.
One representative per component together with I is induced bipartite,
so b≥alpha+m. The complement dominates I because the graph is nontrivial
and connected. At most m−1 vertices of I connect its components: after
contracting them, connectedness gives an I vertex joining the currently
reached union to a new component at each step. Thus gamma_c≤n−alpha+m−1,
and the desired inequality follows. It is correctly credited as prior work.

## 3. WOWII 180: all claw-free graphs

### 3.1 Odd-layer injection

For independent I and root v, send each positive even-layer member x to
an arbitrary predecessor p(x) in the preceding odd layer; send odd-layer
members to themselves. A shared predecessor for two distinct independent
even-layer vertices would have a preceding neighbor in the next lower
even layer. That lower vertex is nonadjacent to both independent vertices
by distance, producing an induced claw. A predecessor image cannot be an
odd-layer member of I because it is adjacent to its preimage in I. Thus
I\{v} injects into O(v), proving the exact indicator inequality.

### 3.2 Essential vertex and maximal odd bipartite path

Fix a maximum independent set I containing an essential vertex v. Choose
a longest induced alternating odd path containing v with both endpoints
in I. Every internal non-I vertex has two I neighbors on the path and
therefore cannot have any third I neighbor outside it. The singleton is
not maximal: a neighbor of v either permits an exchange removing v from
I, or has another I neighbor and supplies a three-vertex path.

If a vertex w can be added while preserving induced bipartiteness and
connectedness, the new graph is a connected bipartite claw-free graph,
so has maximum degree at most two. Consequently w contacts just one
endpoint, or both endpoints and no other path vertices. In the one-end
case, another I neighbor z outside the path is anticomplete to the path
and extends it by two vertices. If no such z exists, exchange all path
I vertices for its non-I vertices and w. Equal cardinality, internal
independence and anticompleteness to I outside the path are all justified.
The resulting maximum independent set omits v. The two-end case admits
the same exchange; claw-freeness rules out any outside I neighbor of w.
Both cases contradict the chosen path or essentiality.

Finally, single-vertex nonextendibility really implies inclusion-maximality
as a connected induced bipartite subgraph: any larger connected induced
bipartite supergraph contains a first outside neighbor that can be added.
This avoids confusing maximality among paths with bipartite maximality.

### 3.3 Completion

At eta=0, an essential vertex would give the preceding odd path and hence
positive slack, impossible. Thus each root can be avoided by a maximum
independent set, and alpha≤|O(v)| for all roots. At eta≥1 the injection
already gives alpha≤|O(v)|+1≤|O(v)|+eta. These exhaust the integer slack
cases and prove 180 on the entire claw-free class.

## 4. WOWII 177: all claw-free graphs

For maximum independent I of size a, every outside vertex has at most
two I neighbors. At most one I vertex has degree below sigma. Therefore

    (a−1)sigma+delta ≤ e(I,V\I) ≤ 2(n−a).

The derivation of 2a+sigma≤n+2 is correct in every case:

* sigma=2: n≥2a−1+delta/2, hence n≥2a by connectedness and integrality;
* a=2: a nonedge supplies two nonuniversal vertices, so sigma≤n−2;
* a=3, sigma≥3: n≥sigma+3+delta/2, hence n≥sigma+4;
* a≥4, sigma≥3: the difference from 2a+sigma−2 is at least (a−4)/2.

Thus eta≥1 suffices. Complete graphs (n≥3) are equality cases; sigma=1
is exactly covered by the weaker published Waller bound. At eta=0,
delta≥2 and no simplicial vertex remain available from the explicit rooted
construction. For a≥4, sigma≥3, the lower difference improves to
(a−3)/2>0, giving the desired extra integer unit. The remaining profiles
were checked in detail:

**A. sigma=2, n=2a.** Equality forces degree 2 on I and exactly two I
neighbors at every outside vertex. An edge between outside vertices with
disjoint I-neighbor sets gives a claw. With a common I neighbor it makes
that degree-two vertex simplicial. Thus no outside edge exists, and the
whole connected graph is an even cycle. Its b=n and gamma_c=n−2 give
eta=1, contradiction.

**B. a=3, sigma≥3, n=sigma+4.** Equality forces degrees 2,sigma,sigma
on I={x,y,z}, with x the unique possible vertex below sigma; all outside
vertices have two I neighbors. With N(x)={u,v}, the other sigma−1 outside
vertices meet both y,z. Degree counts force u to meet y but not z, and
v to meet z but not y. Nonsimpliciality gives uv a nonedge. Since u has
degree≥sigma≥3, it has a neighbor w among those other outside vertices.
The three vertices u,w,z form a connected dominating set. The sequence
y,u,x,v,z is an induced P5, so b≥5 while gamma_c≤3, contradicting eta=0.
Every possible chord and domination obligation in this argument checks.

**C. a=2, sigma=n−2.** A universal vertex would give gamma_c=1 and an
induced P3 (using any nonedge), so b≥3 and positive slack. Otherwise the
complement has no isolated vertices and at most one vertex of degree>1;
its components are a star and matching edges. A single spanning star
would isolate its center in G, so there are at least two components.
Two complement edges from distinct components induce C4 in G, hence b≥4.
A vertex u of degree n−2 exists. If v is its unique nonneighbor, choose
a neighbor w of v. Then uw is an edge and {u,w} is connected dominating,
so gamma_c≤2 and again positive slack follows.

These profiles cover all possible failures of the extra unit at zero
slack. The proof therefore establishes the claimed claw-free subclass
without an additional structural assumption.

## 5. Independent exact computation

The auditor wrote `check_independent.cpp`, without importing the candidate
scripts or a graph catalogue. It enumerates labeled graphs, computes
independence, induced bipartite order and connected domination by exact
subset enumeration, and computes distance parity by BFS. The maximal odd
path certificate is found independently by enumerating induced vertex
subsets, not by copying the author's extension algorithm.

Results in `independent_results.json`:

| Check | Count |
|---|---:|
| Connected labeled graphs examined, n=2,...,7 | 1,893,731 |
| Claw-free connected graphs with exact invariants checked | 332,808 |
| Nonempty independent-set/root odd-layer controls | 41,894,078 |
| Essential-vertex alternating maximal-path certificates | 315,654 |
| Maximal odd bipartite paths in claw-free graphs | 780,174 |
| Zero-slack claw-free graphs, n≥3 | 2,237 |
| Explicit colored-piece deletion constructions, all connected graphs n≤6 | 33,219 |
| Later singleton pieces encountered | 10,980 |
| Repeated connectors encountered | 540 |

Every constructed set was directly verified connected, dominating, and
of order at most b−2. All original subclass inequalities and zero-slack
conclusions tested passed. This is finite corroboration; the unrestricted
proofs within the claw-free class are analytic.

Reproduction from the workspace root:

```sh
g++ -std=c++17 -O3 independent_audit/177_180/check_independent.cpp -o /tmp/audit177180
/tmp/audit177180
```

## 6. Final status

The final consolidated proof no longer requires the stronger baseline
zero-slack→claw-free theorem: it assumes claw-freeness throughout the two
new subclass results. The earlier working note's broader independence-core
corollary may additionally invoke DeLaViña–Waller Theorem 5; that statement
is properly prior, not a new premise silently inserted here.

**No unresolved proof or computation blocker.** The accepted output is
two rigorous subclass theorems, with the published foundational work
credited and the unrestricted original conjectures left open.
