// Independent finite audit of the claw-free WOWII177/180 subclass proofs.
// No candidate implementation or graph catalogue imported.
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <vector>
using U=unsigned;using Count=std::uint64_t;using Graph=std::vector<U>;
int pc(U x){return __builtin_popcount(x);}
void require(bool b,const char*s){if(!b)throw std::runtime_error(s);}
bool connected(const Graph&a,U s){if(!s)return false;U seen=s&-s,old=0;
 while(seen!=old){old=seen;for(unsigned v=0;v<a.size();++v)if(old&(1u<<v))seen|=a[v]&s;}return seen==s;}
bool bipartite(const Graph&a,U s){U uncolored=s;std::array<int,7>color;color.fill(-1);
 while(uncolored){int root=__builtin_ctz(uncolored);color[root]=0;U todo=1u<<root;uncolored&=~todo;
  while(todo){int v=__builtin_ctz(todo);todo&=todo-1;U nb=a[v]&s;
   while(nb){int w=__builtin_ctz(nb);nb&=nb-1;if(color[w]<0){color[w]=1-color[v];uncolored&=~(1u<<w);todo|=1u<<w;}
    else if(color[w]==color[v])return false;}
  }
 }return true;
}
bool independent(const Graph&a,U s){for(unsigned v=0;v<a.size();++v)if((s&(1u<<v))&&(a[v]&s))return false;return true;}
bool clawfree(const Graph&a){for(unsigned v=0;v<a.size();++v)for(U s=a[v];s;s=(s-1)&a[v])if(pc(s)==3&&independent(a,s))return false;return true;}
bool dominates(const Graph&a,U s){U d=s;for(unsigned v=0;v<a.size();++v)if(s&(1u<<v))d|=a[v];return d==(1u<<a.size())-1;}
bool odd_max_path(const Graph&a,U s){
 if(pc(s)<3||!(pc(s)%2)||!connected(a,s))return false;int ends=0;
 for(unsigned v=0;v<a.size();++v)if(s&(1u<<v)){int d=pc(a[v]&s);if(d==1)++ends;else if(d!=2)return false;}
 if(ends!=2)return false;
 for(unsigned v=0;v<a.size();++v)if(!(s&(1u<<v))&&(a[v]&s)&&bipartite(a,s|(1u<<v)))return false;
 return true;
}
// Construct the actual deletion certificate, using deterministic arbitrary
// choices. Repeated connectors and singleton later pieces are permitted.
Count constructed=0,singleton_pieces=0,reused_connectors=0;
void construction(const Graph&a,U initial,int b){
 U all=(1u<<a.size())-1,used=initial,connectors=0;std::vector<U> pieces{initial};std::vector<int>roots{-1};
 while(!dominates(a,used)){
  U neighborhood=0;for(unsigned v=0;v<a.size();++v)if(used&(1u<<v))neighborhood|=a[v];
  U available=all&~(used|neighborhood);int root=-1,connector=-1;
  for(unsigned x=0;x<a.size()&&root<0;++x)if(available&(1u<<x))for(unsigned c=0;c<a.size();++c)
   if((a[x]&(1u<<c))&&(a[c]&used)){root=x;connector=c;break;}
  require(root>=0,"No distance-two root");if(connectors&(1u<<connector))++reused_connectors;connectors|=1u<<connector;
  U piece=1u<<root;bool change=true;while(change){change=false;
   for(unsigned v=0;v<a.size();++v)if((available&(1u<<v))&&!(piece&(1u<<v))&&(a[v]&piece)&&bipartite(a,piece|(1u<<v))){piece|=1u<<v;change=true;break;}}
  pieces.push_back(piece);roots.push_back(root);used|=piece;
 }
 U kept=used|connectors;
 for(unsigned v=0;v<a.size();++v)if((initial&(1u<<v))&&pc(a[v]&initial)==1)kept&=~(1u<<v);
 for(unsigned j=1;j<pieces.size();++j){U s=pieces[j];int r=roots[j];
  if(pc(s)==1){kept&=~s;++singleton_pieces;continue;}
  // BFS spanning tree rooted at the attachment root.
  std::array<int,7> degree{};U seen=1u<<r,frontier=seen;
  while(frontier){int v=__builtin_ctz(frontier);frontier&=frontier-1;U fresh=a[v]&s&~seen;
   while(fresh){int w=__builtin_ctz(fresh);fresh&=fresh-1;seen|=1u<<w;frontier|=1u<<w;++degree[v];++degree[w];}}
  int leaf=-1;for(unsigned v=0;v<a.size();++v)if((s&(1u<<v))&&int(v)!=r&&degree[v]==1){leaf=v;break;}
  require(leaf>=0,"No deletable rooted tree leaf");kept&=~(1u<<leaf);
 }
 require(connected(a,kept)&&dominates(a,kept),"Colored-piece deletion is not connected dominating");
 require(pc(kept)<=b-2,"Colored-piece size bound failed");++constructed;
}
int main(){
 Count connected_total=0,cf_total=0,zero=0,essential=0,injections=0,odd_paths=0,allgraph_odd_paths=0;
 for(int n=2;n<=7;++n){std::vector<std::pair<int,int>>edges;
  for(int u=0;u<n;++u)for(int v=u+1;v<n;++v)edges.push_back({u,v});U all=(1u<<n)-1;
  for(U m=0;m<(1u<<edges.size());++m){Graph a(n);
   for(unsigned j=0;j<edges.size();++j)if(m&(1u<<j)){auto[u,v]=edges[j];a[u]|=1u<<v;a[v]|=1u<<u;}
   if(!connected(a,all))continue;++connected_total;bool cf=clawfree(a);if(!cf&&n==7)continue;
   int alpha=0,b=0,gamma=n;U core=all,chosen=0;std::vector<U> inds;
   for(U s=1;s<=all;++s){int size=pc(s);
    if(independent(a,s)){inds.push_back(s);if(size>alpha){alpha=size;core=s;chosen=s;}else if(size==alpha)core&=s;}
    if(size>b&&bipartite(a,s))b=size;
    if(size<gamma&&connected(a,s)&&dominates(a,s))gamma=size;
   }
   int eta=b-gamma-1;require(eta>=0,"Baseline slack failed");
   std::vector<U> paths;for(U s=1;s<=all;++s)if(odd_max_path(a,s)){
    paths.push_back(s);require(gamma<=b-2,"Maximal odd bipartite path bound failed");
    if(n<=6){construction(a,s,b);++allgraph_odd_paths;}
   }
   if(!cf)continue;++cf_total;odd_paths+=paths.size();
   std::vector<int>degrees;for(U s:a)degrees.push_back(pc(s));std::sort(degrees.begin(),degrees.end());
   if(n==2){require(2+b>=2*alpha+degrees[1],"K2 177 failed");continue;}
   require(n+1+eta>=2*alpha+degrees[1],"Claw-free 177 failed");
   int minodd=n;
   for(int v=0;v<n;++v){std::array<int,7>distance;distance.fill(-1);distance[v]=0;U seen=1u<<v,front=seen;int step=0,odd=0;
    while(front){U next=0;for(int w=0;w<n;++w)if(front&(1u<<w))next|=a[w];next&=~seen;seen|=next;front=next;++step;if(step%2)odd+=pc(next);}
    minodd=std::min(minodd,odd);
    for(U I:inds){require(pc(I)<=odd+int(bool(I&(1u<<v))),"Odd-layer injection failed");++injections;}
   }
   require(eta>=alpha-minodd,"Claw-free 180 failed");
   for(int v=0;v<n;++v)if(core&(1u<<v)){
    ++essential;bool found=false;
    for(U p:paths)if((p&(1u<<v))&&pc(p&chosen)==(pc(p)+1)/2){
     bool endpoints=true;for(int w=0;w<n;++w)if((p&(1u<<w))&&pc(a[w]&p)==1&&!(chosen&(1u<<w)))endpoints=false;
     if(endpoints){found=true;break;}
    }require(found,"No essential-vertex alternating maximal path");
   }
   if(!eta){++zero;require(!core,"Zero-slack independence core nonempty");
    for(int v=0;v<n;++v)require(connected(a,all^(1u<<v)),"Zero-slack cutvertex");
    if(alpha>1)for(int v=0;v<n;++v){bool clique=true;for(int w=0;w<n;++w)if((a[v]&(1u<<w))&&pc(a[w]&a[v])!=pc(a[v])-1)clique=false;
     require(!clique,"Noncomplete zero-slack simplicial vertex");}
   }
  }
 }
 std::cout<<"{\"status\":\"PASS\",\"connected_labeled_graphs_n2_to_n7\":"<<connected_total
 <<",\"clawfree_graphs_checked\":"<<cf_total<<",\"zero_slack_clawfree_graphs_n3_up\":"<<zero
 <<",\"odd_layer_injection_controls\":"<<injections<<",\"essential_vertex_path_certificates\":"<<essential
 <<",\"clawfree_maximal_odd_paths\":"<<odd_paths<<",\"general_graph_colored_piece_constructions_n_le_6\":"<<constructed
 <<",\"singleton_later_pieces\":"<<singleton_pieces<<",\"reused_connectors\":"<<reused_connectors
 <<",\"scope\":\"Finite corroboration of universal subclass proofs; not full original177/180\"}\n";
}
