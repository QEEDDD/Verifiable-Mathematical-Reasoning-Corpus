# Independent audit: final order-43 reduction

**PASS — this strengthens the representative-order bound from 64 to 43.
It does not close WOWII384b or certify an exhaustive order-43 search.**

Audited `addendum43.tex` / `addendum43.md`, `check_order43.py`, and
`order43_checks.json` on 26 October 2026. The stable main manuscript's
probability and order-64 arguments were already accepted in `AUDIT64.md`.
All new universal arguments, case boundaries and exact margins pass.

## 1. Simultaneous independent degree-two omissions

The new lemma is valid for **any independent set S of degree-two
vertices**, with no additional triangle or high-neighbor condition.
After the initial high selection X and the usual monotone high repair,
omit z∈S if every high neighbor of z belongs to X.

Each omitted z retains both neighbors selected: its high neighbors are
in X, while its low neighbors lie outside S by independence and are
never removed. A high vertex outside the final selected set loses no
selected low neighbor, because every high neighbor of a removed vertex
was already in X. Thus the omissions remain safe simultaneously, even
if the events are strongly correlated or roots are shared.

A degree-two vertex can have 0,1,2 high neighbors. The corresponding
event probabilities are 1, s/h, and q=s(s−1)/(h(h−1)); all are at least
q for 2≤s<h. Linearity of expectation therefore gives expected low
omissions≥|S|q. No independence of the events is assumed. Ignoring the
forced-neighbor improvements in high repair only makes the resulting
upper bound more conservative.

In particular this lemma does **not** require the stronger Round09
assertion that the odd low graph has at most one edge. The published
low-cover restriction is sufficient for the subsequent independent-set
count. Zero-high-neighbor cases are legitimate, not an omitted exception.

## 2. Count and case audit

Use a leaf-trimmed counterexample preserving h, T and k as proved in the
earlier audit. For h≤27, the previous bound is already
h+ceil(h/2)+2≤43. The h=42 no-degree-two branch has its previously
audited order-43 representative. Only 28≤h≤41 remain.

Suppose 28≤h≤40 and n≥44. For even h, at most two leaves remain and
the low graph is independent, giving |D2|≥42−h and an independent
degree-two set that large. For odd h, at most one leaf remains and the
low graph has a vertex cover of size at most one. Consequently
alpha(G[D2])≥|D2|−1≥42−h. This count is valid after trimming: high
membership was preserved and connected order>2 has no isolated vertices,
so n=h+|D2|+(number of leaves).

For h=41 and n≥44, at least two degree-two vertices remain. If any two
are nonadjacent, the size-two independent-set credit applies. Otherwise
all degree-two vertices form a clique. They number at most three; three
would be a whole isolated K3 component because their degrees are two,
contradicting connectedness and h=41. Thus there are exactly two and
they are adjacent. Odd criticality requires a low vertex with triangle
count one; leaves cannot supply it. One of the degree-two pair must lie
in a triangle, whose third vertex is necessarily their common high
neighbor. The pair is therefore a pendant triangle. This is an exhaustive
split, not an assumption that every adjacent degree-two pair is pendant.

## 3. Exact margins, independently reproduced

The auditor recomputed the repair sums using unconditional subset counts
with denominator binom(h,s), generated degree bounds by an integer-square-
root calculation, and compared all outputs with the candidate's rational
table. Every margin below is threshold minus the upper bound on expected
net selected high vertices; the full selected-set bound also includes |L|.

| h | s | independent D2 vertices credited | positive margin |
|---:|---:|---:|---:|
|28|14|14|104761/62100|
|29|14|13|6259/5220|
|30|14|12|555607/450225|
|31|14|11|3937304/4652325|
|32|14|10|73523/82708|
|33|14|9|4075549/7120080|
|34|14|8|36783491/60520680|
|35|14|7|1370525/4034712|
|36|15|6|18196217/48416544|
|37|15|5|22835/145928|
|38|15|4|226475387/1031419104|
|39|15|3|5208220/139671337|
|40|15|2|12325127/154120096|
|41|15|2|162283/3197836|

For h=41's pendant case, the separate root-repair saving and one-private-
vertex omission credit give **28995/155992>0**. All thresholds are
floor(h/2)=h−k. Each positive exact margin forces a 2-dominating set
strictly smaller than |L|+h−k=n−k, contradicting criticality. There is
no floating-point or ceiling ambiguity.

## 4. Independent operational controls

`check_order43_independent.py` also enumerates independent degree-two
subsets in all connected labeled graphs through order six with an
applicable high-selection parameter. For every such subset and every
initial high selection it performs the actual simultaneous omission and
checks 2-domination directly. It then checks the exact average-size
inequality. Additional explicitly constructed graphs include degree-two
vertices with zero and one high neighbors, ensuring those boundary cases
are tested rather than merely mentioned.

All checks pass. Exact counts appear in `order43_independent_results.json`.
The earlier main-audit checks separately validate the forced-neighbor
probabilities and h=42/43 exclusions. These are controls for the universal
proof, not a substitute for it and not an exhaustive residual search.

```sh
python independent_audit/384b/check_order43_independent.py
```

## 5. Final scope and dependencies

Every hypothetical counterexample has a **connected representative of
order at most 43**, with **10≤h≤42**. At h=42 it has exactly one leaf
and no degree-two vertices. The low-cover input and original trimming
argument retain their explicit 2011 attribution; h≤9 and h≥44 exclusions
remain the separately audited Round08/09 inputs. No new literature
dependency is introduced by this addendum.

The stable main paper's order64 is superseded numerically by this
addendum, but its proofs remain valid. **No unresolved audit gap or
blocker. No full original-conjecture closure or worldwide novelty claim.**
