# Independent audit: low-omission credits and the order-64 reduction

**PASS — partial progress on WOWII384b, not a full closure.**

Audited 26 October 2026. This report covers the stable
`round_10/twodomination/manuscript.tex` / `384b_low_credit.md` and
`check_low_omission_credit.py`. Any later stronger addendum requires its
own audit and does not silently alter this report's scope.

Verified new conclusions:

* h=43 is excluded entirely;
* h=42 is excluded when a degree-two vertex exists;
* the remaining h=42 case has a counterexample representative of order 43;
* combined with the audited earlier results, every counterexample has a
  representative of order at most **64**, with **10≤h≤42**.

No exhaustive search of that residual family has been performed.

## 1. Critical profiles and alteration construction

The exact equivalence between the original domination inequality and
|T|≤2k is retained, with k=n−gamma2. Maximum cut gives k≥ceil(h/2), while
low triangle counts are 0 or 1. Hence odd critical h has k=(h+1)/2 and
h distinct high counts≥2; even critical h has k=h/2 and at least h−1
distinct high counts≥2. Sorting those representatives gives exactly the
claimed lower degree profiles through tau(v)≤binom(d(v),2). The even
exceptional vertex only needs degree≥3. No assumption of equality between
actual degrees and the profile is made.

Choose a uniform s-subset X of the high vertices and initially select all
low vertices. Add every outside high vertex with fewer than two neighbors
in this initial selected set. Repairs may be simultaneous: a high vertex
not added already has two initially selected neighbors, and adding more
vertices cannot remove either. Selected vertices have no domination
requirement. Thus this always produces a 2-dominating set.

## 2. Forced-neighbor probability lemma

The conditional formulas R0,R1,R2 are correct, including their caps.
An independent derivation uses the unconditional denominator binom(h,s).
If a vertex has q high neighbors and l selected low neighbors, its exact
repair probability is

    sum_{0≤j≤1−l} binom(q,j) binom(h−1−q,s−j) / binom(h,s),

where the sum is empty for l≥2. This counts only initial high selections
excluding the vertex itself; it therefore already includes the probability
that the vertex is outside X.

For degree lower bound d and f known selected low neighbors, retain any
d neighbors including f low ones. Extra actual neighbors can only decrease
repair probability. Replacing any remaining retained low neighbor by a
distinct high nonneighbor changes an always-selected neighbor into a
possibly selected one, so it cannot decrease repair probability. If
d−f≤h−1, there are enough positions to perform these replacements.
This yields the stated hypergeometric upper bound with e=d−f. If
d−f≥h−1, every initial X excluding the vertex supplies at least
d−(h−1−s)≥f+s selected neighbors, so repair is impossible; the capped
formula also vanishes. The same reasoning covers degrees above h−1,
not just the literal all-high-neighbor model.

Increasing d enlarges the random-neighbor set and cannot increase repair
probability. Replacing a random neighbor by a fixed selected one proves
R1≤R0. For uncapped degrees this difference also has the explicit
nonnegative expression

    R0(h,s,d)−R1(h,s,d)
      = (d−1) binom(h−1−d,s−1) / binom(h,s).

Endpoint savings are evaluated at their assigned **lower profile degrees**.
If actual degrees are larger, monotonicity gives the stronger forced
upper bound at that lower degree. It is not necessary that the saving
itself be monotone in the actual degree. Taking the two smallest profile
savings is therefore a safe bound for any two distinct endpoints.

## 3. Safe low omissions and expectation

For a degree-two vertex z with high roots u,v, each root has a forced
initially selected low neighbor. Replace its ordinary repair term by R1.
After all repairs, omit z only if u,v were both in the initial X. Their
joint probability is s(s−1)/(h(h−1)). The omitted z retains its two
selected roots. The only vertices losing z as a selected neighbor are
u,v, which are themselves selected and have no domination obligation.
Thus no outside high vertex is harmed. The argument does not presume
that u,v are adjacent, so it applies to nontriangle degree-two vertices
in the even case as well.

For a pendant triangle, the root has two forced selected low neighbors,
so its repair probability is zero. If the root was initially selected,
omit one private vertex and keep the other. The omitted vertex has its
selected root and private mate; only selected vertices lose it as a
neighbor. The event probability is s/h. The minimum ordinary profile
repair term is a valid universal root saving.

Subtracting these event indicators from the constructed set size and
using linearity of expectation proves the displayed bounds. No
independence of repair events, roots, or omission events is assumed.

## 4. Exact margins and complete h=42/43 case splits

The independent checker uses integer subset counts with denominator
binom(h,s), and explicitly minimizes pair savings over every pair of
distinct profile positions rather than sorting the savings. For s=16 it
reproduces:

| Profile / credit | Threshold minus expected net high selection |
|---|---:|
| h=42, high-high degree-two vertex | 75065/541569 |
| h=43, high-high degree-two vertex | 1057200/7762489 |
| h=43, pendant triangle | 2799123/7762489 |

All are strictly positive. The threshold is h−k=21 in every row, because
the full selected-set bound is |L| plus the net high-selection expression.
Thus an integer-sized 2-dominating set below n−k must exist; a weak
inequality or rounded expectation has not been substituted for this step.

At h=43, criticality requires both low values 0 and 1, since all high
values are distinct and≥2. A low vertex with triangle count 1 has degree
two and lies either on a high-high edge attachment or a pendant triangle.
An all-low triangle would be a whole component and contradict h=43.
The two credits therefore exhaust every putative counterexample.

At h=42, the even tight-cut lemma ensures every degree-two vertex has two
high neighbors. The manuscript's short reproof is valid: a good degree-two
vertex would augment a balanced high side; every other degree-two vertex
can be flipped in a maximum cut; a low adjacency would then create zero
crossing degree at a leaf or degree 0/2 at a degree-two vertex. Thus the
credit covers every h=42 graph with a degree-two vertex.

## 5. Order-64 representative reduction

The earlier order-67 machinery was fully audited in Round08, including
the precise 2011 DeLaViña–Goddard–Henning–Pepper–Vaughan Theorem 5 and
its no-adjacent-degree-less-than-two hypothesis. That hypothesis is
automatic for connected order>2. The resulting low-cover restriction
and leaf-deletion argument remain correctly stated here.

Deleting leaves cannot increase maximum omission capacity: every omission
set in the remaining induced graph is also valid in the original graph
with deleted leaves selected. If h and the triangle-value set T survive,
the maximum-cut lower bound forces k unchanged, so a counterexample
remains a counterexample. Equality of k is derived, not assumed.

Odd critical h has at least two triangles at every high vertex, hence at
least three nonleaf neighbors. Its degree-two vertices have an independent
subset of size at least n2−1, giving n2≤k+1; at most one degree-two-supported
leaf is possible. All other leaves can be removed, retaining one zero-value
witness if needed. Even critical h has independent low vertices, n2≤k,
and at most one exceptional high vertex needing at most two leaves to
retain degree three. These are the previously audited bounds
n≤h+ceil(h/2)+2. After excluding h=43, they give at most 64 when h≤41.

For the remaining h=42 branch there are no degree-two vertices, so all
low vertices are leaves. At least one leaf must occur, otherwise |T|≤h.
Criticality forces all 42 high triangle counts to be distinct and positive.
At most one is 1; every other high vertex has three nonleaf neighbors.
A count-one vertex has two nonleaf neighbors and needs at most one leaf
to retain high degree. Retain one leaf there if needed, otherwise any
leaf. Deleting every other leaf preserves high membership, all high
triangle counts, the value zero, and connectedness. The resulting
counterexample has exactly 43 vertices. This completes the global bound64.

The earlier h≤9 and h≥44 results are separate audited inputs, not newly
claimed proofs in this manuscript. Residual h=42 without degree-two
vertices is not declared eliminated.

## 6. Independent finite checks and optional structural supplement

`check_credit_independent.py` imports no candidate code. Besides exact
margin recomputation it verifies 73099 local configurations, including
extra low neighbors, caps, and every allowed lower degree; 1924
monotonicity comparisons also pass. For connected labeled graphs through
order six it enumerates every eligible initial high selection, executes
repairs, and directly verifies each credited omission is 2-dominating.
It also omits all eligible high-high low vertices and one vertex from
every eligible pendant triangle simultaneously as an additional control.
Counts and results are in `credit_independent_results.json`. These checks
do not replace the universal probability argument or constitute a search
of the residual order-64 family.

The optional `even_cubic_filter.tex` was also reviewed conceptually and
passes. A high vertex tied across a maximum cut could be flipped to
unbalance the forced k/k high split, so crossing majorities are strict.
Noncubic high vertices therefore retain at least three crossing neighbors.
The one-vertex augmentation argument and triangle-count bound correctly
force between one and three cubic vertices; each cubic blocker can block
at most two candidates, giving at most six exceptional candidates total.
The warning against simultaneous two-high-vertex augmentation is correct.
This supplement is **not a dependency** of the three audited main results.

Reproduce with:

```sh
python independent_audit/384b/check_credit_independent.py
```

**No unresolved blocker.** Full WOWII384b and the remaining finite family
are not resolved by this result. Any later reduction must be audited and
reported separately.
