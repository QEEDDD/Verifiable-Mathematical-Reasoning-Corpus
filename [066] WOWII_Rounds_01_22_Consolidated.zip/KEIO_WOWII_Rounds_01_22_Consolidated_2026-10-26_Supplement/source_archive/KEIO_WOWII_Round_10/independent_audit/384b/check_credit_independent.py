"""Independent exact local probabilities, margins, and full-graph alterations.
Does not import the candidate checker. All probabilities use unconditional
counting with denominator C(h,s), unlike the conditional source formula.
"""
from fractions import Fraction
from itertools import combinations
from math import comb
import json

def C(n,k):
    return comb(n,k) if n>=0 and 0<=k<=n else 0

def count_bound(h,s,d,f):
    if f>=2:return 0
    e=min(h-1,d-f)
    return C(h-1-e,s)+(e*C(h-1-e,s-1) if f==0 else 0)

def actual_count(h,s,high_neighbors,low_neighbors):
    return sum(C(high_neighbors,j)*C(h-1-high_neighbors,s-j)
               for j in range(max(0,2-low_neighbors)))

local=0;monotonic=0
for h in range(3,15):
    for s in range(2,h):
        for high in range(h):
            for low in range(6):
                actual_degree=high+low
                if actual_degree<3:continue
                actual=actual_count(h,s,high,low)
                for d in range(3,actual_degree+1):
                    for f in range(min(2,low)+1):
                        assert actual<=count_bound(h,s,d,f)
                        local+=1
        for d in range(3,h+5):
            assert count_bound(h,s,d,0)>=count_bound(h,s,d,1)>=0
            for f in (0,1):
                assert count_bound(h,s,d,f)>=count_bound(h,s,d+1,f)
                monotonic+=1

def rho(t):
    return next(d for d in range(3,t+3) if C(d,2)>=t)

records=[]
for h in (42,43):
    s=16;den=C(h,s)
    degrees=([3]+[rho(t) for t in range(2,h+1)] if h%2==0
             else [rho(t) for t in range(2,h+2)])
    ordinary=[count_bound(h,s,d,0) for d in degrees]
    savings=[ordinary[i]-count_bound(h,s,d,1) for i,d in enumerate(degrees)]
    baseline=s*den+sum(ordinary)
    # Explicitly minimize over all distinct endpoint choices, not sorted two.
    least=min(savings[i]+savings[j] for i in range(h) for j in range(i))
    net=baseline-least-C(h-2,s-2)
    threshold=h-(h+1)//2
    margin=Fraction(threshold*den-net,den)
    expected={42:Fraction(75065,541569),43:Fraction(1057200,7762489)}[h]
    assert margin==expected and margin>0
    record=dict(h=h,s=s,degree_profile=degrees,baseline=str(Fraction(baseline,den)),
                pair_margin=str(margin),pair_net_bound=str(Fraction(net,den)))
    if h%2:
        pendant_net=baseline-min(ordinary)-C(h-1,s-1)
        pm=Fraction(threshold*den-pendant_net,den)
        assert pm==Fraction(2799123,7762489)>0
        record['pendant_margin']=str(pm)
    records.append(record)

def connected(a):
    seen=1
    while True:
        old=seen
        for v in range(len(a)):
            if old>>v&1:seen|=a[v]
        if seen==old:return seen==(1<<len(a))-1

def two_dominating(a,D):
    return all(D>>v&1 or (a[v]&D).bit_count()>=2 for v in range(len(a)))

graphs=0;sampling_experiments=0;pair_experiments=0;pendant_experiments=0;joint_samples=0
for n in range(3,7):
    es=list(combinations(range(n),2))
    for graphmask in range(1<<len(es)):
        a=[0]*n
        for i,(u,v) in enumerate(es):
            if graphmask>>i&1:a[u]|=1<<v;a[v]|=1<<u
        if not connected(a):continue
        high=[v for v in range(n) if a[v].bit_count()>=3];h=len(high)
        if h<3:continue
        graphs+=1;H=sum(1<<v for v in high);L=((1<<n)-1)^H
        pairs=[(v,a[v]) for v in range(n) if a[v].bit_count()==2 and a[v]&H==a[v]]
        pendants=[]
        for x,y in es:
            if a[x].bit_count()==a[y].bit_count()==2 and a[x]>>y&1:
                rootmask=a[x]&a[y]&H
                if rootmask:pendants.append((x,y,rootmask))
        for s in range(2,h):
            den=C(h,s);sums_pair=[0]*len(pairs);sums_pendant=[0]*len(pendants)
            ordinary={v:count_bound(h,s,a[v].bit_count(),0) for v in high}
            baseline=(L.bit_count()+s)*den+sum(ordinary.values())
            for ss in combinations(high,s):
                X=sum(1<<v for v in ss);initial=X|L;D=initial
                for v in high:
                    if not(X>>v&1) and (a[v]&initial).bit_count()<2:D|=1<<v
                assert two_dominating(a,D);sampling_experiments+=1
                joint=D
                for j,(v,roots) in enumerate(pairs):
                    omit=roots&X==roots
                    modified=D&~(1<<v) if omit else D
                    assert two_dominating(a,modified)
                    sums_pair[j]+=modified.bit_count()
                    if omit:joint&=~(1<<v)
                for j,(x,y,root) in enumerate(pendants):
                    omit=bool(root&X);modified=D&~(1<<x) if omit else D
                    assert two_dominating(a,modified)
                    sums_pendant[j]+=modified.bit_count()
                    if omit:joint&=~(1<<x)
                assert two_dominating(a,joint);joint_samples+=1
            for j,(_,roots) in enumerate(pairs):
                saving=sum(ordinary[v]-count_bound(h,s,a[v].bit_count(),1) for v in high if roots>>v&1)
                assert sums_pair[j]<=baseline-saving-C(h-2,s-2)
                pair_experiments+=1
            for j,(_,_,root) in enumerate(pendants):
                v=root.bit_length()-1
                assert sums_pendant[j]<=baseline-ordinary[v]-C(h-1,s-1)
                pendant_experiments+=1

print(json.dumps(dict(status='PASS',exact_local_probability_controls=local,
    monotonicity_controls=monotonic,records=records,
    connected_small_graphs_with_h_at_least_3=graphs,
    complete_alteration_samples=sampling_experiments,
    pair_expected_size_inequalities=pair_experiments,
    pendant_expected_size_inequalities=pendant_experiments,
    simultaneous_safe_omission_samples=joint_samples,
    scope='Independent exact corroboration; no exhaustive residual counterexample search'),indent=2))
