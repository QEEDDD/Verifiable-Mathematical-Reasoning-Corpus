"""Independent exact arithmetic and independent-D2 omission controls."""
from math import comb,isqrt
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
import json

def C(n,k):return comb(n,k) if n>=0 and 0<=k<=n else 0
def rho(t):
    d=(1+isqrt(1+8*t))//2
    if d*(d-1)<2*t:d+=1
    return max(3,d)
def numerator(h,s,d):
    e=min(d,h-1)
    return C(h-1-e,s)+e*C(h-1-e,s-1)
def baseline_numerator(h,s):
    profile=([3]+[rho(t) for t in range(2,h+1)] if h%2==0
             else [rho(t) for t in range(2,h+2)])
    rs=[numerator(h,s,d) for d in profile]
    return s*C(h,s)+sum(rs),rs

author=json.loads((Path(__file__).resolve().parents[2]/'twodomination/order43_checks.json').read_text())
records=[]
for h in range(28,41):
    s=14 if h<=35 else 15;m=42-h;den=C(h,s);B,_=baseline_numerator(h,s)
    margin=F((h//2)*den-B+m*C(h-2,s-2),den)
    assert margin>0 and str(margin)==author['records'][h-28]['strict_margin']
    records.append(dict(h=h,s=s,independent_D2_required=m,margin=str(margin)))
h,s=41,15;B,rs=baseline_numerator(h,s);den=C(h,s)
pair=F(20*den-B+2*C(h-2,s-2),den)
pendant=F(20*den-B+min(rs)+C(h-1,s-1),den)
assert pair==F(162283,3197836)>0
assert pendant==F(28995,155992)>0

def connected(a):
    seen=1
    while True:
        old=seen
        for v in range(len(a)):
            if old>>v&1:seen|=a[v]
        if seen==old:return seen==(1<<len(a))-1
def is2dom(a,D):
    return all(D>>v&1 or (a[v]&D).bit_count()>=2 for v in range(len(a)))

graphs=0;sets=0;trials=0;expectations=0;low_neighbor_counts=[0,0,0]
def check(a):
    global graphs,sets,trials,expectations,low_neighbor_counts
    n=len(a);high=[v for v in range(n) if a[v].bit_count()>=3];h=len(high)
    if h<3:return
    d2=[v for v in range(n) if a[v].bit_count()==2]
    if not d2:return
    graphs+=1;H=sum(1<<v for v in high);L=((1<<n)-1)^H
    for k in range(1,len(d2)+1):
        for vv in combinations(d2,k):
            S=sum(1<<v for v in vv)
            if any(a[v]&S for v in vv):continue
            sets+=1
            for v in vv:low_neighbor_counts[(a[v]&H).bit_count()]+=1
            for s in range(2,h):
                total=0;den=C(h,s)
                for xx in combinations(high,s):
                    X=sum(1<<v for v in xx);initial=X|L;D=initial
                    for v in high:
                        if not(X>>v&1) and (a[v]&initial).bit_count()<2:D|=1<<v
                    for v in vv:
                        if a[v]&H&~X==0:D&=~(1<<v)
                    assert is2dom(a,D)
                    total+=D.bit_count();trials+=1
                bound=(L.bit_count()+s)*den+sum(numerator(h,s,a[v].bit_count()) for v in high)-k*C(h-2,s-2)
                assert total<=bound;expectations+=1

for n in range(3,7):
    edges=list(combinations(range(n),2))
    for mask in range(1<<len(edges)):
        a=[0]*n
        for i,(u,v) in enumerate(edges):
            if mask>>i&1:a[u]|=1<<v;a[v]|=1<<u
        if connected(a):check(a)

def graph(n,edges):
    a=[0]*n
    for u,v in edges:a[u]|=1<<v;a[v]|=1<<u
    return a
K4=list(combinations(range(4),2))
# Extra tests include degree-two vertices with zero or one high neighbor.
for extra in [[(0,4),(4,5),(5,6),(6,1)],
              [(0,4),(4,5),(5,6),(6,0)],
              [(0,4),(4,5)],
              [(0,4),(0,5),(4,5)],
              [(0,4),(4,5),(5,6),(6,7),(7,1)]]:
    n=1+max(max(e) for e in extra)
    check(graph(n,K4+extra))
assert all(low_neighbor_counts)
print(json.dumps(dict(status='PASS',records=records,h41_pair_margin=str(pair),h41_pendant_margin=str(pendant),
    graph_occurrences=graphs,independent_D2_sets=sets,actual_alteration_and_joint_omission_trials=trials,
    exact_expected_size_inequalities=expectations,vertex_occurrences_by_number_of_high_neighbors=low_neighbor_counts,
    representative_bound=43,scope='Universal reduction corroboration; no exhaustive search through order43'),indent=2))
