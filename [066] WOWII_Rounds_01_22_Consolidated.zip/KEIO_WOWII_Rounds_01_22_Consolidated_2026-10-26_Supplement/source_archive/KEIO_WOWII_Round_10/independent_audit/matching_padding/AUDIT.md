# Independent audit: graphical matching-padding auxiliary

**PASS on graphical inputs only. Not a proof of WOWII61, not a Lean
formalization, and not a theorem about arbitrary nongraphical lists.**

Audited `round_09/independence/matching_padding_theorem.md` and its
finite checker on 26 October 2026. Both padding lemmas and the residual
sum consequence are correct. The conclusion is a corollary of an
explicitly attributed established theorem, not a claim to reprove or
rediscover that theorem.

## 1. Exact classical dependency

Michaela Hiller's primary research manuscript, *On the Domination Order
among Elimination Sequences*, arXiv:2206.05820v1, defines domination using
equal total sums and all prefix sums. Definition 1.5 pads the Havel–Hakimi
elimination sequence with zeros to the original degree-list length.
Theorem 1.6 explicitly attributes to Triesch the preservation of this
domination order by canonical elimination sequences.

The original publisher's abstract independently confirms this same
preservation theorem for graphical partitions: Eberhard Triesch,
*Degree sequences of graphs and dominance order*, Journal of Graph
Theory 22(1) (May 1996), 89–93.

Primary sources checked:

* https://arxiv.org/html/2206.05820
* https://onlinelibrary.wiley.com/doi/abs/10.1002/%28SICI%291097-0118%28199605%2922%3A1%3C89%3A%3AAID-JGT12%3E3.0.CO%3B2-J

The original 1996 full proof was not independently reconstructed here.
The dependency is a precisely verified established theorem, not an
unreviewed AI claim. Hiller's displayed statement has an incidental
rho/sigma naming inconsistency, but its mathematical assertion and
definition of order are unambiguous and agree with the original abstract.

## 2. Padding degree lists: universal proof

After zero-padding A,B to common length n, weak prefix domination implies
sum(A)≥sum(B). Graphicality makes both sums even, so their difference is
2m for a nonnegative integer m. Appending 2m zeros to A and 2m ones to B
produces graphical lists A',B' of equal length and equal sum: the added
graphs are isolates and a disjoint m-edge matching, respectively.

Let p be the number of positive A entries. For k≤p, any k-element
selection from B' uses q original entries and k−q appended ones. Its sum
is at most Pq(B)+(k−q), which is at most Pq(A)+(k−q) and then at most
Pk(A). The last step uses **integral positive degrees**, each at least
one, between positions q+1 and k. This covers the maximal k-element
selection and therefore the sorted B' prefix. For k>p, the A' prefix
already equals its total sum, which is the total of B'. All boundaries,
including all-zero lists and m=0, are valid.

Thus A' majorizes B' in the ordinary equal-sum sense required by Triesch.

## 3. Exact matching-elimination identity

The claimed identity

    E(B union 1^(2m)) = sort(E(B) union 1^m union 0^m)

is correct. At each positive head h of the B portion, graphicality of
the current residual B list guarantees at least h other positive entries.
Hence B's own HH reduction never needs a zero entry. The appended ones
can only tie with selected B entries at the boundary, never exceed them.
Resolve every such tie in favor of B, including the choice of a head
when h=1. This is a legitimate reduction of the combined multiset and
leaves all appended ones untouched until B has become zero.

Choice among identical degree values cannot change the resulting degree
multiset, so this tie convention produces the canonical head sequence.
The remaining matching contributes exactly m positive heads equal to one
and m terminal zeros. The zeros left by B are retained as well. The
length accounting is n+2m, and all positive B heads precede the appended
ones in nonincreasing order. Isolated-vertex padding only appends zeros.

## 4. Weak elimination order and residual sum

Applying the established equal-sum theorem to A',B' gives every elimination
prefix of A' at least the corresponding prefix of B'. The former has the
same prefix sums as E(A). By the exact identity, the latter consists of
E(B) plus nonnegative entries and thus has prefix sums at least those of
E(B). This proves the desired weak elimination-prefix order, including
original lists of unequal lengths under zero padding.

Each legal graphical HH step removes exactly twice its head from the
degree sum. Therefore, with completed histories padded by zero heads,

    gap_k = gap_0 − 2(Pk(E(A))−Pk(E(B))) ≤ gap_0.

This is exactly the stated no-residual-overshoot result. It does not imply
that each residual degree list dominates the other, does not require
gap_k≥0, and does not supply the separate graph-level forest/diameter
augmentation needed for original WOWII61. The scope qualifications in
the candidate are mathematically necessary and correctly retained.

## 5. Independent exact checks

The auditor wrote `check_independent.cpp` without importing the candidate
code. Graphical lists through order seven are extracted from **all actual
labeled graphs**, rather than using the candidate Erdős–Gallai predicate.
Order-eight lists are extracted from the 12346 eight-core masks whose
coverage was independently certified in the Round09 #384b audit. That
certificate is copied into `coverage_inputs/` for reproducibility.

The independent HH routine uses degree multiplicities and deferred
decrements, rather than the candidate's repeatedly sorted list. It checks
matching and isolate identities and both equal-length and cross-length
weakly ordered pairs.

Results:

* graphical list counts n=1,...,8: **1,2,4,11,31,102,342,1213**;
* all same-order weak-pair counts exactly match the candidate's 656935;
* **1233751** weakly ordered pairs total, including **576816** different-
  length pairs, pass elimination-prefix and no-overshoot checks;
* **49474** matching identities and the same number of isolate identities
  pass, using m=0,...,28 for every generated list;
* every pair also passes the equal-sum degree-padding step directly.

The supplied candidate checker was separately inspected. Its descending
degree-list generation, Erdős–Gallai test, canonical HH routine, matching
padding and prefix comparisons are consistent with the theorem. No
floating-point or unverified solver premise occurs in either checker.

Reproduction from the workspace root:

```sh
d=independent_audit/matching_padding
g++ -std=c++17 -O3 "$d/check_independent.cpp" -o /tmp/audit_padding
/tmp/audit_padding "$d/coverage_inputs/core8_masks.txt"
# Optional re-verification of the actual graph coverage used at order eight:
g++ -std=c++17 -O3 "$d/coverage_inputs/check_coverage_independent.cpp" -o /tmp/audit_padding_cover
/tmp/audit_padding_cover "$d/coverage_inputs/core7_masks.txt" "$d/coverage_inputs/core8_masks.txt" "$d/coverage_inputs/core8_cover_permutations.bin"
```

**No unresolved gap on the stated graphical domain.** This audit accepts
an auxiliary sequence theorem with a credited classical input. It does
not certify worldwide novelty, arbitrary recursive-list specifications,
or a full numbered conjecture closure.
