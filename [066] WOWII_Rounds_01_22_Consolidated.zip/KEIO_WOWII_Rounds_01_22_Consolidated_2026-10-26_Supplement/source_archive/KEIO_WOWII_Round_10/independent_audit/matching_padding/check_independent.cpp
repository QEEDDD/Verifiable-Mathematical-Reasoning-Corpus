// Independent weak-majorization audit. Graphical lists are obtained from
// actual graphs, not the candidate Erdos-Gallai predicate. HH uses degree
// multiplicities and deferred decrements, not the candidate sort-list code.
#include <algorithm>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <numeric>
#include <set>
#include <stdexcept>
#include <vector>
using Seq=std::vector<int>;using U=unsigned;using Count=std::uint64_t;
void require(bool b,const char*s){if(!b)throw std::runtime_error(s);}
Seq degrees(int n,U mask){Seq d(n);int bit=0;
 for(int u=0;u<n;++u)for(int v=u+1;v<n;++v,++bit)if(mask&(1u<<bit)){++d[u];++d[v];}
 std::sort(d.rbegin(),d.rend());return d;
}
Seq elimination(const Seq&d){
 Seq histogram(d.size()+1),out;for(int x:d){require(x<int(histogram.size()),"Degree too high");++histogram[x];}
 int highest=d.empty()?0:*std::max_element(d.begin(),d.end());
 while(highest>0){
  int head=highest;out.push_back(head);--histogram[head];Seq pending(histogram.size());int remaining=head;
  for(int degree=highest;degree>0&&remaining;--degree){int take=std::min(remaining,histogram[degree]);
   histogram[degree]-=take;pending[degree-1]+=take;remaining-=take;}
  require(!remaining,"Not graphical during HH");
  for(unsigned i=0;i<histogram.size();++i)histogram[i]+=pending[i];
  while(highest&&!histogram[highest])--highest;
 }
 out.resize(d.size(),0);require(std::is_sorted(out.rbegin(),out.rend()),"Elimination not decreasing");
 require(2*std::accumulate(out.begin(),out.end(),0)==std::accumulate(d.begin(),d.end(),0),"Elimination total mismatch");return out;
}
bool weak(const Seq&a,const Seq&b){int delta=0;for(unsigned k=0;k<std::max(a.size(),b.size());++k){
 if(k<a.size())delta+=a[k];if(k<b.size())delta-=b[k];if(delta<0)return false;}return true;
}
int main(int argc,char**argv){
 require(argc==2,"usage: independently covered core8_masks.txt");std::vector<Seq> all,elim;std::vector<int> sums;std::vector<int> counts;
 for(int n=1;n<=8;++n){std::set<Seq> lists;
  if(n<=7)for(U m=0;m<(1u<<(n*(n-1)/2));++m)lists.insert(degrees(n,m));
  else{std::ifstream f(argv[1]);require(bool(f),"Missing certified 8-core data");U m;while(f>>m){require(m<(1u<<28),"Bad core mask");lists.insert(degrees(8,m));}require(f.eof(),"Malformed core list");}
  counts.push_back(lists.size());for(const Seq&d:lists){all.push_back(d);elim.push_back(elimination(d));sums.push_back(std::accumulate(d.begin(),d.end(),0));}
 }
 Count identities=0,pairs=0,crosslength=0,equal_sums=0;std::vector<Count> sameorder(8);
 for(unsigned i=0;i<all.size();++i){
  int n=all[i].size();for(int m=0;m<=28;++m){
   Seq padded=all[i];padded.insert(padded.end(),2*m,1);
   Seq expected=elim[i];expected.insert(expected.end(),m,1);expected.insert(expected.end(),m,0);std::sort(expected.rbegin(),expected.rend());
   require(elimination(padded)==expected,"Matching identity failed");
   Seq isolated=all[i];isolated.resize(n+2*m,0);Seq ze=elim[i];ze.resize(n+2*m,0);
   require(elimination(isolated)==ze,"Zero padding failed");++identities;
  }
  for(unsigned j=0;j<all.size();++j)if(weak(all[i],all[j])){
   ++pairs;if(all[i].size()!=all[j].size())++crosslength;else++sameorder[all[i].size()-1];
   if(sums[i]==sums[j])++equal_sums;
   require(weak(elim[i],elim[j]),"Weak elimination order failed");int m=(sums[i]-sums[j])/2;
   require(m>=0&&sums[i]-sums[j]==2*m,"Invalid even sum gap");
   int n=std::max(all[i].size(),all[j].size());Seq a=all[i],b=all[j];a.resize(n+2*m,0);b.resize(n,0);b.insert(b.end(),2*m,1);std::sort(b.rbegin(),b.rend());
   require(a.size()==b.size()&&std::accumulate(a.begin(),a.end(),0)==std::accumulate(b.begin(),b.end(),0),"Padded sums/lengths mismatch");
   require(weak(a,b),"Padded degree dominance failed");
   int gap0=sums[i]-sums[j],gap=gap0;
   for(int k=0;k<n;++k){if(k<int(elim[i].size()))gap-=2*elim[i][k];if(k<int(elim[j].size()))gap+=2*elim[j][k];require(gap<=gap0,"Residual overshoot");}
  }
 }
 std::cout<<"{\"status\":\"PASS\",\"graphical_lists_from_actual_graphs_by_order\":[";
 for(unsigned i=0;i<counts.size();++i){if(i)std::cout<<',';std::cout<<counts[i];}
 std::cout<<"],\"same_order_weak_pairs_by_order\":[";for(unsigned i=0;i<sameorder.size();++i){if(i)std::cout<<',';std::cout<<sameorder[i];}
 std::cout<<"],\"all_weak_pairs_including_different_lengths\":"<<pairs<<",\"cross_length_weak_pairs\":"<<crosslength
 <<",\"equal_sum_pairs\":"<<equal_sums<<",\"matching_and_isolate_identity_checks_each\":"<<identities
 <<",\"scope\":\"Graphical inputs only; not full WOWII61 or arbitrary Lean-list obligation\"}\n";
}
