# Bounded prior-scope audit: claw-free subclasses of WOWII 177 and 180

26 October 2026. **No exact prior proof of either all-claw-free subclass statement, or of the claimed zero-slack/empty-independence-core implication, was located in this bounded primary-source pass.** This is not a worldwide novelty certification and not a proof that the full numbered problems are currently unresolved. Neither subclass theorem is a full numbered closure. Mathematical correctness is audited separately. Worker artifacts were not edited.

## Source lock

The historical catalogue states, for simple connected graphs of order at least two:

- **177:** `L_s + b >= 2 alpha + sigma`, where sigma is the second entry of the nondecreasing degree sequence, counting multiplicities—not the second distinct degree.
- **180:** `L_s + b >= 1 + alpha + max_v dist_even(v)`. Distance zero is even, so the count includes v itself. The bipartite number is the maximum **order of an induced** bipartite subgraph; L_s is the maximum number of leaves of a spanning tree.

Exact rows and original glossary entries are retained in `statement_177_180.json`. Their historical `O` labels are not used as current-status certification.

## Prior work that must remain credited

**E. DeLaViña and B. Waller, *Spanning Trees with Many Leaves and Average Distance*, Electronic Journal of Combinatorics 15(1) (2008), R33, https://doi.org/10.37236/757 .** The full cached primary paper was inspected. Theorem 3 proves only `L >= 2 alpha - b + 1` and expressly distinguishes the stronger second-smallest-degree term in #177. Theorem 4 proves `gamma_c <= b-1` by sequential maximal connected bipartite pieces, connectors, and leaf deletions. Theorem 5 strengthens the leaf bound using the maximum local independence. Thus the basic bipartite-piece construction and the weak #177 bound are established prior work; the present endpoint-deletion refinement must not be represented as a new construction. The paper asks for equality characterizations; it does not state the present all-claw-free #177/#180 conclusions or the independence-core implication.

Alternating-path exchange for independent sets in claw-free graphs is classical algorithmic machinery, not a new method. The pertinent historical reference is **G. J. Minty, *On maximal independent sets of vertices in claw-free graphs*, Journal of Combinatorial Theory, Series B 28(3) (1980), 284–304, https://doi.org/10.1016/0095-8956(80)90074-X .** Bibliographic and algorithmic context were verified from primary authors' claw-free survey, https://web.math.princeton.edu/~mchudnov/claws_survey.pdf . This pass did not obtain and compare every lemma of Minty's original full paper, so it does not certify priority of the isolated alternating-odd-path/core lemma. No source located stated the exact implication `b-gamma_c-1=0 => intersection of all maximum independent sets is empty` for connected claw-free graphs.

## Nearby sources checked, not collisions

- S. Mukwembi, *Minimum degree, leaf number and traceability*, Czechoslovak Mathematical Journal 63 (2013), 539–545, https://dml.cz/dmlcz/143331 : concerns the leaf/minimum-degree traceability conjecture #190 and its claw-free specialization, not #177/#180.
- P. Mafuta, *Connected domination number and traceable graphs*, Electronic Journal of Mathematics 5 (2023), 54–59, https://doi.org/10.47443/ejm.2023.027 : establishes traceability under `gamma_c >= n-d_2-1`. This is a second-minimum-degree traceability theorem, not the leaf-plus-bipartite-number inequalities here. The publisher PDF was readable through the web tool; a direct download returned HTTP 406.
- The paper *The odd independence number of graphs, I: Foundations and classical classes*, https://arxiv.org/abs/2509.20763 , uses parity of **neighbourhood cardinality**, not parity of distance. It is not a resolution of #180.
- Search hits for 'core' often concern minimum-dominating-set cores or graph reductions, not the intersection of maximum independent sets. Those were not treated as exact prior results.

## Bounded search and access limitations

The pass searched the previously cached all-state WOWII/Gebendorfer issue/PR inventory, plus fresh all-state GitHub issue searches for exact target phrases, repository-scoped numbers in google-deepmind/formal-conjectures and umaia1234/agentic-conjectures, and equivalent bipartite-number/odd-distance/claw-free/core phrases. Repository-scoped 177 and 180 hits in formal-conjectures were unrelated problems; agentic-conjectures returned zero. Broad unscoped terms produced irrelevant/truncated results and **are not exhaustive negative evidence**. Raw query responses are internal cache; compact query metadata and returned titles are in `query_summary.json`.

Focused web queries combined the target numbers with Graffiti, and the formulas' terms with claw-free, odd/even distance, maximum independent-set intersection, second minimum degree, leaf number, and connected domination. No exact earlier all-claw-free claim was found. Publisher access to the full *Independence and upper irredundance in claw-free graphs* (2003) failed with HTTP 403; only its abstract was seen, so no full-text negative claim is made. A J-STAGE request for the 2001 revision of Minty's algorithm failed with HTTP 500; no content from that failed retrieval is used.

**Recommended wording:** “We prove the claw-free specializations of 177 and 180, using established bipartite-piece and alternating-path ideas. We did not locate these exact consequences in a bounded literature check; worldwide priority is not certified.”

Bundle only this note, `statement_177_180.json`, and `compact_provenance.json`; full third-party papers and noisy raw search inventories are research cache.
