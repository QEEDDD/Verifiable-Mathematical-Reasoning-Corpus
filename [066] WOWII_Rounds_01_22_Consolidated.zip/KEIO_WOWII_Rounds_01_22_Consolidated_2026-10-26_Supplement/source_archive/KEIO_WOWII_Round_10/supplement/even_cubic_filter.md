Let $G$ be connected of order greater than two. Let $H$ be its high-degree vertex set $\{v:d_G(v)\geq3\}$, and $L=V(G)\setminus H$. A set is *omittable* if each of its vertices has at least two neighbors outside it, and write $k=n-\gamma_2(G)$ for the largest such size. Let $t$ be the number of distinct vertex triangle-incidence counts. The target inequality is $t\leq2k$.

If $h=|H|$ is even and $G$ is a counterexample, then the maximum-cut bound $k\geq h/2$ and $t\leq h+2$ force $h=2k$ and $t\geq h+1$. At least $h-1$ high-degree vertices have pairwise distinct triangle counts at least two. Indeed the low-degree counts belong to $\{0,1\}$.

::: {#lem:cut .lemma}
**Lemma 1**. *Suppose $h=2k$. Every maximum cut splits $H$ into two sets of size $k$, and every high-degree vertex has strictly more crossing than noncrossing neighbors. In particular every high vertex of degree at least four has at least three crossing neighbors.*
:::

::: proof
*Proof.* Every high vertex has at least two crossing neighbors in a maximum cut, so the high vertices on either side form an omittable set. The two high-side sizes must therefore both be $k$. A high vertex with equally many crossing and noncrossing neighbors could be flipped without changing the cut size. That would give a maximum cut with $k+1$ high vertices on one side, impossible. Strict crossing majority gives the last claim. ◻
:::

::: {#thm:cubic .theorem}
**Theorem 1**. *An even-$h$ counterexample to WOWII 384b has at least one and at most three vertices of degree exactly three.*
:::

::: proof
*Proof.* For the upper bound, select $h-1$ high vertices with distinct triangle counts at least two. At most two selected vertices can be cubic, since a cubic vertex has at most three incident triangles. There is at most one other high vertex, so the total number of cubic vertices is at most three.

For the lower bound, suppose all high vertices have degree at least four. Fix a maximum cut, with high sides $A,B$, each of size $k$. If $v\in B$ had at least two neighbors outside $A$, then $A\cup\{v\}$ would be omittable: the vertices of $A$ each start with at least three selected neighbors by Lemma [1](#lem:cut){reference-type="ref" reference="lem:cut"}, and lose at most the single selected neighbor $v$. Thus every high vertex has at most one neighbor consisting of a same-side high vertex or a low vertex. Interchanging the sides gives this conclusion on both sides of the cut. Hence $G[A]$ and $G[B]$ are matchings, and any high vertex with a same-side high neighbor has no low-degree neighbor.

Consider the triangles containing a high vertex $v$. If $v$ has a same-side high mate, triangles using that mate number at most $k$. The other triangles correspond to edges of the matching on the opposite high side, and number at most $\lfloor k/2\rfloor$. There are no low neighbors in this case. If $v$ has no same-side high mate, triangles using two high neighbors number at most $\lfloor k/2\rfloor$, and the at most one low neighbor can contribute at most one further triangle. Thus every high triangle count is at most $k+\lfloor k/2\rfloor$ for $k\geq1$. Low triangle counts are at most one, so $$t\leq k+\lfloor k/2\rfloor+1\leq2k\qquad(k\geq2).$$ For $k=1$, all counts are at most one, so again $t\leq2k$. This contradicts the counterexample assumption, and proves that a cubic vertex must exist. ◻
:::

::: {#thm:blockers .theorem}
**Theorem 2**. *In a maximum cut of an even-$h$ counterexample, at most six high vertices have two or more neighbors consisting of same-side high vertices or low vertices. More precisely, the number of such vertices on one side is at most twice the number of cubic vertices on the opposite side.*
:::

::: proof
*Proof.* Write $A,B$ for the high sides. If $v\in B$ has at least two neighbors outside $A$, adding $v$ to the omittable set $A$ must fail at some retained vertex $u\in A$ that is adjacent to $v$ and has exactly two neighbors outside $A$. Lemma [1](#lem:cut){reference-type="ref" reference="lem:cut"} forces $u$ to be cubic: a higher-degree high vertex has at least three crossing neighbors. Each such blocker $u$ has only two neighbors outside $A$, and therefore can block at most two candidates $v\in B$. Summing over cubic blockers proves the one-side bound. Applying it on both sides and using Theorem [1](#thm:cubic){reference-type="ref" reference="thm:cubic"} gives at most six exceptions in total. ◻
:::

Only one-high-vertex augmentation is used here. Simultaneously adding two high vertices is not justified by this argument: a retained vertex with three selected neighbors might lose both added vertices. The structural filters do not exclude all remaining high-degree orders and do not resolve the original conjecture.
