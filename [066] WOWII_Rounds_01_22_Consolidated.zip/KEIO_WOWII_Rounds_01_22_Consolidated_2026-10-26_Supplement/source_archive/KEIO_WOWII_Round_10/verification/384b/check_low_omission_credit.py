#!/usr/bin/env python3
"""Exact universal alteration bounds with safe low-vertex omission credits.
No graph catalogue, optimizer or floating-point arithmetic is used.
"""
from fractions import Fraction as F
from math import comb
from pathlib import Path
import json

def C(n,k):
    return comb(n,k) if n>=0 and 0<=k<=n else 0

def rho(t):
    d=3
    while d*(d-1)//2<t:d+=1
    return d

def repair(h,s,d,forced=0):
    assert 2<=s<h and forced in (0,1,2)
    if forced==2:return F(0)
    e=min(d-forced,h-1)
    numerator=C(h-1-e,s)
    if not forced:numerator+=e*C(h-1-e,s-1)
    return F(h-s,h)*F(numerator,C(h-1,s))

records=[]
for h,s in [(42,16),(43,16)]:
    degrees=([3]+[rho(j) for j in range(2,h+1)]) if h%2==0 else [rho(j) for j in range(2,h+2)]
    ordinary=[repair(h,s,d) for d in degrees]
    forced_one=[repair(h,s,d,1) for d in degrees]
    assert all(ordinary[i]>=forced_one[i]>=0 for i in range(h))
    assert all(repair(h,s,d,f)>=repair(h,s,d+1,f) for f in (0,1) for d in range(3,h+3))
    base=F(s)+sum(ordinary,F(0))
    # Any two distinct endpoint positions: take the least available saving.
    pair_savings=sorted(ordinary[i]-forced_one[i] for i in range(h))[:2]
    pair_credit=F(s*(s-1),h*(h-1))
    pair_bound=base-sum(pair_savings,F(0))-pair_credit
    threshold=F(h,2) if h%2==0 else F(h-1,2)
    pair_margin=threshold-pair_bound
    expected_pair=F(75065,541569) if h==42 else F(1057200,7762489)
    assert pair_margin==expected_pair>0
    entry=dict(h=h,s=s,degree_lower_profile=degrees,
        baseline_expected_high_selection=str(base),
        two_endpoint_minimum_repair_savings=list(map(str,pair_savings)),
        degree_two_omission_credit=str(pair_credit),
        degree_two_expected_net_high_selection_bound=str(pair_bound),
        forbidden_counterexample_threshold=str(threshold),
        degree_two_strict_margin=str(pair_margin))
    if h%2:
        pendant_credit=F(s,h)
        pendant_bound=base-min(ordinary)-pendant_credit
        pendant_margin=threshold-pendant_bound
        assert pendant_margin>0
        entry.update(pendant_root_minimum_repair_saving=str(min(ordinary)),
            pendant_omission_credit=str(pendant_credit),
            pendant_expected_net_high_selection_bound=str(pendant_bound),
            pendant_strict_margin=str(pendant_margin))
    records.append(entry)
result=dict(status='PASS',scope='Excludes h=43 altogether and h=42 when a degree-two vertex exists. Partial only.',records=records,
    combined_residual_high_orders=list(range(10,43)),
    residual_h42_representative_order=43,
    all_counterexamples_have_representative_order_at_most=64)
Path(__file__).with_name('low_omission_credit_checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
