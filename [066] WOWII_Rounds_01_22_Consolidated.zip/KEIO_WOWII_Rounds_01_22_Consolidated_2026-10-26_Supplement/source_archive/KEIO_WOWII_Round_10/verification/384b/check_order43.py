#!/usr/bin/env python3
"""Exact rational certificates for the order-43 reduction, not a graph search."""
from fractions import Fraction as F
from math import comb
from pathlib import Path
import json

def C(n,k):return comb(n,k) if n>=0 and 0<=k<=n else 0

def rho(t):
    d=3
    while d*(d-1)//2<t:d+=1
    return d

def repair(h,s,d):
    e=min(d,h-1)
    return F(h-s,h)*F(C(h-1-e,s)+e*C(h-1-e,s-1),C(h-1,s))

def profile(h):
    return [rho(j) for j in range(2,h+2)] if h%2 else [3]+[rho(j) for j in range(2,h+1)]

records=[]
selected=[14,14,14,14,14,14,14,14,15,15,15,15,15]
expected=['104761/62100','6259/5220','555607/450225','3937304/4652325','73523/82708','4075549/7120080','36783491/60520680','1370525/4034712','18196217/48416544','22835/145928','226475387/1031419104','5208220/139671337','12325127/154120096']
for h,s,ex in zip(range(28,41),selected,expected):
    m=42-h
    base=F(s)+sum((repair(h,s,d) for d in profile(h)),F(0))
    credit=F(m*s*(s-1),h*(h-1))
    threshold=F(h//2)
    margin=threshold-base+credit
    assert margin==F(ex)>0
    records.append(dict(h=h,s=s,independent_degree_two_vertices_required_if_order_at_least44=m,
        baseline_expected_selected_high=str(base),low_omission_credit=str(credit),
        forbidden_counterexample_threshold=str(threshold),strict_margin=str(margin)))
h,s=41,15
rs=[repair(h,s,d) for d in profile(h)]
base=F(s)+sum(rs,F(0))
pair_margin=F(20)-base+F(2*s*(s-1),h*(h-1))
pendant_margin=F(20)-base+min(rs)+F(s,h)
assert pair_margin==F(162283,3197836)>0
assert pendant_margin==F(28995,155992)>0
assert max(h+(h+1)//2+2 for h in range(1,28))==43
result=dict(status='PASS',scope='Universal probability inequalities for the order43 representative reduction; no exhaustive graph search or full closure.',records=records,
    h41=dict(s=s,baseline_expected_selected_high=str(base),independent_degree_two_pair_strict_margin=str(pair_margin),pendant_triangle_strict_margin=str(pendant_margin)),
    small_h_maximum_representative_order=43,
    final_counterexample_representative_order_bound=43)
Path(__file__).with_name('order43_checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
