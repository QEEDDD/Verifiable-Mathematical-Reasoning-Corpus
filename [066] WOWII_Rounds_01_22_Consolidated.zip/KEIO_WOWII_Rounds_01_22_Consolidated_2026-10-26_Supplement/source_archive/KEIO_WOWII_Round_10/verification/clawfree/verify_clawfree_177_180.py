"""Finite exact sanity checks; the Markdown/TeX proof is unrestricted within claw-free graphs."""
from pathlib import Path
import sys,itertools as it,json
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'round_01/leaves'))
from search_leaves import nx,masks,bits,stats

def clawfree(G):
 return not any(not any(G.has_edge(a,b)for a,b in it.combinations(S,2))for v in G for S in it.combinations(G[v],3))

def check(G):
 A=masks(G);a=max(s.bit_count()for s in range(1<<len(G))if all(not(A[v]&s)for v in bits(s)))
 s=stats(G);sigma=sorted(d for _,d in G.degree())[1];o=min(sum(d%2 for d in row)for row in s['D'])
 assert s['L']+s['b']>=2*a+sigma
 assert s['eta']>=a-o
 if sigma>=2 and a>=2:assert 2*a+sigma<=len(G)+2
 return dict(n=len(G),alpha=a,sigma=sigma,eta=s['eta'],margin177=s['L']+s['b']-2*a-sigma,margin180=s['eta']-a+o)

def main():
 rows=[]
 for G in nx.graph_atlas_g():
  if len(G)<3 or not nx.is_connected(G) or not clawfree(G):continue
  rows.append(check(G))
 out=dict(result='PASS',clawfree_atlas_graphs=len(rows),orders=sorted(set(x['n']for x in rows)),minimum_margin177=min(x['margin177']for x in rows),minimum_margin180=min(x['margin180']for x in rows))
 Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
if __name__=='__main__':main()
