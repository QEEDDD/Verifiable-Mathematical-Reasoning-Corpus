"""Construct the odd-path certificate forced by an essential independent vertex."""
from pathlib import Path
import sys,itertools as it,json
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'round_01/leaves'))
from search_leaves import nx,masks,bits,bipartite,stats

def clawfree(G):
 return not any(not any(G.has_edge(a,b)for a,b in it.combinations(S,2))for v in G for S in it.combinations(G[v],3))

def certificate(G,I,v):
 P=[v]
 while True:
  ps=set(P);candidates=[w for w in G if w not in ps and set(G[w])&ps and nx.is_bipartite(G.subgraph(ps|{w}))]
  if not candidates:break
  w=candidates[0];on=set(G[w])&ps
  assert len(on)==1,('even-cycle exchange would avoid essential v',P,w,on)
  p=next(iter(on));assert p in {P[0],P[-1]}
  other=(set(G[w])&I)-ps
  assert len(other)==1,('free-end exchange would avoid essential v',P,w,other)
  z=next(iter(other));assert not(set(G[z])&ps)
  P=([z,w]+P)if p==P[0]else(P+[w,z])
  assert nx.is_tree(G.subgraph(P)) and max(dict(G.subgraph(P).degree()).values())<=2
 assert len(P)>=3 and len(P)%2==1
 assert v in P and all((x in I)==(j%2==0)for j,x in enumerate(P))
 assert not any(set(G[w])&set(P) and nx.is_bipartite(G.subgraph(set(P)|{w}))for w in set(G)-set(P))
 return P

def main():
 count=0;essential=0;examples=[]
 for G in nx.graph_atlas_g():
  if len(G)<3 or not nx.is_connected(G) or not clawfree(G):continue
  A=masks(G);inds=[s for s in range(1<<len(G))if all(not(A[v]&s)for v in bits(s))];a=max(map(int.bit_count,inds));mx=[s for s in inds if s.bit_count()==a];core=(1<<len(G))-1
  for s in mx:core&=s
  count+=1
  I=set(bits(mx[0]));st=stats(G)
  for v in bits(core):
   P=certificate(G,I,v);assert st['eta']>=1;essential+=1
   if len(examples)<5:examples.append(dict(edges=list(G.edges()),I=sorted(I),v=v,P=P,eta=st['eta']))
  ds=dict(nx.all_pairs_shortest_path_length(G))
  for v in G:assert a<=sum(d%2 for d in ds[v].values())+int(v in I)
  if st['eta']==0:assert core==0
 out=dict(result='PASS',clawfree_graphs=count,essential_vertex_certificates=essential,examples=examples)
 Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(out['result'],count,essential)
if __name__=='__main__':main()
