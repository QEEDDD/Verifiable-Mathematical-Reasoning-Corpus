# Consolidated Round11 manuscript spot-check

**PASS.** 26 October 2026. Authoritative files:
`round_11/domination133/manuscript.tex` and `manuscript.md`.

The new P7 density proof and the sharpened radius-four characterization
agree with the separately audited notes and reports in this packet. The
converse now explicitly checks both cycle-vertex eccentricity four and
leaf eccentricity five. Definitions consistently use vertex order for
paths, subgraph exclusion for C4, and the unrounded local-independence
average. The full original conjecture is not claimed solved.

## Lemma 4: P6-free radius-three input

The van 't Hof--Paulusma statement is applied with the correct distinction:
the dominating complete bipartite subgraph need not be induced. Strong C4
exclusion forces it to be a star, whose center has eccentricity at most two
in the entire dominated graph. In the other alternative, girth at least
five permits only singleton or opposite-pair contacts on the dominating
C6. A singleton contact gives an induced P6. If an opposite-pair exterior
vertex exists, c0 has distance at most two to all cycle vertices via the
new shortcut and to all exterior vertices because every opposite pair
meets {c5,c0,c1}. Radius three therefore forces G=C6. This is the same
previously audited primary input, now explicitly reproduced.

## Lemma 5: all low-average radii

For r≥4 the classical p≥2r−1 bound covers average at most three. At radius
one a girth-five graph is a star; the singleton and K2 endpoints are harmless.
At radius two, a connected triangle-free P4-free graph is complete bipartite:
fix u, use distance at most two, and observe that a distance-two vertex
missing a neighbor of u gives the induced path w,x,u,y. Triangle-freeness
then makes the two resulting classes independent. C4 exclusion forces a
star, contradicting radius two. Thus p≥4, enough for average at most two.

For the remaining radius-two interval, a connected girth-five P5-free graph
is a tree or C5. If a cycle exists, a shortest cycle is induced; its length
must be five, since an induced cycle of length at least six contains P5.
Any first exterior neighbor has a unique cycle contact and gives P5 with
four consecutive cycle vertices. Connectivity then forces the graph to be
exactly C5. Both possibilities have average degree at most two. Hence an
average above two forces p≥5.

At radius three, the classical bound gives p≥5. If the average is above
two, Lemma 4 excludes P6-freeness, so p≥6. These cases prove Lemma 5 for
every radius. The author implemented the requested precision wording change
from “any cycle” to “a shortest cycle is an induced five-cycle” in the final
snapshotted Markdown and TeX. No theorem repair was required.

## Exact corollary

For triangle-free graphs containing C4, the original target reduces to
p≥r+1. Otherwise the graph has girth at least five and local independence
equals degree. Lemma 5 covers average at most three. For averages in (3,4],
the P7 theorem gives p≥7 at radii two and three; the radius-four
characterization gives p≥8 because its exceptional graphs have average two;
and p≥2r−1≥r+4 covers r≥5. Radius one cannot have average above three.

Thus the consolidated corollary **all triangle-free graphs with average
local independence at most four satisfy original WOWII133** is correct.
This is a subclass result, not a full original numbered closure. Contextual
prior-work/priority remarks are not premises of either new analytic proof;
their separate literature gate is not certified by this spot-check.
