# Independent audit: P7-free graphs of girth at least five

**Verdict: PASS. Self-contained analytic partial result, not full WOWII133.**
26 October 2026.

Candidate: `round_11/domination133/p7_girth5_density.md`, frozen snapshot in
this packet. Every connected simple graph with no triangle, no four-cycle
as a subgraph, and no induced seven-vertex path satisfies 2m≤3n. The
inequality is strict when an induced C7 occurs. No external structural
theorem is required for this density statement.

Together with the separately audited radius-four result, this establishes
original WOWII133 for **all triangle-free graphs with unrounded average
local independence at most four**. Graphs containing triangles and the
unrestricted conjecture are not settled. No worldwide priority is claimed.

## 1. Induced C7 case

The seven-cycle contact restrictions are correct. Girth at least five
forbids contact distances one and two; three contacts necessarily contain
such a pair. A single contact creates the displayed induced P7. Thus each
first-layer vertex has precisely two contacts at cyclic distance three,
and each possible contact pair occurs at most once by C4 exclusion.

Any edge between two first-layer vertices would leave only one permissible
cycle vertex for the second endpoint's two contacts: triangles forbid the
first endpoint's contacts, and four-cycles forbid their cycle neighbors.
Hence the first layer is independent. The candidate's P7 for the index
pair i,i+2 is chordless, including its two cycle-contact chords: the unused
contact of the final vertex is not on the path. The forbidden pairs form
a seven-cycle on the indices, so at most three first-layer vertices occur.

The displayed shortest-path extensions correctly exclude distance-three
vertices and edges within the second layer. In each, the unused contact
of the first-layer vertex is the omitted cycle vertex, not a chord. If
the second-layer degrees are d_y, then 1≤d_y≤k≤3. The common-neighbor
bound gives sum binom(d_y,2)≤binom(k,2). Since 2d−3≤binom(d,2) at all
three possible positive degrees,

    3n−2m ≥ 7−k−binom(k,2) ≥ 1.

This includes k=0, when the second layer is necessarily empty.

## 2. Dominating C5 case: the new component argument

Every exterior vertex has one cycle contact. Edges only join classes at
pentagram distance one (cycle-index difference ±2), and edges between any
two classes form a matching. Consequently the exterior graph has maximum
degree two. Along a component path the class indices advance consistently
in one direction: reversing direction would give the intermediate vertex
two neighbors in one contact class.

The path components have at most six vertices. A cycle component has at
most seven vertices under P7 exclusion, and the consistent class sequence
forces length divisible by five. Thus it is C5.

For the rooted-three-vertex-path index set T(Q), the disjointness assertion
is sound. If two components have such a path rooted in the same class,
join their roots through their common cycle contact. This produces seven
distinct vertices on an induced path. Different components have no exterior
cross edges; the two nonroot vertices of either path have contacts different
from the joining cycle vertex. Hence no hidden chord occurs.

The component excess calculations are exact. A P3 has excess one and two
root indices. A path on four through six vertices has every vertex as a
root of some three-vertex subpath, giving min(k,5) distinct root indices and
excess k−2. A C5 has excess and root-set size both five. Isolated vertices
and single edges have nonpositive excess. Summing over pairwise disjoint
positive-component root sets yields 2e_A−a≤5 and therefore 3n−2m≥0.

There is no assumption that the contact classes are singletons or that
the exterior graph has only one nontrivial component.

## 3. Nondominating C5 with no C7

The shortest-path and same-layer-edge arguments exclude all layers beyond
the second and all edges within the second layer. Each second-layer vertex
has a neighbor in the first layer. Two such neighbors cannot belong to
the same contact class by C4 exclusion. For adjacent contact classes the
candidate uses the four-cycle-vertex arc ending at c_i, not the arc which
would create a closing chord; its seven-vertex sequence is indeed induced.
For nonadjacent classes the displayed closed seven-vertex sequence is an
induced C7. The possible chord between the two first-layer vertices is
excluded by triangle-freeness through their common second-layer neighbor.

Thus every second-layer vertex has degree one. Removing the second layer
leaves a connected induced graph dominated by the fixed C5. Reinserting
each deleted leaf increases 3n−2m by one. This transfer is exact and does
not assume invariance of any radius or domination parameter.

## 4. Exhaustiveness of the cases and the consequence

If there is neither an induced C5 nor an induced C7, a shortest odd cycle
would be induced of length at least nine and contain P7, so the graph is
bipartite. A tree has positive deficit. Otherwise a shortest cycle is C6;
it dominates by the displayed P7 extension, and bipartiteness plus C4
exclusion leaves only an opposite-class exterior matching. The stated
counts n=6+2k+s, m=6+3k+s give deficit 6+s>0.

These cases are exhaustive, and the Petersen equality example is valid
by the earlier independently audited P6-freeness check.

For original WOWII133, triangle-free and C4-free makes local independence
equal degree. Average greater than three now forces p≥7, which suffices
at radius three when the average is at most four. The radius-four theorem
forces p≥8 in the same average range. The previously audited low-average
case, radius-two case, and classical p≥2r−1 for r≥5 cover the remaining
radii. The C4-present branch remains the elementary p≥r+1 branch. These
are exactly the claimed subclass implications; there is no rounding of
the average.

## 5. Independent finite controls

The supplied independent checker reuses only this auditor's elementary
bitset graph and induced-path routines, not the author's implementation.
It generates actual graphs and tests the claimed inequalities and component
conditions from their adjacency matrices.

* Dominating C5: all multisets of at most eight exterior contacts and all
  eligible exterior-edge subsets: **4,202,743 candidates**, 95,988 with girth
  at least five, 13,233 also P7-free. All density and **71,971 component**
  excess/root-disjointness checks passed.
* One or two arbitrary second-layer vertices over the eligible first-layer
  graphs of order at most five, with every nonempty incidence pattern and
  either possible second-layer edge: **1,517,421 candidates**. Of these,
  170,011 have girth at least five; 3,310 are also P7-free; 2,890 additionally
  have no induced C7. Every graph in the last group has all second-layer
  vertices of degree one, and every P7-free graph has the density bound.
* C7 contact sets, with every possible first-layer edge subset:
  **2,350,602 candidates**. Exactly 128 survive the girth test, all with
  independent first layer; 29 are P7-free, all with at most three exterior
  vertices. Adding up to four independent second-layer vertices with all
  nonempty incidence patterns gives **21,308 candidates**, 343 valid
  P7-free/girth-five graphs, all with strict density bound.

Reproduce from the workspace root:

```sh
d=independent_audit/133
g++ -std=c++17 -O3 "$d/check_p7_independent.cpp" -o /tmp/audit_p7_girth5
/tmp/audit_p7_girth5
```

The tests are supplementary finite controls. The universal conclusion
rests on the analytic proof above. **No unresolved mathematical gap.**
