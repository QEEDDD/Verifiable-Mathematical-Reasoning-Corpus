# Independent audit: radius four, girth at least five, and P8 exclusion

**Verdict: PASS, partial result only.** 26 October 2026.

Audited candidate: `round_10/domination133/radius_four_trianglefree.md`,
preserved in this directory's `snapshots/`. The audit is filed in Round11
because Round10 was already being packaged. No modification of a frozen
Round09 or Round10 manuscript is required by this verdict.

The analytic theorem is valid: a connected simple graph of girth at least
five, radius four, and no induced eight-vertex path has average degree at
most three. Consequently original WOWII133 holds for triangle-free graphs
of radius four with unrounded average local independence at most four.
This is not the full conjecture; in particular this result alone does not
settle the nonbipartite radius-three interval.

## 1. Established inputs, checked at the required scope

The exact statement of Camby--Schaudt Theorem 5 was checked in the primary
[arXiv manuscript](https://arxiv.org/pdf/1402.7213v1), printed page 3, including
visual inspection of the rendered page. The needed conclusion is connected
domination by an induced P6-free graph or an induced C8. It is not a claim
that the dominating subgraph must be a path. The relevant Lemma 2 and proofs
of Theorems 4 and 5 on printed pages 4--5 were also read and checked.

The shifting argument in that proof is sound: exchanging one end of a
long induced path for the other end's private neighbor preserves a minimum
connected dominating set. Iterating shifts separates any vertices outside
the path from all replacement vertices, so no such extra vertices exist.
If the minimum set is the path, its ends' private neighbors must be adjacent,
yielding the longer dominating induced cycle.

The paper invokes an earlier minimal-connected-domination lemma. The needed
fact can be independently verified directly. If a minimal connected
dominating set contains an induced path with k−2 vertices, each end has
an extension contacting only that end of the path: use a private neighbor
if the end is not a cut vertex, and a vertex in a component cut off from
the rest of the path otherwise. The two extensions are distinct. Together
with the path they induce Pk or Ck according as they are nonadjacent or
adjacent. Thus a (Pk,Ck)-free graph has no such path in a minimal connected
dominating set. Applying this at k+1 is precisely the auxiliary fact used
in the shifting proof. There is no unreviewed AI-paper dependency here.

The earlier radius-three lemma and the classical bound p≥2r−1 were audited
in `round_09/independent_audit/133/CONSOLIDATED_MANUSCRIPT_AUDIT.md`.
Their hypotheses are preserved under induced subgraphs. The radius-three
lemma uses van 't Hof--Paulusma's established dominating-C6 or dominating
complete-bipartite-subgraph theorem; its exact primary statement was checked
there. In the stronger C4-subgraph-free class, the bipartite subgraph is a
star, giving radius at most two. A dominating C6 with any exterior vertex
also gives radius at most two under P6 exclusion. Hence radius three forces
the graph itself to be C6. This is correctly applied in the current proof.

## 2. Dominating-cycle reduction

For connected induced dominating H, a center of H is within r(H)+1 of
every vertex of G, so r(G)≤r(H)+1. In the P6-free alternative, the path
bound gives r(H)≤3 and r(G)=4 forces r(H)=3. Therefore H=C6.

In the C8 alternative, each exterior contact set is nonempty. C4 exclusion
forbids cyclic contact-distance two. If there is no pair at cyclic distance
three or four, the contacts are a singleton or an adjacent pair, and seven
consecutive cycle vertices appended to the exterior vertex give P8. Thus
every exterior vertex has a pair at distance three or four.

For a fixed cycle vertex, the three cycle vertices at distance at least
three form a consecutive triple and cannot contain that contact pair.
Every exterior vertex is consequently within three of each cycle vertex.
One exterior contact pair also provides a two-edge shortcut toward the
antipode of one contact, reducing its distance to the antipode to at most
three. That contact becomes a center of eccentricity at most three. Thus
the radius-four C8 alternative is exactly G=C8.

## 3. The C6 contact argument and the original count

In the remaining alternative, girth at least five permits one cycle
contact or a pair of opposite contacts. A vertex with an opposite pair has
eccentricity at most three because the cycle dominates, so every exterior
vertex has a unique cycle contact. The six contact classes A_i are
independent; edges between consecutive classes are excluded; edges between
each pair of classes form a matching by the common-neighbor C4 test.

Every class is nonempty, and each A_i contains a vertex at distance four
from c_(i+3). All other vertices have an a priori cycle route of length at
most three from c_(i+3). The witness used in the candidate is therefore
legitimate, not an assumption that some particular exterior vertex realizes
the radius.

For a diagonal edge x∈A_i, y∈A_(i+2), the displayed eight-vertex sequence
with a witness z∈A_(i+4) is an induced P8 whenever a second x'∈A_i exists.
Unique contacts remove cycle--exterior chords; z's distance condition removes
its chords to x,x',y; the between-class matching removes yx'; and the same
class is independent. Reversing orientation gives the symmetric endpoint
conclusion. Thus both endpoint classes must be singletons.

The candidate's density identity 3n−2m=6+(a−2o)−2d is exact. At most two
diagonal edges occur in each parity triple because a triangle is forbidden.
When d=4 all classes are singletons. Negativity would require all three
opposite edges, and each of the three listed possibilities for the odd
P3 center contains exactly the displayed C4. All three witnesses were
independently checked. Thus the original, slightly longer proof passes.

## 4. Optional stronger conclusion found during this audit

The density count can actually be simplified. Every radius witness in A_i
has no exterior neighbor: any allowed neighboring class is A_(i+2),
A_(i+3), or A_(i+4), and an exterior neighbor in any of these classes gives
a route of at most three edges from c_(i+3) to the witness.

Every class therefore contains an exterior-isolated vertex. A diagonal
edge forces its endpoint classes to be singletons by the preceding P8
argument, contradicting the existence of the isolated vertex in each such
class. **There are no diagonal edges.** The exterior graph consists only
of the opposite-class matching and isolated vertices, at least six of
which are present. Consequently the C6 alternative is bipartite and

    3n−2m = 6+a−2o ≥ 12.

The other alternative is C8, which is also bipartite. Hence the argument
already proves that every graph in the theorem is bipartite.

### Final strengthened characterization: PASS

The author subsequently supplied `round_11/domination133/radius_four_characterization.md`,
also preserved in `snapshots/`. Its further simplification is valid. An
opposite exterior edge xy, with x∈A_i and y∈A_(i+3), together with the
exterior-isolated witnesses z∈A_(i+1), w∈A_(i+4), gives the induced P8

    z,c_(i+1),c_i,x,y,c_(i+3),c_(i+4),w.

Unique cycle contacts, the induced C6, and witness isolation exclude every
chord. Thus there are no exterior edges at all. The class is exactly C8,
or C6 with a nonempty leaf set attached to every cycle vertex. The converse
also holds: cycle vertices in the latter family have eccentricity four,
leaves have eccentricity five, and an induced path has at most five cycle
vertices and two leaf endpoints. Both families are unicyclic, so **m=n**.
This stronger characterization has therefore passed full analytic audit,
not merely finite testing.

## 5. Independent finite controls

`check_radius4_independent.cpp` does not import the author's code. It builds
all dominating-C6 graphs with nonempty contact classes of size one or two,
at most two doubled classes, and every subset of the eligible exterior
edges. It then computes girth conditions, radius, and induced-path existence
directly rather than assuming the singleton conclusion.

Results: 811,520 candidates, 85,874 of girth at least five, 58 of radius four,
and 22 simultaneously P8-free. All 22 satisfy the density claim; none has
a diagonal edge. Separately all 800 pairs of legal C8 contact sets, with
both choices of their exterior edge, were checked: 480 have girth at least
five and 104 are P8-free, all with radius at most three. The three exceptional
C4 edge lists also passed. These checks are supporting controls, not an
exhaustive proof of the universal theorem.

Reproduce from the workspace root:

```sh
d=independent_audit/133
g++ -std=c++17 -O3 "$d/check_radius4_independent.cpp" -o /tmp/audit_radius4
/tmp/audit_radius4
```

**No unresolved proof gap.** No full WOWII133 resolution, formal Lean
certificate, exhaustive large-graph census, or worldwide priority claim
is certified by this report.
