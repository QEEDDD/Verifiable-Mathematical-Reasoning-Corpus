// Reuse only this auditor's elementary graph/induced-path routines.
#define main radius4_audit_unused_main
#include "check_radius4_independent.cpp"
#undef main
#include <functional>

bool cycdfs(const Graph&g,int start,int last,U used,int len,int target){
 if(len==target)return true;
 for(U t=g.a[last]&~used;t;t&=t-1){int w=__builtin_ctz(t);if(w<=start)continue;
  U contacts=g.a[w]&used,expected=1u<<last;
  if(len+1==target)expected|=1u<<start;
  if(contacts==expected&&cycdfs(g,start,w,used|(1u<<w),len+1,target))return true;
 }return false;
}
bool cycle(const Graph&g,int k){for(int s=0;s<g.n;++s)if(cycdfs(g,s,s,1u<<s,1,k))return true;return false;}
int main(){try{
 C c5all=0,c5girth=0,c5p7free=0,componentChecks=0,layerAll=0,layerGirth=0,layerP7free=0,layerNoC7=0;
 std::vector<int>classes;
 auto examine=[&](){int a=classes.size();std::vector<std::pair<int,int>>possible;
  for(int u=0;u<a;++u)for(int v=u+1;v<a;++v){int d=(classes[u]-classes[v]+5)%5;if(d==2||d==3)possible.push_back({5+u,5+v});}
  for(U mask=0;mask<(1u<<possible.size());++mask){++c5all;Graph g(5+a);
   for(int i=0;i<5;++i)g.edge(i,(i+1)%5);for(int j=0;j<a;++j)g.edge(5+j,classes[j]);
   for(int j=0;j<(int)possible.size();++j)if(mask&(1u<<j))g.edge(possible[j].first,possible[j].second);
   if(!g.girth5())continue;++c5girth;if(g.haspath(7))continue;++c5p7free;
   need(2*g.edges()<=3*g.n,"Dominating C5 density failure");
   U unseen=((1u<<g.n)-1)&~31u,allRoots=0;int excess=0;
   while(unseen){U comp=1u<<__builtin_ctz(unseen),front=comp;
    while(front){U next=0;for(U t=front;t;t&=t-1)next|=g.a[__builtin_ctz(t)];next&=unseen&~comp;comp|=next;front=next;}
    unseen&=~comp;U roots=0;int vertices=__builtin_popcount(comp),twice=0;
    for(U t=comp;t;t&=t-1){int u=__builtin_ctz(t);twice+=__builtin_popcount(g.a[u]&comp);
     for(U vset=g.a[u]&comp;vset;vset&=vset-1){int v=__builtin_ctz(vset);if((g.a[v]&comp&~(1u<<u)&~g.a[u])!=0)roots|=1u<<classes[u-5];}
    }
    ++componentChecks;need(!(roots&allRoots),"Rooted P3 sets intersect");allRoots|=roots;excess+=twice-vertices;
    if(twice>vertices)need(twice-vertices<=__builtin_popcount(roots),"Component excess bound failure");
   }need(excess<=5,"Total exterior excess failure");
   // For all small first layers, add one or two arbitrary second-layer
   // vertices, including their possible mutual edge. Do not assume leaves.
   if(a==0||a>5)continue;
   for(int b=1;b<=2;++b)for(U incidence=0;incidence<(1u<<(a*b));++incidence){bool nonempty=true;
    for(int j=0;j<b;++j)if(((incidence>>(a*j))&((1u<<a)-1))==0)nonempty=false;
    if(!nonempty)continue;
    for(int linked=0;linked<(b==1?1:2);++linked){++layerAll;Graph h=g;h.n+=b;
     for(int j=0;j<b;++j)for(int i=0;i<a;++i)if(incidence&(1u<<(a*j+i)))h.edge(5+a+j,5+i);
     if(linked)h.edge(5+a,6+a);if(!h.girth5())continue;++layerGirth;if(h.haspath(7))continue;++layerP7free;
     need(2*h.edges()<=3*h.n,"General C5-layer density failure");if(cycle(h,7))continue;++layerNoC7;
     for(int j=0;j<b;++j)need(__builtin_popcount(h.a[5+a+j])==1,"Second-layer nonleaf without C7");
    }
   }
  }
 };
 std::function<void(int,int)>build=[&](int next,int remaining){examine();if(!remaining)return;
  for(int i=next;i<5;++i){classes.push_back(i);build(i,remaining-1);classes.pop_back();}
 };build(0,8);
 C c7all=0,c7girth=0,c7p7free=0,c7layers=0,c7layerfree=0;
 for(U contacts=0;contacts<128;++contacts){std::vector<int>idx;for(int i=0;i<7;++i)if(contacts&(1u<<i))idx.push_back(i);int k=idx.size();
  std::vector<std::pair<int,int>>pairs;for(int i=0;i<k;++i)for(int j=i+1;j<k;++j)pairs.push_back({7+i,7+j});
  for(U edges=0;edges<(1u<<pairs.size());++edges){++c7all;Graph g(7+k);for(int i=0;i<7;++i)g.edge(i,(i+1)%7);
   for(int j=0;j<k;++j){g.edge(7+j,idx[j]);g.edge(7+j,(idx[j]+3)%7);}
   for(int j=0;j<(int)pairs.size();++j)if(edges&(1u<<j))g.edge(pairs[j].first,pairs[j].second);
   if(!g.girth5())continue;++c7girth;need(edges==0,"C7 first layer not independent");if(g.haspath(7))continue;++c7p7free;need(k<=3,"C7 layer larger than three");need(2*g.edges()<3*g.n,"C7 strict density failure");
   for(int b=1;b<=4;++b)for(U inc=0;inc<(1u<<(k*b));++inc){bool nonempty=true;for(int j=0;j<b;++j)if(((inc>>(k*j))&((1u<<k)-1))==0)nonempty=false;if(!nonempty)continue;++c7layers;Graph h=g;h.n+=b;
    for(int j=0;j<b;++j)for(int i=0;i<k;++i)if(inc&(1u<<(k*j+i)))h.edge(7+k+j,7+i);
    if(!h.girth5()||h.haspath(7))continue;++c7layerfree;need(2*h.edges()<3*h.n,"Layered C7 strict density failure");
   }
  }
 }
 std::cout<<"{\n  \"status\": \"PASS\",\n  \"c5_candidates\": "<<c5all<<",\n  \"c5_girth5\": "<<c5girth<<",\n  \"c5_p7free\": "<<c5p7free<<",\n  \"exterior_component_checks\": "<<componentChecks<<",\n  \"c5_second_layer_candidates\": "<<layerAll<<",\n  \"c5_second_layer_girth5\": "<<layerGirth<<",\n  \"c5_second_layer_p7free\": "<<layerP7free<<",\n  \"c5_second_layer_p7free_c7free\": "<<layerNoC7<<",\n  \"c7_first_layer_candidates\": "<<c7all<<",\n  \"c7_first_layer_girth5\": "<<c7girth<<",\n  \"c7_first_layer_p7free\": "<<c7p7free<<",\n  \"c7_second_layer_candidates\": "<<c7layers<<",\n  \"c7_second_layer_valid\": "<<c7layerfree<<"\n}\n";
 return 0;}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
