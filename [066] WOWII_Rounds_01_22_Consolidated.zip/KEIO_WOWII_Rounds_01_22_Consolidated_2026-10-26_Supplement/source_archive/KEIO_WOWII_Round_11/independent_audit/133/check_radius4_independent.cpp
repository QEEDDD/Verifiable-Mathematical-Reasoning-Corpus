// Independent finite stress tests of the radius-four proof, not a census
// sufficient to replace its analytic argument. No author code is imported.
#include <array>
#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <vector>
using U=unsigned; using C=std::uint64_t;
void need(bool b,const char*s){if(!b)throw std::runtime_error(s);}
struct Graph{
 int n; std::array<U,20>a{};
 Graph(int n):n(n){}
 void edge(int u,int v){a[u]|=1u<<v;a[v]|=1u<<u;}
 bool girth5()const{
  for(int u=0;u<n;++u)for(int v=u+1;v<n;++v){
   U common=a[u]&a[v]; if(__builtin_popcount(common)>1)return false;
   if((a[u]&(1u<<v))&&common)return false;
  }return true;
 }
 int edges()const{int s=0;for(int u=0;u<n;++u)s+=__builtin_popcount(a[u]);return s/2;}
 int ecc(int v)const{
  U seen=1u<<v,front=seen;int d=0;
  while(seen!=((1u<<n)-1)){
   U next=0;for(U t=front;t;t&=t-1)next|=a[__builtin_ctz(t)];
   next&=~seen;need(next,"Disconnected test graph");seen|=next;front=next;++d;
  }return d;
 }
 int radius()const{int r=n;for(int v=0;v<n;++v)r=std::min(r,ecc(v));return r;}
 bool pathdfs(int last,U used,U forbidden,int len,int target)const{
  if(len==target)return true;
  for(U t=a[last]&~(used|forbidden);t;t&=t-1){int w=__builtin_ctz(t);
   if(pathdfs(w,used|(1u<<w),forbidden|a[last],len+1,target))return true;
  }return false;
 }
 bool haspath(int k)const{for(int v=0;v<n;++v)if(pathdfs(v,1u<<v,0,1,k))return true;return false;}
};
int main(){try{
 C c6all=0,c6girth=0,c6r4=0,c6r4p8free=0,singletonchecks=0;
 // Six nonempty contact classes, each of size 1 or 2, at most two doubled.
 for(int doubles=0;doubles<64;++doubles){if(__builtin_popcount((unsigned)doubles)>2)continue;
  std::vector<int>cls;int size[6];for(int i=0;i<6;++i){size[i]=1+((doubles>>i)&1);for(int j=0;j<size[i];++j)cls.push_back(i);}
  std::vector<std::pair<int,int>>possible;
  for(int u=0;u<(int)cls.size();++u)for(int v=u+1;v<(int)cls.size();++v){int d=(cls[u]-cls[v]+6)%6;if(d>=2&&d<=4)possible.push_back({6+u,6+v});}
  for(U mask=0;mask<(1u<<possible.size());++mask){++c6all;Graph g(6+cls.size());
   for(int i=0;i<6;++i)g.edge(i,(i+1)%6);
   for(int j=0;j<(int)cls.size();++j)g.edge(6+j,cls[j]);
   for(int j=0;j<(int)possible.size();++j)if(mask&(1u<<j))g.edge(possible[j].first,possible[j].second);
   if(!g.girth5())continue;++c6girth;if(g.radius()!=4)continue;++c6r4;
   if(g.haspath(8))continue;++c6r4p8free;need(2*g.edges()<=3*g.n,"Radius-four density failure");
   need(mask==0&&g.edges()==g.n,"Stronger radius-four characterization failure");
   for(auto [u,v]:possible)if(g.a[u]&(1u<<v)){
    int i=cls[u-6],j=cls[v-6];if((i-j+6)%6!=3){++singletonchecks;need(size[i]==1&&size[j]==1,"Diagonal singleton failure");}
   }
  }
 }
 // All legal one-vertex C8 contact sets, then all pairs and the exterior edge.
 std::vector<U>contact;for(U s=1;s<256;++s){Graph g(9);for(int i=0;i<8;++i){g.edge(i,(i+1)%8);if(s&(1u<<i))g.edge(i,8);}if(g.girth5())contact.push_back(s);}
 C c8all=0,c8girth=0,c8p8free=0;
 for(U s:contact)for(U t:contact)for(int linked=0;linked<2;++linked){++c8all;Graph g(10);
  for(int i=0;i<8;++i){g.edge(i,(i+1)%8);if(s&(1u<<i))g.edge(i,8);if(t&(1u<<i))g.edge(i,9);}
  if(linked)g.edge(8,9);if(!g.girth5())continue;++c8girth;if(g.haspath(8))continue;++c8p8free;need(g.radius()<=3,"Dominating C8 reduction failure");
 }
 C exceptional=0;for(int odd:{1,3,5}){Graph g(12);for(int i=0;i<6;++i){g.edge(i,(i+1)%6);g.edge(i,6+i);}
  g.edge(6,8);g.edge(6,10);for(int j:{1,3,5})if(j!=odd)g.edge(6+odd,6+j);
  for(int i=0;i<3;++i)g.edge(6+i,9+i);
  int cycle[4];if(odd==1){cycle[0]=6;cycle[1]=10;cycle[2]=7;cycle[3]=9;}else{cycle[0]=6;cycle[1]=8;cycle[2]=11;cycle[3]=9;}
  for(int j=0;j<4;++j)need(g.a[cycle[j]]&(1u<<cycle[(j+1)%4]),"Invalid exceptional C4 witness");++exceptional;
 }
 std::cout<<"{\n  \"status\": \"PASS\",\n  \"c6_candidates\": "<<c6all<<",\n  \"c6_girth5\": "<<c6girth<<",\n  \"c6_radius4\": "<<c6r4<<",\n  \"c6_radius4_p8free\": "<<c6r4p8free<<",\n  \"diagonal_singleton_checks\": "<<singletonchecks<<",\n  \"c8_legal_contact_sets\": "<<contact.size()<<",\n  \"c8_two_vertex_candidates\": "<<c8all<<",\n  \"c8_two_vertex_girth5\": "<<c8girth<<",\n  \"c8_two_vertex_p8free\": "<<c8p8free<<",\n  \"exceptional_c4_witnesses\": "<<exceptional<<"\n}\n";
 return 0;}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
