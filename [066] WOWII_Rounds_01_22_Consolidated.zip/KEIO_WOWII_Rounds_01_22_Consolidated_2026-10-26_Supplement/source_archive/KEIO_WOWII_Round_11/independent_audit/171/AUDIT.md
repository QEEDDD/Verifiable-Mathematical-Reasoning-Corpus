# Independent mathematical audit: counterexample to original WOWII171

**Verdict: PASS — the exact original mathematical assertion is false.**
The 407-vertex tree has actual maximum spanning-tree leaf number **53**,
while the claimed lower bound is **54**. This is a full counterexample to
the original numbered assertion, not merely a failed stronger variant.

**Priority/status gate is separate and pending this report:** this audit
does not certify that the counterexample or its family is previously
unpublished. The historical catalogue marker O is not proof of current
open status. Parent/source-audit approval is still required before any
novel-resolution claim.

Audited author files are frozen under
`round_10/leaves/171_counterexample/`, with copies in `snapshots/` here.
The Round11 placement of this report does not change their mathematical
content. Date: 26 October 2026.

## 1. Exact statement and definitions

The pinned original row 171, dated 8 August 2005, asserts for every simple
connected graph G that

    L_s(G) ≥ (max_v dist_even(v) − 1) / dist_avg(B).

It explicitly links definitions **1, 10, and 83**. The original row and
selected archived JavaScript definition entries are preserved in this
packet, together with their source-file hashes and the earlier retrieval
log. The archive log records a successful HTTP200 retrieval of the original
glossary from the Internet Archive, resolving to the 12 May 2024 capture.
Current direct web attempts during this audit timed out/failed; this is
not concealed as a successful fresh retrieval.

The relevant meanings are:

* Definition 1: L_s is the maximum number of degree-one vertices over all
  spanning trees, not an arbitrary chosen tree's leaf count.
* Definition 10: dist_even(v) counts vertices at even graph distance from
  v; zero is an even distance. The word “maximum” is over all roots.
* Definition 83: B consists of vertices of maximum eccentricity. The
  denominator averages nonzero distances whose **two endpoints both lie
  in B**, using graph distances in G.

Thus B is the periphery in modern terminology, not the collection of all
tree leaves or a different local-boundary notion. This is not the B-to-V
average (a separate definition) and not the average distance to a vertex
set. Ordered versus unordered distinct pairs give the same average.
Definition 23 in this archived numbering is average degree and is irrelevant
to row171; it must not replace definition83.

The independent pinned row and the author-provided row/glossary agree.
Source locators:
[pinned original-row transcription](https://gitlab.com/ai-village-agents/village/graffiti-verification/-/blob/3be380b4222f974bedbefb228c8e75fbd9a7b3ae/data/wow2_rows_html.json),
[archived original glossary](https://web.archive.org/web/20240512133636id_/http://cms.uhd.edu/faculty/delavinae/research/wowII/wowIIdefs.js).

## 2. Independent analytic check of the 407-vertex tree

Start at a center c. Attach a 14-edge stem ending at a, then attach 27
new leaves to a. Attach one further 15-edge path at c. Finally attach 25
further 14-edge paths at c. Apart from c and the explicitly shared a, all
new vertices are distinct. Adding paths/leaves at one existing vertex
preserves simplicity, connectivity, and acyclicity.

The order is 1+14+27+15+25·14=407 and the size is 406. A tree is its unique
spanning tree. Its leaves are the 27 leaves at a, the far endpoint q of
the 15-edge path, and the 25 shorter-arm endpoints. Therefore L_s=53
exactly; no optimization assumption is involved.

Every vertex lies within distance 15 of c. The 27 leaves at a are at
distance 30 from q, so the diameter is 30 and all 28 of those vertices
are peripheral. Every other vertex is within distance 14 of c and hence
within distance 29 of every vertex. Thus **only those 28 vertices belong
to B**. In particular the 25 shorter-arm leaves are not peripheral.

Among the peripheral unordered pairs, 351 pairs have distance two and
27 pairs have distance 30. Hence

    dist_avg(B) = (351·2 + 27·30) / 378 = 4.

In a tree, even-distance vertices are exactly the root's bipartition class.
The class containing c has 1+7+7+25·7=190 vertices; the other class has
217 vertices. Thus max_v dist_even(v)=217, attained at every vertex in
the larger class. The asserted inequality becomes

    53 ≥ (217−1)/4 = 54,

which is strictly false. Even if distance zero were excluded, the right
side would be 215/4=53.75, so the principal witness remains a counterexample.
The exact original interpretation nevertheless includes zero.

## 3. Infinite family and first frozen witness

Replacing the 25 shorter arms by k such arms gives

    n=57+14k,   L_s=k+28,   |B|=28,   dist_avg(B)=4,
    bipartition orders 15+7k and 42+7k.

The same periphery proof applies for every nonnegative k. The proposed
bound minus the actual leaf number is

    (41+7k)/4 − (k+28) = (3k−71)/4.

This is positive for every integer k≥24. The claimed infinite family is
therefore valid analytically. At k=24 the order is 393 and the violation
is 1/4; k=25 was chosen as the cleaner primary example because both sides
are integers and the zero-distance interpretation is immaterial to failure.

The independently frozen first witness (R,k,m)=(20,20,38) also passes:
n=458, size457, L_s=59, diameter40, periphery39, and maxEven=238. Its 741
peripheral pairs comprise 703 at distance2 and 38 at distance40, so the
average is 154/39. The proposed right side is 9243/154=59+157/154>59.

## 4. Independent exact computation

`check_independent.py` uses only the Python standard library. It imports
neither author code nor inferred eccentricities. It independently constructs
the graphs, checks simple symmetric adjacency and connectivity, verifies
the n−1 edge count, runs BFS from **every vertex**, computes all eccentricities,
extracts the actual maximum-eccentricity set, counts even distances from
every root, and averages the actual peripheral pair distances using exact
fractions. It separately checks ordered-pair averaging and compares to
the family formulas only after evaluating the graph invariants.

All three supplied author edge lists were additionally compared as edge
sets with the independently constructed graphs. They match exactly.

| Order | L_s | Diameter | Periphery | Average | MaxEven | Claimed RHS |
|---:|---:|---:|---:|---:|---:|---:|
| 393 | 52 | 30 | 28 | 4 | 210 | 209/4 |
| 407 | 53 | 30 | 28 | 4 | 217 | 54 |
| 458 | 59 | 40 | 39 | 154/39 | 238 | 9243/154 |

Complete edge sets, eccentricities, and even-distance counts are retained
in `independent_tree_393.json`, `independent_tree_407.json`, and
`independent_tree_458.json`. Reproduce from the workspace root:

```sh
python3 independent_audit/171/check_independent.py
```

The analytic construction already establishes the counterexample family;
finite BFS certification is an independent control, not an unproved search
assumption. **No mathematical gap or definition mismatch remains.** The
only external reporting gate not decided here is current priority/status.
