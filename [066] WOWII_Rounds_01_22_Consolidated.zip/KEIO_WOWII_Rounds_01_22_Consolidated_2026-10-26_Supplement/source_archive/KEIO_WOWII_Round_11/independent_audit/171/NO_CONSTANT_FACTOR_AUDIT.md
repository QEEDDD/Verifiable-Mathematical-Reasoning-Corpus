# Addendum audit: no fixed positive multiplicative repair of WOWII171

**Verdict: PASS.** This is an additional consequence of the already audited
counterexample construction, not another numbered conjecture closure.
The main 407-vertex audit is unchanged. Date: 26 October 2026.

Audited note: `round_10/leaves/171_counterexample/no_constant_factor_repair.md`,
preserved in `snapshots/`. Definitions are exactly those of the main audit:
maximum spanning-tree leaves, even distances including zero, and the average
of nonzero graph distances with both endpoints in the maximum-eccentricity
periphery.

## 1. The general odd-radius family

For odd R≥19, use the previous construction with k=R shorter arms and
m=2R−3 fan leaves: a length-(R−1) stem with m leaves at its far end,
one length-R opposite arm, and k further length-(R−1) arms at the common
center. The graph is a tree. Direct counts give

    n = R²+3R−3,                  L_s = 3R−2.

Exactly the fan leaves and the opposite long-arm endpoint have eccentricity
2R. Every other vertex has depth at most R−1 from the center and therefore
eccentricity at most 2R−1. The periphery calculation from the main proof
applies without change:

    dist_avg(B) = 2 + 4(R−1)/(m+1) = 4.

Because R is odd, the center's bipartition class has
R+R(R−1)/2=(R²+R)/2 vertices. The other class is larger by m and has
(R²+5R−6)/2 vertices. These are the exact even-distance counts according
to the root's bipartition class. Thus the original proposed lower bound is

    Q(R) = (R²+5R−8)/8,
    Q(R)−L_s = (R²−19R+8)/8.

The last expression is positive at R=19 and for every R≥19, because its
numerator is R(R−19)+8. No approximation is used.

## 2. Integer parameter and the quantified factor obstruction

Substituting R=8t+19 for integer t≥0 gives exactly

    n = 64t²+328t+415,
    L_s = 24t+55,
    maxEven = 32t²+172t+225,
    dist_avg(B) = 4,
    Q(t) = 8t²+43t+56,
    Q(t)−L_s = 8t²+19t+1.

All expansions and parity assumptions are correct. In particular Q(t) is
an integer; the rounding question does not arise. The ratio Q(t)/L_s grows
without bound, and the precise quantifier in the note follows. For example,

    Q(t)/L_s − t/3 = (74t+168)/(3(24t+55)) > 0.

Given **any fixed c>0**, choose an integer t>3/c. Then c·Q(t)>L_s, so
the proposed universal repair L_s≥c·Q fails on this tree. This also covers
arbitrarily small positive c. It does not claim failure for c=0, nor does
it address possible repairs whose factor depends on graph order or other
parameters. The obstruction is already within the class of trees.

## 3. Fresh independent all-pairs BFS controls

`check_no_constant_factor.py` imports only this auditor's earlier independent
graph/BFS routine, not author code. The invariants are recomputed from actual
graphs before comparison to the formulas. Four fresh controls passed:

| t | R | Order | L_s | MaxEven | Average | Q(t) | Q(t)−L_s |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 0 | 19 | 415 | 55 | 225 | 4 | 56 | 1 |
| 1 | 27 | 807 | 79 | 429 | 4 | 107 | 28 |
| 2 | 35 | 1327 | 103 | 697 | 4 | 174 | 71 |
| 3 | 43 | 1975 | 127 | 1029 | 4 | 257 | 130 |

The checker verifies connectivity, simplicity, the tree edge count, actual
eccentricities/periphery, ordered and unordered peripheral averages, every
root's even-distance count, and all displayed integer formulas. Exact
results and pair-distance histograms are retained in
`no_constant_factor_independent_results.json`.

Reproduce from the workspace root:

```sh
python3 independent_audit/171/check_no_constant_factor.py
```

The universal conclusion rests on the explicit analytic family and ratio
calculation, not these four controls. **No mathematical gap found.** As in
the main report, worldwide priority/current-status review is a separate
gate and is not certified by this addendum.
