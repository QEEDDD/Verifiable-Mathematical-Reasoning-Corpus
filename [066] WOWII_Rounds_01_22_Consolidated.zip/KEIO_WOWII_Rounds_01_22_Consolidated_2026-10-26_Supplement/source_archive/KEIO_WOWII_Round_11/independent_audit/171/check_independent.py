"""Independent exact WOWII171 counterexample check, standard library only.

No author construction/verifier is imported. Actual BFS distances, not the
closed-form family formulas, determine the invariants and periphery.
"""
from collections import Counter, deque
from fractions import Fraction
from pathlib import Path
import json


def build(radius, extra_arms, fan_leaves):
    adj = [[]]

    def add(parent):
        v = len(adj)
        adj.append([parent])
        adj[parent].append(v)
        return v

    v = 0
    for _ in range(radius - 1):
        v = add(v)
    left = [add(v) for _ in range(fan_leaves)]
    v = 0
    for _ in range(radius):
        v = add(v)
    right = v
    short_ends = []
    for _ in range(extra_arms):
        v = 0
        for _ in range(radius - 1):
            v = add(v)
        short_ends.append(v)
    return adj, left, right, short_ends


def verify(R, k, m):
    adj, left, right, short_ends = build(R, k, m)
    n = len(adj)
    edges = [(u, v) for u in range(n) for v in adj[u] if u < v]
    assert len(set(edges)) == len(edges) == n - 1
    assert all(u != v and u in adj[v] for u in range(n) for v in adj[u])
    distances = []
    for source in range(n):
        d = [-1] * n
        d[source] = 0
        queue = deque([source])
        while queue:
            u = queue.popleft()
            for v in adj[u]:
                if d[v] == -1:
                    d[v] = d[u] + 1
                    queue.append(v)
        assert min(d) == 0  # All vertices reached; connected and n-1 edges => tree.
        distances.append(d)
    assert all(distances[u][v] == distances[v][u] for u in range(n) for v in range(n))
    eccentricities = [max(d) for d in distances]
    diameter = max(eccentricities)
    periphery = [v for v in range(n) if eccentricities[v] == diameter]
    leaves = [v for v in range(n) if len(adj[v]) == 1]
    assert set(periphery) == set(left + [right])
    assert set(leaves) == set(left + [right] + short_ends)
    assert all(eccentricities[v] == diameter - 1 for v in short_ends)
    even = [sum(distance % 2 == 0 for distance in d) for d in distances]
    pairs = [distances[u][v] for i, u in enumerate(periphery) for v in periphery[i + 1 :]]
    assert all(pairs)
    average = Fraction(sum(pairs), len(pairs))
    # Independently evaluate ordered pairs too: orientation cannot alter the average.
    ordered = [distances[u][v] for u in periphery for v in periphery if u != v]
    assert average == Fraction(sum(ordered), len(ordered))
    L = len(leaves)  # A tree is its only spanning tree.
    rhs = Fraction(max(even) - 1, 1) / average
    assert L < rhs
    assert L * average < max(even) - 1
    # Compare computed values to analytic family formulas only after computing them.
    assert n == 2 * R + m + k * (R - 1)
    assert L == m + k + 1
    assert average == 2 + Fraction(4 * (R - 1), m + 1)
    result = {
        "parameters": {"R": R, "k": k, "m": m},
        "n": n, "edges_count": len(edges), "connected_simple_tree": True,
        "L_s": L, "radius": min(eccentricities), "diameter": diameter,
        "periphery_size": len(periphery), "periphery": periphery,
        "all_tree_leaves": leaves,
        "short_arm_end_eccentricities": [eccentricities[v] for v in short_ends],
        "periphery_unordered_pair_count": len(pairs),
        "periphery_unordered_pair_distance_sum": sum(pairs),
        "periphery_pair_distance_histogram": dict(sorted(Counter(pairs).items())),
        "periphery_pair_average": str(average),
        "even_count_histogram": dict(sorted(Counter(even).items())),
        "maximum_even_distance_count": max(even),
        "claimed_lower_bound_rhs": str(rhs),
        "rhs_minus_actual_L_s": str(rhs - L),
        "L_s_times_average": str(L * average),
        "maximum_even_minus_one": max(even) - 1,
        "conjecture171_holds": False,
        "edges": edges,
        "eccentricities": eccentricities,
        "even_distance_counts": even,
    }
    return result


if __name__ == "__main__":
    directory = Path(__file__).parent
    results = []
    for parameters in [(20, 20, 38), (15, 25, 27), (15, 24, 27)]:
        result = verify(*parameters)
        path = directory / f"independent_tree_{result['n']}.json"
        path.write_text(json.dumps(result, indent=2) + "\n")
        results.append({k: v for k, v in result.items() if k not in
                        {"edges", "eccentricities", "even_distance_counts",
                         "periphery", "all_tree_leaves", "short_arm_end_eccentricities"}})
    summary = {"status": "PASS_THREE_EXACT_COUNTEREXAMPLES", "results": results,
               "source_priority_gate": "Separate; not certified by this checker"}
    (directory / "independent_results.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))
