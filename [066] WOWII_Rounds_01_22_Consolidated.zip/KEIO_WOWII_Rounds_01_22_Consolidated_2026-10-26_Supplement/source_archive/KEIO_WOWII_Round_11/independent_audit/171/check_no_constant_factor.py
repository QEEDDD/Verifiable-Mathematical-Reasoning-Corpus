"""Fresh exact BFS controls for the no-fixed-positive-factor family.
Reuses only this auditor's independently written BFS graph verifier.
"""
from fractions import Fraction
from pathlib import Path
import json
from check_independent import verify

rows = []
for t in range(4):
    R = 8 * t + 19
    result = verify(R, R, 2 * R - 3)
    assert result["n"] == 64 * t * t + 328 * t + 415
    assert result["L_s"] == 24 * t + 55
    assert result["maximum_even_distance_count"] == 32 * t * t + 172 * t + 225
    assert Fraction(result["periphery_pair_average"]) == 4
    rhs = Fraction(result["claimed_lower_bound_rhs"])
    assert rhs == 8 * t * t + 43 * t + 56
    assert rhs - result["L_s"] == 8 * t * t + 19 * t + 1
    assert rhs / result["L_s"] >= Fraction(t, 3)
    rows.append({
        "t": t, "R": R, "n": result["n"],
        "edges": result["edges_count"], "L_s": result["L_s"],
        "radius": result["radius"], "diameter": result["diameter"],
        "periphery_size": result["periphery_size"],
        "periphery_pair_distance_histogram": result["periphery_pair_distance_histogram"],
        "periphery_pair_average": result["periphery_pair_average"],
        "maximum_even_distance_count": result["maximum_even_distance_count"],
        "RHS": str(rhs), "RHS_minus_L_s": str(rhs - result["L_s"]),
        "RHS_over_L_s": str(rhs / result["L_s"]),
    })
out = {"status": "PASS", "method": "Actual all-pairs BFS, exact fractions", "cases": rows}
Path(__file__).with_name("no_constant_factor_independent_results.json").write_text(json.dumps(out, indent=2) + "\n")
print(json.dumps(out, indent=2))
