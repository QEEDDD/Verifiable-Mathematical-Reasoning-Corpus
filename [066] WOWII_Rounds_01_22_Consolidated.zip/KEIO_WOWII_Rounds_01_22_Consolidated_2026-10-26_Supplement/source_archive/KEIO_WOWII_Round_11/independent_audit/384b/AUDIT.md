# Independent audit of the certified h=10 case of WOWII384b

**Verdict: PASS — computer-assisted partial theorem, not a full closure.**
26 October 2026.

Authoritative candidate: `round_11/twodomination/manuscript.tex` and
`384b_h10_certified.md`, preserved with the author checker/results in
`snapshots/`. Every connected simple graph with exactly ten vertices of
degree at least three satisfies the stated WOWII384b inequality. Together
with prior audited results, h≤10 and h≥43 are excluded from counterexamples;
the remaining high orders are 11–42. The representative-order bound remains
43. No exhaustive graph search through order 43 or full conjecture closure
is claimed.

The new even-cubic lemma is an **essential, fully checked input** here, not
merely the optional filter recorded in Round10. Neither the canonicalization
generator nor the author's attachment fallback is trusted by this audit.

## 1. Counterexample profile and even maximum-cut stability

Let k=n−γ₂ be the maximum cardinality of a vertex set each of whose vertices
has at least two neighbors outside the set. Such a set is called omittable.
The target is t≤2k, where t counts distinct triangle-incidence values. The
equivalence to the displayed floor inequality is exact, including odd t.

A maximum cut gives at least two crossing neighbors at every high vertex,
so either high side is omittable. Hence k≥ceil(h/2). Low vertices have
triangle count zero or one, giving t≤h+2. For an even-h counterexample these
facts force h=2k and t≥h+1. Consequently at least h−1 high vertices have
distinct triangle counts at least two.

Every maximum cut has exactly k high vertices on either side; otherwise
one high side is an omission set larger than k. An equal crossing/noncrossing
degree at a high vertex would allow a cut-preserving flip, unbalancing those
high sides. Thus the crossing majority is strict.

A degree-two vertex cannot have two crossing neighbors: adding it to its
high side preserves all of that side's crossing-neighbor guarantees and
produces k+1 omissions. Its crossing degree is therefore exactly one, and
it may be flipped preserving maximum cut size. Such a flip rules out a leaf
neighbor (which would have zero crossing neighbors) and a degree-two neighbor
(which would acquire zero or two crossing neighbors). Its two neighbors are
therefore high vertices on opposite high sides.

If a high vertex v is incident with two degree-two vertices x,y, replace
v in its high-side omission set by x,y. Their two high neighbors are now
selected, and no other omitted vertex on v's high side is adjacent to x or y.
This gives k+1 omissions. Thus the pairs of high endpoints of all degree-two
vertices form a simple matching, including exclusion of repeated pairs.
This establishes all universal claims in Lemma 1.

## 2. Essential cubic-existence lemma

Assume an even-high-order counterexample has no high vertex of degree three.
Strict crossing majority then gives at least three crossing neighbors at
every high vertex. Write A,B for the high sides of a maximum cut. If v∈B
has two neighbors outside A, A∪{v} is omittable: each old member of A loses
at most the selected neighbor v and keeps two of its three crossing
neighbors; v has its assumed two selected neighbors. The same applies with
the sides reversed. Therefore each high vertex has at most one neighbor
among all low vertices and its same-side high vertices combined.

The same-side high graphs are matchings. A vertex with a same-side high
mate has no low neighbor; triangles through it consist of at most k
mate/opposite-side choices and at most floor(k/2) opposite matching edges.
A vertex without a same-side mate has at most floor(k/2) triangles using
two opposite high neighbors and at most one further triangle involving its
sole possible low neighbor. The latter bound uses the already established
degree-two structure; a leaf contributes no triangle.

For k≥2 all high triangle counts are consequently at most k+floor(k/2),
and the low counts are at most one. The total number of distinct integer
values is at most k+floor(k/2)+1≤2k, a contradiction. For k=1 all counts
are at most one. The k=0 profile cannot be a connected counterexample of
order greater than two, since a connected graph of that order has a vertex
of degree at least two and hence at least one omission. Thus every even-h
counterexample has a degree-three high vertex. In particular an h=10
counterexample can label such a vertex last and its core degree is at most
three. No hidden minimum-core-degree hypothesis is used.

## 3. Necessary triangle filter and omission transfer

The low structure shows that triangles outside the high core can only use
one degree-two vertex on a core edge. Since their root pairs form a matching,
each high triangle count is its core count plus zero or one. For h=10,
nine selected high vertices must have distinct final counts at least two.

The author's sorted greedy filter is safe. Over strictly increasing base
values, an inverted final assignment is impossible with offsets in {0,1};
equal bases can exchange assignments. The greedy increasing assignment,
starting above one, is componentwise no larger than any sorted feasible
assignment. Its success is only a necessary condition, as intended; no
claim of realizability by actual matching attachments is made.

This audit deliberately uses a different filter: maximum bipartite matching
between the ten vertices and their available final counts {a_v,a_v+1}∩[2,∞).
A matching of size at least nine is exactly the required necessary
distinct-value condition, without sorting or the greedy proof. It returns
the same survivor count on the complete tested domain.

For a high-only omission set R, all low vertices remain selected. Its
selected-neighbor count at u is d_G(u)−|N_H(u)∩R|, bounded below by
max(3,d_H(u))−|N_H(u)∩R|. Thus the displayed certificate condition transfers
to every actual graph with that core, regardless of additional selected
low neighbors or attachments. The checker need only find six omissions:
omittability is hereditary under taking subsets, so searching exactly six
loses no larger witness. No condition on outside vertices is needed in
2-domination; only omitted vertices require two selected neighbors.

## 4. Coverage chain independently re-established

The coverage inputs are jointly bundled in `round_11/twodomination/` and
pinned in this audit's `COVERAGE_INPUT_HASHES.txt`. Disconnected cores are
included throughout.

1. The separate seven/eight-core audit program was rerun. All 2,097,152
   labeled seven-vertex graphs are marked by 5,261,760 permutation images
   of the 1,044 supplied seven-core masks.
2. All 133,632 eighth-vertex extensions have independently checked bijections
   into the 12,346 eight-core masks. Exact certificate length is checked.
3. A new independent inverse-permutation verifier validates every one of
   the 3,160,576 ninth-vertex extensions against the 274,668 supplied masks.
   It checks input ranges, unique targets, all nine permutation entries,
   inverse bijectivity, all edge/nonedge positions, upper unused record
   bits, end-of-file parsing, and exact consumption of 25,284,608 bytes.
   It does not invoke any canonicalizer.
4. After deleting a chosen cubic high vertex, every remaining nine-core
   maps to a supplied mask. Restoring that vertex needs one of precisely
   1+9+36+84=130 neighborhoods of size at most three. All are enumerated.

Thus the finite domain covers every putative h=10 counterexample. There is
no need to assume that the representative sets are nonredundant or that
the external generation algorithm is correct.

## 5. Independent finite implementation and results

`check_h10_independent.cpp` differs from the author implementation in the
substantive operations:

* Triangle counts start from direct nine-core vertex triples. Each restored
  vertex adds the triangles determined by adjacent pairs in its neighborhood.
* Offset feasibility uses maximum matching rather than sorted greedy.
  Results are cached on 383,134 complete base-count signatures.
* The guaranteed degree deficit is realized by distinct explicit selected
  leaves in a physical adjacency-bitset graph. These are a certificate device,
  not an assertion that the actual graph has such leaves.
* Every four-element selected high set is available for search; its complement
  is the six-element omission set. Each witness is checked by counting actual
  selected neighbors in the materialized graph.

Results:

| Item | Count |
|---|---:|
| Covered nine-core masks | 274,668 |
| Cubic-labeled ten-core extensions | 35,706,840 |
| Matching-feasible count profiles | 3,971,627 |
| Explicit valid six-high omission witnesses | 3,971,627 |
| Four-selected-high witness trials | 49,575,773 |
| Explicit selected-leaf padding occurrences | 2,439,783 |
| Attachment cases used / unresolved cases | 0 / 0 |

Every potential counterexample survives the necessary filter and then has
at least six omissions, contradicting k=5. This proves the stated h=10
partial theorem by the supplied finite certificate computation. The author's
fallback attachment branch is not part of the accepted proof and need not
be trusted, because this independent computation never needs attachments.

As additional controls of the universal lemmas,
`check_even_cubic_independent.cpp` tested all 274,668 supplied nine-vertex
graphs. There are 261,080 connected graphs and 113,034 with positive even
high order. Exactly 353 have tight even omission bound; all 609 maximum
cuts of these graphs satisfy the high-side and strict-majority conditions.
The degree-two matching condition passes. Three tight graphs have no cubic
high vertex; all satisfy the local triangle caps and global noncounterexample
bound. These finite controls supplement, not replace, Sections 1–2.

## 6. Reproduction and exact scope

From the workspace root:

```sh
d=independent_audit/384b
s=verification/384b
g++ -O3 -std=c++17 "$d/check_coverage7_8_independent.cpp" -o /tmp/audit_cov78
/tmp/audit_cov78 "$s/core7_masks.txt" "$s/core8_masks.txt" "$s/core8_cover_permutations.bin"
g++ -O3 -std=c++17 "$d/check_coverage9_independent.cpp" -o /tmp/audit_cov9
/tmp/audit_cov9 "$s/core8_masks.txt" "$s/core9_masks.txt" "$s/core9_cover_permutations.bin"
g++ -O3 -std=c++17 "$d/check_h10_independent.cpp" -o /tmp/audit_h10
/tmp/audit_h10 "$s/core9_masks.txt"
g++ -O3 -std=c++17 "$d/check_even_cubic_independent.cpp" -o /tmp/audit_cubic
/tmp/audit_cubic "$s/core9_masks.txt"
```

**No unresolved mathematical or coverage gap was found.** Acceptance is
an ordinary computer-assisted proof with explicit inspectable source and
verified finite inputs, not a formal proof-assistant certificate. Worldwide
priority, the exploratory 382e files, and full WOWII384b closure are outside
this verdict. The earlier order-43 reduction remains a separate, previously
audited partial theorem and is not strengthened by this h=10 computation.
