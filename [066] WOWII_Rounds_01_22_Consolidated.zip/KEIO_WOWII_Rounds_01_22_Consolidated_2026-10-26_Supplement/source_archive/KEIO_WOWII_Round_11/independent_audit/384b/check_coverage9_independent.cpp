// Inverse-permutation verifier; no canonicalization or author code used.
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <unordered_set>
#include <vector>
using W=std::uint64_t;using U=unsigned;
void need(bool b,const char*s){if(!b)throw std::runtime_error(s);}
std::vector<W> masks(const char*path,int bits){std::ifstream f(path);need(bool(f),"Missing mask file");std::vector<W>r;W x;
 while(f>>x){need(x<(W(1)<<bits),"Mask out of range");r.push_back(x);}need(f.eof()&&!r.empty(),"Malformed/empty mask file");return r;
}
int main(int argc,char**argv){try{need(argc==4,"usage: core8 core9 permutations");auto src=masks(argv[1],28),dst=masks(argv[2],36);
 std::unordered_set<W>targets(dst.begin(),dst.end());need(targets.size()==dst.size(),"Duplicate target mask");
 std::ifstream f(argv[3],std::ios::binary);need(bool(f),"Missing certificate");W count=0;
 for(W m:src){std::array<U,9>core{};int bit=0;for(int i=0;i<8;++i)for(int j=i+1;j<8;++j,++bit)if(m&(W(1)<<bit)){core[i]|=1u<<j;core[j]|=1u<<i;}
  for(U hood=0;hood<256;++hood){auto a=core;a[8]=hood;for(int i=0;i<8;++i)if(hood&(1u<<i))a[i]|=256;
   W code=0;for(int byte=0;byte<8;++byte){int c=f.get();need(c!=EOF,"Truncated certificate");code|=W(c)<<(8*byte);}need(code<(W(1)<<36),"Extra bits in permutation record");
   std::array<int,9>inverse;inverse.fill(-1);for(int old=0;old<9;++old){int now=(code>>(4*old))&15;need(now<9&&inverse[now]<0,"Permutation not bijective");inverse[now]=old;}
   W image=0;bit=0;for(int i=0;i<9;++i)for(int j=i+1;j<9;++j,++bit)if(a[inverse[i]]&(1u<<inverse[j]))image|=W(1)<<bit;
   need(targets.count(image),"Image absent from targets");++count;
  }
 }need(f.get()==EOF,"Trailing certificate bytes");
 std::cout<<"{\"status\":\"PASS\",\"source_eight_masks\":"<<src.size()<<",\"nine_target_masks\":"<<dst.size()<<",\"explicit_inverse_permutations_verified\":"<<count<<",\"certificate_bytes\":"<<count*8<<",\"canonicalizer_trusted\":false}\n";
 return 0;}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
