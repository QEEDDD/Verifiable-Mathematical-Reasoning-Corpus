// Finite controls of the essential universal even-cut/cubic proof.
// Every supplied 9-vertex graph is tested directly; isomorphism coverage
// is established separately. This is not the universal proof itself.
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <vector>
using U=unsigned;using W=std::uint64_t;
void need(bool b,const char*s){if(!b)throw std::runtime_error(s);}
int pc(U x){return __builtin_popcount(x);}
int main(int argc,char**argv){try{need(argc==2,"usage: core9 masks");std::ifstream f(argv[1]);need(bool(f),"Missing input");
 std::array<std::vector<U>,10>sub;for(U s=0;s<512;++s)sub[pc(s)].push_back(s);
 W m,graphs=0,connected=0,even=0,tight=0,cuts=0,nocubic=0,nocubiccuts=0;
 while(f>>m){need(m<(W(1)<<36),"Bad mask");++graphs;std::array<U,9>a{};int bit=0;for(int u=0;u<9;++u)for(int v=u+1;v<9;++v,++bit)if(m&(W(1)<<bit)){a[u]|=1u<<v;a[v]|=1u<<u;}
  U seen=1,old=0;while(seen!=old){old=seen;for(int u=0;u<9;++u)if(old&(1u<<u))seen|=a[u];}if(seen!=511)continue;++connected;
  U high=0;bool cubic=false;for(int u=0;u<9;++u){int d=pc(a[u]);if(d>=3)high|=1u<<u;if(d==3)cubic=true;}int h=pc(high);if(!h||h%2)continue;++even;int k=h/2;
  bool bigger=false;for(U s:sub[k+1]){bool ok=true;for(U z=s;z;z&=z-1)if(pc(a[__builtin_ctz(z)]&~s)<2){ok=false;break;}if(ok){bigger=true;break;}}
  if(bigger)continue;++tight;if(!cubic)++nocubic;
  U low=511^high,usedRoots=0;for(int u=0;u<9;++u)if(pc(a[u])==2){need((a[u]&high)==a[u],"D2 has a low neighbor");need(!(a[u]&usedRoots),"D2 root pairs not a matching");usedRoots|=a[u];}
  int maxcut=-1;std::vector<U>best;for(U s=0;s<256;++s){int e=0;for(U z=s;z;z&=z-1)e+=pc(a[__builtin_ctz(z)]&~s);if(e>maxcut){maxcut=e;best.clear();}if(e==maxcut)best.push_back(s);}
  std::array<int,9>tri{};for(int u=0;u<9;++u)for(int v=u+1;v<9;++v)for(int w=v+1;w<9;++w)if((a[u]&(1u<<v))&&(a[u]&(1u<<w))&&(a[v]&(1u<<w))){++tri[u];++tri[v];++tri[w];}
  W values=0;for(int x:tri)values|=W(1)<<x;if(!cubic)need(__builtin_popcountll(values)<=2*k,"No-cubic triangle count violates conclusion");
  for(U s:best){++cuts;need(pc(s&high)==k,"Unbalanced maximum-cut high sides");if(!cubic)++nocubiccuts;
   for(int u=0;u<9;++u)if(high&(1u<<u)){U same=(s&(1u<<u))?s:(511^s);int crossing=pc(a[u]&~same);need(2*crossing>pc(a[u]),"High crossing majority not strict");
    if(!cubic){need(pc(a[u]&((same&high)|low))<=1,"No-cubic augmentation constraint failed");need(tri[u]<=k+k/2,"No-cubic local triangle cap failed");}
   }
  }
 }
 need(f.eof()&&graphs,"Malformed masks");std::cout<<"{\"status\":\"PASS\",\"nine_graphs\":"<<graphs<<",\"connected\":"<<connected<<",\"positive_even_high_order\":"<<even<<",\"even_tight_graphs\":"<<tight<<",\"maximum_cuts_checked\":"<<cuts<<",\"tight_without_cubic\":"<<nocubic<<",\"maximum_cuts_without_cubic\":"<<nocubiccuts<<"}\n";return 0;
 }catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
