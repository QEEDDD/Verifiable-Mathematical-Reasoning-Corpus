// Independent h10 verification: direct triangle triples; exact bipartite
// matching for offset feasibility; physical selected-leaf-padded kernels;
// enumerate four SELECTED high vertices, leaving exactly six omissions.
#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <functional>
#include <iostream>
#include <stdexcept>
#include <unordered_map>
#include <unordered_set>
#include <vector>
using U=unsigned;using W=std::uint64_t;
void need(bool b,const char*s){if(!b)throw std::runtime_error(s);}
std::unordered_map<W,bool>cache;W signatures=0,tests=0,padded=0;
bool feasible(std::array<int,10> t){std::sort(t.begin(),t.end());W key=0;for(int i=0;i<10;++i)key|=W(t[i])<<(6*i);
 auto it=cache.find(key);if(it!=cache.end())return it->second;++signatures;
 // Maximum matching from the ten vertices to their legal final values.
 // A matching of size >=9 directly certifies some exceptional vertex.
 std::array<int,40>owner;owner.fill(-1);int cardinality=0;
 // Use an explicit function object so no sorted-greedy assumption is needed.
 std::function<bool(int,W&)>go=[&](int v,W&seen){for(int y=t[v];y<=t[v]+1;++y){if(y<2)continue;need(y<40,"Unexpected triangle count");if(seen&(W(1)<<y))continue;seen|=W(1)<<y;
   if(owner[y]<0||go(owner[y],seen)){owner[y]=v;return true;}}
  return false;};
 for(int v=0;v<10;++v){W seen=0;if(go(v,seen))++cardinality;}
 bool yes=cardinality>=9;cache.emplace(key,yes);return yes;
}
int main(int argc,char**argv){try{need(argc==2,"usage: core9 masks");std::ifstream f(argv[1]);need(bool(f),"Missing masks");
 std::vector<U>selected;for(U s=0;s<1024;++s)if(__builtin_popcount(s)==4)selected.push_back(s);
 W sources=0,cores=0,compatible=0,verified=0;std::unordered_set<W>unique;W mask;
 while(f>>mask){need(mask<(W(1)<<36),"Mask out of range");need(unique.insert(mask).second,"Duplicate nine-core");++sources;
  std::array<U,10>base{};int bit=0;for(int u=0;u<9;++u)for(int v=u+1;v<9;++v,++bit)if(mask&(W(1)<<bit)){base[u]|=1u<<v;base[v]|=1u<<u;}
  std::array<int,10>tri{};for(int u=0;u<9;++u)for(int v=u+1;v<9;++v)for(int w=v+1;w<9;++w)
   if((base[u]&(1u<<v))&&(base[u]&(1u<<w))&&(base[v]&(1u<<w))){++tri[u];++tri[v];++tri[w];}
  for(U hood=0;hood<512;++hood){if(__builtin_popcount(hood)>3)continue;++cores;auto a=base;auto t=tri;a[9]=hood;
   for(int u=0;u<9;++u)if(hood&(1u<<u)){a[u]|=512;for(int v=u+1;v<9;++v)if((hood&(1u<<v))&&(base[u]&(1u<<v))){++t[u];++t[v];++t[9];}}
   if(!feasible(t))continue;++compatible;
   // Materialize distinct selected leaves only for the guaranteed degree
   // shortfall. These are proof aids, not assumed leaves of the actual G.
   std::vector<W>g(10);for(int u=0;u<10;++u)g[u]=a[u];
   for(int u=0;u<10;++u)while(__builtin_popcountll(g[u])<3){int v=g.size();need(v<64,"Too many padding vertices");g.push_back(W(1)<<u);g[u]|=W(1)<<v;++padded;}
   bool found=false;for(U s:selected){++tests;W omitted=1023u^s;bool valid=true;
    for(U scan=omitted;scan;scan&=scan-1){int u=__builtin_ctz(scan);if(__builtin_popcountll(g[u]&~omitted)<2){valid=false;break;}}
    if(valid){found=true;break;}
   }need(found,"No six-high omission certificate");++verified;
  }
  if(sources%50000==0)std::cerr<<"nine cores "<<sources<<", ten extensions "<<cores<<", verified "<<verified<<'\n';
 }
 need(f.eof()&&sources>0,"Malformed/empty input");
 std::cout<<"{\"status\":\"PASS\",\"nine_core_masks\":"<<sources<<",\"ten_core_extensions\":"<<cores<<",\"offset_compatible_matching\":"<<compatible<<",\"base_signatures\":"<<signatures<<",\"explicit_six_high_witnesses\":"<<verified<<",\"selected_four_trials\":"<<tests<<",\"selected_leaf_padding_occurrences\":"<<padded<<",\"attachment_cases_used\":0,\"unresolved\":0}\n";
 return 0;}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
