# Source and scope note: Round11 partial work on original WOWII133

26 October 2026. This note records a bounded review, not a certification of worldwide priority.

## Exact mathematical scope

The independently reviewed conclusions are:

1. Every connected graph of girth at least five with no induced P7 has average degree at most three; the inequality is strict if an induced C7 occurs.
2. Every connected graph of girth at least five with radius four and no induced P8 is C8, or C6 with a nonempty leaf set at every cycle vertex. Both families satisfy m=n.
3. Original WOWII133 consequently holds for all triangle-free graphs with unrounded average local independence ell≤4.

These are partials. They do not close original133 for graphs with triangles or arbitrary ell. The exact original uses induced-path **vertex order**, unrounded average local independence, and exclusion of C4 as a **subgraph**, not merely induced C4. The four-cycle-present branch is the immediate p≥r+1 inequality.

## Credited inputs and neighboring prior results

- Erdős–Saks–Sós (1986), *Maximum induced trees in graphs*, SectionII, printed pp64–65: p≥2r−1, with credit to Fan Chung. [Primary DOI](https://doi.org/10.1016/0095-8956(86)90028-6).
- Van ’t Hof–Paulusma (2010), *A new characterization of P6-free graphs*, Theorem6: a connected P6-free graph has a dominating induced C6 or a dominating complete bipartite subgraph, the latter not necessarily induced. [Primary manuscript](https://pimvanthof.github.io/p6free.pdf). The paper's C4 convention is induced; our use explicitly has the stronger noninduced exclusion.
- Camby–Schaudt (2016), *A new characterization of P_k-free graphs*, Theorem5 in [arXiv1402.7213v1](https://arxiv.org/abs/1402.7213v1): a connected P8-free graph has a connected dominating induced subgraph that is P6-free or C8. [Journal DOI](https://doi.org/10.1007/s00453-015-9989-6). Local audit PDF SHA256: efbd17f630b10bad4ebab4753f84911589b89fd9aaed06998e4f29d7d9575134.
- **Jian Song**, not Huang, *Graph Colouring with Input Restrictions*, Durham PhD thesis (2013), Theorem2.4.1, printed pp69–71, proves three-colorability of P7-free girth-five graphs. The complete relevant proof was read. It first peels degree≤2 vertices, then works under minimum degree≥3 and uses layers from a fixed edge. It does not state an average-degree theorem, and its peeling step does not preserve the desired bound 2m≤3n. Full-PDF text search found no occurrence of “average degree.” The chapter credits Golovach–Paulusma–Song, *Coloring graphs without short cycles and long induced paths*, FCT2011, LNCS6914, pp193–204. [Primary thesis](https://etheses.durham.ac.uk/id/eprint/6998/1/thesis_jiansong.pdf).
- Chudnovsky–Stacho, *3-colorable subclasses of P8-free graphs*, author manuscript dated 1 October2017, Theorem1, classifies the minimum-degree-at-least-three exceptions: Petersen, Heawood, and contracted Heawood. This does not directly give the P7 average-degree theorem. Its contracted-Heawood graph (n13,m20,r2,p7) disproves the tempting unrestricted P8-free average-degree≤3 extension. [Primary manuscript](https://web.math.princeton.edu/~mchudnov/p8free1.pdf).

## Review limits

The new P7 density proof is self-contained and does not use the preceding coloring classifications. The radius-four classification explicitly depends on Camby–Schaudt and the P6-radius input. Current bounded searches have not located an exact earlier statement of these partial conclusions, but this is not a novelty certificate. Do not report any full WOWII133 closure or worldwide-first theorem.

External full papers in local source directories are audit material only, not part of the distributed manuscript package unless redistribution is separately licensed. Reproducible checks and the English proof files are our own deliverables.
