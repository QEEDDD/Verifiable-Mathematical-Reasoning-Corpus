# WOWII 171 — source and bounded current-priority gate

**Checked 26 October 2026, 04:07 UTC. Outcome: no prior full resolution or equivalent counterfamily was located in the sources examined.** The proposed counterexample matches the recovered original formula and definitions. This permits a source-scoped report of a counterexample, **not** a worldwide first-priority claim, a current curator certification, or a claim that the underlying tree construction is new. Mathematical verification is recorded separately by the author, root and independent auditor.

## Exact source interpretation

The archived row 171, dated 8 August 2005, states

`L_s(G) >= (max_v dist_even(v)-1) / dist_avg(B)`.

The row links definitions **1, 10, 83**. Original definition 83 specifies the maximum-eccentricity set B and the average of all **nonzero distances between two vertices of B**. This is the internal peripheral-pair average. It is neither distance from B to all vertices (definition 95) nor distance to the set B (definition 109). Definition 10 counts all even distances and therefore includes distance zero. Definition 1 is the maximum spanning-tree leaf count. The 407-vertex tree has a nonempty positive denominator, so singleton/zero-denominator conventions are irrelevant. Exact source excerpts and URLs are in `statement_171.json`.

Pinned original transcription: https://gitlab.com/ai-village-agents/village/graffiti-verification/-/blob/3be380b4222f974bedbefb228c8e75fbd9a7b3ae/data/wow2_rows_html.json . Original glossary snapshot: https://web.archive.org/web/20240512133636id_/http://cms.uhd.edu/faculty/delavinae/research/wowII/wowIIdefs.js . The historical O marker alone is not current evidence of unresolved status.

## Current public records checked

- **GitLab graffiti-verification:** a fresh API check reports unchanged head `e4f890b23a62ed8086269e52afee684db86755b3`, committed 23 October 2026. The cached README/ledger at this head contains no counted WOWII 171 resolution. A mention in §7fb concerns bounded sanity testing of 171 alongside several other entries, not a proof. Several occurrences of “171” are standing counts, numerical values or WOW-I material, not this target. The README's assertion that an O-labelled conjecture cannot fail below a certain order is not accepted as a mathematical or current-status guarantee.
- **Kuberwastaken/c5-k4:** freshly retrieved head `e2cee93231eefb91c41e35450f7eeb19fd9c8c75`, committed 18 October 2026; complete recursive tree (`truncated=false`), current README, and current `data/wowii-conjectures.json` checked. Entry 171 remains a transcription labelled “open”, whose explicit evidence is only the old O marker and August 2005 note. It has no linked Lean file. No 171-specific proof path or README resolution was found. Neighbouring 172/176 concern a two-triangle dumbbell and different formulas, not 171. This is secondary source-scoped evidence, not an independent curator decision.
- **All-state public issues/PRs:** checked the cached 188-hit WOWII inventory, including unmerged records, plus fresh exact phrase and repository-scoped queries. `"WOWII 171"`, `"Graffiti.pc 171"`, `"Written on the Wall II" "171"`, and the c5-k4/agentic-conjectures 171 searches returned zero relevant claims. Exact phrase queries used `in:title,body`; generic numeric issue-number hits were rejected as noise. Query receipts are in `focused_query_summary.json` and `retrieval_audit.json`.

## Closest public counterexamples are different targets

1. **Gebendorfer, WOWII 363**, issue 7360, created 15 October 2026: https://github.com/google-deepmind/formal-conjectures/issues/7360 . The body gives the complete tree family and resolves a total-domination inequality with average positive **distance to the set** B, explicitly definition 109. Its periphery has two vertices. It neither claims 171 nor uses the 171 denominator. The body was read, not merely its title.
2. **Gebendorfer, WOWII 373**, manuscript dated 13 October 2026; issue 7306 created 14 October: https://github.com/google-deepmind/formal-conjectures/issues/7306 . Both the full cached primary manuscript and issue body were inspected. They concern `gamma_t >= (2/3) dist_avg(B,V)`, definition 95, with a long path and three pendant-leaf groups. They do not state 171 or the current long-arm tree family. Distinguishing these conclusions does not assert that using peripheral/nonperipheral leaves as a construction idea is new.
3. **DeLaViña–Waller**, *Spanning Trees with Many Leaves and Average Distance*, Electronic Journal of Combinatorics 15 (2008), R33, https://doi.org/10.37236/757 : the cached primary paper was inspected. Its leaf/independence/bipartite-order bounds and average-distance results do not provide the 171 refutation. Its boundary-to-all-vertices expression differs from definition 83.
4. **Kahsay–Narayankar**, *Peripheral Wiener Index of Graph Operations*, Bulletin of the International Mathematical Virtual Institute 9 (2019), 591–598, https://doi.org/10.7251/BIMVI1903591K : the primary journal paper defines the peripheral-pair distance sum and studies standard graph operations. It supplies relevant terminology, not a 171 statement or the parity/leaf-count counterexample.

Focused web searches included exact target identifiers, the formula terms, leaf number with peripheral average distance, boundary vertices with even distance, and peripheral Wiener index. No exact prior full resolution was found. Search absence is not a proof of worldwide novelty or of absence from unindexed/private work.

## Access limitation — not silently resolved

Fresh requests to the original catalogue on HTTP, HTTPS and its old `cms.dt.uh.edu` host returned HTTP 503. A separate web-tool request timed out; the known July 2026 Wayback open-list URL was inaccessible through that tool. Consequently **the latest live curator annotation could not be read**. The original wording is instead supported by the already pinned original HTML/JavaScript archive, consistent with the freshly read current transcription. No current-live-page status claim is made.

**Recommended release wording:** “The verified tree refutes WOWII 171 under the recovered original definitions. A bounded check of public repositories, unmerged issues/PRs and related literature found no earlier resolution; worldwide priority and the latest live catalogue annotation are not certified.”

For the round ZIP include this note, `statement_171.json`, `focused_query_summary.json`, and `compact_provenance.json`. Full third-party papers and large raw/noisy search responses need not be redistributed.
