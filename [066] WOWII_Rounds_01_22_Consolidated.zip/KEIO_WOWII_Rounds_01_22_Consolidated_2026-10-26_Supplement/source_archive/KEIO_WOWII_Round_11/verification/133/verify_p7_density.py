"""Supplementary finite checks; not a replacement for the analytic proof.
Run from this file's directory, or from any directory. Pure Python standard library.
"""
import itertools,json,pathlib
OUT=pathlib.Path(__file__).resolve().parent

def path(a,k):
 def dfs(v,n,used,blocked):
  if n==k:return True
  can=a[v]&~(used|blocked)
  while can:
   b=can&-can;can-=b
   if dfs(b.bit_length()-1,n+1,used|b,blocked|a[v]):return True
  return False
 return any(dfs(v,1,1<<v,0) for v in range(len(a)))
def edge(a,u,v):a[u]|=1<<v;a[v]|=1<<u
def cycle(n):
 a=[0]*n
 for i in range(n):edge(a,i,(i+1)%n)
 return a
def goodgirth(a):
 return all(not(a[u]&a[v]) if a[u]>>v&1 else (a[u]&a[v]).bit_count()<=1 for u in range(len(a)) for v in range(u))
def deficit(a):return 3*len(a)-sum(x.bit_count() for x in a)

types=[('P',k,i) for k in range(1,7) for i in range(5)]+[('C',5,0)]
def c5graph(tt):
 a=cycle(5)
 for kind,k,i in tt:
  b=len(a);a.extend([0]*k)
  for j in range(k):edge(a,b+j,(i+2*j)%5)
  for j in range(k-1):edge(a,b+j,b+j+1)
  if kind=='C':edge(a,b,b+k-1)
 return a
counts=dict(c5_component_multisets=0,c5_p7_free=0,c5_negative_deficit=0,c7_layer_graphs=0,c7_p7_free=0)
for size in range(4):
 for ids in itertools.combinations_with_replacement(range(len(types)),size):
  a=c5graph([types[i] for i in ids]);counts['c5_component_multisets']+=1
  assert goodgirth(a)
  d=deficit(a)
  if d<0:counts['c5_negative_deficit']+=1
  if not path(a,7):
   counts['c5_p7_free']+=1
   assert d>=0,(ids,d)
# All eligible C7 first-layer index sets, and all pair-packing second layers
# with degree >=2. Degree-one vertices only improve the density deficit.
for k in range(4):
 for I in itertools.combinations(range(7),k):
  if any((i-j)%7 in (2,5) for i,j in itertools.combinations(I,2)):continue
  a=cycle(7);a.extend([0]*k)
  for j,i in enumerate(I):edge(a,7+j,i);edge(a,7+j,(i+3)%7)
  subsets=[s for s in range(1,1<<k) if s.bit_count()>=2]
  for mask in range(1<<len(subsets)):
   ss=[s for j,s in enumerate(subsets) if mask>>j&1]
   if any((s&t).bit_count()>1 for s,t in itertools.combinations(ss,2)):continue
   b=a[:]
   for s in ss:
    u=len(b);b.append(0)
    for j in range(k):
     if s>>j&1:edge(b,u,7+j)
   if not goodgirth(b):continue
   counts['c7_layer_graphs']+=1
   if not path(b,7):counts['c7_p7_free']+=1;assert deficit(b)>=1
# Verify all three exceptional configurations in the radius-four proof have C4.
exception=[]
for odd in (1,3,5):
 a=cycle(6)+[0]*6
 for i in range(6):edge(a,i,6+i)
 for i in range(3):edge(a,6+i,9+i)
 for i in (2,4):edge(a,6,6+i)
 for i in (1,3,5):
  if i!=odd:edge(a,6+odd,6+i)
 witnesses=[(u,v,[j for j in range(12) if (a[u]&a[v])>>j&1]) for u in range(12) for v in range(u) if (a[u]&a[v]).bit_count()>1]
 assert witnesses
 exception.append(dict(odd_middle=odd,common_neighbor_witness=witnesses[0]))
result=dict(status='PASS',counts=counts,radius_four_exceptions=exception,scope='C5 component multisets of size at most3, all admissible C7 contact sets and degree>=2 pair-packing layers, three r4 exceptional configurations. Analytic proofs handle arbitrary order.')
print(json.dumps(result,indent=2))
(OUT/'verification_p7_density.json').write_text(json.dumps(result,indent=2)+'\n')
