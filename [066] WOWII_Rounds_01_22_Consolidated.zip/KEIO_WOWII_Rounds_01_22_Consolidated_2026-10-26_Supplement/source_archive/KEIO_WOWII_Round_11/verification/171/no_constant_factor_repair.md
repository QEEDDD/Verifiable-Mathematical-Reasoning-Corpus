# Additional consequence: no positive constant-factor repair of #171

This note is separate from the frozen 407-vertex witness proof. It uses precisely the same construction and the same pairwise-periphery average.

For any odd integer R>=19, construct the tree with one length-(R-1) stem supporting m=2R-3 leaves, one length-R arm, and k=R further length-(R-1) arms at the common center. Exactly the m stem leaves and the opposite endpoint are peripheral, with diameter 2R. Therefore

- n=R^2+3R-3;
- L=3R-2;
- average periphery-pair distance = 2+4(R-1)/(m+1)=4;
- the center bipartition class has R+R(R-1)/2 vertices;
- the other bipartition class, larger by m, has (R^2+5R-6)/2 vertices.

Consequently the right side of #171 equals (R^2+5R-8)/8, and its excess over L is

(R^2-19R+8)/8 > 0.

The ratio of the proposed right side to L tends to infinity as R tends to infinity through odd integers. Thus no positive universal constant c can make

L >= c * (maximum even-distance count - 1) / average periphery-pair distance

hold for all trees. This is a consequence of the same refutation, not an additional numbered conjecture closure.

For an integer-valued parametrization put R=8t+19, t>=0. Then

n=64t^2+328t+415,
L=24t+55,
maximum even-distance count=32t^2+172t+225,
average=4,
right side=8t^2+43t+56,
right side minus L=8t^2+19t+1.

The proof of the periphery is identical to the principal witness: every nonperipheral candidate is at distance at most R-1 from the center, while all vertices are at distance at most R, so its eccentricity is at most 2R-1. The two diameter endpoint groups are at distance 2R.
