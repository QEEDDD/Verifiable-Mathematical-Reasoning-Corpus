"""Exact, standard-library-only verification of two WOWII 171 tree counterexamples.
The proof is structural; all-pairs BFS independently checks every displayed invariant.
"""
from collections import deque
from fractions import Fraction
from pathlib import Path
import json
HERE=Path(__file__).resolve().parent

def build(R,k,m):
    edges=[];next_id=1;center=0
    def arm(length):
        nonlocal next_id
        last=center;vertices=[]
        for _ in range(length):
            w=next_id;next_id+=1;edges.append((last,w));vertices.append(w);last=w
        return vertices
    left=arm(R-1);left_leaves=[]
    for _ in range(m):
        w=next_id;next_id+=1;edges.append((left[-1],w));left_leaves.append(w)
    right=arm(R);side=[arm(R-1)for _ in range(k)]
    return next_id,edges,left_leaves+[right[-1]],right[0]

def verify(R,k,m,name):
    n,edges,expected_B,root=build(R,k,m)
    A=[[]for _ in range(n)]
    for u,v in edges:A[u].append(v);A[v].append(u)
    D=[]
    for v in range(n):
        d=[-1]*n;d[v]=0;q=deque([v])
        while q:
            u=q.popleft()
            for w in A[u]:
                if d[w]<0:d[w]=d[u]+1;q.append(w)
        assert min(d)>=0
        D.append(d)
    assert len(edges)==n-1 # connected graph with n-1 edges is a tree
    L=sum(len(a)==1 for a in A)
    ecc=list(map(max,D));diam=max(ecc);B=[v for v,e in enumerate(ecc)if e==diam]
    assert set(B)==set(expected_B)
    pair_sum=sum(D[u][v]for i,u in enumerate(B)for v in B[i+1:])
    avg=Fraction(pair_sum,len(B)*(len(B)-1)//2)
    counts=[sum(d%2==0 for d in row)for row in D];even=max(counts)
    rhs=Fraction(even-1,1)/avg
    assert n==m+2*R+k*(R-1) and L==m+k+1
    assert diam==2*R and len(B)==m+1
    assert avg==Fraction(2*(m-1+2*R),m+1)
    e0=1+(R-1)//2+(m if R%2==0 else 0)+R//2+k*((R-1)//2)
    assert even==max(e0,n-e0)
    assert L<rhs
    out=dict(name=name,R=R,k=k,m=m,n=n,edges=len(edges),L=L,diameter=diam,periphery_size=len(B),periphery_pair_distance_sum=pair_sum,periphery_pair_count=len(B)*(len(B)-1)//2,periphery_average=str(avg),maximum_even_distance_count=even,root_attaining_maximum=counts.index(even),RHS=str(rhs),RHS_minus_L=str(rhs-L),result='COUNTEREXAMPLE')
    (HERE/(name+'.edgelist')).write_text(''.join(f'{u} {v}\n'for u,v in edges))
    return out

if __name__=='__main__':
    rows=[verify(20,20,38,'first_witness_458'),verify(15,25,27,'clean_witness_407'),verify(15,24,27,'family_first_393')]
    (HERE/'verification.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(json.dumps(rows,indent=2))
