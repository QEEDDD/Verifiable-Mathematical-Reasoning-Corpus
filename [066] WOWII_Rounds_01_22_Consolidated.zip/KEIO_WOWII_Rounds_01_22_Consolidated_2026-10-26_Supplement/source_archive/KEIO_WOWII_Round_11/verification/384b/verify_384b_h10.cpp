// Covers every possible counterexample by labeling a cubic high vertex last.
// All covered nine-cores + all 130 neighborhoods of cardinality at most three.
#include <array>
#include <vector>
#include <fstream>
#include <iostream>
#include <algorithm>
#include <cstdint>
using U=uint32_t;
std::array<U,10>a;std::array<int,10>base,dc;
std::vector<std::pair<int,int>>Q;
uint64_t cores=0,filtered=0,core_safe=0,pats=0,crit=0,bad=0;
bool omission(){
 auto b=dc;for(auto [u,v]:Q){b[u]++;b[v]++;}for(auto&x:b)x=std::max(x,3);
 for(U r=0;r<1024;r++){
  int score=__builtin_popcount(r);for(auto [u,v]:Q)if(!(r&(1u<<u))&&!(r&(1u<<v)))score++;
  if(score<6)continue;
  bool ok=true;for(int v=0;v<10;v++)if(r>>v&1)if(b[v]-__builtin_popcount(a[v]&r)<2){ok=false;break;}
  if(ok)return true;
 }
 return false;
}
void visit(){
 pats++;auto t=base;uint64_t vals=1; // conservatively allow the low count zero
 if(!Q.empty())vals|=2;
 for(auto[u,v]:Q){t[u]++;t[v]++;}
 for(int x:t)vals|=1ull<<x;
 if(__builtin_popcountll(vals)<=10)return;
 crit++;if(!omission()){bad++;if(bad<=5){std::cerr<<"UNRESOLVED core";for(U x:a)std::cerr<<' '<<x;std::cerr<<" Q";for(auto[u,v]:Q)std::cerr<<' '<<u<<','<<v;std::cerr<<'\n';}}
}
void match(U rem){
 if(!rem){visit();return;}
 int u=__builtin_ctz(rem);rem&=~(1u<<u);match(rem);
 U ns=a[u]&rem;
 while(ns){int v=__builtin_ctz(ns);ns&=ns-1;
  if((u==9||v==9)&&dc[9]==3)continue; // designated high vertex has total degree3
  Q.push_back({u,v});match(rem&~(1u<<v));Q.pop_back();
 }
}
void core(){
 cores++;
 for(int v=0;v<10;v++){dc[v]=__builtin_popcount(a[v]);int x=0;for(int u=0;u<10;u++)if(a[v]>>u&1)x+=__builtin_popcount(a[v]&a[u]);base[v]=x/2;}
 auto t=base;std::sort(t.begin(),t.end());bool compatible=false;
 for(int skip=0;skip<10&&!compatible;skip++){
  int prev=1;bool ok=true;for(int i=0;i<10;i++)if(i!=skip){int y=std::max(t[i],prev+1);if(y-t[i]>1){ok=false;break;}prev=y;}compatible=ok;
 }
 if(!compatible)return;filtered++;
 Q.clear();if(omission()){core_safe++;return;}
 match(1023);
}
int main(int argc,char**argv){if(argc!=2)return 2;std::ifstream in(argv[1]);if(!in)return 2;uint64_t mask;uint64_t source=0;
 while(in>>mask){if(mask>=(1ull<<36))return 3;source++;std::array<U,10>g{};int i=0;for(int u=0;u<9;u++)for(int v=u+1;v<9;v++,i++)if(mask>>i&1){g[u]|=1u<<v;g[v]|=1u<<u;}
  for(U hood=0;hood<512;hood++)if(__builtin_popcount(hood)<=3){a=g;a[9]=hood;for(int u=0;u<9;u++)if(hood>>u&1)a[u]|=512;core();}
  if(source%50000==0)std::cerr<<"processed nine-cores "<<source<<" extensions "<<cores<<" critical "<<crit<<" unresolved "<<bad<<'\n';
 }
 std::cout<<"{\"h\":10,\"source9_masks\":"<<source<<",\"cubic_labeled_core_extensions\":"<<cores<<",\"offset_compatible\":"<<filtered<<",\"safe_before_attachments\":"<<core_safe<<",\"attachment_patterns\":"<<pats<<",\"critical_patterns\":"<<crit<<",\"unresolved_kernels\":"<<bad<<",\"status\":\""<<(bad?"UNRESOLVED":"PASS")<<"\"}\n";
 return bad?1:0;}
