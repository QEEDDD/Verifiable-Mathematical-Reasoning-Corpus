// Independent explicit-isomorphism checker; no canonicalization is performed.
#include <array>
#include <fstream>
#include <iostream>
#include <unordered_set>
#include <cstdint>
using U=uint64_t;
bool read64(std::ifstream&in,U&x){x=0;for(int i=0;i<8;i++){int c=in.get();if(c==EOF)return false;x|=U((unsigned char)c)<<(8*i);}return true;}
int main(int argc,char**argv){
 if(argc!=4)return 2;
 std::ifstream src(argv[1]),dst(argv[2]),perms(argv[3],std::ios::binary);if(!src||!dst||!perms)return 2;
 std::unordered_set<U>target;U m;while(dst>>m){if(m>=(1ull<<36))return 3;target.insert(m);}
 int id[9][9],q=0;for(int u=0;u<9;u++)for(int v=u+1;v<9;v++)id[u][v]=id[v][u]=q++;
 uint64_t count=0,sources=0;
 while(src>>m){if(m>=(1ull<<28))return 3;sources++;
  std::array<unsigned,9>a{};q=0;for(int u=0;u<8;u++)for(int v=u+1;v<8;v++,q++)if(m>>q&1){a[u]|=1u<<v;a[v]|=1u<<u;}
  for(unsigned hood=0;hood<256;hood++){
   U code;if(!read64(perms,code)||code>>36)return 4;std::array<int,9>p;unsigned seen=0;
   for(int v=0;v<9;v++){p[v]=(code>>(4*v))&15;if(p[v]>=9)return 4;seen|=1u<<p[v];}if(seen!=511)return 4;
   U image=0;for(int u=0;u<8;u++)for(int v=u+1;v<8;v++)if(a[u]>>v&1)image|=1ull<<id[p[u]][p[v]];
   for(int u=0;u<8;u++)if(hood>>u&1)image|=1ull<<id[p[u]][p[8]];
   if(!target.count(image))return 5;count++;
  }
 }
 if(perms.get()!=EOF)return 6;
 std::cout<<"{\"status\":\"PASS\",\"source8_masks\":"<<sources<<",\"extensions_covered\":"<<count<<",\"destination9_masks\":"<<target.size()<<",\"scope\":\"Every ninth-vertex extension maps to a supplied mask by an explicitly verified bijection; canonicalizer not trusted.\"}\n";
}
