# Independent audit: general C4-subgraph-free radius-four classification

**Verdict: PASS, analytic partial result toward original WOWII133.**
26 October 2026. Audited author file:
`round_12/domination133/radius_four_general.md`, snapshotted with its finite
checker/results. This extends the earlier triangle-free radius-four result
to graphs containing triangles, without claiming full WOWII133 or worldwide
priority.

The exact class is C8, or a C6 with nonempty single-contact classes A_i
inducing matchings plus isolates and optional single vertices B_i attached
to cycle edges, with no other edges. In the C6 family, the local-independence
sum is L=2n−t, so its average is at most two. Original WOWII133 consequently
holds for all graphs of radius four whose unrounded local-independence
average is at most four.

## 1. Dependencies and dominating-cycle reduction

The exact Camby--Schaudt Theorem5, its required Theorems4–5 proof chain,
the earlier minimal-domination lemma, and the classical vertex-order bound
p≥2r−1 were already audited in the Round11/earlier reports. The connected
dominating subgraph is P6-free or an induced C8. Since r(G)≤r(H)+1, the
P6-free alternative must have radius three.

The general, not only triangle-free, radius-three input is correctly
reproduced. Van 't Hof--Paulusma gives a dominating induced C6 or a
dominating complete bipartite subgraph. The latter is a star under strong
C4 exclusion and yields radius at most two. On C6, a contact set avoiding
cyclic distance two has at most two vertices: the distance-two graph on
the six cycle vertices is two triangles, so its independent sets have
size at most two. The possible contacts are singleton, adjacent pair,
or opposite pair. The first two create P6 using five consecutive cycle
vertices and omitting the unused contact. An opposite-pair exterior vertex
would again yield radius at most two, as detailed in the note. Hence the
radius-three subgraph is exactly C6.

The C8 alternative is also correctly handled with triangles allowed.
Any exterior contact set lacking a distance-three/four pair is a singleton
or adjacent pair and gives P8. A set containing such a pair cannot fit
inside the consecutive triple of cycle vertices at distance at least three
from any fixed cycle vertex. Thus every cycle vertex is within three of
every exterior vertex. One contact pair supplies an antipode shortcut,
making a cycle vertex a center of eccentricity at most three. Therefore
the radius-four alternative is exactly G=C8.

No new unreviewed AI-paper input enters this argument. The established
primary sources remain [Camby--Schaudt](https://arxiv.org/pdf/1402.7213v1)
and [van 't Hof--Paulusma](https://pimvanthof.github.io/p6free.pdf), with
their exact uses and prior audits recorded above.

## 2. Complete contact-class restrictions and radius witnesses

On the dominating C6, opposite-pair contact vertices have eccentricity
at most three and are impossible. Singletons A_i and adjacent pairs B_i
are therefore exhaustive. Two vertices in B_i would have two common
neighbors and form a C4. An A_i vertex with two neighbors within A_i would
form C4 through c_i, so each A_i is a matching plus isolates.

The claimed cross-class edge table is complete:

* A_i–A_j only at index differences 2,3,4;
* A_i–B_j only at differences 2,3;
* B_i–B_j only for opposite indices.

All forbidden cases create a four-cycle as a subgraph; a possible chord
does not rescue them. Edges between any two A classes form a matching by
the common-neighbor test. An independent enumeration of all 78 unordered
contact-type pairs, including repetitions, confirmed exactly 30 permitted
edge types (including six within-A types).

Every cycle vertex c_(i+3) has eccentricity at least four. All vertices
except A_i have a route of at most three through the cycle, and every
vertex has a route of at most four. Hence a radius witness z_i∈A_i at
distance exactly four exists. Every permitted cross-class neighbor of z_i
would give a route of at most three from c_(i+3), so z_i has no exterior
neighbor outside A_i. It may have one mate inside A_i; the proof does not
incorrectly assume that it is an isolated leaf.

## 3. All forbidden-path chord checks

The opposite A–A path uses witnesses in the two adjacent contact classes,
four cycle vertices with no extra cycle edge, and the proposed opposite
edge. Unique contacts and the witnesses' absence of cross-class neighbors
exclude every remaining chord.

Both A–B paths omit the second cycle contact of their B vertex. The B–B
path likewise omits both unused contacts. Their first/last witnesses are
in different A classes from all internal exterior vertices, so possible
same-class mates do not introduce chords. These paths are induced even
in the presence of other simultaneous cross-class edges elsewhere.

The diagonal A–A argument correctly treats the only new complication
caused by triangles. If x∈A_i is adjacent to y∈A_(i+2), then z_i≠x.
Unless z_i is the mate of x, the first displayed eight-vertex sequence
is induced: its only potentially troublesome same-class chord is xz_i.
By reversal, z_(i+2) must be the mate of y. The final sequence

    z_(i+3), c_(i+3), c_(i+4), c_(i+5), c_i, x, y, z_(i+2)

then is induced. Its final witness has only its displayed mate among
the exterior path vertices, and its cycle contact c_(i+2) is absent.
Its first witness has no cross-class exterior neighbor. The four cycle
vertices form an induced path, and neither x nor y has an extra contact
on that path. Thus no hidden chord remains. All possible cross-class
edges are excluded, proving the necessary structure.

## 4. Converse, count, and exact implication

Each proposed exterior vertex is simplicial: a leaf, a vertex in a pendant
triangle, or a vertex attached to both ends of a cycle edge. It cannot be
internal on an induced path. Such a path uses at most five cycle vertices
and two exterior endpoints, so is P8-free. The decoration creates no C4:
single-contact triangles meet the rest only at their cycle root, and a
B vertex only supplies a two-edge alternative to one cycle edge, never
a shorter cycle route.

Cycle vertices have eccentricity four; A vertices have eccentricity five;
B vertices have eccentricity four. The nonempty opposite A classes give
the stated lower witnesses, and direct cycle routes give the upper bounds.
In particular B vertices cannot lower the graph's radius below four.

The vertex, edge, and triangle counts are exact:

    n=6+a+b,   m=6+a+q+2b,   t=q+b.

In a C4-subgraph-free graph, each neighborhood is a matching plus isolates,
so alpha(N(v))=d(v)−q(v). Summing gives L=2m−3t, and substitution yields
L=2n−t. No degree average is incorrectly substituted for local independence
when triangles occur.

For the original r=4 consequence, one can avoid even the earlier low-average
partial theorem: if ell≤3, the classical bound gives p≥7≥4+ell. If
3<ell≤4, the classification forces p≥8≥4+ell. The C4-present branch is
the elementary p≥r+1 branch. This proves exactly the stated all-graphs
radius-four partial case, not the remaining radius-three interval or full
conjecture.

## 5. Independent finite controls

`check_independent.cpp` uses no author code. Its generic induced-path DFS,
all-root distance calculations, and brute-force neighborhood-independent-set
counts evaluate actual graphs.

* All **78** contact-pair cases agree with the analytic edge table.
* All **46,656** decorations with each A_i of size one, size two independent,
  or size two matched, and every subset of B_i, are C4-free, radius four,
  P8-free, and satisfy the exact L identity. This includes **886,464** direct
  neighborhood-independence evaluations. Every graph also contains P7.
* To test simultaneous cross edges, a rich decoration has two matched A_i
  vertices per class (one active and one private witness) and all six B_i.
  All **2^24=16,777,216** subsets of eligible cross edges are explored,
  pruning only additions that immediately create a C4. The pruning test
  is the existence of a length-three path between the new edge endpoints,
  which is exactly the condition for that edge to close a C4.
  There are **26,036** C4-free subsets. Every one of the **26,035 nonempty**
  subsets contains an induced P8 under the generic path search. Thus the
  controls are not limited to the author's single-edge extensions.

These are supplementary tests, not a replacement for the arbitrary-order
analytic proof. Reproduce:

```sh
d=wowii_rounds/round_12/independent_audit/133
g++ -O3 -std=c++17 "$d/check_independent.cpp" -o /tmp/audit_r4_general
/tmp/audit_r4_general
```

**No unresolved proof or dependency gap.** No full numbered closure,
formal proof-assistant certificate, or worldwide novelty claim is made.
