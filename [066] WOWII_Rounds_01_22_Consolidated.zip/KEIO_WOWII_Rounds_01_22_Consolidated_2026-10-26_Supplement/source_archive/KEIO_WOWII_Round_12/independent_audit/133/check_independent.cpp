// Independent controls of the general radius-four classification.
// Direct adjacency, generic induced-path DFS, and brute-force neighborhood
// independence; no author code is imported. Multiple cross edges are tested.
#include <array>
#include <cstdint>
#include <functional>
#include <iostream>
#include <stdexcept>
#include <vector>
using U=std::uint32_t;using W=std::uint64_t;
void need(bool b,const char*s){if(!b)throw std::runtime_error(s);}
int pc(U x){return __builtin_popcount(x);}
struct G{
 int n=6;std::array<U,32>a{};
 G(){for(int i=0;i<6;++i)edge(i,(i+1)%6);}
 void edge(int u,int v){a[u]|=U(1)<<v;a[v]|=U(1)<<u;}
 void erase(int u,int v){a[u]&=~(U(1)<<v);a[v]&=~(U(1)<<u);}
 int add(U neighbors){int v=n++;need(n<32,"Too large");for(U s=neighbors;s;s&=s-1)edge(v,__builtin_ctz(s));return v;}
 bool c4free()const{for(int u=0;u<n;++u)for(int v=u+1;v<n;++v)if(pc(a[u]&a[v])>1)return false;return true;}
 bool safe_edge(int u,int v)const{for(U s=a[u];s;s&=s-1)if(a[__builtin_ctz(s)]&a[v])return false;return true;}
 int ecc(int u)const{U seen=U(1)<<u,front=seen;int d=0;while(seen!=((U(1)<<n)-1)){U next=0;for(U s=front;s;s&=s-1)next|=a[__builtin_ctz(s)];next&=~seen;need(next,"Disconnected graph");seen|=next;front=next;++d;}return d;}
 bool dfs(int last,U used,U blocked,int length,int target)const{if(length==target)return true;for(U s=a[last]&~(used|blocked);s;s&=s-1){int w=__builtin_ctz(s);if(dfs(w,used|(U(1)<<w),blocked|a[last],length+1,target))return true;}return false;}
 bool path(int target)const{for(int u=0;u<n;++u)if(dfs(u,U(1)<<u,0,1,target))return true;return false;}
 int local_independence(int u)const{int best=0;U neighbors=a[u];for(U s=neighbors;;s=(s-1)&neighbors){bool independent=true;for(U t=s;t;t&=t-1)if(a[__builtin_ctz(t)]&s){independent=false;break;}if(independent)best=std::max(best,pc(s));if(!s)break;}return best;}
 int triangles()const{int three=0;for(int u=0;u<n;++u)for(int v=u+1;v<n;++v)if(a[u]&(U(1)<<v))three+=pc(a[u]&a[v]);need(three%3==0,"Triangle count");return three/3;}
};
int main(){try{
 W contactTests=0,allowed=0;
 // All pairs of singleton/adjacent-pair contact types, including repetitions.
 for(int i=0;i<12;++i)for(int j=i;j<12;++j){G g;auto contacts=[](int t){return t<6?(U(1)<<t):((U(1)<<(t-6))|(U(1)<<((t-5)%6)));};
  int x=g.add(contacts(i)),y=g.add(contacts(j));g.edge(x,y);bool actual=g.c4free(),expected=false;
  if(i<6&&j<6){int d=(j-i+6)%6;expected=(d==0||d==2||d==3||d==4);}
  else if(i<6){int d=(j-6-i+6)%6;expected=(d==2||d==3);}
  else expected=((j-i+6)%6==3);
  need(actual==expected,"Contact edge table mismatch");++contactTests;if(actual)++allowed;
 }
 W bases=0,localTests=0;for(int code=0;code<729;++code)for(int bs=0;bs<64;++bs){G g;int xcode=code;std::vector<int>type(6,0);
  for(int i=0;i<6;++i){int choice=xcode%3;xcode/=3;int x=g.add(U(1)<<i);type.push_back(1);if(choice){int y=g.add(U(1)<<i);type.push_back(1);if(choice==2)g.edge(x,y);}}
  for(int i=0;i<6;++i)if(bs&(1<<i)){g.add((U(1)<<i)|(U(1)<<((i+1)%6)));type.push_back(2);}
  need(g.c4free(),"Proposed family contains C4");need(!g.path(8),"Proposed family contains P8");need(g.path(7),"Expected P7 absent");
  int L=0;for(int u=0;u<g.n;++u){need(g.ecc(u)==(type[u]==1?5:4),"Wrong converse eccentricity");L+=g.local_independence(u);++localTests;}
  need(L==2*g.n-g.triangles(),"Local-independence identity failure");++bases;
 }
 // Rich decoration: two matched A_i vertices per class (one active, one
 // private witness), and every B_i. All subsets of all 24 allowed cross
 // edges are explored, pruning only when an added edge creates a C4.
 G rich;std::array<int,6>x,z,b;for(int i=0;i<6;++i){x[i]=rich.add(U(1)<<i);z[i]=rich.add((U(1)<<i)|(U(1)<<x[i]));}
 for(int i=0;i<6;++i)b[i]=rich.add((U(1)<<i)|(U(1)<<((i+1)%6)));
 std::vector<std::pair<int,int>>edges;for(int i=0;i<6;++i)for(int j=i+1;j<6;++j){int d=j-i;if(d==2||d==3||d==4)edges.push_back({x[i],x[j]});}
 for(int i=0;i<6;++i){edges.push_back({x[i],b[(i+2)%6]});edges.push_back({x[i],b[(i+3)%6]});}
 for(int i=0;i<3;++i)edges.push_back({b[i],b[i+3]});need(edges.size()==24&&rich.c4free(),"Rich base invalid");
 W valid=0,nonempty=0,pruned=0;std::array<W,25>sizes{};
 std::function<void(int,int)>walk=[&](int first,int count){if(first==24){++valid;++sizes[count];if(count){++nonempty;need(rich.path(8),"Cross-edge configuration lacks P8");}else need(!rich.path(8),"Rich base unexpectedly has P8");return;}
  walk(first+1,count);auto[u,v]=edges[first];if(rich.safe_edge(u,v)){rich.edge(u,v);walk(first+1,count+1);rich.erase(u,v);}else ++pruned;
 };walk(0,0);
 std::cout<<"{\n  \"status\": \"PASS\",\n  \"contact_pair_tests\": "<<contactTests<<",\n  \"allowed_contact_edges\": "<<allowed<<",\n  \"converse_decoration_graphs\": "<<bases<<",\n  \"direct_neighborhood_independence_evaluations\": "<<localTests<<",\n  \"rich_cross_edge_powerset_size\": "<<(W(1)<<24)<<",\n  \"rich_C4free_cross_subsets\": "<<valid<<",\n  \"rich_nonempty_cross_subsets_with_P8\": "<<nonempty<<",\n  \"incremental_C4_pruned_branches\": "<<pruned<<",\n  \"rich_valid_by_cross_edge_count\": [";
 for(int i=0;i<=24;++i){if(i)std::cout<<',';std::cout<<sizes[i];}std::cout<<"]\n}\n";return 0;
 }catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
