# General C4-free radius-four P8-free graphs

**KEIO — Round12, 26 October 2026.**

**Status:** complete proposed analytic classification, awaiting independent review. This is a further partial result toward original WOWII133; no full closure or priority claim is made. The independently approved Round11 manuscript is unchanged.

## Theorem

Let G be a finite connected simple graph with no C4 as a subgraph. Then r(G)=4 and G is P8-free if and only if G is C8 or has the following form:

- start with an induced C6, cyclically labelled c_0,...,c_5;
- for each i, add a nonempty vertex set A_i, join every vertex of A_i to c_i, and let G[A_i] be an arbitrary matching plus isolated vertices;
- for each cycle edge c_i c_{i+1}, optionally add one vertex b_i adjacent to its two endpoints;
- add no other edges.

For the C6 family, if t is the number of triangles, then

    L(G):=sum_v alpha(G[N(v)])=2n−t≤2n.

The same bound holds for C8. In particular every such graph has average local independence ell≤2.

## 1. Credited dominating-cycle reduction

Camby–Schaudt, Theorem5 of [arXiv1402.7213v1](https://arxiv.org/abs/1402.7213v1), gives a connected dominating induced subgraph H that is P6-free or C8. The classical bound p≥2r−1 and r(G)≤r(H)+1 imply that the P6-free alternative has radius exactly three.

For completeness, a connected C4-subgraph-free P6-free graph of radius three is C6, even when triangles are allowed. Van ’t Hof–Paulusma's Theorem6 gives a dominating induced C6 or a dominating complete bipartite subgraph. The latter must be a star and gives radius at most two. On a dominating C6, C4-freeness permits only a singleton, adjacent pair, or opposite pair as the contact set of an exterior vertex. A singleton or adjacent pair gives P6 by taking that vertex and five consecutive cycle vertices, omitting the unused contact if necessary. Hence every exterior vertex has an opposite pair. If x has contacts c_0,c_3, then c_0 is within distance two of all cycle vertices and every exterior vertex, because every possible opposite pair contains one of c_0,c_1,c_5. Thus any exterior vertex would again give radius at most two. This proves the input.

It follows that G has a dominating induced C6 or C8. In the C8 case, every exterior contact set must contain a pair at cyclic distance three or four: distance-two pairs create C4, while a contact set with no distance-three/four pair is a singleton or adjacent pair and creates P8. Every cycle vertex is within distance three of every exterior vertex, because its three farthest cycle vertices are consecutive and cannot contain such a contact set. One exterior distance-three/four contact pair also shortens a cycle-antipode distance to at most three. Its cycle endpoint would have eccentricity at most three. Therefore the C8 alternative is exactly G=C8.

We henceforth fix a dominating induced C6, with indices modulo six.

## 2. Contact classes and radius witnesses

An exterior contact set has at most two vertices, since three contacts on C6 contain two at cyclic distance two, producing C4. The two-contact case is adjacent or opposite. Opposite contacts would give an exterior vertex within distance two of the whole cycle, hence within distance three of all G. Thus only singleton and adjacent-pair contacts remain.

Let A_i be the vertices with contact set {c_i}, and B_i those with contact set {c_i,c_{i+1}}. We have |B_i|≤1, and write b_i for its vertex when present. Each A_i induces a matching plus isolated vertices, because a three-vertex path in N(c_i) would create a C4.

Elementary four-cycle checks give all possible edges between different contact classes:

- A_i–A_j is possible only for j=i+2,i+3,i+4;
- A_i–B_j is possible only for j=i+2,i+3;
- B_i–B_j is possible only for j=i+3.

For example an A_i–A_{i+1} edge completes a C4 with c_i c_{i+1}; the disallowed A–B and B–B cases similarly use one cycle edge and the two exterior endpoints. Edges between any fixed pair of A classes form a matching by the common-neighbor condition.

Every A_i contains a vertex z_i at distance four from c_{i+3}. Indeed, all cycle vertices, all B vertices, and all A_j with j≠i are within distance three of c_{i+3}. Such a witness z_i has no neighbor outside A_i among the exterior vertices. A permitted neighbor in A_{i+2},A_{i+3},A_{i+4} gives distance at most three from c_{i+3}; a neighbor in B_{i+2} or B_{i+3} gives distance two. Within A_i, z_i has at most one neighbor because G[A_i] is a matching.

All witnesses used below therefore have no exterior neighbor in a different contact class.

## 3. Excluding all cross-class edges

### Opposite A–A edges

If x∈A_i and y∈A_{i+3} are adjacent, then

    z_{i+1},c_{i+1},c_i,x,y,c_{i+3},c_{i+4},z_{i+4}

is an induced P8. Unique cycle contacts and the witness property exclude every chord.

### A–B edges

If x∈A_i is adjacent to b_{i+2}, use

    z_{i+1},c_{i+1},c_i,x,b_{i+2},c_{i+3},c_{i+4},z_{i+4}.

The unused cycle contact of b_{i+2} is c_{i+2}, which is not on the path. If x is adjacent to b_{i+3}, reverse the cycle orientation and use

    z_{i+5},c_{i+5},c_i,x,b_{i+3},c_{i+3},c_{i+2},z_{i+2}.

Both sequences are induced P8s.

### B–B edges

If b_i and b_{i+3} are adjacent, use the induced P8

    z_{i+2},c_{i+2},c_{i+1},b_i,b_{i+3},c_{i+4},c_{i+5},z_{i+5}.

The unused B contacts c_i,c_{i+3} are both absent from the path.

### Diagonal A–A edges

Suppose x∈A_i and y∈A_{i+2} are adjacent. First the witness z_i must be adjacent to x. Otherwise

    z_{i+4},c_{i+4},c_{i+3},c_{i+2},y,x,c_i,z_i

is an induced P8. Notice that z_i≠x, since x has an exterior neighbor in a different class. By reversing the cyclic orientation and exchanging x,y, the witness z_{i+2} must likewise be adjacent to y.

But now

    z_{i+3},c_{i+3},c_{i+4},c_{i+5},c_i,x,y,z_{i+2}

is an induced P8. Its last witness has only the displayed neighbor y among the exterior path vertices, and its cycle contact c_{i+2} is omitted. Its first witness has no other exterior path neighbor. All cycle contacts and cycle edges are therefore chordless in the displayed sequence.

All possible cross-class edges are excluded. This proves the asserted structure.

## 4. Converse and local-independence count

Every graph in the stated C6 family is C4-subgraph-free. Every exterior vertex is simplicial: it has either one neighbor, or two adjacent neighbors. Hence an exterior vertex can occur in an induced path only at an endpoint. An induced path uses at most five vertices of the six-cycle and at most two exterior endpoints, so the graph is P8-free.

Every cycle vertex has eccentricity four, witnessed by a vertex of its opposite A class. Every A vertex has eccentricity five, witnessed by the opposite A class. A B vertex has eccentricity four, witnessed by either of its two farthest A classes. Thus the radius is four. The C8 case is immediate.

Put a=sum_i|A_i|, q=sum_i|E(G[A_i])|, and b=sum_i|B_i|. Then

    n=6+a+b,    m=6+a+q+2b,    t=q+b.

In a C4-subgraph-free graph each open neighborhood is a matching. Thus lambda(v)=d(v)−q(v), where q(v) counts triangles through v, and L=2m−3t. Substitution gives

    L=12+2a−q+b=2n−(q+b)=2n−t.

This proves ell≤2. ∎

## Consequence and remaining boundary

For every connected graph, including graphs with triangles, original WOWII133 holds when r=4 and ell≤4: the C4-present branch is immediate; in the C4-free branch the earlier ell≤3 result applies, and for 3<ell≤4 the theorem forces p≥8≥4+ell.

This does not settle the nonbipartite triangle-containing radius-three interval 3<ell<4, nor arbitrary larger ell. The separate triangle-bisimplicial search is exploratory and is not used in this proof.
