#include <bits/stdc++.h>
using namespace std;using U=uint64_t;mt19937 rng(133202610);
struct G{
 int n;vector<U>N;G(int n):n(n),N(n){};
 void edge(int u,int v){N[u]|=1ull<<v;N[v]|=1ull<<u;}
 void del(int u,int v){N[u]&=~(1ull<<v);N[v]&=~(1ull<<u);}
 bool allowed(int u,int v,bool trianglefree){if(u==v||(N[u]>>v&1))return false;if(trianglefree&&(N[u]&N[v]))return false;U a=N[u];while(a){int x=__builtin_ctzll(a);a&=a-1;if(N[x]&N[v])return false;}return true;}
 bool connected(){U seen=1,front=1;while(front){U next=0;while(front){int u=__builtin_ctzll(front);front&=front-1;next|=N[u];}front=next&~seen;seen|=front;}return __builtin_popcountll(seen)==n;}
 int radius(){int rad=n;for(int s=0;s<n;s++){U seen=1ull<<s,front=seen;int d=0;while(__builtin_popcountll(seen)<n){U next=0;while(front){int u=__builtin_ctzll(front);front&=front-1;next|=N[u];}front=next&~seen;seen|=front;d++;if(!front)return n;}rad=min(rad,d);}return rad;}
 int local_sum(){int degrees=0,tri6=0;for(int u=0;u<n;u++){degrees+=__builtin_popcountll(N[u]);U z=N[u];while(z){int v=__builtin_ctzll(z);z&=z-1;tri6+=__builtin_popcountll(N[u]&N[v]);}}return degrees-tri6/2;}
 long long nodes=0;bool haspath(int target){function<bool(int,int,U,U)>dfs=[&](int v,int len,U used,U forbid){nodes++;if(len>=target)return true;U cand=N[v]&~(used|forbid);while(cand){int u=__builtin_ctzll(cand);cand&=cand-1;if(dfs(u,len+1,used|(1ull<<u),forbid|N[v]))return true;}return false;};for(int s=0;s<n;s++)if(dfs(s,1,1ull<<s,0))return true;return false;}
 void print(){for(int u=0;u<n;u++)for(int v=0;v<u;v++)if(N[u]>>v&1)cout<<u<<","<<v<<";";cout<<endl;}
};

int main(){long long bases=0,extensions=0,r4=0,p8=0;for(int state=0;state<729;state++)for(int bm=0;bm<64;bm++){int temp=state,n=6;vector<vector<int>>A(6);vector<int>B(6,-1),cl;vector<pair<int,int>>mats;for(int i=0;i<6;i++){int z=temp%3;temp/=3;A[i].push_back(n++);if(z){A[i].push_back(n++);if(z==2)mats.push_back({A[i][0],A[i][1]});}}for(int i=0;i<6;i++)if(bm>>i&1)B[i]=n++;G g(n);for(int i=0;i<6;i++){g.edge(i,(i+1)%6);for(int x:A[i])g.edge(i,x);if(B[i]>=0){g.edge(i,B[i]);g.edge((i+1)%6,B[i]);}}for(auto [u,v]:mats)g.edge(u,v);if(g.radius()!=4||g.haspath(8)){cout<<"BASE FAILURE "<<state<<" "<<bm<<endl;g.print();return 1;}bases++;vector<int>label(n,-1);for(int i=0;i<6;i++){for(int x:A[i])label[x]=i;if(B[i]>=0)label[B[i]]=i+6;}for(int u=6;u<n;u++)for(int v=6;v<u;v++){if(label[u]==label[v]||!g.allowed(u,v,false))continue;G h=g;h.edge(u,v);extensions++;if(h.radius()==4){r4++;if(!h.haspath(8)){cout<<"COUNTEREXAMPLE "<<state<<" "<<bm<<" extra "<<u<<" "<<v<<endl;h.print();return 1;}p8++;}}}cout<<"{\"status\":\"PASS\",\"base_decorations\":"<<bases<<",\"single_cross_edge_extensions\":"<<extensions<<",\"radius4_extensions\":"<<r4<<",\"radius4_with_induced_P8\":"<<p8<<",\"scope\":\"All Ai sizes1 or2, independent or matched when size2, all optional Bi, and every single allowed cross-class edge. Supplementary only.\"}"<<endl;}
