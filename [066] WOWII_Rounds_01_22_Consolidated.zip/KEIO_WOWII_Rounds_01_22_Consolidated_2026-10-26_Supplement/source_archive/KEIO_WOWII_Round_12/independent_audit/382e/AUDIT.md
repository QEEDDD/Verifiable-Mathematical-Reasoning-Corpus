# Independent audit of the counterexamples to original WOWII 382e

**Mathematical verdict: PASS — a full counterexample to the original quantified statement, together with an unbounded-additive-defect family.** Source-priority/novelty clearance is a separate task and is not certified by this mathematical report. No smallest-counterexample claim is made.

## 1. Original statement and conventions

The pinned original HTML transcription, commit 3be380b4222f974bedbefb228c8e75fbd9a7b3ae, row 382e, states: for a connected graph of order greater than two, `gamma_2 <= Maxine + gamma`. The original row references definitions 90, 111, and 49. These were independently read in the recovered original glossary `round_03/source_audit/archive_defs.txt` and pinned alongside this report:

- 90: vertices outside a 2-dominating set have at least two distinct neighbors in it; selected vertices have no such requirement.
- 49: ordinary domination, with selected vertices covering themselves.
- 111: Maxine is the **largest** independent-set output of repeated deletion of a current maximum-degree vertex, stopping at an edgeless graph.

The proof treats every tie choice, not merely a single unfavorable run. It uses physical vertices, not weighted bags or a quotient graph. The constructed graph is simple, connected, and has 21 vertices in its smallest presented instance.

## 2. Base construction and exact invariants for all k >= 4

Let H consist of K_{k,k} on A={a_0,...,a_{k-1}}, B={b_0,...,b_{k-1}}, together with independent private vertices x_{ij}, 1<=i<k, 0<=j<k, each adjacent exactly to a_0,a_i,b_j. Set F=overline(H), of order k^2+k.

**Maxine(F)=2 for every run.** On a fixed vertex set, maximum-degree deletion in F is minimum-degree deletion in H. Inductively, while any private vertex remains, every private vertex has H-degree exactly three, whereas every core vertex has H-degree at least k from the intact K_{k,k}. Therefore every private vertex is deleted before any core vertex. The remaining F is two disjoint k-cliques. As long as an edge remains the deleted vertex has positive degree, so the last isolated vertex of either clique can never be removed. The terminal set has exactly one vertex in each part. This argument is strict for k>=4 and covers every tie choice.

**gamma(F)=3.** The set {a_0,x_{10},x_{11}} dominates: the two private vertices have distinct exceptional B-neighbors. Every pair fails, with the author's complete case partition verified: XX misses a_0; AA or BB misses the opposite core; a_i,b_j misses x_{ij} (or x_{1j} for i=0); a_i,x_{pq} misses b_q; b_j,x_{pq} misses a_0. Every witness is outside the proposed pair. A dominating singleton would extend to a dominating pair, so none exists.

**gamma_2(F)=4.** The set {a_1,a_2,b_0,b_1} works: an unselected core vertex sees the two vertices in its own part, and a private vertex misses at most one selected A-vertex and at most one selected B-vertex. For a putative three-set D, N_F(a_0)=A minus {a_0} is decisive. If a_0 is outside D, at least two members of D are in A, leaving at most one neighbor available for an unselected B-vertex. If a_0 is inside D, the six types of its other two members are AA, AB, BB, AX, BX, XX. The respective witnesses are any B, an unselected B, an unselected A other than a_0, b_j, a_i, b_j (using x_{ij} for the indicated private vertex). Each has at most one selected neighbor. The core has sufficient unselected vertices since k>=4. This covers all triples; monotonicity under adding selected vertices excludes smaller sets.

These arguments are elementary and have no unreviewed published theorem as a mathematical dependency. The paper's older-construction and related-inequality citations are contextual attribution, not an input to these proofs.

## 3. Universal-vertex amplification

For r>=1, let J=K_1 join (rF), with new vertex u. It is connected, of order 1+r(k^2+k). Since each old vertex has a nonneighbor within its own copy, u is the unique universal vertex and the unique maximum-degree vertex. Every Maxine run deletes it first. Restricting the subsequent deletion order to each copy gives a valid local maximum-degree run: a globally maximum degree is in particular maximum within its copy. No isolated terminal vertex is removed while any edge remains anywhere. Each copy contributes exactly two survivors, so every run has output 2r.

Ordinary domination is one. If a 2-dominating set contains u, its intersection with each copy must ordinarily dominate that copy, and this condition is also sufficient; the optimum in this case is 1+3r. If u is omitted, the intersections must 2-dominate the copies independently; 4r is both a lower bound and attainable, and their union also gives u at least two selected neighbors. Thus gamma_2(J)=min(1+3r,4r)=3r+1. The original inequality fails by exactly r:

`gamma_2 - (Maxine + gamma) = (3r+1) - (2r+1) = r > 0`.

This is unbounded **additive** defect; no unbounded multiplicative-ratio assertion is inferred.

## 4. Independent physical computation

`check_independent.cpp` constructs the 21-vertex graph directly by adjacency rules for the three cliques and their missing incidences, rather than taking the author's complement or reading its graph/certificate. It then tests **every subset without cardinality pruning** for both ordinary and 2-domination in the 20-vertex base and the 21-vertex joined graph: 2^20+2^21=3,145,728 subset tests. Exact results are gamma(F)=3, gamma_2(F)=4, gamma(J)=1, gamma_2(J)=4. There are 318 optimum base four-sets, 444 optimum base dominating triples, and 762 optimum joined 2-dominating four-sets (318+444, also checking the universal-join split). The graph has exactly 158 edges and a unique dominating singleton.

An independently written breadth-first traversal explores every permitted maximum-degree deletion arc: 4,269 distinct physical states and 25,097 arcs. Its terminal masks are exactly the 16 pairs consisting of one A-vertex and one B-vertex. The direct adjacency masks were compared only after computation and agree exactly with the author certificates. Thus the finite instance gives **4 > 2+1** under the original best-output Maxine definition.

`check_family_controls.py` separately builds base graphs for k=4,...,8 and checks all 5,582 pairs as failed dominating sets and all 104,040 triples as failed 2-dominating sets, together with the explicit upper-bound witnesses. For each k and r=1,...,4 it checks the proposed 3r+1-vertex 2-dominating set and five deterministic/seeded tie-breaking runs, 100 runs in total, all with the predicted forced stages and 2r survivors. These are extra finite controls; the universal proof does not rely on them.

Reproduction:

```
g++ -std=c++17 -O3 check_independent.cpp -o /tmp/audit_382e
/tmp/audit_382e
python check_family_controls.py
```

## 5. Manuscript and scope

Both frozen `manuscript.tex` and `382e_counterexamples.md` were read completely. Their theorem, proof, finite-instance numbers, tie convention, amplification and exact quantifiers agree with this audit. No repair was necessary. Earlier auxiliary-route files are not additional target resolutions. The local original-row and glossary evidence are pinned; any prior-art/source-status verdict remains the separate source auditor's responsibility.
