#!/usr/bin/env python3
"""Independent finite controls, not a substitute for the all-k,r proof."""
from itertools import combinations
from random import Random
from pathlib import Path
import json
rng=Random(382012)
def base(k):
    labels=[('a',i) for i in range(k)]+[('b',j) for j in range(k)]+[('x',i,j) for i in range(1,k) for j in range(k)]
    adj=[0]*len(labels)
    for v,w in combinations(range(len(labels)),2):
        p,q=labels[v],labels[w]
        e=p[0]==q[0]
        if q[0]=='x' and p[0]!='x':
            e=(p[1] not in (0,q[1])) if p[0]=='a' else (p[1]!=q[2])
        if e:adj[v]|=1<<w;adj[w]|=1<<v
    return adj

def good(a,S,d):
    return all((S>>v&1) or (nb&S).bit_count()>=d for v,nb in enumerate(a))
def run(a,tie):
    S=(1<<len(a))-1;seq=[]
    while True:
        ds=[((nb&S).bit_count(),v) for v,nb in enumerate(a) if S>>v&1]
        mx=max(d for d,v in ds)
        if not mx:return [v for d,v in ds],seq
        cand=[v for d,v in ds if d==mx]
        v=cand[0] if tie==0 else cand[-1] if tie==1 else rng.choice(cand)
        S^=1<<v;seq.append(v)
results=[];failed_pairs=failed_triples=runs=0
for k in range(4,9):
    a=base(k);n=len(a)
    for D in combinations(range(n),2):
        assert not good(a,sum(1<<v for v in D),1);failed_pairs+=1
    for D in combinations(range(n),3):
        assert not good(a,sum(1<<v for v in D),2);failed_triples+=1
    W1=[0,2*k,2*k+1];W2=[1,2,k,k+1]
    assert good(a,sum(1<<v for v in W1),1)
    assert good(a,sum(1<<v for v in W2),2)
    for r in range(1,5):
        N=r*n;J=[0]*(N+1)
        for i in range(r):
            for v,nb in enumerate(a):J[i*n+v]=(nb<<(i*n))|(1<<N)
        J[N]=(1<<N)-1
        witness=[N]+[i*n+v for i in range(r) for v in W1]
        assert len(witness)==3*r+1 and good(J,sum(1<<v for v in witness),2)
        assert [v for v,nb in enumerate(J) if nb.bit_count()==N]==[N]
        for t in range(5):
            T,seq=run(J,t);runs+=1
            assert seq[0]==N and len(T)==2*r
            for i in range(r):
                local=[v-i*n for v in seq if i*n<=v<(i+1)*n]
                assert set(local[:k*(k-1)])==set(range(2*k,n))
                tail=[v-i*n for v in T if i*n<=v<(i+1)*n]
                assert len(tail)==2 and min(tail)<k<=max(tail)<2*k
        results.append({'k':k,'r':r,'order':N+1,'gamma2_witness_size':len(witness),'runs_checked':5})
out={'status':'PASS','scope':'finite controls only; universal formulas audited analytically','failed_base_domination_pairs':failed_pairs,'failed_base_two_domination_triples':failed_triples,'joined_runs_checked':runs,'cases':results}
Path(__file__).with_name('family_controls.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='cases'}))
