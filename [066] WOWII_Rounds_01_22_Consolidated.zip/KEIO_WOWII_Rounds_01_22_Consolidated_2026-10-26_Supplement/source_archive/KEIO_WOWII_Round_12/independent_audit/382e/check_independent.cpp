// Independent audit. Build the claimed graph directly by its adjacency rules,
// not by taking the complement or importing any author masks/checker.
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <set>
#include <vector>
using namespace std;
int main(){
 const int k=4,N=20,n=21;vector<uint32_t>a(n);vector<pair<int,int>> label;
 for(int i=1;i<k;i++)for(int j=0;j<k;j++)label.push_back({i,j});
 auto edge=[&](int v,int w){a[v]|=1u<<w;a[w]|=1u<<v;};
 for(int v=0;v<n;v++)for(int w=v+1;w<n;w++){
  bool e=false;
  if(w==N)e=true;
  else if(v<k&&w<k)e=true;
  else if(v>=k&&v<2*k&&w<2*k)e=true;
  else if(v>=2*k)e=true;
  else if(w>=2*k){auto [i,j]=label[w-2*k];e=v<k?(v!=0&&v!=i):(v!=k+j);}
  if(e)edge(v,w);
 }
 vector<vector<uint64_t>> dom(2,vector<uint64_t>(n+1)),two=dom;
 for(int t=0;t<2;t++){
  int z=t? n:N;uint32_t full=(1u<<z)-1;
  for(uint32_t s=0;s<=full;s++){
   bool d=true,d2=true;
   for(uint32_t q=full^s;q;q&=q-1){int v=__builtin_ctz(q),c=__builtin_popcount(s&a[v]);d&=c>=1;d2&=c>=2;}
   int b=__builtin_popcount(s);dom[t][b]+=d;two[t][b]+=d2;
  }
 }
 // Independent breadth-first exploration of all maximum-degree deletion arcs.
 set<uint32_t> level{(1u<<n)-1},terminal;uint64_t states=0,arcs=0;
 while(!level.empty()){
  set<uint32_t> next;
  for(uint32_t s:level){states++;int maxdeg=0;vector<int> rem;
   for(uint32_t q=s;q;q&=q-1){int v=__builtin_ctz(q),d=__builtin_popcount(a[v]&s);if(d>maxdeg){maxdeg=d;rem.clear();}if(d==maxdeg)rem.push_back(v);}
   if(!maxdeg){terminal.insert(s);continue;}
   for(int v:rem){arcs++;next.insert(s^(1u<<v));}
  }
  level=move(next);
 }
 assert(dom[0][0]==0&&dom[0][1]==0&&dom[0][2]==0&&dom[0][3]>0);
 assert(two[0][0]==0&&two[0][1]==0&&two[0][2]==0&&two[0][3]==0&&two[0][4]>0);
 assert(dom[1][1]==1&&two[1][3]==0&&two[1][4]==762);
 set<uint32_t> expected;for(int i=0;i<k;i++)for(int j=k;j<2*k;j++)expected.insert((1u<<i)|(1u<<j));assert(terminal==expected);
 int edges=0;for(auto b:a)edges+=__builtin_popcount(b);edges/=2;assert(edges==158);
 cout<<"{\n\"status\":\"PASS\",\"construction\":\"direct adjacency, independent of author data\",\"order\":"<<n<<",\"size\":"<<edges<<",\"full_subset_tests\":"<<((1u<<N)+(1u<<n))<<",\"Maxine_states\":"<<states<<",\"Maxine_arcs\":"<<arcs<<",\"Maxine\":2,\"gamma\":1,\"gamma2\":4,\"base_gamma\":3,\"base_gamma2\":4,\n";
 auto out=[&](const vector<uint64_t>&b){cout<<'[';for(int i=0;i<=n;i++)cout<<(i?",":"")<<b[i];cout<<']';};
 cout<<"\"base_domination_by_cardinality\":";out(dom[0]);cout<<",\n\"base_two_domination_by_cardinality\":";out(two[0]);cout<<",\n\"joined_domination_by_cardinality\":";out(dom[1]);cout<<",\n\"joined_two_domination_by_cardinality\":";out(two[1]);
 cout<<",\n\"terminal_masks\":[";bool first=true;for(auto s:terminal){if(!first)cout<<',';first=false;cout<<s;}cout<<"],\n\"adjacency_masks\":[";for(int v=0;v<n;v++)cout<<(v?",":"")<<a[v];cout<<"]\n}\n";
}
