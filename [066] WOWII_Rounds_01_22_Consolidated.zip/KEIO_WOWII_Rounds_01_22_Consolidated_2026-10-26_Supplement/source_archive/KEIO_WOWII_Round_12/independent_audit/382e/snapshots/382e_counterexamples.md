# Statement, definitions, and prior construction

All graphs are finite and simple. A set $D$ is 2-dominating if every
vertex outside $D$ has at least two neighbors in $D$. Its minimum size
is $\gamma_2(G)$. Ordinary domination requires one such neighbor and has
minimum size $\gamma(G)$. A *Maxine run* repeatedly deletes a vertex of
maximum degree in the current induced graph until no edges remain. We
use $\operatorname{Maxine}(G)$ for the largest possible number of
remaining vertices over all tie-breaking choices. Original WOWII row
382e asserts $$\label{eq:target}
 \gamma_2(G)\leq\operatorname{Maxine}(G)+\gamma(G)$$ for every connected
graph of order greater than two [@wow]. Our examples have equal output
size for *every* run, so no choice-dependent interpretation can remove
the violation.

DeLaViña, Larson, Pepper, and Waller prove the related valid inequality
$\gamma_2\leq\gamma+\alpha$ as a special case of their Theorem 6 and
Corollary 7 [@dlpw]; this is not the Maxine inequality. The
forced-deletion mechanism has prior art: Cao and Eppstein's 2018
comments describe retaining the edges of a triangle-free cubic graph and
adding a degree-two vertex on each edge. Minimum-degree deletion removes
the new vertices first [@ce]. We credit that mechanism. Here the private
vertices instead have *three* prescribed neighbors, including a common
distinguished vertex. The changed neighborhoods and a universal-vertex
construction give the domination obstruction below. We do not claim a
smallest counterexample or first-ever worldwide discovery;
source-priority conclusions must be limited to the accompanying bounded
audit.

# The base graph

Fix $k\geq4$. Let $$A=\{a_0,a_1,\ldots,a_{k-1}\},\qquad
 B=\{b_0,b_1,\ldots,b_{k-1}\},\qquad
 X=\{x_{ij}:1\leq i\leq k-1,\ 0\leq j\leq k-1\}.$$ Define $H_k$ as
follows: retain every edge between $A$ and $B$; for each $x_{ij}$ add
exactly the three edges to $a_0,a_i,b_j$; add no other edges. Put
$F_k=\overline{H_k}$. Thus $|F_k|=2k+k(k-1)=k^2+k$. Equivalently, $A$,
$B$, and $X$ each induce a clique in $F_k$; there are no $A$--$B$ edges,
and $x_{ij}$ is adjacent to every core vertex except $a_0,a_i,b_j$. In
particular, $$\label{eq:special}
 N_{F_k}(a_0)=A\setminus\{a_0\}.$$

::: {#lem:maxine .lemma}
**Lemma 1**. *Every Maxine run on $F_k$ leaves exactly two vertices, one
in $A$ and one in $B$.*
:::

::: proof
*Proof.* On any fixed surviving vertex set, maximum-degree deletion in a
graph is minimum-degree deletion in its complement. As long as a vertex
of $X$ remains in $H_k$, it has degree three, while every core vertex
has degree at least $k\geq4$, because the retained $K_{k,k}$ is still
present. Consequently every run deletes all of $X$ before any core
vertex. The remaining graph in $F_k$ is $K_k\sqcup K_k$. Deleting
positive-degree vertices cannot delete the last, isolated vertex of
either clique. The terminal set therefore has one vertex from each
clique. ◻
:::

::: {#lem:domination .lemma}
**Lemma 2**. *For every $k\geq4$, $\gamma(F_k)=3$ and
$\gamma_2(F_k)=4$.*
:::

::: proof
*Proof.* First, $\{a_0,x_{10},x_{11}\}$ dominates $F_k$: $a_0$ dominates
$A$, each vertex of $B$ is adjacent to at least one of the two selected
private vertices, and every other private vertex is adjacent to both. No
pair dominates. A pair in $X$ misses $a_0$. A pair in the same core part
misses the other core part. A core pair $a_i,b_j$ misses $x_{ij}$ if
$i\ne0$, and misses $x_{1j}$ if $i=0$. A pair $a_i,x_{pq}$ misses $b_q$,
while a pair $b_j,x_{pq}$ misses $a_0$. These cases exhaust all pairs.
Since a dominating singleton could be enlarged to a dominating pair,
$\gamma(F_k)=3$.

The four vertices $\{a_1,a_2,b_0,b_1\}$ form a 2-dominating set. An
unselected core vertex has two selected neighbors in its own part. A
private vertex misses at most one selected vertex in $A$ and at most one
in $B$, so it has at least two selected neighbors.

Suppose, for a contradiction, that a three-element set $D$ is
2-dominating. If $a_0\notin D$,
equation [\[eq:special\]](#eq:special){reference-type="eqref"
reference="eq:special"} forces at least two vertices of $D$ into
$A\setminus\{a_0\}$. The one possible remaining vertex cannot supply two
selected neighbors to any unselected vertex of $B$. Such a vertex
exists, so this is impossible. Thus $a_0\in D$. The possibilities for
the other two vertices are listed below; in each row the indicated
unselected vertex has fewer than two neighbors in $D$.
$$\begin{array}{c|l}
\text{Locations of }D\setminus\{a_0\}&\text{Witness to failure}\\\hline
 A,A & \text{any vertex of }B\\
 A,B & \text{a vertex of }B\setminus D\\
 B,B & \text{a vertex of }A\setminus\{a_0\}\\
 A,\ x_{ij} & b_j\\
 B,\ x_{ij} & a_i\\
 x_{ij},\ x_{pq} & b_j
\end{array}$$ The needed unselected core vertices exist because
$k\geq4$. No smaller 2-dominating set exists either, since adjoining
vertices preserves 2-domination. Hence $\gamma_2(F_k)=4$. ◻
:::

# Connected counterexamples and amplification

Let $rF_k$ denote the disjoint union of $r$ copies of $F_k$. Form
$J_{k,r}=K_1\vee(rF_k)$ by adding a vertex $u$ adjacent to every vertex
in those copies.

::: {#thm:main .theorem}
**Theorem 1**. *For every $k\geq4$ and $r\geq1$, $J_{k,r}$ is connected
and satisfies $$|J_{k,r}|=1+r(k^2+k),\qquad
 \gamma(J_{k,r})=1,\qquad
 \operatorname{Maxine}(J_{k,r})=2r,\qquad
 \gamma_2(J_{k,r})=3r+1.$$ Every Maxine run has the stated output size.
Consequently,
$$\gamma_2(J_{k,r})-\bigl(\operatorname{Maxine}(J_{k,r})+\gamma(J_{k,r})\bigr)=r>0,$$
so WOWII 382e is false, with unbounded additive defect.*
:::

::: proof
*Proof.* The vertex $u$ is universal. No vertex in a copy of $F_k$ is
universal, since it has a nonneighbor already in that copy. Hence $u$ is
the unique maximum-degree vertex and is deleted first by every Maxine
run. The remaining graph is $rF_k$. Whenever a vertex in one component
is deleted, it has maximum degree within that component; ignoring the
interleaving therefore gives a valid local Maxine run.
Lemma [1](#lem:maxine){reference-type="ref" reference="lem:maxine"}
shows that each component contributes exactly two terminal vertices.
Thus $\operatorname{Maxine}(J_{k,r})=2r$, independently of ties.

Clearly $\gamma(J_{k,r})=1$. If a 2-dominating set contains $u$, its
intersection with each copy of $F_k$ must dominate that copy, and
conversely this condition suffices. Its minimum possible size is
therefore $1+3r$. If the set omits $u$, it must 2-dominate each copy
separately, requiring at least $4r$ vertices. Conversely, the union of
minimum 2-dominating sets in the copies also gives at least two
neighbors to $u$. It follows that
$$\gamma_2(J_{k,r})=\min\{1+3r,4r\}=3r+1,$$ using $r\geq1$ and
Lemma [2](#lem:domination){reference-type="ref"
reference="lem:domination"}. ◻
:::

# The finite witness and exact reproduction

For $k=4,r=1$, the graph has 21 vertices and 158 edges. Label
$A=\{0,1,2,3\}$, $B=\{4,5,6,7\}$, the private vertices $8,\ldots,19$ in
lexicographic order of $(i,j)$, and the universal vertex $20$. Then
$$\gamma_2=4>3=\operatorname{Maxine}+\gamma.$$ An explicit optimum
2-dominating set is $\{1,2,4,5\}$. The accompanying Python certificate
independently explores all maximum-degree deletion choices on physical
vertex subsets. It visits 4,269 states and finds precisely the 16
terminal pairs with one vertex in $A$ and one in $B$. It also rejects
every set of size at most three as 2-dominating. A separate C++
enumerator considers all $2^{21}=2,097,152$ subsets (with cardinality
pruning) and finds exactly 762 optimum 2-dominating four-sets. Neither
calculation is needed for the preceding proofs.

From the round's `twodomination` directory, run:

    python verify_382e_maxine.py
    g++ -O3 -std=c++17 verify_382e_counterexample.cpp -o /tmp/check382e
    /tmp/check382e 4

The authoritative outputs are `382e_maxine_certificate.json` and
`382e_counterexample_exact.json`. Earlier files about auxiliary proof
routes are research history, not additional WOWII closures. No
minimality claim is made for the 21-vertex witness.

::: thebibliography
9 Written on the Wall II, original row 382e and Maxine definition 111.
Original HTML preserved in the [pinned row
transcription](https://gitlab.com/ai-village-agents/village/graffiti-verification/-/blob/3be380b4222f974bedbefb228c8e75fbd9a7b3ae/data/wow2_rows_html.json);
original glossary recovered from the 12 May 2024 Wayback snapshot. E.
DeLaViña, C. E. Larson, R. Pepper, and B. Waller, *Graffiti.pc on the
2-domination number of a graph*, author preprint, Theorem 6 and
Corollary 7. <https://math1um.github.io/Research/r07.pdf>. Y. Cao and D.
Eppstein, comments of 6 January 2018 on *Will core decomposition get a
maximal clique?*, Theoretical Computer Science Stack Exchange.
<https://cstheory.stackexchange.com/questions/39903/will-core-decomposition-get-a-maximal-clique>.
:::
