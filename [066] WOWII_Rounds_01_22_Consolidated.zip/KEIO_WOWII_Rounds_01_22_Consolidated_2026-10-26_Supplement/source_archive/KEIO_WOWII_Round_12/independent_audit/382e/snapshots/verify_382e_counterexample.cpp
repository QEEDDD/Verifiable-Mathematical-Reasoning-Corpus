// Exact physical-vertex enumeration for the candidate WOWII382e counterexample.
#include <vector>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <cstdint>
using namespace std;
int main(int argc,char**argv){int k=argc>1?stoi(argv[1]):4;int n=k*k+k+1;if(n>28)return 2;vector<uint32_t>h(n),a(n);auto he=[&](int u,int v){h[u]|=1u<<v;h[v]|=1u<<u;};for(int u=0;u<k;u++)for(int v=k;v<2*k;v++)he(u,v);int x=2*k;for(int u=1;u<k;u++)for(int v=k;v<2*k;v++,x++){he(x,0);he(x,u);he(x,v);}uint32_t F=(1u<<n)-1;for(int v=0;v<n;v++)a[v]=F&~(h[v]|1u<<v);int g=n,g2=n;uint32_t gw=0,g2w=0;uint64_t ng=0,ng2=0;for(uint32_t S=0;S<=F;S++){int z=__builtin_popcount(S);if(z>g&&z>g2)continue;bool ok=true,ok2=true;for(int v=0;v<n;v++)if(!(S>>v&1)){int c=__builtin_popcount(S&a[v]);if(!c)ok=false;if(c<2)ok2=false;}if(ok){if(z<g)g=z,ng=0,gw=S;if(z==g)ng++;}if(ok2){if(z<g2)g2=z,ng2=0,g2w=S;if(z==g2)ng2++;}}
cout<<"{\"k\":"<<k<<",\"order\":"<<n<<",\"all_subsets_considered\":"<<(1u<<n)<<",\"gamma\":"<<g<<",\"gamma_witness_mask\":"<<gw<<",\"gamma2\":"<<g2<<",\"gamma2_witness_mask\":"<<g2w<<",\"number_gamma_sets\":"<<ng<<",\"number_gamma2_sets\":"<<ng2<<",\"adjacency_masks\":[";for(int v=0;v<n;v++)cout<<(v?",":"")<<a[v];cout<<"]}\n";
}
