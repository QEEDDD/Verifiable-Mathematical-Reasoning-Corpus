#!/usr/bin/env python3
"""Independent physical-vertex Maxine recursion and small-set lower certificates."""
from functools import lru_cache
from itertools import combinations
from pathlib import Path
import json
k=4;n=k*k+k+1;u=n-1
H=set((a,b) for a in range(k) for b in range(k,2*k));private=[]
for a in range(1,k):
 for b in range(k,2*k):
  x=2*k+len(private);private.append(dict(vertex=x,a=a,b=b))
  H.update([(0,x),(a,x),(b,x)])
adj=[0]*n;edges=[]
for v,w in combinations(range(n),2):
 if (v,w) not in H:
  adj[v]|=1<<w;adj[w]|=1<<v;edges.append([v,w])
F=(1<<n)-1
@lru_cache(None)
def outputs(S):
 ds=[(adj[v]&S).bit_count() if S>>v&1 else -1 for v in range(n)];m=max(ds)
 if m<=0:return frozenset([S])
 R=set()
 for v in range(n):
  if ds[v]==m:R.update(outputs(S^(1<<v)))
 return frozenset(R)
terms=outputs(F)
expected=frozenset((1<<a)|(1<<b) for a in range(k) for b in range(k,2*k))
assert terms==expected
# Separate low-cardinality domination tests, not using the C++ subset enumeration.
def domination_witness(twodom):
 for s in range(1,n+1):
  for D in combinations(range(n),s):
   S=sum(1<<v for v in D)
   if all((S>>v&1) or (adj[v]&S).bit_count()>=twodom for v in range(n)):return list(D)
# Exhaust all triples including subsets by using the direct inequality test separately.
failed_by_size={}
for s in range(4):
 cnt=0
 for D in combinations(range(n),s):
  S=sum(1<<v for v in D)
  assert any(not(S>>v&1) and (adj[v]&S).bit_count()<2 for v in range(n))
  cnt+=1
 failed_by_size[s]=cnt
W=[1,2,4,5];S=sum(1<<v for v in W)
assert all((S>>v&1) or (adj[v]&S).bit_count()>=2 for v in range(n))
assert [v for v in range(n) if adj[v].bit_count()==n-1]==[u]
res=dict(status='PASS_COUNTEREXAMPLE_382E',order=n,size=len(edges),k=k,vertex_parts=dict(A=list(range(k)),B=list(range(k,2*k)),private=private,universal=u),edges=edges,adjacency_masks=adj,Maxine=2,all_terminal_outputs=[[v for v in range(n) if S>>v&1] for S in sorted(terms)],Maxine_DP_states=outputs.cache_info().currsize,gamma=1,unique_gamma_set=[u],gamma2=4,two_domination_witness=W,all_subsets_of_size_at_most3_fail=failed_by_size,original_rhs=3,defect=1,scope='Full finite counterexample to original382e under largest-output Maxine; no minimality or global-priority claim.')
Path(__file__).with_name('382e_maxine_certificate.json').write_text(json.dumps(res,indent=2)+'\n')
print(json.dumps({r:res[r] for r in ['status','order','size','Maxine','Maxine_DP_states','gamma','gamma2','original_rhs','defect','all_subsets_of_size_at_most3_fail']},indent=2))
