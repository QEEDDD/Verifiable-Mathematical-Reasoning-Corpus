# Independent root check of the 21-vertex #382e counterexample

The root reconstructed the graph from the construction, without reading the author's verifier. On the physical vertex graph, independent Python subset checks gave 0 two-dominating sets of sizes 1,2,3 and 762 of size4. A separate memoized recursion over all maximum-current-degree choices visited 4,269 physical states and gave both minimum and maximum terminal sizes equal to2. The only dominating singleton is vertex20. Thus gamma_2=4, gamma=1, Maxine=2, and 4>3.

The standard-library code and full adjacency are in check_root.py/results.json. The code writes its regenerated JSON to /tmp/382e_root_check.json. No NetworkX or solver assumption is required.

## Family check
Let k>=4. In H take complete bipartite core A,B of sizek each, distinguish a0, and add x_ab for a in A-{a0}, b in B, with precisely the three H-neighbors a0,a,b. Let F be its complement. Every maximum-degree-deletion run on F first deletes all private vertices, since they have current H-degree3 while core vertices retain H-degree at leastk. The residual is two disjoint k-cliques, giving exactly2 survivors.

In F, a0 has neighbors exactly A-{a0}. There is no dominating pair: two X vertices miss a0; an A+X pair misses the B endpoint of X; a B+X pair misses a0; two same-part core vertices miss the opposite part; an A+B pair misses a private vertex incident to both (if A=a0 choose any private in that B column). Any A+B+X choice dominates, so gamma(F)=3.

A two-dominating triple omitting a0 would require two vertices in A-{a0}, leaving every unselected B vertex with at most one selected neighbor. If the triple contains a0, the other two vertices must both be in B union X to give any unselected B vertex two neighbors. Two B vertices leave other A vertices with no selected neighbor except a0; two X vertices leave an unselected B endpoint with fewer than two neighbors; one B vertex and x_ab either leaves b unselected (and insufficiently dominated), or selects b and then another private in that same column has only x_ab as a selected neighbor. Thus gamma_2(F)>=4. Two distinct vertices in A-{a0} and two in B form a two-dominating four-set, so gamma_2(F)=4.

For s>=1 take J_s=K1 joined to s disjoint copies of F. Its new universal vertex is the unique dominating singleton and is forced to be the first Maxine deletion. Subsequent choices interleave local maximum-degree runs, hence Maxine(J_s)=2s. If the universal vertex belongs to a two-dominating set, its remainder must dominate each F, costing3s additional vertices. If absent, each F requires four selected vertices. Therefore gamma_2(J_s)=min(3s+1,4s)=3s+1. The original proposed bound is2s+1, with deficit s. Order is1+s(k^2+k).

This root audit addresses mathematics, not worldwide priority. The separate source gate checks the original definitions and prior-resolution evidence.
