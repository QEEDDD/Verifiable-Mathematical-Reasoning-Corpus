import itertools,json
k=4;n=k*k+k+1;u=n-1
H=[set()for _ in range(u)]
def edge(a,b):H[a].add(b);H[b].add(a)
for a in range(k):
 for b in range(k,2*k):edge(a,b)
x=2*k
for a in range(1,k):
 for b in range(k,2*k):
  for v in [0,a,b]:edge(x,v)
  x+=1
A=[set(range(n))-{v}-H[v] if v<u else set(range(u))for v in range(n)]
def dom(S,r):return all(len(A[v]&S)>=r for v in range(n)if v not in S)
assert [v for v in range(n)if dom({v},1)]==[u]
counts={}
for r in range(1,5):
 sol=[s for s in itertools.combinations(range(n),r)if dom(set(s),2)]
 counts[r]=len(sol)
 print(r,len(sol),sol[:1],flush=True)
assert counts=={1:0,2:0,3:0,4:762}
# physical maxdegree DP, quotient states unnecessary: at most2^21
from functools import lru_cache
masks=[sum(1<<v for v in a)for a in A]
@lru_cache(None)
def peel(S):
 vv=[v for v in range(n)if S>>v&1]; dd=[(masks[v]&S).bit_count()for v in vv];mx=max(dd,default=0)
 if not mx:return (S.bit_count(),S.bit_count())
 out=[peel(S^(1<<v))for v,d in zip(vv,dd)if d==mx]
 return min(a for a,b in out),max(b for a,b in out)
p=peel((1<<n)-1);print('all run sizes',p,peel.cache_info(),flush=True);assert p==(2,2)
json.dump(dict(order=n,two_domination_counts=counts,all_run_sizes=p,states=peel.cache_info().currsize,adjacency=[sorted(a)for a in A]),open('/tmp/382e_root_check.json','w'),indent=2)
