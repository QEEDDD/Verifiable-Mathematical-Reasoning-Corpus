# Independent audit: zero-slack alpha-excellence and parity classes

**Verdict: PASS, proved structural extension; no full numbered WOWII closure or novelty certification.**

## Definitions and scope

Use exactly `eta(G)=b(G)-gamma_c(G)-1`, where b is the maximum order of an induced bipartite subgraph and gamma_c is connected domination. The result concerns connected zero-slack graphs of order at least three; K2 also satisfies the conclusions directly. Even-distance sets include the root. No assertion of self-centeredness or b=2alpha is made.

## Alternating-path lemma

The frozen author note is mathematically sound. If v is in no maximum independent set I, claw-freeness and the exchange of a unique I-neighbor force exactly two I-neighbors. Start their induced path through v and choose a longest induced alternating odd path with endpoints in I. Its non-I internal vertices have no I-neighbor off the path, since they already have two independent I-neighbors. In a connected induced bipartite extension, claw-freeness forces degree at most two; a first new adjacent vertex therefore attaches only at one endpoint or at both endpoints, the latter closing an even cycle.

For a one-end attachment w, an additional I-neighbor z outside the path extends the path by w,z: z has no other path neighbor, by independence at I-vertices and the preceding claw argument at non-I vertices. Without such a neighbor, exchange all path I-vertices for all path non-I vertices together with w. The resulting independent set has the same size and contains v. The same exchange works for an even-cycle closure, where w already has two I-neighbors and hence none outside. Both cases contradict the hypothesis. Single-vertex maximality implies inclusion-maximality among connected induced bipartite subgraphs by taking a first adjacent vertex of any larger such subgraph.

## Required older inputs

The relevant colored-piece/connector construction of DeLaVina--Waller, EJC 15 (2008), R33, Theorems 4--5, was reread in the local primary `sources/leaves_reference/DW2008.txt` (corresponding proof pages 10--12). The complete odd-path specialization and empty-core proof were previously independently audited in `round_10/independent_audit/177_180/AUDIT.md`. This audit does not blindly import an AI-authored baseline.

The exact needed claw specialization can also be extracted explicitly: initialize the construction with a maximal connected induced bipartite piece containing an induced claw, and extend the claw edges to a spanning tree. Its branching vertex guarantees at least three leaves; two have the same bipartite color. Delete these two leaves rather than the usual one. The retained tree is nonempty and connected, while the opposite color remains intact; maximality of the bipartite piece guarantees that an outside vertex meeting it has neighbors in both colors. The published later-piece/connector argument therefore still dominates and connects, saving two vertices overall and giving gamma_c <= b-2. Consequently eta=0 implies claw-freeness. For a maximal odd path, its two ends have the same color, and the identical two-deletion argument gives gamma_c <= b-2. This excludes the path constructed above and proves alpha-excellence in every connected zero-slack graph.

Combined with the previously audited empty-core lemma, every vertex belongs to some but not all maximum independent sets.

## Parity injection

For any root v choose a maximum independent set I containing v. Map even-distance members to themselves and odd-distance members to a preceding even-distance neighbor. No odd member is at depth one, so no predecessor image is the root. If two odd independent vertices shared a positive-depth even predecessor p, its preceding odd neighbor q would be nonadjacent to both by the distance layers and would form a claw with them at p. A predecessor image cannot equal an even I-member because those vertices are adjacent. The map is injective, proving alpha <= |E(v)|. The previously audited empty-core/odd-layer injection similarly proves alpha <= |O(v)|. Hence both claimed bounds follow, without additional equality or radius claims.

## Independent exhaustive validation

The accompanying C++ implementation imports no author checker or graph catalogue. It enumerates every connected labeled simple graph of orders 2 through 7, computes connected domination and maximum induced bipartite order exactly, and computes every maximum independent set of each claw-free graph. For each vertex absent from all maximum independent sets it explicitly locates an alternating maximal induced odd-path certificate. For every zero-slack graph it also computes BFS layers for every root and constructs the actual two predecessor injections.

Results: 1,893,731 connected graphs; 332,808 claw-free graphs; 465,825 excluded vertices and exactly that many explicit odd-path witnesses; 2,238 zero-slack graphs (by orders 2--7: 1,1,1,13,181,2041); 15,447 zero-slack roots; 30,894 successful parity injections. All checks PASS. These checks validate the universal proof but do not replace it.

Reproduce with `g++ -std=c++17 -O3 check_independent.cpp -o /tmp/audit_alpha_excellence` and run that executable. Author file and pertinent source hashes are pinned separately.
