// Independent exact controls: all connected labeled graphs through order7.
// No author code/catalogue imported. eta=b-gamma_c-1 throughout.
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <vector>
using U=unsigned;using W=std::uint64_t;using G=std::vector<U>;
void need(bool b,const char*s){if(!b)throw std::runtime_error(s);}
int pc(U s){return __builtin_popcount(s);}
bool connected(const G&a,U s){if(!s)return false;U seen=s&-s,old=0;while(old!=seen){old=seen;for(U t=old;t;t&=t-1)seen|=a[__builtin_ctz(t)]&s;}return seen==s;}
bool independent(const G&a,U s){for(U t=s;t;t&=t-1)if(a[__builtin_ctz(t)]&s)return false;return true;}
bool bipartite(const G&a,U s){std::array<int,7>color;color.fill(-1);U unseen=s;
 while(unseen){int root=__builtin_ctz(unseen);color[root]=0;U pending=1u<<root;unseen&=~pending;
  while(pending){int u=__builtin_ctz(pending);pending&=pending-1;for(U t=a[u]&s;t;t&=t-1){int v=__builtin_ctz(t);if(color[v]<0){color[v]=1-color[u];pending|=1u<<v;unseen&=~(1u<<v);}else if(color[v]==color[u])return false;}}
 }return true;
}
bool clawfree(const G&a){for(U neighbors:a)for(U s=neighbors;s;s=(s-1)&neighbors)if(pc(s)==3&&independent(a,s))return false;return true;}
bool dominates(const G&a,U s){U covered=s;for(U t=s;t;t&=t-1)covered|=a[__builtin_ctz(t)];return covered==(1u<<a.size())-1;}
bool odd_max_path(const G&a,U s){if(pc(s)<3||pc(s)%2==0||!connected(a,s))return false;int ends=0;
 for(U t=s;t;t&=t-1){int degree=pc(a[__builtin_ctz(t)]&s);if(degree==1)++ends;else if(degree!=2)return false;}if(ends!=2)return false;
 for(int v=0;v<(int)a.size();++v)if(!(s&(1u<<v))&&(a[v]&s)&&bipartite(a,s|(1u<<v)))return false;return true;
}
int main(){try{
 W graphs=0,cfGraphs=0,zeroGraphs=0,excludedVertices=0,pathWitnesses=0,parityRoots=0,actualInjections=0;
 std::array<W,8>zeroByOrder{};
 for(int n=2;n<=7;++n){U full=(1u<<n)-1;std::vector<std::pair<int,int>>edges;for(int u=0;u<n;++u)for(int v=u+1;v<n;++v)edges.push_back({u,v});std::array<std::vector<U>,8>sub;
  for(U s=1;s<=full;++s)sub[pc(s)].push_back(s);
  for(U mask=0;mask<(1u<<edges.size());++mask){G a(n);for(int i=0;i<(int)edges.size();++i)if(mask&(1u<<i)){auto[u,v]=edges[i];a[u]|=1u<<v;a[v]|=1u<<u;}
   if(!connected(a,full))continue;++graphs;int b=0,gamma=n;
   for(int size=n;size>=1&&!b;--size)for(U s:sub[size])if(bipartite(a,s)){b=size;break;}
   bool done=false;for(int size=1;size<=n&&!done;++size)for(U s:sub[size])if(dominates(a,s)&&connected(a,s)){gamma=size;done=true;break;}
   int eta=b-gamma-1;need(eta>=0,"Negative slack");bool cf=clawfree(a);if(eta==0)need(cf,"Zero slack graph has a claw");if(!cf)continue;++cfGraphs;
   int alpha=0;std::vector<U>maximum;for(int size=n;size>=1&&!alpha;--size)for(U s:sub[size])if(independent(a,s)){alpha=size;maximum.push_back(s);}
   U unionI=0,coreI=full;for(U I:maximum){unionI|=I;coreI&=I;}
   U absent=full^unionI;excludedVertices+=pc(absent);if(absent){std::vector<U>paths;for(int size=3;size<=n;size+=2)for(U s:sub[size])if(odd_max_path(a,s))paths.push_back(s);
    U I=maximum.front();for(U vertices=absent;vertices;vertices&=vertices-1){int v=__builtin_ctz(vertices);bool found=false;
     for(U P:paths)if((P&(1u<<v))&&pc(P&I)==(pc(P)+1)/2){bool alternating=true;for(U t=P;t;t&=t-1){int u=__builtin_ctz(t);if(!(I&(1u<<u))&&pc(a[u]&P&I)!=2)alternating=false;}
      if(alternating){found=true;break;}}
     need(found,"Excluded vertex lacks maximal alternating odd path");++pathWitnesses;
    }
   }
   if(eta)continue;++zeroGraphs;++zeroByOrder[n];need(unionI==full,"Zero-slack graph not alpha-excellent");need(coreI==0,"Zero-slack graph has essential independent vertex");
   for(int root=0;root<n;++root){++parityRoots;std::array<int,7>d;d.fill(-1);d[root]=0;U seen=1u<<root,front=seen;int level=0;
    while(front){U next=0;for(U t=front;t;t&=t-1)next|=a[__builtin_ctz(t)];next&=~seen;seen|=next;++level;for(U t=next;t;t&=t-1)d[__builtin_ctz(t)]=level;front=next;}
    U even=0,odd=0;for(int u=0;u<n;++u)(d[u]%2?odd:even)|=1u<<u;need(pc(even)>=alpha&&pc(odd)>=alpha,"Parity lower bound failed");
    for(int targetParity=0;targetParity<=1;++targetParity){U I=0;for(U J:maximum)if(bool(J&(1u<<root))==(targetParity==0)){I=J;break;}need(I,"Missing required maximum independent set");U images=0;
     for(U t=I;t;t&=t-1){int u=__builtin_ctz(t),image=u;if(d[u]%2!=targetParity){image=-1;for(U s=a[u];s;s&=s-1){int v=__builtin_ctz(s);if(d[v]==d[u]-1){image=v;break;}}need(image>=0,"No predecessor");}
      need(d[image]%2==targetParity&&!(images&(1u<<image)),"Predecessor map not an injection");images|=1u<<image;
     }need(pc(images)==alpha,"Wrong injection cardinality");++actualInjections;
    }
   }
  }
 }
 std::cout<<"{\n  \"status\": \"PASS\",\n  \"connected_labeled_graphs_n2_to_n7\": "<<graphs<<",\n  \"clawfree_graphs\": "<<cfGraphs<<",\n  \"vertices_in_no_maximum_independent_set\": "<<excludedVertices<<",\n  \"explicit_alternating_maximal_odd_path_witnesses\": "<<pathWitnesses<<",\n  \"zero_slack_graphs\": "<<zeroGraphs<<",\n  \"zero_slack_by_order_2_to_7\": [";for(int n=2;n<=7;++n){if(n>2)std::cout<<',';std::cout<<zeroByOrder[n];}
 std::cout<<"],\n  \"zero_slack_roots_checked\": "<<parityRoots<<",\n  \"actual_parity_injections_constructed\": "<<actualInjections<<"\n}\n";return 0;
 }catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
