# Further zero-slack structure: every vertex occurs in some maximum independent set

This is an extension of the audited alternating-path argument, kept separate while the main manuscript is frozen for independent review. It is not a full numbered WOWII resolution.

## Lemma

Let `G` be a nontrivial connected claw-free graph. If a vertex `v` belongs to no maximum independent set, then `G` has an inclusion-maximal connected induced bipartite odd-order path with at least three vertices.

**Proof.** Fix a maximum independent set `I`. The vertex `v` has exactly two neighbors in `I`: no neighbor would allow adding it, one neighbor would allow replacing that neighbor by `v`, and three independent neighbors would be a claw. Start with the induced alternating path `a-v-b` through its two `I`-neighbors. Choose a longest induced odd path containing `v`, alternating between `I` and its complement, with endpoints in `I`.

As in the main manuscript, every internal non-`I` vertex already has two neighbors in `I` and therefore has no further neighbor in `I`. A bipartite extension must attach to one endpoint or close an even cycle. A one-end attachment with a further `I`-neighbor extends the odd alternating path by two vertices, a contradiction. A one-end attachment with no further `I`-neighbor, or an even-cycle closure, permits replacing the path's `I` vertices by its non-`I` vertices and the newly added vertex. This yields an independent set of equal maximum size containing `v`, contradiction. Thus the odd path is maximal connected induced bipartite. QED.

## Consequence

The prior odd-path DW refinement excludes such a path when `eta=0`. Therefore every vertex of a zero-slack graph belongs to a maximum independent set. Together with the essential-vertex result, every vertex belongs to **some but not all** maximum independent sets.

The baseline gives claw-freeness for all zero-slack graphs, so the conclusion applies to every connected zero-slack graph of order at least three, not merely an additionally assumed subclass.

## Both parity classes contain at least alpha vertices

For a root `v`, choose a maximum independent set `I` containing `v`. Map every odd-distance member of `I` to a preceding even-distance neighbor, and map every even-distance member of `I` to itself. Two independent odd vertices cannot share a positive-depth even predecessor: that predecessor's preceding odd neighbor would complete a claw. The root cannot be a predecessor image, because it belongs to `I` and hence has no `I` neighbor. Nor can a predecessor image coincide with an even member of `I`. This gives an injection of `I` into `E(v)`, proving `alpha<=|E(v)|`.

The main manuscript's empty-core result similarly gives `alpha<=|O(v)|`. Thus in every zero-slack graph,

`alpha <= min{|E(v)|,|O(v)|}` for every root `v`.

The even-class claim is an additional structural restriction; no inference of self-centeredness, bipartite equality `b=2alpha`, or full 177/180 outside the proved subclass is made.
