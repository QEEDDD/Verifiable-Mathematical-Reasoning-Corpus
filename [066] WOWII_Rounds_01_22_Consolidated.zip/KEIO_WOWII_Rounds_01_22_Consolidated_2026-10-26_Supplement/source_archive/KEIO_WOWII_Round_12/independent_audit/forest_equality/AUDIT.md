# Independent audit: forest equality and the induced-matching candidate route

**Verdict: PASS after one local proof correction. Auxiliary results only.**
26 October 2026. No proof of the general candidate f≥r+im or of full
WOWII61 is certified.

Audited final file: `round_11/independence/induced_matching_route.md`,
SHA256 `ae098479dbcf3b2d4ee8c18d8421276bba7f8c322180d5f3ac5bc03b4ff8ef6b`.
The companion `residue_dependencies.md` is also audited and snapshotted.
Here r denotes **Havel–Hakimi residue**, not radius; f is maximum induced
forest order; im is maximum induced matching cardinality; ν is ordinary
matching number.

Accepted assertions:

1. Every finite forest F satisfies |F|≥r(F)+im(F), with equality exactly
   when every component is an isolate or edge except possibly one star
   on at least three vertices.
2. If a smallest counterexample to the unproved general candidate
   f(G)≥r(G)+im(G) exists, then it is connected and cyclic; deletion of
   any maximum-degree vertex preserves residue, loses exactly one induced
   matching edge, and leaves a candidate-tight graph.
3. No maximum-degree vertex of such a smallest counterexample is a feedback
   vertex. This is **not** a statement about all feedback-vertex-number-one
   graphs, whose feedback vertex need not have maximum degree.

## 1. Correction identified during audit

The original disconnected-forest paragraph claimed that any nonstar
component implies r(F)≤α(F)−1. This is false: P4 has r=α=2, while
ν=2 and im=1. The connected argument proves strictness of r+im versus
order, not necessarily strictness of r versus α in both of its cases.

The author replaced that sentence by the correct calculation

    r(F)+im(F) ≤ Σ_T(r(T)+im(T)) < Σ_T |T| = |F|

whenever a nonstar component occurs. Induced matching is additive across
components. This repairs the proof without changing the theorem or any
later result. The final snapshot contains the correction and explicitly
notes the P4 distinction. The earlier snapshot is retained only as
`induced_matching_route_before_audit_repair.md`, not as an accepted proof.

## 2. Classical residue dependency, explicitly reduced and checked

The exact established graphical majorization result was checked in the
primary [Hiller manuscript](https://arxiv.org/html/2206.05820), Lemma1.4 and
Theorem1.6, which credit Favaron–Mahéo–Saclé and Triesch. For equal-length,
equal-total graphical lists D₁≽D₂, it gives r(D₁)≥r(D₂). This also follows
from Triesch's elimination-sequence majorization: at the last positive
entry of the smaller sequence, the larger sequence has already reached
the same full sum, so it has no more positive entries and at least as
many terminal zeros. The earlier matching-padding audit verified the
original publisher's description of Triesch's theorem as well. This is
a precisely identified established input, not an unreviewed AI assertion.

The remaining residue facts were independently derived in this audit,
and the author incorporated the derivations in the companion note:

**Largest-coordinate decrement lemma.** Among choices of d distinct
positive entries to decrement, decrementing the d largest entries gives
a majorization-minimal result. If a lower original entry is decremented
but a higher one is not, exchanging these choices transfers one unit
from the higher surviving coordinate to the lower one, or just permutes
the pair when their original values agree. The sorted prefix sums cannot
increase. Repeated exchanges give the canonical choice.

**Positive maximum-degree deletion.** Remove the same largest degree d>0
from D(G). Actual deletion of v decrements its neighbor entries, whereas
the HH step decrements the d largest tail entries. Both residual lists
are graphical, have equal order and sum, and the former majorizes the
latter. Hence r(G−v)≥r(HH(D(G)))=r(G). The condition d>0 is essential:
deleting a vertex from an edgeless graph lowers residue by one. It holds
automatically in the smallest-counterexample application.

**Disjoint-union subadditivity.** Induct on the total length of graphical
lists A,B. The all-zero case is equality. Otherwise choose a largest
pooled positive head in A. The global HH residual C is majorization-minimal
among the tail decrements; separately reducing the head within A gives
S=HH(A)∪B≽C. Residue order and induction yield

    r(A∪B)=r(C)≤r(S)≤r(HH(A))+r(B)=r(A)+r(B).

All intermediate lists are graphical. This transparently proves the needed
ordinary-residue fact without access to the full 2014 article. The established
disjoint-union result is credited to Amos–Davila–Pepper, whose
[primary publisher abstract](https://www.sciencedirect.com/science/article/pii/S0012365X13005141)
independently confirms its scope. Theorem numbering supplied from secondary
transcriptions is not needed for this proof dependency.

Finally r(G)≤α(G), also explicitly stated as Hiller's Theorem1.3 with
classical attribution, can itself be checked from the preceding deletion
lemma by induction: delete a positive maximum-degree vertex until the
edgeless base, using r(G)≤r(G−v)≤α(G−v)≤α(G). Thus every essential residue
use in the candidate reduces to the single precise established graphical
majorization theorem, together with the elementary arguments above.

## 3. Forest equality proof

The inequality follows from r≤α, the forest identity α=|F|−ν, and
ν≥im. The forest identity can be proved by leaf induction: at a leaf v
with neighbor u, a maximum matching can contain uv and a maximum independent
set can contain v but not u, giving the matching/independence recurrences
after deleting u,v; isolates are immediate.

For a connected nonstar tree, ν>im already gives strictness of r+im.
Otherwise an induced matching M of size a=ν=im is also an ordinary maximum
matching. Every edge of M has a leaf endpoint: if both endpoints had another
neighbor, those two neighbors would be distinct unmatched vertices, and
the resulting four-vertex path would augment M.

The chosen support endpoints form an independent vertex cover A. The
unmatched vertices are independent by maximality of the ordinary matching;
the matched leaf partners have no other edges. Hence the graph is bipartite
between A and its complement. In a connected nonstar, |A|≥2 and two supports
x,y have a common neighbor z. This z is not an endpoint of any edge of M:
it is neither a support nor a private matched leaf.

Switching xx',yy' to xy,x'y' preserves every vertex degree and simplicity.
The resulting graph has the vertex-disjoint triangle xyz, edge x'y', and
the other a−2 matching edges. Its vertex cover number is at least a+1,
irrespective of any cross edges. Therefore its independence number is
at most |T|−a−1, and the unchanged degree-sequence residue is also at most
that value. The switch does not presume any edge-addition monotonicity of
residue. Connected strictness follows, and the corrected component sum
handles any forest containing a nonstar component.

If at least two remaining components are nontrivial stars, the second
switch joins their centers and their two removed leaves. Keeping another
leaf at each center supplies three disjoint matching edges where the
original two stars supplied two. Other components retain one matching
edge each. Degree sequence is preserved, and α of the new realization is
at most |F|−ν(F)−1. Since ν=im for unions of stars, equality is impossible.

Conversely one star K_(1,d), e edges, and i isolates has HH degree list
(d,1^(d+2e),0^i). Removing d leaves 2e ones and d+i zeros; the e matching
heads then leave residue d+e+i. Its induced matching number is e+1, and
these sum to its order. With no nontrivial star, r=e+i and im=e. The empty
forest is included harmlessly. This completes both directions.

## 4. Smallest-counterexample restrictions and apex contradiction

The connectedness reduction is valid because f and im are additive across
components and r is subadditive. A forest cannot be a counterexample by
the theorem. For every maximum-degree vertex v, put H=G−v. Minimality,
positive maximum-degree deletion, and im(H)≥im(G)−1 give

    f(G)≥f(H)≥r(H)+im(H)≥r(G)+im(G)−1.

Since G fails the integer inequality, equality holds throughout. In
particular r(H)=r(G), im(H)=im(G)−1, and f(H)=f(G). Every maximum induced
matching must therefore contain v as an endpoint. Componentwise candidate
bounds force both residue additivity and individual tightness in H.

If H were a forest, its equality classification applies. A maximum induced
matching in G uses an edge vu and must retain a maximum induced matching
of H. Therefore u is an isolate of H: using a vertex in an edge or star
component would prevent retaining that component's one required matching
edge. No edge component of H can exist, because its retained edge forbids
v from attaching to it, contradicting connectedness. H cannot consist only
of isolates, as then G would be a star.

Thus H is one nontrivial star K_(1,d) and p≥1 isolates. The vertex v avoids
the star center, meets a star leaves with 2≤a≤d−1, and is adjacent to all
p isolates. The lower bound a≥2 follows because G is cyclic. Its maximum
degree condition gives a+p≥d≥3. The degree list is exactly

    (a+p, d, 2^a, 1^(d−a+p)).

The first HH head a+p decrements d, all a twos, and p−1 ones, leaving
(d−1,1^(d+1),0^(p−1)). The next head d−1 leaves exactly two ones, and
the final positive head removes that edge. Thus r(G)=|G|−3=d+p−1,
whereas r(H)=d+p, contradicting the forced equality. All boundary and
tie cases meet the assumptions, including a+p=d.

## 5. Independent finite controls

The C++ checker generates **all labeled forests of orders 0–8** directly
by acyclic-edge recursion with rollback connectivity; no catalogue or author
code is imported. It computes ordinary and induced matchings by exact edge
subsets, independence by vertex subsets, and HH residue using degree
multiplicities with deferred decrements rather than the author's sorted list.

* Forest counts by order: 1,1,2,7,38,291,2932,36961,561948.
* **602,181** forests checked; **12,173** equality cases exactly match the
  characterization; **280,393** are connected trees.
* **38,010** nonstar-tree switches physically constructed and checked for
  identical degrees and the promised independence drop.
* **10,940** two-star switches checked for the ordinary-matching gain and
  independence cap.
* **1,105,447** positive maximum-degree deletions checked; component residue
  subadditivity also checked on every forest.
* **229,021** apex parameter triples, with 3≤d≤80 and p≤100, satisfy the
  exact three-positive-head HH identity.

All passed. Reproduce:

```sh
d=wowii_rounds/round_12/independent_audit/forest_equality
g++ -O3 -std=c++17 "$d/check_independent.cpp" -o /tmp/audit_forest_equality
/tmp/audit_forest_equality
```

The analytic proofs, not the finite checks, establish the auxiliary results.
The route from the **unproved** general candidate to original WOWII61 is
correct: take every third edge of a diametral induced path, obtaining an
induced matching of size ceil(diameter/3). But the candidate itself remains
unproved, and its finite random-search counts are not upgraded to a theorem
by this audit. **No remaining gap in the corrected auxiliary claims; no
full WOWII61 closure or worldwide-priority claim.**
