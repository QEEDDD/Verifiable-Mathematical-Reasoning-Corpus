# An induced-matching route to WOWII 61: candidate and proved boundary

**The general inequality in this note is a candidate, not a theorem.** It is
not a closure of WOWII 61. The forest equality classification and the
smallest-counterexample restrictions below have self-contained proofs.

Write `im(G)` for the maximum size of an induced matching: a matching whose
endpoints induce exactly its matching edges. Consider

\[
\boxed{f(G)\ge r(G)+\operatorname{im}(G).}\tag{C}
\]

## Why (C) would prove the full original 61

A diametral geodesic of length `D` is an induced path. Its edges in positions
`0,3,6,...` form an induced matching of size `ceil(D/3)`. Thus (C), if proved
for every graph, would imply original 61 without an additional graph-theoretic
bridge. Unlike the earlier sequence-side auxiliary result, this implication
is complete. **The missing part is a proof of (C) itself.**

The analogous distance-three *vertex* packing statement is false: a triangle
with pendant leaves at two distinct triangle vertices has `f=4`, `r=3`, and
two vertices at distance three. Induced matching is a different invariant.

## Exact equality classification for forests

**Theorem.** For a forest `F`,

\[
|F|\ge r(F)+\operatorname{im}(F).
\]

Equality holds if and only if every component is an isolated vertex or an
edge, except possibly one component that is a star on at least three vertices.

### Proof of the inequality

The classical residue bound and the forest matching identity give

\[
r(F)\le\alpha(F)=|F|-\nu(F)
\le |F|-\operatorname{im}(F).
\]

Here `nu` denotes ordinary matching number.

### Strictness for every connected nonstar tree

If `nu(T)>im(T)`, the preceding inequality is already strict. Suppose instead
`nu(T)=im(T)=a`, and fix an induced matching `M` of size `a`. It is also a
maximum ordinary matching.

Every edge `xy` of `M` has a leaf endpoint. Otherwise `x` and `y` have neighbors
`u` and `w` outside the edge. Because `M` is induced, neither neighbor is an
endpoint of another edge of `M`. They are distinct, since `T` has no triangle.
The path `u-x-y-w` augments the matching, a contradiction.

Choose the nonleaf endpoint of each edge of `M` as a support; on an isolated
edge choose either endpoint. The resulting set `A` has size `a`, is
independent, covers every edge, and each of its vertices has a private leaf
partner in `M`. To see the cover property, unmatched vertices are independent
(otherwise `M` is not maximum), and an edge incident with a leaf partner is
its unique matching edge. Thus all edges meet `A`.

If `T` is connected and not a star then `a>=2`. Connectivity of the bipartite
graph with parts `A` and `V(T)\A` gives two distinct supports `x,y` with a common
neighbor `z`. Let their private leaf partners be `x',y'`. Perform the
degree-preserving switch

\[
xx',yy'\quad\longmapsto\quad xy,x'y'.
\]

The two new edges did not exist: `A` is independent and `x',y'` are distinct
private leaves. The resulting simple graph `T'` has the same degree sequence,
and hence the same residue, as `T`. It contains the triangle `xyz`, the edge
`x'y'`, and the other `a-2` edges of `M` on mutually disjoint vertex sets. Any
vertex cover of `T'` needs at least `2+1+(a-2)=a+1` vertices. Cross edges, if
present, cannot weaken this lower bound. Therefore

\[
r(T)=r(T')\le\alpha(T')\le |T|-a-1
=\alpha(T)-1.
\]

This proves strictness for a connected nonstar tree. Notice that no assertion
about residue being monotone under edge addition or deletion was used; the
switch preserves the entire degree sequence.

### Disconnected forests

If any component is a nonstar tree, the classical disjoint-union inequality
`r(F)<=sum r(T)` and the preceding strictness give
`r(F)<=alpha(F)-1`; again the desired inequality is strict.

Suppose all components are stars, edges, or isolates, and at least two stars
have at least three vertices. Let their centers be `x,y`, and choose distinct
leaves `x1,x2` at `x` and `y1,y2` at `y`. Switch

\[
xx_1,yy_1\quad\longmapsto\quad xy,x_1y_1.
\]

In this degree-equivalent realization, the three edges
`xx2`, `yy2`, `x1y1`, together with one edge in each other nontrivial component,
form a matching one larger than the matching number of the original forest.
Thus its independence number, and hence the common residue, is at most
`|F|-nu(F)-1`. Since `nu(F)=im(F)` for a disjoint union of stars, equality is
again impossible.

Conversely, let the forest consist of `K1,d` with `d>=2`, `e` disjoint edges,
and `i` isolates. Its degree sequence is

\[
(d,1^{d+2e},0^i).
\]

After the degree-`d` Havel--Hakimi head is removed, there remain `2e` ones and
`d+i` zeros. Hence `r=d+e+i`, while `im=1+e` and
`|F|=d+1+2e+i`. Equality follows. If there is no nontrivial star, a disjoint
union of `e` edges and `i` isolates has `r=e+i`, `im=e`, again giving equality.
This proves the classification.

## Structure of a smallest counterexample to (C)

If (C) fails, choose a counterexample of minimum order. It is connected: forest
order and induced matching number are additive across components, while the
residue is at most the sum of component residues. It is not a forest by the
theorem just proved.

For **every** maximum-degree vertex `v`, put `H=G-v`. Maximum-degree deletion
does not decrease residue. Deleting one vertex loses at most one edge of an
induced matching, so `im(H)>=im(G)-1`. Minimality gives

\[
f(G)\ge f(H)\ge r(H)+\operatorname{im}(H)
\ge r(G)+\operatorname{im}(G)-1.
\]

Since `G` fails (C), equality holds throughout. In particular,

\[
\boxed{
r(H)=r(G),\quad
\operatorname{im}(H)=\operatorname{im}(G)-1,\quad
f(G)=f(H)=r(G)+\operatorname{im}(G)-1.
}
\tag{1}
\]

Thus every maximum-degree vertex belongs to every maximum induced matching.
The graph `H` is candidate-tight; its residue is additive across components,
and every one of its components is tight as well.

## No maximum-degree vertex of a smallest counterexample is a feedback vertex

**Proposition.** For a smallest counterexample to (C), `G-v` contains a cycle
for every maximum-degree vertex `v`.

**Proof.** Suppose `H=G-v` is a forest. By (1) it is tight, so the classification
above applies. Since `im(G)=im(H)+1`, a maximum induced matching in `G` consists
of an edge `vu` together with a maximum induced matching in `H`.

The vertex `u` must be an isolate of `H`. If it belonged to an edge component,
that component's matching edge would be lost. If it belonged to the possible
star component, every star edge meets or has an endpoint adjacent to `u`, so
that component's one matching edge would be lost. Both alternatives contradict
retaining `im(H)` edges.

There can be no edge component of `H`: its sole edge would have to remain in
the induced matching, forcing `v` to have no neighbor in that component,
contrary to connectedness of `G`. If `H` has no nontrivial star either, then
`G` is itself a star, already excluded. Thus `H` is one star `K1,d` plus `p>=1`
isolates. Write `w` for its center.

To retain a star edge in the induced matching, `v` is not adjacent to `w` and
misses at least one star leaf. Connectedness requires it to meet some star
leaf. Let it meet exactly `a` star leaves. All `p` isolated vertices are
neighbors of `v`. As `G` is not a forest, `a>=2`; and `a<=d-1`, so `d>=3`.
Maximum degree of `v` gives `a+p>=d`.

The degree sequence of `G` is therefore

\[
(a+p,\ d,\ 2^a,\ 1^{d-a+p}),
\qquad a+p\ge d\ge3.
\]

In the first Havel--Hakimi step, choose the head `a+p`. It decrements the
degree `d`, all `a` entries equal to two, and `p-1` ones. The residual list is

\[
(d-1,\ 1^{d+1},\ 0^{p-1}).
\]

The next positive head `d-1` leaves exactly two ones; the third positive head
removes their edge. Consequently there are exactly three positive heads and

\[
r(G)=|G|-3=d+p-1,
\qquad r(H)=d+p,
\]

contradicting (1). This proves the proposition.

The proposition is a restriction on a smallest counterexample to the
**stronger candidate**, not a proof that arbitrary feedback-vertex-number-one
graphs satisfy the candidate: their feedback vertex need not have maximum
degree. No such extra claim is made.

## Exact checks and remaining gap

`check_induced_matching_candidate.py` tests the candidate itself, not merely
the diameter consequence. It passes all 995 connected nontrivial atlas graphs
and 24,479 additional connected seeded draws through order 24, for 25,474
evaluated instances in total. Draws need not be distinct. An exact compatibility
clique computation gives induced matching number, and exhaustive vertex subsets
certify a forest at the required size. The full log is retained.

`search_planted_matching.py` is a separate stress test with a prescribed
induced matching and arbitrary random edges through additional vertices. Its
terminal result, when available, is recorded separately; it is not part of the
preceding count.

The general step is still missing: a smallest counterexample could have every
maximum-degree deletion leave candidate-tight cyclic components. Neither the
forest equality theorem nor finite zero searches exclude this possibility.
No original WOWII resolution is counted.
