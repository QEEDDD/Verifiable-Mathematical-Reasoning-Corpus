# Established residue dependencies, with transparent derivations

This note records an audit contribution by the independent proof auditor. None
of these classical residue facts is claimed as new. The main dependency is the
established equal-sum graphical degree-majorization theorem of
Favaron--Maheo--Sacle/Griggs--Kleitman/Triesch: graphical degree majorization
implies the corresponding residue order. It follows in particular from
Triesch's elimination-sequence majorization theorem, stated and credited in
Theorem 1.6 of [Hiller's primary research manuscript](https://arxiv.org/html/2206.05820).

## 1. Residue order from elimination-sequence majorization

For two graphical lists of the same length and total degree, their elimination
sequences have the same length and total sum (the number of edges). If `A`
majorizes `B`, and `B` has `t` positive entries, then its first `t` entries sum
to the full total. Majorization forces the same prefix of `A` to equal that
total, so `A` has at most `t` positive entries. Its number of zeros is therefore
at least that of `B`. Applied to Triesch's theorem, this gives

\[
D_1\succeq D_2\quad\Longrightarrow\quad r(D_1)\ge r(D_2).
\]

## 2. Decrementing the largest entries is majorization-minimal

Fix a nonnegative list and a number `d` of distinct positive entries to
decrement by one. Among all such choices, decrementing the `d` largest entries
produces a majorization-minimal sorted result. Indeed, if a smaller entry is
decremented but a larger entry is not, exchange those choices. This transfers
one unit from the larger surviving coordinate to the smaller surviving
coordinate, or merely permutes equal coordinates; it cannot increase any
sorted-prefix sum. Repeating exchanges reaches the largest-entry choice.

## 3. Deleting a maximum-degree vertex cannot decrease residue

Assume `Delta(G)>0`. Let `v` have maximum degree `d>0` in `G`, and remove the corresponding degree
head. The canonical Havel--Hakimi step decrements the `d` largest tail entries.
The actual degree sequence of `G-v` decrements the `d` neighbor entries instead.
By the preceding lemma, the latter list majorizes the canonical residual list;
both lists are graphical and have equal degree sum. Hence

\[
r(G-v)\ge r(\operatorname{HHstep}(D(G)))=r(G).
\]

For a nonempty graph with maximum degree zero, deleting a vertex lowers
residue by one instead; the asserted form is used only when `d>0`. All
maximum-degree deletions in the connected nontrivial or cyclic arguments meet
this condition.

## 4. Disjoint-union subadditivity

For any two graphs with degree lists `A,B`,

\[
r(A\cup B)\le r(A)+r(B).
\]

Induct on their total length. If both lists are zero lists, equality is clear.
Otherwise choose a largest pooled positive degree head, say in `A`, of value
`d`. The global canonical reduction decrements the `d` largest entries of the
pooled tail, producing a list `C`. Instead decrement the `d` largest remaining
entries of `A` alone; this is feasible because `A` is graphical and its head
is positive. It produces `S=HHstep(A) union B`. Both `C,S` are graphical and
have the same length and degree sum. Largest-entry decrement minimality gives
`S` majorizing `C`. Therefore

\[
\begin{aligned}
r(A\cup B)&=r(C)\le r(S)\\
&\le r(\operatorname{HHstep}(A))+r(B)\\
&=r(A)+r(B),
\end{aligned}
\]

where the middle line uses induction on the shorter total length. Iteration
gives the corresponding statement for any finite number of components.

This is the classical Disjoint Union Lemma, Theorem 11 of D. Amos, R. Davila
and R. Pepper, *On the k-residue of disjoint unions of graphs with applications
to k-independence*, Discrete Mathematics 321 (2014), 24--34,
[primary publisher page](https://www.sciencedirect.com/science/article/pii/S0012365X13005141).
That paper's Lemma 8 supplies the maximum-degree residual comparison, and
Theorem 16 applies the two facts together at a maximum-degree cut vertex.

The ordinary bound `r(G)<=alpha(G)` is the established Havel--Hakimi residue
bound, with primary reference J. R. Griggs and D. J. Kleitman, *Independence and
the Havel--Hakimi residue*, Discrete Mathematics 127 (1994), 209--212,
[publisher page](https://www.sciencedirect.com/science/article/pii/0012365X9200479B).

These derivations make the auxiliary forest proof independent of access to the
full 2014 paper, but do not replace the credit owed to the existing theorems.
