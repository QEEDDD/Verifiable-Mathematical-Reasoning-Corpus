"""Exact guards for the proved forest equality theorem and apex algebra."""
import json
from pathlib import Path
import networkx as nx
from check_induced_matching_candidate import induced_matching
from verify_explicit_witnesses import adjacency, residue


def hh(degrees):
    d = sorted(degrees, reverse=True)
    positive_heads = 0
    while d and d[0]:
        h = d.pop(0)
        assert h <= len(d) and min(d[:h]) > 0
        d[:h] = [x-1 for x in d[:h]]
        d.sort(reverse=True)
        positive_heads += 1
    return len(d), positive_heads


def expected_equality(G):
    big_stars = 0
    for vertices in nx.connected_components(G):
        H = G.subgraph(vertices)
        if len(H) <= 2:
            continue
        if max(dict(H.degree()).values()) != len(H)-1:
            return False
        big_stars += 1
    return big_stars <= 1


def check_forest(G):
    a = adjacency(len(G), G.edges())
    r = residue(a)
    im = len(induced_matching(G))
    assert len(G) >= r+im
    assert (len(G) == r+im) == expected_equality(G)


def main():
    forests = 0
    for G in nx.graph_atlas_g():
        if len(G) and nx.is_forest(G):
            check_forest(G)
            forests += 1
    trees = 0
    for n in range(2, 15):
        for G in nx.nonisomorphic_trees(n):
            check_forest(G)
            trees += 1
    apex = 0
    for d in range(3, 51):
        for a in range(2, d):
            for p in range(max(1, d-a), 61):
                r, heads = hh([a+p, d]+[2]*a+[1]*(d-a+p))
                assert heads == 3 and r == d+p-1
                apex += 1
    result = dict(status="PASS", atlas_forests_order_1_through_7=forests, nonisomorphic_trees_order_2_through_14=trees, apex_degree_parameter_triples=apex, scope="proved auxiliary forest equality and exact three-head degree identity; not full candidate")
    output = json.dumps(result, indent=2)
    (Path(__file__).resolve().parent / "forest_equality_results.json").write_text(output+"\n")
    print(output)


if __name__ == "__main__":
    main()
