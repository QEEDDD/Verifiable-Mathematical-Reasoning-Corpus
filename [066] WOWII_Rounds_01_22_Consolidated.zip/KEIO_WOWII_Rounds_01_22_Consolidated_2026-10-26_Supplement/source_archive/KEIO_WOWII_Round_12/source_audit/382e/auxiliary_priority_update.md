# Auxiliary Maxine bridges: exact prior construction, and conceptual review

Checked 2026-10-26. This note supersedes the initial negative literature checkpoint in sourceaudit.md.

## Prior result found

**Yixin Cao and David Eppstein, comments dated 6 January 2018** on [“Will core decomposition get a maximal clique?”](https://cstheory.stackexchange.com/questions/39903/will-core-decomposition-get-a-maximal-clique), give the precise construction later rediscovered in this round. Cao adds a private degree-two vertex to every retained edge of Petersen; Eppstein says any triangle-free cubic base works and explicitly names K_{3,3}. They explain that the new vertices are removed before the core, leaving an edge. This is primary public mathematical discussion, not a journal article.

Complementation converts this into the team's 15-vertex well-covered example with i=α=3 and best-run Maxine=2. The unique-universal-vertex lift then disproves the residual bridge as an elementary consequence. **Neither auxiliary phenomenon should be presented as a newly discovered counterexample.**

## Independent conceptual review

For H=K_{k,k}⋄K1, k≥3, every maximal clique is an edge together with its private vertex, so i(complement H)=α(complement H)=3. While private vertices remain, they have degree2 and each core vertex retains at least k neighbors; all minimum-degree deletions therefore remove private vertices first. Starting from K_{k,k}, minimum-degree deletion until a clique remains ends at K_{1,1}, for every tie choice. Complementation exchanges minimum-degree and maximum-degree deletion, proving best-run Maxine=2.

No vertex of complement H is universal. Adjoining a new universal vertex u makes {u} the unique minimum dominating set and forces u to be the first Maxine deletion. The residual independent domination is3 and Maxine remains2. This independently verifies both failures.

The lift is **not** a WOWII382e refutation: γ2=3=Maxine+γ. For the upper bound select u and the two private vertices belonging to disjoint core edges; for the lower bound every old vertex has at least two old nonneighbors, excluding a two-element 2-dominating set.

The operation ⋄ is itself standard: Yaoping Hou and Wai-Chee Shiu, *The spectrum of the edge corona of two graphs*, Electronic Journal of Linear Algebra20(2010),586–594, Definition1.1, https://journals.uwyo.edu/index.php/ela/article/download/791/791/791 . Definition and bibliographic details read from the primary journal PDF via web; direct local PDF retrieval returned502. The operation's age is separate from the exact2018 peeling counterexample.

## Scope distinction

Cao/Eppstein do not state the modified private neighborhoods {a0,a,b}, the universal lift's γ2=4 calculation, or a resolution of WOWII382e. Their prior construction must be credited as the peeling precursor, but it does not by itself invalidate a separately verified claim about that different inequality. No worldwide novelty judgment is made for the modified construction.

Raw primary page response: CaoEppstein2018_web.json (research cache; omit full third-party page from bundle).
