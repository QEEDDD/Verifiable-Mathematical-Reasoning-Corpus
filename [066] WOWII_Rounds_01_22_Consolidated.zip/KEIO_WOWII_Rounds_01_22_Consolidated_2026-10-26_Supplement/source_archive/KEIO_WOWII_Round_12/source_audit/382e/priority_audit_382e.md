# WOWII 382e: source and bounded-priority gate for the modified family

Checked 2026-10-26, 04:36–04:39 UTC. **Source match: PASS. No prior full resolution located in the checked public sources.** Mathematical certification is handled by the separate author/root/independent verifiers, not inferred from this status audit. Worldwide priority and the latest live curator annotation are not certified.

## Exact target

The archived original says that for a connected graph with n>2, **γ₂ ≤ Maxine+γ**. Definition90 is ordinary 2-domination: vertices outside the set need two neighbors in it. Definition49 is ordinary domination. Definition111 takes the largest independent-set survivor count obtainable by repeatedly deleting a vertex of current maximum degree. Thus a deterministic bad run alone is insufficient, while a proof valid for all tie choices meets the source definition.

Pinned original row and verbatim glossary entries are preserved in `statement_382e.json`. Original row: https://gitlab.com/ai-village-agents/village/graffiti-verification/-/blob/3be380b4222f974bedbefb228c8e75fbd9a7b3ae/data/wow2_rows_html.json . The January2010 row has historical O status. Its March2010 note and DLPW Theorem6/Corollary7 establish only the weaker **γ₂≤α+γ**; they do not settle the printed Maxine inequality. DLPW primary preprint: https://math1um.github.io/Research/r07.pdf .

## Proposed family distinguished from the old auxiliary example

The candidate presented for mathematical audit uses a K_{k,k} core with fixed a0, and one private vertex x_ab for each a≠a0 and b, with neighborhood {a0,a,b}; take its complement and adjoin a universal vertex. At k=4 it has21 vertices; the proposed values are γ₂=4, γ=1, Maxine=2. This changes the private degree from2 to3 and the domination obstruction. It is **not** the unmodified edge-corona auxiliary example, whose universal lift satisfies γ₂=3 and therefore does not refute382e.

The precise precursor is public prior work: Cao/Eppstein's January2018 retained-edge/private-vertex construction, including explicit K_{3,3}, found during this audit. Credit and scope are documented in `auxiliary_priority_update.md`. The source page does not claim the modified family or the WOWII inequality. The old construction/peeling mechanism must not be advertised as new.

## Fresh primary-status checks

- All-state GitHub issue/PR API at04:36:54UTC: `repo:google-deepmind/formal-conjectures 382e in:title,body` and the analogous `Maxine` query each returned0, with incomplete_results=false. The c5-k4 and agentic-conjectures382e queries also returned0. Global `Maxine domination in:title,body` returned one unrelated book-import PR. Raw results and exact query URLs are recorded in `fresh_382e_api_summary.json` and associated JSON files. Open and closed states were both included; this is not merely a merged-code check.
- c5-k4 current main remains **e2cee93231eefb91c41e35450f7eeb19fd9c8c75**, confirmed by API at04:37UTC. Its current README, data and recursive tree were already cached and checked. #382e is a **HOLD_BOUNDED** trial with no counterexample, not a proof; the data label derives from historical O. The tree contains trial/search/verification artifacts, no382e full-proof artifact. Primary trial: https://github.com/Kuberwastaken/c5-k4/blob/e2cee93231eefb91c41e35450f7eeb19fd9c8c75/results/expansion/method_v02_382e.md .
- graffiti-verification current main remains **e4f890b23a62ed8086269e52afee684db86755b3**, likewise freshly confirmed. Its cached current README and verification ledger have no full382e disposition. The README's WOW-I248 result concerns nonmaximal outputs under some runs and a different inequality; it is not382e.
- The original live site, https://cms.uhd.edu/faculty/delavinae/research/wowII/ , returned **HTTP503** at04:37UTC. No claim is made to have read the latest curator annotation. The historical archive and independent contemporary trial agree on the formula, not necessarily today's live status.

## Focused literature coverage

Queries covered382e with counterexample/solved/Graffiti, Maxine with2-domination/two-domination/gamma_2, maximum-degree deletion with2-domination, private-vertex and K4,4 variants, and the equivalent well-covered/independent-domination bridge. Barrus–Molnar2016 and Lantz2019 primary texts were read; they give residue/independence bounds and equality classes, not a full382e resolution. The exact2018 precursor was caught by searching the complementary minimum-degree clique formulation, including the comments, rather than only the target number.

No matching prior full382e proof/counterexample was located in this bounded check. Search absence is not a worldwide novelty certificate. The original site outage, incomplete coverage of unindexed manuscripts/comments, and incomplete access to some older full texts remain explicit limitations. Use wording such as **“a counterexample to the archived original statement; no prior full resolution found in the checked sources”**, subject to independent mathematical audit.

## Small bundle files

Include `priority_audit_382e.md`, `statement_382e.json`, `auxiliary_priority_update.md`, `fresh_382e_api_summary.json`, `fresh_heads_live_retrieval.json`, and `priority_382e_provenance.json`. Full cached third-party papers/pages and unrelated search payloads need not be bundled.
