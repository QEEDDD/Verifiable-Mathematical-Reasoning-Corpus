# Round 12: full counterexamples to WOWII 382e

**Main result:** connected graphs J(k,r), k>=4 and r>=1, have order 1+r(k²+k), gamma=1, source-faithful Maxine=2r, and gamma₂=3r+1. Thus the original inequality fails by r. The smallest witness within this displayed parameter range has21 vertices and gives4>3. No claim of global vertex-minimality or first-ever priority is made.

- `manuscript.tex` / `382e_counterexamples.md`: self-contained English proof, source distinctions and prior-mechanism credit.
- `verify_382e_maxine.py` / `382e_maxine_certificate.json`: independent physical-vertex recursion over all maximum-degree tie choices, plus exhaustive rejection of sets of size at most3.
- `verify_382e_counterexample.cpp` / `382e_counterexample_exact.json`: independent subset enumeration.

Commands:

```sh
python verify_382e_maxine.py
g++ -O3 -std=c++17 verify_382e_counterexample.cpp -o /tmp/check382e
/tmp/check382e 4
```

The earlier scripts concerning maximal outputs, independent domination, and the relative gamma-set bridge are **auxiliary research history, not extra target closures**. In particular the15-vertex retained-edge/private-vertex construction was found in prior2018 Cao/Eppstein comments; the main theorem uses changed triple-neighbor private sets plus a universal vertex. See the source audit for bounded priority findings.
