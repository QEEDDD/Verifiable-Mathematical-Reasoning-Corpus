# Independent audit: dominating-C5 weighted density

**PASS: universal analytic partial theorem, not full WOWII133 and not a worldwide-priority certification.** Both the frozen Markdown proof and complete standalone TeX were read. They assert the same theorem; the separate exploratory C7 file is not included in this verdict.

## Scope

Every finite simple C4-subgraph-free, induced-P7-free graph with a dominating induced C5 has L=sum_v alpha(G[N(v)]) <= 3n, with triangles permitted and no rounding of L/n. The dominating connected cycle already ensures graph connectivity. The result excludes this branch of any radius-three counterexample with ell>3 and p<=6. It does not assert that a dominating C5 exists in every relevant graph. The Markdown's further radius-three consequence uses the previously independently audited low-average argument in Round09; the standalone TeX only states the immediate branch-exclusion consequence and requires no extra structural theorem.

## Contact reduction

All cycle-contact restrictions pass for subgraph C4 exclusion, not merely induced exclusion. Any distance-two contact pair makes a C4, so contacts are a singleton Ai or an adjacent pair Bi. Each Ai is a matching plus isolates; repeated Bi is impossible. To make the terse B-B argument explicit, for an edge xy between B0 and Bj, j=1,2, the cycle x-y-c2-c1-x is a C4; for j=3,4 use x-y-c4-c0-x. Extra chords do not matter. A singleton-contact Ai may meet Bj only for i=j+3; the other four cases similarly give a C4 using the appropriate cycle edge. Two such Ai neighbors of one B vertex would share both that B vertex and ci, again a C4. Cross-A edges occur only between diagonal classes and form matchings between fixed class pairs.

A B vertex therefore has degree two or three, and exactly one triangle. It has no possible additional triangle through its sole permitted exterior neighbor. In any C4-subgraph-free graph each neighborhood has maximum degree one, so local independence is degree minus the number of neighborhood edges. Summing gives L=2m-3t. Removing a B vertex decreases L by 2deg-3, equal to one or three. Thus proving the theorem after deleting all B vertices suffices. Deletion preserves all required exclusions and the dominating C5. This reduction handles arbitrarily many Ai vertices and every permitted B configuration.

## Diagonal components and deficit identity

The diagonal graph D on the A vertices has degree at most two. Along a nonbacktracking path, contact indices cannot reverse direction, since that would give two same-class neighbors and a C4. They consequently progress in steps +2 or -2 modulo five. On five consecutive vertices x0,...,x4 the displayed sequence ci,x0,x1,c(i+2),c(i+3),x4,x3 is an induced P7 unless x0x4 is present. All seven vertices are distinct; the listed contacts and degree-two restriction exclude every other chord. No within-class matching edge can contribute a chord because the exterior vertices used have distinct classes. If the closing edge is present, the diagonal degrees are saturated and this is an entire C5 component. Hence every component is P1,P2,P3,P4,C5.

The only triangles remaining in the whole graph are the q matching edges within Ai together with ci. A triangle entirely on A cannot use three distinct classes (the diagonal class cycle has no triangle), and a triangle using two vertices of one class would give a C4 with that class's cycle vertex. Therefore n=5+a, m=5+a+q+d, t=q, and 3n-L=5+a+q-2d=5+q-sum_Q(2e(Q)-v(Q)). The component excess values -1,0,1,2,5 are correct.

## Forced matching edges and global counting

For positive components P3,P4,C5, the contact-index sets of possible rooted induced P3 endpoints have sizes 2,4,5. Two intersecting root sets supply two three-vertex paths joined through the common cycle vertex. All cross-component diagonal edges are absent by definition. The cycle vertex has no extra contact on either path. Consequently a same-class matching edge between the two paths is necessary to prevent an induced P7; in particular one exists between the component pair.

When one component is C5, its two rooted orientations permit choosing non-root classes disjoint from those of the other rooted path. In the resulting seven-vertex sequence, the only possible matching chord is between the roots themselves. Every eligible root in the other component therefore forces that exact edge: two for P3, four for P4, five for C5. These are distinct physical edges, and edges required for different component pairs are distinct. The matching condition may make some combinations impossible, but never weakens these necessary lower bounds.

Writing h,k,s for C5,P4,P3 counts, if h>=1 then q>=5 binom(h,2)+h(4k+2s). Thus 5h+2k+s-q<=5, since h-binom(h,2)<=1 and the remaining coefficients are nonpositive. If h=0,k>=1, all four-element root sets intersect all positive root sets, giving q>=binom(k,2)+ks and 2k+s-q<=3; the scalar maximum of 2k-binom(k,2) is three. If h=k=0, the intersection graph of the s two-element root sets has at most two components, because distinct components use disjoint subsets of the five indices. It has at least s-2 edges, each forcing a distinct physical matching edge, so s-q<=2 (with the empty case immediate). Nonpositive blocks can only help. These inequalities prove the deficit nonnegative without any order bound.

## Independent computation

The author's checker was inspected and rerun: it enumerates multisets of at most three diagonal blocks, with all within-class matchings, rejecting precisely edges that would create a C4. Its path test is an induced-path DFS, and its local sum uses the valid 2m-3t identity. The reproduced counts are 29,314 C4-free configurations, 967 P7-free, minimum deficit zero. This domain omits B vertices by design and is not an enumeration of all graph orders.

The independent `check_independent.cpp` does not assume any diagonal-component or matching conclusion. It derives allowable nonempty one-vertex cycle contacts by a direct common-neighbor C4 test, then enumerates every contact multiset of at most five exterior vertices and every C4-free exterior-edge set. It tests induced P7 by direct seven-subset degree/connectivity inspection, and computes each neighborhood independence number by exact independent-subset enumeration rather than the weighted identity. Both singleton and adjacent-pair contact types are included.

All 3,003 contact multisets were considered, giving 15,499 C4-free configurations and 11,769 P7-free configurations; every latter case satisfies L<=3n, with minimum deficit zero. Per orders 5 through 10, the C4-free counts are 1,10,65,375,2150,12898 and the P7-free counts are 1,10,65,375,1980,9338. These are configuration counts, not claimed counts of nonisomorphic graphs. The independent exact local sums also agree with 2m-3t. This finite validation supplements, rather than proves, the universal theorem.

Reproduce by compiling `check_independent.cpp` with a C++17 compiler and running the executable. All authoritative sources and results are snapshotted and hashed. No mathematical repair was needed; standalone TeX consolidation also passes.
