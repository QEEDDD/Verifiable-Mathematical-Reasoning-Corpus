// Complete finite test around a fixed induced dominating C5, <=5 exterior
// vertices. Does not assume the diagonal-component or matching lemmas.
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <vector>
using namespace std;using U=unsigned;
uint64_t graphs[11]{},free7[11]{},contactcases=0,pruned=0;int minDef=999,n;vector<U>a;vector<int> types,contacts;vector<pair<int,int>> pairs;
void edge(int u,int v){a[u]^=1u<<v;a[v]^=1u<<u;}
bool hasC4(){for(int u=0;u<n;u++)for(int v=u+1;v<n;v++)if(__builtin_popcount(a[u]&a[v])>=2)return true;return false;}
bool hasP7(){if(n<7)return false;U stop=1u<<n;
 for(U s=127;s<stop;){int ones=0,twos=0,sum=0;bool ok=true;U bits=s;
  while(bits){int v=__builtin_ctz(bits);bits&=bits-1;int d=__builtin_popcount(a[v]&s);ones+=d==1;twos+=d==2;sum+=d;if(d<1||d>2){ok=false;break;}}
  if(ok&&ones==2&&twos==5&&sum==12){U seen=s&-s,old=0;while(old!=seen){old=seen;for(U q=seen;q;q&=q-1)seen|=a[__builtin_ctz(q)]&s;}if(seen==s)return true;}
  U c=s&-s,r=s+c;s=(((r^s)>>2)/c)|r;
 }return false;}
int exactL(){int L=0;for(int v=0;v<n;v++){U nb=a[v];int best=0;for(U s=nb;;s=(s-1)&nb){bool independent=true;for(U q=s;q;q&=q-1)if(a[__builtin_ctz(q)]&s){independent=false;break;}if(independent)best=max(best,__builtin_popcount(s));if(!s)break;}L+=best;}return L;}
void evaluate(){graphs[n]++;if(hasP7())return;free7[n]++;int L=exactL(),def=3*n-L;minDef=min(minDef,def);assert(def>=0);
 int twice=0,three=0;for(int v=0;v<n;v++){twice+=__builtin_popcount(a[v]);for(int w=v+1;w<n;w++)if(a[v]>>w&1)three+=__builtin_popcount(a[v]&a[w]);}assert(L==twice-three);
}
void addedges(int pos){if(pos==(int)pairs.size()){evaluate();return;}addedges(pos+1);auto [u,v]=pairs[pos];edge(u,v);if(hasC4())pruned++;else addedges(pos+1);edge(u,v);}
void finish(){contactcases++;n=5+contacts.size();a.assign(n,0);for(int i=0;i<5;i++)edge(i,(i+1)%5);for(int j=0;j<(int)contacts.size();j++)for(int i=0;i<5;i++)if(contacts[j]>>i&1)edge(5+j,i);if(hasC4())return;pairs.clear();for(int u=5;u<n;u++)for(int v=u+1;v<n;v++)pairs.push_back({u,v});addedges(0);}
void choose(int left,int start){if(!left){finish();return;}for(int i=start;i<(int)types.size();i++){contacts.push_back(types[i]);choose(left-1,i);contacts.pop_back();}}
int main(){// Derive allowable one-vertex contact masks by direct C4 test.
 for(int s=1;s<32;s++){n=6;a.assign(n,0);for(int i=0;i<5;i++)edge(i,(i+1)%5);for(int i=0;i<5;i++)if(s>>i&1)edge(5,i);if(!hasC4())types.push_back(s);}assert(types.size()==10);
 for(int t=0;t<=5;t++)choose(t,0);
 cout<<"{\"status\":\"PASS\",\"scope\":\"All exterior contact multisets and all C4-free exterior-edge sets with at most five exterior vertices around a fixed dominating induced C5; no component assumption\",\"contact_multisets\":"<<contactcases<<",\"C4_pruned_edge_branches\":"<<pruned<<",\"minimum_deficit\":"<<minDef<<",\"C4_free_by_order_5_to_10\":[";
 for(int i=5;i<=10;i++)cout<<(i>5?",":"")<<graphs[i];cout<<"],\"P7_free_by_order_5_to_10\":[";for(int i=5;i<=10;i++)cout<<(i>5?",":"")<<free7[i];cout<<"]}\n";
}
