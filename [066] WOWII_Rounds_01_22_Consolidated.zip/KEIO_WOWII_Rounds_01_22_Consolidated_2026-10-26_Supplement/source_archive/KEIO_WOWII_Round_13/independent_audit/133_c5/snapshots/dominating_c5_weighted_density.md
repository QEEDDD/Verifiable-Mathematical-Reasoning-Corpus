# Weighted density for a dominating five-cycle

**KEIO — 26 October 2026.**

**Status:** complete proposed analytic partial result, awaiting independent mathematical review. No full resolution of WOWII133 or priority claim is made. Earlier round checkpoints are unchanged.

## Theorem

Let G be a finite connected simple graph containing no C4 as a subgraph and no induced P7. If G has a dominating induced C5, then

\[
 L(G):=\sum_{v\in V(G)}\alpha(G[N(v)])\le3|V(G)|.
\]

Triangles are permitted. The average local independence is not rounded.

## Contact classes and reduction

Fix a dominating induced cycle c_0,...,c_4, with indices modulo five. The cycle-contact set of every exterior vertex is a singleton or an adjacent pair. A distance-two pair creates a C4, and every three cycle vertices contain such a pair.

Let A_i consist of vertices with contact set {c_i}, and B_i consist of vertices with contact set {c_i,c_(i+1)}. The following facts use only C4-subgraph exclusion:

1. Each A_i induces a matching plus isolated vertices. Otherwise a three-vertex path in N(c_i) gives a C4.
2. |B_i|≤1. Two vertices with the same two contacts give a C4, whether or not those two vertices are adjacent.
3. Different B classes have no edges between them. Any such edge, together with a suitable cycle edge or two consecutive contacts, completes a C4.
4. An A_i–A_j edge with i≠j is possible only when j=i±2. Edges between any fixed two A classes form a matching: two neighbors in A_j would give a C4 with c_j.
5. An A_i–B_j edge is possible only when i=j+3. Each B_j has at most one such neighbor, again by the common-neighbor condition.

Thus every B vertex has degree two or three and lies in exactly one triangle, namely its two cycle contacts. In any C4-subgraph-free graph, each neighborhood is a matching plus isolated vertices, so

\[
 L(G)=2|E(G)|-3t(G),
\]

where t(G) counts triangles. Deleting a B vertex therefore decreases L by either 1 or 3, and decreases n by 1. Deleting all B vertices cannot decrease the deficit 3n−L in the direction relevant to the claimed bound: explicitly, if G_0=G−B and L(G_0)≤3|V(G_0)|, then L(G)≤L(G_0)+3|B|≤3n.

It remains to prove the theorem when all exterior vertices lie in the A classes.

## The diagonal-edge components

Write a=|A|, and let q count the edges inside the individual A_i. Let D be the graph on A consisting only of edges between different A classes, and write d=|E(D)|. Its maximum degree is at most two. Along every nonbacktracking path in D, the contact indices progress consistently by +2 or by −2 modulo five: a reversal would give a vertex with two neighbors in one A class and hence a C4.

Every component of D is P1, P2, P3, P4, or C5. To see this, take five consecutive vertices x_0,...,x_4 along a path in D, with contacts c_i,c_(i+2),c_(i+4),c_(i+1),c_(i+3). If x_0x_4 is absent, then

\[
 c_i,x_0,x_1,c_{i+2},c_{i+3},x_4,x_3
\]

is an induced P7. No matching edge inside an A class can be a chord, since these five exterior vertices have distinct contact classes. The only possible further diagonal chord is x_0x_4. If that edge is present, the five vertices form an entire C5 component because their diagonal degrees are already two. This proves the component list.

For a component Q define

\[
 e(Q)=2|E(Q)|-|V(Q)|.
\]

The values on P1,P2,P3,P4,C5 are respectively −1,0,1,2,5. Since the only triangles of G are the q internal A edges together with their cycle contacts,

\[
 3n-L(G)=5+a+q-2d=5+q-\sum_Q e(Q).
\tag{1}
\]

We show that the sum of the positive component excesses is at most 5+q.

## Rooted paths and matching edges

Call a component positive if it is P3, P4, or C5. For each such component Q let T(Q) be the set of contact indices of endpoints of its induced three-vertex paths. Then

\[
 |T(P_3)|=2,\qquad |T(P_4)|=4,\qquad T(C_5)=\mathbb Z/5\mathbb Z.
\]

If two distinct positive components have intersecting T sets, there must be at least one internal A matching edge between these components. Indeed, choose an induced three-vertex path in each, ending in the same contact class A_i. Join the two paths through c_i. This gives seven distinct vertices. Each path uses three distinct contact classes, so c_i has no additional neighbor on either path. No diagonal edge joins the two components. Thus, without a matching edge between their path vertices, the joined sequence is an induced P7.

A stronger conclusion holds when one component is C5. Let x be an endpoint of a three-vertex path in another positive component, and suppose x has contact c_i. The C5 component contains a unique vertex y in A_i and has rooted three-vertex paths at y in both cyclic orientations. Choose the orientation opposite to that of the rooted path at x. Their two sets of non-root contact indices are disjoint. Consequently the only possible cross-component matching chord in the seven-vertex joined path is xy. Therefore xy must be an edge.

It follows that a C5 component requires at least two matching edges to every P3 component, four to every P4 component, and five to every other C5 component. These are distinct edges for distinct component pairs.

## Counting the positive excesses

Let h,k,s be the numbers of C5, P4, and P3 components, respectively.

If h≥1, the preceding stronger requirement gives

\[
 q\ge5\binom h2+h(4k+2s).
\]

Hence

\[
 5h+2k+s-q
 \le 5h-5\binom h2+(2-4h)k+(1-2h)s\le5.
\]

The final inequality follows because h−binom(h,2)≤1 for every positive integer h, and the other coefficients are nonpositive.

Suppose h=0. Every four-element contact set intersects every other positive contact set, which has size two or four. The first matching-edge requirement therefore gives

\[
 q\ge\binom k2+ks.
\]

If k≥1, then

\[
 2k+s-q\le2k-\binom k2+(1-k)s\le3.
\]

For k=0, form the intersection graph of the s two-element sets T(Q) from the P3 components. Distinct connected components of this intersection graph use disjoint sets of contact indices. Each uses at least two of the five indices, so the intersection graph has at most two components. It therefore has at least s−2 edges, and every such edge requires a distinct matching edge between the corresponding diagonal components. Thus q≥s−2 and s−q≤2. The empty case s=0 is immediate.

In every case the positive excess sum is at most 5+q. The P1 and P2 components have nonpositive excess and can only help. Equation (1) proves L(G)≤3n. Reinstating the B vertices proves the theorem. ∎

## Exact scope

This proves original WOWII133 whenever G is C4-subgraph-free, P7-free, has a dominating induced C5, and has radius three: the theorem gives ell≤3, while the previously verified general low-average result gives p≥r+ell. More usefully, it excludes a dominating induced C5 from any still-unresolved radius-three counterexample with ell>3 and p≤6.

It does not assert that every P7-free graph has a dominating C5. The non-dominating C5 case and the other cycle/domination alternatives still need separate arguments. The proof is self-contained beyond the original definitions and uses no general triangle-bisimplicial assertion; that stronger proposed auxiliary statement was explicitly refuted in the previous exploration.
