#include <bits/stdc++.h>
using namespace std;using U=uint64_t;mt19937 rng(133202610);
struct G{
 int n;vector<U>N;G(int n):n(n),N(n){};
 void edge(int u,int v){N[u]|=1ull<<v;N[v]|=1ull<<u;}
 void del(int u,int v){N[u]&=~(1ull<<v);N[v]&=~(1ull<<u);}
 bool allowed(int u,int v,bool trianglefree){if(u==v||(N[u]>>v&1))return false;if(trianglefree&&(N[u]&N[v]))return false;U a=N[u];while(a){int x=__builtin_ctzll(a);a&=a-1;if(N[x]&N[v])return false;}return true;}
 bool connected(){U seen=1,front=1;while(front){U next=0;while(front){int u=__builtin_ctzll(front);front&=front-1;next|=N[u];}front=next&~seen;seen|=front;}return __builtin_popcountll(seen)==n;}
 int radius(){int rad=n;for(int s=0;s<n;s++){U seen=1ull<<s,front=seen;int d=0;while(__builtin_popcountll(seen)<n){U next=0;while(front){int u=__builtin_ctzll(front);front&=front-1;next|=N[u];}front=next&~seen;seen|=front;d++;if(!front)return n;}rad=min(rad,d);}return rad;}
 int local_sum(){int degrees=0,tri6=0;for(int u=0;u<n;u++){degrees+=__builtin_popcountll(N[u]);U z=N[u];while(z){int v=__builtin_ctzll(z);z&=z-1;tri6+=__builtin_popcountll(N[u]&N[v]);}}return degrees-tri6/2;}
 long long nodes=0;bool haspath(int target){function<bool(int,int,U,U)>dfs=[&](int v,int len,U used,U forbid){nodes++;if(len>=target)return true;U cand=N[v]&~(used|forbid);while(cand){int u=__builtin_ctzll(cand);cand&=cand-1;if(dfs(u,len+1,used|(1ull<<u),forbid|N[v]))return true;}return false;};for(int s=0;s<n;s++)if(dfs(s,1,1ull<<s,0))return true;return false;}
 void print(){for(int u=0;u<n;u++)for(int v=0;v<u;v++)if(N[u]>>v&1)cout<<u<<","<<v<<";";cout<<endl;}
};


struct Block{int k,start;bool cyc;};
long long graphs=0,p7free=0,pruned=0;int mindef=999;vector<Block>types,bs;
void evaluate(G&g,int q){graphs++;if(g.haspath(7))return;p7free++;int D=3*g.n-g.local_sum();mindef=min(mindef,D);if(D<0){cerr<<"FAIL n "<<g.n<<" D "<<D<<endl;g.print();exit(1);}}
void matchclasses(G&g,vector<vector<int>>&vs,int cl,int q);
void matchone(G&g,vector<vector<int>>&vs,int cl,vector<int>v,int q){
 if(v.empty()){matchclasses(g,vs,cl+1,q);return;}
 int x=v.back();v.pop_back();matchone(g,vs,cl,v,q);
 for(int j=0;j<(int)v.size();j++){int y=v[j];if(!g.allowed(x,y,false)){pruned++;continue;}auto w=v;w.erase(w.begin()+j);g.edge(x,y);matchone(g,vs,cl,w,q+1);g.del(x,y);}
}
void matchclasses(G&g,vector<vector<int>>&vs,int cl,int q){if(cl==5){evaluate(g,q);return;}matchone(g,vs,cl,vs[cl],q);}
void run(){int n=5;for(auto b:bs)n+=b.k;G g(n);vector<vector<int>>vs(5);for(int i=0;i<5;i++)g.edge(i,(i+1)%5);int z=5;for(auto b:bs){for(int j=0;j<b.k;j++){int cl=(b.start+2*j)%5;vs[cl].push_back(z+j);g.edge(z+j,cl);if(j)g.edge(z+j-1,z+j);}if(b.cyc)g.edge(z,z+b.k-1);z+=b.k;}matchclasses(g,vs,0,0);}
void choose(int left,int last){run();if(!left)return;for(int i=last;i<(int)types.size();i++){bs.push_back(types[i]);choose(left-1,i);bs.pop_back();}}
int main(){for(int k=1;k<=4;k++)for(int i=0;i<5;i++)types.push_back({k,i,false});types.push_back({5,0,true});choose(3,0);cout<<"{\"status\":\"PASS\",\"scope\":\"All multisets of at most three diagonal blocks P1-P4 or C5 with all possible same-contact-class matchings\",\"C4_free_graphs\":"<<graphs<<",\"P7_free_graphs\":"<<p7free<<",\"C4_pruned_matching_choices\":"<<pruned<<",\"minimum_3n_minus_L_among_P7_free\":"<<mindef<<"}"<<endl;}
