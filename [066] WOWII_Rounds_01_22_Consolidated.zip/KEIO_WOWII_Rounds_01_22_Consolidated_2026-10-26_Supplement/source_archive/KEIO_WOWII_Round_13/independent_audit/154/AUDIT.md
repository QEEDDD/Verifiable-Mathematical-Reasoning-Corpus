# Independent audit: full counterexample family to original WOWII 154

**Mathematical verdict: PASS.** The 20-vertex physical graph disproves the original numbered statement, and the analytic proof establishes the entire family for every integer t>=2. No mathematical repair was necessary. Source-priority clearance is separate; this report does not certify worldwide novelty, and no smallest-counterexample claim is made. **WOWII155 is not refuted.**

## 1. Exact statement and definitions locked

The original row154 in the pinned original-page transcription (commit 3be380b4222f974bedbefb228c8e75fbd9a7b3ae) asserts, for a simple connected graph,

`L_s >= (1 + maximum order of radial circles) / minimum order of radial circles`.

The row refers to original definitions 1 and 81. Both were independently read in the recovered glossary `round_03/source_audit/archive_defs.txt` and pinned in this packet. Definition 1 is the actual maximum number of degree-one vertices over all spanning trees, not the number of leaves in the original graph. Definition 81 specifies a radial circle **centered at a center vertex**, consisting of vertices at distance equal to the graph radius. Thus only central roots contribute to the minimum and maximum. The proof and computations use exactly these conventions.

Original row155 instead asks `L_s >= 1 + number of distinct orders of radial circles`. It is pinned separately to prevent confusing the two claims.

## 2. Construction

The seven core vertices v,w,a,u,b1,b2,c induce the tree with edges vw,va,au,wb1,wb2,ac. For each of the three stems x=b1,b2,c and each j=1,...,t, add distinct vertices p_xj,z_xj and edges xp_xj,xz_xj,p_xjz_xj,uz_xj. Add one pendant vertex q adjacent only to u. All vertices and edges are ordinary, unweighted and distinct. There are no omitted implied edges. The graph is simple and connected, with n=8+6t and m=7+12t. At t=2 these are n=20,m=31.

## 3. Exact connected domination and actual spanning-tree leaf optimum

The seven core vertices form a connected dominating set, so gamma_c<=7. The author's branch-cost lower bound is valid and shorter than a separate case split independently derived during this audit.

Every connected dominating set D contains u. Otherwise domination forces q into D, where it is isolated; the singleton {q} does not dominate this graph either. For each stem x, partition its branch as the stem and its t private pairs. If x is omitted, every p_xj must be selected or have z_xj selected, so the branch contributes at least t>=2 vertices. If x is selected but its parent (w for b1,b2; a for c) is absent, selecting no other branch vertex would isolate x in D from the required u. The branch again contributes at least two. Thus a branch contributes at least one if its parent is selected and at least two otherwise.

With indicators W,A,V for selected w,a,v, these disjoint branch counts imply

`|D| >= 1 + 2(2-W) + (2-A) + W + A + V = 7-W+V`.

The omitted pendant q can only increase the left side. If |D|<=6, all inequalities must be equalities, W=1,V=0, and |D|=6. Each b-branch then contributes exactly one vertex, necessarily its stem, since omitting the stem would cost at least two. Consequently {w,b1,b2} is an entire connected component of G[D]: v is absent and all private neighbors of b1,b2 are absent. This component excludes u, contradiction. Therefore gamma_c=7 for every t>=2.

For completeness, the identity L_s=n-gamma_c is justified here rather than imported unreviewed. In a spanning tree of order at least three, its internal vertices form a connected dominating set, giving L_s<=n-gamma_c. Conversely, span a minimum connected dominating set by a tree and attach every outside vertex to a selected neighbor as a leaf, giving a spanning tree with at least n-gamma_c leaves. Equality follows. Hence L_s=6t+1.

There is also a direct optimal tree certificate: retain the six core edges, the two stem edges xp_xj and xz_xj for every pair, and uq. It is a spanning tree; all 6t+1 new vertices are leaves and all seven core vertices are internal. Thus the claimed leaf count is not merely the original graph's pendant count.

## 4. Exact radius and radial extrema

The author's four distance layers at v are exact: v; w,a; u,b1,b2,c; all 6t private vertices together with q. Every last-layer vertex has a length-three path, and none has a shorter path because it is adjacent only to vertices at depth at least two or to its pair mate. Thus ecc(v)=3 and |R(v)|=6t+1.

To exclude radius at most two, any candidate root would have to lie within two of q, hence in {q,u,a} or among the z vertices. Their stated witnesses are valid: d(q,w)=4, d(u,w)=3, d(a,p_b1,1)=3. For any z_xj, choose another stem y; the neighborhoods {x,p_xj,u} and {y,z_y1} are disjoint and the two vertices are nonadjacent, so d(z_xj,p_y1)>=3. This excludes every radius-two candidate, proving radius exactly three.

The vertex u reaches a, every z and q in one step, and v, every stem and every p in at most two. Its sole distance-three vertex is w. Thus u is central and its radial circle has order one, so R_min=1.

Every radial circle has size at most L_s: in a BFS spanning tree rooted at its center, every vertex of the final distance layer is a leaf. Since v attains 6t+1=L_s, R_max=6t+1. Therefore original154 demands

`6t+1 >= (1+(6t+1))/1 = 6t+2`,

which is false for every t>=2. The principal instance gives **13<14**. This is a full original counterexample, not a counterexample only to a strengthened auxiliary statement.

## 5. Independent physical verification

`check_independent.cpp` independently constructs the graph from the explicit core and pair-edge rules, without importing the author's graph, statistics module, masks, or verifier. It exhausts all **1,048,575 nonempty vertex subsets**, testing both domination and connectivity directly. There are no connected dominating sets of sizes one through six and exactly **25 of size seven**. The core mask127 is an optimum witness. It separately verifies the explicit 19-edge spanning tree, its connectivity, and exactly13 degree-one vertices.

BFS from every physical vertex gives radius3, diameter4 and exactly the following centers, using the author's stated vertex labels:

| Center | Radial-circle order |
|---|---:|
| 0=v | 13 |
| 2=a | 6 |
| 3=u | 1 |
| 8,10,12,14 | 7 each |

The two c-branch z vertices (16,18) are not central and are correctly excluded from the radial-circle collection. The independent complete distance matrix and edge set were compared only after computation and agree exactly with the author data. Results include all distances, cardinality counts, graph edges and the explicit tree certificate.

`check_family_bfs.py` independently constructs further family instances with named vertices for t=2,...,12. All BFS radii, radial extrema, seven-core dominating sets and explicit 6t+1-leaf spanning trees pass. These additional controls do not claim to enumerate all connected dominating sets of the larger graphs; their optimality follows from the universal analytic branch proof.

The central radial-circle orders in G2 have exactly four distinct values {1,6,7,13}. Therefore original155 requires only L_s>=5 and is satisfied. There is no #155 closure here.

Reproduce with a C++17 compiler on `check_independent.cpp`, then run `check_family_bfs.py`. No external graph library is required by either independent checker.

## 6. Manuscript consistency and separate source gate

The complete frozen `counterexample_154.md` and corresponding `counterexample_154.tex` were checked against this proof and the original definitions. Their principal-instance data, infinite-family quantifier t>=2, spanning-tree identity, radius proof and explicit distinction from155 all match. No substantive correction was requested. Any final root reformatted delivery source should be compared separately before packaging. Prior/source-status findings belong to the independent source-audit lane and are not inferred from a finite computation.
