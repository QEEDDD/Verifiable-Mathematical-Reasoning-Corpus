#!/usr/bin/env python3
from collections import deque
from pathlib import Path
import json
rows=[]
for t in range(2,13):
    adj={x:set() for x in ['v','w','a','u','b1','b2','c','q']};tree=[]
    def edge(x,y,tree_edge=False):
        adj.setdefault(x,set()).add(y);adj.setdefault(y,set()).add(x)
        if tree_edge:tree.append((x,y))
    for x,y in [('v','w'),('v','a'),('a','u'),('w','b1'),('w','b2'),('a','c'),('u','q')]:edge(x,y,True)
    for x in ['b1','b2','c']:
        for j in range(t):
            p=f'p_{x}_{j}';z=f'z_{x}_{j}'
            edge(x,p,True);edge(x,z,True);edge(p,z);edge('u',z)
    distances={}
    for x in adj:
        ds={x:0};queue=deque([x])
        while queue:
            y=queue.popleft()
            for z in adj[y]:
                if z not in ds:ds[z]=ds[y]+1;queue.append(z)
        assert len(ds)==len(adj);distances[x]=ds
    ecc={x:max(ds.values()) for x,ds in distances.items()};r=min(ecc.values());circles={x:sum(y==r for y in distances[x].values()) for x in adj if ecc[x]==r}
    degree={x:0 for x in adj}
    for x,y in tree:degree[x]+=1;degree[y]+=1
    assert len(tree)==len(adj)-1 and sum(z==1 for z in degree.values())==6*t+1
    core={'v','w','a','u','b1','b2','c'};assert all(x in core or adj[x]&core for x in adj)
    assert r==3 and min(circles.values())==1 and max(circles.values())==6*t+1 and circles['v']==6*t+1 and circles['u']==1
    assert sorted({y for y in circles.values()})==[1,2*t+2,2*t+3,6*t+1]
    rows.append({'t':t,'n':len(adj),'m':sum(map(len,adj.values()))//2,'radius':r,'diameter':max(ecc.values()),'center_count':len(circles),'radial_min':min(circles.values()),'radial_max':max(circles.values()),'explicit_tree_leaves':6*t+1,'distinct_central_radial_sizes':sorted(set(circles.values()))})
out={'status':'PASS','scope':'independent BFS and physical spanning-tree/CDS witness controls; general optimality proved analytically, not inferred from these controls','cases':rows}
Path(__file__).with_name('family_bfs_results.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS for t=2,...,12')
