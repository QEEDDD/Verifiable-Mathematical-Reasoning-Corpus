#include <algorithm>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <vector>
#include <queue>
using namespace std;
int main(){const int n=20;vector<unsigned>a(n);vector<pair<int,int>>edges,tree;
 auto edge=[&](int x,int y,bool t){a[x]|=1u<<y;a[y]|=1u<<x;edges.push_back({x,y});if(t)tree.push_back({x,y});};
 for(auto p:vector<pair<int,int>>{{0,1},{0,2},{2,3},{1,4},{1,5},{2,6}})edge(p.first,p.second,true);
 int z=7;for(int x:{4,5,6})for(int j=0;j<2;j++){int p=z++,q=z++;edge(x,p,true);edge(x,q,true);edge(p,q,false);edge(3,q,false);}assert(z==19);edge(3,19,true);
 vector<vector<int>>d(n,vector<int>(n,-1));vector<int>ecc(n),radial(n);int rad=n,diam=0;
 for(int v=0;v<n;v++){queue<int>q;q.push(v);d[v][v]=0;while(!q.empty()){int x=q.front();q.pop();for(unsigned b=a[x];b;b&=b-1){int y=__builtin_ctz(b);if(d[v][y]<0){d[v][y]=d[v][x]+1;q.push(y);}}}assert(find(d[v].begin(),d[v].end(),-1)==d[v].end());ecc[v]=*max_element(d[v].begin(),d[v].end());rad=min(rad,ecc[v]);diam=max(diam,ecc[v]);}
 int rmin=n,rmax=0;vector<int>centers;for(int v=0;v<n;v++){radial[v]=count(d[v].begin(),d[v].end(),rad);if(ecc[v]==rad){centers.push_back(v);rmin=min(rmin,radial[v]);rmax=max(rmax,radial[v]);}}
 vector<uint64_t>cds(n+1);unsigned witness=0,full=(1u<<n)-1;int gc=n;
 for(unsigned s=1;s<=full;s++){
  unsigned cover=s;for(unsigned b=s;b;b&=b-1)cover|=a[__builtin_ctz(b)];if(cover!=full)continue;
  unsigned seen=s&-s,old=0;while(seen!=old){old=seen;for(unsigned b=seen;b;b&=b-1)seen|=a[__builtin_ctz(b)]&s;}if(seen!=s)continue;
  int c=__builtin_popcount(s);cds[c]++;if(c<gc){gc=c;witness=s;}
 }
 vector<int>deg(n);vector<unsigned>ta(n);for(auto [x,y]:tree){deg[x]++;deg[y]++;ta[x]|=1u<<y;ta[y]|=1u<<x;}unsigned seen=1,old=0;while(old!=seen){old=seen;for(unsigned b=seen;b;b&=b-1)seen|=ta[__builtin_ctz(b)];}assert(seen==full&&tree.size()==n-1);int leaves=count(deg.begin(),deg.end(),1);
 assert(gc==7&&leaves==13&&rad==3&&diam==4&&rmin==1&&rmax==13);
 vector<int> radialvalues;for(int v:centers)radialvalues.push_back(radial[v]);sort(radialvalues.begin(),radialvalues.end());radialvalues.erase(unique(radialvalues.begin(),radialvalues.end()),radialvalues.end());assert(radialvalues==vector<int>({1,6,7,13}));
 cout<<"{\"status\":\"PASS\",\"order\":20,\"size\":"<<edges.size()<<",\"nonempty_subsets_tested\":"<<full<<",\"gamma_c\":"<<gc<<",\"minimum_cds_mask\":"<<witness<<",\"max_spanning_tree_leaves\":"<<leaves<<",\"radius\":"<<rad<<",\"diameter\":"<<diam<<",\"minimum_radial_circle\":"<<rmin<<",\"maximum_radial_circle\":"<<rmax<<",\"original154_rhs\":14,\"original155_distinct_radial_sizes\":4,\"centers\":[";
 for(int i=0;i<(int)centers.size();i++)cout<<(i?",":"")<<centers[i];cout<<"],\"eccentricities\":[";for(int i=0;i<n;i++)cout<<(i?",":"")<<ecc[i];cout<<"],\"radius_distance_counts_all_vertices\":[";for(int i=0;i<n;i++)cout<<(i?",":"")<<radial[i];cout<<"],\"connected_dominating_sets_by_cardinality\":[";for(int i=0;i<=n;i++)cout<<(i?",":"")<<cds[i];cout<<"],\"edges\":[";for(int i=0;i<(int)edges.size();i++)cout<<(i?",":"")<<'['<<edges[i].first<<','<<edges[i].second<<']';cout<<"],\"spanning_tree_edges\":[";for(int i=0;i<(int)tree.size();i++)cout<<(i?",":"")<<'['<<tree[i].first<<','<<tree[i].second<<']';cout<<"],\"distance_matrix\":[";for(int i=0;i<n;i++){cout<<(i?",":"")<<'[';for(int j=0;j<n;j++)cout<<(j?",":"")<<d[i][j];cout<<']';}cout<<"]}\n";
}
