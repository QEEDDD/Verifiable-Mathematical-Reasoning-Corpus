# A 20-vertex counterexample to WOWII Conjecture 154

## Exact statement and scope

For a simple connected graph $G$, let $L_s(G)$ be the maximum number of leaves in a spanning tree. Let $r$ be its radius. A radial circle is the set of vertices at distance $r$ from a central vertex. Write $R_{\min}$ and $R_{\max}$ for the smallest and largest orders of these radial circles. Original WOWII154 asserts

$$L_s(G)\geq\frac{1+R_{\max}}{R_{\min}}.$$

The construction below has $L_s=13$, $R_{\min}=1$ and $R_{\max}=13$. Thus it refutes the original assertion by the strict inequality $13<14$. It does **not** refute WOWII155, whose different right side counts distinct radial-circle orders.

The exact archived rows154 and155 are preserved in `source_row154.json` and `source_row155.json`, from the pinned original-page transcription:

<https://gitlab.com/ai-village-agents/village/graffiti-verification/-/blob/3be380b4222f974bedbefb228c8e75fbd9a7b3ae/data/wow2_rows_html.json>

Current external priority/status is checked separately by the source-audit lane. The mathematical proof below is self-contained and applies exactly to the original nontrivial connected-graph statement.

## 1. Construction

In fact there is an infinite family, indexed by an integer $t\geq2$.

Start with seven distinct vertices

$$v,w,a,u,b_1,b_2,c$$

and the six edges

$$vw,\ va,\ au,\ wb_1,\ wb_2,\ ac.$$

Thus these seven vertices induce a tree. For each stem $x\in\{b_1,b_2,c\}$ and each index $j\in\{1,\ldots,t\}$, introduce two new vertices $p_{x,j},z_{x,j}$ and the four edges

$$xp_{x,j},\quad xz_{x,j},\quad p_{x,j}z_{x,j},\quad uz_{x,j}.$$

Finally introduce a vertex $q$ with the single edge $uq$. There are no other edges. Denote the resulting graph by $G_t$. It is visibly simple and connected, with

$$n=8+6t.$$

The principal witness is $G_2$, of order20 and size31.

## 2. Connected domination number is exactly seven

Let $\gamma_c$ denote minimum connected dominating set cardinality. The original seven core vertices form a connected dominating set, so $\gamma_c(G_t)\leq7$.

We prove the reverse bound. Let $D$ be any connected dominating set. Necessarily $u\in D$: otherwise the pendant vertex $q$ must belong to $D$ to be dominated, but then it has no neighbor in $D$ and cannot be part of a connected dominating set of this graph.

For a stem $x$, let its branch be

$$X_x=\{x\}\cup\{p_{x,j},z_{x,j}:1\leq j\leq t\}.$$

Its parent is $w$ when $x=b_1,b_2$, and $a$ when $x=c$. Two observations give a branch-cost lower bound.

- If $x\notin D$, then domination of each $p_{x,j}$ requires $D$ to meet $\{p_{x,j},z_{x,j}\}$. These pairs are disjoint and $t\geq2$, so $|D\cap X_x|\geq2$.
- If $x\in D$ but its parent is absent from $D$, then selecting no further vertex of $X_x$ would leave $x$ isolated in $G[D]$, because its only neighbors outside $X_x$ are its parent. Since $u\in D$ and $u\ne x$, this is impossible. Again $|D\cap X_x|\geq2$.

Consequently a branch costs at least one selected vertex if its parent is in $D$, and at least two otherwise.

Write $W=\mathbf1_{w\in D}$, $A=\mathbf1_{a\in D}$ and $V=\mathbf1_{v\in D}$. Summing the three disjoint branch costs and the required core selections gives

$$|D|\geq1+(4-2W)+(2-A)+W+A+V=7-W+V.$$

If $|D|\leq6$, the only possibility is $W=1$, $V=0$, $|D|=6$, with equality in every cost estimate. In particular, each of the branches $X_{b_1},X_{b_2}$ contains exactly one selected vertex. It must be its stem $b_i$, since excluding that stem requires at least two selected vertices. Thus neither branch contains any selected $p$- or $z$-vertex. Since $v\notin D$, the set $\{w,b_1,b_2\}$ is then a connected component of $G[D]$ not containing the required vertex $u$. This contradicts connectivity.

Therefore

$$\boxed{\gamma_c(G_t)=7.}$$

For a connected graph of order at least three, $L_s=n-\gamma_c$. Indeed the internal vertices of any spanning tree form a connected dominating set; conversely a connected dominating set can be spanned by a tree and all remaining vertices attached as leaves. Hence

$$\boxed{L_s(G_t)=6t+1.}$$

## 3. Radius and a radial circle of order one

The distance layers from $v$ are exactly

$$\{v\},\qquad\{w,a\},\qquad\{u,b_1,b_2,c\},\qquad
\{q\}\cup\{p_{x,j},z_{x,j}:x\in\{b_1,b_2,c\},1\leq j\leq t\}.$$

Thus $\operatorname{ecc}(v)=3$ and its third sphere has order $6t+1$.

There is no vertex of eccentricity at most two. Any such vertex would have to be within distance two of the pendant vertex $q$, and hence belong to

$$\{q,u,a\}\cup\{z_{x,j}:x\in\{b_1,b_2,c\},1\leq j\leq t\}.$$

Each candidate fails:

- $d(u,w)=3$ and $d(q,w)=4$;
- $d(a,p_{b_1,1})=3$;
- for any $z_{x,j}$, choose a different stem $y\ne x$. The vertices $z_{x,j}$ and $p_{y,1}$ are neither adjacent nor have a common neighbor, so their distance is at least three.

Since $v$ has eccentricity three, the radius is exactly three.

The vertex $u$ also has eccentricity three, and its unique vertex at distance three is $w$. Indeed $u$ is adjacent to $a$, every $z_{x,j}$ and $q$; it reaches $v$ through $a$, every stem through either $a$ or a $z$-vertex, and every $p$-vertex through its $z$-vertex, all within two steps. Its distance to $w$ is three. Therefore

$$\boxed{R_{\min}=1.}$$

## 4. Maximum radial-circle order and contradiction

The radial circle at $v$ has order $6t+1=L_s(G_t)$. Every radial circle has order at most $L_s$: in a BFS spanning tree rooted at its center, all vertices of the final distance layer are leaves. Thus

$$\boxed{R_{\max}=6t+1.}$$

Conjecture154 would require

$$6t+1\geq\frac{1+(6t+1)}1=6t+2,$$

which is false for every integer $t\geq2$. At $t=2$, the explicit contradiction is

$$\boxed{13<14.}$$

This is a full counterexample family to the original numbered statement154, not merely to an auxiliary strengthening.

## 5. Exact verification and the distinction from155

`verify_154.py` uses only the Python standard library. It constructs the 20-vertex graph, checks simplicity and connectivity, verifies the seven-vertex connected dominating set, and exhausts all60,460 vertex subsets of size at most six, finding no smaller connected dominating set. It then performs BFS from every vertex, computes the radius, center, every radial circle and the two conjectural right sides using exact integers.

The exact central radial-circle orders of $G_2$ are

$$13,6,1,7,7,7,7.$$

Thus the distinct orders are $\{1,6,7,13\}$. Original155 only requires $L_s\geq1+4=5$, which this graph satisfies. **No resolution of155 is claimed.**

The supplied `counterexample20.edgelist` uses labels

$$0=v,\ 1=w,\ 2=a,\ 3=u,\ 4=b_1,\ 5=b_2,\ 6=c,$$

followed by consecutive $(p,z)$ pairs for $b_1$, then $b_2$, then $c$, and finally label19 for $q$. Complete distances and exact verification results are retained in `verification.json`. The structural argument, not merely the exhaustive calculation, proves the whole infinite family.
