"""Exact standard-library certificate for the 20-vertex WOWII154 counterexample."""
from collections import deque
from itertools import combinations
from pathlib import Path
import json
HERE=Path(__file__).resolve().parent

def build(t=2):
    # 0=v, 1=w, 2=a, 3=u, 4=b1, 5=b2, 6=c
    edges=[(0,1),(0,2),(2,3),(1,4),(1,5),(2,6)];j=7;blocks={}
    for x in (4,5,6):
        blocks[x]=[]
        for i in range(t):
            p,z=j,j+1;j+=2;blocks[x].append((p,z))
            edges.extend([(x,p),(x,z),(p,z),(3,z)])
    edges.append((3,j));return j+1,edges,blocks,j

def connected(A,s):
    if not s:return False
    reached=0;front=s&-s
    while front:
        reached|=front;new=0
        while front:
            bit=front&-front;front-=bit;new|=A[bit.bit_length()-1]
        front=new&s&~reached
    return reached==s

def dominates(A,s,full):
    reach=s
    while s:
        bit=s&-s;s-=bit;reach|=A[bit.bit_length()-1]
    return reach==full

def verify():
    n,edges,blocks,pendant=build();A=[0]*n
    for x,y in edges:A[x]|=1<<y;A[y]|=1<<x
    full=(1<<n)-1;assert connected(A,full)
    assert len(set(tuple(sorted(e))for e in edges))==len(edges) and all(x!=y for x,y in edges)
    core=sum(1<<x for x in range(7));assert connected(A,core) and dominates(A,core,full)
    checked=0
    for k in range(7):
        for vs in combinations(range(n),k):
            s=sum(1<<x for x in vs);checked+=1
            assert not(connected(A,s) and dominates(A,s,full)),('smaller CDS',vs)
    gamma=7;L=n-gamma
    D=[]
    for root in range(n):
        d=[-1]*n;d[root]=0;q=deque([root])
        while q:
            v=q.popleft();neighbors=A[v]
            while neighbors:
                bit=neighbors&-neighbors;neighbors-=bit;w=bit.bit_length()-1
                if d[w]<0:d[w]=d[v]+1;q.append(w)
        D.append(d)
    ecc=list(map(max,D));r=min(ecc);center=[x for x in range(n)if ecc[x]==r]
    circles={x:[y for y in range(n)if D[x][y]==r]for x in center};orders={x:len(S)for x,S in circles.items()}
    rmin=min(orders.values());rmax=max(orders.values())
    assert (n,gamma,L,r,rmin,rmax)==(20,7,13,3,1,13)
    assert circles[3]==[1] and len(circles[0])==13
    assert L*rmin<1+rmax
    out=dict(result='COUNTEREXAMPLE_TO_ORIGINAL154',n=n,size=len(edges),gamma_c=gamma,minimum_CDS=list(range(7)),subsets_of_order_at_most_6_exhausted=checked,L=L,radius=r,diameter=max(ecc),center=center,radial_circle_orders=orders,Rmin=rmin,Rmax=rmax,RHS154='14',margin154='L-RHS=-1',distinct_radial_orders=sorted(set(orders.values())),RHS155=1+len(set(orders.values())),conjecture155_refuted=False,edges=edges,distances=D)
    (HERE/'verification.json').write_text(json.dumps(out,indent=2)+'\n')
    (HERE/'counterexample20.edgelist').write_text(''.join(f'{x} {y}\n'for x,y in edges))
    print(json.dumps({k:v for k,v in out.items()if k not in ['edges','distances']},indent=2))
if __name__=='__main__':verify()
