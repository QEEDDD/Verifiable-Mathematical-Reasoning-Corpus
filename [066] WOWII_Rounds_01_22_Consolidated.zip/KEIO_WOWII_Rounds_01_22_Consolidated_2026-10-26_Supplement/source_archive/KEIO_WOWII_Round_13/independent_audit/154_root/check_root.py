import itertools,collections,json
# v,w,a,u,b1,b2,c =0..6
edges=[(0,1),(0,2),(2,3),(1,4),(1,5),(2,6)]
x=7
for root in [4,5,6]:
 for j in range(2):
  p,z=x,x+1;x+=2
  edges.extend([(root,p),(root,z),(p,z),(3,z)])
edges.append((3,x));n=x+1
adj=[set()for _ in range(n)]
for a,b in edges:adj[a].add(b);adj[b].add(a)
dists=[]
for root in range(n):
 d={root:0};Q=collections.deque([root])
 while Q:
  a=Q.popleft()
  for b in adj[a]:
   if b not in d:d[b]=d[a]+1;Q.append(b)
 dists.append([d[v]for v in range(n)])
ecc=list(map(max,dists));r=min(ecc);centers=[v for v in range(n)if ecc[v]==r];rad={v:dists[v].count(r)for v in centers};print(n,r,rad)
A=[sum(1<<v for v in a)for a in adj];allmask=(1<<n)-1
counts={}
for k in range(1,8):
 count=0;first=None
 for vv in itertools.combinations(range(n),k):
  if 3 not in vv:continue
  S=sum(1<<v for v in vv);closed=S
  for v in vv:closed|=A[v]
  if closed!=allmask:continue
  reach=1<<vv[0];old=0
  while old!=reach:
   old=reach
   for v in vv:
    if reach>>v&1:reach|=A[v]&S
  if reach==S:count+=1;first=vv if first is None else first
 counts[k]=count;print(k,count,first,flush=True)
assert counts[7] and not any(counts[k]for k in range(1,7));assert r==3 and min(rad.values())==1 and max(rad.values())==13
json.dump(dict(order=n,edges=edges,radius=r,central_radial_orders=rad,cds_counts=counts,gamma_c=7,max_leaves=13),open('/tmp/154_root_check.json','w'),indent=2)
