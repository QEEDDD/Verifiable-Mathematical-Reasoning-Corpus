# Mathematical audit of WOWII310 and its prior-corollary status

**Mathematical PASS; RETIRED FROM NEW-CLOSURE COUNT.** The elementary depth argument is valid, but the full numbered inequality is already a direct consequence of the published Peng--Zhou (2021) minimum-status theorem. A newly written proof must not be counted as a new resolution of a currently unresolved target. This verdict does not claim who first noticed the corollary.

## Exact original statement

Pinned row310 states, for every finite simple connected graph of order n>2,

`gamma_t(G) <= ceil(1 + Tdist_min(G)/3)`.

Recovered original definition79 is the sum of distances from a vertex to all other vertices, minimized over the root; it is not normalized average distance. Definition94 is total domination: every vertex, including selected vertices, must have a selected neighbor. Both definitions and the row are pinned in this packet.

## Valid self-contained rooted-tree lemma

For a tree T rooted at v, let I be the number of nonleaf vertices in the unrooted tree and I'=I-1 if v is nonleaf, otherwise I'=I. Put S=sum_x d(v,x). Let I1,I2 count nonroot internal vertices at depths one,two. In the sum of depth minus three over nonroot internal vertices, the only negative terms are -2I1-I2; all depth-at-least-three terms are nonnegative.

Let L2 count tree leaves at depth two and L3 count leaves at depth at least three. Every depth-two internal vertex has a descendant leaf at depth at least three, and their rooted subtrees are disjoint. Hence L3>=I2. Each depth-one internal vertex has a depth-two child, with distinct parents giving distinct children, so L2+I2>=I1. Therefore

`2L2+3L3 >= 2L2+3I2 >= 2I1+I2`.

The contribution of all leaves to S is at least the left side; depth-one leaves only add nonnegative weight, and a leaf root contributes zero. This cancels the negative internal contributions and proves **S>=3I'** for every rooted tree. No median-root assumption is needed.

If T is not a star, its nonleaf vertices induce a connected tree with at least two vertices. They totally dominate T: every leaf has an internal neighbor, and every internal vertex has another internal neighbor. Consequently gamma_t(T)<=I<=1+S/3, whether or not the root is a leaf. If T is a star of order n>2, gamma_t(T)=2 and S>=n-1>=2, giving the original ceiling bound as well.

For a connected graph G, choose a minimum-transmission root and its BFS spanning tree T. All distances from the chosen root are preserved, so S=Tdist_min(G). Every total dominating set of T also totally dominates G. Combining these facts proves the exact original inequality. In fact, for n>=4 the same proof gives the stronger floor bound gamma_t<=floor(1+Tdist_min/3): the only extra case is a star BFS tree, where S>=3 and gamma_t<=2. The connected order-three graphs require the original ceiling and are precisely the small exception to the floor claim.

## Published prior implication

The primary paper is Z. Peng and B. Zhou, *Minimum status of trees with given parameters*, RAIRO--Operations Research 55 (2021), S765--S785, DOI10.1051/ro/2020015. Its local primary text was inspected, especially Section4 and Theorem4.1 on printed S772. That theorem says the minimum status among n-vertex trees with p leaves is attained by the balanced p-legged spider (including the path for p=2). The exact status is the sum of ell(ell+1)/2 over its positive integer arm lengths ell, whose sum is n-1.

For each positive integer ell,

`ell(ell+1)/2 - 3(ell-1) = (ell-2)(ell-3)/2 >= 0`.

The nonnegativity uses integrality; there is no integer strictly between two and three. Summing gives s(T)>=3(n-p-1)=3(I-1). The same nonstar-internal-total-domination argument and star exception imply gamma_t(T)<=ceil(1+s(T)/3). For the BFS tree of G, s(T)<=S_T(v)=Tdist_min(G), so the same result transfers to G. Hence the published theorem already implies the full original310, and also the n>=4 floor corollary.

The independent elementary proof above establishes mathematical validity without relying on that paper's proof. The primary theorem is used here to determine the prior-corollary classification, in agreement with the separate source correction at `round_13/source_audit/310_priority_correction.md`. The original manuscript need not mention WOWII310 for this implication to hold.

## Independent finite checks

`check_independent.cpp` enumerates all 1,893,730 connected labeled graphs of orders3 through7. It computes transmissions by BFS from all13,227,820 roots and computes total domination exactly by every vertex subset's open-neighborhood union. Every original310 inequality passes. Every n>=4 floor inequality also passes; all four connected labeled order-three graphs fail the floor bound, exactly as the proof predicts.

A separate Prüfer-code traversal enumerates all280,392 labeled trees of orders2 through8 and checks every2,223,277 root choice. All three combinatorial inequalities L3>=I2, L2+I2>=I1 and S>=3I' pass. No author graph catalogue or checker is imported. The finite tests support but do not replace either universal argument.

This packet is suitable as a retired-prior-corollary supplement, not a new full-closure allocation. No proof manuscript was required for this independent reconstruction; any future consolidated article should preserve this explicit status.
