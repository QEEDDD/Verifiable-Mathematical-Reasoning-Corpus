// Independent finite audit of rooted-tree transmission lemma and WOWII310.
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <vector>
using namespace std;using U=unsigned;
uint64_t connected=0,graphroots=0,trees=0,treeroots=0,floor_exceptions_n3=0;
vector<uint64_t>byorder(9);
vector<int> bfs(const vector<U>&a,int root){int n=a.size();vector<int>d(n,-1),q{root};d[root]=0;for(int z=0;z<(int)q.size();z++)for(U b=a[q[z]];b;b&=b-1){int v=__builtin_ctz(b);if(d[v]<0){d[v]=d[q[z]]+1;q.push_back(v);}}return d;}
void treecheck(const vector<U>&a){int n=a.size();trees++;vector<int>deg(n);int I=0;for(int v=0;v<n;v++){deg[v]=__builtin_popcount(a[v]);I+=deg[v]>1;}
 for(int root=0;root<n;root++){treeroots++;auto d=bfs(a,root);int S=0,I1=0,I2=0,L2=0,L3=0;for(int v=0;v<n;v++){assert(d[v]>=0);S+=d[v];if(v==root)continue;if(deg[v]>1){I1+=d[v]==1;I2+=d[v]==2;}else{L2+=d[v]==2;L3+=d[v]>=3;}}
  assert(L3>=I2&&L2+I2>=I1);assert(2*L2+3*L3>=2*I1+I2);assert(S>=3*(I-(deg[root]>1)));
 }
}
void prufer(int n){uint64_t limit=1;for(int i=0;i<n-2;i++)limit*=n;for(uint64_t code=0;code<limit;code++){auto c=code;vector<int>seq(n-2),deg(n,1);for(int&i:seq){i=c%n;c/=n;deg[i]++;}vector<U>a(n);auto edge=[&](int x,int y){a[x]|=1u<<y;a[y]|=1u<<x;};for(int x:seq){int leaf=0;while(deg[leaf]!=1)leaf++;edge(leaf,x);deg[leaf]--;deg[x]--;}int x=0;while(deg[x]!=1)x++;int y=x+1;while(deg[y]!=1)y++;edge(x,y);treecheck(a);}}
int main(){for(int n=3;n<=7;n++){vector<pair<int,int>>E;for(int i=0;i<n;i++)for(int j=i+1;j<n;j++)E.push_back({i,j});uint64_t total=1ull<<E.size();U full=(1u<<n)-1;
 for(uint64_t g=0;g<total;g++){vector<U>a(n);for(int i=0;i<(int)E.size();i++)if(g>>i&1){auto[x,y]=E[i];a[x]|=1u<<y;a[y]|=1u<<x;}U seen=1,old=0;while(seen!=old){old=seen;for(U b=seen;b;b&=b-1)seen|=a[__builtin_ctz(b)];}if(seen!=full)continue;connected++;byorder[n]++;
  int T=n*n;for(int v=0;v<n;v++){graphroots++;auto d=bfs(a,v);int S=0;for(int x:d)S+=x;T=min(T,S);}
  int gamma=n;vector<U>cover(1u<<n);for(U s=1;s<=full;s++){U bit=s&-s;cover[s]=cover[s^bit]|a[__builtin_ctz(bit)];if(cover[s]==full)gamma=min(gamma,__builtin_popcount(s));}
  assert(gamma<=(T+5)/3); // ceil(1+T/3)=(T+5)/3
  if(n>=4)assert(gamma<=(T+3)/3);else floor_exceptions_n3+=gamma>(T+3)/3;
 }}for(int n=2;n<=8;n++)prufer(n);
 cout<<"{\"status\":\"PASS\",\"connected_labeled_graphs_n3_to_7\":"<<connected<<",\"graph_roots\":"<<graphroots<<",\"graphs_by_order_3_to_7\":[";for(int n=3;n<=7;n++)cout<<(n>3?",":"")<<byorder[n];cout<<"],\"labeled_trees_n2_to_8\":"<<trees<<",\"all_tree_roots_checked\":"<<treeroots<<",\"floor_bound_exceptions_order3\":"<<floor_exceptions_n3<<",\"scope\":\"all graph invariants exact; all rooted-tree inequalities exact; universal proofs are analytic\"}\n";
}
