# WOWII 310: published prior implication — retire from new-closure allocation

**26 October 2026, 04:56 UTC. The initial bounded “no exact prior result located” assessment is superseded.** A published minimum-status theorem implies the full conjecture by an elementary spanning-tree argument. Do not count a newly written self-contained proof as a new closure of a currently unresolved target.

## Exact published theorem

Zhene Peng and Bo Zhou, *Minimum status of trees with given parameters*, **RAIRO—Operations Research 55 (2021), S765–S785**, DOI [10.1051/ro/2020015](https://doi.org/10.1051/ro/2020015). Primary full PDF: https://www.numdam.org/item/10.1051/ro/2020015.pdf . Received 29 September 2019, accepted 12 February 2020. Theorem 4.1 is on printed **S772**, with proof continuing through S774.

For every tree T of order n with p leaves, 2≤p≤n−1, the theorem says

`s(T) >= s(S_{n,p})`,

with equality if and only if T is the balanced spider S_{n,p}: p pendant paths of almost equal lengths attached to a common vertex (for p=2, the path). Here `s(T)=min_v sum_u d(v,u)` is exactly the original WOWII minimum total distance, not normalized proximity.

Writing `q=floor((n−1)/p)` and `r=n−1−pq`, its explicit minimum is

`s(S_{n,p}) = p q(q+1)/2 + r(q+1)`.

Equivalently, it is the sum of `ell(ell+1)/2` over the p arm lengths ell. The primary PDF/text are cached as `310_primary/PengZhou2021.pdf` and `.txt`.

## Full implication for WOWII 310

For every positive integer ell,

`ell(ell+1)/2 − 3(ell−1) = (ell−2)(ell−3)/2 >= 0`.

Thus, since the arm lengths sum to n−1,

`s(T) >= 3(n−p−1)`.

Let I=n−p be the number of nonleaves. If T is not a star, its nonleaves induce a connected graph with at least two vertices and constitute a total dominating set. Consequently

`gamma_t(T) <= I <= 1+s(T)/3`.

If T is a star of order n>2, `gamma_t(T)=2` and `s(T)=n−1>=2`, so `gamma_t(T)<=ceil(1+s(T)/3)` still holds.

Finally, for a connected graph G, choose a vertex v of minimum total distance and a breadth-first spanning tree T rooted at v. Then

`gamma_t(G) <= gamma_t(T) <= ceil(1+s(T)/3)`

`<= ceil(1+sum_u d_T(v,u)/3) = ceil(1+sum_u d_G(v,u)/3)`.

This is exactly WOWII 310 for every simple connected graph of order greater than two. The BFS reduction and nonleaf total dominating set are elementary; the sharp minimum-status theorem is prior published work.

## Attribution and status language

The primary paper does not need to name WOWII 310 for its theorem to imply it. We found no direct earlier310-labelled claim in the inspected records, but that absence is irrelevant to the demonstrated published implication. The correct status for this program is **retired: elementary consequence of Peng–Zhou (2021)**, not “newly solved” and not a purported new mathematical method. This note does not assert who first noticed this particular corollary.
