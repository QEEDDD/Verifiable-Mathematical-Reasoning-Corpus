# Independent audit of the radial-equality separation reduction

**PASS as a necessary-condition theorem, including Section 5.** This report concerns the frozen `round_12/leaves/radial_equality_reduction.md`, not a full resolution of either numbered conjecture. The later full counterexample to154 is audited separately and does not contradict this reduction.

## Statement

Let G be connected of radius r>=3 and maximum spanning-tree leaf number L. Suppose v is central and its final BFS layer S has size L. If another center u has exactly one eccentric vertex, then d(v,u)>=r-1. For distance r-1, the opposite component described in the proof has a unique depth-one vertex w and deg_{G-S}(w)>=3. For distance r, every neighbor of v has degree at least three in G-S. These are the exact claims audited; the two extreme-depth cases are not declared impossible.

## Proof details

Every vertex in S is a leaf in every BFS spanning tree rooted at v. Equality with the global maximum L forbids any other tree leaf. For any positive-depth vertex x below the final layer, if all its forward neighbors had alternative previous-layer neighbors, one could independently choose their BFS parents to avoid x, making x an additional leaf. Thus x has a private forward child. Different vertices have distinct such children, which gives injective forward rays within each component until S is reached. The separate observation that a center of radius at least two cannot have degree one is valid.

C=V-S is connected and dominates S. The standard identity L=n-gamma_c follows directly by comparing internal spanning-tree vertices with connected dominating sets and attaching all nonselected vertices as leaves; it is also proved in the separate154 audit. Therefore C is minimum connected dominating. Any x of depth at most r-2 has no neighbor in S. If C-x were connected, it would still dominate G, including x, since C has at least three vertices and is connected. Consequently x is a cut vertex of G[C], including v. Each component of C-v contains a neighbor of v and private forward rays reaching every depth through r-1.

For adjacent centers u,v, take x at depth r-1 in another C-v component and its private child y in S. A u-x path via v has length at least r, while a bypass must meet S and hence has length at least (r-1)+1. The route through v attains r. If d(u,y)<r, it must equal r-1; preceding a geodesic by vu gives a v-y geodesic, whose penultimate vertex is in the u-component and contradicts y's unique previous-level neighbor x. Thus x and y are two distinct eccentric vertices of u, impossible.

For 2<=h=d(v,u)<=r-2, put ell=r-h>=2. Every depth-ell vertex x in any other C-v component is distance r from u: a route via v costs at least h+ell; a bypass meets S and costs at least (r-h)+(r-ell); the concatenated geodesic walk via v provides the matching upper bound. Uniqueness forces exactly one opposite component D and exactly one depth-ell vertex w. Private-child injections imply exactly one vertex of D at every earlier positive depth. Its depth-one vertex a has precisely two C-neighbors, v and the unique depth-two vertex, and is a leaf of G[D].

The private child y of w lies in C at depth ell+1 and must be within r-1 of u. Its shortest path cannot go through v. If z_first,z_last are its first and last vertices in S, the initial and final segments have lower bounds ell and h-1. They sum to r-1, so equality is forced, with a single S vertex z and no middle segment. The vertices before z lie in the u-component A, and those after z lie in D. The neighbors of z on both sides have depth r-1 and are not a. Hence replacing {v,a} in C by z preserves connectivity: A and D-a are connected and z joins them. All old S vertices retain their C-neighbors, since neither removed vertex met S; v is dominated from A and a from depth two. This produces a smaller connected dominating set, contradiction. The proof excludes all distances below r-1.

The h=r-1 argument remains valid with ell=1 except that the opposite depth-one vertex w need not be a leaf of D. If deg_C(w)=2, it would be such a leaf, and exactly the same exchange gives a contradiction; a private child already ensures degree at least two, so the necessary degree is at least three. The proof correctly stops there.

For h=r, u is in S and v is its unique eccentric vertex. Each neighbor a of v is at distance exactly r-1 from u. Prepending va to a geodesic to u produces a v-u geodesic increasing depth at every step, so u has a neighbor at depth r-1 in every component of C-v. Thus adding u joins all these components. If any neighbor a of v had C-degree two, it would be a leaf of its component; the u-attachment is at depth r-1>=2 and survives deletion of a. Removing v,a and adding u would again preserve connectivity and domination, contradicting minimality. This verifies the second extreme-depth branching condition.

## Validation and limits

No theorem-specific exhaustive test is claimed for this reduction. The author's earlier small-graph caches did not contain its full hypothesis, so they would be vacuous as final-hypothesis evidence. The proof itself is complete.

The independently verified 20-vertex154 counterexample now supplies a nonvacuous boundary control: r=3, v=0 has |R(v)|=L=13, u=3 has a unique eccentric vertex, and d(v,u)=2=r-1. Its opposite depth-one vertex w=1 has degree exactly three in the minimum connected dominating core C={0,...,6}. Thus both the distance bound and the stated degree threshold are attained in that example. In particular the reduction must not be strengthened to exclude this boundary case.
