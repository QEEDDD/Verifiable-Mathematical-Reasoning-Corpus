# Radial-circle equality: a separation reduction for 154 and 155

This is a necessary-condition theorem, not a full resolution of either original conjecture.

Let G be a finite simple connected graph with radius r>=3 and maximum spanning-tree leaf number L. Suppose v is central and its radial sphere S={x:d(v,x)=r} has size L. Suppose u is another center with exactly one vertex at distance r. Then

**d(v,u) >= r-1.**

## 1. Equality forces private forward children

Every BFS spanning tree rooted at v contains every member of S as a leaf. Since |S|=L, it can have no other leaf. In particular, for any vertex x at depth i with 1<=i<r, there is some forward neighbor y at depth i+1 whose sole neighbor in level i is x. Otherwise one could independently choose BFS parents for every forward neighbor of x different from x, making x an extra leaf. Fix such a private forward child for each x. Private children of distinct vertices are distinct. These choices inject each level into the following level and yield forward rays ending in S.

The root does not need this parent-selection argument: it has at least two neighbors. Indeed, a graph of radius at least two cannot have a central vertex of degree one. If v had only neighbor t, then ecc(t)=ecc(v)-1, contradicting centrality.

## 2. The inner vertices form a minimum connected dominating set

Put C=V(G)\S. It is connected by BFS paths and dominates S. Since L=n-gamma_c, |C|=n-L=gamma_c, so C is a minimum connected dominating set.

Every vertex x of depth at most r-2 is a cut vertex of G[C]. Such x has no neighbor in S. If G[C]-x were connected, then C\{x} would remain a connected dominating set: all S vertices retain their neighbors, and x has a retained neighbor. This contradicts minimum cardinality. In particular v is a cut vertex of G[C].

Every component of G[C]-v contains a neighbor of v and, by repeatedly following private children, vertices of every depth 1,...,r-1. A private-child ray remains in the same component until it enters S.

## 3. Adjacent centers cannot have a unique eccentric vertex

Suppose d(v,u)=1. Let D be a component of G[C]-v not containing u. Choose x in D at depth r-1 and a private forward child y in S.

Every u-x path through v has length at least r. A path avoiding v must leave one component of G[C]-v for another, so it meets S. Its length is at least d(u,S)+1>=r. Conversely the edge uv followed by a v-x geodesic gives length r. Thus d(u,x)=r.

Also d(u,y)>=r. Otherwise the triangle inequality gives d(u,y)=r-1, and a u-y geodesic together with vu is a v-y geodesic. Its penultimate vertex belongs to the component containing u, whereas y has the unique previous-level neighbor x in D. This is impossible. As u is central, d(u,y)=r as well. The distinct vertices x,y contradict uniqueness.

## 4. Centers at distances 2,...,r-2 are also excluded

Suppose 2<=h=d(v,u)<=r-2, and write ell=r-h>=2. Here u belongs to C. For any component D of G[C]-v not containing u, every vertex x in D at depth ell has d(u,x)=r:

- a path through v has length at least h+ell=r;
- a bypass must meet S and has length at least (r-h)+(r-ell)=r;
- concatenating geodesics through v gives a walk of length r, hence distance at most r.

Since u has only one eccentric vertex, G[C]-v has exactly two components: the component A containing u and one other component D. Moreover D contains exactly one vertex w at depth ell. The private-child injections force D to contain exactly one vertex at each of depths 1,...,ell. Let a be its depth-one vertex. Because ell>=2, a has exactly two neighbors in C, namely v and the depth-two vertex in D; it is a leaf of G[D]. It has no neighbor in S because r>=3.

Choose a private forward child y of w, at depth ell+1<=r-1. Thus y is in D and y is not w. Uniqueness of the eccentric vertex gives d(u,y)<=r-1. A path through v has length at least h+ell+1=r+1, so a shortest u-y path bypasses v and meets S.

Let z_first and z_last be the first and last S vertices on this shortest path. Its initial segment has length at least r-h=ell; its final segment has length at least r-(ell+1)=h-1. These lower bounds sum to r-1. Consequently equality holds throughout, z_first=z_last=z, and this is the only S vertex on the path. All preceding vertices lie in A and all succeeding vertices lie in D. Therefore z has a neighbor in A and a neighbor in D at depth r-1, beyond the removed depth-one vertex a.

Now replace C by

D_new=(C\{v,a}) union {z}.

The set A is connected, D\{a} is connected, and z joins them. Thus G[D_new] is connected. Every vertex of S still has a neighbor among the retained old C vertices, because neither v nor a had a neighbor in S. The removed vertex v is dominated by a retained neighbor in A, and a is dominated by the depth-two vertex in D. Hence D_new is a connected dominating set of order |C|-1, a contradiction.

The only possibilities are therefore d(v,u)=r-1 or r.

## Exact remaining obstacle

The two extreme-depth cases are not resolved by this exchange. When d(v,u)=r-1, the opposite depth-one vertex itself is the unique eccentric vertex and may have many forward branches, so deleting it need not preserve connectivity after adding a single S vertex. When d(v,u)=r, u belongs to S, and the component argument at positive depth does not directly apply. No conclusion about the existence or impossibility of these profiles is claimed.

## 5. Necessary branching in the two remaining cases

These are still reductions, not closures.

### Distance h=r-1

The level-ell argument of Section4 remains valid with ell=1: C-v has exactly two components, and the component D not containing u has a single depth-one vertex w, the unique eccentric vertex of u. A private forward child y of w is in C at depth2. The exact shortest-path argument still produces one S vertex z joining the u-component to D beyond w. If w had degree2 in C, then w would be a leaf of G[D]. The connected dominating set (C\{v,w}) union {z} would have order |C|-1. Thus deg_C(w)>=3 is necessary.

### Distance h=r

Here u belongs to S and v is its unique eccentric vertex. Every neighbor a of v is at distance exactly r-1 from u: the triangle inequality gives the lower bound, and uniqueness gives the upper bound. A shortest a-u path, preceded by va, is a v-u geodesic and hence increases the v-depth at every step. Thus u has a neighbor at depth r-1 in every component of C-v. Therefore (C\{v}) union {u} is connected.

If a neighbor a of v had degree2 in C, then a would be a leaf of its component D of C-v. Its forward geodesic to u attaches u to a depth-(r-1) vertex of D other than a, since r>=3. Hence (C\{v,a}) union {u} remains connected. It dominates all vertices: neither v nor a has a neighbor in S; v retains a neighbor in another C-v component; and a retains its other C-neighbor. This again saves one vertex, impossible. Consequently every neighbor of v has degree at least3 in C.
