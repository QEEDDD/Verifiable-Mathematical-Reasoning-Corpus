# WOWII 154 — source and bounded priority gate

**Checked 26 October 2026, 04:51 UTC. Source match: PASS. No prior full resolution of WOWII 154, or equivalent radial-circle counterexample, was located in the public sources examined.** This is a bounded search outcome, not worldwide priority certification or certification of the latest live curator annotation. Mathematical verification of the proposed 20-vertex counterexample is separate.

## Exact statement and definitions

For a simple connected graph G, the archived row 154 asserts

`L_s(G) >= (1 + max_{v in C(G)} |R(v)|) / min_{v in C(G)} |R(v)|`,

where `C(G)` is the center, `R(v) = {x : d(v,x)=rad(G)}`, and `L_s(G)` is the **maximum** number of leaves among spanning trees of G. The row links original definitions **1 and 81**. Definition 81 expressly says that the radial circle is centered at a **center vertex**, not an arbitrary vertex. No rounding and no claw-free, triangle-free, or minimum-degree restriction occur. The dated source note is 8 August 2005. Exact HTML and definition excerpts are in `statement_154.json`.

Pinned source: https://gitlab.com/ai-village-agents/village/graffiti-verification/-/blob/3be380b4222f974bedbefb228c8e75fbd9a7b3ae/data/wow2_rows_html.json . Original glossary: https://web.archive.org/web/20240512133636id_/http://cms.uhd.edu/faculty/delavinae/research/wowII/wowIIdefs.js . Independently, the original-host HTML freeze accessed 28 July 2026 and included in the [Gebendorfer 354 intake attachment](https://github.com/user-attachments/files/33373810/Gebendorfer_WOWII_354_Intake_2026-10-13.zip) reproduces exactly this154 formula and its two definition links. Thus the coefficient-version problem discovered for354 does **not** affect154.

## Primary current-status checks

- The GitLab verification README at `e4f890b23a62ed8086269e52afee684db86755b3` (head rechecked at04:37UTC) has no WOWII154 result. Its many154 references concern **WOW-I154**, the eigenvalue-deviation/average-distance conjecture, standing counts, or numerical data. They are not a collision with this leaf/radial formula.
- The c5-k4 repository at `e2cee93231eefb91c41e35450f7eeb19fd9c8c75` (head rechecked at04:37UTC), current README, complete recursive tree and current `data/wowii-conjectures.json` were checked. Entry154 repeats this formula and has no linked Lean file; its “open” evidence is explicitly only the historical O marker. We do not treat that label as independent current-open certification. No154-specific result path was found.
- The cached218 distinct primary issue/PR bodies from the all-state WOWII/Gebendorfer inventory contain no radial-circle or WOWII154 proof/counterexample. Fresh all-state API queries at04:49–04:51UTC returned0 for `GraphConjecture154` in formal-conjectures,0 for formal-conjectures `radial circle`,0 for c5-k4 `154`,0 for c5-k4 `radial`, and0 for `WOWII154`. The formal-repository broad `radial` query found7 unrelated analysis/geometry records. Agentic-conjectures154 returned one unrelated busy-beaver record. Fresh formula-term queries returned no relevant graph-theory claim. Raw receipts and concise summaries are retained locally.
- A first global numeric query was polluted by hundreds of thousands of issue-number154 matches and is **not** used as negative evidence. A mistyped repository query returned422; the corrected `Kuberwastaken/c5-k4` queries succeeded. Neither limitation is silently counted as a successful search.

## Related literature and false-positive control

Focused web queries used exact154/WOWII/Graffiti.pc identifiers, “radial circle(s)” with graph/spanning/leaves, and maximum-leaf/eccentric-vertex terms. No earlier full resolution was located. Secondary news/search headlines claiming “154 disproved” refer to the different WOW-I spectral conjecture; the primary verification README confirms the distinction.

DeLaViña and Waller, *Spanning Trees with Many Leaves and Average Distance*, Electronic Journal of Combinatorics15 (2008), R33, https://doi.org/10.37236/757 , was checked in the cached primary text. Its lower bounds use independence, local independence, bipartite induced order and average distance, not the154 radial-circle ratio. This does not assert that all underlying graph gadgets or spanning-tree arguments in the new construction are novel.

## Limits and recommended wording

The original live UHD host returned503 in the recent04:37UTC request; latest live curator notes therefore remain unread. Search coverage is bounded to the named records and indexed literature, not all possible public/private/unindexed work.

Recommended wording: **“The verified graph refutes WOWII154 under the recovered original definitions. A bounded check of primary public repositories, unmerged issues/PRs and related literature found no earlier resolution; worldwide priority and the latest live catalogue annotation are not certified.”**

For the round bundle include this note, `statement_154.json`, `api2_summary.json` and `compact_provenance.json`; omit bulk unrelated search responses and third-party attachments.
