# WOWII 310: recovered prior consequence, excluded from the new-result count

The original statement is true, but is already an elementary consequence of Peng and Zhou, *Minimum status of trees with given parameters*, RAIRO Operations Research (2021), Theorem4.1, printed p.S772, DOI https://doi.org/10.1051/ro/2020015 . It is not counted as an additional new closure.

Their fixed-leaf minimum-status theorem gives the balanced spider. If its positive integer arm lengths are ell_i, then each ell_i(ell_i+1)/2 is at least3(ell_i−1), because the difference is (ell_i−2)(ell_i−3)/2≥0. Therefore a tree with I nonleaf vertices has minimum transmission at least3(I−1). In a nonstar tree all nonleaf vertices form a total dominating set. The star case is immediate for the original ceiling inequality. A BFS spanning tree rooted at a minimum-transmission vertex preserves that transmission, and a total dominating set of the tree also totally dominates the original graph. Hence gamma_t(G)≤ceil(1+minimum_transmission/3) for connected graphs of order greater than2, exactly original310.

## Independent elementary proof of the tree bound

Root a tree. Let I_1,I_2 count its nonleaf vertices at depths1,2; let L_2 count leaves at depth2 and L_3 count leaves at depths at least3. Every depth2 nonleaf has a descendant leaf in a disjoint rooted subtree, so L_3≥I_2. Every depth1 nonleaf has a child at depth2, so L_2+I_2≥I_1. The only negative contributions to depth−3 among nonroot nonleaf vertices are −2I_1−I_2; deeper nonleaf contributions are nonnegative. Leaf depths contribute at least2L_2+3L_3≥2I_1+I_2. Thus total transmission is at least three times the number of nonroot nonleaf vertices, hence at least3(I−1).

For order at least4 the same argument even gives gamma_t(G)≤floor(1+minimum_transmission/3). If the BFS tree is a star, its transmission is at least n−1≥3 and its total domination number is2; otherwise use the nonleaf set. The order3 cases require the original ceiling. This strengthening is likewise implied by the published theorem, not a separate novelty claim.

The mathematical proof and finite independent controls are distinguished from priority. See source_audit/310_priority_correction.md for the source gate and independent_audit/310 for verification. No full third-party paper is redistributed in this ZIP.
