import collections,json
edges=[(0,1),(0,2)];D={0,1};n=3;branches=[]
for parent in [0,1,1]:
 a,b,c,d,e,f,g,h,i,j,k=range(n,n+11);n+=11
 edges +=[(parent,a),(a,b),(a,c),(b,d),(d,e),(d,f),(f,g),(c,h),(h,i),(h,j),(j,k)]
 D.update([d,f,h,j]);branches.append([a,b,c,d,e,f,g,h,i,j,k])
adj=[set()for _ in range(n)]
for a,b in edges:adj[a].add(b);adj[b].add(a)
A={v for v in range(n)if len(adj[v])==2};X={u for v in A for u in adj[v]};comps=[];left=X.copy()
while left:
 C={left.pop()};q=list(C)
 for v in q:
  for u in adj[v]&left:left.remove(u);C.add(u);q.append(u)
 comps.append(sorted(C))
ecc=[]
for root in range(n):
 ds={root:0};q=collections.deque([root])
 while q:
  v=q.popleft()
  for u in adj[v]:
   if u not in ds:ds[u]=ds[v]+1;q.append(u)
 ecc.append(max(ds.values()))
centers=[v for v in range(n)if ecc[v]==min(ecc)]
assert all(adj[v]&D for v in range(n));assert n==36 and len(D)==14 and len(comps)==15 and centers==[0,1]
result=dict(order=n,size=len(edges),edges=edges,selected_total_dominating_set=sorted(D),degree2=sorted(A),open_neighborhood_components=comps,centers=centers,radius=min(ecc),diameter=max(ecc),rhs=len(centers)*len(comps)/2)
print(json.dumps(result,indent=2));json.dump(result,open('wowii_rounds/round_14/354_root/counterexample36.json','w'),indent=2)
