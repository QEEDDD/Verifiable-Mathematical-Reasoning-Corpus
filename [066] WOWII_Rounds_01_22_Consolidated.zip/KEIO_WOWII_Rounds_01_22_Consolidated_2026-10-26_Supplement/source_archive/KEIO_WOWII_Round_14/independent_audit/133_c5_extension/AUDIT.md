# Independent audit: C5-containing, induced-C7-free weighted density

**PASS: universal analytic partial result.** Every connected C4-subgraph-free, induced-P7-free graph containing an induced C5 and no induced C7 satisfies L=sum_v alpha(G[N(v)])<=3n. Triangles are allowed and no rounding is used. This is not a full resolution of WOWII133 and is not a worldwide-priority finding. The separate proposed general P7-free theorem is outside this report.

The frozen complete Markdown proof was read and checked. Its only mathematical dependency is the Round13 dominating-C5 component argument, already independently audited in `round_13/independent_audit/133_c5/AUDIT.md`. The precise stronger intermediate needed here, D_A>=2 when the diagonal graph has no C5 component, follows directly from that audit's no-C5 excess bound (positive excess minus matching count at most three). No general triangle-bisimplicial assertion or unreviewed structure paper is used.

## 1. Beyond-cycle components and safe deletion

The inherited first-layer contact restrictions are correct. Every first-layer vertex starts an induced P5 consisting of itself and four cycle vertices: for a pair-contact B vertex choose the direction omitting its second cycle contact. If a component Q of vertices with no cycle contact is not complete to a touching first-layer vertex x, a boundary edge ab in Q with xa present and xb absent extends this rooted P5 to b,a,x followed by four cycle vertices, an induced P7. There are no hidden cycle contacts on a,b. Thus Q is complete to x. Because every C4-subgraph-free neighborhood is a matching plus isolates, connected Q is K1 or K2. Connectedness supplies a touching first-layer vertex for every Q, so no deeper layer exists.

A K2 component cannot have two first-layer neighbors: its two vertices would have those two common neighbors and give a C4. It is therefore a pendant triangle, whose deletion removes two vertices, three edges and one triangle, changing L=2m-3t by three. This is safe for the claimed bound.

For a singleton z, two neighbors cannot share a cycle contact. The listed pair exclusions were checked for inducedness, not merely for existence of a cycle. A0,A1 creates the displayed P7; A0,A2 without their diagonal edge creates the displayed induced C7; A0,B1 likewise creates that C7 because a direct edge would itself give a C4. Reflection excludes A0,B3, while B0,B4 share contacts with A0. Hence the remaining pairs are diagonal adjacent A-A, the unique opposite A-B type, or disjoint B-B types. The compatibility graph has no triangle: each A type has only one compatible B type and conversely, and each same-kind compatibility graph is a five-cycle. Repeated types share contacts. Thus z has degree at most two.

Removing singleton leaves changes L by two; removing degree-two singletons with adjacent neighbors changes it by one. The residual singleton vertices therefore subdivide nonedges of type Ai--B(i+2) or Bi--B(i±2). Duplicate endpoint pairs are impossible by C4 exclusion.

For a marked A vertex x with no diagonal neighbor, its only remaining neighbors are its cycle contact, its unique subdivision vertex, and possibly a within-class mate. The only possible direct B neighbor would be the same nonadjacent endpoint of the subdivision, so none exists. Deleting x and its subdivision removes three edges/no triangle or four edges/one triangle, costing L=6 or5 for two vertices. This is safe. It does not disconnect a surviving branch: any mate and B endpoint retain their cycle contacts, and x has no other residual singleton neighbor. It also does not change any other diagonal degree. Thus the iterative second reduction is valid.

## 2. Subdivision restrictions and path-chord checks

All displayed P7 sequences in Section3 have seven distinct vertices and every listed consecutive edge. Their chord exclusions were checked individually:

- For two marks at Bj, choose a diagonal neighbor y of one mark x. The other mark x' has the same A class. Unless x,x' are within-class mates, the displayed sequence through c(j+1),cj,y,x,c(j+3),x',z' is induced. The possible yx' chord is forbidden because diagonal edges between the two fixed classes form a matching. The known two neighbors of z' supply no other chord. Hence there are at most two marks and they are matched if both occur.
- The path cj,Bj,z,x,c(j+3),c(j+2),B(j+1) is induced if the neighboring B type exists. In particular a direct x--B(j+1) edge is forbidden by the inherited contact restrictions. Reflection handles the other neighbor. Active B indices are consequently an independent set in C5, of size at most two.
- A permitted direct neighbor y of B(j+2) gives the next displayed P7. Its only potentially unexcluded cross-A chord xy would make the explicit C4 through c(j+3) and B(j+2). Reflection handles B(j+3). Thus one active B allows at most one direct A-B edge globally, and two active B vertices allow none.
- For a B0--B2 subdivision, each of the three displayed paths using B1,B3,B4 is induced: the unused second cycle contacts are absent from its path, all B-B edges are absent, and z has exactly its two designated neighbors. Thus only B0,B2 remain. The unique-endpoint-pair C4 test then gives at most one B-B subdivision in total.

These arguments address multiple simultaneous unknown edges, rather than validating only isolated edge additions. The forbidden chords are excluded by the stated structural conditions, not assumed away.

## 3. Deficit and exhaustive case split

For G_A induced by the cycle and all A vertices, let D_A=3|G_A|-L(G_A). Adding b B vertices contributes 2b+e edges and exactly b triangles. Adding s+u remaining subdivision vertices contributes two edges and no triangle per vertex. Therefore the identity

`3n-L = D_A + 2b-2e-s-u`

is correct. When the diagonal graph has no C5 component, the audited Round13 bound gives D_A>=2.

The displayed case split for the remaining expression is exhaustive and correct. With no active B, s=0 and e<=b; if a B-B subdivision exists, b=2,u=1, giving a minimum of -1. With one active B, s<=2,e<=1 and b is1,2,or3; the respective worst bounds are -2,-1,2, using u=0 for b=1 or3 and u<=1 for b=2. With two active B vertices, b=2,e=0,s<=4,u<=1, giving at least -1. Hence the expression is always at least -2 and the total deficit is nonnegative.

## 4. Petersen alternative

A diagonal C5 component contains one vertex u_i in each A_i and, together with the fixed cycle, induces the Petersen graph. If any other diagonal component had an edge xy with classes i,i+2, the displayed P7 ci,x,y,c(i+2),c(i+3),u(i+3),u(i+1) would be induced. Cross-component diagonal edges are absent, and no within-class mate can be a chord because the two selected u-classes differ from both x,y classes. Therefore all other diagonal components are isolated vertices.

The second safe reduction ensures every surviving marked vertex has a diagonal neighbor, so every such mark must lie in this Petersen component. The two final displayed P7s correctly forbid, respectively, an A-B subdivision incident with u(j+3), and a B0-B2 subdivision. Their potentially relevant A-B edges have the wrong contact types and are forbidden. No within-class matching chord is possible among the selected exterior vertices. Thus no residual subdivision survives. The fixed C5 dominates the reduced graph, to which the audited Round13 theorem applies. Reversing all safe deletions proves the universal claim.

## 5. Independent finite verification

The author checker was inspected and rerun. Its exact scope is first-layer contact multisets of at most five vertices, all C4-free first-layer edges, and every permitted nonadjacent A-B/B-B subdivision. It gives11,649 P7/C7-free bases,27,265 C4-free residual configurations,14,894 P7/C7-free configurations, minimum deficit zero. It is not a general-order enumeration and does not cover every safely deleted decoration; those are handled analytically.

The independent `check_independent.cpp` uses a deliberately larger candidate residual domain: **every nonadjacent first-layer endpoint pair** is eligible for a subdivision, without assuming the A-B/B-B compatibility lemma. It derives the ten allowable first-layer contact masks by a direct C4 common-neighbor test and enumerates all contact multisets through five vertices and every C4-free first-layer edge set. Induced P7 and C7 are detected by exact seven-subset degree patterns and connectivity, not by copying the author's DFS. Every neighborhood independence number is computed by exhaustive independent-subset enumeration, not by relying on 2m-3t.

The independent counts are15,499 C4-free bases,11,649 P7/C7-free bases, and exactly14,894 valid residual configurations, agreeing with the author on the shared admissible domain. All surviving subdivisions automatically satisfy the claimed A-B/B-B compatibility, which is explicitly asserted after generation. The largest surviving order is14 and the minimum deficit is zero. There are45,850 C4-pruned and46,825 induced-P7/C7-pruned subdivision steps. These are search-branch counts, not claims about numbers of nonisomorphic graphs.

Reproduce with a C++17 compiler on the independent checker; the author rerun is recorded separately. The finite evidence supplements the analytic proof, including its unbounded layer-component reductions and Petersen alternative. No mathematical repair was needed. Any future standalone TeX consolidation should be compared against the pinned Markdown version before delivery.
