// Independent extension of fixed-C5 exhaustive validation. All nonadjacent
// first-layer endpoint pairs are tried; the A-B/B-B compatibility is NOT assumed.
// Forbidden induced P7 and C7 are recognized by exact seven-subset degrees and
// connectivity, rather than the author's path/cycle DFS.
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <vector>
using namespace std;using U=unsigned;
vector<U>a;vector<int>types,contacts;vector<pair<int,int>> firstpairs,subpairs,usedpairs;
uint64_t bases=0,valid=0,extra_pruned_c4=0,extra_pruned_p7c7=0,basefree=0;int minDef=999,maxorder=0;
void toggle(int x,int y){a[x]^=1u<<y;a[y]^=1u<<x;}
bool c4(){for(int x=0;x<(int)a.size();x++)for(int y=x+1;y<(int)a.size();y++)if(__builtin_popcount(a[x]&a[y])>=2)return true;return false;}
bool bad7(){int n=a.size();if(n<7)return false;U stop=1u<<n;for(U s=127;s<stop;){int ones=0,twos=0;bool ok=true;for(U b=s;b;b&=b-1){int d=__builtin_popcount(a[__builtin_ctz(b)]&s);if(d<1||d>2){ok=false;break;}ones+=d==1;twos+=d==2;}
 if(ok&&((ones==0&&twos==7)||(ones==2&&twos==5))){U seen=s&-s,old=0;while(seen!=old){old=seen;for(U b=seen;b;b&=b-1)seen|=a[__builtin_ctz(b)]&s;}if(seen==s)return true;}
 U c=s&-s,r=s+c;s=(((r^s)>>2)/c)|r;}return false;}
int local(){int L=0;for(U nb:a){int best=0;for(U s=nb;;s=(s-1)&nb){bool ind=true;for(U b=s;b;b&=b-1)if(a[__builtin_ctz(b)]&s){ind=false;break;}if(ind)best=max(best,__builtin_popcount(s));if(!s)break;}L+=best;}return L;}
pair<int,int> type(int mask){if(__builtin_popcount((unsigned)mask)==1)return {0,__builtin_ctz((unsigned)mask)};for(int i=0;i<5;i++)if(mask==((1<<i)|(1<<((i+1)%5))))return {1,i};assert(false);return{-1,-1};}
void evaluate(){valid++;maxorder=max(maxorder,(int)a.size());int def=3*a.size()-local();minDef=min(minDef,def);assert(def>=0);
 for(auto[x,y]:usedpairs){auto[t,i]=type(contacts[x-5]);auto[u,j]=type(contacts[y-5]);bool eligible=false;if(t==0&&u==1)eligible=i==(j+3)%5;if(t==1&&u==0)eligible=j==(i+3)%5;if(t==1&&u==1)eligible=(i-j+5)%5==2||(i-j+5)%5==3;assert(eligible);}
}
void subedges(int pos){if(pos==(int)subpairs.size()){evaluate();return;}subedges(pos+1);auto[x,y]=subpairs[pos];int z=a.size();assert(z<30);a.push_back(0);toggle(z,x);toggle(z,y);if(c4())extra_pruned_c4++;else if(bad7())extra_pruned_p7c7++;else{usedpairs.push_back({x,y});subedges(pos+1);usedpairs.pop_back();}toggle(z,x);toggle(z,y);a.pop_back();}
void firstdone(){basefree++;if(bad7())return;bases++;subpairs.clear();for(int x=5;x<(int)a.size();x++)for(int y=x+1;y<(int)a.size();y++)if(!(a[x]>>y&1))subpairs.push_back({x,y});subedges(0);}
void firstedges(int pos){if(pos==(int)firstpairs.size()){firstdone();return;}firstedges(pos+1);auto[x,y]=firstpairs[pos];toggle(x,y);if(!c4())firstedges(pos+1);toggle(x,y);}
void finish(){a.assign(5+contacts.size(),0);for(int i=0;i<5;i++)toggle(i,(i+1)%5);for(int j=0;j<(int)contacts.size();j++)for(int i=0;i<5;i++)if(contacts[j]>>i&1)toggle(5+j,i);if(c4())return;firstpairs.clear();for(int x=5;x<(int)a.size();x++)for(int y=x+1;y<(int)a.size();y++)firstpairs.push_back({x,y});firstedges(0);}
void choose(int left,int start){if(!left){finish();return;}for(int i=start;i<(int)types.size();i++){contacts.push_back(types[i]);choose(left-1,i);contacts.pop_back();}}
int main(){for(int s=1;s<32;s++){a.assign(6,0);for(int i=0;i<5;i++)toggle(i,(i+1)%5);for(int i=0;i<5;i++)if(s>>i&1)toggle(5,i);if(!c4())types.push_back(s);}assert(types.size()==10);for(int k=0;k<=5;k++)choose(k,0);
 cout<<"{\"status\":\"PASS\",\"scope\":\"All first-layer contact multisets through five vertices, all C4-free first-layer edge sets, and every subset of nonadjacent first-layer pairs subdivided once; induced P7/C7 exclusion checked directly\",\"C4_free_bases\":"<<basefree<<",\"P7_C7_free_bases\":"<<bases<<",\"P7_C7_free_residual_configurations\":"<<valid<<",\"pruned_subdivision_steps_C4\":"<<extra_pruned_c4<<",\"pruned_subdivision_steps_P7_C7\":"<<extra_pruned_p7c7<<",\"maximum_order_surviving\":"<<maxorder<<",\"minimum_deficit\":"<<minDef<<"}\n";
}
