# Weighted density with a five-cycle and no induced seven-cycle

**KEIO — 26 October 2026.**

**Status:** complete proposed analytic extension, awaiting independent review. This is a partial result toward original WOWII133, not a full resolution or a priority claim. The approved Round13 dominating-C5 paper is unchanged.

## Theorem

Every connected C4-subgraph-free P7-free graph containing an induced C5 but no induced C7 satisfies

    L(G):=sum_v alpha(G[N(v)]) ≤ 3|V(G)|.

Triangles are permitted. The only dependency is the independently audited Round13 dominating-C5 weighted-component argument, used in the precise form recalled below.

## 1. Contact classes and beyond-cycle components

Fix C=c_0...c_4c_0, with indices modulo five. Its first layer consists of A_i vertices with sole cycle contact c_i and at most one B_i vertex with contacts c_i,c_(i+1). The A_i induce matchings; diagonal edges run only A_i–A_(i±2), with at most one neighbor in each such class. Different B vertices are nonadjacent, and B_j has at most one first-layer A neighbor, which must lie in A_(j+3). These are the C4 checks in Round13.

Every first-layer vertex x starts an induced five-vertex path using x and four cycle vertices. Therefore each component Q of the set R of vertices with no cycle contact is complete to every first-layer vertex touching Q. Otherwise an edge a-b in Q with xa present and xb absent gives an induced P7 b,a,x followed by the four cycle vertices. Since Q⊆N(x), the common-neighbor condition forces Q to be K1 or K2. Connectedness ensures such an x exists. In particular no vertex has distance at least three from C.

A K2 component has exactly one first-layer neighbor, since two would give its two vertices two common neighbors. It is a pendant triangle. Removing it loses two vertices and three units of L=2m−3t, and is therefore safe for proving L≤3n.

Let z be a singleton R component. The only possible pairs of neighbors of z are:

- A_i,A_(i±2), necessarily adjacent;
- A_i,B_(i+2), adjacent or nonadjacent;
- B_i,B_(i±2), necessarily nonadjacent.

Indeed their cycle contacts must be disjoint, or a C4 uses z and a common cycle contact. An A_0,A_1 pair gives the induced P7 c_2,c_3,c_4,c_0,x,z,y. An A_0,A_2 nonedge gives the induced C7 x,c_0,c_4,c_3,c_2,y,z,x. An A_0,B_1 pair gives the same induced C7; an edge xy in that case is forbidden by the C4 x,c_0,c_1,y,x. Reflection excludes B_3, while B_0,B_4 share a contact with A_0. Two B types must have disjoint cycle edges, so their indices differ by ±2.

No three types are pairwise compatible: the A-only and B-only compatibility graphs are five-cycles, and every A type is compatible with only one B type, and conversely. Repeated types share a cycle contact. Thus d(z)≤2.

A singleton leaf has removal cost ΔL=2 for one vertex. A degree-two singleton whose neighbors are adjacent has ΔL=1. Remove these and all K2 components. Every remaining R vertex has degree two with nonadjacent neighbors and subdivides either A_i–B_(i+2) or B_i–B_(i±2). There is at most one subdivision vertex for any fixed endpoint pair, by C4 exclusion.

## 2. A second safe reduction

Call an A vertex marked if it is an endpoint of one of the remaining A–B subdivisions. Each A_i vertex supports at most one such subdivision, since the only possible B endpoint is the unique B_(i+2), and two subdivision vertices would give a C4.

Let D be the diagonal-edge graph on A, omitting the internal A_i matching edges. If a marked vertex x has degree zero in D, delete x together with its subdivision vertex z. The neighbors of x are its cycle contact, z, and possibly its unique within-class mate. It cannot have a direct B neighbor, since its only possible B neighbor is the nonadjacent endpoint of the subdivision. The pair deletion loses either three edges and no triangle, or four edges and one triangle. Thus ΔL is six or five for two vertices. This is safe.

Perform these deletions until every remaining marked vertex has a diagonal neighbor. All subsequent arguments concern this reduced induced graph. Proving its density bound proves the original one by reversing the safe deletions.

## 3. Restrictions imposed by a subdivision

Let z subdivide B_j–x with x∈A_(j+3). Call B_j active.

### At most two marks per active B

Suppose x has a diagonal neighbor y∈A_j; the A_(j+1) case is its reflection. If another mark x′ at B_j is not adjacent to x, with subdivision vertex z′, then

    c_(j+1),c_j,y,x,c_(j+3),x′,z′

is an induced P7. The possible diagonal edge yx′ is excluded because y already has a neighbor x in the same A class; all contacts of z′ are known. Therefore every other mark at B_j must be the within-class mate of x. There are at most two marks at B_j, and if there are two, they are matched.

### Neighboring B types are absent

If B_(j+1) existed, then

    c_j,B_j,z,x,c_(j+3),c_(j+2),B_(j+1)

would be an induced P7. Reflection excludes B_(j−1). Hence active B indices form an independent set in a five-cycle. There are at most two active B vertices. One active B leaves at most three B vertices in total; two active B vertices leave exactly those two B vertices.

### Other B vertices have no direct A neighbor

The only other possible B types are B_(j+2),B_(j+3). If B_(j+2) had its permitted direct neighbor y∈A_j, then

    c_(j+1),c_j,y,B_(j+2),c_(j+3),x,z

would be an induced P7. A potential chord xy is excluded by the C4 x,c_(j+3),B_(j+2),y,x. Reflection handles B_(j+3). Thus, with exactly one active B, at most that B has a direct A neighbor. With two active B vertices, neither can have a direct A neighbor.

### A B–B subdivision leaves exactly two B vertices

Suppose z subdivides B_0–B_2. The three other B types give these induced P7s:

- B_1: c_4,c_0,B_0,z,B_2,c_2,B_1;
- B_3: c_2,B_2,z,B_0,c_0,c_4,B_3;
- B_4: c_1,B_0,z,B_2,c_3,c_4,B_4.

Rotations and reflection cover every B–B subdivision. Consequently such a subdivision forces exactly two B vertices, and there is at most one B–B subdivision in total.

## 4. The deficit when the diagonal graph has no five-cycle

Let b be the number of B vertices, e the number of direct A–B edges, s the number of A–B subdivisions, and u the number of B–B subdivisions. Put G_A=G[V(C)∪A] and D_A=3|V(G_A)|−L(G_A). Adding B vertices introduces 2b+e edges and b triangles; adding the subdivision vertices introduces two edges and no triangle each. Therefore

    3n−L(G) = D_A + 2b−2e−s−u.                 (1)

The audited Round13 component proof shows that if the diagonal graph has no C5 component, then D_A≥2: its positive diagonal excess minus its within-class matching count is at most three, and D_A is five minus that quantity, with isolated diagonal vertices only increasing it.

The restrictions in Section3 imply

    2b−2e−s−u ≥ −2.                            (2)

For clarity, here is the complete case check. If there is no active B, then s=0. With u=0, use e≤b; with u=1, b=2 and e≤2 give a lower bound −1. If there is one active B, then s≤2 and e≤1. For b=1 we have u=0 and the expression is at least −2; for b=2 it is at least −1 because u≤1; for b=3 we have u=0 and it is at least two. If there are two active B vertices, then b=2, e=0, s≤4 and u≤1, giving a lower bound −1.

Equations (1) and (2) now prove 3n−L(G)≥0 whenever D has no C5 component.

## 5. The diagonal-five-cycle alternative

Suppose D has a C5 component. Label its vertices u_i∈A_i, with diagonal edges u_i u_(i±2). Together with C, these vertices induce the Petersen graph.

No diagonal edge can occur in any other component of D. Indeed an edge xy with x∈A_i and y∈A_(i+2), outside the displayed component, gives the induced P7

    c_i,x,y,c_(i+2),c_(i+3),u_(i+3),u_(i+1).

The possible within-class mates of x,y have indices i,i+2, neither of which appears among the two u vertices on the path. All other cross-component diagonal edges are absent by definition.

Thus every remaining marked A vertex lies in the displayed Petersen component, since the second safe reduction removed marked vertices with no diagonal neighbor. But a subdivision z between B_j and u_(j+3) gives the induced P7

    c_j,B_j,z,u_(j+3),c_(j+3),c_(j+2),u_(j+2).

Hence there are no A–B subdivisions. A B–B subdivision z between B_0,B_2 gives the induced P7

    c_0,c_1,u_1,u_3,c_3,B_2,z.

Again rotations and reflection cover every pair. Therefore there are no subdivision vertices at all. The fixed C5 now dominates the reduced graph, and the audited Round13 theorem gives L≤3n directly.

Both alternatives are proved. Reversing the safe deletions completes the theorem. ∎

## Exact remaining scope

The result eliminates the C5-containing, C7-free branch of a proposed general theorem L≤3n for C4-subgraph-free P7-free graphs. It does not yet prove that general theorem: graphs containing an induced C7 and graphs containing neither C5 nor C7 remain separate branches. No full WOWII133 resolution is claimed.
