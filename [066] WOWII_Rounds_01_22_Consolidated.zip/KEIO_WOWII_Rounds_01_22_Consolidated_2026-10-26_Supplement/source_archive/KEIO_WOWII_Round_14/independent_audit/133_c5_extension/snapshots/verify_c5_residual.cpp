#include <bits/stdc++.h>
using namespace std;using U=uint64_t;mt19937 rng(133202610);
struct G{
 int n;vector<U>N;G(int n):n(n),N(n){};
 void edge(int u,int v){N[u]|=1ull<<v;N[v]|=1ull<<u;}
 void del(int u,int v){N[u]&=~(1ull<<v);N[v]&=~(1ull<<u);}
 bool allowed(int u,int v,bool trianglefree){if(u==v||(N[u]>>v&1))return false;if(trianglefree&&(N[u]&N[v]))return false;U a=N[u];while(a){int x=__builtin_ctzll(a);a&=a-1;if(N[x]&N[v])return false;}return true;}
 bool connected(){U seen=1,front=1;while(front){U next=0;while(front){int u=__builtin_ctzll(front);front&=front-1;next|=N[u];}front=next&~seen;seen|=front;}return __builtin_popcountll(seen)==n;}
 int radius(){int rad=n;for(int s=0;s<n;s++){U seen=1ull<<s,front=seen;int d=0;while(__builtin_popcountll(seen)<n){U next=0;while(front){int u=__builtin_ctzll(front);front&=front-1;next|=N[u];}front=next&~seen;seen|=front;d++;if(!front)return n;}rad=min(rad,d);}return rad;}
 int local_sum(){int degrees=0,tri6=0;for(int u=0;u<n;u++){degrees+=__builtin_popcountll(N[u]);U z=N[u];while(z){int v=__builtin_ctzll(z);z&=z-1;tri6+=__builtin_popcountll(N[u]&N[v]);}}return degrees-tri6/2;}
 long long nodes=0;bool haspath(int target){function<bool(int,int,U,U)>dfs=[&](int v,int len,U used,U forbid){nodes++;if(len>=target)return true;U cand=N[v]&~(used|forbid);while(cand){int u=__builtin_ctzll(cand);cand&=cand-1;if(dfs(u,len+1,used|(1ull<<u),forbid|N[v]))return true;}return false;};for(int s=0;s<n;s++)if(dfs(s,1,1ull<<s,0))return true;return false;}
 void print(){for(int u=0;u<n;u++)for(int v=0;v<u;v++)if(N[u]>>v&1)cout<<u<<","<<v<<";";cout<<endl;}
};


bool c7(G&g){for(int start=0;start<g.n;start++){function<bool(int,int,U)>dfs=[&](int v,int len,U seen){U can=g.N[v]&~seen;while(can){int u=__builtin_ctzll(can);can&=can-1;if(u<start)continue;U expect=(1ull<<v);if(len==6)expect|=1ull<<start;if((g.N[u]&seen)!=expect)continue;if(len==6)return true;if(dfs(u,len+1,seen|(1ull<<u)))return true;}return false;};if(dfs(start,1,1ull<<start))return true;}return false;}
long long bases=0,graphs=0,pass=0;int mindef=999;vector<int>types;
void subdivisions(G&g){if(g.haspath(7)||c7(g))return;bases++;vector<pair<int,int>>ps;for(int i=0;i<(int)types.size();i++)for(int j=0;j<i;j++){int x=types[i],y=types[j];if(g.N[5+i]>>(5+j)&1)continue;bool good=false;if(x<5&&y>=5)good=(x==(y-5+3)%5);else if(y<5&&x>=5)good=(y==(x-5+3)%5);else if(x>=5&&y>=5)good=((x-y+5)%5==2||(x-y+5)%5==3);if(good)ps.push_back({5+i,5+j});}
for(int mask=0;mask<(1<<(int)ps.size());mask++){G h(g.n+__builtin_popcount((unsigned)mask));for(int i=0;i<g.n;i++)h.N[i]=g.N[i];int z=g.n;bool ok=true;for(int j=0;j<(int)ps.size();j++)if(mask>>j&1){auto[u,v]=ps[j];h.edge(z,u);if(!h.allowed(z,v,false)){ok=false;break;}h.edge(z++,v);}if(!ok)continue;graphs++;if(h.haspath(7)||c7(h))continue;pass++;int D=3*h.n-h.local_sum();mindef=min(mindef,D);if(D<0){cerr<<"FAIL D "<<D<<endl;h.print();exit(1);}}}
void edges(G&g,vector<pair<int,int>>&ps,int i){if(i==(int)ps.size()){subdivisions(g);return;}edges(g,ps,i+1);auto[u,v]=ps[i];if(g.allowed(u,v,false)){g.edge(u,v);edges(g,ps,i+1);g.del(u,v);}}
void run(){G g(5+types.size());for(int i=0;i<5;i++)g.edge(i,(i+1)%5);for(int j=0;j<(int)types.size();j++){int t=types[j];g.edge(5+j,t%5);if(t>=5)g.edge(5+j,(t+1)%5);}for(int u=0;u<g.n;u++)for(int v=0;v<u;v++)if(__builtin_popcountll(g.N[u]&g.N[v])>1)return;vector<pair<int,int>>ps;for(int i=0;i<(int)types.size();i++)for(int j=0;j<i;j++)ps.push_back({5+i,5+j});edges(g,ps,0);}
void choose(int left,int last){run();if(!left)return;for(int t=last;t<10;t++){if(t>=5&&find(types.begin(),types.end(),t)!=types.end())continue;types.push_back(t);choose(left-1,t);types.pop_back();}}
int main(){choose(5,0);cout<<"{\"status\":\"PASS\",\"scope\":\"All C5 contact-type multisets of at most five first-layer vertices, every C4-free first-layer edge set, and all nonadjacent eligible A-B/B-B subdivisions\",\"P7_C7_free_bases\":"<<bases<<",\"C4_free_graphs\":"<<graphs<<",\"P7_C7_free_graphs\":"<<pass<<",\"minimum_3n_minus_L\":"<<mindef<<"}"<<endl;}
