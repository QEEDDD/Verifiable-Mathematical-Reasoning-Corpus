# Independent audit: historical half-coefficient/open-neighborhood WOWII354

**Mathematical verdict: PASS for the exact pinned historical formula.** The36-vertex tree and the entire family refute the half-coefficient, open-neighborhood statement. This is not an unqualified claim about the latest live curator formulation, current unresolved status, worldwide novelty, or the separately stated closed-neighborhood variant. Those source questions belong to the source-audit lane. No minimum-order claim is made.

## 1. Exact historical scope and definitions

The pinned original HTML row354, dated18 February2009, states for every tree T of order n>2:

`gamma_t(T) >= (|C(T)|/2) * c(T[N(D_2(T))])`,

where D_2 consists of vertices of degree exactly two, C is the entire center, and c counts induced connected components, including isolated vertices. The coefficient one-half is present literally in the HTML transcription; it must not be dropped. The subscript displayed as capital T in part of the source is identified as total domination by its referenced definition94.

The recovered original glossary was independently inspected and pinned: definition46 gives N(S) as the union of open neighborhoods; definition54 separately defines N[S]=N(S) union S; definition64 gives all minimum-eccentricity vertices as the center; definition94 is total domination, including domination of selected vertices; definition100 defines the induced subgraph. The computation uses precisely these conventions. The right side counts **components**, not an independence number, although the induced graph in this example happens to be independent.

The author's historical-source qualification is appropriate. A result about the coefficient-one formula does not automatically settle the half-coefficient formula; a result about closed neighborhoods concerns a different set. This audit establishes the mathematics of the pinned formula and leaves priority/live-status evidence separate.

## 2. Physical tree and family

Each branch has eleven vertices a,b,c,d,e,f,g,h,i,j,ell with edges ab,ac,bd,de,df,fg,ch,hi,hj,jell. It is attached by one edge from a to its designated center. The two arms have depths1 through5 from that center, and deepest leaves g,ell have depth five.

For k>=2, start with edge uv, attach one branch to u and k branches to v, and attach one additional leaf z to u. This is a simple tree because each new branch is a tree joined by exactly one edge. Its order is11k+14 and size11k+13. For k=2, n=36,m=35.

The degrees of u and v are3 and k+1, so neither contributes to D_2. In each branch only b,c,f,j have degree two; their open neighborhood is exactly {a,d,h,g,ell}. Those five vertices are pairwise nonadjacent, and no two different branches have edges between their contributed vertices. Centers and the additional leaf are not in this neighborhood. Therefore the induced open-neighborhood graph is independent on5(k+1) vertices and has exactly that many components.

## 3. Center and exact total domination

A deepest leaf on the u side and a deepest leaf on the v side have distance11. No pair has larger distance: same-side vertices are at most10 apart and opposite-side vertices at most5+1+5. Each of u,v has eccentricity6. Any other vertex at positive depth q from its designated endpoint has distance q+1+5>=7 to a deepest leaf on the opposite side. This includes the additional leaf. Hence the center is exactly {u,v}, radius6, diameter11.

Take u,v and d,f,h,j in every branch. They total-dominate all vertices, including themselves: u,v dominate each other; d,f and h,j are adjacent selected pairs; the center dominates a; d and h dominate b and c; the appropriate selected support dominates each branch leaf; u dominates the additional leaf. The certificate has4k+6 vertices.

The author's exact lower bound also passes. Every branch leaf forces its neighbor d,f,h,j, giving4(k+1) distinct forced vertices, and the additional leaf forces u. None of those4(k+1)+1 vertices is a neighbor of u. Total domination of u requires one more selected vertex. Thus gamma_t=4k+6, not merely an upper bound.

The historical right side is (2/2)*5(k+1)=5k+5. Its excess over gamma_t is k-1>0, unbounded as k grows. In particular the36-vertex instance gives **14<15**. Only the upper certificate is needed for refutation, but the exact lower proof removes any optimization uncertainty.

## 4. Open versus closed neighborhood

This distinction was checked independently rather than assumed. Under the closed convention, each branch contributes the nine vertices {a,b,c,d,f,g,h,j,ell}, inducing one connected tree. Different branches remain disconnected because the centers are absent. Thus c(T[N[D_2]])=k+1, only3 in the principal instance. Its half-coefficient closed-neighborhood right side is3, which is satisfied by gamma_t=14. This witness does **not** refute that variant. Since D_2 happens to be independent here, open union and external neighborhood coincide on this particular family, but the historical definition is explicitly the open union.

## 5. Independent computation

The independent standard-library program `check_independent.py` constructs the tree as two-arm branch gadgets; it does not import the author or root verifier, graph statistics, masks, or edge list. It computes BFS distances from every physical vertex, eccentricities, every center, degree-two vertices, open and closed neighborhood unions, and their induced connected components. It directly checks every vertex's selected neighbor in the certificate.

In addition, an independent bottom-up tree dynamic program computes the exact total domination number. Its states specify whether a vertex and its parent are selected. Every subtree vertex must be dominated; the vertex itself must see a selected parent or at least one selected child. This includes selected vertices and thus does not accidentally compute ordinary domination. It returns14 for the principal tree, matching the certificate and analytic lower bound.

Principal exact results: n36,m35, radius6, diameter11, centers0 and1, twelve degree-two vertices, fifteen open-neighborhood singleton components, three closed-neighborhood components, gamma_t14, historical right side15. The full distance matrix, graph adjacency/edges, certificate, forced supports and component lists are retained. The independently built edge set and eccentricity vector were compared only after computation and match the author output.

Additional fresh controls at k=3,4,5,10,20 all verify the exact tree-DP optimum4k+6, center size2, radius6, diameter11, open component count5(k+1), and strict gapk-1. They also confirm the closed variant is satisfied. These finite checks supplement the arbitrary-k proof, not replace it.

## 6. Frozen proof consistency and limitations

Both complete frozen `counterexample_354.md` and the mathematical text of `counterexample_354.tex` were reviewed. They preserve the exact half coefficient, open-union convention, physical family, forced-support lower bound, unbounded additive gap and historical-source disclaimer. No mathematical repair was needed. The discovery dynamic program is not a proof dependency. Any final root-formatted delivery source should be diffed against the pinned TeX before packaging.

The report intentionally does not turn a historical O marker into an assertion of current open status, and does not decide whether the bounded source gate warrants a new-closure allocation. The mathematical statement refuted here is fully specified and unconditional.
