#!/usr/bin/env python3
from check_independent import build,bfs,components,exact_total_domination_tree
from pathlib import Path
from fractions import Fraction
import json
_,edges,_,_=build(2)
a=[set() for _ in range(34)]
def merge(v):return 0 if v in [0,1] else v-2
for x,y in edges:
    if 2 in [x,y]:continue
    x,y=merge(x),merge(y)
    if x==y:continue
    a[x].add(y);a[y].add(x)
D=[bfs(a,v) for v in range(34)];e=list(map(max,D));radius=min(e);C=[v for v in range(34) if e[v]==radius]
D2={v for v in range(34) if len(a[v])==2};X=set().union(*(a[v] for v in D2));cc=components(a,X);gt=exact_total_domination_tree(a);rhs=Fraction(len(C)*len(cc),2)
assert sum(map(len,a))//2==33 and gt==14 and len(cc)==15 and C==[0] and radius==5 and max(e)==10 and rhs==Fraction(15,2)
out={'status':'PASS','scope':'numerical check of the explicitly described unicentral three-branch Feit precursor; source-image identification remains in separate source audit','n':34,'m':33,'gamma_t':gt,'open_components':len(cc),'center':C,'radius':radius,'diameter':max(e),'historical_half_open_rhs':str(rhs),'refutes_historical_half_open':gt<rhs}
Path(__file__).with_name('feit_precursor_control.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
