#!/usr/bin/env python3
"""Independent physical BFS, induced-component and exact tree-DP audit."""
from collections import deque
from fractions import Fraction
from pathlib import Path
import json

def build(k):
    # Build each branch as two arms with a side leaf at depth three.
    adjacency=[set() for _ in range(3)];edges=[];certificate={0,1};branches=[]
    def new():adjacency.append(set());return len(adjacency)-1
    def link(x,y):
        assert x!=y and y not in adjacency[x]
        adjacency[x].add(y);adjacency[y].add(x);edges.append([x,y])
    link(0,1);link(0,2)
    for center in [0]+[1]*k:
        a=new();link(center,a);branch={'a':a}
        # Allocate vertices in the author's named order without copying its edge list.
        b=new();c=new();d=new();e=new();f=new();g=new();h=new();i=new();j=new();ell=new()
        branch.update(zip(['b','c','d','e','f','g','h','i','j','k'],[b,c,d,e,f,g,h,i,j,ell]));branches.append(branch)
        for first,support,sideleaf,nextvertex,end in [(b,d,e,f,g),(c,h,i,j,ell)]:
            link(a,first);link(first,support);link(support,sideleaf);link(support,nextvertex);link(nextvertex,end);certificate.update([support,nextvertex])
    return adjacency,edges,certificate,branches

def bfs(adj,r):
    d=[-1]*len(adj);d[r]=0;q=deque([r])
    while q:
        x=q.popleft()
        for y in adj[x]:
            if d[y]<0:d[y]=d[x]+1;q.append(y)
    assert min(d)>=0
    return d

def components(adj,S):
    S=set(S);out=[]
    while S:
        r=S.pop();part={r};q=[r]
        for v in q:
            more=adj[v]&S;S-=more;part|=more;q.extend(more)
        out.append(sorted(part))
    return sorted(out)

def exact_total_domination_tree(adj):
    # DP[v][selected_v][selected_parent], enforcing domination of every subtree
    # vertex, including v. An independently selected parent may dominate v.
    n=len(adj);parent=[-1]*n;parent[0]=0;order=[0]
    for x in order:
        for y in adj[x]:
            if parent[y]<0:parent[y]=x;order.append(y)
    assert len(order)==n
    inf=n+1;dp=[None]*n
    for v in reversed(order):
        table=[[inf,inf],[inf,inf]]
        for sv in range(2):
            costs=[0,inf]
            for c in adj[v]:
                if c==parent[v]:continue
                nxt=[inf,inf]
                for anychild in range(2):
                    for sc in range(2):nxt[anychild|sc]=min(nxt[anychild|sc],costs[anychild]+dp[c][sc][sv])
                costs=nxt
            table[sv][0]=sv+costs[1]
            table[sv][1]=sv+min(costs)
        dp[v]=table
    return min(dp[0][0][0],dp[0][1][0])

def check(k,full=False):
    adj,edges,D,branches=build(k);n=len(adj);assert len(edges)==n-1
    dist=[bfs(adj,v) for v in range(n)];ecc=[max(row) for row in dist];radius=min(ecc);C=[v for v in range(n) if ecc[v]==radius]
    D2={v for v in range(n) if len(adj[v])==2};openN=set().union(*(adj[v] for v in D2));closedN=openN|D2
    opencomponents=components(adj,openN);closedcomponents=components(adj,closedN)
    assert C==[0,1] and radius==6 and max(ecc)==11
    assert D2=={b[x] for b in branches for x in ['b','c','f','j']}
    assert openN=={b[x] for b in branches for x in ['a','d','g','h','k']}
    assert all(adj[v]&D for v in range(n))
    forced={next(iter(adj[v])) for v in range(n) if len(adj[v])==1}
    assert forced=={0}|{b[x] for b in branches for x in ['d','f','h','j']}
    assert not(adj[branches[1]['a']]&forced)
    optimum=exact_total_domination_tree(adj);assert optimum==len(D)==4*k+6
    rhs=Fraction(len(C)*len(opencomponents),2);closedrhs=Fraction(len(C)*len(closedcomponents),2)
    assert len(opencomponents)==5*(k+1) and all(len(c)==1 for c in opencomponents)
    assert len(closedcomponents)==k+1 and rhs-optimum==k-1 and optimum>=closedrhs
    out={'k':k,'n':n,'m':len(edges),'radius':radius,'diameter':max(ecc),'centers':C,'total_domination_exact':optimum,'certificate_size':len(D),'open_neighborhood_components':len(opencomponents),'closed_neighborhood_components':len(closedcomponents),'literal_half_open_rhs':str(rhs),'literal_violation_gap':str(rhs-optimum),'half_closed_rhs':str(closedrhs),'closed_variant_refuted':False}
    if full:out.update(edges=edges,adjacency=[sorted(x) for x in adj],distance_matrix=dist,eccentricities=ecc,D2=sorted(D2),open_neighborhood=sorted(openN),open_components=opencomponents,closed_components=closedcomponents,total_dominating_certificate=sorted(D),forced_supports=sorted(forced))
    return out
if __name__ == "__main__":
    principal=check(2,True)
    author=json.loads((Path(__file__).resolve().parents[2]/'leaves/354_counterexample/verification.json').read_text())['principal']
    assert {tuple(sorted(e)) for e in principal['edges']}=={tuple(sorted(e)) for e in author['edges']}
    assert principal['eccentricities']==author['eccentricities']
    out={'status':'PASS literal historical half/open formula','method':'independent physical construction, BFS, components, and exact tree total-domination DP; analytical lower bound from forced supports also verified','principal':principal,'family_controls':[check(k) for k in [3,4,5,10,20]]}
    Path(__file__).with_name('independent_results.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in principal.items() if k not in ['edges','adjacency','distance_matrix','eccentricities','D2','open_neighborhood','open_components','closed_components','total_dominating_certificate','forced_supports']},indent=2))
