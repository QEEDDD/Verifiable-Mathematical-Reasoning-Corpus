# A counterexample to the historical half-coefficient, open-neighborhood formulation of WOWII #354

## 1. Exact statement and scope

The pinned original WOWII row #354, dated 18 February 2009, states that a tree T of order greater than two satisfies

\[
\gamma_t(T)\ \ge\ \frac{|C(T)|}{2}\,c\bigl(T[N(D_2(T))]\bigr).
\tag{354-half/open}
\]

Here \(\gamma_t\) is the total domination number, \(C(T)\) is the full center, \(D_2(T)=\{x:\deg_T(x)=2\}\), and
\(N(A)=\bigcup_{a\in A}N(a)\) is the **union of open neighborhoods**. Components of the induced subgraph include isolated vertices. This is neither the external neighborhood \(N(A)\setminus A\) nor the closed neighborhood \(N[A]\).

We give a 36-vertex counterexample and an infinite family. The counterexample has

\[
\gamma_t(T)=14,\qquad |C(T)|=2,\qquad c(T[N(D_2(T))])=15,
\]

so the displayed historical inequality would require \(14\ge15\).

**Source qualification.** The literal coefficient one-half is preserved both in the [pinned HTML-row archive](https://gitlab.com/ai-village-agents/village/graffiti-verification/-/blob/3be380b4222f974bedbefb228c8e75fbd9a7b3ae/data/wow2_rows_html.json) and in a recovered 23 July 2026 archive of the original HTML. An inspected ASCII-only export loses this glyph; that loss is not evidence of a curator revision. An inspected public 2026 paper refutes the coefficient-one/open version and proves a closed-neighborhood version, neither of which settles the exact historical half/open formula. The present mathematical result concerns the pinned formula only. The bounded source audit does not certify worldwide priority or the latest live curator status; comparison with the full Desormeaux–Henning 2016 paper remained incomplete when this proof was frozen. See the accompanying source audit rather than interpreting a historical O label as present open status.

## 2. Feit’s earlier construction and the bicentral modification

The eleven-vertex branch below is **not claimed as new**. P. Feit’s published 34-vertex counterexample to WOWII #240/#346 consists of one root with three copies of exactly this branch. Its [original archived image](https://web.archive.org/web/20100718125429id_/http://cms.uhd.edu/faculty/delavinae/research/wowII/ceDalm240.jpg) has been recovered and independently compared with the branch template. The example and the unbounded-gap extension are credited to Feit in DeLaViña–Larson–Pepper–Waller, *Graffiti.pc on the total domination number of a tree*, Congressus Numerantium 195 (2009), 5–18, manuscript p.7 ([primary paper](https://www.uhd.edu/documents/academics/sciences/boca2009-dlpw.pdf)).

Feit’s 34-vertex tree has total domination number14 and15 open-neighborhood components, but only **one** center (radius5, diameter10). Consequently its right-hand side in (354-half/open) is15/2, and that older example does not refute the half-coefficient formula. Our principal36-vertex tree is a **bicentral modification of Feit’s construction**: split the common root into adjacent vertices, place one branch on one side and two on the other, and add a leaf on the one-branch side to keep both new central vertices from having degree two. The contribution asserted here is this source-qualified application/modification, not the original branch or the older component-bound counterexample.

## 3. One branch

Let \(B\) have eleven distinct vertices

\[
a,b,c,d,e,f,g,h,i,j,\ell
\]

and ten edges

\[
ab,\ ac,\ bd,\ de,\ df,\ fg,\ ch,\ hi,\ hj,\ j\ell.
\]

The vertex \(a\) is its attachment vertex. When \(a\) is joined to a new vertex \(r\), the distances from \(r\) are:

| Distance | Branch vertices |
|---:|:---|
| 1 | a |
| 2 | b, c |
| 3 | d, h |
| 4 | e, f, i, j |
| 5 | g, ell |

In the resulting tree, the branch vertices of degree two are exactly \(b,c,f,j\); vertices \(a,d,h\) have degree three, and \(e,g,i,\ell\) are leaves. Consequently, the union of the open neighborhoods of these four degree-two vertices is

\[
\{a,d,h,g,\ell\}.
\tag{1}
\]

These five vertices are pairwise nonadjacent.

## 4. The family

Fix an integer \(k\ge2\). Start with an edge \(uv\). Attach one copy of \(B\) to \(u\), and \(k\) pairwise disjoint copies to \(v\), by joining each copy's vertex \(a\) to its designated endpoint. Finally add one new leaf \(z\) adjacent to \(u\). There are no other vertices or edges. Call the resulting tree \(T_k\).

Every branch is attached by one edge to the original edge, and \(z\) is pendant, so this is a tree. Its order and size are

\[
|V(T_k)|=2+1+11(k+1)=11k+14,\qquad
|E(T_k)|=11k+13.
\]

The principal example is \(T_2\), of order 36 and size 35.

## 5. Degree-two neighborhood components

The degrees of \(u\) and \(v\) are respectively 3 and \(k+1\), hence neither is degree two. The new vertex \(z\) is a leaf. The preceding branch calculation therefore lists **all** degree-two vertices of \(T_k\): each branch contributes precisely \(b,c,f,j\).

Equation (1) shows that \(N(D_2(T_k))\) consists of five vertices from each branch. Neither \(u\), \(v\), nor \(z\) belongs to this union, and different branches have no edges between them. The five vertices within a branch are also pairwise nonadjacent. Thus the entire induced subgraph is independent, and

\[
c\bigl(T_k[N(D_2(T_k))]\bigr)=5(k+1).
\tag{2}
\]

This computation uses the open-union convention directly; it does not replace that neighborhood by an external or closed one.

## 6. The center

Every branch has maximum depth five from the endpoint to which it is attached, and has vertices at that depth. A depth-five vertex on the \(u\)-side and a depth-five vertex on the \(v\)-side have distance 11. No two vertices have greater distance: vertices on one side have distance at most 10, and vertices on opposite sides have distance at most \(5+1+5=11\). Therefore the diameter is 11.

Both \(u\) and \(v\) have eccentricity 6: they are at distance six from depth-five vertices on the opposite side, and all other vertices are no farther away. If \(x\notin\{u,v\}\) lies on one side at depth \(q\ge1\), then its distance to a depth-five vertex on the opposite side is exactly \(q+1+5\ge7\). This also applies to the extra leaf \(z\). Hence no other vertex is central, and

\[
C(T_k)=\{u,v\},\qquad \operatorname{rad}(T_k)=6.
\tag{3}
\]

## 7. Exact total domination number

Let \(D\) consist of \(u,v\) and the four vertices \(d,f,h,j\) in every branch. It has size

\[
|D|=2+4(k+1)=4k+6.
\]

The centers dominate each other, and \(u\) dominates \(z\). In each branch, \(a\) is dominated by its attached center; \(b\) by \(d\); \(c\) by \(h\); the pair \(d,f\) dominates itself and the leaves \(e,g\); and the pair \(h,j\) dominates itself and the leaves \(i,\ell\). Thus every vertex, including every member of \(D\), has a neighbor in \(D\). This proves \(\gamma_t(T_k)\le4k+6\).

For the reverse inequality, the branch leaves \(e,g,i,\ell\) force their four distinct neighbors \(d,f,h,j\) into every total dominating set. The leaf \(z\) forces \(u\). These are \(4(k+1)+1\) forced vertices. None is adjacent to \(u\): its neighbors are \(v\), the vertex \(a\) of the single left branch, and \(z\), none of which is among those forced vertices. Total domination of \(u\) therefore requires at least one further vertex. Consequently,

\[
\gamma_t(T_k)=4k+6.
\tag{4}
\]

Only the upper certificate is needed for the counterexample; the lower argument makes the displayed value exact without exhaustive search.

## 8. Contradiction and size of the gap

Combining (2), (3), and (4), the right-hand side of (354-half/open) is

\[
\frac{2}{2}\,5(k+1)=5k+5,
\]

whereas its left-hand side is \(4k+6\). The claimed lower bound exceeds the actual total domination number by

\[
(5k+5)-(4k+6)=k-1>0.
\]

Thus every \(T_k\), \(k\ge2\), refutes the pinned historical formulation. The additive error is unbounded. For \(k=2\), this is the promised 36-vertex inequality \(14<15\). No minimum-order claim is made.

## 9. Reproducible certificate

The adjacent file `verify_354.py` uses only the Python standard library. It constructs the graphs independently from the edge template, checks connectivity and the tree edge count, computes all distances by BFS, verifies the center and diameter, obtains the degree-two set and its open union neighborhood directly from the adjacency lists, counts induced components, and checks the total dominating certificate. Fractions are exact.

`verification.json` records the principal graph and checks at \(k=2,3,4,10\); `counterexample36.edgelist` is the principal edge list. These computations corroborate the hand proof and are not its substitute. In the code, the final branch vertex is named `k` rather than the manuscript's \(\ell\); this is only a label, not the family parameter.

In the present session, the bicentral modification was reached after a rooted-tree dynamic-program search produced a counterexample to the stronger inequality \(\gamma_t\ge c(T[N(D_2)])\). The subsequent source audit identified the exact Feit precursor, which is credited above. The search is discovery provenance, not a proof dependency or a priority claim.
