# WOWII #354: final source-qualified counterexample gate

**Checked 26 October 2026, 05:23 UTC.**

**Disposition:** the 36-vertex certificate refutes the **pinned historical half-coefficient, open-neighborhood statement**. No prior counterexample to this exact statement was located in the bounded inspected sources. This is **not** a certification of worldwide priority or present live-curator status. The branch construction has a clear prior source: Feit’s 2009 example.

## 1. Original statement independently locked

The original catalogue [23 July 2026 archived HTML](https://web.archive.org/web/20260723161800id_/http://cms.uhd.edu/faculty/delavinae/research/wowII/all.html) explicitly contains

`gamma_t(T) >= (1/2)|C(T)| * c(T[N(D_2(T))])`, for trees of order greater than two.

The half glyph is present in the retrieved response, agreeing with the earlier pinned JSON. The open neighborhood means the union of individual open neighborhoods (original definition 46), not the closed neighborhood. C is the set of centers. The raw selected row and normalized record are `original_row_354.html` and `statement354_from_live_archive.json`.

The response decodes fully as UTF-8, despite its legacy windows-1252 declaration; the half glyph has bytes C2 BD. The July28 ASCII-only attachment lacks the literal half glyph. This discrepancy must not be described as a demonstrated curator revision or as an arithmetic error in another author's theorem.

## 2. Feit’s primary 34-vertex witness is a precursor, not the same refutation

The catalogue links [Feit’s original diagram, archived 18 July 2010](https://web.archive.org/web/20100718125429id_/http://cms.uhd.edu/faculty/delavinae/research/wowII/ceDalm240.jpg). The image was recovered and visually inspected. It consists of one central root with three copies of the same eleven-vertex branch used by the present construction.

Independent reconstruction/check (`reconstruct_feit34.py`, `feit34_comparison.json`) gives:

| Quantity | Feit34 |
|---|---:|
| Total domination number | 14 |
| Open-neighborhood component count | 15 |
| Number of centers | 1 |
| Radius / diameter | 5 / 10 |
| Historical #354 right side | 15/2 |

All degree-two vertices are independent, so its open and external neighborhoods coincide. It refutes the stronger component-only bound, as reported for #240/#346, but **does not refute half/open #354**. DLPW, *Graffiti.pc on the total domination number of a tree*, Congressus Numerantium 195 (2009), 5–18, also records Feit’s example; [primary PDF](https://www.uhd.edu/documents/academics/sciences/boca2009-dlpw.pdf).

The present36-tree is a **bicentral modification of Feit’s construction**. Its certified TDS of size14, fifteen open-neighborhood components and two centers give `gamma_t<=14<15=RHS`. No novelty of the branch construction, and no global minimal-order claim, is asserted.

## 3. Current public #354 claims checked

[Issue7276](https://github.com/google-deepmind/formal-conjectures/issues/7276), created13October2026, and [PR7373](https://github.com/google-deepmind/formal-conjectures/pull/7373), created15October and last updated26October00:38UTC, explicitly target a **closed-neighborhood variant**. PR7373 remains open/unmerged at retrieved head `d314161aab663c4f977aa3884293d48e80f63a78`.

The current [immutable certificate endpoint](https://github.com/RhudeJJJJ/formal-conjectures/blob/afe9d3138ae1da4df353114471573ea4d46fccba/Proofs/WOWII376354/WOWII354Full.lean) was read, not executed. All three theorem types use `closedNeighbors`. Thus no external Lean-validation claim is made here.

The accompanying five-vertex open-neighborhood example has gamma_t=2, two centers and two components. It refutes the **coefficient-one/open** expression, but gives equality in the historical half/open expression. Its closed-neighborhood theorem remains a different statement.

Fresh all-state GitHub searches for exact354 and equivalent neighborhood/half-component wording found these existing claims and unrelated hits, not an identical bicentral half/open counterexample. Raw queries, bodies and comments are saved beside `api_summary.json`. The general search also surfaced an unrelated Erdős354 aggregation; it was not treated as a WOWII result.

## 4. Remaining primary-literature limitation

Desormeaux–Henning, *Lower bounds on the total domination number of a graph*, J. Combin. Optim.31 (2016),52–66, [DOI10.1007/s10878-014-9708-2](https://doi.org/10.1007/s10878-014-9708-2), was accessible only as publisher/institutional abstract and metadata. Its full text was **not read**. It may contain other relevant counterexamples; this audit does not certify that it fails to cover #354.

Live original UHD retrieval returned503. Historical O is not used as proof of present unresolved status. No author/curator was contacted and no external state was changed.

## Safe release wording

“An independently verified counterexample to the archived original half-coefficient/open-neighborhood version of WOWII #354, obtained by a bicentral modification of Feit’s 2009 construction. No prior resolution of this exact version was located in the bounded checked sources; worldwide priority and live-curator status are not certified.”
