"""Independent standard-library checker for the source-qualified half/open #354.
Upper TDS certificate only; no minimum-total-domination computation is needed.
"""
from collections import deque
from fractions import Fraction
import json
from pathlib import Path
OUT=Path(__file__).resolve().parent

def construct(k=2):
 assert k>=2
 names=['u','v','leaf_u'];edges=[(0,1),(0,2)];D={0,1};branches=[]
 for side,count in [(0,1),(1,k)]:
  for j in range(count):
   labels=['a','b','c','d','e','f','g','h','i','j','k'];ids={x:len(names)+i for i,x in enumerate(labels)}
   names.extend(f'{names[side]}{j}_{x}'for x in labels)
   edges.append((side,ids['a']))
   edges.extend((ids[x],ids[y])for x,y in [('a','b'),('a','c'),('b','d'),('d','e'),('d','f'),('f','g'),('c','h'),('h','i'),('h','j'),('j','k')])
   D.update(ids[x]for x in ['d','f','h','j']);branches.append(ids)
 return names,edges,D,branches

def verify(k):
 names,edges,D,branches=construct(k);n=len(names);N=[set()for _ in names]
 for a,b in edges:N[a].add(b);N[b].add(a)
 def bfs(r):
  dist=[None]*n;dist[r]=0;q=deque([r])
  while q:
   a=q.popleft()
   for b in N[a]:
    if dist[b]is None:dist[b]=dist[a]+1;q.append(b)
  assert None not in dist
  return dist
 distances=[bfs(r)for r in range(n)];ecc=list(map(max,distances));rad=min(ecc);C=[v for v,e in enumerate(ecc)if e==rad]
 assert len(edges)==n-1
 Y={v for v in range(n)if len(N[v])==2};X=set().union(*(N[y]for y in Y))
 comps=[];unseen=set(X)
 while unseen:
  root=unseen.pop();q=[root];comp={root}
  for a in q:
   for b in N[a]&unseen:unseen.remove(b);q.append(b);comp.add(b)
  comps.append(sorted(comp))
 td=all(N[v]&D for v in range(n));rhs=Fraction(len(C)*len(comps),2)
 assert td and C==[0,1] and max(ecc)==11 and rad==6
 assert len(Y)==4*(k+1) and len(X)==5*(k+1) and all(len(c)==1 for c in comps)
 assert len(D)==4*k+6 and len(D)<rhs
 return {'k':k,'n':n,'m':len(edges),'names':names,'edges':edges,'TDS':sorted(D),'TDS_size':len(D),'TDS_valid':td,'D2':sorted(Y),'N_D2':sorted(X),'components':comps,'component_count':len(comps),'eccentricities':ecc,'radius':rad,'diameter':max(ecc),'centers':C,'original_RHS':str(rhs),'strict_gap_RHS_minus_certificate':str(rhs-len(D))}
if __name__=='__main__':
 results=[verify(k)for k in [2,3,4,10]]
 (OUT/'verification.json').write_text(json.dumps({'status':'PASS source-qualified half/open counterexample','principal':results[0],'family_checks':[{a:b for a,b in r.items()if a not in ['names','edges','eccentricities','components','TDS','D2','N_D2']}for r in results]},indent=2)+'\n')
 (OUT/'counterexample36.edgelist').write_text('\n'.join(f'{a} {b}'for a,b in results[0]['edges'])+'\n')
 print(json.dumps({a:b for a,b in results[0].items()if a not in ['names','edges','eccentricities','components','TDS','D2','N_D2']},indent=2))
