# Independent audit: connected high-degree core at h=11

**PASS: structural reduction only.** The proof establishes that a WOWII384b counterexample with exactly eleven degree-at-least-three vertices must have a connected induced high-degree core. It does not exclude that case, run the residual finite search, or prove the full conjecture. The residual range h=11,...,42 and representative-order bound43 are unchanged.

## 1. Exact reduction and audited dependency

The original target is equivalent to t<=2k, where t is the number of distinct vertex triangle-incidence counts and k=n-gamma_2 is maximum omission capacity. A maximum cut gives k>=ceil(h/2), and low-degree vertices have triangle counts only0 or1, so t<=h+2. At h=11 a counterexample must therefore have k=6,t=13. All eleven high-vertex counts are pairwise distinct and at least two, with both low counts also present.

The exact odd equality-case attachment theorem in `round_09/twodomination/attachment_stability.tex` was reread. Its universal proof and physical-graph checks were previously independently audited in `round_09/independent_audit/384b/AUDIT.md`. It applies to equality k=ceil(h/2), allows initially parallel low incidences, and proves that the high-neighbor incidence graph is simple and is a matching plus at most one disjoint P3. If any low-low edge occurs, the incidence graph is a matching. It does not assume that the high core is connected.

Consequently triangle attachments along core edges form a matching, possibly with one disjoint P3; there can be at most one pendant triangle, and its presence rules out the P3. Triangles with no high vertex cannot occur here, by connectedness and h>0. Nontriangle low vertices may connect different core components but do not alter their triangle counts. A triangle-attachment edge belongs to the high core, so its two endpoints cannot lie in different core components. Thus there is at most one core component with a nonmatching exception globally. This is the precise previously audited dependency, not an unreviewed AI-paper citation.

## 2. Matching increments on cores of order at most six

Let b(v) count core triangles and t(v)=b(v)+d_Q(v) for a matching of core edges. The hand proof is valid for all simple cores, connected or disconnected.

For order at most four, the range from2 through binom(n-1,2)+1 has fewer than n integers.

At order five, distinct counts at least two sum to at least20. Since their sum is3c_3+2|Q| and |Q|<=2, the core has at least six triangles. Deleting any two edges from K5 destroys at least five of its ten triangles: each removed edge is in three, and their triangle sets overlap in at most one. Therefore the core is K5 or K5-e. The count multisets 6^5 and3^2,5^3 cannot be separated by binary increments.

At order six with max b<=6, the corrected counts must be exactly2,3,4,5,6,7 and sum to27. The equation27=3c_3+2|Q| forces |Q|=0 or3. The first cannot create seven. The second is a perfect matching, so the base counts are exactly1,...,6 and the core has seven triangles. A vertex with b=6 has degree at least four; degree four would place it in K5 and force five counts at least six, impossible. It is therefore universal. Removing it leaves a five-vertex graph L with six edges and one triangle. The identity b_K(w)=d_L(w)+b_L(w) holds, and the remaining counts include five. Since L has only one triangle, that value requires d_L(w)=4 and b_L(w)=1. But a universal vertex of a six-edge, five-vertex graph lies in6-4=2 triangles. This contradiction closes the low-maximum case.

If max b>=7, the responsible vertex is universal (degree four supplies at most six triangles). Its five incident edges plus at least seven neighbor-neighbor edges give at least twelve core edges. The complement has at most three edges. All nine component types and triangle multisets were checked by hand and independently enumerated:

| Complement type | Core triangle counts | Number of labeled complements |
|---|---|---:|
| 6K1 | 10,10,10,10,10,10 | 1 |
| K2 + 4K1 | 6,6,9,9,9,9 | 15 |
| 2K2 + 2K1 | 5,5,5,5,8,8 | 45 |
| P3 + 3K1 | 3,6,6,8,8,8 | 60 |
| 3K2 | 4,4,4,4,4,4 | 15 |
| P3 + K2 + K1 | 2,4,4,5,5,7 | 180 |
| P4 + 2K1 | 3,3,5,5,7,7 | 180 |
| K1,3 + 2K1 | 1,6,6,6,7,7 | 60 |
| K3 + 3K1 | 3,3,3,7,7,7 | 20 |

These exhaust all576 labeled graphs with at most three edges. Most rows contain a triple equal value, which cannot be separated by offsets0/1. In P3+K2+K1, the four values4,4,5,5 have only the three possible corrected values4,5,6. In P4+2K1, each of three equal pairs must receive exactly one increment, demanding exactly three matching-incident vertices, impossible because that number is even. The table includes some cases not having max b>=7; this harmless overinclusion does not weaken the argument.

## 3. Small exceptional components and h=11

For any permitted attachment pattern, components of order at most three cannot supply enough distinct values at least two. At order four, four such values require a maximum of at least five. Matching increments alone give at most four. With a pendant triangle, attaining five requires its root to have three core triangles and a matching incidence; the four-vertex component is then K4, whose other three vertices can have only values3 or4. With a P3 attachment, attaining five similarly forces K4, and the two fork endpoints have the same value four. Thus every core component has at least five vertices, including a possible exceptional one.

Every nonexceptional component has matching increments only and therefore has at least seven vertices by the preceding lemma. If the high core were disconnected, its total order would be at least5+7=12 when an exception exists, or at least7+7=14 otherwise. This contradicts h=11. Nothing in this count presupposes connectedness of the full high core; only the original graph G is connected.

## 4. Independent finite verification

`check_independent.cpp` independently enumerates Q edge subsets first and classifies them by their vertex degrees, rather than copying the author's recursive matching generator. It then visits every labeled core of orders1 through6 and checks Q containment, exact core triangle counts by triple enumeration, and every permissible pendant placement.

Across33,867 labeled cores it checks718,920 matching-only patterns; none has distinct corrected counts all at least two. Across all matching/pendant/fork patterns it checks6,262,289 cases. Orders1,...,4 have no valid distinct-count profile. At order5 there are71,424 patterns with360 critical cases; at order6 there are6,189,056 patterns with27,360 critical cases. All profile masks and attachment-type flags agree exactly with the author's reported outputs. Every critical case uses the permitted exception, as required.

The same independent program enumerates all576 complements with at most three edges and recomputes every table multiset and multiplicity, matching the nine-row list exactly. These exhaustive checks validate the hand classification; the analytic proof does not rely on them.

Reproduce with a C++17 compiler on `check_independent.cpp`. The frozen proof, prior attachment theorem, author checker and profiles are snapshotted and hashed.

## 5. Limits and manuscript consistency

Both `component_connectivity.tex` and the corresponding Markdown were reviewed. The stated theorem, dependency hypotheses, nine-row proof, finite counts and partial-only conclusion agree. No mathematical repair was necessary. The timed-out MILP attempt is correctly treated as inconclusive, not as an infeasibility certificate. It is not a proof dependency and was not promoted here.
