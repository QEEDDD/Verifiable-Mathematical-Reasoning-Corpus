// Independent exhaustive implementation: enumerate all edge-subsets Q first,
// classify their components by degree, then test Q subset core.
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <map>
#include <set>
#include <vector>
using namespace std;
struct Attachment{unsigned edges;vector<int>inc;bool fork;};
int main(){cout<<"{\"status\":\"PASS\",\"orders\":[";uint64_t totalMatching=0,totalPatterns=0;
 map<vector<int>,uint64_t> complements;
 for(int n=1;n<=6;n++){
  vector<pair<int,int>>E;for(int u=0;u<n;u++)for(int v=u+1;v<n;v++)E.push_back({u,v});unsigned end=1u<<E.size();vector<Attachment>qs;
  for(unsigned q=0;q<end;q++){
   vector<int>d(n);vector<unsigned>a(n);for(int j=0;j<(int)E.size();j++)if(q>>j&1){auto[u,v]=E[j];d[u]++;d[v]++;a[u]|=1u<<v;a[v]|=1u<<u;}
   if(*max_element(d.begin(),d.end())>2)continue;int twos=count(d.begin(),d.end(),2);if(twos>1)continue;
   if(twos==1){int x=find(d.begin(),d.end(),2)-d.begin();bool good=true;for(int v=0;v<n;v++)if(a[x]>>v&1)good&=d[v]==1;if(!good)continue;}
   qs.push_back({q,d,twos==1});
  }
  uint64_t matchpatterns=0,patterns=0,critical=0,matchcritical=0;set<tuple<unsigned,int,int>>profiles;
  for(unsigned g=0;g<end;g++){
   vector<unsigned>a(n);for(int j=0;j<(int)E.size();j++)if(g>>j&1){auto[u,v]=E[j];a[u]|=1u<<v;a[v]|=1u<<u;}
   vector<int>b(n);for(int x=0;x<n;x++)for(int y=x+1;y<n;y++)for(int z=y+1;z<n;z++)if((a[x]>>y&1)&&(a[x]>>z&1)&&(a[y]>>z&1))b[x]++,b[y]++,b[z]++;
   if(n==6&&__builtin_popcount((end-1)^g)<=3){auto z=b;sort(z.begin(),z.end());complements[z]++;}
   for(auto&q:qs)if((g&q.edges)==q.edges){
    if(!q.fork)matchpatterns++;
    for(int p=-1;p<(q.fork?0:n);p++){
     patterns++;unsigned values=0;bool good=true;for(int v=0;v<n;v++){int t=b[v]+q.inc[v]+(v==p);if(t<2||(values>>t&1)){good=false;break;}values|=1u<<t;}
     if(good){critical++;profiles.insert({values,p>=0,q.fork});if(!q.fork&&p<0)matchcritical++;}
    }
   }
  }
  assert(matchcritical==0);if(n<=4)assert(critical==0);if(n==5){assert(patterns==71424&&critical==360);}if(n==6){assert(patterns==6189056&&critical==27360);}
  totalMatching+=matchpatterns;totalPatterns+=patterns;
  cout<<(n>1?",":"")<<"{\"n\":"<<n<<",\"labeled_cores\":"<<end<<",\"matching_only_patterns\":"<<matchpatterns<<",\"matching_or_fork_plus_pendant_patterns\":"<<patterns<<",\"critical_patterns\":"<<critical<<",\"matching_only_critical\":"<<matchcritical<<",\"profiles\":[";
  bool first=true;for(auto[v,p,f]:profiles){cout<<(first?"":",")<<'['<<v<<','<<p<<','<<f<<']';first=false;}cout<<"]}";
 }
 map<vector<int>,uint64_t>expected={{{10,10,10,10,10,10},1},{{6,6,9,9,9,9},15},{{5,5,5,5,8,8},45},{{3,6,6,8,8,8},60},{{4,4,4,4,4,4},15},{{2,4,4,5,5,7},180},{{3,3,5,5,7,7},180},{{1,6,6,6,7,7},60},{{3,3,3,7,7,7},20}};assert(complements==expected);
 cout<<"],\"total_matching_only_patterns\":"<<totalMatching<<",\"total_permitted_attachment_patterns\":"<<totalPatterns<<",\"complement_table\":[";bool first=true;for(auto&[v,c]:complements){cout<<(first?"":",")<<"{\"triangle_counts\":[";first=false;for(int i=0;i<6;i++)cout<<(i?",":"")<<v[i];cout<<"],\"labeled_complements\":"<<c<<'}';}cout<<"]}\n";
}
