// Complete labeled small-core enumeration for the odd critical triangle profile.
#include <array>
#include <vector>
#include <iostream>
#include <cstdint>
#include <set>
#include <tuple>
using namespace std;
bool forkq=false;set<tuple<uint64_t,int,int>>profiles;int h,P=-1;array<unsigned,8>A;array<int,8>T;vector<pair<int,int>>Q;uint64_t patterns=0,critical=0,cores=0;
void visit(){patterns++;auto t=T;if(P>=0)t[P]++;for(auto[u,v]:Q)t[u]++,t[v]++;uint64_t seen=0;for(int v=0;v<h;v++){if(t[v]<2 || (seen>>t[v]&1))return;seen|=1ull<<t[v];}critical++;profiles.insert({seen,P>=0,forkq});if(critical<=3){cerr<<"CRITICAL h "<<h<<" adjacency";for(int v=0;v<h;v++)cerr<<' '<<A[v];cerr<<" P "<<P<<" Q";for(auto[u,v]:Q)cerr<<' '<<u<<','<<v;cerr<<" counts";for(int v=0;v<h;v++)cerr<<' '<<t[v];cerr<<'\n';}}
void match(unsigned S,bool allowP){if(!S){P=-1;visit();if(allowP)for(P=0;P<h;P++)visit();P=-1;return;}int u=__builtin_ctz(S);S&=~(1u<<u);match(S,allowP);unsigned ns=A[u]&S;while(ns){int v=__builtin_ctz(ns);ns&=ns-1;Q.push_back({u,v});match(S&~(1u<<v),allowP);Q.pop_back();}}
int main(int argc,char**argv){h=argc>1?stoi(argv[1]):5;uint64_t end=1ull<<(h*(h-1)/2);unsigned F=(1u<<h)-1;for(uint64_t code=0;code<end;code++){A.fill(0);int p=0;for(int u=0;u<h;u++)for(int v=u+1;v<h;v++,p++)if(code>>p&1){A[u]|=1u<<v;A[v]|=1u<<u;}cores++;for(int v=0;v<h;v++){int z=0;for(int u=0;u<h;u++)if(A[v]>>u&1)z+=__builtin_popcount(A[v]&A[u]);T[v]=z/2;}Q.clear();forkq=false;match(F,true);forkq=true;for(int v=0;v<h;v++)for(int u=0;u<h;u++)if(A[v]>>u&1)for(int w=u+1;w<h;w++)if(A[v]>>w&1){Q={{v,u},{v,w}};match(F&~((1u<<u)|(1u<<v)|(1u<<w)),false);Q.clear();}}
cout<<"{\"h\":"<<h<<",\"all_labeled_cores\":"<<cores<<",\"attachment_patterns\":"<<patterns<<",\"critical_profiles\":"<<critical<<",\"profiles\":[";bool comma=false;for(auto[m,p,f]:profiles){if(comma)cout<<',';comma=true;cout<<'['<<m<<','<<p<<','<<f<<']';}cout<<"]}\n";}
