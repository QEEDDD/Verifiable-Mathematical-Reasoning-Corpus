# Matching increments on small cores

For a graph $K$, let $b(v)$ denote the number of triangles containing
$v$. For a matching $Q\subseteq E(K)$ put $t(v)=b(v)+d_Q(v)$. Thus each
triangle attachment on a matching edge adds one to each of its two
high-endpoint triangle counts.

::: {#lem:matching .lemma}
**Lemma 1**. *If $1\leq |K|\leq6$, the numbers $t(v)$ cannot be both
pairwise distinct and all at least two.*
:::

::: proof
*Proof.* For $|K|\leq4$, one has $t(v)\leq\binom{|K|-1}{2}+1$; the
available integers at least two are fewer than $|K|$.

Suppose $|K|=5$. Distinctness and the lower bound two imply
$\sum_v t(v)\geq20$. If $c_3(K)$ is the number of triangles, then
$$\sum_v t(v)=3c_3(K)+2|Q|\leq3c_3(K)+4,$$ so $c_3(K)\geq6$. Deleting
any two edges from $K_5$ destroys at least five of its ten triangles:
each edge lies in three triangles and two edges lie together in at most
one triangle. Hence $K$ must be $K_5$ or $K_5-e$. Their triangle-count
multisets are respectively $\{6,6,6,6,6\}$ and $\{3,3,5,5,5\}$. Binary
increments cannot give five distinct values in either case.

Now let $|K|=6$, and first assume $\max_v b(v)\leq6$. The six distinct
corrected counts must be exactly $2,3,4,5,6,7$, whose sum is 27. The
identity $27=3c_3(K)+2|Q|$ and $|Q|\leq3$ force $|Q|=0$ or 3. The first
possibility cannot produce a count seven. The second makes $Q$ a perfect
matching, so the uncorrected counts are exactly $1,2,3,4,5,6$. Let $v$
be the vertex with six triangles. Its degree is at least four. If its
degree is four, its neighborhood is a $K_4$, so it lies in a $K_5$ and
at least five vertices have triangle count at least six, a
contradiction. Thus $v$ is universal. The graph $L=K-v$ has five
vertices, six edges, and exactly one triangle, since $K$ has seven
triangles and six contain $v$. For $w\in L$, $$b_K(w)=d_L(w)+b_L(w).$$
These five values are $1,2,3,4,5$. A value five requires $d_L(w)=4$ and
$b_L(w)=1$, because $L$ has only one triangle. But a universal vertex in
this six-edge graph lies in $6-4=2$ triangles, a contradiction.

Finally suppose $\max_v b(v)\geq7$. The responsible vertex has degree
five and is universal. Hence $K$ has at least $7+5=12$ edges, and its
complement $C$ has at most three edges. All possibilities and their
uncorrected triangle counts in $K$ are listed below. Superscripts denote
multiplicities, not powers. $$\begin{array}{c|c}
 C & \{b(v):v\in V(K)\}\\\hline
 6K_1&10^6\\
 K_2\sqcup4K_1&6^2,9^4\\
 2K_2\sqcup2K_1&5^4,8^2\\
 P_3\sqcup3K_1&3,6^2,8^3\\
 3K_2&4^6\\
 P_3\sqcup K_2\sqcup K_1&2,4^2,5^2,7\\
 P_4\sqcup2K_1&3^2,5^2,7^2\\
 K_{1,3}\sqcup2K_1&1,6^3,7^2\\
 K_3\sqcup3K_1&3^3,7^3
\end{array}$$ The list is exhaustive by the component types of graphs
with zero, one, two, or three edges. In all but two rows, a value occurs
at least three times and cannot be separated by increments zero or one.
For $P_3\sqcup K_2\sqcup K_1$, the four vertices with initial values
four or five have only three possible corrected values. For
$P_4\sqcup2K_1$, each equal pair requires exactly one increment, so
precisely three vertices would be incident with $Q$, impossible for a
matching. This completes the proof. ◻
:::

# Consequence for the odd critical kernel

Recall the already established counterexample reductions from Rounds
08--09. Let $H$ be the induced subgraph on the $h$ vertices of degree at
least three. For odd $h=2k-1$, a counterexample to WOWII 384b has
maximum omittable-set size $k$ and all $h$ high-vertex triangle counts
pairwise distinct and at least two. The triangle attachments have the
following form:

-   $P$ is either absent or one pendant triangle at a high root;

-   the edge attachments $Q$ form a matching, possibly with one disjoint
    $P_3$ component;

-   if $P$ is present, $Q$ is a matching.

Here a pendant triangle contributes one to its high root's count; an
edge attachment contributes one to each endpoint of its core edge.
Nontriangle low vertices do not affect these counts. These are necessary
conditions, not assumptions that every such kernel is a counterexample.

::: {#lem:four .lemma}
**Lemma 2**. *Every component of $H$ has at least five vertices.*
:::

::: proof
*Proof.* For a component of order at most three, the largest possible
corrected count is too small to supply distinct values all at least two.
For order four, four distinct values at least two would require a value
at least five. Pure matching increments have maximum four. With a
pendant triangle, a value five requires that its root have core triangle
count three and also be incident with $Q$; hence the component is $K_4$.
Its other three vertices then have only the two possible counts three
and four. With a $Q$-$P_3$ instead, a value five likewise forces a
$K_4$, and its two fork endpoints both have corrected count four. These
contradictions cover every permitted attachment type. ◻
:::

::: {#cor:connected .corollary}
**Corollary 1**. *Any WOWII 384b counterexample with exactly eleven high
vertices has connected high-degree core $H$.*
:::

::: proof
*Proof.* There is at most one exceptional attachment component globally:
either the pendant triangle, or the $P_3$ in $Q$. Every core component
not containing that exception has only matching increments, so
Lemma [1](#lem:matching){reference-type="ref" reference="lem:matching"}
gives order at least seven. The exceptional component, if present, has
order at least five by Lemma [2](#lem:four){reference-type="ref"
reference="lem:four"}. Two or more core components would therefore have
total order at least $5+7=12$ (or at least fourteen with no exception),
contrary to $h=11$. ◻
:::

# Checks and limits

The C++ program `check_small_core_components_profiles.cpp` independently
enumerates all labeled cores of orders five and six and all permitted
$P,Q$ attachment patterns. It checks respectively 1,024 and 32,768
cores, with 71,424 and 6,189,056 attachment patterns. Every
distinct-count profile uses the pendant triangle or the fork; none uses
matching increments alone. These computations confirm the hand proof but
are not needed for it.

The separate script `discover_384b_h11_milp.py` models necessary
conditions for an eleven-high-vertex counterexample. Its first run
reached its 120-second time limit with no feasible candidate and no
infeasibility certificate. That status proves nothing about the
eleven-vertex case. The remaining high orders are still 11--42, and the
previously established representative-order bound 43 is unchanged.
