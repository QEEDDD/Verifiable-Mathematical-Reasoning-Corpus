"""Reconstruct the visibly threefold-symmetric primary Feit diagram ceDalm240.jpg.
This checks the prior witness, not the new36-tree file. Standard library only.
"""
import collections,json,pathlib
n=34; edges=[]; support=[]; arms=[]
for j in range(3):
 a,b,c,d,e,f,g,h,i,k,l=range(1+11*j,12+11*j)
 edges += [(0,a),(a,b),(a,c),(b,d),(d,e),(d,f),(f,g),(c,h),(h,i),(h,k),(k,l)]
 support += [d,f,h,k];arms.append(dict(branch_root=a,vertices=list(range(1+11*j,12+11*j))))
adj=[set()for _ in range(n)]
for x,y in edges:adj[x].add(y);adj[y].add(x)
assert len(edges)==n-1
D=set(support)|{0,arms[0]['branch_root']};assert len(D)==14
assert all(adj[v]&D for v in range(n))
forced={next(iter(adj[v]))for v in range(n)if len(adj[v])==1};assert forced==set(support)
# Every TDS contains forced support vertices. To dominate0 it must contain
# a branchroot a; none of a's neighbors is forced, so one more vertex is needed.
assert len(forced)==12
assert all(a not in forced and not (adj[a]&forced)for a in adj[0])
A={v for v in range(n)if len(adj[v])==2};assert all(not(adj[v]&A)for v in A)
N=set().union(*(adj[v]for v in A)); assert len(N)==15
left=N.copy();comps=[]
while left:
 q=[left.pop()];c=set(q)
 for v in q:
  for w in adj[v]&left:left.remove(w);c.add(w);q.append(w)
 comps.append(sorted(c))
ecc=[]
for v in range(n):
 dist={v:0};q=collections.deque([v])
 while q:
  x=q.popleft()
  for y in adj[x]:
   if y not in dist:dist[y]=dist[x]+1;q.append(y)
 assert len(dist)==n;ecc.append(max(dist.values()))
centers=[v for v in range(n)if ecc[v]==min(ecc)]
assert centers==[0]and min(ecc)==5 and max(ecc)==10 and len(comps)==15
result=dict(source_image='https://web.archive.org/web/20100718125429id_/http://cms.uhd.edu/faculty/delavinae/research/wowII/ceDalm240.jpg',reconstruction='One root with three identical eleven-vertex arms, matching the primary drawing; arm permutation immaterial.',n=n,m=len(edges),edges=edges,arms=arms,degree_two=sorted(A),degree_two_independent=True,open_equals_external_neighborhood=True,open_neighborhood_components=comps,centers=centers,radius=5,diameter=10,total_domination=14,tds=sorted(D),forced_support_vertices=sorted(forced),lower_bound_certificate='12 forced support vertices; dominating root requires one branchroot; dominating this selected branchroot requires a second nonforced vertex.',historical_354_rhs='15/2',historical_354_refuted=False,status='PASS')
p=pathlib.Path(__file__).with_name('feit34_comparison.json');p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k]for k in ['status','n','total_domination','centers','radius','diameter','historical_354_rhs','historical_354_refuted']}))
