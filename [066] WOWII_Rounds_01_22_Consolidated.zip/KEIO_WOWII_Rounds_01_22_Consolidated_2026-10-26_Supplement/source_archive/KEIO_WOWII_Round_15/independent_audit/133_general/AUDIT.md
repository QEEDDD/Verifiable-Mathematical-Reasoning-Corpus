# Independent mathematical audit: general P7-free weighted density

**Verdict: PASS.** Every finite C4-subgraph-free, P7-free graph satisfies
`L(G)=sum_v alpha(G[N(v)])=2m−3t <= 3|V(G)|`.
Together with the explicitly checked radius results, this proves original WOWII133 **only in the range of unrounded average local independence ell <= 4**. This is not a full resolution of original133, and this audit does not certify worldwide priority.

## Reviewed objects and dependency boundary

The audit reviewed `round_15/domination133/general_p7_density.md`, `c7_first_layer_reduction.md`, the supplementary checker, and the complete standalone `manuscript.tex`, including its embedded Round13/Round14 arguments and radius-four appendix. The earlier Round14 C5-containing/no-induced-C7 theorem now has a completed independent PASS audit at `round_14/independent_audit/133_c5_extension/`; it is not an unresolved dependency despite the older proposal note's status wording. The Round12 radius-four proof likewise has an earlier completed audit, and the entire copy was reread here.

The main density proof uses no unreviewed AI manuscript as a black-box premise. Its only standard general structural fact is the elementary simplicial-vertex property of chordal graphs. For completeness, the usual induction proves that every noncomplete chordal graph has two nonadjacent simplicial vertices: an inclusion-minimal separator between two nonadjacent vertices is a clique (otherwise shortest paths through two separator-full components give an induced cycle of length at least four); apply induction in two component-plus-separator induced subgraphs. In each, a simplicial vertex can be chosen outside the clique separator, since two nonadjacent simplicial vertices cannot both lie in it; in the complete case any vertex of the component works. These vertices remain simplicial in the whole graph. This also proves the single simplicial-vertex fact used here. C4-subgraph exclusion then makes its degree at most two.

For the consequence for original133, the exact primary statements were checked again in the locally pinned source texts: Erdős–Saks–Sós, Theorem2.2 (with Fan Chung proof credit), gives `p >= 2r−1`; van 't Hof–Paulusma, Theorem6, gives a dominating induced C6 or a dominating not-necessarily-induced complete bipartite subgraph in a connected P6-free graph; Camby–Schaudt arXiv1402.7213v1, Theorem5 with k=8, gives connected induced domination by a P6-free graph or C8. Their hypotheses and induced/noninduced distinctions are used correctly. Chen–Wu–Xu's contact analysis and the Cameron et al. atom classification are contextual antecedents, not required black-box premises of the new density argument.

## Universal proof audit

### 1. Weighted accounting and prior five-cycle branch

C4-subgraph exclusion implies every open neighborhood is a matching plus isolates. Therefore `alpha(N(v))=d(v)−t(v)` and summation gives `L=2m−3t`, with each triangle counted three times. This identity applies throughout, including after every induced deletion. Component additivity extends the connected result to arbitrary finite graphs.

The complete embedded dominating-C5 proof and nondominating C5/no-C7 extension agree with the previously audited arguments. In particular, the diagonal-component excess bound, the sharper deficit at least two without a diagonal C5, all residual A–B/B–B subdivision restrictions, and the Petersen alternative retain their necessary chord exclusions. No unwarranted atom-to-global or clique-cutset deficit transfer is made.

### 2. No induced C5 or C7: the C6 reduction

If no induced C6 exists either, the graph is chordal: every hole of length at least eight contains P7. A simplicial deletion preserves connectedness except for the singleton base. Reinstating a leaf costs two in L; reinstating a degree-two triangle vertex costs one. Thus `L <= 2(n−1)` is valid in this branch.

On an induced C6, the nonempty contact sets are exactly singletons A_i, adjacent pairs B_i, or opposite pairs Z_i. A three-element set contains a distance-two pair, which creates C4. Each B/Z type is unique; distinct Z vertices are independent. An A or B vertex followed by five suitably oriented consecutive cycle vertices is induced P6, so no such vertex meets R, the set having no cycle contact.

All proposed B–A and B–B edges not already excluded by C4 produce the displayed induced C5s; all B–Z edges create C4. Thus every B is a degree-two triangle vertex and its deletion is safe. A–A edges between different classes can join only opposite classes, and form a matching. An A_i–Z_i edge precludes both an A_i mate and an opposite-class mate by explicit C4s, so those A vertices are also safe degree-two triangle deletions. The remaining A contribution is `Delta L=2a+2e−q`; hence its deficit contribution `a−2e+q` is nonnegative because `2e<=a`. All deletions leave the fixed cycle and the residual attachments connected; no deleted A/B vertex could have been an R attachment.

A vertex of R cannot meet two Z vertices: adjacent contacts selected from their disjoint opposite pairs produce an induced C5. For a fixed Z vertex z, a rooted induced P4 through three R vertices would concatenate with z and three cycle vertices to form induced P7; the unused opposite cycle contact is omitted, and R has no cycle contacts. Therefore a component Q meeting z has distance at most two from z. Its neighbors X induce a matching, each other vertex has a unique parent in X, child sets induce matchings, and edges between different child sets would form the forbidden rooted P4. Connectedness forces X=K1 or K2.

With only the boundary z, Q+z is an edge/triangle block graph, so its q new vertices and tau triangles contribute q+tau edges and `Delta L=2q−tau`. With a second boundary z', its neighbor must be a child y. A second parent would give z',y,x,x' as a rooted P4; thus X={x}. At most one child meets z' by C4, and every other child must be adjacent to y to block z',y,x,w. A matching child set permits at most one such child. Hence Q is K2 or K3. All boundary vertices attach to distinct Q vertices. The three listed possibilities have deficit contributions 0,2,0. No extra triangle spans two boundaries because Z is independent and each R vertex meets at most one Z.

The base C6 with k<=3 opposite-contact vertices has deficit 6−k>=3. Summing these nonnegative contributions and reversing the safe deletions proves the C6 branch at arbitrary order.

### 3. Seven-cycle contacts and connected induction

The nonempty contact sets are exactly X_i={i,i+3} and Y_i={i,i+3,i+4}. A singleton or adjacent pair yields induced P7 with six consecutive cycle vertices, while distance-two pairs create C4. Repeated types create C4. First-layer independence follows by checking which contacts could avoid a cycle-edge C4: for X_0 only X_0 itself would remain possible, already forbidden by repetition; for Y_0 no type remains.

Every necessary pair exclusion in the manuscript was checked against its exact contact sets. The displayed seven-vertex sequences have no cycle, contact, or exterior-exterior chord. Rotation/reflection covers the remaining orientations; common-two-contact cases directly give C4. These rules yield at most three first-layer vertices. If Y_0 occurs, Y_2/Y_5 are the only possible other Y types and do not touch c3,c4; X_1/X_3 cannot coexist. Thus one of c3,c4 has degree exactly three and exactly one incident triangle. Deleting it leaves all its neighbors connected through the remaining cycle and Y_0, hence leaves the entire graph connected even if R is arbitrary. It costs exactly three in L.

With no Y, the compatible X-index sets of size two have representatives {0,1},{0,3}; each size-three set is a rotation of {0,1,4}. Thus an untouched adjacent cycle pair always exists. Both vertices have degree two, and deletion loses exactly three edges and no triangle. The remaining cycle path remains connected and no exterior vertex had a contact to the deleted pair, so the full remaining graph is connected. The cost is exactly six in L. Induction on order now closes the general theorem; hereditary exclusions are preserved.

The only requested wording refinement was to say **nonempty** exterior cycle-contact set, since R vertices have empty contact sets. This is a precision edit, not a change in the proof.

## Low-ell and radius-four consolidation checks

The new standalone low-ell argument is valid. An exterior neighbor of induced C5 has singleton/adjacent-pair contacts and produces induced P5; hence a connected P5-free graph containing C5 is exactly C5. Without C5 it is chordal, giving L<=2(n−1). The proof that a connected P4-free/C4-subgraph-free graph has a universal vertex is correct: for an induced u-w-v, a nonneighbor x of w can meet neither endpoint (else P4 or C4); a length-two x-y-w path and whichever endpoint is not adjacent to y then form induced P4. The radius-one local count is `L=2d−q<2n`.

The copied P6-free radius-three lemma correctly uses a dominating complete bipartite subgraph, not necessarily an induced one: C4-subgraph exclusion still forces it to be a star, and its center has eccentricity at most two. In the induced-C6 case only opposite contacts remain; any such exterior vertex makes a cycle vertex have eccentricity at most two. Hence radius three forces exactly C6.

The full radius-four appendix was reread, including connected-domination reduction, the C8 alternative, all six radius witnesses, all cross-class P8 constructions, the diagonal-mate case, and the converse. It preserves the previously audited classification and `L=2n−t<=2n`. Simultaneous other cross edges cannot spoil the displayed witnesses because each witness has no exterior cross-class neighbor; all remaining candidate chords are independently excluded. The proof does not rely on a single-cross-edge finite check.

The final original133 case split is exhaustive for ell<=4. For ell<=3 the lower-radius arguments and p>=2r−1 suffice. For 3<ell<=4, radius one is impossible, radii2/3 use the new theorem contrapositively to give p>=7, radius4 uses the appendix to give p>=8, and r>=5 uses p>=2r−1>=r+4. If a C4 exists, the original exponent is zero and a geodesic gives p>=r+1. No range above ell=4 is claimed.

## Independent computation, not the universal proof

`check_independent.cpp` was written separately, using direct seven-vertex-subset path recognition rather than the author's induced-path DFS, direct rooted-P4 triples, and exact neighborhood independence rather than assuming the weighted identity. It is not linked to or importing the author checker.

C7 checks exhaust all nonempty contact subsets, all pairs including possible exterior edges/repetition, and all subsets of the 14 admissible types. Counts: 14 single types,42 valid pair configurations,85 full layers; 56 contain Y and have the asserted connected single-vertex deletion,29 have no Y and have the asserted connected adjacent-pair deletion.

For residual checks it enumerates every connected C4-free labeled R graph through order6, with one,two,three independent boundary vertices. Every R vertex has zero or one boundary neighbor, all boundaries must be used, and rooted-P4 exclusions are imposed separately. This covers 310,702 one-boundary assignments,2,930,962 two-boundary assignments,10,149,084 three-boundary assignments, totaling **13,390,748**. It independently verifies the one-boundary edge/triangle block count and exact nonnegative deficit. The admissible counts are 1,614 /8 /6. All14 multiple-boundary survivors are exactly the predicted K2/K3 cases; none has R order at least four. Of the assignments,13,205,640 have R order6. Minimum incremental deficits by boundary count are1,0,0. These are finite controls, not an exhaustive proof at arbitrary order.

The author checker was compiled and rerun independently. It reproduces the stored counts, including175,294 multiple-boundary assignments through order5 and14 survivors. See `independent_results.json` and `author_rerun.json`.

Reproduction from project root:
```
g++ -std=c++17 -O3 round_15/independent_audit/133_general/check_independent.cpp -o /tmp/audit133_general
/tmp/audit133_general

g++ -std=c++17 -O3 round_15/domination133/verify_general_density_parts.cpp -o /tmp/author133_general
/tmp/author133_general
```

## Final scope

**Mathematics: PASS.** Main weighted theorem is proved analytically at arbitrary finite order. Its original133 consequence is a substantive partial range, ell<=4, not a new full numbered closure. Source priority and current public status are separate bounded source-audit questions. Root owns PDF compilation, visual QA, and release packaging.
