// Independent finite audit: subset-recognition of induced P7, direct triple
// recognition of rooted P4, exact neighborhood independence.
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <vector>
using namespace std;using U=unsigned;using G=vector<U>;
void add(G&a,int x,int y){a[x]|=1u<<y;a[y]|=1u<<x;}
bool connected(const G&a,U s=0){if(!s)s=(1u<<a.size())-1;U seen=s&-s,old=0;while(seen!=old){old=seen;for(U b=seen;b;b&=b-1)seen|=a[__builtin_ctz(b)]&s;}return seen==s;}
bool c4(const G&a){for(int x=0;x<(int)a.size();x++)for(int y=x+1;y<(int)a.size();y++)if(__builtin_popcount(a[x]&a[y])>=2)return true;return false;}
bool p7(const G&a){int n=a.size();if(n<7)return false;U stop=1u<<n;for(U s=127;s<stop;){int ones=0,twos=0;bool ok=true;for(U b=s;b;b&=b-1){int d=__builtin_popcount(a[__builtin_ctz(b)]&s);if(d<1||d>2){ok=false;break;}ones+=d==1;twos+=d==2;}if(ok&&ones==2&&twos==5&&connected(a,s))return true;U c=s&-s,r=s+c;s=(((r^s)>>2)/c)|r;}return false;}
int local(const G&a){int L=0;for(U nb:a){int best=0;for(U s=nb;;s=(s-1)&nb){bool ind=true;for(U b=s;b;b&=b-1)if(a[__builtin_ctz(b)]&s){ind=false;break;}if(ind)best=max(best,__builtin_popcount(s));if(!s)break;}L+=best;}return L;}
G cyclelayer(const vector<int>&masks){G a(7+masks.size());for(int i=0;i<7;i++)add(a,i,(i+1)%7);for(int j=0;j<(int)masks.size();j++)for(int i=0;i<7;i++)if(masks[j]>>i&1)add(a,7+j,i);return a;}
bool rootedp4(const G&a,int z,int r){for(int x=0;x<r;x++)if(a[z]>>x&1)for(int y=0;y<r;y++)if(y!=x&&(a[x]>>y&1)&&!(a[z]>>y&1))for(int w=0;w<r;w++)if(w!=x&&w!=y&&(a[y]>>w&1)&&!(a[z]>>w&1)&&!(a[x]>>w&1))return true;return false;}
int main(){vector<int>types;for(int m=1;m<128;m++){G a=cyclelayer({m});if(!c4(a)&&!p7(a))types.push_back(m);}assert(types.size()==14);
 int pairs=0,sets=0,ys=0,xs=0;for(int i=0;i<14;i++)for(int j=i;j<14;j++)for(int e=0;e<2;e++){G a=cyclelayer({types[i],types[j]});if(e)add(a,7,8);if(!c4(a)&&!p7(a)){assert(!e);pairs++;}}
 for(unsigned mask=0;mask<(1u<<14);mask++){vector<int>chosen;bool hasY=false;for(int j=0;j<14;j++)if(mask>>j&1){chosen.push_back(types[j]);hasY|=__builtin_popcount((U)types[j])==3;}G a=cyclelayer(chosen);if(c4(a)||p7(a))continue;sets++;assert(chosen.size()<=3);bool found=false;int n=a.size();U full=(1u<<n)-1;
  if(hasY){ys++;for(int v=0;v<7;v++){int t=0;for(int x=0;x<n;x++)if(a[v]>>x&1)for(int y=x+1;y<n;y++)if((a[v]>>y&1)&&(a[x]>>y&1))t++;if(__builtin_popcount(a[v])==3&&t==1){assert(connected(a,full^(1u<<v)));found=true;}}}
  else{xs++;for(int v=0;v<7;v++){int w=(v+1)%7;if(__builtin_popcount(a[v])==2&&__builtin_popcount(a[w])==2){assert(connected(a,full^(1u<<v)^(1u<<w)));found=true;}}}assert(found);
 }
 assert(pairs==42&&sets==85&&ys==56&&xs==29);
 uint64_t assignments[4]{},admissible[4]{},r6assignments=0;int minDef[4]={999,999,999,999};uint64_t byorder[7][4]{};
 for(int r=1;r<=6;r++){vector<pair<int,int>>E;for(int x=0;x<r;x++)for(int y=x+1;y<r;y++)E.push_back({x,y});for(unsigned g=0;g<(1u<<E.size());g++){G base(r);for(int j=0;j<(int)E.size();j++)if(g>>j&1)add(base,E[j].first,E[j].second);if(!connected(base)||c4(base))continue;
   for(int k=1;k<=3;k++){if(r<k)continue;unsigned limit=1;for(int j=0;j<r;j++)limit*=k+1;
    for(unsigned code=0;code<limit;code++){G a(r+k);for(int v=0;v<r;v++)a[v]=base[v];unsigned val=code,used=0;for(int v=0;v<r;v++){int z=val%(k+1);val/=k+1;if(z){add(a,v,r+z-1);used|=1u<<(z-1);}}if(used!=(1u<<k)-1)continue;assignments[k]++;if(r==6)r6assignments++;if(c4(a))continue;bool ok=true;for(int z=r;z<r+k;z++)if(rootedp4(a,z,r)){ok=false;break;}if(!ok)continue;
     admissible[k]++;byorder[r][k]++;int def=3*r-local(a);minDef[k]=min(minDef[k],def);assert(def>=0);
     int edges=0,t=0;for(int x=0;x<r+k;x++){edges+=__builtin_popcount(a[x]);for(int y=x+1;y<r+k;y++)for(int z=y+1;z<r+k;z++)if((a[x]>>y&1)&&(a[x]>>z&1)&&(a[y]>>z&1))t++;}edges/=2;
     if(k==1)assert(edges==r+t);else{assert(r==2||r==3);for(int x=0;x<r;x++)for(int y=x+1;y<r;y++)assert(a[x]>>y&1);}
    }
   }
  }
 }
 assert(admissible[2]+admissible[3]==14);
 cout<<"{\"status\":\"PASS\",\"C7_single_types\":14,\"C7_valid_pairs\":"<<pairs<<",\"C7_first_layers\":"<<sets<<",\"C7_Y_case_safe_vertex_deletions\":"<<ys<<",\"C7_noY_safe_pair_deletions\":"<<xs<<",\"R_component_max_order_tested\":6,\"R_assignments_by_boundary_count_1_2_3\":[";for(int k=1;k<=3;k++)cout<<(k>1?",":"")<<assignments[k];cout<<"],\"R_admissible_by_boundary_count_1_2_3\":[";for(int k=1;k<=3;k++)cout<<(k>1?",":"")<<admissible[k];cout<<"],\"R_min_deficits_by_boundary_count_1_2_3\":[";for(int k=1;k<=3;k++)cout<<(k>1?",":"")<<minDef[k];cout<<"],\"R_order6_assignments\":"<<r6assignments<<",\"R_admissible_by_order_and_boundary\":[";for(int rr=1;rr<=6;rr++){cout<<(rr>1?",":"")<<'[';for(int k=1;k<=3;k++)cout<<(k>1?",":"")<<byorder[rr][k];cout<<']';}cout<<"]}\n";
}
