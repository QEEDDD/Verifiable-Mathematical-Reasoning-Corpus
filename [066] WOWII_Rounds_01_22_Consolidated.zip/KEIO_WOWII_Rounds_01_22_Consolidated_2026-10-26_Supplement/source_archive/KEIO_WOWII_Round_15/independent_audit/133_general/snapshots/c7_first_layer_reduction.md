# A first-layer reduction around an induced seven-cycle

**Research lemma, 26 October 2026; not yet independently audited.** This is a partial structural result, not a full WOWII closure. The standard X/Y contact partition and most forbidden pairs occur in Chen–Wu–Xu, arXiv:2302.11115v1, proof of Theorem1.1, claims(1)–(6). Under the stronger exclusion of C4 as a subgraph, the following elementary presentation also excludes consecutive Y types.

Let G be C4-subgraph-free and P7-free, and let C=c_0...c_6c_0 be induced. Write A=N(C)\C. Then **|A|≤3**, A is independent, and every vertex of A has contacts of one of the forms

    X_i={c_i,c_(i+3)},  Y_i={c_i,c_(i+3),c_(i+4)}.

There is at most one vertex of each type. Subscripts are modulo seven.

## Contact types and independence

No contact pair can have circular distance two, because that creates a C4. A singleton or adjacent pair gives P7 by appending six consecutive cycle vertices and omitting the unused adjacent contact. Sets of at least four contacts contain a distance-two pair. A three-contact set with no distance-two pair has the displayed Y form. Thus the list is complete, and repeating a type gives two common cycle neighbors and hence C4.

Suppose exterior contact vertices x,y are adjacent, with contact sets S,T. No cycle edge can run from a vertex of S to a distinct vertex of T, or that edge and xy complete a C4. If S=X_0={c_0,c_3}, this forces T⊆{c_0,c_3,c_5}; the only admissible contact type inside this set is X_0 itself, already excluded by repetition. If S=Y_0, the forbidden cycle-neighbor union leaves only c_0, too few contacts. Therefore A is independent.

## Pair exclusions

The following necessary pair restrictions hold:

- X_i and X_(i±2) cannot both occur.
- X_i and Y_j can coexist only for j−i∈{4,5,6}.
- Y_i and Y_j can coexist only for j−i∈{2,5}.

The repeated-type and common-two-contact cases are C4 obstructions. The remaining exclusions follow from the following induced-P7 lists, with x,y denoting the two listed exterior types:

- X_0,X_2: c_1,c_0,x,c_3,c_4,c_5,y.
- X_0,Y_1: c_2,c_3,x,c_0,c_6,c_5,y.
- X_0,Y_2: c_1,c_0,x,c_3,c_4,c_5,y.
- Y_0,Y_1: c_2,c_3,x,c_0,c_6,c_5,y.

Rotations and reversals give the other cases. Independence of A and the displayed exact contact sets verify all chords.

## Counting

If no Y occurs, the X indices form an independent set in the seven-cycle whose steps are ±2, so there are at most three.

If Y_0 occurs, every X index lies in {1,2,3}; X_1 and X_3 cannot coexist. If there is only one Y, there are therefore at most two X vertices. Distinct Y indices differ by ±2; there are at most two Y vertices because the step-two seven-cycle is triangle-free. If Y_0 and Y_2 occur, their permitted X sets intersect only at X_3. Again |A|≤3.

## A consequence and its limitation

If the induced C7 dominates G, put x=|X| and y=|Y|. Then

    n=7+x+y,  m=7+2x+3y,  t=y,
    3n−L=3n−(2m−3t)=7−x≥4.

Thus every graph in this dominating-C7 branch has ell<3.

For a nondominating C7, the distance-two and farther layers are not eliminated by this argument. In particular, a Y vertex need not have a rooted induced P5 using cycle vertices, so the triangle-free proof's assertion that every attached component is K1 or K2 cannot simply be reused. Only the X types have that stronger rooted-path extension. This is the precise remaining dependency gap in a full C7-containing density argument.
