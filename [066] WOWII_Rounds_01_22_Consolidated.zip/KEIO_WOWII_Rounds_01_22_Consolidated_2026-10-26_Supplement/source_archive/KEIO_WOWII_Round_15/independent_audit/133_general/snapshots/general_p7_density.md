# A proposed general P7-free local-independence bound

**KEIO — 26 October 2026.**

**Status:** complete analytic partial theorem; independent mathematical review passed on 26 October 2026. This is NOT a full resolution of original WOWII133. The proof uses the independently reviewed Round14 C5-containing/C7-free density theorem and Round13 weighted-component theorem. Worldwide priority remains uncertified.

## Main theorem

Every connected C4-subgraph-free P7-free graph G satisfies

    L(G):=sum_v alpha(G[N(v)])=2m−3t ≤3n.

Triangles are allowed. Here t is the number of triangles and the average ell=L/n is unrounded. Combined with the approved earlier radius-four classification and low-average/radius bounds, this establishes original WOWII133 for every connected graph with ell≤4. Values ell>4 are not covered by this theorem alone.

## 1. The C5-free, C7-free branch

Assume G has no induced C5 or C7. If G has no induced C6 either, then it is chordal: every longer induced cycle contains P7, and C4 is excluded as a subgraph. A chordal C4-subgraph-free graph has a simplicial vertex of degree at most two. Removing it preserves connectedness; reinstatement costs either two units of L for a leaf or one for a degree-two triangle vertex. Induction gives L≤2(n−1), so the desired bound follows.

We may therefore fix an induced C6=c_0...c_5c_0. All indices in this section are modulo six. Exterior vertices with a cycle contact have one contact, an adjacent pair, or an opposite pair. Let A_i denote the single-contact class {c_i}, B_i the adjacent-pair class {c_i,c_(i+1)}, and Z_i the opposite-pair class {c_i,c_(i+3)}, where Z_i=Z_(i+3). Each B or Z class has size at most one; write its vertex by the same letter when present. There are at most three Z vertices, and they are independent by C4 exclusion.

Let R consist of vertices with no cycle contact. A first-layer A or B vertex starts an induced P6 using five consecutive cycle vertices. A neighbor in R would give P7. Thus only Z vertices can have neighbors in R.

### Removing the adjacent-pair and A–Z triangles

Every B vertex has degree two. The C4 restrictions leave only possible B–A edges to the two far A classes and B–B edges to the opposite B class. Each gives an induced C5: for example B_0–A_3 gives B_0,x,c_3,c_2,c_1,B_0, and B_0–B_3 gives B_0,c_1,c_2,c_3,B_3,B_0. All B–Z edges create C4, while B–R edges were just excluded. Therefore B is a simplicial degree-two triangle vertex, whose deletion costs ΔL=1. Remove all B vertices safely.

A diagonal edge A_i–A_(i±2) creates an induced C5 and is forbidden. Thus edges among different A classes run only between opposite classes, and they form a matching. Within each A_i there is a matching as usual.

An A_i vertex can meet only the opposite-contact vertex Z_i among the Z vertices: an edge to another Z type creates C4. If x∈A_i is adjacent to Z_i, then x has no within-class mate y, or x,y,c_i,Z_i,x would be a C4. It also has no opposite-class neighbor y∈A_(i+3), or x,y,c_(i+3),Z_i,x would be a C4. It has no R neighbor. Hence d(x)=2 and it lies in one triangle. Remove every such x safely.

Now all remaining A vertices meet only their cycle contacts and other A vertices. If a is their number, q the number of internal A_i matching edges, and e the number of opposite A–A edges, reinstating A costs

    ΔL=2a+2e−q,

so it adds deficit a−2e+q≥0, because the opposite edges form a matching. Remove all A and account for them by this nonnegative deficit.

### Components attached to the opposite-contact vertices

We are left with the cycle, at most three Z vertices, and R. Every component Q of G[R] touches at least one Z vertex.

No R vertex meets two Z vertices. Two distinct opposite pairs on C6 contain adjacent cycle contacts, so a common R neighbor would give an induced C5 of the form Z_i,c_j,c_(j+1),Z_k,x,Z_i.

For each Z vertex z, there is no induced four-vertex path in G[R∪{z}] having endpoint z: append the three cycle vertices of an induced rooted P4 starting at z, and obtain P7. Fix a component Q touching z. Every vertex of Q is therefore within distance two of z. Let X=N(z)∩Q, and Y=Q\X. The graph on X is a matching plus isolated vertices. Every y∈Y has a unique neighbor in X, since two would give a C4 through z. Call it its parent. No edge joins vertices of Y with different parents, since z,x,y,y′ would then be an induced P4. The vertices with any fixed parent induce a matching plus isolated vertices. Connectedness now shows that X is K1 or K2 and Q consists of these one or two adjacent parent vertices with private sets of children, each child set inducing a matching.

If Q touches only z, then Q∪{z} is a connected block graph whose blocks are edges or triangles. If r=|Q| and τ is its number of triangles including those through z, the attachment has r+τ edges. Thus it adds L=2r−τ≤2r, and adds nonnegative deficit.

Suppose Q touches another opposite-contact vertex z′. Since no R vertex meets two Z vertices, z′ attaches to a child y of a parent x∈X. If X contained a second vertex x′, then z′,y,x,x′ would be an induced P4, impossible. Hence X={x}. At most one child is adjacent to z′, by the C4 z′,y,x,y′,z′. For every other child w, the path z′,y,x,w would be induced unless yw is an edge. Since the child set induces a matching, there is at most one such w. Consequently Q is K2 or K3.

For K2, its two vertices meet two distinct Z vertices. For K3, two or three of its vertices meet distinct Z vertices. The corresponding contributions to the deficit are respectively

    K2 with two Z attachments: 3·2−2(1+2)=0;
    K3 with two Z attachments: 3·3−[2(3+2)−3]=2;
    K3 with three Z attachments: 3·3−[2(3+3)−3]=0.

Thus every R component adds nonnegative deficit. The base C6 plus k opposite-contact vertices has

    n=6+k, m=6+2k, t=0,
    3n−L=6−k≥3.

Reinstating all removed vertices proves L≤3n in the C5-free, C7-free branch.

## 2. The C5-containing, C7-free branch

This is exactly the separately frozen Round14 theorem in `c5_containing_c7free_density.md`: the beyond-cycle components reduce safely to A–B and B–B subdivisions; the audited Round13 diagonal-component bound supplies deficit at least two outside the Petersen alternative, and explicit P7 restrictions bound the remaining cost by two. In the Petersen alternative every residual subdivision is excluded by an induced P7.

Assuming that theorem, all C7-free graphs are now covered.

## 3. Induction for graphs containing an induced C7

We use the following elementary first-layer facts around an induced C7=c_0...c_6c_0, with indices modulo seven. Every nonempty exterior cycle-contact set has the form

    X_i={c_i,c_(i+3)}, or Y_i={c_i,c_(i+3),c_(i+4)}.

Each type occurs at most once, and all first-layer vertices are independent. Necessary compatibility conditions are:

    X_i and X_(i±2) cannot coexist;
    X_i and Y_j coexist only if j−i∈{4,5,6};
    Y_i and Y_j coexist only if j−i∈{2,5}.

These facts are proved explicitly in the separate `c7_first_layer_reduction.md` note. The standard X/Y partition and several pair exclusions also occur in Chen–Wu–Xu, arXiv:2302.11115v1, proof of Theorem1.1, claims(1)–(6). The stronger C4-subgraph exclusion is used throughout here.

We prove L≤3n by induction on n, using Sections1–2 when G is C7-free.

If a Y type occurs, rotate so that Y_0 is present. The only possible other Y types are Y_2,Y_5, and the only X types are X_1,X_2,X_3. The cycle vertex c_3 has degree three unless X_3 occurs; c_4 has degree three unless X_1 occurs. Since X_1 and X_3 cannot coexist, at least one of c_3,c_4 has degree exactly three and belongs to exactly one triangle. Delete that vertex v. Its three neighbors remain connected through the rest of the cycle and Y_0, so G−v is connected. The deletion decreases L by 2d(v)−3t(v)=3. The induction hypothesis gives L(G)≤3(n−1)+3=3n.

If no Y occurs, there are at most three X types. There are two adjacent cycle vertices with no exterior neighbor. This can be checked directly from the X compatibility rule: with zero or one X it is immediate; with two X types, up to rotation and reflection the index pairs are {0,1} or {0,3}, leaving respectively c_5,c_6 or c_1,c_2 untouched; with three X types, every permitted set is a rotation of {0,1,4}, again leaving c_5,c_6 untouched. Delete this adjacent degree-two pair. Exactly three edges and no triangles are lost, so ΔL=6. The remaining cycle path is connected and no exterior vertex touched the deleted pair, hence the remaining graph is connected. Induction gives L(G)≤3(n−2)+6=3n.

This completes the proof of the general P7-free weighted-density theorem. ∎

## Dependencies and exact original-conjecture coverage

Independent review of this note, the Round14 theorem, the explicit C7 contact argument, and the standalone consolidation passed. No unrestricted WOWII133 claim is made. Its combination with the earlier general radius-four P8-free classification, the classical induced-path bound p≥2r−1, and the approved ell≤3 cases gives original133 for all ell≤4: for 3<ell≤4 and r=2 or3 the theorem forces p≥7; for r=4 the earlier classification forces p≥8; and r≥5 follows from p≥2r−1. Radius one is impossible in this range under strong C4 exclusion, because its neighborhoods are matchings and ell<2.
