#include <bits/stdc++.h>
using namespace std;using U=uint64_t;mt19937 rng(133202610);
struct G{
 int n;vector<U>N;G(int n):n(n),N(n){};
 void edge(int u,int v){N[u]|=1ull<<v;N[v]|=1ull<<u;}
 void del(int u,int v){N[u]&=~(1ull<<v);N[v]&=~(1ull<<u);}
 bool allowed(int u,int v,bool trianglefree){if(u==v||(N[u]>>v&1))return false;if(trianglefree&&(N[u]&N[v]))return false;U a=N[u];while(a){int x=__builtin_ctzll(a);a&=a-1;if(N[x]&N[v])return false;}return true;}
 bool connected(){U seen=1,front=1;while(front){U next=0;while(front){int u=__builtin_ctzll(front);front&=front-1;next|=N[u];}front=next&~seen;seen|=front;}return __builtin_popcountll(seen)==n;}
 int radius(){int rad=n;for(int s=0;s<n;s++){U seen=1ull<<s,front=seen;int d=0;while(__builtin_popcountll(seen)<n){U next=0;while(front){int u=__builtin_ctzll(front);front&=front-1;next|=N[u];}front=next&~seen;seen|=front;d++;if(!front)return n;}rad=min(rad,d);}return rad;}
 int local_sum(){int degrees=0,tri6=0;for(int u=0;u<n;u++){degrees+=__builtin_popcountll(N[u]);U z=N[u];while(z){int v=__builtin_ctzll(z);z&=z-1;tri6+=__builtin_popcountll(N[u]&N[v]);}}return degrees-tri6/2;}
 long long nodes=0;bool haspath(int target){function<bool(int,int,U,U)>dfs=[&](int v,int len,U used,U forbid){nodes++;if(len>=target)return true;U cand=N[v]&~(used|forbid);while(cand){int u=__builtin_ctzll(cand);cand&=cand-1;if(dfs(u,len+1,used|(1ull<<u),forbid|N[v]))return true;}return false;};for(int s=0;s<n;s++)if(dfs(s,1,1ull<<s,0))return true;return false;}
 void print(){for(int u=0;u<n;u++)for(int v=0;v<u;v++)if(N[u]>>v&1)cout<<u<<","<<v<<";";cout<<endl;}
};


bool c4(G&g){for(int u=0;u<g.n;u++)for(int v=0;v<u;v++)if(__builtin_popcountll(g.N[u]&g.N[v])>1)return true;return false;}
bool rootedp4(G&g,int z,int r){function<bool(int,int,U)>dfs=[&](int v,int len,U used){if(len==4)return true;U can=g.N[v]&((1ull<<r)-1)&~used;while(can){int u=__builtin_ctzll(can);can&=can-1;if((g.N[u]&used)!=(1ull<<v))continue;if(dfs(u,len+1,used|(1ull<<u)))return true;}return false;};return dfs(z,1,1ull<<z);}
int main(){long long c7types=0,c7pairs=0,c7sets=0,lowcost=0;vector<vector<int>>T;
for(int m=1;m<128;m++){G g(8);for(int i=0;i<7;i++)g.edge(i,(i+1)%7);vector<int>v;for(int i=0;i<7;i++)if(m>>i&1){g.edge(7,i);v.push_back(i);}if(!c4(g)&&!g.haspath(7)){T.push_back(v);c7types++;}}
for(int i=0;i<(int)T.size();i++)for(int j=i;j<(int)T.size();j++)for(int edge=0;edge<2;edge++){G g(9);for(int k=0;k<7;k++)g.edge(k,(k+1)%7);for(int v:T[i])g.edge(7,v);for(int v:T[j])g.edge(8,v);if(edge)g.edge(7,8);if(!c4(g)&&!g.haspath(7)){assert(edge==0);c7pairs++;}}
for(int mask=0;mask<(1<<(int)T.size());mask++){G g(7+__builtin_popcount((unsigned)mask));for(int i=0;i<7;i++)g.edge(i,(i+1)%7);int z=7;for(int i=0;i<(int)T.size();i++)if(mask>>i&1){for(int v:T[i])g.edge(z,v);z++;}if(c4(g)||g.haspath(7))continue;c7sets++;assert(g.n<=10);bool found=false;for(int v=0;v<7;v++){int d=__builtin_popcountll(g.N[v]),tt=0;for(int w=0;w<g.n;w++)if(g.N[v]>>w&1)tt+=__builtin_popcountll(g.N[v]&g.N[w]);tt/=2;if(d==3&&tt==1)found=true;if(d==2&&__builtin_popcountll(g.N[(v+1)%7])==2)found=true;}assert(found);lowcost++;}
long long assignments=0,admissible=0;for(int r=1;r<=5;r++){vector<pair<int,int>>es;for(int u=0;u<r;u++)for(int v=0;v<u;v++)es.push_back({u,v});for(int mask=0;mask<(1<<(int)es.size());mask++){G base(r);for(int j=0;j<(int)es.size();j++)if(mask>>j&1)base.edge(es[j].first,es[j].second);if(!base.connected()||c4(base))continue;for(int k=2;k<=3;k++){int total=1;for(int i=0;i<r;i++)total*=k+1;for(int code=0;code<total;code++){G g(r+k);for(int i=0;i<r;i++)g.N[i]=base.N[i];int x=code,used=0;for(int v=0;v<r;v++){int z=x%(k+1);x/=k+1;if(z){g.edge(v,r+z-1);used|=1<<(z-1);}}if(used!=(1<<k)-1)continue;assignments++;if(c4(g))continue;bool good=true;for(int z=r;z<r+k;z++)if(rootedp4(g,z,r)){good=false;break;}if(!good)continue;admissible++;assert(r==2||r==3);for(int u=0;u<r;u++)for(int v=0;v<u;v++)assert(g.N[u]>>v&1);int D=3*r-g.local_sum(); // boundary local_sum includes all edges/triangles, as needed
assert(D>=0);}}}}
cout<<"{\"status\":\"PASS\",\"C7_admissible_single_contact_sets\":"<<c7types<<",\"C7_admissible_two_vertex_configurations\":"<<c7pairs<<",\"C7_admissible_full_first_layers\":"<<c7sets<<",\"C7_low_cost_deletions_verified\":"<<lowcost<<",\"R_boundary_assignments_tested\":"<<assignments<<",\"admissible_multi_Z_components\":"<<admissible<<",\"R_scope\":\"all connected C4-free labeled R graphs through order5, with2or3 independent boundary vertices, each R vertex adjacent to at most one boundary vertex; rooted P4 exclusions imposed separately for each boundary\"}"<<endl;}
