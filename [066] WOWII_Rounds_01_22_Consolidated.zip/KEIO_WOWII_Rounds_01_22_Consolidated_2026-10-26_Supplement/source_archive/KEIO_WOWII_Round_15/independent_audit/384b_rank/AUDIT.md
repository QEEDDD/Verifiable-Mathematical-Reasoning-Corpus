# Independent audit: triangle rank and the h=42 case of WOWII384b

**Verdict: PASS — partial theorem, not full conjecture closure.**

The new theorem proves the original inequality for every connected graph with exactly42 vertices of degree at least three and no degree-two vertex. Combining this with the previously independently audited degree-two case excludes all h=42, and hence all h>=42. The remaining possible high-vertex orders are11 through41. The representative-order bound remains43; no exhaustive check of all graphs through order43 is asserted.

## 1. Original target and critical profile

The original target is `gamma_2(G) <= floor(n−|T(G)|/2)`, where T is the set of distinct vertex triangle-incidence counts. With k=n−gamma_2 this is exactly `|T|<=2k`, including odd |T|. A 2-dominating set imposes its condition only on vertices outside the set; this convention is used correctly in both the cut argument and alteration.

In a locally maximal cut every degree-at-least-three vertex has at least two crossing neighbors. The high vertices on either side are therefore omittable while every other vertex remains selected. For h=42 this gives k>=21. Connectedness and the absence of degree-two vertices imply that all nonhigh vertices are leaves (there are no isolated vertices). Hence |T|<=43. Failure forces k=21 and |T|=43. There must be a leaf: without one,42 vertices have at most42 triangle values. Therefore all42 high triangle counts are positive and pairwise distinct; deleting the leaves preserves these counts exactly.

No assumption that the high core is connected is needed anywhere in the new argument. Positive core triangle count implies core degree at least two. A core-degree-two vertex must have triangle count one, so there is at most one and it is the first vertex in triangle-rank order. Its actual graph degree is at least three, so it has at least one leaf neighbor. Every other high vertex has core degree at least three.

## 2. Triangle-rank lemma

Let u=tau_H(v_i)>=i, d=d_H(v_i), and r=binom(d,2)−u. The neighborhood has exactly r missing edges. At most2r neighborhood vertices are incident to a missing edge, so at least d−2r neighbors are adjacent to all other neighbors. The bound is still valid if d−2r is negative.

For such a neighbor w, the triangles through w inside the closed neighborhood of v_i number exactly u: d−1 use v_i, while the remaining `u−(d−1)` are edges of the original neighborhood not incident to w. Thus tau_H(w)>=u. Distinctness of all core triangle counts implies tau_H(w)>u, so each such w has rank greater than i. Consequently

`h−i >= d−2r = 2u−d(d−2)`,

and `d(d−2)>=2u+i−h>=3i−h`. The other bound `binom(d,2)>=i` follows immediately from u>=i. This is a universal counting argument, not an extrapolation from the finite diagnostic.

## 3. Exact sampling and leaf credit

For a uniform16-subset S of the42 high vertices, the unconditional counts of outcomes with v omitted and zero/at-most-one selected high neighbor are exactly F1(d) and F0(d) in the manuscript. The denominator is `binom(42,16)`, not `binom(41,16)`; the numerator automatically excludes the focal vertex. Coupling nested prescribed neighborhoods proves that both probabilities are nonincreasing in core degree.

Initially select all leaves and S. Add every initially unselected high vertex with fewer than two initially selected neighbors. Every vertex remaining outside the set already had two initial selected neighbors, so the simultaneous additions cannot harm it. The expected number of selected high vertices is16 plus the sum of the repair probabilities; no independence of repairs is assumed.

A vertex incident to a leaf needs repair only when it has no selected high neighbor, giving F1 rather than F0. If it has two or more leaves, its true repair probability is zero and F1 is still a safe upper bound. The proof therefore needs just one leaf-neighbor vertex, not any special arrangement or independence of leaves.

When all core degrees are at least three, the rank lower profile is
`3^3,4^3,5^4,6^5,7^6,8^7,9^7,10^5,11^2`.
Only ranks36,41,42 improve over the elementary triangle-degree profile, each by one. A chosen leaf-neighbor vertex v_j gives
`E Z <= B−F0(a_j)+F1(a_j) <= B−c`.
The minimum credit is at ranks41,42. The baseline for a possible degree-two core vertex incorrectly treats it as degree three only temporarily, and the proof explicitly replaces its entire term F0(3) by the correct leaf-assisted F1(2). Thus no unjustified core minimum-degree-three assumption is made.

Fresh independent exact arithmetic gives:

| Quantity | Exact value |
|---|---:|
| B |705171683/33577278|
| c |10120/987567|
| F0(3)−F1(2) |160/861|
| B−c |704827603/33577278|
| 21−(B−c) |295235/33577278|
| Exceptional degree-two-core upper bound |99847429/4796754|
| Its strict margin below21 |884405/4796754|

Both expected high-set sizes are strictly below21. An integer-valued outcome therefore selects at most20 high vertices; all leaves remain selected, so at least22 vertices are omitted. This contradicts k=21 and proves the new theorem.

## 4. Prior inputs needed for the advertised residual range

These are completed earlier independently audited results, not newly claimed closures:

* Round10 excludes h=42 when a degree-two vertex exists. In an even critical graph every maximum cut has21 high vertices on each side. Every degree-two vertex has exactly one crossing neighbor; two would allow it to be added to its high-side omission set. Flipping it preserves maximum cut size. An adjacent leaf would then have zero crossing neighbors, and an adjacent degree-two vertex would have zero or two, each impossible. Hence its two neighbors are high. Selecting all low vertices initially improves both high endpoints' repair terms; the degree-two vertex itself can subsequently be omitted whenever both endpoints were initially selected. That omission harms no omitted high vertex, because both its high neighbors remain selected. Fresh arithmetic reproduces the strict margin75065/541569.
* Round10 excludes h=43. The odd critical profile requires a low triangle-count-one vertex. It either has two high triangle partners or is in a pendant triangle; a triangle with all vertices low would be an entire K3 component. The same two-endpoint credit or the pendant credit applies. Fresh arithmetic reproduces1057200/7762489 and2799123/7762489 respectively.
* Round08 excludes h44 through51 by exact fixed-size sampling, and all h>=52 by a Bernoulli alteration and a positive two-step increment, not by testing finitely many h values. The completed report `round_08/independent_audit/384b/AUDIT.md`, sections5–6, was reread. Its forced-selected-low-neighbor comparison and the capped high-degree case are explicitly valid; the all-h induction has positive base values and uniform positive parity increment.
* The completed Round08/09/11 finite-kernel audit chain excludes h<=10. In particular the Round11 h10 result uses the proved even-cubic lemma, explicitly verified permutation coverage, all35,706,840 cubic-labeled extensions, and independently checked six-high omission witnesses for every3,971,627 necessary-filter survivor. The prior audit did not trust the canonicalizer or an unreached attachment fallback.
* The existing order43 representative reduction is a separately audited leaf-trimming plus low-omission result. It does not depend on a counterexample actually having h42, so removing h42 leaves the bound43 valid. This new note does not strengthen that order bound or eliminate the remaining h11…41 cases.

## 5. Independent computational controls

`check_independent.py` does not import the author script. It derives the rank profile afresh and evaluates the probabilities by conditioning on the focal vertex being omitted, rather than using the author's unconditional numerator. It also independently recomputes the needed Round10 margins by minimizing over all distinct endpoint pairs.

The checker enumerates the elementary sampling experiment through h12:1,485 exact probability controls pass, including zero,one,two forced selected leaves and monotonicity. It also enumerates all33,867 labeled graphs of orders1…6 and directly counts triangles. Across202,013 neighborhoods, the missing-edge endpoint bound passes; across160,076 fully adjacent-neighbor incidences, the closed-neighborhood triangle count is exactly u and no larger than the neighbor's full triangle count. These controls test the key local lemma independently, but are not a proof by graph exhaustion at h42.

The author script was separately rerun from a pinned snapshot, reproducing the published fractions. The analytic proof and exact finite rational sums establish the theorem; no optimization oracle, floating-point threshold, or large unperformed search is required.

## Consolidation and limits

The root delivery was diffed against the author TeX. Its only changes are T1/lmodern/xurl, author KEIO, and hidden hyperlink decoration; no mathematical text changes. Final hashes are in `source_hashes.json` and `CONSOLIDATED_TEX_AUDIT.md`.

**PASS for the new h42 theorem and the stated combined residual range11…41. Not a full resolution of WOWII384b.** No priority claim is certified by this mathematical audit. Root owns PDF compilation, visual QA and packaging.
