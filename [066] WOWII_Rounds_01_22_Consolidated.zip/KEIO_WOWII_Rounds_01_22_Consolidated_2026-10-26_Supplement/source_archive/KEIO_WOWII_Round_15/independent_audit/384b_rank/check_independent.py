"""Independent rank-profile and conditional hypergeometric calculation.
No author module is imported. Small controls enumerate sampling subsets and
all labeled graphs through order6, evaluating triangle counts directly.
"""
from fractions import Fraction as Q
from math import comb
from itertools import combinations
import json

def C(n,k):return comb(n,k) if n>=0 and 0<=k<=n else 0

def prob(h,s,d,leaves):
    # First condition on omission of the focal high vertex.
    if leaves>=2:return Q(0)
    return Q(h-s,h)*sum((Q(C(d,j)*C(h-1-d,s-j),C(h-1,s)) for j in range(2-leaves)),Q(0))

h,s=42,16
profile=[]; old=[]
for i in range(1,h+1):
    ds=[d for d in range(3,h) if C(d,2)>=i]
    old.append(min(ds))
    profile.append(min(d for d in ds if d*d-2*d>=3*i-h))
B=Q(s)+sum((prob(h,s,d,0) for d in profile),Q(0))
credits=[prob(h,s,d,0)-prob(h,s,d,1) for d in profile]
c=min(credits);ex=prob(h,s,3,0)-prob(h,s,2,1)
assert B==Q(705171683,33577278)
assert c==Q(10120,987567)
assert ex==Q(160,861)>c
assert 21-(B-c)==Q(295235,33577278)>0
assert B-ex==Q(99847429,4796754)<21
# Recompute the already-audited R10 inputs without trusting cached fractions.
def rho(j):return next(d for d in range(3,50) if C(d,2)>=j)
def force_low_prob(h,s,d,force):
    if force>=2:return Q(0)
    return prob(h,s,min(h-1,d-force),force)
previous=[]
for hh in (42,43):
    ss=16
    pp=([3]+[rho(j) for j in range(2,hh+1)]) if hh%2==0 else [rho(j) for j in range(2,hh+2)]
    ordinary=[force_low_prob(hh,ss,d,0) for d in pp]
    cc=[ordinary[i]-force_low_prob(hh,ss,d,1) for i,d in enumerate(pp)]
    base=ss+sum(ordinary)
    # Minimum over distinct high endpoints, rather than sorting credits.
    pair=min(cc[i]+cc[j] for i in range(hh) for j in range(i))
    margin=hh//2-(base-pair-Q(ss*(ss-1),hh*(hh-1)))
    expected={42:Q(75065,541569),43:Q(1057200,7762489)}[hh]
    assert margin==expected>0
    row={'h':hh,'degree_two_margin':str(margin)}
    if hh==43:
        pendant=hh//2-(base-min(ordinary)-Q(ss,hh))
        assert pendant==Q(2799123,7762489)>0
        row['pendant_margin']=str(pendant)
    previous.append(row)
# Exact enumeration of the elementary sampling experiment.
probability_controls=0
for hh in range(3,13):
 for ss in range(2,hh):
  outcomes=list(combinations(range(hh),ss));den=len(outcomes)
  for d in range(hh):
   neighbors=set(range(1,d+1));counts=[0,0,0]
   for X in outcomes:
    X=set(X)
    for leaf in range(3):
     counts[leaf]+=0 not in X and len(X&neighbors)+leaf<2
   for leaf in range(3):
    assert Q(counts[leaf],den)==prob(hh,ss,d,leaf)
    probability_controls+=1
   if d<hh-1:
    assert prob(hh,ss,d+1,0)<=prob(hh,ss,d,0)
    assert prob(hh,ss,d+1,1)<=prob(hh,ss,d,1)
# Independent neighborhood-triangle fact on all labeled graphs through n6.
graphs=0;local_relations=0;universal_neighbor_relations=0
for n in range(1,7):
 es=list(combinations(range(n),2))
 for mask in range(1<<len(es)):
  A=[set() for _ in range(n)]
  for j,(x,y) in enumerate(es):
   if mask>>j&1:A[x].add(y);A[y].add(x)
  tau=[sum(y in A[x] for x,y in combinations(A[v],2)) for v in range(n)]
  graphs+=1
  for v in range(n):
   d=len(A[v]);u=tau[v];r=C(d,2)-u
   full=[w for w in A[v] if A[v]-{w}<=A[w]]
   assert len(full)>=d-2*r
   local_relations+=1
   for w in full:
    inside=sum(y in A[x] for x,y in combinations(A[w]&(A[v]|{v}),2))
    assert inside==u<=tau[w]
    universal_neighbor_relations+=1
print(json.dumps({'status':'PASS','profile':profile,'increased_ranks':[i+1 for i,(a,b) in enumerate(zip(old,profile)) if a!=b], 'B':str(B),'minimum_credit':str(c),'min_credit_ranks':[i+1 for i,x in enumerate(credits) if x==c],'exceptional_core_degree2_credit':str(ex),'regular_upper':str(B-c),'regular_margin':str(21-B+c),'exception_upper':str(B-ex),'exception_margin':str(21-B+ex),'previous_R10_margins':previous,'enumerated_sampling_probability_controls':probability_controls,'labeled_graphs_through_order6':graphs,'neighborhood_missing_edge_bounds':local_relations,'full_neighbor_triangle_equalities':universal_neighbor_relations,'scope':'Exact arithmetic and finite local checks; not exhaustive graphs with h42.'},indent=2))
