#!/usr/bin/env python3
"""Exact arithmetic for the triangle-rank lemma and the h=42 leaf case.
This checks a finite rational calculation, not an enumeration of all graphs.
"""
from fractions import Fraction
from math import comb
from pathlib import Path
import json

def C(n,k):
    return comb(n,k) if 0 <= k <= n else 0

def rho(t):
    return next(d for d in range(100) if C(d,2) >= t)

def degree_lower(i,h):
    return next(d for d in range(max(3,rho(i)),h)
                if d*(d-2) >= 3*i-h)

h,s=42,16
profile=[degree_lower(i,h) for i in range(1,h+1)]
old=[max(3,rho(i)) for i in range(1,h+1)]
den=C(h,s)
def F0(d): return Fraction(C(h-1-d,s)+d*C(h-1-d,s-1),den)
def F1(d): return Fraction(C(h-1-d,s),den)
base=s+sum(map(F0,profile))
credits=[F0(d)-F1(d) for d in profile]
min_credit=min(credits)
exception_credit=F0(3)-F1(2)
net_regular=base-min_credit
net_exception=base-exception_credit
assert base == Fraction(705171683,33577278)
assert min_credit == Fraction(10120,987567)
assert exception_credit >= min_credit
assert net_regular == Fraction(704827603,33577278) < 21
assert net_exception < 21
# Check the local rank conclusion against every abstract missing-edge pattern
# in neighborhoods of orders <=6. This is diagnostic, not needed by the proof.
local_checks=0
for d in range(7):
    edges=[(i,j) for i in range(d) for j in range(i+1,d)]
    for missing in range(1<<len(edges)):
        r=missing.bit_count()
        touched=set()
        for j,(u,v) in enumerate(edges):
            if missing>>j&1: touched.update((u,v))
        assert d-len(touched) >= d-2*r
        local_checks+=1

def rat(x): return {'numerator':x.numerator,'denominator':x.denominator,'decimal':float(x)}
result={
 'scope':'Exact rational bound and elementary neighborhood endpoint check; not graph exhaustion.',
 'h':h,'sample_size':s,'profile':profile,'profile_sum':sum(profile),
 'improved_ranks':[{'rank':i+1,'old':a,'new':b} for i,(a,b) in enumerate(zip(old,profile)) if a!=b],
 'base_expectation':rat(base),'minimum_leaf_credit':rat(min_credit),
 'degree_two_core_root_credit':rat(exception_credit),
 'regular_core_upper':rat(net_regular),'degree_two_core_root_upper':rat(net_exception),
 'strict_margin_below_21':rat(21-net_regular),
 'local_missing_edge_patterns_checked':local_checks,
 'claim':'Every connected h=42 graph with no degree-two vertex satisfies WOWII 384b.'
}
path=Path(__file__).with_name('rank_h42_certificate.json')
path.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
