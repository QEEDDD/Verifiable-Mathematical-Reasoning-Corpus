# Round 15: bounded priority check for the proposed P7-free weighted-density theorem

Checked 2026-10-26, 05:15 UTC. Source/priority screening only; mathematical validity and dependencies are audited elsewhere. No full closure of WOWII #133 is claimed.

## Exact proposed result

For a connected graph with **no C4 as any subgraph** and no induced P7,

`sum_v alpha(G[N(v)]) = 2m - 3t <= 3n`,

where t is the number of triangles. Triangles are allowed. This is the statement in `round_15/domination133/general_p7_density.md`. The unrounded local-independence average is intended; prior rounded/floor interpretations of the original #133 are not interchangeable.

## Relevant primary literature and limits of implication

* **R. Chen, D. Wu, B. Xu**, *Structure and coloring of some (P7,C4)-free graphs*, [arXiv:2302.11115v1](https://arxiv.org/abs/2302.11115v1), submitted 22 February 2023; the locally pinned primary text is `round_09/domination133/sources/Chen_Wu_Xu_2302.11115v1.txt`. Theorem 1.1 bounds the minimum degree of connected (P7,C4,diamond)-free graphs without clique cutsets, except for the Petersen graph and their graph F. Its proof’s C7 neighborhood types and compatibility claims overlap the proposed argument and should remain credited. This is an atom minimum-degree theorem, **not an explicit global weighted-density theorem**. Minimum degree at most two alone does not yield the proposed average-three bound.

* **K. Cameron, S. Huang, I. Penev, V. Sivaraman**, *The class of (P7,C4,C5)-free graphs: decomposition, algorithms, and χ-boundedness*, Journal of Graph Theory **93**(4) (2020), 503–552, [DOI 10.1002/jgt.22499](https://doi.org/10.1002/jgt.22499); [arXiv:1803.03315](https://arxiv.org/abs/1803.03315), first submitted 8 March 2018. The [author-hosted revision dated 22 July 2019](https://iuuk.mff.cuni.cz/~ipenev/P7C4C5FreeGraphs-revision02.pdf) was retrieved and its structural theorems screened.

  Theorem 3.1 characterizes clique-cutset-free graphs in this induced-forbidden class: complete graphs, or graphs with exactly one nontrivial anticomponent of one of five specified types (7-bracelet, thickened emerald, lantern, 6-wreath, 6-crown). This supplies substantial **prior structural context for the C5-free branch**, including lantern structures. No explicit `2m−3t<=3n` statement was located in the screened text.

  A theorem for atoms is not, without more argument, the proposed theorem for every connected graph. For a clique sum along K1, K2, or K3, the deficit `3n−(2m−3t)` loses 3, 4, or 6 respectively. Therefore an atom-level nonnegative deficit does not automatically glue. No complete derivation of the proposed global inequality from this prior structure theorem was established in this audit. This is a limitation of the comparison, **not a claim that no such derivation exists**.

The papers’ “C4-free” means induced-C4-free; the proposed result has the stronger no-C4-subgraph hypothesis. They are relevant sources, but the hypotheses must not be conflated.

## Bounded search scope

Focused web searches used P7/C4-free plus average degree, density, triangles, weighted, local independence, and the literal expression 2m/3n. Fresh GitHub issue searches included all states and used `in:title,body`:

* formal-conjectures + “GraphConjecture 133”;
* formal-conjectures + “P7” + “C4”;
* formal-conjectures + “P7” + “density”;
* Kuberwastaken/c5-k4 + “weighted” + “133”.

All four API searches returned zero items (`api_summary.json` and raw receipts). Those strings are not exhaustive synonyms and zero indexed hits cannot certify priority. The recent pinned c5-k4 status remains partial/blocked for #133 rather than a new full original-unrounded resolution.

## Finding

No explicit prior full weighted-density theorem, nor a verified prior implication covering the exact proposed result, was located in this bounded pass. Substantial published structural overlap exists and should be credited. This is not a worldwide novelty certificate, and it does not convert a partial #133 result into a full closure.
