# Independent audit: h=41 and a redundant repair

**Verdict: PASS — partial exclusion for WOWII384b, not full closure.**

The new proof excludes every connected graph with exactly41 high vertices (degree at least three). Together with completed prior audits, the residual high-order range is11…40, with counterexample representative order still at most43. No enumeration of all graphs through that order is asserted.

Reviewed `round_16/twodomination/rank_h41.tex`, the arithmetic checker/certificate, and the reused Round10 h41 calculations. The original target `t<=2(n−gamma_2)` and the outside-only convention of2-domination are preserved.

## Critical configuration and all branches

A maximum cut supplies at least ceil(41/2)=21 omissions among the high vertices. Low triangle counts belong to {0,1}; thus t<=43, and a counterexample has k=21,t=43,gamma_2=|L|+20. All41 high triangle counts are distinct and at least two, and both low values occur.

If exactly one degree-two vertex x exists, its count must be one. Its two neighbors a,b are adjacent high vertices; a leaf could not be a triangle partner, and no other degree-two vertex is available. A leaf z exists to supply low count zero. Its neighbor c is high: x is already saturated by the triangle, and adjacent leaves would form the entire connected component. All other low vertices are leaves. Removing low vertices changes exactly the two high counts at a,b, by one each; this justifies the offset profile, even if c equals a or b.

If at least two degree-two vertices exist, either there is an independent pair or all are pairwise adjacent. Three pairwise adjacent degree-two vertices would be a whole K3 component; hence the latter case has exactly two, and the required low count one forces a pendant triangle at their common high neighbor. The previously audited Round10 pair/pendant arguments apply without any order>=44 assumption: that order assumption was only a way of guaranteeing the presence of two such vertices in the older representative-order proof. Their constructions and arithmetic themselves exclude the present branches directly. The independent recalculation below confirms the strict margins.

## Offset-rank lemma

Let the increasing full triangle values be t_i>=i+1 and let epsilon_i indicate membership in {a,b}. For d=d_H(v_i), the core neighborhood misses `r=binom(d,2)−(t_i−epsilon_i)` edges. At least d−2r neighbors are untouched by those missing edges. Each has at least t_i−epsilon_i full triangles, because that many triangles already occur through it in the closed core neighborhood.

Among the other high vertices, at most41−i+epsilon_i have full count at least t_i−epsilon_i. For epsilon=0 these are precisely higher ranks; for epsilon=1 at most one lower rank can have value t_i−1, by distinct integer counts. Hence

`d(d−2) >= 2t_i+i−41−3epsilon_i >= 3i+2−41−3epsilon_i`.

The binomial lower bound and d>=3−epsilon are also correct: zero offset means core count at least two, while offset one leaves a positive core count. Negative lower estimates d−2r are harmless. No core connectedness or assumed minimum core degree three is needed.

## Exact placement bound and forcing steps

The conservative alteration selects a uniform15-subset S of the41 high vertices and all low vertices. Its bad-vertex test counts only S plus the distinguished x,z, ignoring all other selected leaves. This makes repair possibly wasteful, not unsafe. Add all bad high vertices; remaining omitted high vertices already have two initial selected neighbors. Omit x only if a,b both belonged to S; its removal then affects no omitted high vertex. This remains valid when the leaf root c equals a or b, because the corresponding root has two distinguished selected low neighbors and needs no repair.

The F_r probabilities have the correct denominator binom(41,15) and already include the focal high vertex being absent. Monotonicity in core degree follows by coupling nested neighborhoods. Substituting the rank degree bounds, adding the chosen15 vertices, and subtracting the probability a,b both belong to S yields exactly U(a,b,c). All33,620 possible distinct a,b ranks and arbitrary c ranks are enumerated; infeasible rank placements only enlarge this safe domain.

Independent exact computation gives maximum U=127990267/6395672 at(40,41,41), and maximum with any boundary rank<=34 equal to127854567/6395672 at(28,40,40), strictly below20. There are exactly22 placements with U>=20. Thus a putative counterexample must have a,b,c>=35.

The maximal excess is eta=76827/6395672. Ranks1,2 have lower core degree3; increasing either to at least4 saves3150/28823>eta, giving an immediate expectation contradiction. Thus both have degree3; their distinct full counts are2 and3. For every rank<=34 the lower profile is at most9, and increasing its actual degree to at least10 saves at least F0(9)−F0(10)=108675/6395672>eta. Consequently all those core degrees are at most9, and rank34 has degree exactly9.

These are legitimate single-term improvements to the same upper bound, not an assumption that every vertex attains its lower profile. Once boundary ranks lie above34, the affected vertices all use F0, so the stated savings apply without a changed low-neighbor credit.

## Near clique and the low-rank adjacent pair

At rank34, the full/core count is at least35 and the exact untouched-neighbor inequality gives
`7 >= 2t_34−9(9−2)`, hence t_34<=35. Therefore its neighborhood is K9 minus one edge. The seven vertices not incident to that missing edge are pairwise adjacent and each has at least35 full triangles. Distinctness makes all seven ranks greater than34, so they are exactly ranks35…41. This produces a genuine K7 on the high boundary ranks.

Rank1 has three core neighbors and exactly two core triangles, so those three neighbors induce P3. Its two endpoints are nonadjacent, and hence cannot both lie in the K7. Choose an endpoint w outside it. Then w has rank<=34 and core degree3…9, neither w nor v1 is any distinguished boundary root, and the two vertices have exactly one common core neighbor (the middle vertex of that P3).

## Redundant repair is safe, including simultaneous low omission

On event E, both w,v1 lie outside S and each has exactly one neighbor in S. Since neither is a distinguished boundary root, both are bad in the conservative test and would be added. Leave v1 unadded while retaining w. The newly omitted v1 has its original selected S-neighbor and the selected repaired vertex w. Every other vertex still omitted was nonbad and already had two initial selected neighbors; none depended on v1, which was not initially selected. Optional omission of x still affects only a,b in S. Selected vertices, including w, do not themselves need2-domination. This proves the joint construction, not merely its expected size.

Outside the pair v1,w, the shared-neighbor class has size1, the exclusive classes have sizes1 and d−2, and the neither-neighbor class has size39−d. Exactly-one-neighbor conditions arise either by selecting the common neighbor and no exclusive one, or by omitting it and selecting one from each exclusive class. Hence

`Pr(E) = [C(39−d,14)+(d−2)C(39−d,13)]/C(41,15)`.

All seven d values were independently evaluated. The minimum is198375/12791344 at d=9. Subtracting this from the maximum excess gives strict margin44721/12791344. Thus the improved expected size is strictly below |L|+20; integrality gives a2-dominating set of size at most |L|+19, contradicting the critical profile.

No independence between repair events, between boundary events, or between the two omissions is assumed. The expectation argument uses their pointwise-safe combined construction and linearity only.

## Independent arithmetic and physical finite controls

`check_independent.py` imports no author code. It constructs both lower profiles directly, computes conditional hypergeometric probabilities, and evaluates each placement through baseline-plus-boundary deltas rather than the author's full per-rank summation. It reproduces all33,620 placements, all22 survivors and both exact maximizing placements. The seven event values are counted by a four-category multivariate sampling sum, independently of the author's closed form.

The checker further enumerates372 small sampling experiments to check the pair event directly. On all labeled core graphs through order6 it finds19,242 graphs containing eligible adjacent pairs, and verifies255,360 actual redundant-repair events. Low-degree core vertices are given selected private leaves to realize a physical degree-at-least-three extension; the conservative test still ignores those leaves. Every resulting omitted vertex is directly checked to retain two selected neighbors. These controls are diagnostic, not a proof by exhaustive h41 graph search.

The reused h41 margins were freshly recomputed as162283/3197836 for two independent degree-two vertices and28995/155992 for a pendant triangle. The author checker was separately rerun from a pinned snapshot; its exact certificate agrees.

Reproduction from workspace root:
```
python wowii_rounds/round_16/independent_audit/384b_h41/check_independent.py
```

## Scope and dependencies

The new h41 proof is an analytic reduction plus an exhaustive finite arithmetic check over explicitly specified rank parameters, with no solver, unverified canonicalizer or graph-feasibility inference. Its dependence on the prior h41 multi-degree-two calculations has been rechecked above. The all-h>=42 and h<=10 inputs are the completed earlier audits, most recently summarized in `round_15/independent_audit/384b_rank/AUDIT.md`; the order43 reduction remains unchanged.

**PASS for excluding h41 and for the combined residual range11…40.** Original384b remains unresolved. No worldwide priority or extra closed-conjecture count is certified. Root handles final TeX formatting, PDF rendering and visual QA separately.
