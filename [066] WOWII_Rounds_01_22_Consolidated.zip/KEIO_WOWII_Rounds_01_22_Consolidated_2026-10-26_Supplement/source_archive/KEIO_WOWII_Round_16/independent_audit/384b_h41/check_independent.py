"""Independent conditional probabilities, boundary deltas and repair controls.
No author script is imported. The 33,620 rank placements are arithmetic,
not graph enumeration proving h41 by exhaustion.
"""
from math import comb
from fractions import Fraction as Q
from itertools import combinations
from collections import Counter
import json

def C(n,k):return comb(n,k) if n>=0 and 0<=k<=n else 0
h,s=41,15
P={}
for offset in (0,1):
 P[offset]=[min(d for d in range(2,h) if d>=3-offset and C(d,2)>=i+1-offset and d*d-2*d>=3*i+2-h-3*offset) for i in range(1,h+1)]
def F(d,f):
 if f>=2:return Q(0)
 # Condition on the focal vertex not belonging to S.
 return Q(h-s,h)*sum((Q(C(d,j)*C(h-1-d,s-j),C(h-1,s)) for j in range(2-f)),Q(0))
base=Q(s)+sum((F(d,0) for d in P[0]),Q(0))
q=Q(s*(s-1),h*(h-1))
qdelta=[F(P[1][i],1)-F(P[0][i],0) for i in range(h)]
leaf=[F(P[0][i],0)-F(P[0][i],1) for i in range(h)]
mx=lo=None;at=lat=None;survivors=[];count=0
for a,b in combinations(range(h),2):
 v=base+qdelta[a]+qdelta[b]-q
 for c in range(h):
  credit=F(P[1][c],1) if c in (a,b) else leaf[c]
  upper=v-credit;loc=(a+1,b+1,c+1);count+=1
  if mx is None or upper>mx:mx,at=upper,loc
  if min(loc)<=34 and (lo is None or upper>lo):lo,lat=upper,loc
  if upper>=20:survivors.append({'ranks':loc,'upper':str(upper)})
slack=mx-20
inc3=F(3,0)-F(4,0);inc9=F(9,0)-F(10,0)
assert count==33620 and len(survivors)==22
assert mx==Q(127990267,6395672) and lo==Q(127854567,6395672)<20
assert inc3==Q(3150,28823)>slack and inc9==Q(108675,6395672)>slack
assert P[0][:2]==[3,3] and P[0][33]==9 and max(P[0][:34])==9
# Count four categories outside the pair: shared, left-only, right-only,
# neither. The pair itself is required absent. No closed-form event from
# the author's implementation is imported.
def event(h,s,d):
 total=0
 for common in (0,1):
  left=right=1-common
  remaining=s-common-left-right
  total+=C(1,common)*C(1,left)*C(d-2,right)*C(h-2-d,remaining)
 return Q(total,C(h,s))
events=[event(h,s,d) for d in range(3,10)]
assert min(events)==Q(198375,12791344)
assert min(events)-slack==Q(44721,12791344)>0
# Direct subset enumeration of the pair event at smaller parameters.
event_controls=0
for hh in range(6,14):
 for d in range(3,hh-1):
  Nu={1,2,3};Nw={0,2}|set(range(4,4+d-2))
  assert len(Nw)==d and len(Nu&Nw)==1
  for ss in range(2,hh):
   good=0
   for S in combinations(range(hh),ss):
    S=set(S)
    good+=(0 not in S and 1 not in S and len(S&Nu)==len(S&Nw)==1)
   assert Q(good,C(hh,ss))==event(hh,ss,d)
   event_controls+=1
# Universal redundancy operation checked on all labeled core graphs n<=6.
# All core vertices are given selected private leaves if needed to achieve
# degree>=3 in a physical supergraph. The conservative test ignores leaves.
core_graphs=pair_events=0
for n in range(2,7):
 E=list(combinations(range(n),2))
 for mask in range(1<<len(E)):
  A=[0]*n
  for j,(a,b) in enumerate(E):
   if mask>>j&1:A[a]|=1<<b;A[b]|=1<<a
  pairs=[(u,w) for u in range(n) if A[u].bit_count()==3 for w in range(n) if A[u]>>w&1 and A[w].bit_count()>=3 and (A[u]&A[w]).bit_count()==1]
  if not pairs:continue
  core_graphs+=1;full=(1<<n)-1
  padding=[max(0,3-a.bit_count()) for a in A]
  for S in range(1<<n):
   bad=sum(1<<v for v in range(n) if not(S>>v&1) and (A[v]&S).bit_count()<2)
   for u,w in pairs:
    if S>>u&1 or S>>w&1 or (A[u]&S).bit_count()!=1 or (A[w]&S).bit_count()!=1:continue
    assert bad>>u&1 and bad>>w&1
    D=(S|bad)&~(1<<u)
    assert all(D>>v&1 or (A[v]&D).bit_count()+padding[v]>=2 for v in range(n))
    pair_events+=1
# Recheck the earlier h41 multiple-degree-two arithmetic.
def rho(t):return next(d for d in range(3,50) if C(d,2)>=t)
deg=[rho(i) for i in range(2,43)]
oldbase=s+sum((F(min(h-1,d),0) for d in deg),Q(0))
oldpair=20-(oldbase-2*q)
oldpendant=20-(oldbase-min(F(min(h-1,d),0) for d in deg)-Q(s,h))
assert oldpair==Q(162283,3197836)>0 and oldpendant==Q(28995,155992)>0
print(json.dumps({'status':'PASS','profiles':P,'placements':count,'surviving_placements':survivors,'max_upper':str(mx),'attaining_max':at,'max_low_boundary_upper':str(lo),'attaining_low_max':lat,'eta':str(slack),'degree3_increment_saving':str(inc3),'degree9_increment_saving':str(inc9),'event_probabilities_by_d3_to_9':list(map(str,events)),'minimum_event':str(min(events)),'strict_final_margin':str(min(events)-slack),'small_exact_event_controls':event_controls,'physical_core_graphs_tested':core_graphs,'physical_redundant_repair_events':pair_events,'prior_h41_independent_pair_margin':str(oldpair),'prior_h41_pendant_margin':str(oldpendant),'scope':'Exact boundary-rank arithmetic and independent finite local controls; not exhaustive h41 graphs.'},indent=2))
