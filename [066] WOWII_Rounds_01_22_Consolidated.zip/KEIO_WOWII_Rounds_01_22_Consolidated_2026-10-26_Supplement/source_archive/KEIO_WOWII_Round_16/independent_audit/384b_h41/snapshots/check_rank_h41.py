#!/usr/bin/env python3
"""Exact parameter arithmetic for the h=41 one-degree-two proof.
The 33,620 cases are rank placements, not graph enumeration or solver states.
"""
from fractions import Fraction as F
from itertools import combinations
from math import comb
from pathlib import Path
import json
H,S=41,15

def C(n,k):return comb(n,k) if 0<=k<=n else 0

def rho(t):return next(d for d in range(H) if C(d,2)>=t)

def lower(i,eps):
    return next(d for d in range(max(3-eps,rho(i+1-eps)),H)
                if d*(d-2)>=3*i+2-H-3*eps)

def bad_numerator(d,r):
    if r>=2:return 0
    return C(H-1-d,S)+(d*C(H-1-d,S-1) if r==0 else 0)

def rational(x):return dict(numerator=x.numerator,denominator=x.denominator,decimal=float(x))

DEN=C(H,S)
OMIT=C(H-2,S-2)
profile=[[lower(i,e) for i in range(1,H+1)] for e in (0,1)]
best=(-1,None);best_low=(-1,None);cases=0;survivors=[]
for a,b in combinations(range(H),2):
    for c in range(H):
        total=S*DEN-OMIT
        for v in range(H):
            eps=int(v in (a,b));r=eps+int(v==c)
            total+=bad_numerator(profile[eps][v],r)
        cases+=1
        loc=(a+1,b+1,c+1)
        if total>best[0]:best=total,loc
        if min(loc)<=34 and total>best_low[0]:best_low=total,loc
        if total>=20*DEN:survivors.append(dict(Q_ranks=list(loc[:2]),leaf_rank=loc[2],upper=rational(F(total,DEN))))
max_upper=F(best[0],DEN);max_low=F(best_low[0],DEN)
slack=max_upper-20
increment3=F(bad_numerator(3,0)-bad_numerator(4,0),DEN)
increment9=F(bad_numerator(9,0)-bad_numerator(10,0),DEN)
# u has degree 3; w is an endpoint of the P3 on N(u), so it has
# exactly one common neighbor with u. For d=d(w), the exclusive
# neighborhood sizes are 1 and d-2, and there are H-3-d+1 other vertices.
events=[]
for d in range(3,10):
    other=H-3-d+1
    p=F(C(other,S-1)+(d-2)*C(other,S-2),DEN)
    events.append(dict(neighbor_degree=d,probability=rational(p)))
min_event=min(F(x['probability']['numerator'],x['probability']['denominator']) for x in events)
assert cases==33620 and len(survivors)==22
assert max_upper==F(127990267,6395672)
assert max_low==F(127854567,6395672)<20
assert increment3==F(3150,28823)>slack
assert increment9==F(108675,6395672)>slack
assert min_event==F(198375,12791344)>slack
assert min_event-slack==F(44721,12791344)
# With all boundary ranks at least 35, these profile facts force the
# low-degree vertices used by the analytic near-clique/P3 argument.
assert profile[0][0]==profile[0][1]==3
assert profile[0][33]==9
assert max(profile[0][:34])==9
result={
 'scope':'Exact finite rank-placement arithmetic; no graph-exhaustion or solver claim.',
 'h':H,'sample_size':S,'placements_checked':cases,
 'profiles_by_triangle_offset':profile,
 'maximum_upper':rational(max_upper),'maximum_upper_placement':best[1],
 'maximum_with_boundary_rank_at_most_34':rational(max_low),
 'maximum_low_boundary_placement':best_low[1],
 'maximum_surplus_above_20':rational(slack),
 'degree_3_to_4_saving':rational(increment3),
 'degree_9_to_10_saving':rational(increment9),
 'redundant_repair_event_probabilities':events,
 'minimum_event_probability':rational(min_event),
 'strict_final_margin':rational(min_event-slack),
 'surviving_placements':survivors,
 'claim':'The h=41 exactly-one-degree-two branch cannot violate WOWII 384b.'
}
Path(__file__).with_name('rank_h41_certificate.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('profiles_by_triangle_offset','surviving_placements','redundant_repair_event_probabilities')},indent=2))
