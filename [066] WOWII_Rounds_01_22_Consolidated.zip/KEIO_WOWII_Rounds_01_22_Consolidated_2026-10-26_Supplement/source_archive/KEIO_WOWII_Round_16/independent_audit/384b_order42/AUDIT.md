# Independent audit: representative order42 for WOWII384b

**Verdict: PASS after one explicit counting-branch repair.** If original384b has a counterexample, it has a connected representative of order at most42. Combined with the separately audited h41 theorem, the residual high-vertex range is11…40. This is not a full resolution and does not assert that the remaining graphs have been exhaustively searched.

Final audited author TeX SHA-256: `0cb54459af1a54fd7804b0c3edd43e3730e390eba2529ea909517aef377ca5c4`.

## Repair found and verified

The original draft deleted a last leaf in the odd, nonpendant D2–D2 case and immediately counted at least43−h degree-two vertices. The order can fall from43 to42 in that deletion, so this inference required a branch. The author repaired it explicitly: if the new order is at most42, the desired representative already exists; otherwise replace G by the new representative and retain n>=43 before counting. Lines134–139 of the revised TeX contain this branch. No numerical formula changed. The repaired argument is valid; the report does not silently accept the earlier inference.

## Inputs and critical equality

For a counterexample, maximum cut and the triangle-value count force `k=n−gamma_2=ceil(h/2)`. Odd h gives pairwise distinct high triangle values at least two; even h gives at least h−1 high vertices with distinct values at least two. The prior leaf deletion preserves h and all triangle values, and cannot increase k: an omission set in the smaller graph lifts by leaving deleted leaves selected. The maximum-cut lower bound then forces the same critical k, so the counterexample property persists.

The stronger low-degree structural input was reread in `round_09/twodomination/attachment_stability.tex`, not inferred from the published vertex-cover bound. For even h, maximum-cut stability gives an independent low graph. For odd h, it gives at most one low edge. The proof reduces each low component to a path and keeps its high endpoints fixed while maximizing its crossing edges. A longer low path would have good degree-two vertices on both high-cut sides, including the larger side, contradicting critical k. Each remaining low-edge component can independently place a good degree-two vertex on the smaller side, so two such components would also exceed k. This justifies the at-most-one-edge assertion used in the pendant and nonpendant cases. A cover-number-at-most-one bound alone would not have been sufficient.

The prior order reduction and the h<=10 / h>=41 exclusions have completed independent audits. In particular the new h41 report is separate at `round_16/independent_audit/384b_h41/AUDIT.md`; it is not assumed from an unreviewed proposed theorem.

## Even representatives need at most one leaf

Every high vertex on at least two triangles has at least three nonleaf neighbors, so deleting its leaves does not lower it out of the high set. There is at most one exceptional high vertex v. Connectedness and h>=11 give it at least one nonleaf neighbor. Preserve its degree by retaining only the necessary leaves; retain a single leaf elsewhere only if needed to keep zero in the triangle-value set. A retained leaf at v already keeps zero. Low-graph independence precludes leaf neighbors of degree two.

The only remaining two-leaf possibility has both leaves at v, whose unique nonleaf neighbor makes its triangle count zero. Delete v and those leaves. All other h−1 high vertices have at least two triangles, none using v; hence all retain degree at least three. A locally maximal cut in the remainder provides an omittable set of at least ceil((h−1)/2)=h/2 high vertices. Restore the deleted structure and also omit v, while keeping its two leaves selected. The old omitted vertices retain the two selected neighbors they already had in the remainder; v has its two selected leaves. This gives h/2+1 omissions, a contradiction. No assumption that every vertex of the remainder has unchanged degree is needed. Connectedness of that remainder is in fact preserved because v had only one nonleaf attachment, but maximum cut would work even without it.

Thus the claimed at-most-one-leaf even representative is proved, and the triangle-count set and h are preserved in all accepted deletions.

## Simultaneous alteration and pendant credits

The degree profile and repair upper bounds match the previously audited alteration construction. The displayed R_i uses the total-degree lower bound even when some neighbors are low: replacing a forced selected low neighbor by a random high nonneighbor can only increase the repair event. For the numerical h range the profile degree is below h−1, so enough high nonneighbors exist for this comparison. Larger actual degrees only improve the bound; two fixed low neighbors give zero repair. All21 calculations use exact rational arithmetic.

For independent degree-two I, remove a vertex only if all its high neighbors belonged to the initial high sample. Its low neighbors lie outside I and remain selected. Thus each removed vertex has both neighbors selected, and no previously omitted high vertex loses a selected neighbor. If a degree-two vertex has zero,one,two high neighbors, this event has probability1,s/h,q respectively, each at least q. The construction is simultaneously safe for all of I.

For a pendant triangle p1,p2,v, the root v has two initially selected low neighbors and never needs repair. Its baseline repair term can therefore be removed, saving at least min R_i. Remove p1 only when v was initially sampled, with probability s/h, leaving p2 selected. Every other degree-two vertex has no low adjacency because the pendant edge is the unique possible low edge. They form an independent set and have no adjacency to p1,p2. Their omission rule can therefore be applied at the same time. If v is not sampled, p1 is retained and v keeps both low neighbors; if v is sampled, omitting p1 affects no omitted high vertex. No independence between these random events is needed. Linearity of expectation yields exactly the manuscript's combined pendant formula.

## Complete order counting

The already established bound `h+ceil(h/2)+2` is at most41 for h<=26. Consider27<=h<=40 and a reduced representative of order at least43.

* Even h: at most one leaf and independent D2 give |D2|>=42−h.
* Odd h without a pendant triangle: if the possible low edge is absent or is leaf–D2, then D2 is independent and again has at least42−h vertices. If the edge is D2–D2 and nontriangular, both endpoints have triangle count zero. All leaves then meet high vertices, so deleting all leaves preserves high membership and zero. Apply the repaired stopping branch described above. If order remains at least43, there are no leaves and |D2|>=43−h; removing one endpoint of the sole possible low edge gives an independent set of size at least42−h.
* Odd h with a pendant triangle: at most one leaf leaves at least n−h−1−2>=40−h other degree-two vertices, exactly the m lower bound used in the combined estimate.

The14 independent-set margins (h27…40) and7 pendant margins (odd h27…39) are all strictly positive. They force an expected2-dominating-set size below `|L|+floor(h/2)=n−k`. Integrality gives a contradiction whenever the representative still has order at least43. Thus some connected representative has order at most42. This proves existence of a bounded representative, not that every original counterexample itself has that order.

## Independent computation

`check_independent.py` imports no author code. It derives the degree profiles and evaluates the repair terms by conditioning on the focal vertex being omitted, then computes all21 rational margins. Only after derivation does it compare the exact fractions with the author's certificate. Every entry matches and is positive.

The independent checker also verifies the combined pendant-plus-other-D2 operation on240 small connected labeled graphs with the requisite unique low edge, through order6. All1,140 sampled sets yield valid2-dominating sets, and300 exact expected-size inequalities pass. A separate generic reconstruction test checks37,231 lifts obtained by adjoining a high support with two selected leaves to arbitrary small graphs and omitting that support together with an existing omittable set. These are finite diagnostic controls of the constructions, not substitutes for the universal arguments.

The author exact-arithmetic program was separately rerun from the pinned snapshot. See `independent_results.json`, `author_rerun.json`, the checker and SHA manifest. Reproduction from workspace root:
```
python wowii_rounds/round_16/independent_audit/384b_order42/check_independent.py
```

## Final scope

**PASS for representative order42, after the explicit deletion-count repair.** Residual h11…40 and order<=42 are separate necessary reductions; neither has been exhaustively discharged. No full original384b closure, extra solved-conjecture count or worldwide priority is certified. Root handles release TeX formatting and PDF visual QA.
