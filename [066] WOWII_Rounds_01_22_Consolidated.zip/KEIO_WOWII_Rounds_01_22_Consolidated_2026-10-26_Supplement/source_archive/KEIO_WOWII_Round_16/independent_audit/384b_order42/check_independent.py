"""Exact conditional alteration margins and simultaneous omission controls.
No candidate script is imported. Finite tests do not replace the proof.
"""
from itertools import combinations
from fractions import Fraction as Q
from math import comb
import json

def C(n,k):return comb(n,k) if n>=0 and 0<=k<=n else 0
def degrees(h):
 ts=range(2,h+2) if h%2 else range(2,h+1)
 result=[min(d for d in range(3,h) if C(d,2)>=j) for j in ts]
 return result if h%2 else [3]+result

def repair(h,s,d):
 e=min(d,h-1)
 return Q(h-s,h)*sum((Q(C(e,j)*C(h-1-e,s-j),C(h-1,s)) for j in (0,1)),Q(0))
ind=[];pend=[]
for h in range(27,41):
 s=14 if h<=35 else 15
 rr=[repair(h,s,d) for d in degrees(h)]
 margin=Q(h//2)-s-sum(rr)+Q((42-h)*s*(s-1),h*(h-1))
 assert margin>0
 ind.append({'h':h,'s':s,'margin':str(margin)})
for h,s in [(27,13),(29,13),(31,13),(33,14),(35,14),(37,14),(39,15)]:
 rr=[repair(h,s,d) for d in degrees(h)]
 margin=Q(h//2)-s-sum(rr)+min(rr)+Q(s,h)+Q((40-h)*s*(s-1),h*(h-1))
 assert margin>0
 pend.append({'h':h,'s':s,'margin':str(margin)})
# Compare exact fractions only after independent derivation.
author=json.load(open('wowii_rounds/round_16/twodomination/order42_certificate.json'))
for ours,theirs in [(ind,author['independent_degree_two_cases']),(pend,author['pendant_triangle_cases'])]:
 assert len(ours)==len(theirs)
 for a,b in zip(ours,theirs):assert a['h']==b['h'] and a['s']==b['s'] and Q(a['margin'])==Q(b['margin']['numerator'],b['margin']['denominator'])

def graph(n,mask):
 A=[0]*n
 for i,(u,v) in enumerate(combinations(range(n),2)):
  if mask>>i&1:A[u]|=1<<v;A[v]|=1<<u
 return A
def td2(A,D):return all(D>>v&1 or (A[v]&D).bit_count()>=2 for v in range(len(A)))
def connected(A):
 seen=1
 while True:
  old=seen
  for v in range(len(A)):
   if seen>>v&1:seen|=A[v]
  if seen==old:return seen==(1<<len(A))-1
pendant_graphs=simultaneous_samples=expectation_checks=0
for n in range(3,7):
 for mask in range(1<<(n*(n-1)//2)):
  A=graph(n,mask)
  if not connected(A):continue
  high=[v for v in range(n) if A[v].bit_count()>=3];h=len(high)
  if h<3:continue
  H=sum(1<<v for v in high);L=((1<<n)-1)^H
  lowedges=[(u,v) for u,v in combinations(range(n),2) if L>>u&1 and L>>v&1 and A[u]>>v&1]
  if len(lowedges)!=1:continue
  p1,p2=lowedges[0]
  if A[p1].bit_count()!=2 or A[p2].bit_count()!=2:continue
  common=A[p1]&A[p2]&H
  if common.bit_count()!=1:continue
  root=common.bit_length()-1
  other=[v for v in range(n) if A[v].bit_count()==2 and v not in (p1,p2)]
  assert all(not(A[v]&L) for v in other)
  pendant_graphs+=1
  for s in range(2,h):
   total=0;rr=[repair(h,s,A[v].bit_count()) for v in high]
   bound=L.bit_count()+s+sum(rr)-min(rr)-Q(s,h)-Q(len(other)*s*(s-1),h*(h-1))
   for selected in combinations(high,s):
    X=sum(1<<v for v in selected);D=initial=X|L
    for v in high:
     if not(X>>v&1) and (A[v]&initial).bit_count()<2:D|=1<<v
    if X>>root&1:D&=~(1<<p1)
    for v in other:
     if A[v]&X==A[v]:D&=~(1<<v)
    assert td2(A,D);simultaneous_samples+=1;total+=D.bit_count()
   assert Q(total,C(h,s))<=bound;expectation_checks+=1
# Generic lifting used when the double-leaf high support is removed.
lift_controls=0
for n in range(1,6):
 for mask in range(1<<(n*(n-1)//2)):
  F=graph(n,mask)
  for attachment in range(n):
   G=F.copy()+[0,0,0]
   for u,v in [(attachment,n),(n,n+1),(n,n+2)]:G[u]|=1<<v;G[v]|=1<<u
   for omitted in range(1<<n):
    if not td2(F,((1<<n)-1)^omitted):continue
    omit=omitted|(1<<n);D=((1<<(n+3))-1)^omit
    assert td2(G,D);lift_controls+=1
print(json.dumps({'status':'PASS','independent_low_margins':ind,'pendant_low_margins':pend,'positive_exact_margins':len(ind)+len(pend),'small_pendant_graphs':pendant_graphs,'simultaneous_omission_samples':simultaneous_samples,'expected_size_inequalities_checked':expectation_checks,'double_leaf_lift_controls':lift_controls,'scope':'Exact rational checks and finite construction controls; representative-order theorem is analytic.'},indent=2))
