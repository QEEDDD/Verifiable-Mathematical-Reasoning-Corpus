#!/usr/bin/env python3
"""Exact expectation margins for the order-42 counterexample reduction."""
from fractions import Fraction as F
from math import comb
from pathlib import Path
import json

def C(n,k):return comb(n,k) if 0<=k<=n else 0

def rho(t):return next(d for d in range(3,100) if C(d,2)>=t)

def profile(h):return list(map(rho,range(2,h+2))) if h%2 else [3]+list(map(rho,range(2,h+1)))

def bounds(h,s):
    vals=[F(C(h-1-d,s)+d*C(h-1-d,s-1),C(h,s)) for d in profile(h)]
    return s+sum(vals),min(vals),F(s*(s-1),h*(h-1))

def rat(x):return dict(numerator=x.numerator,denominator=x.denominator,decimal=float(x))
independent=[]
for h in range(27,41):
    s=14 if h<=35 else 15
    B,m,q=bounds(h,s)
    margin=h//2-(B-(42-h)*q)
    assert margin>0
    independent.append(dict(h=h,s=s,independent_low_count=42-h,margin=rat(margin)))
pendant=[]
samples={27:13,29:13,31:13,33:14,35:14,37:14,39:15}
for h,s in samples.items():
    B,m,q=bounds(h,s)
    other=40-h
    margin=h//2-(B-m-F(s,h)-other*q)
    assert margin>0
    pendant.append(dict(h=h,s=s,other_degree_two_count=other,margin=rat(margin)))
r={'scope':'Exact arithmetic only; structural hypotheses are proved in addendum42.tex.',
   'independent_degree_two_cases':independent,'pendant_triangle_cases':pendant,
   'claim':'Any remaining WOWII 384b counterexample has a connected representative of order at most42.'}
Path(__file__).with_name('order42_certificate.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r,indent=2))
