# Independent audit: decorated dominating even cycles

**Verdict: PASS for the corrected arbitrary-k classification and its stated original133 corollary.**

For k>=3, a connected C4-subgraph-free graph with a dominating induced C_(2k), radius k+1 and no induced P_(2k+2) has exactly the described nonempty single-contact matching classes and optional unique triangle vertices on cycle edges, with no other edges. Conversely all those graphs qualify, have p=2k+1 and L=2n−t. The domination hypothesis must not be omitted.

The standalone corollary is also valid: original133 holds for connected graphs with a dominating induced C_(2k), radius k+1 and unrounded average local independence ell<=k+1. This is a parameter-class result, not unrestricted original133 or a classification of every radius-five graph. No solved-conjecture count or worldwide priority is certified.

## Reviewed versions and precision repair

Reviewed `general_even_cycle_classification.md`, the author checker/results, and the complete standalone `manuscript.tex`. Final note SHA-256 is `0d59bd95c916b04e69f208016cda754223e477a931e2867ebed0e4f89a293dfe`; final author TeX SHA-256 is `a5f7c675acba2b93ba68aae3c5d614e4f2d41fb39312f256d5bbb3ae85291cf1`.

One false descriptive sentence in the earlier converse was repaired: a triangle on a cycle edge belongs to the same2-connected block as the cycle, not a separate pendant triangle block. The replacement correctly argues that a C4 through b_i would require a second length-two path between its two cycle contacts, absent from this construction. A-class attachments really are pendant edges/triangles. This affects only the C4-free justification, not the classification or formulas. The final note and standalone TeX contain the corrected argument.

The classification proof is elementary and self-contained. Its original133 corollary uses only the previously checked classical induced-path bound p>=2r−1 of Erdős–Saks–Sós, whose proof is credited to Fan Chung (SectionII, Theorem2.2). The exact pinned primary statement was checked during the Round15 audit. The other connected-domination theorems used in earlier radius classifications are not needed here, because domination by the cycle is an explicit hypothesis.

## Contact sets and radius witnesses

Write N=2k. If an exterior vertex has cycle contacts separated by shorter circular distance d>=3, the largest distance from it to any cycle vertex is at most `1+floor((N−d)/2)<=k−1`: every point of either arc is at most half the longer arc from one of its endpoints. Since the cycle dominates, that exterior vertex is within k of the whole graph, contradicting radius k+1. A distance-two contact pair makes a C4. Thus a nonempty contact set is a singleton or adjacent pair; a larger set necessarily has a prohibited pair. Contact sets are nonempty by domination.

Two adjacent-pair vertices of the same type would have two common neighbors, so each b_i type has at most one vertex. The neighborhood C4 test makes each single-contact class A_i a matching plus isolates. The listed permitted cross-class ranges are exhaustive: adjacent A classes, nearby A–b types, and b–b types with index separation at most two produce explicit C4s. Index differences are cyclic, and the ranges at N=6 are nonempty exactly as required.

The antipodal cycle vertex c_(i+k) is within k of every vertex except possibly those in A_i: every other single contact is at cycle distance at most k−1, and an adjacent contact pair always has a contact at that distance. Its eccentricity is at least k+1, so a witness z_i in A_i exists with distance exactly k+1. A cross-class neighbor of z_i would have a cycle contact at distance at most k−2 from c_(i+k), yielding a route of length at most k to z_i. Hence every witness has no exterior neighbor outside its own A class and has at most one within-class mate.

This witness property is independent of how many other cross edges the graph contains. Therefore the path arguments below handle arbitrary simultaneous cross edges, rather than only the single-edge perturbations tested computationally.

## All parameterized induced paths

Every displayed contradiction uses N−2 cycle vertices and four exterior vertices, hence exactly N+2 distinct vertices. The two omitted cycle vertices separate the used cycle segments and remove the unused contacts of b vertices. All exterior vertices other than the two cross-edge endpoints are witnesses, so they cannot create cross-class chords.

* A_0–A_d,3<=d<=N−3: omit cycle indices d−1,N−1. The witnesses have classes d−2,N−2, different from both cross endpoints and from each other. The two cycle segments contain d−1 and N−d−1 vertices. Unique contacts and the witness property exclude every chord, including the extreme d=3,N−3 cases.
* A_0–A_2: if z0 is not adjacent to x, the first path omitting1,N−1 is induced. Thus xz0 must be an edge. Reflection gives yz2. The final path omitting1,2 starts with z3 and ends with z2; the latter's only exterior path neighbor is its mate y. Its cycle contact2 is absent. Distinctness and absence of cycle chords hold already at N=6. Rotation/reflection covers both circular distance-two orientations.
* A_0–b_d,2<=d<=N−3: omit d,N−1 and use witnesses in classes d−1,N−2. The unused b_d contact is d. Even when d=N−3, its used contact equals the last cycle index N−2 but the witness in that class has no exterior edge to b_d, so no extra chord appears. The lower endpoint d=2 is also valid.
* b0–b_d,3<=d<=N−3: omit0,d, exactly the unused contacts. Witness classes d−1,N−1 differ, and the two segments contain d−1 and N−d−1 cycle vertices. The resulting path is induced in all allowed parameter cases.

These cases exhaust the cross-edge ranges, forcing their complete absence. The proof does not assume unsupported uniform adjacency between exterior classes.

## Converse and exact invariants

No C4 uses an A attachment, which is a pendant edge or triangle. A C4 through b_i would require another length-two path between c_i,c_(i+1); uniqueness of that b type and all other contact types preclude one. The core cycle has length at least six, so the whole graph is C4-subgraph-free.

Every exterior vertex is simplicial, with one neighbor or two adjacent neighbors, and hence can occur only as an endpoint of an induced path. Such a path contains at most N−1 cycle vertices and two exterior endpoints, giving p<=N+1. Choosing one vertex in A0 and one in A_(N−2), and using cycle vertices0,…,N−2, gives an induced path of that order. Thus p=N+1 exactly.

The optional triangles and pendant A attachments do not shorten cycle distances. Each cycle vertex has eccentricity k+1, witnessed in the opposite A class. An A vertex has eccentricity k+2, again witnessed in the opposite A class. A b_i vertex has eccentricity k+1, witnessed in either of its two farthest A classes. Hence the radius is k+1 exactly.

With a total A vertices, q internal matching edges and b pair-contact vertices, the counts `n=N+a+b`, `m=N+a+q+2b`, `t=q+b` are correct. C4-subgraph exclusion makes each neighborhood a matching plus isolates, giving L=2m−3t. Substitution yields L=2n−t<=2n.

## Precise standalone corollary

If a C4 occurs, original133 has exponent zero and a geodesic gives p>=r+1. Otherwise, for ell<=k, the classical bound gives `p>=2(k+1)−1=2k+1>=r+ell`. For k<ell<=k+1, the classification rules out P_(2k+2)-freeness, because every classified graph has ell<=2<k. Thus `p>=2k+2>=r+ell`. This is exhaustive for the stated parameter class and keeps both the dominating induced cycle and exact radius assumptions.

The new corollary is not a claim that every relevant radius-five graph has a dominating C8. The separate later radius-five candidate is not part of this audit or paper.

## Independent finite controls

`check_independent.py` imports no author functions. It recognizes the displayed path **vertex sets** by induced degrees (two degree-one vertices, all remaining degree two) plus connectedness, rather than trusting the author's ordered-path tester. It checks5,656 certificates for every even cycle length6…60:3,136 distant A–A,112 distance-two A–A,1,624 A–b,784 b–b, including all mate choices. It also directly checks1,176 two-contact distance bounds and2,400 witness-contact distance inequalities on cycles through length100.

For converses, it exhausts all46,656 C6 decorations with each A class being a singleton,two isolates,or one matched pair, and independently optional b vertices. It additionally checks200 seeded decorations on cycle lengths8,10,12,16,20, reaching physical order72. Every graph is tested for C4 by common-neighbor counts, all eccentricities by BFS, local independence by exact neighborhood subsets, absence of the forbidden path by a separate induced-path DFS, and presence of the stated maximum path by its explicit vertex list. Every check passes. These are finite diagnostics, not a substitute for the arbitrary-k analytic proof.

The author program was also rerun from a pinned snapshot and reproduces its1,261 path certificates and400 decorations. Reproduce the independent test from workspace root with:
```
python wowii_rounds/round_16/independent_audit/even_cycle/check_independent.py
```

## Consolidation and scope

The entire standalone TeX was checked against the corrected note, including its added original133 corollary and source credit. Root delivery differs only by xurl and hidden-link formatting. Final hashes are pinned in `CONSOLIDATED_TEX_AUDIT.md` and `source_hashes.json`.

**PASS arbitrary-k structural theorem and stated parameter-class corollary. No full original133 closure.** Root handles PDF compilation and visual QA; worldwide priority is a separate bounded source-audit question.
