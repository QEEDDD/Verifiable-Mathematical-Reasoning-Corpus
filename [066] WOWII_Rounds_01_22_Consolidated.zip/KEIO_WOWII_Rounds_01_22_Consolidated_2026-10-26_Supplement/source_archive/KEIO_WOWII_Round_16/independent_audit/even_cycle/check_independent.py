"""Independent path-subset recognition and exhaustive small converse controls.
No author functions are imported. Counts are diagnostics, not universal proof.
"""
from itertools import product,combinations
from collections import Counter,deque
import random,json

def base(N):
 A={}
 def edge(x,y):A.setdefault(x,set()).add(y);A.setdefault(y,set()).add(x)
 for i in range(N):
  edge(('c',i),('c',(i+1)%N));edge(('z',i),('c',i))
  edge(('b',i),('c',i));edge(('b',i),('c',(i+1)%N))
 return A

def edge(A,x,y):A.setdefault(x,set()).add(y);A.setdefault(y,set()).add(x)
def check_path_set(A,W,N):
 assert len(W)==N+2
 degree=Counter(len(A[v]&W) for v in W)
 assert degree=={1:2,2:N},degree
 seen={next(iter(W))};queue=list(seen)
 for v in queue:
  for w in A[v]&W:
   if w not in seen:seen.add(w);queue.append(w)
 assert seen==W
counts=Counter()
for N in range(6,61,2):
 for kind in ('AA','AB','BB'):
  drange=range(2,N-2) if kind!='BB' else range(3,N-2)
  for d in drange:
   for mates in product((0,1),repeat=2 if kind=='AA' else (1 if kind=='AB' else 0)):
    A=base(N);x=('x',0) if kind!='BB' else ('b',0);y=('y',d) if kind=='AA' else ('b',d)
    if kind!='BB':
     edge(A,x,('c',0))
     if mates[0]:edge(A,x,('z',0))
    if kind=='AA':
     edge(A,y,('c',d))
     if mates[1]:edge(A,y,('z',d))
    edge(A,x,y)
    if kind=='AA' and d==2:
     if not mates[0]:omitted={1,N-1};witnesses={('z',N-2),('z',0)}
     elif not mates[1]:omitted={(2-i)%N for i in (1,N-1)};witnesses={('z',(2-i)%N) for i in (N-2,0)}
     else:omitted={1,2};witnesses={('z',3),('z',2)}
     key='AA_distance2'
    elif kind=='AA':omitted={d-1,N-1};witnesses={('z',d-2),('z',N-2)};key='AA_long'
    elif kind=='AB':omitted={d,N-1};witnesses={('z',d-1),('z',N-2)};key='AB'
    else:omitted={0,d};witnesses={('z',d-1),('z',N-1)};key='BB'
    W={('c',i) for i in range(N) if i not in omitted}|witnesses|{x,y}
    check_path_set(A,W,N);counts[key]+=1
# Check every possible two-contact distance bound directly on bare cycles.
contact_bounds=witness_bounds=0
for N in range(6,102,2):
 k=N//2
 for d in range(3,k+1):
  dist=lambda x,y:min((x-y)%N,(y-x)%N)
  maximum=max(1+min(dist(j,0),dist(j,d)) for j in range(N))
  assert maximum==1+(N-d)//2<=k-1
  contact_bounds+=1
 for j in range(2,N-1):assert min((j-k)%N,(k-j)%N)<=k-2;witness_bounds+=1

def decorate(N,states):
 A=[0]*N;classes=[];bs=[]
 def e(x,y):A[x]|=1<<y;A[y]|=1<<x
 def v(contacts):
  z=len(A);A.append(0)
  for x in contacts:e(x,z)
  return z
 for i in range(N):e(i,(i+1)%N)
 for i,state in enumerate(states):
  typ,b=divmod(state,2);cl=[v([i]) for _ in range(1 if typ==0 else 2)]
  if typ==2:e(*cl)
  classes.append(cl)
  if b:bs.append(v([i,(i+1)%N]))
 return A,classes,bs

def check_decor(N,states):
 A,classes,bs=decorate(N,states);n=len(A);k=N//2
 assert all((A[x]&A[y]).bit_count()<=1 for x in range(n) for y in range(x))
 ecc=[]
 for start in range(n):
  seen=front=1<<start;d=0
  while seen.bit_count()<n:
   nxt=0;todo=front
   while todo:
    bit=todo&-todo;todo-=bit;nxt|=A[bit.bit_length()-1]
   front=nxt&~seen;seen|=front;assert front;d+=1
  ecc.append(d)
 assert all(ecc[i]==k+1 for i in range(N))
 assert all(ecc[x]==k+2 for cl in classes for x in cl)
 assert all(ecc[x]==k+1 for x in bs)
 # Exact neighborhood independence, without the weighted identity.
 L=0
 for hood in A:
  best=0;sub=hood
  while True:
   if sub.bit_count()>best and all(not(A[v]&sub) for v in range(n) if sub>>v&1):best=sub.bit_count()
   if sub==0:break
   sub=(sub-1)&hood
  L+=best
 triangles=sum((A[x]&A[y]).bit_count() for x in range(n) for y in range(x) if A[x]>>y&1)//3
 assert L==2*n-triangles
 # Search directly for an induced forbidden path, checking all earlier contacts.
 target=N+2
 def dfs(last,used,depth):
  if depth==target:return True
  todo=A[last]&~used
  while todo:
   bit=todo&-todo;todo-=bit;v=bit.bit_length()-1
   if A[v]&used==1<<last and dfs(v,used|bit,depth+1):return True
  return False
 assert not any(dfs(v,1<<v,1) for v in range(n))
 path=[classes[0][0]]+list(range(N-1))+[classes[N-2][0]]
 assert len(path)==N+1 and all(bool(A[x]>>y&1)==(j==i+1) for i,x in enumerate(path) for j,y in enumerate(path) if j>i)
 return n
exhaustive=0;maxn=0
for states in product(range(6),repeat=6):maxn=max(maxn,check_decor(6,states));exhaustive+=1
rng=random.Random(161336)
random_controls=0
for N in (8,10,12,16,20):
 for _ in range(40):maxn=max(maxn,check_decor(N,[rng.randrange(6) for _ in range(N)]));random_controls+=1
print(json.dumps({'status':'PASS','path_certificates_by_type':dict(counts),'path_certificates_total':sum(counts.values()),'certificate_cycle_lengths':[6,60],'direct_contact_distance_checks':contact_bounds,'direct_witness_distance_checks':witness_bounds,'exhaustive_C6_decorations':exhaustive,'larger_exact_converse_checks':random_controls,'larger_converse_cycle_lengths':[8,10,12,16,20],'maximum_physical_order':maxn,'seed':161336,'scope':'Independent finite controls; general proof is the parameterized witness/path argument.'},indent=2))
