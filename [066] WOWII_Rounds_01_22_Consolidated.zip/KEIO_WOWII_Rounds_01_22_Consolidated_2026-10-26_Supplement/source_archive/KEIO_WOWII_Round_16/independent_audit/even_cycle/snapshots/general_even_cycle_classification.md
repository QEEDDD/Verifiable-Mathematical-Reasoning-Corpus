# A uniform decorated-even-cycle classification

**KEIO — 26 October 2026.**

**Status:** complete proposed analytic partial theorem; independent review pending. This is not a full resolution of WOWII133. It generalizes the separately audited radius-four, dominating-six-cycle analysis. No worldwide-priority claim is made.

## Theorem

Let k≥3, and let G be a connected graph containing no C4 as a subgraph. Suppose G has a dominating induced cycle C=c_0…c_(2k−1)c_0, radius k+1, and no induced P_(2k+2). Then G has exactly the following form:

1. For every cycle vertex c_i there is a nonempty class A_i of vertices whose sole cycle neighbor is c_i.
2. Each G[A_i] is a matching plus isolated vertices.
3. On each cycle edge c_ic_(i+1), optionally place one vertex b_i adjacent to its endpoints.
4. There are no other vertices or edges.

Conversely, every such graph has the stated properties. It has

    p(G)=2k+1=2r(G)−1,
    L(G):=sum_v alpha(G[N(v)])=2n−t≤2n,

where t is its triangle count.

All indices below are modulo N=2k. Intervals written in a displayed path are traversed in the indicated ordinary cyclic direction.

## Contact sets and witnesses

If an exterior vertex x has two cycle contacts at circular distance d≥3 (choose the shorter arc, so d≤k), then every cycle vertex is within

    1+floor((2k−d)/2)≤k−1

of x. Since the cycle dominates, eccentricity(x)≤k, contradicting radius k+1. Two contacts at distance two give a C4. Thus each exterior contact set is a singleton or an adjacent pair; three contacts would contain a prohibited pair. Let A_i and b_i denote these types. Every b_i type occurs at most once, since two vertices sharing both contacts give a C4. Each G[A_i] is a matching plus isolates, since a three-vertex path in N(c_i) completes a C4.

Four-cycle exclusion leaves only these possible cross-class edges:

- A_i–A_j with circular distance at least two;
- A_i–b_j with j−i∈{2,…,N−3};
- b_i–b_j with j−i∈{3,…,N−3}.

For each i, the cycle vertex c_(i+k) is within distance k of every vertex except possibly A_i. Its eccentricity is at least k+1. Consequently A_i is nonempty and contains a witness z_i with dist(c_(i+k),z_i)=k+1.

A witness z_i has no exterior neighbor outside A_i. For an allowed neighbor in A_j, its contact c_j lies at cycle distance at most k−2 from c_(i+k), giving a path of length at most k to z_i. For an allowed b_j neighbor, either contact is also within k−2, with the same contradiction. Thus z_i has at most one exterior neighbor, namely a possible mate within A_i.

## Eliminating cross-class edges

Every path displayed below has exactly N+2 vertices. Distinct cycle segments are separated by the stated omitted cycle vertices. All non-cycle vertices other than the cross-edge endpoints are the witnesses, whose lack of cross-class neighbors excludes every further exterior chord.

### A_0–A_d, with 3≤d≤N−3

For an edge xy, x∈A_0 and y∈A_d, take

    z_(d−2), c_(d−2), c_(d−3), …, c_0,
    x, y,
    c_d, c_(d+1), …, c_(N−2), z_(N−2).

The omitted cycle vertices are c_(d−1),c_(N−1). The witnesses' contact classes differ from those of x,y. This is induced P_(N+2), a contradiction.

### A_0–A_2

Let xy be such an edge. The witness z_0 differs from x because x has a cross-class neighbor. If z_0x were not an edge, then

    z_(N−2), c_(N−2), c_(N−3), …, c_2,
    y, x, c_0, z_0

would be induced P_(N+2). Therefore z_0x is an edge. Reflecting the cycle gives z_2y as an edge. But now

    z_3, c_3, c_4, …, c_(N−1), c_0,
    x, y, z_2

is induced P_(N+2). Its omitted cycle vertices are c_1,c_2, and z_2's only exterior path neighbor is its mate y. This is again impossible. Rotation and reversal cover every distance-two pair of classes.

### A_0–b_d, with 2≤d≤N−3

For an edge xb_d, x∈A_0, take

    z_(d−1), c_(d−1), c_(d−2), …, c_0,
    x, b_d,
    c_(d+1), c_(d+2), …, c_(N−2), z_(N−2).

The omitted cycle vertices are c_d,c_(N−1). In particular b_d's unused contact c_d is absent. The endpoint witness classes differ from A_0. This is induced P_(N+2).

### b_0–b_d, with 3≤d≤N−3

Take

    z_(d−1), c_(d−1), c_(d−2), …, c_1,
    b_0, b_d,
    c_(d+1), c_(d+2), …, c_(N−1), z_(N−1).

The omitted cycle vertices are c_0,c_d, the two unused contacts of b_0,b_d. Again this is induced P_(N+2).

The list exhausts all cross-class edges. Therefore no such edge exists, proving the asserted structure.

## Converse and counting

In a graph of the asserted form, every exterior vertex is simplicial: it has one neighbor or two adjacent neighbors. Such a vertex can occur on an induced path only as an endpoint. An induced path uses at most N−1 cycle vertices and two exterior endpoints. Thus p≤N+1. Since each A_i is nonempty, an induced path from A_0 through c_0,c_1,…,c_(N−2) to A_(N−2) has N+1 vertices, giving equality.

Every cycle vertex has eccentricity k+1, witnessed by the opposite A class. Every A vertex has eccentricity k+2, witnessed by a vertex in the opposite A class. Every b_i vertex has eccentricity k+1, witnessed by either farthest A class. Hence the radius is k+1. The construction contains no C4. An A attachment lies in a pendant edge or triangle. A C4 containing b_i would require a second length-two path between c_i and c_(i+1), and the construction has no such path. The remaining core cycle has length at least six.

Let a=sum|A_i|, q=sum|E(G[A_i])|, and b=# {i:b_i exists}. Then

    n=N+a+b, m=N+a+q+2b, t=q+b.

In a C4-subgraph-free graph every neighborhood is a matching plus isolates, so L=2m−3t. Therefore

    L=2N+2a−q+b=2n−(q+b)=2n−t.

This proves the theorem. ∎

## Exact next-step use and limitations

For k=4, this settles the dominating-C8 branch of a C4-subgraph-free P10-free graph of radius five. The full radius-five case also has a possible connected dominating P8-free radius-four subgraph that is a decorated C6, rather than a C8. That branch is **not** covered by this theorem. The theorem does not assume or prove that every relevant graph has a dominating even cycle, and it does not settle unrestricted WOWII133.
