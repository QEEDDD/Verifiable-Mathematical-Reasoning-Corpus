#!/usr/bin/env python3
"""Finite checks of the explicit uniform path certificates, not a proof by search."""
import itertools,json,random
from pathlib import Path

def make(N):
    a=[set() for _ in range(3*N)]
    def edge(x,y): a[x].add(y);a[y].add(x)
    for i in range(N):
        edge(i,(i+1)%N)
        edge(i,N+i)             # radius witness z_i
        edge(i,2*N+i);edge((i+1)%N,2*N+i)  # every optional b_i present
    return a

def edge(a,x,y):a[x].add(y);a[y].add(x)
def add(a,neighbors):
    v=len(a);a.append(set())
    for w in neighbors:edge(a,v,w)
    return v

def c4free(a):return all(len(a[x]&a[y])<=1 for x in range(len(a)) for y in range(x))
def induced(a,p):
    return len(set(p))==len(p) and all((p[j] in a[p[i]])==(j==i+1) for i in range(len(p)) for j in range(i+1,len(p)))
def radius(a):
    es=[]
    for s in range(len(a)):
        ds={s:0};q=[s]
        for x in q:
            for y in a[x]:
                if y not in ds:ds[y]=ds[x]+1;q.append(y)
        assert len(ds)==len(a)
        es.append(max(ds.values()))
    return min(es),es

def longest(a):
    aa=[sum(1<<v for v in ns) for ns in a];best=1
    def walk(u,mask,blocked,depth):
        nonlocal best
        best=max(best,depth)
        options=aa[u]&~blocked&~mask
        while options:
            bit=options&-options;options-=bit;v=bit.bit_length()-1
            walk(v,mask|bit,blocked|aa[u],depth+1)
    for u in range(len(a)):walk(u,1<<u,0,1)
    return best

count=0;bykind={}
def record(kind,a,p,N):
    global count
    assert c4free(a),(N,kind,'C4')
    assert len(p)==N+2,(N,kind,len(p))
    assert induced(a,p),(N,kind,p)
    count+=1;bykind[kind]=bykind.get(kind,0)+1

for k in range(3,16):
    N=2*k
    # Long-diagonal A--A pairs, including both possible within-class mates.
    for d in range(3,N-2):
        for mx,my in itertools.product(range(2),repeat=2):
            a=make(N);x=add(a,[0]+([N] if mx else []));y=add(a,[d]+([N+d] if my else []));edge(a,x,y)
            p=[N+d-2]+list(range(d-2,-1,-1))+[x,y]+list(range(d,N-1))+[2*N-2]
            record('AA_long',a,p,N)
    # Distance-two pair: one of the two forcing paths, or the final mate path.
    for mx,my in itertools.product(range(2),repeat=2):
        a=make(N);x=add(a,[0]+([N] if mx else []));y=add(a,[2]+([N+2] if my else []));edge(a,x,y)
        if not mx:
            p=[2*N-2]+list(range(N-2,1,-1))+[y,x,0,N]
        elif not my:
            # Reflection i -> 2-i takes the first forcing path to its symmetric form.
            def f(v):
                if v<N:return (2-v)%N
                if v<2*N:return N+(2-(v-N))%N
                if v==x:return y
                if v==y:return x
                raise AssertionError(v)
            p=list(map(f,[2*N-2]+list(range(N-2,1,-1))+[y,x,0,N]))
        else:p=[N+3]+list(range(3,N))+[0,x,y,N+2]
        record('AA_distance2',a,p,N)
    for d in range(2,N-2):
        for mx in range(2):
            a=make(N);x=add(a,[0]+([N] if mx else []));edge(a,x,2*N+d)
            p=[N+d-1]+list(range(d-1,-1,-1))+[x,2*N+d]+list(range(d+1,N-1))+[2*N-2]
            record('AB',a,p,N)
    for d in range(3,N-2):
        a=make(N);edge(a,2*N,2*N+d)
        p=[N+d-1]+list(range(d-1,0,-1))+[2*N,2*N+d]+list(range(d+1,N))+[2*N-1]
        record('BB',a,p,N)

# Exact converse checks on varied random decorations, with all parameters recorded.
rng=random.Random(1331601);decor=0
for N in (6,8,10,12):
    for rep in range(100):
        a=[set() for _ in range(N)]
        for i in range(N):edge(a,i,(i+1)%N)
        acount=0;qcount=0;bcount=0
        for i in range(N):
            vertices=[add(a,[i]) for _ in range(rng.randint(1,3))];acount+=len(vertices)
            if len(vertices)>=2 and rng.randrange(2):edge(a,*vertices[:2]);qcount+=1
            if rng.randrange(2):add(a,[i,(i+1)%N]);bcount+=1
        assert c4free(a)
        r,es=radius(a);assert r==N//2+1
        assert all(es[i]==N//2+1 for i in range(N))
        m=sum(map(len,a))//2;t=sum(len(a[x]&a[y]) for x in range(len(a)) for y in a[x] if y<x)//3
        L=2*m-3*t
        assert t==qcount+bcount and L==2*len(a)-t
        assert longest(a)==N+1
        decor+=1
out={'status':'PASS','cycle_lengths_for_path_checks':list(range(6,31,2)),'explicit_path_certificates':count,'by_kind':bykind,'exact_random_decoration_checks':decor,'decoration_cycle_lengths':[6,8,10,12],'seed':1331601,'scope':'finite supplementary checks, not an exhaustive proof of the arbitrary-order theorem'}
print(json.dumps(out,indent=2))
Path(__file__).with_name('verification_even_cycle_classification.json').write_text(json.dumps(out,indent=2)+'\n')
