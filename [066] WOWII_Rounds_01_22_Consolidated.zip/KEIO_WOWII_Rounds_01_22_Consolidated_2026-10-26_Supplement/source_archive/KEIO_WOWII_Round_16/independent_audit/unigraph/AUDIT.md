# Independent audit: induced forests, residue and induced matchings on unigraphs

**Verdict: PASS as an auxiliary subclass theorem.** Every unigraph G, and every graph obtained by arbitrary split compositions over a unigraph, satisfies `f(G)>=r(G)+im(G)`. The separate smallest-counterexample consequence is also valid: a smallest counterexample to this inequality for arbitrary graphs must be canonically indecomposable.

**Mandatory scope calibration:** this is not a full result for original WOWII61, nor a new substantive solution of its unigraph cases. Every connected unigraph has diameter at most three, so those cases already follow from the elementary `f>=alpha+1>=r+1` bound. The induced-matching strengthening, which can grow unboundedly beyond the +1 term, is the actual auxiliary theorem. Worldwide priority is not certified.

## Audited versions and structural dependency

Reviewed `round_15/independence/unigraph_subclass.md` (SHA-256 `84e2c611fc4ae33315472020507783f4b58479ea635151cf3878a11ef9f8d7ac`), the mandatory `unigraph_priority_boundary.md`, and the author checker/results.

The published structural input is genuinely needed; the finite check does not replace it. Barrus, *Havel–Hakimi residues of unigraphs*, IPL112 (2012),44–48, Corollary3.3 and Theorems4.1–4.2 were independently located in the primary indexed author manuscript. They support split-composition residue additivity, the canonical-component criterion for unigraphs, and exactly the nonsplit indecomposable core families listed in the proof, with complementation allowed. The definition of U_m is also confirmed there. These are credited to Barrus and the underlying Tyshkevich/Chernyak structure theory, not claimed as new. [Primary author manuscript](https://math.uri.edu/~barrus/papers/UniRes_v1.pdf), [journal DOI](https://doi.org/10.1016/j.ipl.2011.10.011).

Direct PDF fetching timed out; the existing `/tmp/UniRes_v1.pdf` is HTML, not a PDF, and was not represented as one. Exact numbered statements were available from the primary URL's indexed text. This audit does not claim to have independently reproved the classification or downloaded/read a complete PDF. The elementary residue inputs can additionally be derived directly, as follows.

## Independent derivation of the credited split residue facts

The Havel–Hakimi reduction may use any maximum-degree head and any largest-degree tie choices. We use the familiar bipartite switching observation: a row can be made adjacent to columns of the largest prescribed degrees. If it meets a lower-degree column a and misses a higher-degree column b, some other row meets b and misses a; switching these two row-column edges exchanges the contacts while preserving all row and column degrees. Repeat until the prescribed highest columns are neighbors. This proves each peeling step below is graphical.

For a split graph choose a maximum independent part A, whose complement B is a clique. Such a split partition exists: starting with any split partition, its largest independent set either is the independent part or adds one clique vertex having no neighbor in that part. Every vertex of B has an A-neighbor, or A would not be maximum. With b remaining clique vertices, their degrees are at least b, while A degrees are at most b. Thus a largest clique entry is an HH head, and the other clique entries may all be decremented before the A entries; decrement the requisite number of largest A entries. The bipartite observation preserves the remaining A–B realization. Each remaining clique vertex keeps its original positive number of A-neighbors in the degree data. Hence all B vertices are peeled, leaving exactly |A| zeros: `r=|A|=alpha`.

For a composition S(A,B)∘J with h=|J|>=2, a remaining clique entry has degree h+b−1 plus its A-row degree. It is at least every inner entry (whose maximum is h+b−1) and every A entry. In its tail, each remaining clique entry has degree at least h+b−2>=b, every J entry has degree at least b, and A entries have degree at most b. Therefore HH can decrement all remaining B entries and all J entries before taking the required largest A entries. The same bipartite switch preserves realizability. Peeling all B leaves the original J degree list and |A| zeros. Thus `r(S∘J)=|A|+r(J)` without requiring the outer split graph to be a unigraph or its given A to be maximum. If |J|=1, the whole composition is split and has independence |A|+1, proving the same formula. Empty A/B cases are included.

These are transparent audit derivations of established facts, not novelty claims. The standard bound r<=alpha used elsewhere is the previously audited residue bound, also stated in Barrus's reference framework.

## Composition inheritance

Deleting B leaves J plus |A| isolates, so `f(S∘J)>=|A|+f(J)`. Any edge outside J has an endpoint in B. That endpoint is adjacent to all J vertices and all other B vertices, so it conflicts with every other possible edge of an induced matching. Thus if J has an edge, every induced matching of size at least two lies wholly in J, and `im(S∘J)=im(J)` also when this value is one. Residue additivity now proves the inheritance inequality exactly. If J is edgeless, S∘J is split and is handled directly. Repeated composition is legitimate by induction; no assumption that arbitrary outer split factors are unigraphs is needed.

For a split graph with an edge, every induced matching has size one, since every edge meets the clique. A maximum independent set plus any vertex outside it induces a star and isolates, so f>=alpha+1=r+1. Edgeless graphs have f=r=n and im=0. This includes empty/one-vertex degenerate cases.

## Exhaustive analytic check of the listed core families

* C5 has residue2, induced matching number1 and induced forest order4. The latter is obtained by deleting one vertex.
* A matching mK2 has `(f,r,im)=(2m,m,m)`.
* For mK2 disjoint union K1,n, removing the star HH head leaves n zeros and2m ones. Thus `(f,r,im)=(2m+n+1,m+n,m+1)`, and equality holds.
* Complements of these nonsplit forests have independence2, because the original forest has clique number2. They have no induced2K2, since that would correspond to an induced C4 in the forest. They are noncomplete and have an edge, hence im=1, residue2 and f>=3. The residue-one characterization used here is valid: if a positive HH head d leaves residue1, induction makes the residual list the complete-graph list on n−1 entries; if d<n−1, any decremented tail entry originally had value n−1>d, impossible for a maximum head. Thus d=n−1 and the original graph is complete. The zero-head base case is immediate.
* U_m has degree list `(2m+2,2^(2m+3))`. One HH step leaves `(2,1^(2m+2))`, so residue=m+2. Removing the common cycle vertex gives a forest of order2m+3, which is maximum because U_m is cyclic. Avoiding the common vertex gives an induced matching of m+1 edges, one in each triangle remainder and one in the P3 remainder. An induced matching using the common vertex cannot have a second edge, since that vertex has only one nonneighbor. Hence im=m+1 and equality holds.
* The complement of U_m has degree list `((2m+1)^(2m+3),1)`. After one HH step it is `(2m+1,(2m)^(2m+1),1)`; after the second it is `((2m−1)^(2m+1),1)`, the same form with parameter m−1. It ends at1^4 and has residue2. The original four-cycle vertices induce2K2 in the complement, giving im>=2 and f>=4. An induced matching of three edges would make those six vertices have degree4 within U_m, impossible because all but its common vertex have total degree2. Thus im=2 and f>=r+im. No unsupported assertion about a maximum forest is needed in this case.

The credited classification covers all nonsplit indecomposable cores up to complement; C5 is self-complementary. Split cores were covered separately. Therefore composition inheritance closes the auxiliary theorem for all unigraphs at arbitrary order.

## Original61 and smallest-counterexample boundary

An induced diametral path of length D contains ceil(D/3) pairwise induced-matching edges, by selecting edge positions1,4,7,…. Thus the stronger candidate implies original61 on the stated subclass. However the mandatory boundary note correctly observes that every connected unigraph has diameter at most three. Connected nonsplit cores in the classification have diameter at most three; a nontrivial connected split composition also has diameter at most three, since outer independent vertices must have a neighbor in its complete outer clique and every inner vertex meets that clique. An outer factor with empty clique only adds isolates and cannot be a nontrivial connected composition. Therefore original61 here was already a consequence of f>=alpha+1>=r+1. No new original-conjecture count is justified.

If a smallest counterexample to the arbitrary-graph candidate were a proper split composition, its smaller nonempty inner graph would satisfy the candidate by minimality when it has an edge, and inheritance would give a contradiction. An edgeless inner graph makes the composition split, already covered. Thus such a counterexample must be canonically indecomposable. This is a restriction on a hypothetical counterexample, not a proof that none exists.

## Independent finite controls

`check_independent.py` uses a different exact algorithm from the author: forests are detected by iterative degree-at-most-one stripping on each vertex subset; induced matchings are detected by requiring every induced-subset vertex to have degree exactly one. It does not use the author's edge-compatibility clique algorithm or union-find forest routine.

For orders7/8 it uses the previously independently covered `core7_masks.txt` / `core8_masks.txt`, rather than the author's connected graph8 catalogue and disconnected-component generator. Earlier explicit permutation audits establish coverage. This run additionally verifies pairwise nonisomorphism within every degree-sequence bucket, requiring303,073 comparisons. It reproduces all696 unigraphs among13,599 nonisomorphic graphs through order8, and checks every one exactly. Counts by order0…8 are1,1,2,4,11,28,72,170,407; equality counts are1,1,2,4,10,23,57,134,320. All connected examples have diameter at most three.

The checker also constructs51,600 compositions using every labeled inner graph of orders1…4 and all split factors with0…3 independent and0…3 clique vertices, excluding the empty outer factor and allowing all bipartite edges. It verifies exact residue additivity, the forest lower bound, induced-matching inheritance when the inner graph has an edge, and the target inequality. These are finite controls, not a replacement for the analytic inheritance proof or the published classification.

The author checker was rerun separately and reproduces its696 cases. Exact results, input hashes and snapshots are included. Reproduce from workspace root with:

```
PYTHONPATH=/tmp/wowii_deps python wowii_rounds/round_15/independent_audit/unigraph/check_independent.py
```

NetworkX is used for the compact Atlas inputs and independent isomorphism tests; the three invariant algorithms are explicitly implemented in the checker. Package/catalogue completeness is not used as the proof of the universal theorem.

## Final verdict and remaining limits

**PASS auxiliary subclass theorem, conditional only on the explicitly credited published canonical classification in the ordinary mathematical sense.** Exact structural statements were verified in the indexed primary manuscript; no inaccessible AI claim is being silently assumed. The direct PDF acquisition limitation is recorded above. No full original61 closure, arbitrary-graph candidate closure, priority certification, or new nontrivial original61 subclass resolution is claimed. Later one-end splitting notes and broader core classifications are separate, unaudited research objects and are not dependencies here.
