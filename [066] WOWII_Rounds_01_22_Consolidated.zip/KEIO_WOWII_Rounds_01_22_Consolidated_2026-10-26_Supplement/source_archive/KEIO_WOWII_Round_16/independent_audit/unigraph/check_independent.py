"""Independent finite controls using covered core masks, not author's graph8 file.
Exact forests use leaf stripping; induced matchings use degree-one subsets.
"""
from pathlib import Path
from itertools import combinations
from collections import defaultdict,Counter
import json,hashlib
import networkx as nx
B=Path('wowii_rounds')
def adj(n,mask):
 a=[0]*n
 for j,(x,y) in enumerate(combinations(range(n),2)):
  if mask>>j&1:a[x]|=1<<y;a[y]|=1<<x
 return a
def res(a):
 d=sorted((x.bit_count() for x in a),reverse=True)
 while d and d[0]:
  h=d[0];d=d[1:]
  assert h<=len(d)
  for i in range(h):d[i]-=1
  assert min(d,default=0)>=0
  d.sort(reverse=True)
 return len(d)
def invariants(a):
 f=im=0
 for S in range(1<<len(a)):
  sz=S.bit_count()
  if sz//2>im and sz%2==0 and all((a[v]&S).bit_count()==1 for v in range(len(a)) if S>>v&1):im=sz//2
  if sz<=f:continue
  T=S
  while T:
   remove=sum(1<<v for v in range(len(a)) if T>>v&1 and (a[v]&T).bit_count()<=1)
   if not remove:break
   T^=remove
  if not T:f=sz
 return f,res(a),im
def nxg(a):
 g=nx.Graph();g.add_nodes_from(range(len(a)))
 g.add_edges_from((x,y) for x in range(len(a)) for y in range(x+1,len(a)) if a[x]>>y&1)
 return g
records=[];pairchecks=0;total=0;maxD=0
for n in range(9):
 if n<=6:
  # Atlas is used here only for compact nonisomorphic finite controls.
  gs=[G for G in nx.graph_atlas_g() if len(G)==n]
  aa=[ [sum(1<<w for w in G[v]) for v in range(n)] for G in gs]
 else:
  name=B/f'round_11/twodomination/core{n}_masks.txt'
  aa=[adj(n,m) for m in map(int,name.read_text().split())]
 groups=defaultdict(list)
 for a in aa:groups[tuple(sorted(x.bit_count() for x in a))].append(a)
 # Verify pairwise nonisomorphism within degree classes. Coverage of supplied
 # core masks has a separate earlier explicit-permutation independent audit.
 for bucket in groups.values():
  ng=[nxg(a) for a in bucket]
  for i,g in enumerate(ng):
   for z in ng[:i]:
    pairchecks+=1;assert not nx.is_isomorphic(g,z)
 uni=[v[0] for v in groups.values() if len(v)==1];tight=0;connected=0
 for a in uni:
  f,r,im=invariants(a);assert f>=r+im
  tight+=f==r+im
  g=nxg(a)
  if len(a)>0 and nx.is_connected(g):
   D=nx.diameter(g);maxD=max(maxD,D);connected+=1
   assert D<=3 and (D==0 or f>=r+(D+2)//3)
 records.append({'n':n,'representatives':len(aa),'unigraphs':len(uni),'equalities':tight,'connected_unigraphs':connected})
 total+=len(uni)
# Test the stronger inheritance against arbitrary labeled split factors and
# every labeled inner graph through order4, not only unigraphs.
composition_cases=0
for h in range(1,5):
 for m in range(1<<(h*(h-1)//2)):
  inner=adj(h,m);fj,rj,ij=invariants(inner)
  for na in range(4):
   for nb in range(4):
    if na+nb==0:continue
    for cross in range(1<<(na*nb)):
     n=h+na+nb;a=[0]*n
     for v in range(h):a[v]=inner[v]
     def edge(x,y):a[x]|=1<<y;a[y]|=1<<x
     for x,y in combinations(range(h+na,n),2):edge(x,y)
     for x in range(h+na,n):
      for y in range(h):edge(x,y)
     for x in range(na):
      for y in range(nb):
       if cross>>(x*nb+y)&1:edge(h+x,h+na+y)
     f,r,im=invariants(a)
     assert r==na+rj and f>=na+fj and f>=r+im
     if ij:assert im==ij
     composition_cases+=1
print(json.dumps({'status':'PASS','orders':records,'unigraph_total':total,'pairwise_nonisomorphism_tests_within_degree_classes':pairchecks,'maximum_connected_unigraph_diameter':maxD,'arbitrary_split_composition_controls':composition_cases,'source8_masks_sha256':hashlib.sha256((B/'round_11/twodomination/core8_masks.txt').read_bytes()).hexdigest(),'source7_masks_sha256':hashlib.sha256((B/'round_11/twodomination/core7_masks.txt').read_bytes()).hexdigest(),'scope':'Finite controls; classification remains a credited external theorem. Covered seven/eight-core masks come from separately completed independent permutation audit.'},indent=2))
