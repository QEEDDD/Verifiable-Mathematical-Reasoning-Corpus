"""Exact finite check on every unlabeled graph of order <=8.

The n<=7 atlas is NetworkX's published atlas. For order8 we combine the
11117 connected graph6 records with all unordered multisets of connected
atlas components. Degree classes of size one are then exactly unigraphs.
"""
import argparse,collections,hashlib,itertools,json,time
from pathlib import Path
import networkx as nx

def residue(D):
    D=sorted(D,reverse=True)
    while D and D[0]:
        d=D.pop(0)
        for i in range(d):D[i]-=1
        assert min(D,default=0)>=0
        D.sort(reverse=True)
    return len(D)

def forest(G,S):
    par={u:u for u in S}
    def root(u):
        while par[u]!=u:
            par[u]=par[par[u]];u=par[u]
        return u
    for u,v in G.edges():
        if u in par and v in par:
            a,b=root(u),root(v)
            if a==b:return False
            par[a]=b
    return True

def exact_f(G):
    for k in range(len(G),-1,-1):
        if any(forest(G,S) for S in itertools.combinations(G,k)):return k

def exact_im(G):
    E=list(G.edges());C=nx.Graph();C.add_nodes_from(range(len(E)))
    for i,e in enumerate(E):
        for j,d in enumerate(E[:i]):
            if len(set(e+d))==4 and not any(G.has_edge(u,v) for u in e for v in d):C.add_edge(i,j)
    return max(map(len,nx.find_cliques(C)),default=0)

def disjoint8(components):
    def rec(left,start,chosen):
        if not left:
            if len(chosen)>=2:yield nx.disjoint_union_all(chosen)
            return
        for i in range(start,len(components)):
            H=components[i]
            if len(H)>left:break
            yield from rec(left-len(H),i,chosen+[H])
    yield from rec(8,0,[])

def main():
    p=argparse.ArgumentParser();p.add_argument('--connected-eight',default='wowii_rounds/round_01/leaves/graph8c.g6')
    a=p.parse_args();start=time.monotonic()
    atlas=nx.graph_atlas_g();components=sorted([G for G in atlas if len(G) and nx.is_connected(G)],key=lambda G:(len(G),nx.to_graph6_bytes(G,header=False)))
    eight=list(nx.read_graph6(a.connected_eight))+list(disjoint8(components))
    assert len(eight)==12346,len(eight)
    by_n=collections.defaultdict(list)
    for G in atlas+eight:by_n[len(G)].append(G)
    out={'scope':'exact finite controls, not a replacement for structural classification',
         'connected_eight_sha256':hashlib.sha256(Path(a.connected_eight).read_bytes()).hexdigest(),
         'networkx_version':nx.__version__,'orders':[]}
    total=0
    for n,graphs in sorted(by_n.items()):
        groups=collections.defaultdict(list)
        for G in graphs:groups[tuple(sorted(dict(G.degree()).values()))].append(G)
        uni=[L[0] for L in groups.values() if len(L)==1];tight=0
        for G in uni:
            f=exact_f(G);r=residue([d for _,d in G.degree()]);im=exact_im(G)
            assert f>=r+im,(n,list(G.edges()),f,r,im)
            tight+=f==r+im
        total+=len(uni)
        out['orders'].append({'n':n,'unlabeled_graphs':len(graphs),'unigraphs':len(uni),'candidate_equalities':tight})
    out.update(status='PASS_ALL_UNIGRAPHS_THROUGH_8',total_unigraphs=total,seconds=time.monotonic()-start)
    print(json.dumps(out,indent=2))
if __name__=='__main__':main()
