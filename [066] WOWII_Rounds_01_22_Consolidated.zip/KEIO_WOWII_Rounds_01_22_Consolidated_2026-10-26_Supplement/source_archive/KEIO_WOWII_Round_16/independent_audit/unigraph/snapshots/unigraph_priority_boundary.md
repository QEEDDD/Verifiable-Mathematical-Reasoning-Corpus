# Priority and scope correction for the unigraph subclass result

The proof in `unigraph_subclass.md` is a stronger auxiliary result for
`f>=r+im`, not a new nontrivial resolution of original WOWII #61 on unigraphs.

Indeed every connected unigraph has diameter at most three, as follows from
the same credited canonical classification. Each connected nonsplit
indecomposable core has diameter at most three; the disconnected cores
become diameter at most three whenever a split composition connects them.
More generally, a connected nontrivial split composition has diameter at
most three: its outer independent vertices have neighbors in the outer
clique, inner vertices are adjacent to that entire clique, and the outer
clique is complete.

Therefore original #61 for connected unigraphs is already covered by the
elementary bound `f>=alpha+1>=r+1`. The induced-matching strengthening can
be much stronger, for example on `U_m`, and is the actual auxiliary theorem
proved in the companion note. No new original conjecture closure is counted.

## A general smallest-counterexample consequence

The split-composition inheritance proposition also proves that any smallest
counterexample to `f>=r+im` must be **canonically indecomposable**. A proper
inner graph would satisfy the candidate by minimality, and the inheritance
proof would close the outer graph. If the inner graph were edgeless, the
outer graph would be split and already covered. This is a restriction on a
hypothetical counterexample, not proof that none exists.

All residue additivity and canonical classification inputs remain credited
to Barrus/Tyshkevich. Prior-equivalent publication of the auxiliary
unigraph inequality itself has not yet been excluded.
