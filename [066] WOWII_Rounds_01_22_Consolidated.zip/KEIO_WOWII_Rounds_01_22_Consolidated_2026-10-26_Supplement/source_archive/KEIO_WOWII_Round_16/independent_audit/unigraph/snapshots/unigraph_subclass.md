# The induced-forest / residue / induced-matching inequality for unigraphs

**Status: proved subclass result, pending independent audit and prior-equivalent
source review.** This is not a full closure of WOWII #61 or of the stronger
candidate for arbitrary graphs.

Write `f(G)` for maximum induced forest order, `r(G)` for ordinary
Havel--Hakimi residue, and `im(G)` for maximum induced matching size.

## Theorem

Every unigraph `G` satisfies

\[
 \tag{C} f(G)\ge r(G)+\operatorname{im}(G).
\]

The same holds after any number of split compositions over a unigraph;
the outer split factors need not themselves be unigraphs.

Consequently every connected unigraph of positive diameter `D` satisfies
original WOWII #61,

\[
 f(G)\ge r(G)+\left\lceil D/3\right\rceil,
\]

because a diametral path is induced and contains an induced matching of
`ceil(D/3)` edges. This is a subclass corollary only.

## Established structural inputs and attribution

A split composition `S(A,B) circle J` takes a split graph with specified
independent part `A` and clique part `B`, and a nonempty graph `J`, and
adds every edge from `B` to `V(J)` and none from `A` to `V(J)`.

We use the following established results, not claims of new work:

* residue equals independence on split graphs: Barrus [1, Proposition 2.2];
* `r(S(A,B) circle J)=|A|+r(J)`: Barrus [1, Corollary 3.3];
* the canonical decomposition of a unigraph has split outer factors and
  an indecomposable unigraph core, and the nonsplit cores are, up to
  complementation, `C5`, `mK2` (`m>=2`), `mK2 disjoint union K1,n`
  (`m>=1,n>=2`), and `U_m` (`m>=1`): [1, Theorems 4.1--4.2], crediting
  Tyshkevich and Chernyak.

Here `U_m` consists of one chordless four-cycle and `m` triangles, all
sharing one common vertex and otherwise vertex-disjoint. The classification
is a genuine external theorem; the proof below does not purport to reprove it.

[1] M. D. Barrus, *Havel--Hakimi residues of unigraphs*, Information
Processing Letters **112** (2012), 44--48.
DOI: <https://doi.org/10.1016/j.ipl.2011.10.011>.
Author manuscript: <https://math.uri.edu/~barrus/papers/UniRes_v1.pdf>.
The primary indexed manuscript was inspected, including the numbered
statements and definition of `U_m`. The direct download currently redirects
to a departmental HTML page; no downloaded HTML is represented as a PDF.

## Split-composition inheritance

Suppose `J` has an edge and satisfies (C), and put `G=S(A,B) circle J`.
Deleting all of `B` leaves `J` and `|A|` isolates, so

\[
 f(G)\ge |A|+f(J).
\]

Every induced matching of size at least two lies entirely in `J`. Indeed,
any edge not lying in `J` has an endpoint in `B`; that endpoint is adjacent
to every vertex of `J` and every other vertex of `B`. It therefore conflicts
with every other possible matching edge. Since `J` has an edge,

\[
 \operatorname{im}(G)=\operatorname{im}(J).
\]

Together with credited residue additivity, these inequalities give

\[
 f(G)\ge |A|+r(J)+\operatorname{im}(J)
       =r(G)+\operatorname{im}(G).
\]

If `J` is edgeless, the composition is itself split, so it is handled below.
Repeated composition follows by induction.

## Split graphs

An edgeless graph has `f=r=|V|` and `im=0`. A split graph with an edge has
`im=1`, since every edge meets its clique part. Adjoining any vertex outside
a maximum independent set gives an induced star and isolates, so

\[
 f\ge\alpha+1=r+1=r+\operatorname{im}.
\]

This uses the established split-graph residue equality, not a new equality
classification.

## The nonsplit indecomposable cores

### Five-cycle

For `C5`, the values are `r=2`, `im=1`, and `f=4`, so (C) holds.

### Matching and matching plus a star

For `mK2`, the values are `(f,r,im)=(2m,m,m)`.
For `mK2 disjoint union K1,n`, they are

\[
 (f,r,\operatorname{im})=(2m+n+1,m+n,m+1).
\]

Both give equality in (C); the residue values follow immediately by
removing the star head and then the remaining degree-one pairs.

### Complements of those star forests

The complement of either preceding nonsplit forest has independence two.
It has no induced `2K2`, because the original forest has no four-cycle, so
its induced matching number is one. Its residue is two: `r<=alpha=2`, and
a noncomplete graph cannot have residue one (proved below). Since it has
an edge, `f>=alpha+1=3`, proving (C).

For reference, residue one characterizes complete graphs. Induct on the
order. If a nonzero first HH head `d` leaves residue one, the residual list
is the complete-graph list by induction. If `d<n-1`, a decremented tail
entry originally had value `n-1>d`, contradicting maximality of the head.
Thus `d=n-1` and every original degree is `n-1`. The edgeless and one-vertex
cases are immediate.

### The graph U_m

Its order is `2m+4`, and its degree list is

\[
 (2m+2,2^{\,2m+3}).
\]

Removing the first head leaves `(2,1^{2m+2})`, the list of `mK2` and `P3`.
Hence `r(U_m)=m+2`. Deleting the common cycle vertex leaves that forest on
`2m+3` vertices; since the original graph has a cycle, this is maximum:

\[
 f(U_m)=2m+3.
\]

An induced matching avoiding the common vertex can choose one edge in each
triangle and one in the remaining three-vertex path, giving `m+1` edges.
No larger induced matching is possible: if the common vertex is used,
its only nonneighbor is the opposite four-cycle vertex, so no second edge
can coexist; if it is avoided, the remaining components are `mK2` and `P3`.
Thus `im(U_m)=m+1`, and (C) is equality.

### The complement of U_m

Its degree list is

\[
 ( (2m+1)^{\,2m+3},1).
\]

Two HH steps turn it into

\[
 ((2m-1)^{\,2m+1},1),
\]

the same list with parameter `m-1`. At `m=0` the list is `1^4`, of residue
two. Therefore `r(U_m^c)=2` for all `m>=1`.

The four-cycle vertices of `U_m` induce a `2K2` in its complement, so the
complement has both an induced matching of size two and an induced forest
of order four. It cannot have an induced matching of size three: the same
six vertices would induce minimum degree four in `U_m`, but every vertex
of `U_m` except its common vertex has total degree two. Therefore

\[
 \operatorname{im}(U_m^c)=2,\qquad f(U_m^c)\ge4
 =r(U_m^c)+\operatorname{im}(U_m^c).
\]

## Completion and research boundary

The credited classification lists all indecomposable nonsplit unigraph
cores, and every listed core has now been handled. Split cores were handled
separately. Split-composition inheritance completes the theorem for every
unigraph, and for every arbitrary split extension of a unigraph.

No inference that all graphs, or all tight `2K2`-free cores, lie in this
class is made. The remaining arbitrary-graph candidate and original #61
are still unproved here. Prior publication of this particular subclass
inequality has not yet been excluded; all classification and residue
additivity inputs are explicitly credited above.
