# Related triangle-distinct graph literature

A later targeted source check identified relevant prior neighborhood-counting work. This does not change the proved inequalities or turn any partial result into a full WOWII closure.

Hak, Kozerenko and Serdiuk, *There is no 8-regular K3-irregular graph*, arXiv:2609.37978v3 (20 October2026), Section2.4, Lemma2.5, uses nearly complete neighborhoods, vertices untouched by missing edges, distinct external-neighbor counts, and an edge-budget contradiction. This is an important antecedent for further external-incidence refinements; that mechanism must not be advertised as newly invented here. Their stated setting is regular graphs. The present rank/2-domination applications have different hypotheses and conclusions; we do not claim the source directly proves these WOWII partial results.

Primary full text: https://arxiv.org/html/2609.37978v3

Stevanovic et al., *Searching for regular, triangle-distinct graphs*, arXiv:2401.10971v1 (2024), reports a smallest triangle-distinct graph of order7 and millions of examples by order11. Thus triangle-distinctness alone is not an impossibility argument for our remaining high cores. Positive triangle counts and the permitted attachment offsets still require separate analysis.

Primary full text: https://arxiv.org/html/2401.10971v1

These sources are credited as related literature. Neither an absence-of-prior-art certificate nor worldwide novelty is asserted. The independent proofs and exact arithmetic in this round do not depend on accepting the sources' large computational classification results.
