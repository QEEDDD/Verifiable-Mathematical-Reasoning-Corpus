# Independent audit: original155 when the maximum spanning-tree leaf number is at most three

**Verdict: PASS — arbitrary-order subclass theorem, not full original155.**

For a nontrivial connected simple graph, let L be the maximum number of degree-one vertices in a spanning tree, and let q count the distinct radial-circle orders over **all center vertices**. The proof establishes L=2 => q=1 and L=3 => q<=2, hence L>=1+q throughout L<=3. No claim for L>=4 or the general missing-order proposal is established.

Reviewed `round_16/leaves/155_at_most_three_leaves.md/.tex`, the exact source row, and the targeted family verifier. Final reviewed hashes: Markdown `0a756f35a378b6fa23789d895e08bf484c613c56da18a5846c15e9e6d985282e`; TeX `93bfafbf3cc1e058ffd34aa0d7d60362fd94255e022f0b128c76c407aef9832b`. No proof correction was required.

## Original statement and conventions

The pinned row155 is exactly `L_s(G) >= 1 + number of distinct orders of radial circles`, with definition references1 and81. Definition1 maximizes leaves over spanning trees. Definition81 specifies a radial circle centered at a center vertex, containing vertices at the graph radius from that vertex. Thus q is neither the number of centers nor a count over all graph vertices. There is no division by a minimum radial order; that belongs to154, not155. The source row and the already source-locked original definitions are included in the audit packet. The theorem explicitly works with nontrivial connected graphs, so the exceptional order-one convention is not being silently used.

## Full-star criterion

A vertex of degree at least four has a full incident star extending to a spanning tree; a tree with a degree-at-least-four vertex has at least four leaves. Hence L<=3 implies maximum degree at most three.

In a subcubic graph, the union of the full incident stars of two degree-three vertices extends to a spanning tree if it is a forest. Both centers then retain degree three, so the tree leaf identity gives at least four leaves. Conversely a subcubic spanning tree with at least four leaves has two degree-three vertices. Their tree stars are their entire graph stars because their graph degrees are also three, and their union is a forest. Thus the criterion is an equivalence, not just a necessary local condition.

For adjacent centers, a cycle in their two-star union exists exactly when they have a common neighbor. For nonadjacent centers, it exists exactly when they have at least two common neighbors. This proves the stated local form, including the possibility of chorded cycles in the union. No induced-cycle assumption is needed.

## Exhaustiveness of the degree-three-core classification

Let B be the degree-three vertices. If B is independent, the three neighbors of any fixed member all have degree at most two and provide at most three remaining incidences into B. Each additional B vertex needs two such incidences, so |B|<=2.

If |B|>=3, choose an adjacent B pair a,b. A common neighbor either is already in B or is a saturated degree-two vertex. In the latter case a third B vertex cannot avoid both a,b: it would share at most one neighbor with a. Once it meets a, the required common neighbor with a must be b, since the degree-two common neighbor is saturated. Therefore B contains a triangle.

Every additional B vertex must meet that triangle; otherwise it shares at most one neighbor with a triangle vertex. Meeting one triangle vertex forces it to meet another, consuming at least two of the triangle's three free incidences. Thus there is at most one additional B vertex, giving |B|<=4.

Outside B every component is a path, except the whole-cycle case when B is empty. It cannot be a disjoint cycle when B is nonempty because of connectedness. Its ends either consume free B incidences or are graph leaves. Pairing these incidences gives exactly the listed families: one branch vertex yields a three-arm tree or one-tailed cycle; two adjacent branch vertices yield a triangle with two tails or theta(1,2,l); two nonadjacent ones yield opposite tails on C4 or theta(2,2,l); three form a triangle with three tails or theta(1,2,l) with a tail at the short-path internal vertex; four yield K4, a subdivision of one K4 edge, or a diamond with opposite tails. Path lengths are at least two where a direct existing edge would otherwise be duplicated. No outside components or alternative incidence pairings are omitted.

## Eccentricity and radial-order calculations

All formulas in Sections4–9 were checked directly, including boundary equalities and shortest parameter values.

* Paths/cycles give q=1. A tree has at most two centers, so every three-leaf tree gives q<=2.
* For a cycle with one tail, cycle eccentricity is max(s,d(x,c)+t) and tail eccentricity is max(t−j,s+j). When t>s, centers lie along the tail and there are at most two. Otherwise only central cycle vertices occur, each with its usual one/two cycle antipodes and possibly the tail endpoint, giving only two possible orders.
* For a triangle with tail lengths A>=B>=C and at least two positive lengths, the core eccentricities are max(A,B+1),A+1,A+1. Equal largest lengths give only core centers with one or two farthest endpoints. Unequal largest lengths put the center on the longest tail, where max(A−j,B+1+j) has at most two minimizing vertices. The no-tail third vertex is correctly included by C=0.
* For opposite tails on C4 or a diamond, the same core eccentricities hold in both graphs. If A=B only the two other core vertices are central. If A=B+1, exactly three core vertices are central, each with a unique farthest tail endpoint; this special case correctly gives q=1 despite having three centers. If A>=B+2, the center lies on the longer tail and has at most two vertices.
* For theta(1,2,l) with optional tail t, the long cycle has length m=l+1, radius s=floor(m/2), and distances within it are unchanged by the short extra path and tail. The contact distance function is 1+min(distance to either endpoint). Its multiplicities are two copies of1…s for even m, and two copies of1…s plus one s+1 for odd m. The eccentricity formulas in the note follow. The parity cases correctly handle t=0, t=s and t=s+1. In particular the even t=s case has one center and radial order3, while the odd t=s case has three centers but every radial order1. The shortest odd-cycle case m=3 is valid.
* For theta(2,2,l), the second short-path internal vertex duplicates a cycle vertex's two neighbors. Adding the edge between these duplicates gives precisely a K4 graph with one edge subdivided. Neither operation shortens distances within the original cycle, whose length is at least four. All vertices have the same eccentricity s>=2. Each original antipodal count can gain only the duplicate as one additional farthest vertex, including the mutual-distance=s boundary. Thus all radial orders lie in {f,f+1}. Unsubdivided K4 is correctly handled separately.

These are arbitrary-length formulas, not conclusions inferred from a bounded test. Every classified L=3 family has q<=2, completing the theorem without an external classification dependency.

## Independent finite verification

`check_independent.py` does not import the author's family constructors or BFS code. It processes all12,112 connected graph representatives of orders2…8 (the seven/eight-vertex masks come from the separately audited complete permutation coverage). Of these,306 are subcubic; the other11,806 have a degree-at-least-four star witness and cannot lie in the target class. For each subcubic graph the checker directly enumerates edge sets of size n−1, tests whether they are spanning trees, and counts their leaves. It stops early only after finding at least four leaves; every L<=3 result is obtained by exhausting the spanning-tree candidates. It examines4,963 edge sets and independently confirms the full-star equivalence. There are13 L=2 and68 L=3 graphs, all satisfying the claimed q bounds by fresh BFS. The number of degree-three vertices is at most four in every accepted graph.

It additionally builds5,528 fresh arbitrary-length family instances, up to order72:840 cycle-tail graphs,1,750 triangle-tail graphs,465 C4/opposite-tail graphs,465 diamond-tail graphs,1,209 theta(1,2,l)-tail graphs,59 theta(2,2,l),59 subdivided K4,680 three-arm trees and K4. All radial-order conclusions pass; the principal eccentricity formulas are directly compared to BFS values. This expands rather than merely reruns the author's957 theta instances. The author routines were also independently rerun and compared with their stored profiles without modifying the frozen source output.

Reproduction from workspace root:
```
PYTHONPATH=/tmp/wowii_deps python wowii_rounds/round_17/independent_audit/155_low_leaves/check_independent.py
```

The finite checks are diagnostics. The theorem's arbitrary-order validity rests on the complete incidence classification and exact distance analysis above.

## Final scope

**PASS nontrivial connected graphs with L<=3; no full155 closure.** The source definition is correctly distinguished from154. No global priority, general missing-order lemma, or L>=4 extension is certified. Root owns later Round17 consolidation, PDF rendering and visual QA.
