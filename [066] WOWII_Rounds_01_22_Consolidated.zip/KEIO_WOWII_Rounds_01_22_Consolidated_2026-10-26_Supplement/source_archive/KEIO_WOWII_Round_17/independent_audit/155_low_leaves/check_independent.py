"""Independent spanning-tree enumeration and fresh BFS family controls."""
from itertools import combinations,combinations_with_replacement
from collections import Counter
from pathlib import Path
import json
import networkx as nx

def frommask(n,m):
 A=[set() for _ in range(n)]
 for j,(u,v) in enumerate(combinations(range(n),2)):
  if m>>j&1:A[u].add(v);A[v].add(u)
 return A
def connected(A):
 seen={0};Q=[0]
 for v in Q:
  for w in A[v]:
   if w not in seen:seen.add(w);Q.append(w)
 return len(seen)==len(A)
def profile(A):
 dist=[]
 for root in range(len(A)):
  D={root:0};Q=[root]
  for v in Q:
   for w in A[v]:
    if w not in D:D[w]=D[v]+1;Q.append(w)
  assert len(D)==len(A);dist.append(D)
 ecc=[max(D.values()) for D in dist];r=min(ecc);center=[v for v,e in enumerate(ecc) if e==r]
 R={v:sum(d==r for d in dist[v].values()) for v in center}
 return r,center,R,dist,ecc
def stars(A):
 B=[v for v in range(len(A)) if len(A[v])==3]
 return all(len(A[x]&A[y])>=(1 if y in A[x] else 2) for x,y in combinations(B,2))

def leaves_capped(A):
 n=len(A);E=[(u,v) for u in range(n) for v in A[u] if u<v];best=0;trials=0
 for T in combinations(E,n-1):
  parent=list(range(n));deg=[0]*n
  def root(x):
   while x!=parent[x]:x=parent[x]
   return x
  good=True
  for u,v in T:
   x,y=root(u),root(v)
   if x==y:good=False;break
   parent[x]=y;deg[u]+=1;deg[v]+=1
  trials+=1
  if good:
   best=max(best,deg.count(1))
   if best>=4:return best,trials
 return best,trials
counts=Counter();tree_trials=0;accepted=Counter();examples={}
for n in range(2,9):
 if n<=6:graphs=[[set(G[v]) for v in range(n)] for G in nx.graph_atlas_g() if len(G)==n]
 else:graphs=[frommask(n,m) for m in map(int,Path(f'wowii_rounds/round_11/twodomination/core{n}_masks.txt').read_text().split())]
 for A in graphs:
  if not connected(A):continue
  counts['connected_graphs']+=1
  if max(map(len,A))>3:counts['degree_at_least_four']+=1;continue
  counts['subcubic_graphs']+=1;L,trials=leaves_capped(A);tree_trials+=trials
  assert (L<=3)==stars(A)
  if L<=3:
   accepted[L]+=1;r,C,R,_,_=profile(A);q=len(set(R.values()))
   assert (L==2 and q==1) or (L==3 and q<=2)
   assert sum(len(x)==3 for x in A)<=4
   examples.setdefault((L,q),(n,r,sorted(R.values())))

def edge(A,u,v):A[u].add(v);A[v].add(u)
def path(A,u,length,v=None):
 # Append length edges from u; v is an existing terminal when specified.
 vertices=[u]
 for j in range(length):
  w=v if v is not None and j==length-1 else len(A)
  if w==len(A):A.append(set())
  edge(A,vertices[-1],w);vertices.append(w)
 return vertices

def cycle(n):
 A=[set() for _ in range(n)]
 for i in range(n):edge(A,i,(i+1)%n)
 return A
family_counts=Counter();max_order=0

def check(A,kind):
 global max_order
 assert max(map(len,A))<=3 and stars(A)
 r,C,R,D,ecc=profile(A);assert len(set(R.values()))<=2
 family_counts[kind]+=1;max_order=max(max_order,len(A))
 return r,C,R,D,ecc
# Cycle with one tail, all attachment lengths and both parities.
for m in range(3,31):
 for t in range(1,31):
  A=cycle(m);tail=path(A,0,t);r,C,R,D,e=check(A,'cycle_tail');s=m//2
  for x in range(m):assert e[x]==max(s,min(x,m-x)+t)
  for j,x in enumerate(tail):assert e[x]==max(t-j,s+j)
# Triangle with two or three tails, sorted lengths and zero third tail.
for aa in range(1,21):
 for bb in range(1,aa+1):
  for cc in range(bb+1):
   A=cycle(3);tails=[path(A,i,t) for i,t in enumerate((aa,bb,cc))]
   r,C,R,D,e=check(A,'triangle_tails')
   assert [e[i] for i in range(3)]==[max(aa,bb+1),aa+1,aa+1]
# Opposite tails on C4, with optional diamond edge.
for aa in range(1,31):
 for bb in range(1,aa+1):
  for diamond in (False,True):
   A=cycle(4)
   if diamond:edge(A,1,3)
   left=path(A,0,aa);right=path(A,2,bb);r,C,R,D,e=check(A,'diamond_tails' if diamond else 'C4_tails')
   assert [e[i] for i in range(4)]==[max(aa,bb+2),aa+1,aa+2,aa+1]
# Theta(1,2,l) and a tail at the length-two internal vertex.
for ell in range(2,41):
 for t in range(31):
  A=[set(),set()];path(A,0,1,1);short=path(A,0,2,1);long=path(A,0,ell,1);c=short[1];tail=path(A,c,t)
  r,C,R,D,e=check(A,'theta12_tail');Q=set(long);s=(ell+1)//2
  hs={x:1+min(D[x][0],D[x][1]) for x in Q};H=max(hs.values())
  for x in Q:assert e[x]==max(s,hs[x]+t)
  for j,x in enumerate(tail):assert e[x]==max(t-j,H+j)
# Theta(2,2,l), optionally adding the edge between length-two internal vertices.
for ell in range(2,61):
 for extra in (False,True):
  A=[set(),set()];p=path(A,0,2,1);q=path(A,0,2,1);path(A,0,ell,1)
  if extra:edge(A,p[1],q[1])
  r,C,R,D,e=check(A,'subdivided_K4' if extra else 'theta22')
  assert r==(ell+2)//2 and len(C)==len(A)
# Arbitrary three-arm trees.
for arms in combinations_with_replacement(range(1,16),3):
 A=[set()]
 for t in arms:path(A,0,t)
 r,C,R,D,e=check(A,'three_arm_tree');assert len(C)<=2
A=[set(range(4))-{i} for i in range(4)];check(A,'K4')
print(json.dumps({'status':'PASS','small_graph_counts':dict(counts),'spanning_tree_edge_sets_examined':tree_trials,'small_graphs_with_L2_or_L3':dict(accepted),'small_q_examples':{str(k):v for k,v in examples.items()},'fresh_family_counts':dict(family_counts),'fresh_family_total':sum(family_counts.values()),'maximum_family_order':max_order,'scope':'Exact small spanning-tree and BFS controls; universal theorem is the analytic classification and distance formulas.'},indent=2))
