# WOWII #155 for graphs whose maximum spanning-tree leaf number is at most three

**Status: proved subclass only; not a full resolution of #155.** The proof is structural and applies to graphs of arbitrary order. The accompanying bounded family calculations are diagnostic checks, not the proof.

## 1. Statement and conventions

For a nontrivial simple connected graph G, let L(G) be the maximum number of leaves in a spanning tree. Let r=rad(G), let C be its full center, and for v in C put

\[
R(v)=|\{x:d(v,x)=r\}|,\qquad q(G)=|\{R(v):v\in C\}|.
\]

The pinned original WOWII #155 states **L(G)>=1+q(G)**. There is no division by a minimum radial-circle order in #155; that quotient belongs to #154. The exact row is in `source_row155.json` and the [pinned source archive](https://gitlab.com/ai-village-agents/village/graffiti-verification/-/blob/3be380b4222f974bedbefb228c8e75fbd9a7b3ae/data/wow2_rows_html.json).

**Theorem.** If L(G)<=3, then #155 holds. More precisely, L(G)=2 implies q(G)=1, and L(G)=3 implies q(G)<=2.

## 2. A full-star criterion

If G has maximum degree at most three, the following are equivalent:

1. L(G)<=3.
2. For every two distinct degree-three vertices x,y, the union of their full incident-edge stars contains a cycle.
3. Every adjacent pair of degree-three vertices has a common neighbor, and every nonadjacent pair has at least two common neighbors.

Indeed, every forest in a connected graph extends to a spanning tree. If the two full stars form a forest, such an extension retains degree three at both x and y. A subcubic tree has precisely two more leaves than degree-three vertices, so this gives at least four leaves. Conversely any spanning tree with at least four leaves has two degree-three vertices, and its edge set contains their full stars, which therefore form a forest. Finally, two adjacent stars contain a cycle exactly when their centers have a common neighbor; two nonadjacent stars contain a cycle exactly when they have at least two common neighbors.

If L(G)<=3, then Delta(G)<=3: a vertex of degree at least four has an incident star that extends to a spanning tree, which has at least four leaves.

## 3. Classification needed here

Let B be the set of degree-three vertices. If B is empty, G is a path or a cycle.

We first show |B|<=4. If B is independent, fix x in B. Its three neighbors have degree at most two, and so together can have at most three edges to B−{x}. Each further vertex of B must use at least two of these edges by the full-star criterion. Hence |B|<=2.

Suppose |B|>=3. There is an edge ab with a,b in B. They have a common neighbor c. If c belongs to B, we have a triangle in B. Otherwise c has degree two and its neighbors are exactly a,b. A third vertex z in B cannot be nonadjacent to both a and b: to have two common neighbors with a, it would have to be adjacent to at least one of b,c, which is impossible under that assumption. Thus, say, z is adjacent to a. The adjacent pair a,z needs a common neighbor; among the other neighbors b,c of a, only b can be adjacent to z because c is already saturated. Therefore a,b,z form a triangle in B.

Fix a triangle a,b,c in B. Any additional vertex z in B must be adjacent to at least one of a,b,c: otherwise it could share at most the one remaining neighbor of a with a. If z is adjacent to a, the adjacent-star condition makes z adjacent to b or c as well. Thus each additional vertex consumes at least two of the three free incident edges of the triangle. There is at most one such vertex, proving |B|<=4.

Every component outside B is a path, unless B is empty and G is a cycle. Its ends attach to free incidences at vertices of B or are leaves. It follows that the following list is exhaustive (a tail is a positive-length pendant path):

- |B|=1: a three-leaf tree, or a cycle with one tail.
- |B|=2, with the vertices adjacent: a triangle with tails at two vertices, or a theta graph with path lengths 1,2,l, l>=2.
- |B|=2, with the vertices nonadjacent: a four-cycle with tails at opposite vertices, or a theta graph with path lengths 2,2,l, l>=2. The case of three common neighbors is l=2.
- |B|=3: a triangle with three tails, or a theta graph of path lengths 1,2,l, l>=2, with a tail at the internal vertex of the length-two path.
- |B|=4: K4; a subdivision of exactly one edge of K4; or a diamond K4−e with tails at its two degree-two vertices.

For the last assertion, the fourth vertex is adjacent to two or three vertices of the triangle. Three gives K4. Two gives a diamond; the two remaining free incidences are either joined by a path or terminate in separate tails. For |B|=3 the three free incidences are either all tails, or two are paired by a path and the third is a tail. The |B|=2 descriptions follow immediately by using the one or two common neighbors required by the star criterion. This derivation is self-contained; no classification theorem from the literature is assumed.

## 4. Paths, cycles and trees

If L=2, the graph is a path or cycle. A cycle is vertex-transitive, so all radial circles have the same order. A path has one or two centers, and their radial-circle orders coincide (two for a unique center, one at each of two centers). Thus q=1.

A tree has at most two centers, namely the one or two middle vertices of a diametral path. Hence any three-leaf tree has q<=2.

## 5. A cycle with one tail

Let the cycle have length m, put s=floor(m/2), and let the tail have length t>=1, attached at c. For a cycle vertex x,

\[
\operatorname{ecc}(x)=\max\{s,d_{C_m}(x,c)+t\}.
\]

At distance j along the tail from c, eccentricity is max{t−j,s+j}. If t>s, the center lies on this tail, and minimizing this maximum of two opposite affine functions gives at most two centers. If t<=s, the radius is s, no positive-depth tail vertex is central, and the cycle centers satisfy d(x,c)<=s−t.

A cycle has f=1 farthest vertices from each vertex when m is even and f=2 when m is odd. At a central cycle vertex, the only possible additional farthest vertex is the tail endpoint, and it contributes exactly when d(x,c)+t=s. Thus all radial orders lie in {f,f+1}. In either case q<=2.

## 6. A triangle with two or three tails

Allow tail lengths A>=B>=C>=0 at the triangle vertices a,b,c; a zero length means that no tail is attached. The cases in the classification have at least two positive lengths. The eccentricity at a is max{A,B+1}; the other two triangle vertices have eccentricity A+1.

If A=B, all three triangle vertices are central with radius A+1, and no positive-depth tail vertex is central. A radial circle comprises the endpoints of maximum-length tails attached at other triangle vertices. Its order is one or two, so q<=2.

If A>B, a has eccentricity at most A, while every vertex outside a's tail has eccentricity at least A+1. Thus the center is restricted to a's tail, including a. At depth j its eccentricity is max{A−j,B+1+j}, which is minimized at at most two consecutive vertices. Again q<=2.

## 7. A four-cycle or diamond with opposite tails

Let the attachment vertices c,d have tail lengths A>=B>=1. They are the nonadjacent corners of a four-cycle; its other corners a,b may or may not be joined by the diamond edge. In both cases

\[
\operatorname{ecc}(c)=\max\{A,B+2\},\quad
\operatorname{ecc}(d)=A+2,\quad
\operatorname{ecc}(a)=\operatorname{ecc}(b)=A+1.
\]

- If A=B, the center is exactly {a,b}; hence q<=2.
- If A=B+1, the center is exactly {a,b,c}. Its radius is A+1>=3. Each of a,b has the unique farthest vertex at the end of the A-tail, and c has the unique farthest vertex at the end of the B-tail. Thus every radial order is one.
- If A>=B+2, the center is restricted to c's tail, including c; the eccentricity there is max{A−j,B+2+j}. There are at most two centers.

The asserted exclusions of other centers also follow directly from these formulas: a positive-depth vertex on a tail reaches the endpoint of the opposite tail through a length-two core path. Thus q<=2 in every case.

## 8. Theta(1,2,l), with an optional tail

Let the theta endpoints be a,b, the length-two path be a-c-b, and the third path have length l>=2. Allow a tail of length t>=0 attached at c. The direct edge ab and the long path form a cycle Q of length m=l+1. Distances between vertices of Q are unchanged by c and its tail.

Put s=floor(m/2), and for x in Q define h(x)=d(x,c)=1+min{d_Q(x,a),d_Q(x,b)}. Then

\[
\operatorname{ecc}(x)=\max\{s,h(x)+t\}.
\tag{1}
\]

At depth j from c on its tail (including j=0), eccentricity is

\[
\max\{t-j,H+j\},\qquad H=\max_{x\in Q}h(x).
\tag{2}
\]

### Even m=2s

Here h takes every value 1,...,s exactly twice, and H=s.

- If t<s, the radius is s. The centers are c and the cycle vertices with h(x)<=s−t. A central cycle vertex has its one cycle antipode, with the tail endpoint as one additional farthest vertex exactly when h(x)+t=s. The vertex c has its two farthest cycle vertices. Thus all radial orders are in {1,2}.
- If t=s, c is the sole center; its radial order is three (two cycle vertices and the tail endpoint).
- If t>s, all cycle vertices have eccentricity at least t+1, while c has eccentricity t. Hence the center lies on the tail and (2) gives at most two centers.

### Odd m=2s+1

Here h takes each value 1,...,s twice and the value s+1 once, so H=s+1.

- If t<s, the radius is s and the centers are exactly the cycle vertices with h(x)<=s−t. Every central cycle vertex has its two cycle antipodes, plus the tail endpoint exactly when h(x)+t=s. Thus all radial orders lie in {2,3}.
- If t=s, the center is exactly {a,b,c}, of radius s+1. The vertices a,b each have the tail endpoint as their unique farthest vertex. The vertex c has the unique cycle vertex with h=s+1 as its unique farthest vertex. All radial orders are one.
- If t>=s+1, every cycle vertex has eccentricity at least t+1, whereas c has eccentricity t. Formula (2) restricts the center to at most two tail vertices.

These cases include t=0, the theta graph without a tail. In all cases q<=2.

## 9. Theta(2,2,l), and a single subdivided edge of K4

For l>=2, form a cycle Q from the long path and one length-two path. It has length m=l+2>=4; let c be the internal vertex of its length-two path. The other length-two path introduces a vertex d with the same neighbors as c. Optionally add the edge cd. Without that edge this is theta(2,2,l); with it this is K4 with one edge subdivided.

Distances within Q are unchanged. For x in Q−{c}, the distance d(x,d) equals d_Q(x,c), regardless of whether cd is present. The distance between c and d is two without the edge and one with it. Put s=floor(m/2)>=2. Every vertex has eccentricity s, so the graph is self-centered.

Each vertex of Q has f cycle antipodes, where f=1 for even m and f=2 for odd m. A vertex other than c gains d as a farthest vertex only when its distance to c is s. The vertices c,d likewise have either f or f+1 farthest vertices, according as their mutual distance equals s. Thus all radial orders lie in {f,f+1}, and q<=2. The unsubdivided K4 is the remaining exceptional case; all its radial circles have order three.

## 10. Conclusion and limitations

The classification is exhaustive, and every L=3 family has q<=2. Consequently

\[
L(G)=3\ge1+q(G).
\]

For L=2, q=1 gives equality. This proves the theorem for every nontrivial connected graph with maximum spanning-tree leaf number at most three.

This is not a proof of the proposed general missing-order lemma, nor a full resolution of WOWII #155. No extension to L>=4 is claimed. A targeted diagnostic (`probe_L3_families.py`, `L3_family_profiles.json`) checked957 instances of the theta families and agrees with the formulas; the arbitrary-order proof is the classification and the exact eccentricity calculations above.
