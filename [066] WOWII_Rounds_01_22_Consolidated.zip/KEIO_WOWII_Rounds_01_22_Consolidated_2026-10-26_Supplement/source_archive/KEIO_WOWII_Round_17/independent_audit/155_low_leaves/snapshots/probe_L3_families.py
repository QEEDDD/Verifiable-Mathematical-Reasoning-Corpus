import sys,json
sys.path.insert(0,'wowii_rounds/pydeps')
import networkx as nx

def theta(lengths,tail=0,cross=False):
 G=nx.Graph();G.add_nodes_from([0,1]);j=2;paths=[]
 for l in lengths:
  p=[0]+list(range(j,j+l-1))+[1];j+=l-1;G.add_edges_from(zip(p,p[1:]));paths.append(p)
 if tail:
  x=paths[1][1];p=[x]+list(range(j,j+tail));G.add_edges_from(zip(p,p[1:]));j+=tail
 if cross:G.add_edge(paths[0][1],paths[1][1])
 return G

def profile(G):
 D=dict(nx.all_pairs_shortest_path_length(G));ecc={v:max(d.values())for v,d in D.items()};r=min(ecc.values());C=[v for v in G if ecc[v]==r];return dict(n=len(G),r=r,C=C,orders={v:sum(z==r for z in D[v].values())for v in C},distinct=sorted({sum(z==r for z in D[v].values())for v in C}))
if __name__=='__main__':
 out=[]
 for l in range(2,31):
  for tail in range(31):
   G=theta([1,2,l],tail);p=profile(G);out.append(dict(family='theta_1_2_l_tail',l=l,tail=tail,**p))
   if len(p['distinct'])>2:print('THREE',out[-1],flush=True)
  for cross in [False,True]:
   G=theta([2,2,l],cross=cross);p=profile(G);out.append(dict(family='theta_2_2_l_cross'if cross else'theta_2_2_l',l=l,**p))
   if len(p['distinct'])>2:print('THREE',out[-1],flush=True)
 json.dump(out,open('wowii_rounds/round_16/leaves/L3_family_profiles.json','w'),indent=2)
 print('tested',len(out),'profiles',sorted({tuple(d['distinct'])for d in out}))
