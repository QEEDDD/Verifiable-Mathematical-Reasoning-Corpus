# Independent audit: small maximum columns in split WOWII 199

**Verdict: PASS, scoped arbitrary-order reduction.** Under the original hypothesis `tree(G) <= κ(G)+2`, a connected noncomplete split graph is traceable whenever `k=κ(G)>=2` and `k>=2m-2`, where m is the largest independent-side column in a split partition with maximum independent side. This is not a full closure of original 199.

## Proof review

The original row and definitions, the maximum-independent split partition, the equality `κ=min independent-side degree`, and the induced-double-star restriction are independently checked and pinned in the sibling κ=2/κ=3 audits. No additional classification theorem is needed here.

For a largest column A and any column B, the identity
`2|B\A|=|B△A|+|B|-|A|`
indeed gives at most `r=floor(k/2)` outside neighbors per clique vertex. Thus each subset J of outside independent vertices sends at least k|J| incidences to its neighborhood, which receives at most r per vertex. The resulting neighborhood bound ≥2|J| implies Hall's condition on two copies of each outside vertex: an arbitrary subset of copies has at most twice as many vertices as its set of underlying outside vertices. Distinct clique representatives therefore exist for all copies. The resulting C–I–C paths are disjoint, all other clique vertices are singleton components, and the chosen maximum-column vertex c₀ is necessarily a singleton because it has no outside neighbor.

The endpoint count has been checked including all degeneracies. Initially every clique vertex is an endpoint. Joining c₀'s singleton to another component through the first core vertex makes at most one clique vertex internal (zero if the other component is also a singleton). The path remains clique-ended. Every subsequent join between two different clique-ended components makes at most two former endpoint vertices internal. Hence, after t inserted core vertices, at most 2t−1 clique vertices are internal.

For `1<=t<=m-2`, the next core vertex has at least `k-(2t-1)>=3` endpoint **vertices** among its neighbors. Each component has at most two distinct endpoint vertices; a singleton has one, not two. Two eligible neighbors therefore belong to different components and can be joined without creating a cycle. After m−1 insertions, the final core vertex has at least `k-(2m-3)>=1` endpoint neighbor. Appending it leaves one independent endpoint and one clique endpoint. All remaining clique-ended components can then concatenate at the clique endpoint via clique edges. No arbitrary linear/cycle-factor patching is asserted.

The m=2 intermediate loop is empty and the final endpoint bound remains valid. The m=1 case has disjoint independent-neighbor groups with at least two vertices each, so direct three-vertex-path concatenation works. The proof also allows an empty outside set. It needs only the displayed parameter bounds, not a hidden assumption that every clique vertex has a neighbor in every outside group.

Failure of `k>=2m-2` means the integer bound `m>=floor((k+2)/2)+1`. Combining this with the separately audited low-connectivity arguments gives the stated necessary conditions for a split counterexample: κ≥4 and the displayed large-column condition. Neither condition proves that such counterexamples exist or excludes all of them.

## Computation and source treatment

`check_independent.py` independently implements the doubled assignment as a network maximum-flow problem, then constructs paths using randomized component orientations and endpoint choices. It does not import the author's augmenter or merge code. Fresh seeded incidence and even/odd boundary families are checked with explicit final vertex/edge validation. Exact counts are in `independent_results.json`; this is supplemental finite evidence, not the universal proof.

The author's 1,708 constructive certificates were rerun on a snapshot, leaving its frozen files unchanged, and matched every stored non-runtime field. Hall's theorem and the graph connectivity facts are classical tools; no novelty claim is made for them or for this subclass result. The parent's source-priority gate remains separate.

### Final fresh control counts

All 2,014 independently constructed maximum-flow/endpoint-merge paths passed, with maximum order 409. The incidence and boundary grammars, random seed, and parameter breakdown are preserved in the script and JSON.
