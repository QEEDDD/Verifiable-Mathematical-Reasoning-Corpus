"""Fresh max-flow pairing and endpoint-merge construction; no author import."""
from pathlib import Path
from itertools import combinations
from collections import Counter
import random,json
import networkx as nx
rng=random.Random(1202617199);counts=Counter();total=0;maximum_order=0

def run(cols,h,k):
 global total,maximum_order
 q=len(cols);rows=[{c for c,T in enumerate(cols) if i in T} for i in range(h)];m=max(map(len,cols))
 assert k>=2 and min(map(len,rows))>=k and k>=2*m-2
 assert all(cols) and all(len(a^b)<=k for a,b in combinations(cols,2))
 c0=rng.choice([c for c,T in enumerate(cols) if len(T)==m]);core=list(cols[c0]);rng.shuffle(core);outside=set(range(h))-set(core)
 # Independent unit-capacity network flow implementation of the doubled Hall assignment.
 flow=nx.DiGraph();source=('s',);sink=('t',)
 flow.add_nodes_from([source,sink])
 for x in outside:
  flow.add_edge(source,('i',x),capacity=2)
  for c in rows[x]:flow.add_edge(('i',x),('c',c),capacity=1)
 for c in range(q):flow.add_edge(('c',c),sink,capacity=1)
 value,F=nx.maximum_flow(flow,source,sink)
 assert value==2*len(outside)
 components=[];used=set()
 for x in outside:
  pair=[v[1] for v,f in F[('i',x)].items() if f and v[0]=='c'];assert len(pair)==2
  assert not used.intersection(pair);used.update(pair);components.append([pair[0],q+x,pair[1]])
 components.extend([[c] for c in range(q) if c not in used]);assert [c0] in components
 def join(a,p,r):
  i=next(i for i,P in enumerate(components) if p in (P[0],P[-1]));j=next(j for j,P in enumerate(components) if r in (P[0],P[-1]));assert i!=j
  P=components[i];Q=components[j]
  if P[-1]!=p:P=P[::-1]
  if Q[0]!=r:Q=Q[::-1]
  components[:]=[R for l,R in enumerate(components) if l not in (i,j)]+[P+[q+a]+Q]
 if m>1:
  join(core[0],c0,max(rows[core[0]]-{c0}))
  for t,a in enumerate(core[1:-1],1):
   internal={v for P in components for v in P[1:-1] if v<q};assert len(internal)<=2*t-1
   avail=[(i,v) for i,P in enumerate(components) for v in set((P[0],P[-1])) if v in rows[a]]
   assert len(avail)>=3
   i,p,j,r=rng.choice([(i,p,j,r) for (i,p),(j,r) in combinations(avail,2) if i!=j]);join(a,p,r)
 internal={v for P in components for v in P[1:-1] if v<q}
 if m>1:assert len(internal)<=2*m-3
 possible=[(i,v) for i,P in enumerate(components) for v in set((P[0],P[-1])) if v in rows[core[-1]]]
 assert possible;i,p=rng.choice(possible);P=components.pop(i)
 if P[0]!=p:P=P[::-1]
 P=[q+core[-1]]+P;rng.shuffle(components)
 for Q in components:
  if rng.randrange(2):Q=Q[::-1]
  assert P[-1]<q and Q[0]<q;P+=Q
 assert len(P)==len(set(P))==q+h and set(P)==set(range(q+h))
 for u,v in zip(P,P[1:]):
  assert (u<q and v<q) or (u<q<=v and v-q in cols[u]) or (v<q<=u and u-q in cols[v])
 counts[(k,m)]+=1;total+=1;maximum_order=max(maximum_order,len(P))

for k in range(2,19):
 for _ in range(100):
  h=rng.randint(1,25);m=min(h,(k+2)//2);types=[]
  for attempt in range(100):
   T=set(rng.sample(range(h),rng.randint(1,m)))
   if all(len(T^S)<=k for S in types):types.append(T)
  union=set().union(*types)
  for x in set(range(h))-union:
   if all(len({x}^S)<=k for S in types):types.append({x})
  if set().union(*types)!=set(range(h)):continue
  cols=[T.copy() for T in types for _ in range(rng.randint(1,3))]
  for x in range(h):
   while sum(x in T for T in cols)<k:cols.append(rng.choice([T for T in types if x in T]).copy())
  run(cols,h,k)
# All core orders on compact even/odd boundary families, with randomized choices.
for m in range(2,11):
 for k in (2*m-2,2*m-1):
  for p in range(1,21):
   C=set(range(m-1));cols=[C|{m-1+i} for i in range(p) for _ in range(k)]
   run(cols,m-1+p,k)
print(json.dumps({'status':'PASS','fresh_flow_and_merge_paths':total,'maximum_order':maximum_order,'case_counts':{str(k):v for k,v in counts.items()},'scope':'Seeded fresh incidence and boundary controls; maximum-flow pairing and randomized endpoint merges independently implemented. Not exhaustive graph certification.'},indent=2))
