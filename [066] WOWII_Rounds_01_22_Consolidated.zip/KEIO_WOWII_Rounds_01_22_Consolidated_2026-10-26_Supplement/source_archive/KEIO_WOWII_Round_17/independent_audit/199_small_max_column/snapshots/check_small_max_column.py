#!/usr/bin/env python3
"""Exact constructive guards for the small-maximum-column absorption lemma.
Finite checks supplement, not replace, the mathematical proof.
"""
from pathlib import Path
from itertools import combinations
from collections import Counter
import json,random,time

def construct(cols,h,k):
 q=len(cols); rows=[{c for c,T in enumerate(cols) if i in T} for i in range(h)]
 assert h and all(cols) and min(map(len,rows))>=k>=2
 m=max(map(len,cols));assert m<=k+1 and k>=2*m-2
 assert all(len(a^b)<=k for a,b in combinations(cols,2))
 c0=max(range(q),key=lambda c:len(cols[c]));A=sorted(cols[c0]);X=sorted(set(range(h))-set(A))
 # Hall matching for two copies of every outside vertex. The two copies
 # cannot use one column twice because each column has capacity one.
 mate={}
 def augment(slot,seen):
  for c in sorted(rows[slot//2]):
   if c in seen:continue
   seen.add(c)
   if c not in mate or augment(mate[c],seen):mate[c]=slot;return True
  return False
 for x in X:
  for t in range(2):assert augment(2*x+t,set())
 chosen={s:c for c,s in mate.items()}
 components=[[chosen[2*x],q+x,chosen[2*x+1]] for x in X]
 components += [[c] for c in range(q) if c not in mate]
 assert any(P==[c0] for P in components)
 def locate(c):return next(j for j,P in enumerate(components) if c==P[0] or c==P[-1])
 def join(a,p,r):
  j=locate(p);l=locate(r);assert j!=l
  P=components[j];Q=components[l]
  if P[-1]!=p:P=P[::-1]
  if Q[0]!=r:Q=Q[::-1]
  merged=P+[q+a]+Q
  for index in sorted([j,l],reverse=True):components.pop(index)
  components.append(merged)
 if m==1:
  # The same general construction works, with the sole core inserted last.
  p=next(iter(rows[A[0]]));j=locate(p);P=components.pop(j)
  if P[0]!=p:P=P[::-1]
  P=[q+A[0]]+P
 else:
  p=next(iter(rows[A[0]]-{c0}));join(A[0],c0,p)
  for t,a in enumerate(A[1:-1],start=1):
   internal={v for P in components for v in P[1:-1] if v<q}
   assert len(internal)<=2*t-1
   choices=sorted(rows[a]-internal);assert len(choices)>=3
   pair=next((p,r) for p,r in combinations(choices,2) if locate(p)!=locate(r))
   join(a,*pair)
  internal={v for P in components for v in P[1:-1] if v<q}
  assert len(internal)<=2*m-3
  p=next(iter(rows[A[-1]]-internal));j=locate(p);P=components.pop(j)
  if P[0]!=p:P=P[::-1]
  P=[q+A[-1]]+P
 for Q in components:assert P[-1]<q and Q[0]<q;P+=Q
 assert set(P)==set(range(q+h)) and len(P)==q+h
 def edge(a,b):
  if a<q and b<q:return a!=b
  if a>=q and b>=q:return False
  if a>=q:a,b=b,a
  return b-q in cols[a]
 assert all(edge(a,b) for a,b in zip(P,P[1:]))
 return m,len(X),q

start=time.monotonic();count=0;cases=Counter();rng=random.Random(1991610)
def run(cols,h,k):
 global count
 m,x,q=construct(cols,h,k);count+=1;cases[f'k={k},m={m}']+=1
# A deterministic incidence grammar. Repeated columns are allowed and
# important; no isomorphism completeness assertion is made.
for k in range(2,13):
 for _ in range(100):
  h=rng.randrange(1,41);bound=min(h,(k+2)//2)
  family=[]
  for attempt in range(200):
   T=set(rng.sample(range(h),rng.randrange(1,bound+1)))
   if all(len(T^S)<=k for S in family):family.append(T)
   if len(set().union(*family))==h and len(family)>=h:break
  if len(set().union(*family))<h:
   # Singletons are compatible with every column when k>=2,m<=k-1;
   # the sole exceptional k=2,m=2 grammar is generated separately below.
   missing=set(range(h))-set().union(*family)
   for i in missing:
    T={i}
    if all(len(T^S)<=k for S in family):family.append(T)
  if len(set().union(*family))<h:continue
  mult=[rng.randrange(1,4) for _ in family]
  for i in range(h):
   while sum(n for T,n in zip(family,mult) if i in T)<k:
    j=rng.choice([j for j,T in enumerate(family) if i in T]);mult[j]+=1
  run([T.copy() for T,n in zip(family,mult) for _ in range(n)],h,k)
# Exact boundary k=2m-2 with an unbounded number of petals and common core.
for m in range(2,11):
 k=2*m-2
 for petals in range(1,31):
  core=set(range(m-1));family=[core|{m-1+j} for j in range(petals)]
  cols=[T.copy() for T in family for _ in range(k)]
  run(cols,m-1+petals,k)
# Disjoint singleton columns, all connectivity parameters.
for k in range(2,15):
 for h in range(1,31):run([{i} for i in range(h) for _ in range(k)],h,k)
out=dict(status='PASS',total_constructed_paths=count,case_counts=dict(cases),seconds=time.monotonic()-start,scope='Seeded exact incidence construction and scalable boundary families; not exhaustive graph certification.',new_original_closures=0)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
