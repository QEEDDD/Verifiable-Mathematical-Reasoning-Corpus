# A general path-cover absorption lemma for small maximum columns

**Scoped reduction; independent audit pending. Not a closure of WOWII 199.**

Let G be a connected noncomplete split graph with partition V=C∪I, where I
is maximum. Put k=κ(G)≥2 and m=max_{c∈C}|N(c)∩I|. Assume the original
199 hypothesis τ(G)≤k+2. If

    k≥2m−2,

then G is traceable. In particular, a possible split counterexample must
have m≥floor((k+2)/2)+1, as well as k≥4 by the separate low-connectivity
partial proofs (once independently audited).

## Proof

If m=1, each independent vertex has at least two clique neighbors, and
these neighborhoods are disjoint. Concatenate disjoint C–I–C paths and
unused clique vertices. Assume m≥2.

Choose c₀ with A=N(c₀)∩I and |A|=m. The induced-double-star bound gives
|A_c△A|≤k for every c, and maximality of m gives

    2|A_c\A|=|A_c△A|+|A_c|−|A|≤k.

Let r=floor(k/2)≥1. Every clique vertex has at most r neighbors in I\A,
whereas every independent vertex has at least k clique neighbors. Thus for
J⊆I\A, counting incidences yields

    k|J|≤r|N_C(J)|,   hence |N_C(J)|≥2|J|.

Hall's theorem, applied to two copies of each vertex of I\A, gives two
distinct clique neighbors per vertex, with all chosen clique vertices
distinct. Form the resulting disjoint three-vertex paths. Add every
unselected clique vertex as a singleton path. This collection covers
C∪(I\A), every component is C-ended, and c₀ is a singleton because it has
no neighbors outside A.

List A={a₁,…,a_m}. Since d(a₁)≥k≥2, choose a neighbor p≠c₀. Join the
singleton c₀ and the component containing p through a₁. If p is the end
of a nontrivial component, that endpoint becomes internal; c₀, formerly
isolated, becomes an endpoint rather than an internal vertex. Thus after
this first insertion at most one clique vertex is internal.

Inductively, after t core vertices have been inserted by joining distinct
C-ended components, at most 2t−1 clique vertices are internal. Each later
join makes at most two former clique endpoints internal, establishing the
bound. Every clique vertex not internal is an endpoint of one component
(a singleton counts as one endpoint vertex).

For t=1,…,m−2, consider a_{t+1}. It has at least

    k−(2t−1)≥2m−2−2t+1≥3

clique neighbors that are endpoints. A C-ended component has at most two
endpoint vertices, so two such neighbors lie in distinct components. Join
those components through a_{t+1}. This maintains the invariant and covers
all of A except a_m.

At t=m−1, the final vertex a_m has at least

    k−(2m−3)≥1

endpoint neighbor. Append a_m to that component, creating a path with one
independent endpoint and one clique endpoint. Concatenate every remaining
C-ended component at that clique endpoint, using clique edges. This yields
a spanning path. The same argument includes m=2: the intermediate loop is
empty. ∎

## Limit of the argument

The endpoint count is essential. The proof does not show how to proceed
when k<2m−2. It does not assume that a general capacity-two factor is acyclic;
it begins with the explicit disjoint three-vertex paths supplied by the
stronger Hall condition outside the maximum column.

Hall's theorem and the degree-counting argument are classical tools; no
novelty claim is made for them or for an equivalent theorem elsewhere in
the literature.
