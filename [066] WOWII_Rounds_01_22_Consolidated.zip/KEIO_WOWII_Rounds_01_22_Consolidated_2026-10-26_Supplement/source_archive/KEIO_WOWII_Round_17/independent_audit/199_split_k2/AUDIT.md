# Independent audit: original WOWII 199, split graphs with connectivity two

**Mathematical verdict: PASS.** This is an arbitrary-order split-subclass theorem, not a closure of original 199. No worldwide priority conclusion is made here.

## Exact statement and source lock

The archived original row says: for a simple connected graph of order greater than one, `tree(G) - 2 <= κ(G)` implies a Hamiltonian path. Definitions 48, 85 and 88 are copied to `pinned_original_definitions.txt`: tree number counts **vertices of a largest induced tree**, not an induced forest or an edge count; κ is vertex connectivity. Thus the κ=2 hypothesis is exactly an induced-tree order at most four. Complete graphs cause no difficulty under the usual connectivity convention.

Audited source: `round_16/induced/split199_connectivity_two.md`, SHA-256 `27a110ea67194d32777434c33b67b8c9d8023a09fee1d1bfdcb45b63256f1d4c`. The proof and executable controls are snapshotted. No mathematical repair was requested.

## Universal proof review

1. **Partition and connectivity.** Starting with a split partition, moving a clique vertex with no independent-side neighbor produces a maximum independent side; if no such vertex exists, the current side is already maximum. Every remaining clique vertex then has a nonempty column. For a noncomplete split graph with this partition, κ equals the minimum independent-side degree: deleting fewer vertices leaves a nonempty clique and attaches each surviving independent vertex; deleting a minimum neighborhood isolates its independent vertex, with another independent vertex remaining. This also covers a minimum neighborhood equal to the whole clique.
2. **Induced-tree restrictions.** One clique vertex gives the full induced star, and two give the induced double star on their exclusive independent neighbors. Consequently columns have sizes at most three and pairwise symmetric difference at most two. In fact these restrictions describe the maximum induced-tree order exactly: an induced tree uses at most two clique vertices, because three form a triangle. Common independent neighbors cannot occur with two clique vertices. The argument does not confuse an induced forest with a connected tree.
3. **Small independent side.** For α≤3, the primary Chvátal–Erdős theorem applies. The scan was obtained and read, including Theorem 1 and its proof and the universal-vertex derivation of Theorem 2 on printed page 112. Theorem 2 directly supplies α≤κ+1 ⇒ traceability. Source: [author-institution archive](https://users.renyi.hu/~p_erdos/1972-02.pdf), DOI [10.1016/0012-365X(72)90079-9](https://doi.org/10.1016/0012-365X(72)90079-9). A local primary PDF and text are retained under `sources/`.
4. **Maximum column size one.** Independent-neighbor groups are disjoint. Each has at least two members, so the disjoint three-vertex paths concatenate through clique edges; the final endpoint is in the clique, allowing all unused clique vertices to be appended.
5. **Maximum column size two.** Pairwise-intersecting two-sets either share a point or are confined to three points. Every singleton lies in every two-set. When the independent side has at least four vertices, all columns therefore have the stated common-point/petal form; each petal has a separate group of at least two clique neighbors. The displayed path has no repeated vertex and covers the common point and every petal.
6. **Maximum column size three.** The classification of pairwise two-intersecting triples into a common pair or a four-point union is correct. Smaller columns are contained in every triple. In the common-pair case, there are at least two petals, and the displayed insertion of the second common vertex between the first two petal blocks is valid. Distinct private groups prevent all vertex reuse.
7. **Four-point case.** Three triple-columns that are not all identical cover the four independent vertices and have a common point. Removing any specified common point leaves either a repeated pair plus another pair, or the three different pairs on a three-point ground set; both yield the displayed alternating path. This is a **prescribed-endpoint** assertion, which is precisely what the final append step needs. If an unused triple-column exists, it meets an endpoint of the seven-vertex path. Otherwise every unused column is a nonempty subset of the common intersection of all triples; choosing a point in one such column makes it an endpoint before appending that clique vertex and all the rest. The case with no unused clique vertex is also handled.

No arbitrary cycle-factor patching, 1-toughness implication, or unverified split-graph Hamiltonian-path characterization is used. The proof is a finite case distinction with scalable explicit paths, not a claim established by bounded enumeration.

## Reproducibility and finite controls

`check_independent.py` computes exact vertex connectivity, maximum independent-set size, the split partition, induced-tree order, and Hamiltonian paths by subset endpoint dynamic programming on the previously covered small-graph catalog. It separately checks a larger column-multiset grammar and every prescribed-endpoint seven-vertex instance. It imports **none** of the author's path constructor. Results are in `independent_results.json`.

The author's 1,093 constructive guards were rerun from a snapshot, leaving the frozen originals untouched. All fields except runtime agree exactly with the stored JSON. The tested domains and branch counts are recorded in `author_rerun.json`; these tests corroborate, but do not replace, the proof.

## Limits

This accepts only the κ=2 split subclass. The separate κ=3 manuscript requires its own audit. Original 199 on arbitrary connected graphs, and arbitrary-connectivity split graphs, is not closed. Historical status/priority checking remains the parent's separate source gate.

### Final independent counts

All 12,112 connected representatives of orders 2–8 were examined; 556 were split. Exactly 44 had κ=2 and induced-tree order at most 4; all had a Hamiltonian path by independent endpoint dynamic programming. The expanded column-multiset grammar supplied 808 further cases through order 11, all PASS. Across the joint check, all 96 prescribed-endpoint seven-vertex configurations also passed. The script independently computed the maximum induced-tree order on these tests and checked the exact column formula.
