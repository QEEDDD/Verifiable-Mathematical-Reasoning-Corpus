"""Independent exact graph invariants / endpoint dynamic programming.
No author constructor imported. Small graph catalog has separately audited coverage.
"""
from pathlib import Path
from itertools import combinations,product
from collections import Counter
import json,time
import networkx as nx
ROOT=Path('wowii_rounds');start=time.monotonic()
def bits(s):
 while s:
  b=s&-s;yield b.bit_length()-1;s^=b

def connected(A,S=None):
 if S is None:S=(1<<len(A))-1
 if not S:return False
 seen=S&-S;front=seen
 while front:
  nxt=0
  for v in bits(front):nxt|=A[v]
  front=nxt&S&~seen;seen|=front
 return seen==S

def hp(A,required_start=None):
 n=len(A);full=(1<<n)-1;ends=[0]*(full+1)
 for i in (range(n) if required_start is None else [required_start]):ends[1<<i]=1<<i
 for S in range(1,full+1):
  for v in bits(ends[S]):
   for w in bits(A[v]&~S):ends[S|1<<w]|=1<<w
 assert ends[full],('no HP',A,required_start)
 return ends[full]

def split(A):
 n=len(A);full=(1<<n)-1;best=None;alpha=0
 for S in range(1,full+1):
  if any(A[v]&S for v in bits(S)):continue
  alpha=max(alpha,S.bit_count());C=full^S
  if all((A[v]&C).bit_count()==C.bit_count()-1 for v in bits(C)):
   if best is None or S.bit_count()>best.bit_count():best=S
 if best is not None:assert best.bit_count()==alpha
 return best

def tree(A):
 n=len(A)
 for k in range(n,0,-1):
  for V in combinations(range(n),k):
   S=sum(1<<v for v in V)
   if sum((A[v]&S).bit_count() for v in V)==2*(k-1) and connected(A,S):return k

def connectivity(A):
 n=len(A);full=(1<<n)-1
 if all(x.bit_count()==n-1 for x in A):return n-1
 for k in range(n-1):
  for V in combinations(range(n),k):
   if not connected(A,full^sum(1<<v for v in V)):return k
 raise AssertionError

def frommask(n,m):
 A=[0]*n
 for j,(v,w) in enumerate(combinations(range(n),2)):
  if m>>j&1:A[v]|=1<<w;A[w]|=1<<v
 return A

small=Counter();case=Counter();kcounts=Counter()
for n in range(2,9):
 if n<=6:graphs=[[sum(1<<w for w in G[v]) for v in range(n)] for G in nx.graph_atlas_g() if len(G)==n]
 else:graphs=[frommask(n,m) for m in map(int,(ROOT/f'round_11/twodomination/core{n}_masks.txt').read_text().split())]
 for A in graphs:
  if not connected(A):continue
  small['connected_representatives']+=1;I=split(A)
  if I is None:continue
  small['split_graphs']+=1;C=((1<<n)-1)^I
  cols=[A[c]&I for c in bits(C)]
  if not C:continue
  assert all(cols)
  k=connectivity(A)
  if I.bit_count()>1:assert k==min((A[i]&C).bit_count() for i in bits(I))
  tau=tree(A)
  formula=max([1]+[1+x.bit_count() for x in cols]+[2+(x^y).bit_count() for x,y in combinations(cols,2)])
  assert tau==formula
  if k in (2,3) and tau<=k+2:
   hp(A);kcounts[k]+=1;case[(k,n,I.bit_count())]+=1

def colgraph(cols,h):
 q=len(cols);A=[((1<<q)-1)^(1<<c) for c in range(q)]+[0]*h
 for c,T in enumerate(cols):
  for i in bits(T):A[c]|=1<<(q+i);A[q+i]|=1<<c
 return A

# A larger independent multiset grammar, exact subset-DP rather than proof paths.
grammar=Counter();bydim=Counter();maxorder=0
for k in (2,3):
 for h in range(1,7):
  types=[s for s in range(1,1<<h) if s.bit_count()<=k+1]
  for q in range(k,8):
   if q+h>11:continue
   def visit(cols,first,rows):
    global maxorder
    left=q-len(cols)
    if any(d+left<k for d in rows):return
    if left==0:
     if min(rows)!=k:return
     A=colgraph(cols,h);hp(A)
     assert tree(A)<=k+2
     grammar[k]+=1;bydim[(k,h,q)]+=1;maxorder=max(maxorder,h+q);return
    for j in range(first,len(types)):
     t=types[j]
     if all((t^s).bit_count()<=k for s in cols):visit(cols+[t],j,[rows[i]+((t>>i)&1) for i in range(h)])
   visit([],0,[0]*h)

observations=0
for cols in product((7,11,13,14),repeat=3):
 if len(set(cols))==1:continue
 common=cols[0]&cols[1]&cols[2]
 for x in bits(common):
  E=hp(colgraph(cols,4),3+x);assert E&sum(1<<(3+i) for i in range(4) if i!=x)
  observations+=1
print(json.dumps(dict(status='PASS',small_graphs=dict(small),accepted_small_graphs={str(k):v for k,v in kcounts.items()},small_breakdown={str(k):v for k,v in case.items()},column_multisets={str(k):v for k,v in grammar.items()},grammar_breakdown={str(k):v for k,v in bydim.items()},grammar_max_order=maxorder,seven_vertex_prescribed_endpoint_checks=observations,seconds=time.monotonic()-start,scope='Exact finite controls only; no author constructor used. Universal conclusions rely on the audited analytic arguments.'),indent=2))
