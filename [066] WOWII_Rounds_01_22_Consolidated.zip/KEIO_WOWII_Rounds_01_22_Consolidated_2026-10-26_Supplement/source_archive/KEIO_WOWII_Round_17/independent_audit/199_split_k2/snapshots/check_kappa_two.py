#!/usr/bin/env python3
"""Exact constructive guards for the connectivity-two split subclass."""
from pathlib import Path
from itertools import combinations,permutations,product
from functools import lru_cache
import json,time

def path_small(cols,h):
    q=len(cols);n=q+h;A=[0]*n
    for c in range(q):
        for d in range(q):
            if c!=d:A[c]|=1<<d
        for i in cols[c]:A[c]|=1<<(q+i);A[q+i]|=1<<c
    @lru_cache(None)
    def dfs(mask,v):
        if mask==(1<<n)-1:return (v,)
        todo=A[v]&~mask
        for u in sorted((u for u in range(n) if todo>>u&1),key=lambda u:(A[u]&~mask).bit_count()):
            ans=dfs(mask|1<<u,u)
            if ans:return (v,)+ans
        return None
    for v in range(n):
        ans=dfs(1<<v,v)
        if ans:return list(ans)
    raise AssertionError('No path in small-alpha guard')

def construct(cols,h):
    q=len(cols);rows=[{c for c,K in enumerate(cols) if i in K} for i in range(h)]
    assert all(cols) and min(map(len,rows))>=2
    assert max(map(len,cols))<=3 and all(len(A^B)<=2 for A,B in combinations(cols,2))
    if h<=3:return path_small(cols,h),'small_alpha'
    m=max(map(len,cols));used=set();P=[]
    def add_petal(i):
        pair=sorted(rows[i])[:2]
        assert not used.intersection(pair)
        used.update(pair);return [pair[0],q+i,pair[1]]
    if m==1:
        for i in range(h):P+=add_petal(i)
        case='singleton_columns'
    elif m==2:
        core=set.intersection(*(K for K in cols if len(K)==2));assert len(core)==1
        a=next(iter(core));P=[q+a]
        for i in range(h):
            if i!=a:P+=add_petal(i)
        case='one_core'
    else:
        triples=[c for c,K in enumerate(cols) if len(K)==3]
        core=set.intersection(*(cols[c] for c in triples))
        if len(core)==2:
            a,b=sorted(core);petals=sorted(set(range(h))-core);assert len(petals)>=2
            P=[q+a]+add_petal(petals[0])+[q+b]
            for i in petals[1:]:P+=add_petal(i)
            case='two_core'
        else:
            assert h==4
            selected=next(T for T in combinations(triples,3) if len({tuple(sorted(cols[c])) for c in T})>1)
            used=set(selected);rest=set(range(q))-used
            preferred=None
            if rest and not any(len(cols[c])==3 for c in rest):
                d=min(rest);preferred=next(iter(cols[d]))
            x=preferred if preferred is not None else next(iter(set.intersection(*(cols[c] for c in selected))))
            P=None
            for IP in permutations(range(h)):
                if IP[0]!=x:continue
                for CP in permutations(selected):
                    if all(IP[j] in cols[CP[j]] and IP[j+1] in cols[CP[j]] for j in range(3)):
                        P=[q+IP[0],CP[0],q+IP[1],CP[1],q+IP[2],CP[2],q+IP[3]];break
                if P:break
            assert P is not None
            if rest:
                # Reverse if necessary to append an unused clique neighbor.
                join=next(((reverse,c) for reverse in [False,True] for c in sorted(rest) if (P[0] if reverse else P[-1])-q in cols[c]),None)
                assert join is not None
                reverse,c=join
                if reverse:P.reverse()
                P.append(c);used.add(c)
            case='four_vertex_core'
    P+=sorted(set(range(q))-used)
    return P,case

def verify(cols,h):
    P,case=construct(cols,h);q=len(cols);n=q+h
    assert len(P)==len(set(P))==n and set(P)==set(range(n))
    for u,v in zip(P,P[1:]):
        assert (u<q and v<q) or (u<q and v-q in cols[u]) or (v<q and u-q in cols[v])
    return case

start=time.monotonic();counts={};total=0
# Complete labeled matrix guard through the stated small scope.
for q in range(2,6):
 for h in range(1,6):
  if q+h>9 or q*h>20:continue
  types=[set(T) for size in range(1,min(3,h)+1) for T in combinations(range(h),size)]
  # Enumerate column multisets rather than all label permutations.
  def visit(cols,start_type):
    global total
    if len(cols)==q:
        degrees=[sum(i in K for K in cols) for i in range(h)]
        if min(degrees)!=2:return
        case=verify(cols,h);counts[case]=counts.get(case,0)+1;total+=1;return
    for j in range(start_type,len(types)):
        T=types[j]
        if all(len(T^K)<=2 for K in cols):visit(cols+[T],j)
  visit([],0)
small_total=total
# Arbitrarily scalable petal families, all with at least one degree-two petal.
for core_size in [0,1,2]:
 for petals in range(4,31):
  for variant in range(4):
    h=petals+core_size;core=set(range(core_size));cols=[]
    for j in range(petals):
        count=2 if j==0 else 2+(j+variant)%4
        cols.extend([core|{core_size+j} for _ in range(count)])
    if core_size:
        cols.extend([{a} for a in core for _ in range(variant)])
    case=verify(cols,h);counts[case]=counts.get(case,0)+1;total+=1
large_total=total-small_total
# All four-point triple multiplicities 0..3, and smaller-column multiplicities0..2.
triples=[set(range(4))-{i} for i in range(4)]
four_inputs=0
for mult in product(range(4),repeat=4):
    support=[T for T,m in zip(triples,mult) if m]
    if len(support)<2:continue
    intersection=set.intersection(*support)
    small=[set(T) for size in range(1,min(2,len(intersection))+1) for T in combinations(sorted(intersection),size)]
    for counts_small in product(range(3),repeat=len(small)):
        cols=[T.copy() for T,m in zip(triples,mult) for _ in range(m)]+[T.copy() for T,m in zip(small,counts_small) for _ in range(m)]
        if min(sum(i in T for T in cols) for i in range(4))!=2:continue
        case=verify(cols,4);counts[case]=counts.get(case,0)+1;total+=1;four_inputs+=1
out=dict(status='PASS',total=total,column_multiset_small_cases=small_total,scalable_family_cases=large_total,four_core_multiplicity_cases=four_inputs,case_counts=counts,seconds=time.monotonic()-start,scope='Exact path verification, not proof by finite enumeration; small scope q2..5,h1..5,q+h<=9,q*h<=20; scalable petals4..30 and four-core multiplicity grammar.',new_original_closures=0)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
