# Eliminating the path-factor gap when the split graph has connectivity two

**Status: a complete, precisely scoped partial proof, awaiting independent
audit. This does not close original WOWII 199, and no worldwide novelty claim
is made.**

## Theorem

Let G be a finite simple connected split graph with κ(G)=2. If its largest
induced tree has at most four vertices, then G has a Hamiltonian path.

The hypothesis is exactly the original 199 condition τ(G)≤κ(G)+2 in this
subclass. The proof avoids the unjustified implication from a capacity-two
factor to an acyclic factor. Instead, it classifies the possible neighborhood
families and directly constructs spanning paths in the unbounded cases.

## 1. Choose the split partition carefully

Choose V(G)=C∪I with C a clique and I a maximum independent set. Such a split
partition always exists: from any split partition, if a clique vertex has
no independent-side neighbor, move it to the independent side. Every
remaining clique vertex is adjacent to the moved vertex; thereafter no
independent set using a clique vertex can be larger than I. If no vertex
can be moved, the initial I is already maximum.

For c∈C put A_c=N(c)∩I, and let m=max_c |A_c|. Every A_c is nonempty.
The complete graph case is immediate, so suppose G is not complete. Then
κ(G)=min_{i∈I}d_C(i), as in the earlier split-graph parameter calculation.
Thus every independent vertex has at least two clique neighbors. An induced
star centered at c gives |A_c|≤3. For two distinct clique vertices c,d,
using every independent vertex adjacent to exactly one of c,d gives an
induced double star. Therefore

    1≤|A_c|≤3,                |A_c△A_d|≤2.                 (1)

Repeated sets are allowed: distinct clique vertices can have identical
independent-side neighborhoods.

If |I|≤3, then α(G)≤κ(G)+1, and the classical Chvátal–Erdős traceability
corollary gives a Hamiltonian path. For completeness, that corollary follows
from their Hamiltonian-cycle theorem by adjoining a universal vertex: the
connectivity increases by one and the independence number does not increase;
deleting the added vertex from a Hamiltonian cycle gives the required path.
We therefore assume |I|≥4 below.

## 2. Maximum column size one

If m=1, the clique neighborhoods of different independent vertices are
disjoint. Choose two distinct neighbors p_i,q_i for every i∈I. The paths
p_i,i,q_i are pairwise vertex-disjoint. Concatenate them using clique edges,
and append all unused clique vertices. This is a spanning path.

## 3. Maximum column size two

Two two-element columns must intersect, since disjoint ones have symmetric
difference four. A pairwise-intersecting family of two-element sets either
has a common element or is contained in a three-element ground set. Here is
the elementary reason: for two distinct sets {a,b},{a,c}, a set not containing
a must be {b,c}; its presence prevents every other set from introducing a
new element.

Every singleton column belongs to every two-element column, by (1). If the
two-element family had only one distinct member, all columns would lie in
that two-element set. If the family were contained in a three-element set,
all columns would lie there as well. Both alternatives contradict |I|≥4,
since every independent vertex has a neighbor. Consequently there is one
common element a, and all two-element columns have the form {a,x}.
Their common intersection is exactly {a}; singleton columns can only be {a}.

Write I\{a}={x₁,…,x_t}. Each x_j has at least two clique neighbors, and all
of them have column {a,x_j}. Choose distinct p_j,q_j from that group. The
groups for different petals x_j are disjoint. Then

    a,p₁,x₁,q₁,p₂,x₂,q₂,…,p_t,x_t,q_t

is a path containing all independent vertices and the chosen clique vertices.
Append all unused clique vertices. Every asserted connecting edge is either
inside C or one of the displayed incidences.

## 4. Maximum column size three: classification

Distinct three-element columns intersect in at least two elements. Such a
family either has a common two-element subset or has its entire union in a
four-element set. To verify this, take two distinct members
{a,b,c},{a,b,d}. A third member not containing both a,b must be either
{a,c,d} or {b,c,d}. Once such a member occurs, no set containing a,b can
introduce a fifth element, and the same intersection requirement confines
all other members to {a,b,c,d}.

Furthermore, every two-element column is a subset of every three-element
column, and every singleton column belongs to every three-element column;
both statements follow immediately from (1). If there is only one distinct
three-element column, all independent vertices lie in it, contrary to
|I|≥4.

### 4a. The common-pair case

Suppose the intersection of all three-element columns contains {a,b}.
Since there are at least two distinct such columns, their intersection is
exactly {a,b}. All other columns are nonempty subsets of {a,b}. Hence every
vertex x∈I\{a,b} appears only in columns {a,b,x} and has at least two
clique neighbors of that type.

Write I\{a,b}={x₁,…,x_t}; here t≥2. Choose distinct p_j,q_j with column
{a,b,x_j}. The following is a path:

    a,p₁,x₁,q₁,b,p₂,x₂,q₂,p₃,x₃,q₃,…,p_t,x_t,q_t.

It contains every independent vertex. Append all unused clique vertices.
This directly resolves the unbounded-order case, without any assertion that
an arbitrary previously selected cycle factor can be patched.

### 4b. The four-element case

The remaining alternative has |I|=4. Let T be the set of clique vertices
whose columns have size three. There are at least three vertices in T.
Indeed, if T had at most two vertices, its two distinct column types would
each have a private independent vertex; that vertex appears in no smaller
column and would have degree one. There are at least two distinct types.
Choose distinct t₁,t₂,t₃∈T whose three columns are not all identical.
Their union is I, and their intersection is nonempty.

We use the following constant-size observation.

**Seven-vertex observation.** Given four independent vertices and three
clique vertices, each of whose columns has size three and whose columns are
not all identical, there is an alternating spanning path beginning at any
specified vertex x common to the three columns.

To prove it, delete x from the three columns. They are three two-element
subsets of the remaining three-element set, not all identical. Up to
relabelling and reordering, the multiset is either

    {ab,ab,bc},       or       {ab,bc,ca}.

In the first case order the columns as ab,ab,bc; in the second as ca,ab,bc.
In both cases the vertex order

    x,t₁,a,t₂,b,t₃,c

is an alternating spanning path. This proves the observation.

Apply it to the chosen three clique vertices. If there are no unused clique
vertices, the proof is finished. If there is an unused clique vertex d with
a three-element column, at least one of the two independent endpoints of
the seven-vertex path is adjacent to d. Orient the path so that this endpoint
comes last, append d, and then append every other unused clique vertex.

Finally suppose every unused clique vertex has a smaller column. Choose one
such vertex d. Its nonempty column is contained in the intersection of *all*
three-element columns, hence in the intersection of the three selected ones.
Choose x∈A_d, use the observation to obtain a path with endpoint x, orient it
to end at x, append d, and append all remaining clique vertices. This again
is a Hamiltonian path. ∎

## Attribution and limits

The only non-elementary theorem invoked is the classical Chvátal–Erdős
Hamiltonian-cycle theorem, solely for α≤3. Primary source:
[V. Chvátal and P. Erdős, *A note on Hamiltonian circuits*, Discrete Mathematics
2 (1972), 111–113](https://doi.org/10.1016/0012-365X(72)90079-9),
[author archive scan](https://combinatorica.hu/~p_erdos/1972-02.pdf).
The set-family arguments above are elementary classifications, not claimed
as new general results.

This does not rely on Renjith–Sadagopan's 2017 HPATH characterization,
[arXiv:1711.09262](https://arxiv.org/abs/1711.09262). A reading caution is
that their Theorem 4 counts a short cycle as an I–K path after deleting one
cycle edge, as explicitly stated in the following proof paragraph. A
preliminary concern about an omitted cycle condition was therefore withdrawn.
No inference is made from 1-toughness alone. The κ≥3 split case and the original unrestricted conjecture
remain unresolved by this proof.
