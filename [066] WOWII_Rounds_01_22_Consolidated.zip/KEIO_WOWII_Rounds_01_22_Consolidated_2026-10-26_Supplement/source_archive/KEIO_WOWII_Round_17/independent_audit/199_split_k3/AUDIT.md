# Independent audit: original WOWII 199, split graphs with connectivity three

**Mathematical verdict: PASS.** The accepted theorem is: a finite simple connected split graph with κ=3 and maximum induced-tree vertex order at most five is traceable. It does not close original 199 or the arbitrary-connectivity split case. No novelty or worldwide priority certification is made here.

Audited source: `round_16/induced/split199_connectivity_three.md`, SHA-256 `22927e5f762605957829703b532c882c06a6018530a854d6aebedbe234b5a769`. Proof, checker, stored results, and the finite family input are snapshotted. No mathematical repair was needed.

## Definitions and dependencies

The exact original row and definitions 48/85/88 are pinned beside this report. The condition is precisely `tree(G) <= κ(G)+2`, with **connected induced tree vertex order**, not induced forest order. The maximum-independent split partition and κ=minimum independent-side degree were independently checked in the κ=2 audit and are valid here. For α≤4, Chvátal–Erdős Theorem 2 (1972, printed p.112) directly gives traceability; the primary scan and proof were read and saved in the sibling κ=2 audit. The closure rule used below is proved within the submitted manuscript; it does not depend on access to an external unreviewed proof.

## Universal proof review

### Three path operations

Insertion of an unused clique vertex d beside an independent neighbor a uses an existing edge a–c of the path; replacing it by a–d–c is valid. Since the relevant paths contain all independent vertices, a has an incident clique edge. Repeating cannot introduce repeats.

The detour a–p–x–q–c is valid when p,q are distinct unused neighbors of the new independent vertex x and p also sees a. It works at an internal a and at either endpoint after orientation. The clique-edge detour c–p–x–q–d leaves clique edges c–p and q–d available for subsequent repetitions. All reserved and absorbed groups are explicitly disjoint; this is not cycle-factor patching.

### Maximum-column decomposition

Let A be a largest column of size m. The induced-star and induced-double-star bounds give size at most four and symmetric difference at most three. The displayed identity
`2|A_c\A| = |A_c△A| + |A_c| - |A| <= 3`
forces at most one outside independent neighbor per column. Thus private groups C_x are pairwise disjoint, each of size at least three. Their core parts satisfy `|A_c∩A| >= m-2`. A preliminary path through A reserving at most one vertex of each group leaves two unused neighbors for every outside vertex. For m≥3 the first reserved detour vertex has a core neighbor already on the path. Absorbing one group does not deplete any other group.

### Small maximum columns

For m=1, separate neighbor pairs concatenate through clique edges. For m=2, a–r–c₀–b is a core-spanning path with a clique edge and at most one reserved private vertex. The clique-edge operation handles every outside vertex without needing any core adjacency of its group.

For m=3, a second column with two core neighbors immediately gives the stated five-vertex core path. If none exists, all private columns have exactly one core neighbor. Because there are at least two outside groups, symmetric difference at most three forces the same core point in every group. The other two core points have private-to-core clique neighbors outside c₀; these two neighbors are distinct, since no other column has two core points. The displayed six-vertex core path is therefore simple and reserves no private-group vertex.

### Four core points and at least two outside groups

Each private core part has size at least two. If two distinct groups offer a union of at least three points, their two columns plus c₀ yield an alternating path through all four core points. The disjoint case consists of two disjoint pairs. In the intersecting case, distinct a,b,c with {a,b} in the first core part and {b,c} in the second always exist, including nested or equal three-point parts. Only one vertex is reserved in each of two different groups.

If no such pair exists, comparison across two different nonempty groups forces every private core part to be the same pair. Each of the other two core points has clique neighbors entirely in C₀, beyond c₀. The paths for r=s and r≠s use distinct vertices in precisely the stated way, reserving only one private-group vertex. Absorption then applies.

### Four core points and one outside vertex

Here there are five independent vertices. The outside vertex has at least three clique neighbors and none is a singleton column; together with c₀ this supplies at least four different columns of size at least two. For any missing incidence to such a column, the degree sum is at least `3+(|C|-1+2)=n-1`. Completing these columns raises every independent-side degree to at least four. Missing incidences to the remaining singleton columns then also satisfy the threshold. The complete split graph with five independent vertices and at least four clique vertices has an explicit alternating path, with additional clique vertices inserted or appended.

The reverse closure argument is correct: add a universal vertex to convert a Hamiltonian path into a cycle; deleting the newly added nonedge yields a spanning path with those nonadjacent endpoints. Their degree sum in the augmented graph is at least its order. The two index sets among the N−1 possible cuts therefore overlap, giving the displayed reversed-tail cycle using no forbidden edge. Deleting the universal vertex recovers a Hamiltonian path in the original graph. End indices cannot produce degenerate cuts because the endpoints are nonadjacent. Degrees are evaluated before each edge insertion; monotonicity permits all subsequent insertions.

## Auxiliary κ=1 observation

For clarity, the κ=1 split case can be supplied without an additional classification dependency. Columns then have size at most two and symmetric difference at most one. If a two-column exists, all two-columns are identical and all singletons belong to it; if none exists, all singleton columns are identical. Hence the maximum independent side has at most two vertices. Chvátal–Erdős Theorem 2 applies. Complete graphs are immediate. Thus combining this elementary observation with the separately audited κ=2 and κ=3 arguments indeed proves original 199 throughout the split subclass κ≤3, but not beyond it.

## Independent computation and author controls

The sibling `check_independent.py` uses exact graph invariant computations and a subset endpoint dynamic program, not the author's constructor. It tests the κ=3 portion of the covered small-graph catalog and a larger column-multiset grammar; the complete output is copied as `independent_results.json` here. These are finite controls, not the arbitrary-order proof.

The author checker was also reread and rerun on a snapshot. All 5,791 path certificates pass and its stored non-runtime fields match exactly: 4,517 small grammar cases, 1,100 seeded family multiplicities, and 174 scalable cases. All eight code branches occur; 730 cases use the one-outside closure route, with 1,424 explicit reverse-edge repairs. The 11-family input file is only a source of supplementary controls, **not** asserted to certify exhaustive arbitrary-order coverage and not a dependency of the analytic proof.

## Scope and status

The proof uses κ=3 essentially to make the private groups disjoint and retain two unused neighbors after one reservation. Neither fact has been established in the needed form for arbitrary κ. No full original closure or new-closure count increment is justified. Source priority remains a separate gate.

### Final independent counts

All 12,112 connected representatives of orders 2–8 were examined; 556 were split. Exactly 45 had κ=3 and induced-tree order at most 5; all had a Hamiltonian path by independent endpoint dynamic programming. The expanded column-multiset grammar supplied 19,944 further cases through order 11, all PASS. Across the joint check, all 96 prescribed-endpoint seven-vertex configurations also passed. The script independently computed the maximum induced-tree order on these tests and checked the exact column formula.
