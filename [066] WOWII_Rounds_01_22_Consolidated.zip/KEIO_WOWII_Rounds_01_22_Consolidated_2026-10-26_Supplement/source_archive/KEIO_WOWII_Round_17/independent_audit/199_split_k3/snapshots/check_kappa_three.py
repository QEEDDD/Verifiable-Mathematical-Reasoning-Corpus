#!/usr/bin/env python3
"""Standard-library constructive guard for the kappa-three split proof."""
from pathlib import Path
from itertools import combinations,permutations,product
from collections import Counter
import json,random,time

def adjacent(u,v,cols,q):
    if u<q and v<q:return u!=v
    if u>=q and v>=q:return False
    if u>=q:u,v=v,u
    return v-q in cols[u]

def check_path(P,cols,h,spanning=True):
    q=len(cols);assert len(P)==len(set(P))
    assert set(range(q,q+h))<=set(P)
    if spanning:assert set(P)==set(range(q+h))
    assert all(adjacent(u,v,cols,q) for u,v in zip(P,P[1:]))

def insert_remaining(P,cols,h):
    q=len(cols)
    if len(P)==1:
        c=next(c for c,K in enumerate(cols) if P[0]-q in K);P.append(c)
    for c in range(q):
        if c in P:continue
        a=q+next(iter(cols[c]));j=P.index(a)
        # Every independent vertex has an incident path edge to C.
        if j+1<len(P):assert P[j+1]<q;P.insert(j+1,c)
        else:assert P[j-1]<q;P.insert(j,c)
    check_path(P,cols,h);return P

def small_independent_path(cols,h):
    q=len(cols);rows=[{c for c,K in enumerate(cols) if i in K} for i in range(h)]
    if h==1:return [q]
    for order in permutations(range(h)):
        def dfs(j,used,P):
            if j==h-1:return P
            a,b=order[j:j+2]
            for c in sorted((rows[a]&rows[b])-used):
                out=dfs(j+1,used|{c},P+[c,q+b])
                if out:return out
            for c in sorted(rows[a]-used):
                for d in sorted(rows[b]-used-{c}):
                    out=dfs(j+1,used|{c,d},P+[c,d,q+b])
                    if out:return out
            return None
        out=dfs(0,set(),[q+order[0]])
        if out:return out
    raise AssertionError('small-independent-set path absent')

def closure_path(cols,h):
    q=len(cols);n=q+h;adj=[set() for _ in range(n)];added=[]
    for c in range(q):
        adj[c]=set(range(q))-{c}
        for i in cols[c]:adj[c].add(q+i);adj[q+i].add(c)
    order=[c for c,K in enumerate(cols) if len(K)>=2]+[c for c,K in enumerate(cols) if len(K)==1]
    for c in order:
        for i in range(h):
            u=q+i
            if c in adj[u]:continue
            assert len(adj[u])+len(adj[c])>=n-1
            added.append((u,c));adj[u].add(c);adj[c].add(u)
    assert all(len(adj[q+i])==q for i in range(h)) and q>=h-1
    P=[q]
    for i in range(1,h):P.extend([i-1,q+i])
    P.extend(range(h-1,q))
    repairs=0
    for u,v in reversed(added):
        adj[u].remove(v);adj[v].remove(u)
        assert len(adj[u])+len(adj[v])>=n-1
        if not any({a,b}=={u,v} for a,b in zip(P,P[1:])):continue
        repairs+=1;w=n;cyc=P+[w];N=n+1;j=cyc.index(u)
        step=-1 if cyc[(j+1)%N]==v else 1
        Q=[cyc[(j+step*t)%N] for t in range(N)]
        assert Q[0]==u and Q[-1]==v
        def edge(a,b):return a==w or b==w or b in adj[a]
        cut=next(j for j in range(N-1) if edge(u,Q[j+1]) and edge(Q[j],v))
        cyc=Q[:cut+1]+Q[cut+1:][::-1]
        z=cyc.index(w);P=cyc[z+1:]+cyc[:z]
        assert all(b in adj[a] for a,b in zip(P,P[1:]))
    check_path(P,cols,h)
    return P,repairs

def construct(cols,h):
    q=len(cols);rows=[{c for c,K in enumerate(cols) if i in K} for i in range(h)]
    assert all(cols) and min(map(len,rows))>=3
    assert max(map(len,cols))<=4 and all(len(a^b)<=3 for a,b in combinations(cols,2))
    if h<=4:return insert_remaining(small_independent_path(cols,h),cols,h),'small_alpha',0
    c0=max(range(q),key=lambda c:len(cols[c]));A=cols[c0];m=len(A);X=sorted(set(range(h))-A)
    groups={x:rows[x] for x in X};assert all(len(G)>=3 for G in groups.values())
    assert sum(map(len,groups.values()))==len(set().union(*groups.values()))
    if m==1:
        P=[]
        for i in range(h):
            p,r=sorted(rows[i])[:2];P.extend([p,q+i,r])
        return insert_remaining(P,cols,h),'m1',0
    if m==2:
        a,b=sorted(A);r=next(iter(rows[a]-{c0}));P=[q+a,r,c0,q+b];case='m2'
    elif m==3:
        high=next((c for c in range(q) if c!=c0 and len(cols[c]&A)>=2),None)
        if high is not None:
            a,b=sorted(cols[high]&A)[:2];c=next(iter(A-{a,b}));P=[q+c,c0,q+a,high,q+b];case='m3_pair'
        else:
            assert len(X)>=2
            a=next(iter(cols[next(iter(groups[X[0]]))]&A));b,c=sorted(A-{a})
            assert all(cols[d]&A=={a} for G in groups.values() for d in G)
            p=next(iter(rows[b]-{c0}));r=next(iter(rows[c]-{c0}));assert p!=r
            P=[q+a,c0,q+b,p,r,q+c];case='m3_common_vertex'
    else:
        if len(X)==1:
            P,repairs=closure_path(cols,h);return P,'m4_one_outside_closure',repairs
        pair=None
        for x,y in combinations(X,2):
            pair=next(((p,r) for p in sorted(groups[x]) for r in sorted(groups[y]) if len((cols[p]|cols[r])&A)>=3),None)
            if pair:break
        if pair:
            selected=(c0,)+pair;P=None
            for IP in permutations(sorted(A)):
                for CP in permutations(selected):
                    if all(IP[j] in cols[CP[j]] and IP[j+1] in cols[CP[j]] for j in range(3)):
                        P=[q+IP[0],CP[0],q+IP[1],CP[1],q+IP[2],CP[2],q+IP[3]];break
                if P:break
            assert P;case='m4_union'
        else:
            p=next(iter(groups[X[0]]));B=cols[p]&A;assert len(B)==2
            assert all(cols[d]&A==B for G in groups.values() for d in G)
            a,b=sorted(B);c,d=sorted(A-B);r=next(iter(rows[c]-{c0}));s=next(iter(rows[d]-{c0}))
            P=[q+a,p,q+b,c0,q+c,r]+([] if r==s else [s])+[q+d];case='m4_common_pair'
    assert all(len(set(P)&G)<=1 for G in groups.values())
    for x in X:
        p,r=sorted(groups[x]-set(P))[:2]
        if m==2:
            j=next(j for j in range(len(P)-1) if P[j]<q and P[j+1]<q)
            P[j+1:j+1]=[p,q+x,r]
        else:
            a=q+next(iter(cols[p]&A));j=P.index(a)
            if j+1<len(P):P[j+1:j+1]=[p,q+x,r]
            else:P[j:j]=[r,q+x,p]
    return insert_remaining(P,cols,h),case,0

start=time.monotonic();cases=Counter();total=repairs=0

def run(cols,h):
    global total,repairs
    P,case,r=construct(cols,h);check_path(P,cols,h)
    cases[case]+=1;total+=1;repairs+=r

# Small exhaustive column-multiset grammar, no graph-isomorphism assumptions.
for h in range(1,7):
 for q in range(3,7):
  if h+q>10:continue
  types=[set(T) for size in range(1,min(4,h)+1) for T in combinations(range(h),size)]
  def visit(cols,start_type,degrees):
    remaining=q-len(cols)
    if any(d+remaining<3 for d in degrees):return
    if not remaining:
        if min(degrees)==3:run(cols,h)
        return
    for j in range(start_type,len(types)):
        T=types[j]
        if all(len(T^K)<=3 for K in cols):visit(cols+[T],j,[d+(i in T) for i,d in enumerate(degrees)])
  visit([],0,[0]*h)
small=total
# Seeded multiplicities on the saved h=6 compatible-family representatives.
families=json.loads(Path(__file__).with_name('kappa3_h6_maximal_family_representatives.json').read_text())
rng=random.Random(1991603)
for F in families:
 F=list(map(set,F))
 for _ in range(100):
    mult=[rng.randrange(4) for T in F]
    for i in range(6):
        while sum(mult[j] for j,T in enumerate(F) if i in T)<3:
            j=rng.choice([j for j,T in enumerate(F) if i in T and mult[j]<3]);mult[j]+=1
    cols=[T.copy() for T,m in zip(F,mult) for _ in range(m)]
    run(cols,6)
seeded=total-small
# Large explicit families exercise each private-group branch.
for petals in range(2,31):
 # m1 and m2
 cols=[{i} for i in range(petals+2) for _ in range(3)];run(cols,petals+2)
 cols=[{0,1},{0},{0},{1},{1}]+[{i} for i in range(2,petals+2) for _ in range(3)];run(cols,petals+2)
 # m3: common core vertex or an additional two-core-neighbor column.
 cols=[{0,1,2},{1},{1},{2},{2}]+[{0,i} for i in range(3,petals+3) for _ in range(3)];run(cols,petals+3)
 cols=[{0,1,2},{0,2},{0,2}]+[{0,1,i} for i in range(3,petals+3) for _ in range(3)];run(cols,petals+3)
 # m4: fixed pair versus core-neighborhood union >=3.
 cols=[{0,1,2,3},{0,2},{0,2},{0,3},{0,3}]+[{0,1,i} for i in range(4,petals+4) for _ in range(3)];run(cols,petals+4)
 cols=[{0,1,2,3},{0,1,3},{0,1,3}]+[{0,1,2,i} for i in range(4,petals+4) for _ in range(3)];run(cols,petals+4)
large=total-small-seeded
out=dict(status='PASS',total_cases=total,small_column_multiset_cases=small,seeded_multiplicity_cases=seeded,scalable_family_cases=large,case_counts=dict(cases),closure_edge_repair_operations=repairs,seconds=time.monotonic()-start,scope='Exact constructed spanning paths, not proof by enumeration. Small grammar h1..6,q3..6,h+q<=10; seeded h6 families; scalable petals2..30.',new_original_closures=0)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
