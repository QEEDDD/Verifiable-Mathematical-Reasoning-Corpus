# Private-neighborhood absorption for the connectivity-three split case

**Status: complete scoped partial proof, independent audit pending. Original
WOWII 199 is NOT closed. No worldwide novelty claim is made.**

## Theorem

Every finite simple connected split graph G with κ(G)=3 and largest induced
tree order τ(G)≤5 has a Hamiltonian path.

Together with the separate connectivity-two argument and the earlier
connectivity-one argument, this removes κ≤3 from a possible split-graph
counterexample to the original conjecture, subject to independent audit.

## 1. Setup and three elementary operations

Choose a split partition V=C∪I with I maximum; the existence of such a
partition is proved in the connectivity-two note. Write A_c=N(c)∩I.
Complete graphs are immediate. Otherwise

    d_C(i)≥3 for every i∈I,
    1≤|A_c|≤4,                 |A_c△A_d|≤3.              (H)

The last two inequalities come from the induced star and induced double-star
constructions. If |I|≤4, Chvátal–Erdős gives traceability because
α(G)=|I|≤κ(G)+1. We henceforth assume |I|≥5.

**Operation 1: insert an unused clique vertex.** Once a path contains all
vertices of I, every unused d∈C has an independent neighbor a already on the
path. Replace an incident path edge a–c, c∈C, by a–d–c. Repeating this gives
a spanning path. Thus it suffices to construct a simple path containing I;
we do not need to cover all clique vertices initially.

**Operation 2: absorb a private petal at an independent vertex.** Suppose a
path contains a∈I and an incident edge a–c with c∈C. Let x∈I be outside the
path and let p,q∈C be distinct unused neighbors of x, with ap∈E. Replace

    a–c   by   a–p–x–q–c.                               (1)

This preserves a simple path and covers x. It works even when a is internal.

**Operation 3: absorb a petal at a clique edge.** Given a path edge c–d
with c,d∈C, and distinct unused p,q∈N(x), replace it by

    c–p–x–q–d.                                          (2)

At least one clique edge remains available, so this operation can be
repeated for disjoint private groups.

## 2. Maximum-column decomposition

Choose c₀∈C with A=A_{c₀} of maximum size m. Let X=I\A. For any c∈C,

    2|A_c\A|=|A_c△A|+|A_c|−|A|≤3.

Consequently every clique vertex has at most one neighbor in X. The sets

    C_x=N_C(x),  x∈X,

are therefore pairwise disjoint, each with at least three vertices. Put
C₀=C\⋃_{x∈X}C_x; in particular c₀∈C₀. A clique vertex in C_x has exactly
one outside neighbor x and some core neighbors S_c=A_c∩A. Comparing its
column with A gives

    m+1−|S_c|=|A_c△A|≤3,
    hence |S_c|≥m−2.                                    (3)

A preliminary path through A that uses at most one clique vertex from each
C_x leaves at least two unused vertices in every C_x. If m≥3, (3) guarantees
a core neighbor for each chosen first petal neighbor, so Operation 2 then
absorbs every x∈X. Operation 1 finishes the spanning path. This is the
precise reason that the reserved vertices cannot exhaust a petal group.

## 3. Maximum column size at most two

If m=1, clique-neighbor groups of all independent vertices are disjoint.
Choose two clique neighbors per independent vertex, form disjoint
three-vertex paths, and concatenate them through clique edges.

If m=2, write A={a,b}. Choose r∈N_C(a)\{c₀}; it exists because d_C(a)≥3.
The path

    a,r,c₀,b

contains A and has a clique edge. It uses at most one vertex of any C_x.
Use Operation 3 with two remaining neighbors from each group C_x, then
Operation 1. No core incidence for the outside columns is needed here.

## 4. Maximum column size three

Here |X|≥2 because |I|≥5. If some d≠c₀ satisfies |A_d∩A|≥2, choose distinct
a,b in this intersection and let c be the third core vertex. Then

    c,c₀,a,d,b

is a core-spanning path, with at most one reserved vertex in a private group.
The absorption procedure in Section 2 finishes.

Otherwise every clique vertex except c₀ has at most one core neighbor.
By (3), each vertex in C_x has exactly one core neighbor, so its column is
{a,x} for some a∈A. For two different groups C_x,C_y, columns {a,x},{b,y}
would have symmetric difference four unless a=b. Since |X|≥2, comparison
with a fixed column in another group shows that **all** private-group
columns use the same core vertex a.

Write A={a,b,c}. The other two core vertices b,c have all their clique
neighbors in C₀ and have degree at least three. Choose
p∈N_C(b)\{c₀} and q∈N_C(c)\{c₀}. They are distinct because no column other
than c₀ contains two core vertices. Now

    a,c₀,b,p,q,c

is a simple path containing A. It reserves no private-group vertices.
All private groups can be absorbed at a using Operation 2.

## 5. Maximum column size four, with at least two outside vertices

Assume first |X|≥2. By (3), every private-group column has at least two core
neighbors.

### 5a. Two groups offer a core-neighborhood union of size at least three

Suppose p∈C_x and q∈C_y, x≠y, satisfy

    |(A_p∩A)∪(A_q∩A)|≥3.

Let S=A_p∩A, T=A_q∩A. There is an alternating path through the four core
vertices using c₀,p,q:

* If S,T are disjoint, both have size two; for S={a,b}, T={c,d}, use
  a,p,b,c₀,c,q,d.
* Otherwise choose distinct a,b,c with a,b∈S and b,c∈T. Such a choice exists
  because both sets have size at least two and their union has size at least
  three. Let d be the remaining core vertex; use d,c₀,a,p,b,q,c.

This reserves one vertex in each of two different private groups, and no
others. Section 2 applies.

### 5b. No such pair of groups exists

Then all private-group core neighborhoods are one and the same two-element
set B={a,b}. Indeed, any columns from two different groups have core sets
of size at least two whose union has size at most two, forcing equality;
comparison with a fixed column in another group covers every column.

Write A\B={c,d}. Both c,d have all their clique neighbors in C₀. Choose
r∈N_C(c)\{c₀} and s∈N_C(d)\{c₀}. Also choose any p from any private group.
If r=s, use the path

    a,p,b,c₀,c,r,d.

If r≠s, use

    a,p,b,c₀,c,r,s,d.

Both paths contain A and reserve only one private-group vertex p. Section 2
again applies.

## 6. Maximum column size four, with one outside vertex

The case X=∅ was covered by |I|≤4. It remains that |X|=1, so |I|=5.
Write X={x}. A singleton column {x} would have symmetric difference five
from A, which is forbidden. Thus the at least three clique neighbors of x
all have column size at least two. Together with c₀, this gives at least four
distinct clique vertices whose columns have size at least two.

We apply the classical Hamiltonian-path closure rule: adding a nonedge uv
preserves traceability whenever d(u)+d(v)≥n−1. A proof is supplied below.
Here n=|C|+5. For any nonedge ic with i∈I and |A_c|≥2,

    d(i)+d(c) ≥ 3+(|C|−1+2)=n−1.

Successively add all missing incidences to those columns. There are at least
four of them, so every independent vertex now has degree at least four.
Every remaining column is a nonempty singleton, and its missing incidences
can also be added, since 4+(|C|−1+1)=n−1. The resulting graph is the complete
split graph with five independent vertices and at least four clique vertices,
which has a Hamiltonian path. Reversing the closure steps proves that the
original graph is traceable. ∎

## Appendix: the classical path-closure rule

Let uv be a nonedge of an n-vertex graph G with d(u)+d(v)≥n−1. Only the
backward direction needs proof. If G+uv has a spanning path, add a new
universal vertex w to obtain a Hamiltonian cycle in H+uv, where H=G+w has
N=n+1 vertices and d_H(u)+d_H(v)≥N. If that cycle does not use uv, nothing
is needed. Otherwise deleting uv gives a spanning path

    u=v₁,v₂,…,v_N=v

in H. Among the N−1 indices j, the sets defined by uv_{j+1}∈E(H) and
v_jv∈E(H) have total size at least N. Some j belongs to both. The order

    v₁,…,v_j,v_N,v_{N−1},…,v_{j+1},v₁

is a Hamiltonian cycle in H. Delete w to obtain a Hamiltonian path in G.
This is the usual Bondy–Chvátal closure argument, not a new theorem.

Primary attribution: J. A. Bondy and V. Chvátal,
[*A method in graph theory* (1976)](https://doi.org/10.1016/0012-365X(76)90078-9).
The small-independent-set case credits Chvátal–Erdős,
[*A note on Hamiltonian circuits* (1972)](https://doi.org/10.1016/0012-365X(72)90079-9).

## Exact residual scope

This proof uses κ=3 critically: outside a maximum column, each clique vertex
has at most one independent neighbor, making the private groups disjoint;
and each group has at least three clique vertices, so one can be reserved
without losing its two-neighbor detour. For κ≥4 the first property fails.
No claim of arbitrary cycle-factor patching is made in that regime.
