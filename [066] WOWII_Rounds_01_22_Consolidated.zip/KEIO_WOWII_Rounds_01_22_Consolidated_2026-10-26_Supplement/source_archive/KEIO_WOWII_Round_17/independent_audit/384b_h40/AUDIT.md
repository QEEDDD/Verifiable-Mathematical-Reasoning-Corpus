# Independent audit: matching-coupled repair at h=40

**Verdict: PASS.** Every finite simple connected graph with exactly forty vertices of degree at least three satisfies original WOWII 384b. No mathematical repair was requested. Combined with the earlier independently audited exclusions, the remaining high-vertex range is **11≤h≤39**. The separate representative-order bound remains **42**. This is not a full closure.

Audited manuscript: `round_17/twodomination/matching_h40.tex`, SHA-256 `a09bb02212ce0f403ce5e20683b48d09903acc7e78ab9a61b510fdb52b4e3743`. Author checker hash: `4c53641c6efce77949522a5052eea980883933ce4feff214965a5aba0c80198e`. Original files, certificate and primary dependency are snapshotted or copied below this directory.

## 1. Exact original statement and critical configuration

The pinned archived row 384b requires `gamma_2 <= floor(n-|T|/2)`, where T is the set of **distinct per-vertex triangle counts**. Definition 90 is ordinary 2-domination: only vertices outside the selected set require two selected neighbors. Thus, for `k=n-gamma_2`, the exact equivalent statement is `|T|<=2k`. No total, double, or tuple domination is substituted.

Every low vertex (full degree at most two) has triangle count zero or one, so t≤h+2=42. A locally maximum cut of the high-induced graph gives an omittable high side of size at least twenty: each vertex omitted has at least half its high neighbors across the cut, while all its low neighbors are selected. Full degree at least three then ensures two selected neighbors. Hence k≥20. A violation forces k=20 and t≥41. There must be at least 39 distinct counts at least two, represented by high vertices, leaving at most one exceptional high vertex. This argument does not require low-vertex independence or any attachment classification.

## 2. Fresh audit of the published matching input

The cached primary author manuscript `DGH_PV_kdomination2011.pdf/.txt` was read, including the definitions, **Theorem 3**, Lemma 7, and its entire proof (printed pp.1–3). Its low-degree set consists of full-degree vertices below 2k−1; the asserted bound is gamma_k ≤ matching number of the remaining induced graph + size of the low set. The matching symbol is explicitly defined on page 1. For k=2 this is exactly the needed `gamma_2 <= mu(H)+|L|`.

Theorem 3 has **no** hypothesis that low vertices are independent or that no two vertices of degree below two are adjacent. That extra hypothesis belongs to the separate Theorem 5 and is not imported here.

The proof is valid: take a maximum cut of the high graph and its bipartite crossing graph. A maximum matching and alternating reachability from unmatched vertices in one side yield a set `D ∪ (S\C)` of size exactly the matching. There are no crossing edges from C to T\D, so every omitted high vertex has at least half its high neighbors in this set. Adding all low vertices gives at least k selected neighbors whenever its full degree is at least 2k−1. This proves the bound directly, with the crossing matching no larger than the high graph's matching number. It is not a blind citation to an earlier AI manuscript.

At h=40, `gamma_2=|L|+20` therefore forces `mu(H)>=20`. A matching on forty vertices has at most twenty edges, so the high graph has a perfect matching. The archived primary author PDF is retained under `sources/`; its original URL is [Clemson author manuscript](https://people.computing.clemson.edu/~goddard/papers/kDomination.pdf). A fresh web open redirected to an inaccessible endpoint, but the complete previously recovered primary PDF/text were available and read locally; no source-content uncertainty remains for the theorem used.

## 3. Full-degree triangle-rank profile

For a chosen representative v_i, let d be its **full** degree, u its triangle count, and r the number of missing edges among its neighbors. At least d−2r neighbors meet no missing edge. For such a neighbor w, the triangles containing w inside the closed neighborhood number
`(d−1)+binom(d−1,2)−r = binom(d,2)−r = u`.
Thus w has at least u≥2 triangles and is high. At most 39−i later representatives plus the one exceptional high vertex can have count at least u. Therefore `40−i >= d−2r = 2u−d(d−2)`. With u≥i+1 this gives the stated inequality `d(d−2)>=3i+2−40`, while `binom(d,2)>=i+1` is immediate.

This correctly counts full-neighborhood triangles, even with low neighbors. The lower bounds, independently recomputed for all ranks, are:
`3^3, 4^3, 5^4, 6^5, 7^6, 8^7, 9^6, 10^6`.
The exceptional vertex contributes only the valid full-degree lower bound three. No distinctness assumption is imposed on its triangle count.

## 4. Coupled repair and artificial supports

Initially select a uniform fourteen-element high set S and all low vertices. For each matched pair, normally add its bad endpoints. If both are bad and at least one has one initial selected neighbor, add just an appropriate endpoint: add the zero-support endpoint if present, otherwise either one. The other endpoint then has its initial selected neighbor and its distinct, newly added matched partner. Both-zero requires two additions. Every pair can be handled simultaneously, since pairs are disjoint and no initially selected vertex is removed. Additional repairs elsewhere can only help.

For two initially unselected endpoints, the cost is two only at (0,0), zero only when both supports are at least two, and one otherwise. Capping supports at two gives exactly the displayed coordinatewise nonincreasing cost matrix. If one endpoint was selected, the other needs an addition precisely when its support is below two; this is also monotone.

For an assigned full-degree lower bound a, the artificial high-neighbor set can always contain the true matched partner. If there are at least a actual high neighbors, choose a of them. Otherwise use all of them and arbitrary fillers. The number of fillers is at most the number of low neighbors, all selected initially. Consequently actual support dominates artificial support **for every S**, not merely on average. Artificial sets need not be symmetric or realizable as one graph. They are used only for pairwise support lower bounds, while the matched edge is always a genuine edge. Pointwise cost monotonicity therefore justifies summing artificial expected costs. This is the crucial safeguard against a false graph-realization assumption.

## 5. Exact event counting and finite arithmetic certificate

The bad-event count F includes the requirement that its endpoint is outside S. For a pair, after removing both endpoints, the artificial neighborhoods partition into c common vertices, a−1−c left-only vertices, b−1−c right-only vertices, and h−a−b+c neutral vertices. Saving one repair occurs exactly when both supports are at most one and their sum is positive. Its possibilities are: one selected common vertex; one selected exclusive vertex on either side; or one selected exclusive vertex on each side. This gives exactly the manuscript's Q formula. All possible intersections are included by `0<=c<min(a,b)`; with a,b≤10 and h=40 there is no extra feasibility lower bound.

The independent checker recomputes Q by summing the four-category choices, rather than copying the closed formula. All **192** inequalities `beta_a+beta_b<=Q(a,b,c)` pass; the minimum slack is zero. Negative beta values are harmless: only the explicitly verified pair inequalities are used. The weights need not be optimal, and neither their discovery method nor an optimization solver is a proof dependency.

The exact independently reproduced values are:

- `binom(40,14) = 23206929840`;
- baseline expectation `120019687/5927696`;
- total matching-saving lower bound `1245979/3592404`;
- final upper bound `92365610053/4641385968`;
- strict margin below twenty `462109307/4641385968 > 0`.

An integer-valued selected-set size with expectation below |L|+20 has an outcome of size at most |L|+19, contradicting the critical value. This closes the h=40 case universally.

## 6. Independent controls and reproduction

`check_independent.py` imports no author checker. Besides the exact certificate, it performs:

- **4,246** direct category/event-formula cases, including empty/full sample sizes, with **408,232** explicit samples;
- **12,339** physical graphs built from matched high cores of orders 2,4,6, with leaves, shared degree-two triangle vertices, and pendant two-edge arms as forced-low attachments;
- **787,212** actual initial sets, verifying both actual and artificial repair plans really 2-dominate every omitted high vertex, and actual cost never exceeds artificial cost;
- **10,287** tested physical graphs whose artificial neighbor sets are asymmetric;
- fresh exact DGH matching-bound checks on all **1,253** Atlas graphs, including disconnected and edgeless cases.

The low-attachment controls explicitly include adjacent low vertices, confirming that no hidden independence assumption entered the implementation. These physical tests are supplementary; only the finite integer certificate and analytic proof establish the arbitrary-order result.

The author checker was also reread and rerun from a snapshot. Its stored certificate is reproduced exactly, including its 1,297 direct counting controls. The separate h=11 MILP experiments are not proof dependencies. Previous h≤10 and h≥41 exclusions, and the order-42 reduction, remain the earlier independently audited results; none was silently strengthened here.

## Scope and priority

Mathematical PASS is unconditional within the original finite-simple-graph setting, using the verified published matching theorem. Original 384b remains open beyond the excluded ranges. No new full-conjecture count increment is warranted. The related near-complete-neighborhood literature is contextual rather than an additional theorem dependency, and worldwide publication priority is not certified by this audit.
