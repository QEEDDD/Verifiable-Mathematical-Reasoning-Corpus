"""Independent category-count certificate and physical paired-repair controls."""
from math import comb
from fractions import Fraction
from itertools import combinations,product
from collections import Counter
from pathlib import Path
import json
import networkx as nx

def C(n,j):return comb(n,j) if 0<=j<=n else 0

def paircounts(h,s,a,b,c):
 # Direct four-category sample count: common, left-only, right-only, neutral.
 common,left,right,neutral=c,a-1-c,b-1-c,h-a-b+c
 saved=0
 for z,x,y in product(range(2),repeat=3):
  if z+x<=1 and z+y<=1 and 2*z+x+y>0:
   saved+=C(common,z)*C(left,x)*C(right,y)*C(neutral,s-z-x-y)
 bad=lambda d:sum(C(d,j)*C(h-1-d,s-j) for j in (0,1))
 return bad(a)+bad(b)-saved,saved

h,s=40,14;D=C(h,s)
beta=dict(zip(range(3,11),(923276120,775290440,571290100,413052400,236242200,49774300,-137436500,-389725340)))
profile=[3]
for i in range(1,h):
 feasible=[d for d in range(3,h) if d*(d-1)>=2*(i+1) and d*(d-2)>=3*i+2-h]
 profile.append(min(feasible))
counts=Counter(profile);slacks=[]
for a in beta:
 for b in beta:
  if a>b:continue
  for c in range(min(a,b)):
   cost,save=paircounts(h,s,a,b,c)
   slack=save-beta[a]-beta[b];assert slack>=0
   slacks.append({'a':a,'b':b,'common':c,'saving':save,'slack':slack})
bad=lambda a:sum(C(a,j)*C(h-1-a,s-j) for j in (0,1))
baseline=Fraction(s*D+sum(bad(a) for a in profile),D)
saving=Fraction(sum(beta[a] for a in profile),D)
upper=baseline-saving;margin=20-upper
assert D==23206929840 and upper==Fraction(92365610053,4641385968) and margin==Fraction(462109307,4641385968)>0

# Larger direct sample enumeration than the author check, including s=0,h.
formula_cases=0;sample_tests=0
for hh in range(3,12):
 for aa in range(1,hh):
  for bb in range(aa,hh):
   for cc in range(max(0,aa+bb-hh),min(aa,bb)):
    common=set(range(2,cc+2));left=set(range(cc+2,aa+1));right=set(range(aa+1,aa+bb-cc))
    A=common|left|{1};B=common|right|{0};assert len(A)==aa and len(B)==bb and max(A|B)<hh
    cost_by_size=[0]*(hh+1);save_by_size=[0]*(hh+1)
    for mask in range(1<<hh):
     selected={v for v in range(hh) if mask>>v&1};x=len(A&selected);y=len(B&selected)
     bad0=(0 not in selected and x<2);bad1=(1 not in selected and y<2)
     saved=int(bad0 and bad1 and x+y>=1)
     cost_by_size[len(selected)]+=bad0+bad1-saved;save_by_size[len(selected)]+=saved;sample_tests+=1
    for ss in range(hh+1):
     cost,sv=paircounts(hh,ss,aa,bb,cc);assert cost==cost_by_size[ss] and sv==save_by_size[ss];formula_cases+=1

# Physical simple graphs: fixed perfect matching in the high core;
# low attachments include leaves, degree-two triangle vertices, and pendant P2s.
def plan(H,A,S):
 out=S
 for u in range(0,len(H),2):
  v=u+1
  bu=not(S>>u&1) and A[u]<2;bv=not(S>>v&1) and A[v]<2
  if bu and bv:
   if A[u]==A[v]==0:out|=(1<<u)|(1<<v)
   elif A[u]==0:out|=1<<u
   else:out|=1<<v
  else:
   if bu:out|=1<<u
   if bv:out|=1<<v
 return out
physical_graphs=physical_samples=asymmetric_sets=0
for hh in (2,4,6):
 fixed={(i,i+1) for i in range(0,hh,2)};other=[e for e in combinations(range(hh),2) if e not in fixed]
 for mask in range(1<<len(other)):
  H=[0]*hh
  for u,v in fixed|{e for j,e in enumerate(other) if mask>>j&1}:H[u]|=1<<v;H[v]|=1<<u
  for mode in range(3):
   # Low-neighbor counts of actual graphs. Mode 1 adds one degree-two
   # vertex on every matched edge; mode 2 attaches a pendant P2 at every high.
   L=[int(mode>0) for _ in range(hh)]
   for u in range(hh):L[u]+=max(0,3-H[u].bit_count()-L[u])
   A=[]
   for u in range(hh):
    partner=u^1;actual=[v for v in range(hh) if H[u]>>v&1]
    a=min(hh-1,H[u].bit_count()+L[u])
    if mode==0:a=min(a,3)
    elif mode==2:a=max(1,a-1)
    chosen=[partner]+[v for v in reversed(actual) if v!=partner][:a-1]
    if len(chosen)<a:chosen += [v for v in range(hh) if v!=u and v not in chosen][:a-len(chosen)]
    A.append(sum(1<<v for v in chosen));assert A[-1].bit_count()==a and A[-1]>>partner&1
   asymmetric_sets+=any(bool(A[u]>>v&1)!=bool(A[v]>>u&1) for u,v in combinations(range(hh),2))
   for S in range(1<<hh):
    actual=[(H[u]&S).bit_count()+L[u] for u in range(hh)];art=[(A[u]&S).bit_count() for u in range(hh)]
    assert all(x>=y for x,y in zip(actual,art))
    P=plan(H,actual,S);Q=plan(H,art,S)
    assert P.bit_count()<=Q.bit_count()
    for T in (P,Q):assert all((T>>u&1) or (H[u]&T).bit_count()+L[u]>=2 for u in range(hh))
    physical_samples+=1
   physical_graphs+=1

# Fresh exact control of the published DGH bound on all Atlas graphs,
# including isolated vertices and disconnected graphs.
def matching(A,V):
 if not V:return 0
 u=(V&-V).bit_length()-1;best=matching(A,V&~(1<<u))
 for v in range(len(A)):
  if A[u]>>v&1 and V>>v&1:best=max(best,1+matching(A,V&~(1<<u)&~(1<<v)))
 return best
DGH_checks=0
for G in nx.graph_atlas_g():
 n=len(G);A=[sum(1<<v for v in G[u]) for u in G];high=sum(1<<u for u in range(n) if len(G[u])>=3);mu=matching(A,high)
 gamma=n
 for S in range(1<<n):
  if S.bit_count()>=gamma:continue
  if all(S>>u&1 or (A[u]&S).bit_count()>=2 for u in range(n)):gamma=S.bit_count()
 assert gamma<=n-high.bit_count()+mu;DGH_checks+=1
print(json.dumps({'status':'PASS','profile':profile,'degree_multiplicities':dict(counts),'denominator':D,'inequalities':len(slacks),'minimum_dual_slack':min(z['slack'] for z in slacks),'baseline':str(baseline),'matching_saving_lower_bound':str(saving),'expectation_upper_bound':str(upper),'strict_margin':str(margin),'direct_category_formula_cases':formula_cases,'explicit_sample_tests':sample_tests,'physical_graphs':physical_graphs,'physical_samples':physical_samples,'physical_graphs_with_asymmetric_artificial_sets':asymmetric_sets,'DGH_exact_graph_controls':DGH_checks,'dual_checks':slacks,'scope':'Exact finite arithmetic certifies the universal expectation; direct event, physical-repair, and DGH graph checks are supplemental.'},indent=2))
