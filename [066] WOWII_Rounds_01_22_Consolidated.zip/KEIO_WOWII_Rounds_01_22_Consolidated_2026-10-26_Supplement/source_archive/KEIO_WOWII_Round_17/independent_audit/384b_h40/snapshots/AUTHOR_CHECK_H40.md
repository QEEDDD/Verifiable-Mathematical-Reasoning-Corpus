# Author checks: h=40 matching repair

Authoritative files are `matching_h40.tex`, `check_matching_h40.py`, and `matching_h40_certificate.json`.

- Exact checker passes all 192 overlap inequalities across 36 type pairs.
- Rank degree multiplicities reconstructed directly from the two integer inequalities.
- Repair-cost coordinatewise monotonicity checked on every capped-support pair.
- Saving-event formula checked by direct set enumeration in 1,297 small parameter cases.
- Strict expectation margin: 462109307/4641385968 > 0.
- No optimizer, external graph catalogue, or third-party Python package is a certificate dependency.
- PDF compiled twice with no remaining warnings/overfull boxes; all four pages rendered and visually inspected.
- Independent audit remains required before promotion.

Frozen hashes:

```
a09bb02212ce0f403ce5e20683b48d09903acc7e78ab9a61b510fdb52b4e3743  matching_h40.tex
4c53641c6efce77949522a5052eea980883933ce4feff214965a5aba0c80198e  check_matching_h40.py
```

The separate h11 MILP models are inconclusive discovery experiments, not dependencies.
