#!/usr/bin/env python3
"""Exact arithmetic certificate for a matching-coupled repair at h=40.
No optimizer, graph catalogue, or third-party package is used.
"""
from collections import Counter
from fractions import Fraction
from math import comb
from pathlib import Path
import json

H,S=40,14
def C(n,k): return comb(n,k) if 0 <= k <= n else 0
DEN=C(H,S)
def lower(i):
    return next(d for d in range(3,H) if C(d,2)>=i+1 and d*(d-2)>=3*i+2-H)
profile=[3]+[lower(i) for i in range(1,H)]
counts=Counter(profile)
assert counts=={3:3,4:3,5:4,6:5,7:6,8:7,9:6,10:6}
# Integral dual weights, scaled by DEN. They may be negative.
BETA={3:923276120,4:775290440,5:571290100,6:413052400,
      7:236242200,8:49774300,9:-137436500,10:-389725340}
def bad(d): return C(H-1-d,S)+d*C(H-1-d,S-1)
def saving(a,b,c):
    other=H-a-b+c
    return ((a+b-2-c)*C(other,S-1)
            +(a-1-c)*(b-1-c)*C(other,S-2))
checks=[]
for a in sorted(counts):
    for b in sorted(counts):
        if b<a: continue
        vals=[]
        for c in range(max(0,a+b-H),min(a,b)):
            q=saving(a,b,c)
            assert BETA[a]+BETA[b] <= q
            vals.append(dict(common=c,saving_numerator=q,
                             dual_slack=q-BETA[a]-BETA[b]))
        checks.append(dict(a=a,b=b,common_neighbor_checks=vals))
base=S*DEN+sum(counts[d]*bad(d) for d in counts)
save=sum(counts[d]*BETA[d] for d in counts)
upper=Fraction(base-save,DEN)
margin=20-upper
assert upper==Fraction(92365610053,4641385968)
assert margin==Fraction(462109307,4641385968)>0
# Monotonicity of the two-endpoint repair cost, including initial selection.
# When both endpoints are unselected, 0/1/2 denotes capped initial support.
def cost(a,b): return 2 if (a,b)==(0,0) else 0 if (a,b)==(2,2) else 1
for a in range(3):
    for b in range(3):
        for aa in range(a,3):
            for bb in range(b,3): assert cost(aa,bb)<=cost(a,b)
# Direct counting controls: materialize every set for small analogous h.
# These do not prove the h40 formula, but independently catch formula mistakes.
from itertools import combinations
controls=0
for h in range(4,10):
    for s in range(1,h):
        den=C(h,s)
        for a in range(1,h):
            for b in range(a,h):
                for c in range(max(0,a+b-h),min(a,b)):
                    shared=set(range(2,2+c)); pos=2+c
                    left=set(range(pos,pos+a-1-c));pos+=a-1-c
                    right=set(range(pos,pos+b-1-c))
                    Av={1}|shared|left;Aw={0}|shared|right
                    nsave=0
                    for tup in combinations(range(h),s):
                        T=set(tup)
                        if 0 in T or 1 in T:continue
                        x=len(Av&T);y=len(Aw&T)
                        nsave+=int(x<=1 and y<=1 and x+y>=1)
                    q=((a+b-2-c)*C(h-a-b+c,s-1)
                       +(a-1-c)*(b-1-c)*C(h-a-b+c,s-2))
                    assert nsave==q
                    controls+=1

def rat(x):return dict(numerator=x.numerator,denominator=x.denominator,decimal=float(x))
result=dict(scope='Finite rational certificate for a universal h=40 exclusion; independent audit pending.',
 h=H,sample_size=S,denominator=DEN,profile=profile,degree_multiplicities=dict(counts),
 dual_weights=BETA,type_pairs=len(checks),overlap_checks=sum(len(t['common_neighbor_checks']) for t in checks),
 direct_small_set_controls=controls,baseline=rat(Fraction(base,DEN)),
 matching_saving_lower_bound=rat(Fraction(save,DEN)),upper_bound=rat(upper),strict_margin=rat(margin),
 pair_checks=checks)
Path(__file__).with_name('matching_h40_certificate.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('pair_checks','profile')},indent=2))
