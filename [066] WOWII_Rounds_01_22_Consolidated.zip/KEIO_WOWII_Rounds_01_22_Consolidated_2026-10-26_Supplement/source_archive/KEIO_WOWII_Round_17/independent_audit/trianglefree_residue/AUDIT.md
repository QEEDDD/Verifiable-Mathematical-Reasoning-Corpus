# Independent audit: first forest–residue equality in triangle-free graphs

**Verdict: PASS.** For every finite connected triangle-free graph with an edge, `f(G)=res(G)+1` holds exactly for stars and C4. Here f is maximum **induced forest vertex order**. The stronger intermediate statement for side-only maximum independent sets in bipartite graphs also passes. No mathematical repair was needed.

This is an auxiliary equality classification. It proves original WOWII 61 for triangle-free diameter at most six, and the induced-matching candidate only for connected triangle-free graphs with induced matching number at most two. It does **not** close either unrestricted conjecture.

## Pinned manuscript and original statement

The final author TeX `round_17/independence/manuscript.tex`, SHA-256 `65ec89e4bdee5071a4dd973aa57d8fbf37c6be6440971622d79c329e055f87f4`, was read in full, including the added triangle-free corollary and the limited consequences. It matches the mathematics of `proof.md`; the final related-work paragraph supplies context only, not a proof input. Snapshots and hashes accompany this report.

The archived original row 61 is `f(G) >= res(G) + ceil(diam(G)/3)` for simple connected graphs. Its forest and residue definitions, and the diameter definition, are pinned here. No connected-tree number, non-induced forest, edge count, or different residue is substituted.

## Mathematical audit

### Baseline and maximum independent sets

For a connected graph with an edge, a maximum independent set plus any vertex outside it induces a star and isolates, so `f>=alpha+1>=res+1`. The outside vertex exists. The one-vertex exception is correctly separated.

In a bipartite graph, if a maximum independent set I omits vertices a,b from opposite sides, their I-neighborhoods are disjoint. The induced graph on I+a+b is two stars, possibly joined at the centers, and isolates. It cannot contain a cycle, even if ab is present. Equality `f=alpha+1` therefore forces I to contain an entire side; absence of isolated vertices forces I to equal that side. This proves the side-only restriction, not merely existence of one side which is maximum.

### Unequal sides: switch and cover certificate

With |A|=p>|B|=q, the side-only hypothesis makes A the unique maximum independent set. For every nonempty X⊆B, the alternative independent set `X ∪ (A\N(X))` gives strict Hall `|N(X)|>=|X|+1`. Hence deleting any w∈A preserves Hall saturation of B. When q>=2, connectivity supplies a w with two B-neighbors u,v. In a matching of G−w saturating B, their partners a,b are distinct from each other and w.

The switch `au,bv -> ab,uv` is legal: all four switched endpoints are distinct, and the added same-part edges were absent. Degrees are unchanged. The triangle wuv, edge ab, and q−2 remaining matching edges are vertex-disjoint subgraphs of the new realization. Any vertex cover therefore has size at least q+1, irrespective of other edges; thus its independence number is at most p−1. Degree-sequence invariance and the classical residue bound give the desired strict residue loss. The q=1 exception is exactly a star.

### Equal sides: the conformal cycle exists

The side-only hypothesis gives strict Hall on nonempty proper subsets. A perfect matching follows, including the full-set condition: a subset of size q−1 already has all q opposite vertices as neighbors. Contracting its matched pairs into the stated directed index graph gives an outgoing arc from every nonempty proper index set, which is equivalent to strong connectivity.

A directed cycle with at least three indices yields a simple alternating even cycle on those matched pairs, with the remaining matching edges covering its complement. If there is no such directed cycle, every arc has its reverse: a shortest directed return path of length at least two would form a forbidden cycle. The underlying undirected graph is then a connected tree. For q>=3 it contains i−j−k; all six displayed bipartite cycle edges follow respectively from matching edges or the two pairs of reverse arcs. Its vertices are distinct, and the other matching edges certify conformality. This verifies the sometimes delicate bidirected-tree branch; no Hamiltonian or induced cycle is being assumed.

### Balanced switch

On a conformal cycle of order 2k>=6, replacing `c0c1,c3c4` by `c0c4,c1c3` is a legal degree-preserving switch because the inserted edges are within the bipartition classes. The two displayed odd cycles have lengths 3 and 2k−3 and are vertex-disjoint. Their cover lower bound is `2+(k−1)=k+1`; the outside perfect matching contributes q−k more. Thus the new realization has independence number at most q−1. Chords and other outside edges cannot invalidate this lower bound on vertex covers. The small balanced cases are K2 and C4, exactly as stated.

### Equality and triangle-free extension

Equality `f=res+1` forces both `f=alpha+1` and `res=alpha`; the strictness theorem excludes every nonexceptional bipartite graph. Stars and C4 have the stated exact f and residue values, including K2.

For a general triangle-free graph, an edge uv outside a maximum independent set has disjoint neighborhoods in that independent set (a common neighbor would form a triangle). The induced graph on I+u+v is again a forest of order alpha+2. Therefore `f=alpha+1` forces the complement of I to be independent, proving bipartiteness. This is sufficient and does not presume a special maximum independent set.

### Exact consequence calibration

For diameter at most three, the baseline already proves original 61; the isolated one-vertex graph is checked separately. For triangle-free diameter four, five or six the required ceiling is two, and neither exceptional graph has such diameter. Nothing here yields the ceiling three required at diameter seven. Both stars and C4 have induced matching number one, so the classification also proves the stronger candidate when induced matching number is at most two, but not in general.

## Established inputs and primary-source check

The only residue theorem required is the classical `res<=alpha`, credited to Favaron–Mahéo–Saclé (1991). This is the same input independently checked in the earlier forest/unigraph audits. Its transparent dependency derivation was reread: graphical majorization gives maximum-positive-degree deletion monotonicity, then induction gives `res(G)<=res(G−v)<=alpha(G−v)<=alpha(G)`; the edgeless base is equality. No reversal of the strong Havel–Hakimi class implication is used.

The primary Levit–Mandrescu arXiv:math/9912120v1 Theorem 2.5 and its relevant proof were read, not merely a secondary summary. It confirms the classical balanced/bistable strict-Hall antecedent. The needed implication is also proved directly in the manuscript, so the classification does not depend on unreviewed external structure results. [Primary version](https://arxiv.org/pdf/math/9912120v1), printed pp.5–6. A copy is retained under `sources/`.

Hall's theorem and elementary vertex-cover/independence complementation are standard inputs. The Yu/Iľkovič comparison concerns larger-part-size forest bounds, not residue; those papers are contextual and not mathematical dependencies. The separate source-priority checkpoint is `round_17/source_audit/61/priority_checkpoint.md`. This audit makes no worldwide-priority certification.

## Independent computation

`check_independent.py` starts from the separately covered mask catalogs through order nine, rather than the author's extracted bipartite bundle. It independently computes forests by a union-find cycle test, independent sets by subset recursion, and residue with an ascending-list HH implementation. For every nonexceptional side-only bipartite graph, it searches legal edge-pair switches directly and verifies that a switched realization has no independent set of the old maximum size. It does not import the author's matching/directed-cycle constructor.

Results: all **273,192** connected representatives examined; **1,736** triangle-free, including **983** bipartite and **753** nonbipartite. There are **574** side-only bipartite graphs. All **565** nonexceptional instances admit independently found lowering switches: **535** unequal and **30** balanced. Exactly nine forest–residue equality examples occur: eight stars and C4. Every nonbipartite triangle-free instance satisfies `f>=alpha+2`. These finite results corroborate the proof, not replace it.

The author bundle and triangle-free scripts were additionally reviewed and rerun from snapshots; their outputs agree with the stored non-runtime counts. No claim of finite verification at arbitrary order is made.

### Final packaging-only bundle amendment

After the main proof freeze, the author added a standalone triangle-free graph6 bundle and optional input flags. The final bundled scripts were separately snapshotted under `final_bundled_controls/` and rerun successfully on 983 bipartite and 1,736 triangle-free records (`final_bundled_reruns.json`). The author manuscript/proof and all mathematical hashes remained unchanged. These extracted records are reproducibility conveniences, not the independent coverage source.
