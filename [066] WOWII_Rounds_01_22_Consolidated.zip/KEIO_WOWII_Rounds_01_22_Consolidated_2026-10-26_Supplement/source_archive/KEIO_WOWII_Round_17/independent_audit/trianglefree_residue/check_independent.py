"""Independent exact forest/IS/HH audit using certified mask catalogs.
The switch search is exhaustive over edge pairs, not the author's matching code.
"""
from pathlib import Path
from itertools import combinations
from collections import Counter
from functools import lru_cache
import networkx as nx
import json,time
ROOT=Path('wowii_rounds');start=time.monotonic();counts=Counter();equality=[];switches=Counter();diameters=Counter()
def bits(x):
 while x:
  b=x&-x;yield b.bit_length()-1;x^=b

def frommask(n,m):
 A=[0]*n
 for j,(v,w) in enumerate(combinations(range(n),2)):
  if m>>j&1:A[v]|=1<<w;A[w]|=1<<v
 return A

def connected(A):
 seen=1;front=1
 while front:
  nxt=0
  for v in bits(front):nxt|=A[v]
  front=nxt&~seen;seen|=front
 return seen==(1<<len(A))-1

def trianglefree(A):return all(not(A[u]&A[v]) for u in range(len(A)) for v in bits(A[u]) if u<v)
def bipartition(A):
 color={0:0};Q=[0]
 for u in Q:
  for v in bits(A[u]):
   if v in color:
    if color[v]==color[u]:return None
   else:color[v]=1-color[u];Q.append(v)
 X=sum(1<<v for v,c in color.items() if c==0);Y=((1<<len(A))-1)^X
 if X.bit_count()<Y.bit_count():X,Y=Y,X
 return X,Y

def inv(A):
 n=len(A);N=1<<n;ind=[False]*N;ind[0]=True;alpha=0;maxsets=[];f=0
 for S in range(1,N):
  u=(S&-S).bit_length()-1;T=S^(1<<u)
  ind[S]=ind[T] and not(A[u]&T)
  if ind[S]:
   k=S.bit_count()
   if k>alpha:alpha=k;maxsets=[S]
   elif k==alpha:maxsets.append(S)
  if S.bit_count()<=f:continue
  parent=list(range(n))
  def root(u):
   while u!=parent[u]:u=parent[u]
   return u
  good=True
  for u in bits(S):
   for v in bits(A[u]&S&~((1<<(u+1))-1)):
    x,y=root(u),root(v)
    if x==y:good=False;break
    parent[x]=y
   if not good:break
  if good:f=S.bit_count()
 return alpha,f,maxsets

def residue(A):
 D=[x.bit_count() for x in A]
 while any(D):
  D.sort();head=D.pop()
  for j in range(head):D[-1-j]-=1
  assert min(D,default=0)>=0
 return len(D)

def lowers_alpha(A,target):
 # Only existence of an independent target-set matters; use descending deletion.
 @lru_cache(None)
 def yes(S,k):
  if k==0:return True
  if S.bit_count()<k:return False
  u=max(bits(S),key=lambda u:(A[u]&S).bit_count())
  return yes(S&~(1<<u),k) or yes(S&~(A[u]|1<<u),k-1)
 return not yes((1<<len(A))-1,target)

def switch(A,X,Y,a):
 edges=[(u,v) for u in bits(X) for v in bits(A[u]&Y)]
 for (u,v),(w,z) in combinations(edges,2):
  if u==w or v==z:continue
  B=A.copy()
  for x,y in [(u,v),(w,z)]:B[x]^=1<<y;B[y]^=1<<x
  for x,y in [(u,w),(v,z)]:assert not(B[x]>>y&1);B[x]|=1<<y;B[y]|=1<<x
  assert list(map(int.bit_count,B))==list(map(int.bit_count,A))
  if lowers_alpha(B,a):return True
 return False

for n in range(2,10):
 if n<=6:graphs=([sum(1<<w for w in G[v]) for v in range(n)] for G in nx.graph_atlas_g() if len(G)==n)
 else:graphs=(frommask(n,int(m)) for m in (ROOT/f'round_11/twodomination/core{n}_masks.txt').read_text().split())
 for A in graphs:
  if not connected(A):continue
  counts['connected']+=1
  if not trianglefree(A):continue
  counts['triangle_free']+=1;a,f,M=inv(A);r=residue(A);partition=bipartition(A)
  star=max(map(int.bit_count,A))==n-1 # triangle-free forces every other edge absent
  C4=n==4 and all(x.bit_count()==2 for x in A)
  assert (f==r+1)==(star or C4)
  assert f>=a+1>=r+1
  if f==r+1:equality.append({'order':n,'degrees':sorted(map(int.bit_count,A)),'f':f,'alpha':a,'residue':r})
  if partition is None:
   counts['nonbipartite_triangle_free']+=1;assert f>=a+2
   for I in M:
    outside=((1<<n)-1)^I
    assert any(A[u]&outside for u in bits(outside))
  else:
   counts['bipartite']+=1;X,Y=partition
   only=all(I in (X,Y) for I in M)
   if f==a+1:assert only;counts['bipartite_forest_alpha_tight']+=1
   if only:
    counts['side_only']+=1
    if not(star or C4):
     assert r<=a-1 and switch(A,X,Y,a)
     switches['unequal' if X.bit_count()!=Y.bit_count() else 'balanced']+=1
print(json.dumps({'status':'PASS','counts':dict(counts),'independent_switch_realizations':dict(switches),'equality_examples':equality,'seconds':time.monotonic()-start,'scope':'All covered graph-mask representatives n<=9. Independent union-find forest test, subset independent sets, ascending-list HH, and unrestricted edge-pair switch search. Universal claims follow from analytic proof, not finite tests.'},indent=2))
