"""Exact small controls and explicit degree-switch certificates for the note.
This is author validation, not an independent audit or proof by computation.
"""
import argparse, collections, functools, hashlib, itertools, json, time
from pathlib import Path
import networkx as nx

def residue(G):
 D=sorted([len(G[u]) for u in G],reverse=True)
 while D and D[0]:
  d=D.pop(0)
  for j in range(d):D[j]-=1
  D.sort(reverse=True)
 return len(D)

def invariants(G):
 n=len(G);adj=[sum(1<<v for v in G[u]) for u in G]
 @functools.lru_cache(None)
 def alpha(S):
  if not S:return 0
  u=(S&-S).bit_length()-1
  return max(alpha(S&~(1<<u)),1+alpha(S&~((1<<u)|adj[u])))
 def forest(S):
  while S:
   for u in range(n):
    if S>>u&1 and (adj[u]&S).bit_count()<=1:S^=1<<u;break
   else:return False
  return True
 a=alpha((1<<n)-1);mx=[]
 for vv in itertools.combinations(range(n),a):
  S=sum(1<<v for v in vv)
  if all(not adj[u]&S for u in vv):mx.append(set(vv))
 f=next(k for k in range(n,-1,-1) if any(forest(sum(1<<v for v in vv)) for vv in itertools.combinations(range(n),k)))
 return a,f,mx

def certify(G,A,B):
 """Return switched realization, odd-cycle/edge cover certificate, branch."""
 p,q=len(A),len(B)
 if p>q:
  w=next(w for w in A if len(G[w])>=2);u,v=sorted(G[w])[:2]
  M=nx.bipartite.maximum_matching(G.subgraph(set(G)-{w}),top_nodes=B)
  assert all(b in M for b in B)
  a,b=M[u],M[v]
  removed=[(a,u),(b,v)];added=[(a,b),(u,v)]
  parts=[([w,u,v],2),([a,b],1)]+[([z,M[z]],1) for z in B-{u,v}]
  branch='unequal'
 else:
  M=nx.bipartite.maximum_matching(G,top_nodes=A);aa=sorted(A);bb=[M[a] for a in aa]
  assert len(M)==len(G)
  D=nx.DiGraph();D.add_nodes_from(range(q))
  D.add_edges_from((i,j) for i in range(q) for j in range(q) if i!=j and G.has_edge(aa[i],bb[j]))
  assert nx.is_strongly_connected(D)
  dc=next((cc for cc in nx.simple_cycles(D) if len(cc)>=3),None)
  if dc:
   C=[]
   for i,j in zip(dc,dc[1:]+dc[:1]):C.extend([aa[i],bb[j]])
   used=set(dc);branch='balanced_directed_cycle'
  else:
   T=D.to_undirected();assert nx.is_tree(T)
   j=next(j for j in T if len(T[j])>=2);i,k=sorted(T[j])[:2]
   C=[aa[i],bb[i],aa[j],bb[k],aa[k],bb[j]];used={i,j,k};branch='balanced_tree'
  assert all(G.has_edge(x,y) for x,y in zip(C,C[1:]+C[:1]))
  removed=[(C[0],C[1]),(C[3],C[4])];added=[(C[0],C[4]),(C[1],C[3])]
  odd1=C[1:4];odd2=C[4:]+C[:1]
  parts=[(odd1,(len(odd1)+1)//2),(odd2,(len(odd2)+1)//2)]+[([aa[i],bb[i]],1) for i in range(q) if i not in used]
 assert all(G.has_edge(*e) for e in removed) and all(not G.has_edge(*e) for e in added)
 H=G.copy();H.remove_edges_from(removed);H.add_edges_from(added)
 assert dict(G.degree())==dict(H.degree())
 used=set();lower=0
 for V,k in parts:
  assert not used.intersection(V);used.update(V);lower+=k
  if len(V)==2:assert H.has_edge(*V) and k==1
  else:
   assert len(V)%2==1 and k==(len(V)+1)//2
   assert all(H.has_edge(x,y) for x,y in zip(V,V[1:]+V[:1]))
 assert lower==q+1
 ah,_,_=invariants(H);assert ah<=p-1 and residue(G)<=p-1
 return branch

def main():
 p=argparse.ArgumentParser();p.add_argument('--bipartite-file',help='optional bundled extracted subset; full source completeness is recorded separately');p.add_argument('--graphs8',default='wowii_rounds/round_16/independence/controls/graph8c.g6');p.add_argument('--graphs9',default='wowii_rounds/round_01/leaves/graph9c.g6');args=p.parse_args()
 out={'scope':'author exact checks, not independent audit; proof is in accompanying note','sources':{},'connected_graphs':0,'connected_bipartite':0,'side_only':0,'forest_tight':0,'residue_forest_tight':0,'switch_branches':{}}
 for path in ([args.bipartite_file] if args.bipartite_file else [args.graphs8,args.graphs9]):out['sources'][path]=hashlib.sha256(Path(path).read_bytes()).hexdigest()
 counts=collections.Counter();st=time.monotonic()
 def graphs():
  if args.bipartite_file:
   for line in open(args.bipartite_file,'rb'):yield nx.from_graph6_bytes(line.strip())
   return
  yield from (G for G in nx.graph_atlas_g() if len(G)>=2 and nx.is_connected(G))
  for path in [args.graphs8,args.graphs9]:
   for line in open(path,'rb'):yield nx.from_graph6_bytes(line.strip())
 for G in graphs():
  out['connected_graphs']+=1
  if not nx.is_bipartite(G):continue
  out['connected_bipartite']+=1;a,f,maxsets=invariants(G);r=residue(G)
  color=nx.bipartite.color(G);A={u for u in G if color[u]==0};B=set(G)-A
  if len(A)<len(B):A,B=B,A
  only=all(I==A or I==B for I in maxsets)
  star=nx.is_tree(G) and max(dict(G.degree()).values())==len(G)-1
  C4=len(G)==4 and all(len(G[u])==2 for u in G)
  if f==a+1:out['forest_tight']+=1;assert only
  if f==r+1:out['residue_forest_tight']+=1;assert star or C4
  assert (f==r+1)==(star or C4)
  if only:
   out['side_only']+=1
   if not(star or C4):counts[certify(G,A,B)]+=1
 out['switch_branches']=dict(counts);out.update(status='PASS',seconds=time.monotonic()-st)
 print(json.dumps(out,indent=2))
if __name__=='__main__':main()
