"""Author finite control for the short triangle-free extension (not main proof)."""
import argparse,hashlib,itertools,json,time
from pathlib import Path
import networkx as nx
from check_bipartite_tight import invariants,residue
p=argparse.ArgumentParser();p.add_argument('--triangle-free-file',help='optional bundled extracted subset');p.add_argument('--graphs8',default='wowii_rounds/round_16/independence/controls/graph8c.g6');p.add_argument('--graphs9',default='wowii_rounds/round_01/leaves/graph9c.g6');a=p.parse_args()
out={'scope':'author finite control, not independent audit','connected_graphs':0,'triangle_free':0,'triangle_free_nonbipartite':0,'alpha_forest_tight':0,'residue_forest_tight':0,'sources':{x:hashlib.sha256(Path(x).read_bytes()).hexdigest() for x in ([a.triangle_free_file] if a.triangle_free_file else [a.graphs8,a.graphs9])}}
st=time.monotonic()
def graphs():
 if a.triangle_free_file:
  for line in open(a.triangle_free_file,'rb'):yield nx.from_graph6_bytes(line.strip())
  return
 yield from (G for G in nx.graph_atlas_g() if len(G)>=2 and nx.is_connected(G))
 for path in [a.graphs8,a.graphs9]:
  for line in open(path,'rb'):yield nx.from_graph6_bytes(line.strip())
for G in graphs():
 out['connected_graphs']+=1
 adj=[set(G[u]) for u in G]
 if any(adj[u]&adj[v] for u,v in G.edges()):continue
 out['triangle_free']+=1;al,f,M=invariants(G);r=residue(G);bip=nx.is_bipartite(G)
 if not bip:out['triangle_free_nonbipartite']+=1;assert f>=al+2
 if f==al+1:
  out['alpha_forest_tight']+=1;assert bip
  assert all(not G.subgraph(set(G)-I).number_of_edges() for I in M)
 exc=(nx.is_tree(G) and max(dict(G.degree()).values())==len(G)-1) or (len(G)==4 and all(len(G[u])==2 for u in G))
 assert (f==r+1)==exc
 if f==r+1:out['residue_forest_tight']+=1
out.update(status='PASS',seconds=time.monotonic()-st);print(json.dumps(out,indent=2))
