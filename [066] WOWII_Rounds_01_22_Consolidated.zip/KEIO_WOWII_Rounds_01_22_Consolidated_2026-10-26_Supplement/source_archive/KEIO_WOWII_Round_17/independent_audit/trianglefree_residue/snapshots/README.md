# Round17: bipartite first equality case

`manuscript.tex` is the standalone English mathematical manuscript (KEIO,
11pt, lmodern, xurl, one-inch margins). It has not been compiled here; the
parent handles compilation and visual QA. `proof.md` is the frozen proof
note from which it was expanded. Independent audit and priority review
are separate, pending processes; no full original WOWII closure is claimed.

**Theorem:** a connected triangle-free graph with an edge has `f=res+1`
exactly when it is a star or C4. All other connected triangle-free graphs have
`f>=res+2`. Consequences are precisely original61 for triangle-free diameter
at most six and the candidate `f>=res+im` for connected triangle-free `im<=2`.
Larger diameter or induced matching number, and general graphs containing triangles
cases, remain open in this argument.

## Reproduce the controls

Requires Python 3 and NetworkX (author environment: 3.7). From this folder:

```sh
python controls/check_bipartite_tight.py \
  --bipartite-file controls/bipartite_connected_2_to_9.g6
```

The bundled 983 graph6 records are the connected bipartite subset of all
connected unlabeled graphs of orders 2--9. Records through order7 come
from `networkx.graph_atlas_g()`. The orders8/9 source files and their hashes
are recorded in `controls/bipartite_tight_results.json`; the full-source
scan examined 273,192 connected graphs. The bundled-subset rerun checks
exactly the same 983 eligible graphs and all 565 switch certificates; its
result is `controls/bundled_subset_results.json`. The subset is small and
self-contained, but its exhaustiveness rests on those source collections,
not on treating an arbitrary bundled list as complete.

The script enumerates maximum independent sets and induced forests,
computes ordinary Havel--Hakimi residue, builds both kinds of degree
switches, and validates the disjoint odd-cycle/matching cover certificate.
It also computes the switched graph's exact independence number. These
are author controls, not the independent audit and not a proof substitute.

## Status boundaries

- The first equality classification has a complete proof in the note.
- Full original #61 and general `f>=res+im` remain unresolved here.
- Earlier P5 independent-blow-up work is subsumed by this bipartite result
  and is not counted a second time.
- The tempting strengthening `f>=alpha+im` is false even for bipartite
  graphs: C4 with a pendant leaf at each of two opposite vertices has
  `(f,alpha,im,res)=(5,4,2,3)`.
- No publication novelty is asserted without the source-priority gate.

The triangle-free extension has a separate full-source author control:
`controls/check_triangle_free_corollary.py` and `triangle_free_results.json`.
It checks 1,736 connected triangle-free graphs through order9, including
753 nonbipartite graphs, and finds the same nine equality exceptions.
The primary balanced strict-Hall antecedent is explicitly credited to
Levit--Mandrescu (1999), Theorem2.5, in the manuscript.

A second tiny extracted graph6 bundle makes the triangle-free control
self-contained as well:

```sh
python controls/check_triangle_free_corollary.py \
  --triangle-free-file controls/triangle_free_connected_2_to_9.g6
```

Its output is `controls/bundled_triangle_free_results.json`. As with the
bipartite subset, catalog completeness is inherited from the separately
hashed original source collections.
