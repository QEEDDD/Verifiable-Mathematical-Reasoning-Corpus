# A residue-strictness lemma for connected bipartite graphs

**Research status:** complete argument below, submitted for independent audit.
Not part of the frozen Round16 unigraph paper. No full original WOWII
conjecture is claimed closed. Literature priority has not been certified.

Write `r` for Havel--Hakimi residue, `alpha` for independence number, and
`f` for the maximum order of an **induced** forest. We use the established
inequality `r(H)<=alpha(H)` for every graph H and the fact that residue
only depends on the degree sequence. These are credited inputs, not new
claims (Favaron--Maheo--Sacle, *J. Graph Theory* 15 (1991), 39--64,
DOI 10.1002/jgt.3190150107; see also the audited residue dependencies in
Round12).

## 1. A maximum-independent-set restriction

**Lemma.** Let G be a connected bipartite graph with at least one edge,
with bipartition `(A,B)`. If `f(G)=alpha(G)+1`, then every maximum
independent set is either A or B.

**Proof.** Let I be maximum. If I omits both some `a in A` and some
`b in B`, then the neighborhoods of a and b within I are disjoint:
`N(a) intersect I` lies in B, and `N(b) intersect I` lies in A. Therefore
`G[I union {a,b}]` consists of two stars, possibly joined by the edge ab,
and isolated vertices. It is an induced forest of order `alpha+2`, a
contradiction. Thus I contains all of one side. Every vertex has positive
degree, so independence prevents adding any vertex of the other side.
Hence I is precisely one of the two sides. QED.

## 2. Strict residue loss except for stars and C4

**Theorem.** Let G be a connected bipartite graph with at least one edge.
Suppose every maximum independent set is a bipartition class. If G is
neither a star nor C4, then

`r(G) <= alpha(G)-1`.

**Proof, unequal sides.** Relabel so `|A|=p>|B|=q`. The hypothesis forces
A to be the unique maximum independent set, and `alpha=p`. For any
nonempty `X subset B`, the independent set
`X union (A minus N(X))` differs from A, so it has order at most p-1.
Consequently `|N(X)|>=|X|+1`.

If q=1, G is a star, which is excluded. If q>=2, connectivity gives a
vertex `w in A` with two distinct neighbors `u,v in B`. The strict Hall
inequalities show that G-w has a matching M saturating B. Write `au,bv`
for the edges of M incident with u,v. The vertices a,b,w are distinct.
Make the degree-preserving switch

`au,bv -> ab,uv`.

The added edges were absent because G was bipartite. The resulting graph
G' contains the vertex-disjoint subgraphs

- the triangle `w,u,v`;
- the edge `a,b`;
- the q-2 other edges of M.

Every vertex cover of G' therefore has at least `2+1+(q-2)=q+1`
vertices. Thus `alpha(G')<=p-1`, and
`r(G)=r(G')<=alpha(G')<=p-1`.

**Proof, equal sides.** Write `|A|=|B|=q=alpha`. If `X` is a nonempty
proper subset of A, then `X union (B minus N(X))` is an independent set
that equals neither A nor B. Therefore `|N(X)|>=|X|+1`. Hall's theorem
gives a perfect matching

`M={a_i b_i : 1<=i<=q}`.

Define a directed graph D on the matching indices by adding an arc
`i -> j` whenever `i!=j` and `a_i b_j` is an edge of G. Every nonempty
proper set of indices has an outgoing arc, by the strict Hall
inequalities. Thus D is strongly connected.

We show that if q>=3, G has an even cycle of length at least six whose
vertex complement has a perfect matching. Such a cycle is called
*conformal* here; no inducedness is asserted or needed.

If D contains a directed cycle of length k>=3, its arcs, together with
the k corresponding matching edges, give a conformal cycle of length
2k. Otherwise, for every arc `i -> j`, a shortest directed return path
from j to i must have length one: a longer one would form a directed
cycle of length at least three. Thus all arcs occur in reverse pairs.
The underlying undirected graph is connected and has no cycle, since
an undirected cycle would give a directed cycle of length at least three.
It is therefore a tree. For q>=3 it contains a path `i-j-k`; the six
vertices of these three matching pairs contain the cycle

`a_i, b_i, a_j, b_k, a_k, b_j, a_i`.

This is conformal, using the other edges of M as its outside matching.

Label the vertices of a conformal cycle of length `2k>=6` consecutively
`c_0,...,c_(2k-1)`. Delete `c_0 c_1` and `c_3 c_4`, and insert
`c_0 c_4` and `c_1 c_3`. The inserted edges were absent, since their
endpoints are in the same bipartition class. Degrees are preserved.
The new graph contains two vertex-disjoint odd cycles: the triangle
`c_1,c_2,c_3`, and the cycle
`c_4,c_5,...,c_(2k-1),c_0` of length `2k-3`. Together their vertex
covers require at least `2+(k-1)=k+1` vertices. The q-k outside matching
edges require a further q-k vertices. Hence every vertex cover has
size at least q+1, proving `r(G)<=alpha(G')<=q-1` as before.

The remaining cases are q=1, which is K2 (a star), and q=2. The strict
Hall inequalities then force all four possible edges, so G=C4. QED.

## 3. Exact forest-tight classification and limited WOWII consequence

**Corollary.** For a connected bipartite graph with an edge,

`f(G)=r(G)+1` if and only if G is a star or C4.

**Proof.** Always `f>=alpha+1>=r+1`, since a maximum independent set
plus one other vertex induces a star and isolates. Equality `f=r+1`
forces `f=alpha+1` and `alpha=r`, so the lemma and theorem exclude all
other graphs. A star with q leaves has `f=q+1`, `r=q`; C4 has `f=3`,
`r=2`. QED.

Consequently every connected bipartite graph other than a star or C4
satisfies `f>=r+2`. In particular this establishes the diameter-four
threshold (W) on **all bipartite graphs**, and original #61 on connected
bipartite graphs of diameter 4, 5, or 6. It also proves the candidate
`f>=r+im` for connected bipartite graphs of induced matching number at
most two (im=1 is immediate). It does **not** prove original #61 for
arbitrary bipartite diameter at least seven, nor the full candidate for
larger induced matching number, nor the P5-free conclusion for general
forest-tight graphs.

The earlier independent-P5-blow-up argument is now a special case of
this broader bipartite result. Its exact invariant formulas remain a
separate useful check; they are not counted as an additional closure.

## 4. Triangle-free extension

For a connected triangle-free graph with an edge, `f=res+1` also holds
exactly for stars and C4. Indeed equality forces `f=alpha+1`. For a maximum
independent set I, any edge uv outside I has disjoint neighborhoods in I
by triangle-freeness; therefore I+u+v induces a forest of order alpha+2.
This is impossible, so the complement of I is independent and G is
bipartite. The preceding classification applies. Thus the stated D<=6
and im<=2 consequences extend to all connected triangle-free graphs,
without asserting either unrestricted bound.

### Classical structural credit

The balanced side-only maximum-independent-set condition is called
bistability. Its equivalence with strict Hall inequalities and with
connectedness plus every edge lying in a perfect matching is classical:
Levit--Mandrescu, *Matrices and alpha-stable bipartite graphs*,
arXiv:math/9912120v1 (1999), Theorem 2.5. The direct implication used above
is reproduced for completeness, not claimed as new.
