# Round 17: bounded priority review of the forest–residue tight classification

Checked 2026-10-26, approximately 06:19–06:22 UTC. This is a source/priority review, not the mathematical audit and not a worldwide originality certificate.

## Result and scope

**No exact prior theorem was located in the sources checked** for the proposed statement: for a finite simple connected triangle-free graph with an edge,

> `f(G) = res(G) + 1` if and only if `G` is a star or `C4`.

Here `f` is the maximum **order of an induced forest**, and `res` is the Havel–Hakimi residue. The proposed argument first treats bipartite graphs, then shows that triangle-free equality `f=alpha+1` forces bipartiteness. The implied original WOWII #61 result is restricted to triangle-free graphs of diameter at most six; **unrestricted #61 is not closed**. The induced-matching consequence is also only the stated subclass result, not the unrestricted auxiliary conjecture.

This bounded finding supports reporting an independently proved partial/subclass result with the antecedents below. It does not support “first proof,” “new method,” or an assertion that no other relevant result exists.

## Exact catalogue and public-status controls

* Original archived row 61, dated March 25, 2004, reads `f(G) >= res(G) + CEIL[diam(G)/3]` for simple connected graphs; definitions 41, 42, 14. `statement61.json` preserves the pinned row. Its historical O is not being used as proof of present unresolved status.
* The Formal Conjectures source fetched in this pass still has `category research open` and an unproved declaration for this exact formula. The bytes are saved as `formal61_current.lean`; this is a retrieval-time observation, not a claim of formal verification. [Current source](https://github.com/google-deepmind/formal-conjectures/blob/main/FormalConjectures/WrittenOnTheWallII/GraphConjecture61.lean).
* c5-k4's pinned `method_v02_61.md` describes construction searches and explicitly distinguishes an empty search from a theorem; it does not claim a full solution. [Pinned report](https://github.com/Kuberwastaken/c5-k4/blob/e2cee93231eefb91c41e35450f7eeb19fd9c8c75/results/expansion/method_v02_61.md). Saved as `c5_method_v02_61.md`.
* Fresh GitHub API issue searches, **all states**, are retained in `api_summary.json` plus raw responses: FormalConjectures `GraphConjecture61` gave zero hits; `residue forest` gave two reports, #4573/#4583, both concerning the different conjecture #59; `bistable` gave zero; agentic-conjectures `residue forest` gave zero. The two #59 bodies were inspected rather than dismissed by title alone. Exact-number query absence alone was not treated as decisive.
* Focused indexed searches included triangle-free/induced-forest/residue, bistable/Havel–Hakimi, elementary-bipartite/Havel–Hakimi, degree-sequence/two-maximum-independent-sets, and forest/residue/stars. None located this classification. Search indexing and terminology can miss work; no exhaustive repository, language, unpublished, or historical literature survey is claimed.

## Established antecedents and the actual distinction

1. **O. Favaron, M. Mahéo, J.-F. Saclé**, *On the residue of a graph*, Journal of Graph Theory **15** (1991), 39–64, DOI [10.1002/jgt.3190150107](https://doi.org/10.1002/jgt.3190150107). The classical `res<=alpha` and degree-sequence dependence are credited inputs, not new results. The entire 1991 paper was not newly recovered in this pass; the established dependency and primary later statements were reused.

2. **V. E. Levit and E. Mandrescu**, *Matrices and α-Stable Bipartite Graphs*, [arXiv:math/9912120](https://arxiv.org/abs/math/9912120) (1999); published Journal of Universal Computer Science **13**(11) (2007), 1692–1706. Full arXiv text was downloaded and read. **Theorem 2.5** already identifies bistability with strict Hall inequalities on nonempty proper partite subsets and with connectedness plus every edge lying in a perfect matching. **Proposition 3.4** gives the fully indecomposable matrix characterization; the ensuing discussion identifies bistable and elementary bipartite graphs. This is a direct classical antecedent of the balanced structural step. The paper does not state a Havel–Hakimi-residue or induced-forest result. Its strict-Hall argument must not be presented as a new structural discovery.

3. **M. D. Barrus and G. Molnar**, *Graphs with the strong Havel–Hakimi property*, Graphs and Combinatorics **32** (2016), 1689–1697, DOI [10.1007/s00373-015-1674-7](https://doi.org/10.1007/s00373-015-1674-7), [arXiv:1505.00085](https://arxiv.org/abs/1505.00085). The already cached primary manuscript was inspected. Theorems 1 and 5 give a forbidden-induced-subgraph characterization of the **strong Havel–Hakimi class** and `res=alpha` on that class. This is not a characterization of all graphs with `res=alpha`, and it does not directly give the proposed strictness theorem for all bistable graphs. Reversing the implication would be invalid.

4. **Lixiang Yu**, *Forest number of bipartite graphs under Ore-type degree sum and common neighbor conditions*, author-uploaded preprint dated June 15, 2026; [author full text](https://www.researchgate.net/publication/407072917_Forest_number_of_bipartite_graphs_under_Ore-type_degree_sum_and_common_neighbor_conditions); [SSRN DOI 10.2139/ssrn.7592679](https://doi.org/10.2139/ssrn.7592679), whose record was posted October 10. This is relevant **different equality literature**: with part sizes `m<=n`, Proposition 2.3 restates `f=n+1` through cyclicity of all selected `n+2`-vertex induced subgraphs, Theorem 2.6 gives a sufficient same-part degree-sum condition, and Theorem 2.11 gives sharp Ore-type upper bounds. Its `n` is the larger part size, **not residue**. The author-uploaded searchable full text was inspected and contains no Havel–Hakimi/residue conclusion. The direct SSRN/PDF endpoints failed (403/503 and a bad ResearchGate PDF link); those failures are not counted as negative evidence. The readable author text, not a secondary summary, supports this comparison.

5. **Daniel Iľkovič**, *Maximum Forest Number of General Bipartite Graphs: Structural and Complexity Results*, [arXiv:2606.26761](https://arxiv.org/abs/2606.26761), June 25, 2026. The full primary PDF was downloaded and inspected. Its Theorem 3.1 optimizes `f` over Ore-constrained bipartite families; it has no residue invariant. Its separate complexity claim is not needed or mathematically audited here. It does not supply the present residue classification simply by replacing a part size with residue.

6. **O. Kadrawi and V. E. Levit**, *Annihilation, Independence, and Residue: Sharp Matching Bounds for the Annihilation Gap and a TxGraffiti Application*, [arXiv:2607.01438](https://arxiv.org/abs/2607.01438), July 1, 2026. The retrieved primary manuscript was screened, including its residue section: it treats annihilation gaps and a TxGraffiti inequality, using `res<=alpha`; no induced-forest/bistable residue-strictness classification was located. The work is not an input to the new proof.

The proposed remaining step, as formulated by the author, is a degree-preserving realization switch yielding an independent-set upper bound strictly below the original bipartition-class size. This note does **not** certify novelty of that switch technique or of conformal-cycle facts.

## Packaging / limits

Include this note, `api_summary.json`, `statement61.json`, and `compact_provenance.json` in a compact bundle if desired. Full third-party PDFs and raw API bodies may stay in the research cache. Public-source hashes document what was inspected; none of the external Lean files or literature proofs were reverified in Lean. Live curator knowledge, unpublished proofs, nonindexed papers, and worldwide priority remain uncertified.
