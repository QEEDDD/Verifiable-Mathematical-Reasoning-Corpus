# Bounded degree-sequence 2-domination source follow-up

2026-10-26 06:24–06:25 UTC; responding to the active #389a research lane's request.

No primary source was located in this focused pass for a universal mixed-degree upper bound `gamma_2(G)<=sum_v c(deg(v))` having coefficients near 1/2 at degrees 3–5 and decreasing above degree 5. This is not a nonexistence claim.

* Bujtás–Jaskó, *Bounds on the 2-domination number*, [arXiv:1612.08301](https://arxiv.org/abs/1612.08301), published Discrete Applied Mathematics 242 (2018), DOI [10.1016/j.dam.2017.05.014](https://doi.org/10.1016/j.dam.2017.05.014): the primary manuscript's Theorem 1 fixes **global** minimum degree d>=6 and parameters satisfying its linear inequalities, and concludes `(a/s)n`. The evolving weight assignment is not a published permission to apply a different minimum-degree constant independently at each original vertex. Local full text reused from `round_08/source_audit/new_routes/bujtas_jasko_2dom.txt`.
* DeLaViña–Goddard–Henning–Pepper–Vaughan, *Bounds on the k-Domination Number of a Graph*, manuscript January 5, 2011, Theorem 3 gives `gamma_k <= mu(G-H)+|H|`, where H consists of vertices of degree below 2k-1. Thus for k=2, H={degree<=2}. This previously credited bound is genuine and useful, but not the requested decreasing high-degree coefficient sum. Cached primary text: `round_08/source_audit/new_routes/DGH_PV_kdomination2011.txt`.
* The degree-sequence searches also retrieve sub-k-domination (a **lower** bound), upper-median bounds, and double/total/Roman/Italian domination results. None was silently substituted for an upper bound on the ordinary outside-vertex 2-domination parameter.

Searches used 2-domination / degree sequence / weighted / degree-based / upper bounds and k-domination variants. Existing references and the two primary full texts above were rechecked. No proof attempt or new resolution is claimed.

## Matching-coupled alteration follow-up

The h=40 manuscript's repair step was read: initially select S plus all low vertices; among two bad matched endpoints, save one repair when at least one endpoint already has one selected neighbor. Focused primary searches for 2-domination with matching/random/probabilistic/alteration located the general probabilistic and dynamic-weight literature, but no exact prior formula for the manuscript's matched-pair event and fixed-size sampling expression. This is not a novelty certificate for the elementary repair idea. General random selection followed by repairing deficient vertices is an established probabilistic technique and should not be marketed as newly invented. The manuscript explicitly credits the already known matching bound and gives its repair argument self-containedly; that is the appropriate presentation.
