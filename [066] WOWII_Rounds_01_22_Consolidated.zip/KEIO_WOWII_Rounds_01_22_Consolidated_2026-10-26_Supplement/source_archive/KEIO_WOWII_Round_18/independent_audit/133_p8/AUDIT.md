# Independent audit: P8-free local-independence classification

**Verdict: PASS, computer-assisted theorem; partial original WOWII133 coverage only.**

The universal mathematical argument and its complete finite proof certificate both pass. This is not a conclusion extrapolated from a bounded-order search. The accepted new part is the triangle-containing classification and its weighted-density consequence; the three triangle-free exceptions are the explicitly credited prior theorem of Chudnovsky–Stacho.

## Audited versions

- `p8_min_local_classification.md`: `97c3811ced12987b88b519aa4e5ef4b363b4d5e33a55b990d9ecefb88d6a0ca9`.
- `p8_manuscript.tex`: `cd0d7accf189028b597bd6ced884a4e1680271551ee074c085aefd7ff48ac659`.
- `verify_p8_core_certificate.py`: `bd2bc56745f0f07159325444b0801d7e50d4f6e6530734d7b335d9d96a3df2c3`.
- `p8_core_certificate.json.gz`: `d7be0e33ac427e6ed0aabeef4e69efd50be0ebd7a05063a30bee4aa42fe31982`.

All are snapshotted here. Status-only later revisions, if any, are recorded separately. The builder and its canonical-labeling software are not proof dependencies.

## 1. Mathematical completion argument

In a graph with no C4 as a **subgraph**, every neighborhood has maximum degree one. Consequently its independence number is degree minus the number of triangles through the vertex. This gives exactly L=2m−3t and deletion cost 2 lambda(v)−t(v), including isolated vertices.

The deficient-neighborhood extension lemma is valid at arbitrary order. If every new neighbor of u met an old neighbor, the matching property of the full neighborhood would force each new neighbor to pair with a different previously isolated old neighbor. No additional new-new or old-neighbor edge could occur. Each such replacement preserves local independence, contradicting its strict increase. Hence a required new neighbor anticomplete to the old neighborhood exists.

The exact contact conditions are exhaustive: the pivot is present, none of its old neighbors is present, and each pair of contacts has no common old neighbor. The last condition is precisely the absence of a new four-cycle. Choosing a designated deficient pivot separately in each certificate state loses no target embedding. Canonical labels do not need to agree with the embedding: the supplied permutation transports it.

The verified certificate is closed and well-founded by graph order. An induced embedding of a nonterminal state in a target graph extends by the lemma; its row cannot be a rejected P8, so it embeds a state of one greater order. There are only finitely many states and every allowed extension is accounted for. The process must reach the terminal H. This proves the containment lemma without any assumed bound on the target order. Observed maximum state order 25 is not a cutoff.

## 2. Terminal attachments and converse

All nonempty contact sets at H were independently enumerated. Only singleton contacts at the three triangle vertices can survive C4/P8 exclusion. The three displayed rooted P6s are induced; prepending a distance-two vertex and its predecessor gives an induced P8, since their precise contacts are known. Connectedness therefore eliminates all further layers.

Cross-edges between distinct root classes create a four-cycle through the triangle edge. A three-vertex path within one class creates a four-cycle through its root. Thus each class is a matching plus isolates and the classes are anticomplete.

The converse is valid for arbitrarily many simultaneous attachments. Attachments make only pendant edges and triangles, so cannot create a C4. A path meeting H can use at most one vertex from an attachment at either end. If it uses two different roots, their adjacency forces their core segment to be just one edge; if the roots coincide the path has order at most three. With one exterior endpoint, an induced P8 would be a forbidden rooted P7 in H, excluded by the exhaustively checked single-leaf extension. Paths entirely outside H have order at most two. Every added vertex has local independence one, so no proper extension satisfies minimum local independence at least three.

This completes the triangle-containing classification once the exact certificate is verified.

## 3. Independent certificate implementation

`check_independent.py` imports no author code and no graph package. It uses an exhaustive subset dynamic program for contact sets, rather than the author's recursive clique enumerator; checks relabeled edge-set equality for permutations; and checks path witnesses by distinctness, consecutive edges, and exactly seven total induced edges. It also uses a separate forbidden-set induced-path search for all negative checks.

Results (`independent_results.json`):

- **192 states**, all reachable and recursively closed; maximum order **25**.
- **3,788,806 candidate subsets** explicitly accounted for, giving **93,895** required legal extensions.
- All **93,608 induced-P8 witnesses** pass.
- All **287 explicit retained-extension permutations** pass and strictly increase order.
- The sole terminal is state **191**; its supplied permutation to H passes.
- H was independently constructed from the seven lines of PG(2,2), building the Heawood incidence graph, deleting one point, and joining its three line neighbors. The independently found explicit permutation agrees with the manuscript's adjacency table.
- All **8,191 nonempty contact subsets** at H were examined, without assuming their size. Exactly 13 singletons and 30 pairs are C4-compatible; all larger sets fail. Independent path searches reproduce all 40 rejections and exactly the three singleton survivors. Contact lists were additionally checked for distinct valid entries.
- All three rooted distance-two P8 witnesses pass.
- **500 fresh simultaneous decorations**, up to order 56, pass direct C4/P8 and local-independence checks.
- The author's standard-library verifier was rerun successfully from the snapshot. Its structural counts and certificate hash agree exactly; only elapsed time naturally differs.

The finite certificate is a proof dependency, not a heuristic check. Both implementations reproduce it exactly. Optional builder correctness and discovery searches are immaterial.

## 4. Published triangle-free input

Primary source: Chudnovsky–Stacho, *3-colorable subclasses of P8-free graphs*, SIAM J. Discrete Math. 32(2) (2018), 1111–1138, DOI 10.1137/16M1104858. The author-hosted primary version is dated October 1, 2017:
https://web.math.princeton.edu/~mchudnov/p8free1.pdf

Theorem 1 on printed page 2 states exactly: a connected graph of girth at least five with no induced P8 is Petersen, Heawood, an edge-contracted Heawood, or has a vertex of degree at most two. Its definitions and full Section 3 proof (printed pp.4–11, claims (0)–(12)) were read, not a secondary paraphrase. In the present triangle-free branch, strong C4 exclusion gives girth at least five and lambda equals degree, so all hypotheses match. This is a credited published dependency, not a new classification claim or an unreviewed AI-manuscript input.

Cached primary PDF: `round_09/source_audit/partial_priority/Chudnovsky_p8free1.pdf`, SHA-256 `f6d71a367c70ff23ad78d418cb086031e5f254503000d87284eda00403c04db1`. The primary source need not be redistributed with the audit packet.

The independent checker also constructs all four exceptional graphs directly and verifies their hypotheses and (n,L) pairs: (10,30), (14,42), (13,40), (13,39). Their exact induced-path orders are respectively 5,7,7,7.

## 5. Density induction and conjecture calibration

For a vertex with local independence at most two, the potential deletion cost is at most four. Strong C4/P8 exclusion is hereditary. Induct on the positive order, allowing disconnected graphs; handle order one explicitly. Otherwise each component is one of the four exceptions, each with L<4n, and their strict bounds sum. Thus the strict density conclusion is valid for every nonempty graph in the class.

Original133 uses the **unrounded** average local independence and excludes C4 as a subgraph in its exponent. The prior all-ell<=4 range remains a separately audited dependency (Round15). The new density consequence gives p>=8 whenever ell>4 in the strong-C4-free branch. Therefore it supplies exactly the announced additions:

- radius 3 with ell<=5;
- radius 2 with ell<=6.

If C4 is present, the exponent is zero and a geodesic supplies the required p>=r+1. No claim for every graph with ell<=5 is justified: radius 4 with 4<ell<=5 remains outside this result. Unrestricted original133 remains open. Classical Heawood/Y–Delta provenance is appropriately credited; worldwide priority is outside this mathematical audit.

## Consolidation

The full standalone `p8_manuscript.tex` was read and compared with the note. It preserves the extension, finite closure, attachment, converse, induction, and exact parameter scope. No mathematical repair was requested. The adjacency table is independently verified. Parent handles PDF rendering and final delivery-format comparison.
