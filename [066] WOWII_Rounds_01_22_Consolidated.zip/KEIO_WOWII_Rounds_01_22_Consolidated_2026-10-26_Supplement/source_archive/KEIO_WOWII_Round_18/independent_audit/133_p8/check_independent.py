"""Independent standard-library verification: exhaustive subset contacts,
edge-set permutations, direct path checks, Fano-plane terminal construction.
No author code or graph library is imported.
"""
from pathlib import Path
from itertools import combinations
from collections import Counter
import gzip,json,hashlib,time,random
ROOT=Path(__file__).resolve().parent;start=time.monotonic()
def bits(x):
 while x:
  b=x&-x;yield b.bit_length()-1;x-=b

def graph(a):
 n=len(a);assert all(type(x)==int and 0<=x<1<<n for x in a)
 E={frozenset((i,j)) for i in range(n) for j in bits(a[i])}
 assert all(len(e)==2 for e in E)
 assert all(bool(a[i]>>j&1)==bool(a[j]>>i&1) for i,j in combinations(range(n),2))
 assert all((a[i]&a[j]).bit_count()<=1 for i,j in combinations(range(n),2))
 return E

def local(a,u):
 V=list(bits(a[u]));return len(V)-sum(bool(a[v]>>w&1) for v,w in combinations(V,2))

def path(a,p):
 assert len(p)==8 and len(set(p))==8 and all(type(u)==int and 0<=u<len(a) for u in p)
 assert sum(bool(a[u]>>v&1) for u,v in combinations(p,2))==7
 assert all(a[u]>>v&1 for u,v in zip(p,p[1:]))

def longest(a,cap=8):
 # A forbidden-set recursion: prohibit all neighbors of earlier vertices,
 # except those of the current endpoint. Every extension is induced.
 best=0
 def visit(last,blocked,used,depth):
  nonlocal best
  best=max(best,depth)
  if best>=cap:return
  opts=a[last]&~blocked&~used
  for v in bits(opts):
   visit(v,blocked|a[last],used|(1<<v),depth+1)
   if best>=cap:return
 for u in range(len(a)):
  visit(u,0,1<<u,1)
  if best>=cap:break
 return best

def extension(a,S):
 n=len(a);b=a.copy()+[S]
 for u in bits(S):b[u]|=1<<n
 return b

def iso(a,b,p):
 assert len(a)==len(b)==len(p) and set(p)==set(range(len(a)))
 EA={frozenset((p[i],p[j])) for i in range(len(a)) for j in bits(a[i])}
 EB={frozenset((i,j)) for i in range(len(b)) for j in bits(b[i])}
 assert EA==EB

def from_edges(n,edges):
 a=[0]*n
 for u,v in edges:a[u]|=1<<v;a[v]|=1<<u
 return a

def induced(a,vs):
 return [sum(1<<j for j,v in enumerate(vs) if a[u]>>v&1) for u in vs]

def find_iso(a,b):
 n=len(a);p={};used=set()
 def go():
  if len(p)==n:return list(p[i] for i in range(n))
  u=max((u for u in range(n) if u not in p),key=lambda u:(sum(a[u]>>v&1 for v in p),a[u].bit_count()))
  for v in range(n):
   if v in used or a[u].bit_count()!=b[v].bit_count():continue
   if any(bool(a[u]>>x&1)!=bool(b[v]>>y&1) for x,y in p.items()):continue
   p[u]=v;used.add(v);r=go()
   if r is not None:return r
   del p[u];used.remove(v)
  return None
 return go()

# Construct the Heawood graph from the seven lines of PG(2,2), not graph6.
lines=[T for T in combinations(range(1,8),3) if T[0]^T[1]^T[2]==0]
assert len(lines)==7
heawood=from_edges(14,[(p-1,7+j) for j,T in enumerate(lines) for p in T])
nh=list(bits(heawood[0]));yd=heawood.copy()
for u,v in combinations(nh,2):yd[u]|=1<<v;yd[v]|=1<<u
yd=induced(yd,list(range(1,14)))
# Independently transcribe the manuscript adjacency table.
N=[[1,2,3,9],[0,2,4,12],[0,1,5,10],[0,6,7],[1,7,11],[2,7,8],[3,10,12],[3,4,5],[5,9,12],[0,8,11],[2,6,11],[4,9,10],[1,6,8]]
core=[sum(1<<v for v in T) for T in N];graph(core)
mapping=find_iso(core,yd);assert mapping is not None;iso(core,yd,mapping)
assert all(local(core,u)==3 for u in range(13)) and longest(core)==7

raw=(ROOT/'snapshots/p8_core_certificate.json.gz').read_bytes();data=json.loads(gzip.decompress(raw));states=data['states'];counts=Counter();arcs=[]
assert data['root']==0 and states[0]['adjacency']==[6,5,3]
orders=Counter();subset_counts=0;terminal_ids=[]
for sid,st in enumerate(states):
 a=st['adjacency'];n=len(a);graph(a);assert longest(a)<8;orders[n]+=1
 if st.get('terminal'):
  assert all(local(a,u)>=3 for u in range(n));iso(a,core,st['terminal_isomorphism']);terminal_ids.append(sid);continue
 u=st['pivot'];assert type(u)==int and 0<=u<n and local(a,u)<3
 # Enumerate ALL subsets of the candidates; not recursive clique generation.
 choices=[v for v in range(n) if v!=u and not(a[u]>>v&1) and not(a[u]&a[v])]
 q=len(choices);conflicts=[sum(1<<j for j,w in enumerate(choices) if j!=i and a[v]&a[w]) for i,v in enumerate(choices)]
 valid=bytearray(1<<q);valid[0]=1;expected={1<<u};subset_counts+=1<<q
 for S in range(1,1<<q):
  b=S&-S;j=b.bit_length()-1;R=S^b
  if valid[R] and not(R&conflicts[j]):
   valid[S]=1;expected.add((1<<u)|sum(1<<choices[k] for k in bits(S)))
 rows=st['extensions'];observed=[r['mask'] for r in rows]
 assert all(type(S)==int and 0<S<1<<n for S in observed)
 assert len(set(observed))==len(observed) and set(observed)==expected
 for row in rows:
  b=extension(a,row['mask']);counts['extensions']+=1
  if 'P8' in row:
   path(b,row['P8']);counts['P8_witnesses']+=1
  else:
   tid=row['target'];assert type(tid)==int and 0<=tid<len(states)
   assert len(states[tid]['adjacency'])==n+1
   iso(b,states[tid]['adjacency'],row['isomorphism']);arcs.append((sid,tid));counts['explicit_isomorphisms']+=1
assert len(terminal_ids)==1
reachable={0};todo=[0]
while todo:
 s=todo.pop()
 for u,v in arcs:
  if s==u and v not in reachable:reachable.add(v);todo.append(v)
assert reachable==set(range(len(states)))
# A stronger explicit well-founded closure check: every state is classified
# by descending order, so no hidden target outside the certificate is used.
closed=set(terminal_ids)
for sid in sorted(range(len(states)),key=lambda j:len(states[j]['adjacency']),reverse=True):
 if sid not in closed:
  assert all(t in closed for s,t in arcs if s==sid);closed.add(sid)
assert len(closed)==len(states)

# Every one of 8191 nonempty contact subsets at H; no size assumption.
allowed=set();contact_hist=Counter()
for S in range(1,1<<13):
 V=list(bits(S))
 if all(not(core[u]&core[v]) for u,v in combinations(V,2)):allowed.add(S);contact_hist[len(V)]+=1
assert dict(contact_hist)=={1:13,2:30}
rows=json.loads((ROOT/'snapshots/weighted_core_contact_certificates.json').read_text());seen=set();survivors=[]
for row in rows:
 V=row['contacts'];assert len(V)==len(set(V)) and all(type(v)==int and 0<=v<13 for v in V)
 S=sum(1<<v for v in V);assert S not in seen;seen.add(S);b=extension(core,S);graph(b)
 # Independently search every case, not merely validate supplied positives.
 p=longest(b)
 if row['P8'] is None:
  assert p==7;survivors.append(V)
 else:
  path(b,row['P8']);assert p==8
assert seen==allowed and sorted(survivors)==[[0],[1],[2]]
for P in ([0,1,4,7,5,8],[1,0,3,6,10,11],[2,0,3,6,12,8]):
 a=extension(core,1<<P[0]);a=extension(a,1<<13);path(a,[14,13]+P)

# All four exceptional graphs from elementary constructions, including exact p.
pairs=list(combinations(range(5),2));petersen=from_edges(10,[(i,j) for i,j in combinations(range(10),2) if not(set(pairs[i])&set(pairs[j]))])
v=nh[0];remain=[i for i in range(14) if i!=v];idx={u:i for i,u in enumerate(remain)};E=set()
for i in range(14):
 for j in bits(heawood[i]):
  x,y=(0 if i==v else i),(0 if j==v else j)
  if x!=y:E.add(tuple(sorted((idx[x],idx[y]))))
contracted=from_edges(13,E);exceptions=[]
for name,a in [('Petersen',petersen),('Heawood',heawood),('contracted_Heawood',contracted),('Y_Delta_Heawood',yd)]:
 graph(a);L=sum(local(a,u) for u in range(len(a)));p=longest(a)
 assert min(local(a,u) for u in range(len(a)))>=3 and p<8 and L<4*len(a)
 exceptions.append(dict(name=name,n=len(a),m=sum(x.bit_count() for x in a)//2,L=L,p=p))

# Fresh simultaneous decorations: direct C4/P8 tests, all added lambda=1.
rng=random.Random(1331808);decoration_counts=Counter()
for trial in range(500):
 a=core.copy();added=matched=0
 for u in range(3):
  n=rng.randrange(16);V=[]
  for _ in range(n):V.append(len(a));a=extension(a,1<<u);added+=1
  rng.shuffle(V)
  for j in range(0,len(V)-1,2):
   if rng.randrange(2):
    x,y=V[j:j+2];a[x]|=1<<y;a[y]|=1<<x;matched+=1
 graph(a);assert longest(a)<8 and all(local(a,u)==1 for u in range(13,len(a)))
 assert sum(local(a,u) for u in range(len(a)))==39+2*added-matched
 decoration_counts['graphs']+=1;decoration_counts['maximum_order']=max(decoration_counts['maximum_order'],len(a))

out={'status':'PASS','certificate_sha256':hashlib.sha256(raw).hexdigest(),'states':len(states),'state_orders':dict(sorted(orders.items())),'all_candidate_subsets_checked':subset_counts,**counts,'terminal_ids':terminal_ids,'maximum_state_order':max(orders),'reachable_states':len(reachable),'closed_states':len(closed),'terminal_mapping_to_Fano_Y_Delta':mapping,'all_terminal_contact_subsets_checked':(1<<13)-1,'admissible_contact_sizes':dict(contact_hist),'terminal_contact_survivors':survivors,'rooted_distance_two_P8_witnesses':3,'exception_graphs':exceptions,'independent_decoration_controls':dict(decoration_counts),'seconds':time.monotonic()-start,'scope':'Exact independent certificate verification; universal force relies on the separately audited completion and attachment arguments.'}
print(json.dumps(out,indent=2))
