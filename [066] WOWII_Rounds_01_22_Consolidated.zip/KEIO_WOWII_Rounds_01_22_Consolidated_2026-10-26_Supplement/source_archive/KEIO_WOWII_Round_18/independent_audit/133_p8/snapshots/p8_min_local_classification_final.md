# A finite-certificate extension of the P8-free local-independence classification

**KEIO — 26 October 2026.**

**Status:** computer-assisted theorem; independent mathematical, implementation, and final-TeX audits PASS. The bounded source review found no exact prior triangle-containing classification or full-class weighted bound. No unrestricted WOWII133 closure or worldwide-priority claim is made.

## 1. Statement and notation

All graphs are finite and simple. A four-cycle is forbidden as a subgraph, even if it has chords. Let p be the maximum vertex order of an induced path, and let

    λ(v)=α(G[N(v)]),  L(G)=Σ_v λ(v),  ell=L/n.

In a C4-subgraph-free graph every open neighborhood induces a matching plus isolated vertices. Hence λ(v)=d(v)−t(v), where t(v) counts triangles through v, and

    L(G)=2m−3t,
    L(G)−L(G−v)=2d(v)−3t(v)=2λ(v)−t(v).

Let H be the 13-vertex graph obtained from the Heawood graph by removing one vertex and joining its three neighbors pairwise (a Y–Delta move). We use the labeled graph6 representation `L{O__wC_HC@BOg`; its triangle is T={0,1,2}.

**Theorem A.** If G is connected, C4-subgraph-free, P8-free, and λ(v)≥3 for every vertex, then G is exactly one of:

1. the Petersen graph;
2. the Heawood graph;
3. the Heawood graph with one edge contracted;
4. H.

The triangle-free part (the first three graphs) is the prior theorem of Chudnovsky–Stacho, Theorem 1. The new part asserted here is the triangle-containing case. In particular, the first three cases must not be presented as new classifications.

**Corollary B.** Every nonempty C4-subgraph-free P8-free graph satisfies

    L(G)<4|V(G)|.

The classification is stronger than the potential-deletion statement needed for Corollary B: except for the four listed graphs, a connected graph in the class has a vertex with λ(v)≤2, and therefore deletion cost at most four.

## 2. The exhaustive extension lemma

**Lemma 1.** Let F be an induced subgraph of a C4-subgraph-free graph G with λ_G(v)≥3 at every vertex. If u∈V(F) has λ_F(u)<3, there is a vertex x∈V(G)\V(F) adjacent to u and anticomplete to N_F(u).

**Proof.** In both graphs, the neighborhood of u is a matching plus isolates. Suppose every new neighbor of u were adjacent to some old neighbor in N_F(u). No new neighbor can have two such contacts, no old neighbor can meet two new ones, and none of these new neighbors can have another neighbor inside N_G(u), because the neighborhood is a matching. Thus each new neighbor simply extends a formerly isolated old neighbor into a matched pair. This does not change the independence number of the neighborhood, contradicting λ_G(u)≥3>λ_F(u). ∎

For such an x, its contact set S=N_G(x)∩V(F) necessarily satisfies:

- u∈S;
- S∩N_F(u)=∅;
- no two vertices of S have a common neighbor in F.

Conversely the third condition is exactly what prevents a four-cycle through the newly added x; F is already C4-subgraph-free. Consequently all possible one-vertex extensions required by Lemma 1 can be listed by enumerating cliques in the compatibility graph whose edges join pairs with no common neighbor in F, with the first two restrictions imposed.

The choice of deficient vertex u is arbitrary. In particular it may be chosen separately in each finite certificate state, without losing a possible target graph.

## 3. A closed finite certificate

The file `p8_core_certificate.json.gz` contains a finite directed certificate rooted at the labeled triangle. Each state specifies an adjacency list as integer bitmasks. A nonterminal state specifies a vertex u with λ_F(u)<3 and accounts for **every** contact set S satisfying the preceding three conditions. For each extension F+x it supplies exactly one of:

- eight distinct vertices that induce P8; or
- a target state of order |V(F)|+1 and an explicit adjacency-preserving permutation from F+x to that target state.

A terminal state has λ_F(v)≥3 at every vertex and is accompanied by an explicit isomorphism to H. There is exactly one terminal state.

The certificate has:

| item | count |
|---|---:|
| states | 192 |
| maximum state order | 25 |
| one-vertex extensions | 93,895 |
| explicit induced-P8 rejection certificates | 93,608 |
| explicit retained-extension isomorphisms | 287 |
| terminal states, each isomorphic to H | 1 |
| unaccounted extensions / cutoff frontier | 0 |

The maximum order 25 is an observed property of a **closed** certificate, not an imposed bound on G. The builder has no graph-order cutoff. Its use of canonical labeling is only a convenience for producing a compact certificate; no canonical-labeling package is required or trusted by the verifier.

`verify_p8_core_certificate.py` uses only the Python standard library. It independently lists all required contact sets, compares them exactly with the certificate rows, directly checks every positive P8 certificate, and checks every displayed permutation on all vertex pairs. It also checks the state graphs and the terminal identification. The root is the triangle, every target state has one more vertex than its predecessor, and all states are reachable from the root. The result is `verification_p8_core_certificate.json`.

**Lemma 2.** Every C4-subgraph-free P8-free graph G with a triangle and λ_G(v)≥3 for all vertices contains an induced copy of H.

**Proof from the certificate.** Embed the root triangle in G. Suppose a nonterminal state F is embedded as an induced subgraph. Apply Lemma 1 at its designated deficient vertex u, and choose the resulting new vertex x of G. Its exact contact set occurs among the certificate rows. That row cannot give an induced P8, since G is P8-free. The retained-extension isomorphism therefore yields an induced embedding of the specified next state into G. Its order is one larger. Since the certificate is finite and all nonterminal extensions are accounted for, this process must reach a terminal state. The terminal isomorphism identifies an induced H in G. No bound on |V(G)| has been assumed. ∎

## 4. Every allowed extension of H is harmless

The following elementary arbitrary-order attachment argument uses a second small, explicit finite certificate. Its data are in `weighted_core_contact_certificates.json`, checked by the same pure-Python verifier.

For a new vertex x with a nonempty contact set in H, C4 exclusion requires every two contacts to have no common neighbor in H. The compatibility graph on V(H) has 30 edges and no triangle (all 286 triples are checked). Thus a contact set has size at most two, and there are exactly 13+30=43 possibilities. For 40 of these the certificate supplies an explicit induced P8 in H+x. The only remaining possibilities are {0},{1},{2}, and those three single-leaf extensions are P8-free.

**Lemma 3.** Every connected C4-subgraph-free P8-free graph containing an induced H consists of H plus, at each vertex of T, an arbitrary matching and isolated vertices all adjacent to that triangle vertex, with no other vertices or edges.

**Proof.** The finite contact certificate shows that every exterior vertex with a neighbor in H has exactly one H neighbor, belonging to T. Suppose some vertex y has distance two from H, and choose y–x–i with i∈T. The following induced six-vertex paths in H start at the indicated i:

    i=0: 0,1,4,7,5,8;
    i=1: 1,0,3,6,10,11;
    i=2: 2,0,3,6,12,8.

Prepending y,x gives an induced P8: y has no H neighbor and x has only i as a contact. Hence no distance-two vertex exists, and connectedness rules out further layers. All exterior vertices therefore lie in classes A_i of vertices whose unique H contact is i∈T. An edge between A_i and A_j with i≠j gives a C4 through the triangle edge ij. Each A_i has maximum degree one, because a path x–y–z within A_i gives the C4 i–x–y–z–i. This proves the required form.

Conversely, those pendant edges and triangles introduce no four-cycle. An induced path with vertices in H and an attachment uses at most one attachment vertex at either end. If the two attachment roots are distinct, their adjacency in T prevents any H segment other than their single edge. With only one exterior endpoint, a P8 would give a rooted seven-vertex path in H, contradicting the checked single-leaf extension. Therefore every stated decoration is P8-free. ∎

In a proper extension described by Lemma 3, every added vertex has local independence one. It follows that a graph satisfying λ(v)≥3 everywhere cannot properly contain H. Lemma 2 therefore proves the triangle-containing case of Theorem A. The triangle-free case follows directly from Chudnovsky–Stacho's Theorem 1, because then λ(v)=d(v).

## 5. Density consequence and exact WOWII133 coverage

**Proof of Corollary B.** Induct on the order, allowing disconnected graphs and summing over components when necessary. If some vertex v has λ(v)≤2, then

    L(G)−L(G−v)=2λ(v)−t(v)≤4.

The induction hypothesis gives L(G)<4n; the one-vertex base case is immediate. Otherwise each connected component is one of the four graphs in Theorem A. Their pairs (n,L) are respectively

    (10,30), (14,42), (13,40), (13,39),

all strictly below L=4n. Summing the strict inequalities proves the claim. ∎

The previously proved general ell≤4 result for original WOWII133 is unchanged. Corollary B adds:

- **radius three, ell≤5**: the range ell≤4 was covered earlier; if 4<ell≤5, P8-freeness is impossible, so p≥8≥3+ell;
- **radius two, ell≤6**: the range ell≤4 was covered earlier; if 4<ell≤6, again p≥8≥2+ell.

When a four-cycle is present, the original exponent is zero and a geodesic supplies p≥r+1. The new density argument concerns the strong-C4-free branch. It does not settle radius four with 4<ell≤5, and does not resolve unrestricted original WOWII133.

## 6. Reproducibility and source attribution

Authoritative files for independent review:

- `p8_min_local_classification.md` — mathematical completion, attachment, and induction arguments;
- `p8_core_certificate.json.gz` — closed finite certificate;
- `weighted_core_contact_certificates.json` — all 43 terminal-core contact cases;
- `verify_p8_core_certificate.py` — standard-library-only verifier;
- `verification_p8_core_certificate.json` — completed verifier result;
- `build_p8_core_certificate.py` — optional builder, using NetworkX and pynauty; these packages are not dependencies of certificate verification.

The independent mathematical/implementation audit and final-TeX consolidation audit pass. The finite certificate is part of the proof, not merely heuristic evidence. Earlier random searches and catalogue sweeps are not used as proof steps.

Primary prior result: M. Chudnovsky and J. Stacho, “3-colorable subclasses of P8-free graphs,” *SIAM Journal on Discrete Mathematics* 32(2) (2018), 1111–1138, DOI [10.1137/16M1104858](https://doi.org/10.1137/16M1104858), Theorem 1. Author-hosted primary text: <https://web.math.princeton.edu/~mchudnov/p8free1.pdf>. The theorem's exact three triangle-free exceptions are credited, not re-counted as new work. The complete original source PDF is kept for audit only and need not be redistributed.

The Y–Delta operation and the Heawood graph are classical. No priority claim is made for the particular 13-vertex graph or for its construction. A bounded search found no exact prior general min-local-independence classification or explicit full-class weighted-density consequence; absence of a located result does not certify worldwide priority.
