"""Pure-Python proof-certificate checker, requiring no third-party package.

No canonical-label library and no imported author path-search routine is used.
Every compatible extension is accounted for by an explicit P8 or an explicit
adjacency-preserving permutation to a certified state of one larger order.
The fixed terminal's attachment certificate is checked as well.
"""
import gzip,hashlib,itertools,json,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent;start=time.time()

def vertices(mask):return [i for i in range(mask.bit_length()) if mask>>i&1]
def graphcheck(a):
 n=len(a)
 assert all(isinstance(x,int) and 0<=x<(1<<n) for x in a)
 assert all(not(a[i]>>i&1) for i in range(n))
 assert all(bool(a[i]>>j&1)==bool(a[j]>>i&1) for i in range(n) for j in range(i))
 assert all((a[i]&a[j]).bit_count()<=1 for i in range(n) for j in range(i))
def local(a,u):
 ns=vertices(a[u]);matching=sum(bool(a[v]>>w&1) for j,v in enumerate(ns) for w in ns[:j])
 return len(ns)-matching

def pathcheck(a,p):
 assert len(p)==len(set(p)) and all(isinstance(v,int) and 0<=v<len(a) for v in p)
 assert all(bool(a[p[i]]>>p[j]&1)==(j==i+1) for i in range(len(p)) for j in range(i+1,len(p)))
def has_P8(a):
 def grow(seq,mask):
  if len(seq)==8:return True
  for u in vertices(a[seq[-1]]&~mask):
   if (a[u]&mask)!=(1<<seq[-1]):continue
   if grow(seq+[u],mask|(1<<u)):return True
  return False
 return any(grow([u],1<<u) for u in range(len(a)))
def extend(a,S):return [x|((1<<len(a)) if S>>i&1 else 0) for i,x in enumerate(a)]+[S]
def isocheck(a,b,p):
 assert len(a)==len(b)==len(p) and sorted(p)==list(range(len(a)))
 assert all(bool(a[i]>>j&1)==bool(b[p[i]]>>p[j]&1) for i in range(len(a)) for j in range(i))

def expected_contacts(a,u):
 # Iterative clique enumeration in the compatibility graph, containing u.
 choices=[v for v in range(len(a)) if v!=u and not(a[u]>>v&1) and not(a[u]&a[v])]
 stack=[(1<<u,choices)];result=set()
 while stack:
  mask,choices=stack.pop();assert mask not in result;result.add(mask)
  for j,v in enumerate(choices):
   stack.append((mask|(1<<v),[w for w in choices[j+1:] if not(a[v]&a[w])]))
 return result

def decode_graph6(s):
 raw=s.encode();n=raw[0]-63;stream=[]
 for x in raw[1:]:stream.extend((x-63>>k)&1 for k in range(5,-1,-1))
 a=[0]*n;k=0
 for j in range(1,n):
  for i in range(j):
   if stream[k]:a[i]|=1<<j;a[j]|=1<<i
   k+=1
 return a

core=decode_graph6('L{O__wC_HC@BOg');graphcheck(core)
assert len(core)==13 and all(local(core,u)==3 for u in range(13)) and not has_P8(core)
p=ROOT/'p8_core_certificate.json.gz';raw=p.read_bytes();data=json.loads(gzip.decompress(raw));states=data['states']
assert data['format']=='p8-strong-c4-min-local3-completion-v1' and data['root']==0
assert states[0]['adjacency']==[6,5,3]
counts={'states':len(states),'extensions':0,'P8_certificates':0,'isomorphisms':0,'terminal_states':0};reached={0};arcs=[]
for sid,state in enumerate(states):
 a=state['adjacency'];graphcheck(a);assert not has_P8(a)
 if state.get('terminal'):
  assert all(local(a,u)>=3 for u in range(len(a)))
  isocheck(a,core,state['terminal_isomorphism']);counts['terminal_states']+=1;continue
 u=state['pivot'];assert 0<=u<len(a) and local(a,u)<3
 rows=state['extensions'];masks=[r['mask'] for r in rows]
 assert len(masks)==len(set(masks)) and set(masks)==expected_contacts(a,u)
 for row in rows:
  b=extend(a,row['mask']);counts['extensions']+=1
  if 'P8' in row:
   assert len(row['P8'])==8;pathcheck(b,row['P8']);counts['P8_certificates']+=1
  else:
   tid=row['target'];assert 0<=tid<len(states)
   isocheck(b,states[tid]['adjacency'],row['isomorphism']);arcs.append((sid,tid));counts['isomorphisms']+=1
# Every state in the supplied finite directed acyclic certificate is reachable.
changed=True
while changed:
 changed=False
 for s,t in arcs:
  if s in reached and t not in reached:reached.add(t);changed=True
assert reached==set(range(len(states)))
assert counts['terminal_states']==1

# Terminal-core attachment lemma: exact possible nonempty contact sets.
compat=[(i,j) for i in range(13) for j in range(i) if not(core[i]&core[j])]
assert len(compat)==30
assert all(any(core[i]&core[j] for i,j in itertools.combinations(ss,2)) for ss in itertools.combinations(range(13),3))
allowed={1<<i for i in range(13)}|{(1<<i)|(1<<j) for i,j in compat}
rows=json.loads((ROOT/'weighted_core_contact_certificates.json').read_text())
assert len(rows)==43 and {sum(1<<v for v in r['contacts']) for r in rows}==allowed
surv=[]
for row in rows:
 b=extend(core,sum(1<<v for v in row['contacts']));graphcheck(b)
 if row['P8'] is None:
  assert row['contacts'] in [[0],[1],[2]] and not has_P8(b);surv.append(row['contacts'])
 else:
  assert len(row['P8'])==8;pathcheck(b,row['P8'])
assert len(surv)==3
for path in [[0,1,4,7,5,8],[1,0,3,6,10,11],[2,0,3,6,12,8]]:pathcheck(core,path)
counts.update({'status':'PASS','maximum_state_order':max(len(s['adjacency']) for s in states),'certificate_sha256':hashlib.sha256(raw).hexdigest(),'fixed_core_contact_cases':43,'fixed_core_P8_certificates':40,'fixed_core_singleton_survivors':3,'rooted_P6_certificates':3,'elapsed_seconds':time.time()-start,'scope':'closed finite proof certificate for triangle-containing min-local-independence-three cores; logical completion and attachment lemmas are supplied separately'})
(ROOT/'verification_p8_core_certificate.json').write_text(json.dumps(counts,indent=2)+'\n');print(json.dumps(counts,indent=2))
