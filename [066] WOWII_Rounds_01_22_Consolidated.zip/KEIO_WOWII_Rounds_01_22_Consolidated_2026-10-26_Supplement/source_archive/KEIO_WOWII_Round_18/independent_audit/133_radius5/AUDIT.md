# Independent audit: radius five without induced P10

**Mathematical verdict: PASS.** The exact classification and its radius-five, average-local-independence-at-most-five consequence are valid. No mathematical repair was requested. This is a parameter-specific partial result for original WOWII 133, not a full closure or a worldwide-priority certification.

Frozen note: `round_17/domination133/radius_five_classification.md`, SHA-256 `4fcc294e678b0de05d7635d954507e631501dd1528a785728aed9e1e89398eb8`. The checker and author TeX are also snapshotted and hashed. Round17 delivery files remain unchanged; this audit belongs to Round18.

## Exact scope and accepted dependencies

The classification concerns connected **C4-subgraph-free**, **induced-P10-free** graphs of radius five. It allows triangles; it does not weaken four-cycle exclusion to induced-C4 exclusion. The three alternatives are C10, the already classified nonempty one-level C8 decorations, and the stated two-level C6 decorations with a depth-two arm at every cycle vertex. Each has p=9 and L=2n−t, where p counts vertices of an induced path and L is total local independence.

The proof uses the already independently audited radius-four classification (Round12) and uniform dominating-even-cycle classification (Round16). Their full hypotheses are retained in the TeX's Proposition 1; neither is cited as an unreviewed research assertion. The classical Chung bound p≥2r−1 was verified in earlier primary-source audits. Camby–Schaudt arXiv:1402.7213v1 Theorem 5 was reread locally, with its proof and the relevant preceding Theorem 4 argument. It indeed supplies a connected dominating induced subgraph which is P8-free or C10 when the original graph is connected and P10-free. The exact version is important; no different later theorem numbering is silently substituted.

The Fajtlowicz/ciliate and later radius literature is contextual, not a mathematical dependency or an asserted novelty certificate. Original-source definitions for row 133 are pinned here.

## Reduction to the C6 two-layer branch

A connected dominating induced subgraph H has r(G)≤r(H)+1. If H is P8-free, Chung gives r(H)≤4 and the radius-five premise gives r(H)≥4. The radius-four classification therefore supplies either a dominating C8 in G or a fixed induced C6 at distance at most two from every vertex of G. Inducedness of the core survives because H is induced in G. The dominating-C8 case meets every hypothesis of the audited uniform theorem at k=4.

For a dominating C10, a singleton contact or an adjacent-pair contact gives an induced P10 by appending nine cycle vertices and omitting the second contact where necessary. A distance-two contact pair gives a C4. Hence any exterior vertex has contacts at circular distance at least three. For each cycle vertex c, the three cycle vertices at distance at least four form a three-consecutive-vertex set, which cannot contain such an admissible full contact set. Thus c is within distance four of every exterior vertex. A distance-d contact pair, d=3,4,5, also shortens one contact's distance to its antipode to `2+(5−d)<=4`. All other cycle vertices were already within four, contradicting radius five. Therefore the C10 branch has no exterior vertices.

## Contact types and clean arms

For the two-dominating induced C6, three contacts contain a distance-two pair. The remaining possible two-contact types are adjacent or opposite. An opposite-contact vertex is within two of the entire cycle and hence within four of every graph vertex, so it is forbidden. C4 exclusion gives unique B_i triangle vertices and makes each A_i a matching plus isolates. The listed first-layer cross-edge types are exactly the ones not already forbidden by a four-cycle.

Every cycle vertex has eccentricity **exactly** five: two-domination gives the upper bound and the graph radius gives the lower bound. A witness for c_(i+3) must be in the second layer and can have first-layer neighbors only in A_i; every other contact gives a route of length at most four. Two such neighbors create a C4, giving the unique-parent arm c_i–a_i–z_i. The six parents and terminals are distinct. Every permitted cross edge incident to a_i shortens the prescribed witness distance, so a_i is clean outside its own A_i.

## Terminal simpliciality: all chord conditions checked

For an R-neighbor w of z_0, any first-layer neighbor x of w must have type A_0,A_1,A_5,B_0,B_5. The three displayed representative P10s, and their reflections, exclude every possibility other than x=a_0.

In the A_0\{a_0} path, the potentially nontrivial chords wa_2, wz_2, and z_0z_2 respectively give a length-at-most-four route to z_0 or z_2 from its prescribed opposite cycle vertex. For example wz_2 gives c_5–c_0–x–w–z_2. In the A_1 path, wa_3, wz_3, z_0z_3 are likewise ruled out; in the B_0 path the corresponding a_2/z_2 chords are ruled out, with c_1 deliberately omitted. Exact cycle contacts, unique first-layer neighbors of z_i, and clean first-layer parents exclude every other chord. These arguments remain valid with additional arbitrary edges elsewhere.

Thus w has only a_0 as first-layer neighbor and is adjacent to it. At most one such w exists, since two would have common neighbors a_0,z_0 and make C4. Hence z_0 is simplicial of degree one or two. Rotation proves the same for every terminal. Possible coincidence w=z_j does not invalidate the displayed paths: the first-layer type restrictions exclude the endpoint-index coincidences used in those paths.

## First-layer cross edges

The opposite-A, A–B, and opposite-B paths have ten distinct vertices. Clean parents have no cross-class neighbors, terminals have unique first-layer parents and the newly proved simpliciality, and the unused B contact is omitted. Thus the paths have no chord even if several other cross edges coexist elsewhere.

For a diagonal edge x∈A_0,y∈A_2, clean-parent exclusion first ensures x≠a_0 and y≠a_2. If a_0x is absent, the first displayed path is induced; reflection similarly forces a_2y. With these two mate edges present, the second displayed path is induced instead. The matching property prevents hidden same-class chords. Rotations and reflection exhaust all permitted cross types. No single-cross-edge-only assumption is used.

## Unique parents in R

A putative multiple-parent vertex w cannot be adjacent to any clean terminal, by terminal simpliciality, and has at most one neighbor in each A class by C4 exclusion. The radius guard `wx with x∈A_i ⇒ wa_(i+3) absent` is valid via the explicit four-edge route to z_(i+3).

- **Two A parents at distance two:** all three cases x=a_0, x a mate of a_0, and x a nonmate are handled. The possible wa_0 chord in the last two cases makes a C4; the far-end-parent chord is forbidden by the radius guard. All other first-layer cross edges have already been excluded.
- **Adjacent A parents:** the displayed path works unless wa_2 is present, in which case the already proved distance-two case applies. There is no circular use of the adjacent case.
- **Opposite A parents:** the previous cases exclude A parents in the other four classes, validating the shorter clean-arm endpoint used in the displayed path.
- **One A and one B parent:** B types sharing the A contact make C4. The two diagonal B types and the three mate/nonmate cases for an adjacent-edge B type all give the stated induced paths. The previously established at-most-one-A result rules out the remaining endpoint-parent chords.
- **Two B parents:** sharing a cycle contact makes C4; the only remaining relative positions are the two displayed cases. The previous mixed-parent exclusion ensures w has no A neighbor, exactly as needed for these paths.

Every R vertex has at least one first-layer neighbor by two-domination, so it now has exactly one.

## No edges between distinct child classes

For an R edge uv with distinct parents x,y and x∈A_i, choose s=i±2 avoiding y=a_s. Such a choice always exists. The indicated five-vertex cycle arc together with z_s,a_s,x,u,v has ten vertices. Unique parenthood excludes chords to x and a_s; terminal simpliciality excludes chords to z_s. It also guarantees that u or v cannot equal the chosen terminal: their parents differ from a_s. If both parents are B vertices, the displayed arc omits the other contact of b_0 and the same reasoning applies. Thus different child classes are anticomplete. A length-two path inside one child class would create a C4 with its parent, so every child class is a matching plus isolates.

## Converse and invariant calculations

The construction is C4-subgraph-free. Pendant matching/triangle attachments cannot introduce a four-cycle; a remaining C4 through a B vertex would require a second length-two route between its adjacent cycle contacts, which does not exist.

An induced path cannot leave and reenter the core through a B vertex: the two adjacent core contacts would be a chord. The other attachments have only one core contact. Thus a path meeting the cycle meets it in one contiguous induced cycle path of at most five vertices, and each endpoint has at most two exterior vertices. Traversing two vertices of an attachment matching and their common parent creates a triangular chord. A path missing the core is confined to one attachment component and has at most four vertices. Hence p≤9. The required depth-two arms at the ends of a five-vertex core arc attain nine.

All eccentricity assertions were checked, not just the radius: C/A/B vertices have eccentricities 5/6/5, children of A have 7, children of B have 6. Opposite depth-two A classes supply the lower bounds; cycle distances and unique-parent attachment routes supply the upper bounds. Matching edges do not shorten routes between attachment classes. Counts n=6+a+b+s, m=6+a+2b+s+q+h, and t=b+q+h are exact, giving L=2m−3t=2n−t. The other two types have the same p=9 and L≤2n conclusions by direct calculation or the audited one-level theorem.

## Original 133 consequence

For C4-present graphs, the exponent in original 133 is zero and a geodesic gives p≥r+1=6. For C4-free graphs of radius five, Chung gives p≥9, enough when ell≤4. If 4<ell≤5 and the graph were P10-free, the classification would force ell=L/n≤2, a contradiction. Hence p≥10≥5+ell. The claim is precisely radius five and ell≤5; it does not settle all radii or unbounded ell.

## Independent computation

The independent script does not import the author C++ program. It generates all **5,777 C4-admissible** parent configurations directly: selected B types form a matching of C6, and selected A types avoid their cycle endpoints. The count is independently `4095 + 6·256 + 9·16 + 2 = 5777`. All **1,617** multiple-parent radius-five cases contain P10. Adding an edge from a clean terminal leaves **55** witness-preserving cases; exactly **one** is P10-free, the permitted parent triangle.

A further **500** fresh varied two-level decorations, through order **99**, pass exact C4 exclusion, full per-vertex eccentricity formulas, induced-P10 absence, induced-P9 presence, and the exact weighted identity. The path search checks a new vertex's intersection with the entire current path, independently of the author's forbidden-mask implementation.

The author program was compiled and rerun from a snapshot and its JSON reproduced exactly: 262,143 raw parent assignments, the counts above, 13 first-layer displayed-path cases, 9,600 different-parent certificates, and 2,000 decorations. These controls do not replace the arbitrary-order analytic proof or certify completeness of unspecified graph families.

## Limits

Mathematical PASS uses the explicitly stated published and earlier independently audited dependencies. The radius-critical literature comparison is separately bounded; no inaccessible prior paper is silently treated as a proof input, and no worldwide originality conclusion is asserted. The final delivery TeX/PDF formatting checkpoint can be pinned separately after parent compilation.
