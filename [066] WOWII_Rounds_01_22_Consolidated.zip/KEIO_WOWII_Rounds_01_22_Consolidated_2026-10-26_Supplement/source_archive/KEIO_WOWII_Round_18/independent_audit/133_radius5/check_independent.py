"""Independent bitset BFS and induced-path controls for radius-five theorem."""
from itertools import product,combinations
from collections import Counter
from pathlib import Path
import random,json,time
start=time.monotonic();rng=random.Random(1331807)
def edge(A,u,v):A[u]|=1<<v;A[v]|=1<<u

def add(A,ns):
 v=len(A);A.append(0)
 for u in ns:edge(A,u,v)
 return v

def base():
 A=[0]*18
 for i in range(6):edge(A,i,(i+1)%6);edge(A,i,6+i);edge(A,6+i,12+i)
 return A

def bits(s):
 while s:
  b=s&-s;yield b.bit_length()-1;s^=b

def distances(A,s):
 D=[-1]*len(A);D[s]=0;Q=[s]
 for u in Q:
  for v in bits(A[u]):
   if D[v]<0:D[v]=D[u]+1;Q.append(v)
 assert len(Q)==len(A)
 return D

def c4free(A):return all((A[u]&A[v]).bit_count()<=1 for u,v in combinations(range(len(A)),2))
def witness(A):return all(distances(A,(i+3)%6)[12+i]==5 for i in range(6))
def radius(A):return min(max(distances(A,u)) for u in range(len(A)))
def path(A,target):
 def extend(P,used):
  if len(P)==target:return P
  v=P[-1]
  for w in bits(A[v]&~used):
   if A[w]&used==1<<v:
    answer=extend(P+[w],used|1<<w)
    if answer:return answer
  return None
 for u in range(len(A)):
  ans=extend([u],1<<u)
  if ans:return ans
 return None

def checkpath(A,P):
 assert len(set(P))==len(P)
 assert all(bool(A[u]>>v&1)==(j==i+1) for i,u in enumerate(P) for j,v in enumerate(P) if i<j)

# Generate the C4-admissible parent configurations directly: selected B-types
# form a matching of C6, and any selected A-type avoids their cycle endpoints.
counts=Counter()
for B in range(64):
 edges=[(i,(i+1)%6) for i in range(6) if B>>i&1]
 covered=[v for E in edges for v in E]
 if len(covered)!=len(set(covered)):continue
 free=[i for i in range(6) if i not in covered]
 for modes in product(range(4),repeat=len(free)):
  if not B and not any(modes):continue
  A=base();parents=[]
  for i,mode in zip(free,modes):
   if mode==1:parents.append(6+i)
   if mode in (2,3):parents.append(add(A,[i]+([6+i] if mode==3 else [])))
  for i,j in edges:parents.append(add(A,[i,j]))
  w=add(A,parents);assert c4free(A);counts['C4_admissible_parent_assignments']+=1
  if len(parents)>1 and radius(A)==5:
   counts['multiparent_radius5']+=1;P=path(A,10);assert P;checkpath(A,P)
  edge(A,12,w)
  if c4free(A) and witness(A):
   counts['terminal_neighbor_witness_preserving']+=1;P=path(A,10)
   if not P:
    assert parents==[6];counts['terminal_neighbor_P10free']+=1
   else:checkpath(A,P)

# Fresh larger two-level decorations, exact full eccentricity profile and p.
maximum_order=0
for rep in range(500):
 A=[0]*6;kind=['C']*6
 for i in range(6):edge(A,i,(i+1)%6)
 parents=[]
 for i in range(6):
  group=[]
  for j in range(rng.randint(1,4)):
   u=add(A,[i]);group.append(u);kind.append('A');parents.append((u,j==0))
  rng.shuffle(group)
  for j in range(0,len(group)-1,2):
   if rng.randrange(2):edge(A,group[j],group[j+1])
  if rng.randrange(2):
   u=add(A,[i,(i+1)%6]);kind.append('B');parents.append((u,False))
 for u,required in parents:
  children=[]
  for _ in range(rng.randint(int(required),4)):
   v=add(A,[u]);kind.append('child_'+kind[u]);children.append(v)
  rng.shuffle(children)
  for j in range(0,len(children)-1,2):
   if rng.randrange(2):edge(A,children[j],children[j+1])
 assert c4free(A)
 expected={'C':5,'A':6,'B':5,'child_A':7,'child_B':6}
 for u,t in enumerate(kind):assert max(distances(A,u))==expected[t]
 assert not path(A,10);P=path(A,9);assert P;checkpath(A,P)
 m=sum(x.bit_count() for x in A)//2
 triangles=sum((A[u]&A[v]).bit_count() for u in range(len(A)) for v in bits(A[u]))//6
 assert 2*m-3*triangles==2*len(A)-triangles
 counts['fresh_two_level_decorations']+=1;maximum_order=max(maximum_order,len(A))
print(json.dumps({'status':'PASS','counts':dict(counts),'maximum_decoration_order':maximum_order,'seconds':time.monotonic()-start,'scope':'Independent parent grammar, BFS, induced-path tests, and larger converse controls; analytic proof remains the arbitrary-order justification.'},indent=2))
