# Radius five without an induced ten-vertex path

**KEIO — 26 October 2026.**

**Status:** proposed complete analytic partial theorem, awaiting independent review. No unrestricted WOWII133 closure or worldwide-priority claim is made. The reduction uses the independently reviewed radius-four classification and the separately proposed uniform dominating-even-cycle theorem.

## Main theorem

Every connected C4-subgraph-free P10-free graph of radius five belongs to exactly one of the following three types:

1. C10.
2. A decorated C8 of the uniform even-cycle theorem: every cycle vertex has a nonempty single-contact class inducing a matching plus isolates; optionally one triangle vertex sits on each cycle edge; there are no cross-class edges.
3. The following two-level decoration of C6. On each cycle vertex c_i place a class A_i inducing a matching plus isolates, all its vertices adjacent to c_i. Optionally place b_i on each cycle edge c_ic_(i+1), adjacent to its endpoints. Every vertex outside this first layer has exactly one first-layer parent; the children of each parent induce a matching plus isolates, and there are no edges between different child classes. For every i, at least one vertex a_i∈A_i has at least one child.

Every graph in the list has p=9 and L=2n−t≤2n. Consequently original WOWII133 holds at radius five whenever ell≤5.

The key new lemma below proves the C6 branch directly under the weaker hypothesis that every vertex is at distance at most two from the fixed induced C6.

## 1. Reduction to C10, a dominating C8, or a two-dominating C6

The classical induced-path theorem gives p≥2r−1. Theorem5 of Camby–Schaudt (arXiv:1402.7213v1) supplies a connected dominating induced subgraph H that is P8-free or is C10. In the first case,

    5=r(G)≤r(H)+1, and 2r(H)−1≤p(H)≤7,

so r(H)=4. The independently reviewed radius-four classification makes H either C8 or a decorated C6. Therefore G has a dominating C8 or every vertex of G lies within distance two of a fixed induced C6.

In the C10 case, no exterior vertex exists. A singleton or adjacent-pair contact set gives P10 by appending nine consecutive cycle vertices. A distance-two pair gives C4. Every exterior vertex therefore has two contacts at circular distance at least three. For any cycle vertex c, the cycle vertices at distance at least four from c form a set of three consecutive vertices. Such a set cannot contain an admissible contact set. Thus every cycle vertex is within distance four of every exterior vertex. A pair of contacts at distance d∈{3,4,5} gives a shortcut from one contact to its antipode of length 2+(5−d)≤4. That contact is now within distance four of the entire graph, contrary to radius five. Hence G=C10.

The dominating-C8 case is the k=4 instance of the uniform even-cycle classification in the preceding checkpoint. It remains to prove the two-dominating-C6 lemma.

## 2. Contact types and six radius witnesses

Let C=c_0…c_5c_0 be induced, and suppose every vertex is within distance two of C. All indices in the remaining proof are modulo six. First-layer contact sets are singletons, adjacent pairs, or opposite pairs: distance-two contacts give C4, and three contacts contain such a pair. An opposite-contact vertex is within distance two of the cycle, hence within distance four of G, contrary to radius five. Thus first-layer vertices have types A_i={c_i} or B_i={c_i,c_(i+1)}. Each B_i has at most one vertex b_i. Write R for the vertices with no cycle contact. Every vertex of R has a first-layer neighbor.

Four-cycle exclusion permits only these first-layer cross edges:

    A_i–A_j, j−i∈{2,3,4};
    A_i–b_j, j−i∈{2,3};
    b_i–b_j, j−i=3.

Each A_i induces a matching plus isolates.

The vertex c_(i+3) has eccentricity five. Its distance-five witness must lie in R and all of that witness's first-layer neighbors must be in A_i; every other type gives a route of length at most four. Two neighbors in A_i would give a C4 with c_i. Thus choose

    c_i–a_i–z_i, with a_i∈A_i, z_i∈R,
    N(z_i)∩(first layer)={a_i}, dist(c_(i+3),z_i)=5.

Every a_i has no first-layer neighbor outside A_i. An allowed A_j neighbor has j−i∈{2,3,4}, yielding a route from c_(i+3) to z_i of length at most four. An allowed B neighbor gives an even shorter route. The remaining cross types are already excluded by C4. Within A_i, a_i has at most one mate.

## 3. The terminal witnesses are simplicial

We prove that every z_i has no R neighbor except possibly one vertex adjacent to a_i. Such a neighbor, if present, makes a pendant triangle at a_i.

Rotate to i=0, and suppose z_0w is an R edge. A first-layer neighbor of w can only have type A_0,A_1,A_5,B_0,B_5: any other type would put z_0 within distance four of c_3. Let x be such a neighbor.

- If x∈A_0 and x≠a_0, then

      z_2,a_2,c_2,c_3,c_4,c_5,c_0,x,w,z_0

  is an induced P10. The possible chords from w to a_2 and z_2 would respectively shorten the prescribed distances to z_0 and z_2 to four. The chord z_0z_2 would also shorten one of these distances. All first-layer cross chords involving a_2 are excluded by the preceding paragraph, and z_0x is excluded by uniqueness of its first-layer neighbor.

- If x∈A_1, use

      z_0,w,x,c_1,c_0,c_5,c_4,c_3,a_3,z_3.

  The possible edges wa_3,wz_3,z_0z_3 contradict the radius witnesses; the other chords are excluded by exact contacts and the clean first-layer parent a_3. Reflect for A_5.

- If x=b_0, use

      z_0,w,b_0,c_0,c_5,c_4,c_3,c_2,a_2,z_2.

  The unused contact c_1 is omitted. Again wa_2,wz_2,z_0z_2 contradict the prescribed witness distances. Reflect for B_5.

Consequently every first-layer neighbor of w is a_0; at least one exists, so wa_0 is an edge. There is at most one such w, since two would have common neighbors a_0,z_0 and give C4. Therefore z_0, and similarly every z_i, is simplicial of degree one or two.

## 4. There are no first-layer cross edges

Every displayed path below has ten vertices. The clean two-vertex arms z_i,a_i replace the one-vertex endpoint witnesses in the radius-four argument. Their contact restrictions and the simplicial terminal witnesses verify every chord condition.

For opposite A classes, an edge x∈A_0, y∈A_3 gives

    z_1,a_1,c_1,c_0,x,y,c_3,c_4,a_4,z_4.

For x∈A_0 adjacent to b_2 or b_3, use respectively

    z_1,a_1,c_1,c_0,x,b_2,c_3,c_4,a_4,z_4;
    z_5,a_5,c_5,c_0,x,b_3,c_3,c_2,a_2,z_2.

For b_0b_3, use

    z_2,a_2,c_2,c_1,b_0,b_3,c_4,c_5,a_5,z_5.

Finally, suppose x∈A_0 and y∈A_2 are adjacent. Since a_0 has no first-layer cross edge, x≠a_0. If a_0x were absent, then

    z_4,a_4,c_4,c_3,c_2,y,x,c_0,a_0,z_0

would be induced P10. Thus a_0x is present; reflection gives a_2y. Now

    z_3,a_3,c_3,c_4,c_5,c_0,x,y,a_2,z_2

is induced P10. Rotations and reversals exhaust all cross types. Hence the first layer has only the individual A_i matchings; each b_i has no first-layer neighbor.

## 5. Every R vertex has exactly one first-layer parent

Suppose w∈R has at least two first-layer neighbors. It is adjacent to at most one vertex of each A_i, by C4 exclusion through c_i. It is nonadjacent to every terminal witness z_i, by Section3. We shall use the following radius consequence repeatedly:

    if w has a neighbor x∈A_i, then wa_(i+3) is absent,

because c_i,x,w,a_(i+3),z_(i+3) would have length four.

### Two A neighbors

First take x∈A_0 and y∈A_2. According to the relation between x and a_0, one of these is induced P10:

| condition | path |
|---|---|
| x=a_0 | z_0,x,w,y,c_2,c_3,c_4,c_5,a_5,z_5 |
| x≠a_0 and a_0x is an edge | a_0,x,w,y,c_2,c_3,c_4,c_5,a_5,z_5 |
| x≠a_0 and a_0x is absent | z_0,a_0,c_0,x,w,y,c_2,c_3,a_3,z_3 |

In the last two rows wa_0 is forbidden by C4 through c_0 and x. The end-parent chord wa_5 or wa_3 is forbidden by the radius consequence. All other first-layer cross edges have already been removed. This excludes contact indices at distance two.

For x∈A_0,y∈A_1, if wa_2 is absent, use

    z_2,a_2,c_2,c_3,c_4,c_5,c_0,x,w,y.

If wa_2 is present, the just-proved distance-two case applies to x,a_2. Thus adjacent A types are excluded as well.

For x∈A_0,y∈A_3, the previous cases imply that w has no A neighbor in any of the other four classes. Now

    a_1,c_1,c_0,x,w,y,c_3,c_4,a_4,z_4

is induced P10. This excludes the final possibility. Thus w has at most one A neighbor.

### One A neighbor and one B neighbor

Take x∈A_0. The B types b_0,b_5 are excluded by C4 through c_0. The remaining types are b_1,b_2,b_3,b_4. All clean parents outside A_0 are nonneighbors of w, by the previous A–A exclusion.

For b_2, use

    a_1,c_1,c_0,x,w,b_2,c_3,c_4,a_4,z_4.

The b_3 case is its reflection. For b_1, use the following table; reflect it for b_4.

| condition | path |
|---|---|
| x=a_0 | a_2,c_2,b_1,w,x,c_0,c_5,c_4,a_4,z_4 |
| x≠a_0 and a_0x is absent | a_0,c_0,x,w,b_1,c_2,c_3,c_4,a_4,z_4 |
| x≠a_0 and a_0x is an edge | a_0,x,w,b_1,c_2,c_3,c_4,c_5,a_5,z_5 |

The same-class chord wa_0 is forbidden by C4 whenever needed. The unused contact of each B vertex is omitted. This excludes every A–B pair.

### Two B neighbors

There is now no A neighbor of w. Two B types sharing a cycle contact give C4, so up to rotation and reflection the pair is b_0,b_2 or b_0,b_3. Use respectively

    a_1,c_1,b_0,w,b_2,c_3,c_4,c_5,a_5,z_5;
    a_2,c_2,c_1,b_0,w,b_3,c_4,c_5,a_5,z_5.

Again these are induced P10s. Every R vertex consequently has exactly one first-layer neighbor, its parent.

## 6. Different child classes are anticomplete

Suppose uv is an R edge with distinct parents x,y. If at least one parent is an A vertex, orient so x∈A_i. Choose s∈{i+2,i−2} so that y≠a_s. Follow the five-vertex cycle arc from c_s to c_i, choosing the direction that avoids the other neighbor of c_i. Then

    z_s,a_s, [five cycle vertices from c_s to c_i], x,u,v

is induced P10. The different parent condition excludes xv; uniqueness of parents excludes every other first-layer chord. The choice y≠a_s and Section3 exclude all chords to the clean endpoint arm.

If both parents are B vertices, rotate so x=b_0. Then

    z_2,a_2,c_2,c_3,c_4,c_5,c_0,b_0,u,v

is induced P10; the unused contact c_1 is omitted. Thus no edge joins different child classes. Each child class induces a matching plus isolates, by C4 exclusion in the neighborhood of its parent. This proves the asserted two-level structure.

## 7. Converse, invariant calculation, and exact coverage

Every graph of the two-level C6 form is C4-subgraph-free. The A attachments and the second-layer matching classes add only pendant edges or triangles. A C4 through b_i would require a second length-two path between c_i and c_(i+1), and the construction contains no such path. The remaining core is C6. An induced path meeting the cycle meets it in one contiguous induced path of at most five vertices, and at each end it has at most two exterior vertices. Without a cycle vertex, an induced path lies within one of the stated small attachment components and has at most four vertices. Thus p≤9. The nonempty depth-two class at every cycle vertex supplies an induced nine-vertex path, so p=9.

Every cycle vertex has eccentricity five, witnessed by the opposite depth-two class. An A vertex has eccentricity six; a B vertex has eccentricity five. A child of an A vertex has eccentricity seven, and a child of a B vertex has eccentricity six. These statements follow directly from the core-cycle distances; internal matching edges do not shorten routes between attachment classes. Hence the radius is five.

Let a count the A vertices, b the B vertices, s the R vertices, q the A-class matching edges, and h the child-class matching edges. Then

    n=6+a+b+s,
    m=6+a+2b+s+q+h,
    t=b+q+h,
    L=2m−3t=2n−t.

The C8-decoration and C10 cases have the same L≤2n conclusion, and p=9. This completes the proposed classification.

For original WOWII133 at radius five, if a C4 occurs, a geodesic supplies p≥6. In the C4-free case ell≤4 follows already from p≥2r−1=9. If 4<ell≤5, the classification excludes P10-freeness, because every graph it lists has ell≤2. Hence p≥10≥5+ell. This remains a radius-specific partial result, not an unrestricted closure.

## Dependencies and source notes

- Erdős–Saks–Sós, Maximum induced trees in graphs, JCTB41(1986),61–79; radius bound credited to Fan Chung, SectionII, pp64–65, DOI10.1016/0095-8956(86)90028-6.
- Camby–Schaudt, A new characterization of P_k-free graphs, Algorithmica75(2016),205–217, DOI10.1007/s00453-015-9989-6; exact arXiv:1402.7213v1 Theorem5.
- The radius-four classification is included in the independently reviewed preceding manuscript; the uniform dominating-even-cycle classification is a separately proposed dependency awaiting its own review.
- Fajtlowicz's1988 radius-critical-ciliate theorem is related context, but it is not used as a dependency in this proof.

## Supplementary finite checks

`verify_radius5_classification.cpp` completed with PASS. It checks all262,143 nonempty first-layer parent-type assignments for one second-layer vertex (per A class: absent, clean parent, new nonmate, or new mate; each B type optional). Of5,777 C4-free assignments, every one of the1,617 multiple-parent radius-five cases contains P10. In the terminal-neighbor variant,55 assignments retain all six prescribed witness distances; the only P10-free assignment is the permitted triangle at the witness parent.

The program also verifies13 displayed first-layer path cases,9,600 explicit different-parent edge path certificates, and2,000 deterministic varied two-level decorations by exact C4 exclusion, radius, induced-path search, and L=2n−t. These finite checks supplement, rather than replace, the arbitrary-order proof.
