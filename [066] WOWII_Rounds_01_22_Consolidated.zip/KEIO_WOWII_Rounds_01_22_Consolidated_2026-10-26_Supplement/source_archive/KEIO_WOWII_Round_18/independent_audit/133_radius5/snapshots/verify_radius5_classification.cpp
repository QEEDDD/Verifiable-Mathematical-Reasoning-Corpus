#include <bits/stdc++.h>
using namespace std;using U=uint64_t;mt19937 rng(1331701);
struct G{
 int n;vector<U>N;G(int n):n(n),N(n){};
 void edge(int u,int v){N[u]|=1ull<<v;N[v]|=1ull<<u;}
 void del(int u,int v){N[u]&=~(1ull<<v);N[v]&=~(1ull<<u);}
 bool allowed(int u,int v,bool trianglefree){if(u==v||(N[u]>>v&1))return false;if(trianglefree&&(N[u]&N[v]))return false;U a=N[u];while(a){int x=__builtin_ctzll(a);a&=a-1;if(N[x]&N[v])return false;}return true;}
 bool connected(){U seen=1,front=1;while(front){U next=0;while(front){int u=__builtin_ctzll(front);front&=front-1;next|=N[u];}front=next&~seen;seen|=front;}return __builtin_popcountll(seen)==n;}
 int radius(){int rad=n;for(int s=0;s<n;s++){U seen=1ull<<s,front=seen;int d=0;while(__builtin_popcountll(seen)<n){U next=0;while(front){int u=__builtin_ctzll(front);front&=front-1;next|=N[u];}front=next&~seen;seen|=front;d++;if(!front)return n;}rad=min(rad,d);}return rad;}
 int local_sum(){int degrees=0,tri6=0;for(int u=0;u<n;u++){degrees+=__builtin_popcountll(N[u]);U z=N[u];while(z){int v=__builtin_ctzll(z);z&=z-1;tri6+=__builtin_popcountll(N[u]&N[v]);}}return degrees-tri6/2;}
 long long nodes=0;bool haspath(int target){function<bool(int,int,U,U)>dfs=[&](int v,int len,U used,U forbid){nodes++;if(len>=target)return true;U cand=N[v]&~(used|forbid);while(cand){int u=__builtin_ctzll(cand);cand&=cand-1;if(dfs(u,len+1,used|(1ull<<u),forbid|N[v]))return true;}return false;};for(int s=0;s<n;s++)if(dfs(s,1,1ull<<s,0))return true;return false;}
 void print(){for(int u=0;u<n;u++)for(int v=0;v<u;v++)if(N[u]>>v&1)cout<<u<<","<<v<<";";cout<<endl;}
};



void vertex(G&g){assert(g.n<63);g.n++;g.N.push_back(0);}
int add(G&g,vector<int>ns){int v=g.n;vertex(g);for(int u:ns)g.edge(u,v);return v;}
bool c4free(G&g){for(int u=0;u<g.n;u++)for(int v=0;v<u;v++)if(__builtin_popcountll(g.N[u]&g.N[v])>1)return false;return true;}
G core(){G g(18);for(int i=0;i<6;i++){g.edge(i,(i+1)%6);g.edge(i,6+i);g.edge(6+i,12+i);}return g;}
int distance(G&g,int s,int t){U seen=1ull<<s,front=seen;int d=0;while(!(seen>>t&1)){U next=0;while(front){int u=__builtin_ctzll(front);front&=front-1;next|=g.N[u];}front=next&~seen;seen|=front;d++;assert(front);}return d;}
bool prescribed(G&g){for(int i=0;i<6;i++)if(distance(g,(i+3)%6,12+i)!=5)return false;return true;}
bool induced(G&g,vector<int>p){if(p.size()!=10||set<int>(p.begin(),p.end()).size()!=10)return false;for(int i=0;i<10;i++)for(int j=i+1;j<10;j++)if(bool(g.N[p[i]]>>p[j]&1)!=(j==i+1))return false;return true;}
int main(){
 long long raw=0,c4ok=0,radiusok=0,terminalok=0,terminalallowed=0;
 // Exhaust every first-layer parent-type choice for one extra R vertex.
 // A options: absent, existing clean parent, new nonmate, new mate.
 for(int code=0;code<4096;code++)for(int bm=0;bm<64;bm++){
  G g=core();vector<int> ns;int z=code;
  for(int i=0;i<6;i++){int mode=z%4;z/=4;if(mode==1)ns.push_back(6+i);if(mode==2)ns.push_back(add(g,{i}));if(mode==3)ns.push_back(add(g,{i,6+i}));}
  for(int i=0;i<6;i++)if(bm>>i&1)ns.push_back(add(g,{i,(i+1)%6}));
  if(ns.empty())continue;int w=add(g,ns);raw++;
  if(c4free(g)){
   c4ok++;if(ns.size()>=2&&g.radius()==5){radiusok++;if(!g.haspath(10)){cerr<<"BAD multiparent "<<code<<" "<<bm<<endl;return 1;}}
  }
  // An R neighbor of the prescribed terminal z_0 can only complete its triangle.
  g.edge(12,w);
  if(c4free(g)&&prescribed(g)){terminalok++;
   bool allowed=ns.size()==1&&ns[0]==6;
   if(!g.haspath(10)){if(!allowed){cerr<<"BAD terminal "<<code<<" "<<bm<<endl;return 2;}terminalallowed++;}
  }
 }
 long long cross=0;
 auto check=[&](G&g,vector<int>p){assert(c4free(g));if(!induced(g,p)){cerr<<"BAD displayed path"<<endl;return false;}cross++;return true;};
 for(int mx=0;mx<2;mx++)for(int my=0;my<2;my++){
  G g=core();int x=add(g,mx?vector<int>{0,6}:vector<int>{0});int y=add(g,my?vector<int>{3,9}:vector<int>{3});g.edge(x,y);
  assert(check(g,{13,7,1,0,x,y,3,4,10,16}));
  g=core();x=add(g,mx?vector<int>{0,6}:vector<int>{0});y=add(g,my?vector<int>{2,8}:vector<int>{2});g.edge(x,y);
  if(!mx)assert(check(g,{16,10,4,3,2,y,x,0,6,12}));
  else if(!my){vector<int>p={16,10,4,3,2,x,y,2,8,14}; // use explicit reflected forcing path below
   p={16,10,4,5,0,x,y,2,8,14};assert(check(g,p));}
  else assert(check(g,{15,9,3,4,5,0,x,y,8,14}));
 }
 for(int mx=0;mx<2;mx++)for(int d:{2,3}){
  G g=core();int x=add(g,mx?vector<int>{0,6}:vector<int>{0});int b=add(g,{d,d+1});g.edge(x,b);
  assert(check(g,d==2?vector<int>{13,7,1,0,x,b,3,4,10,16}:vector<int>{17,11,5,0,x,b,3,2,8,14}));
 }
 {G g=core();int b=add(g,{0,1}),c=add(g,{3,4});g.edge(b,c);assert(check(g,{14,8,2,1,b,c,4,5,11,17}));}
 // Uniform different-parent edge certificates in a rich first layer.
 long long redges=0;
 for(int mt=0;mt<64;mt++){
  G base=core();vector<int> pars;vector<int>type;
  for(int i=0;i<6;i++){pars.push_back(6+i);type.push_back(i);int x=add(base,(mt>>i&1)?vector<int>{i,6+i}:vector<int>{i});pars.push_back(x);type.push_back(i);}
  for(int i=0;i<6;i++){pars.push_back(add(base,{i,(i+1)%6}));type.push_back(6+i);}
  for(int j=0;j<(int)pars.size();j++)for(int k=j+1;k<(int)pars.size();k++){
   int x=pars[j],y=pars[k],tx=type[j],ty=type[k];G g=base;int u=add(g,{x}),v=add(g,{y});g.edge(u,v);if(!c4free(g))continue;
   vector<int>p;
   if(tx<6){int i=tx,s=(i+2)%6,dir=1;if(y==6+s){s=(i+4)%6;dir=-1;}p={12+s,6+s};for(int h=0;h<5;h++)p.push_back((s+dir*h+12)%6);p.insert(p.end(),{x,u,v});}
   else{int i=tx-6,s=(i+2)%6;p={12+s,6+s};for(int h=0;h<5;h++)p.push_back((s+h)%6);p.insert(p.end(),{x,u,v});}
   assert(induced(g,p));redges++;
  }
 }
 long long dec=0;
 for(int rep=0;rep<2000;rep++){
  G g(6);for(int i=0;i<6;i++)g.edge(i,(i+1)%6);vector<pair<int,bool>>parents;
  for(int i=0;i<6;i++){int x=add(g,{i});parents.push_back({x,true});if(rng()%2){int y=add(g,{i});parents.push_back({y,false});if(rng()%2)g.edge(x,y);}if(rng()%2)parents.push_back({add(g,{i,(i+1)%6}),false});}
  for(auto[x,required]:parents){int num=required?1+rng()%2:rng()%3;vector<int>cs;for(int z=0;z<num;z++)cs.push_back(add(g,{x}));if(num==2&&rng()%2)g.edge(cs[0],cs[1]);}
  assert(c4free(g)&&g.radius()==5&&!g.haspath(10)&&g.haspath(9));
  int m=0,tri6=0;for(int u=0;u<g.n;u++){m+=__builtin_popcountll(g.N[u]);U a=g.N[u];while(a){int v=__builtin_ctzll(a);a&=a-1;tri6+=__builtin_popcountll(g.N[u]&g.N[v]);}}m/=2;int t=tri6/6;assert(m==g.n+t&&g.local_sum()==2*g.n-t);dec++;
 }
 cout<<"{\n  \"status\": \"PASS\",\n  \"parent_type_assignments\": "<<raw<<",\n  \"C4_free_parent_assignments\": "<<c4ok<<",\n  \"multiple_parent_radius5_cases_all_P10\": "<<radiusok<<",\n  \"terminal_neighbor_cases_with_prescribed_witnesses\": "<<terminalok<<",\n  \"terminal_neighbor_P10_free_cases\": "<<terminalallowed<<",\n  \"first_layer_displayed_paths\": "<<cross<<",\n  \"different_parent_edge_displayed_paths\": "<<redges<<",\n  \"exact_two_level_decorations\": "<<dec<<",\n  \"seed\": 1331701\n}\n";
}
