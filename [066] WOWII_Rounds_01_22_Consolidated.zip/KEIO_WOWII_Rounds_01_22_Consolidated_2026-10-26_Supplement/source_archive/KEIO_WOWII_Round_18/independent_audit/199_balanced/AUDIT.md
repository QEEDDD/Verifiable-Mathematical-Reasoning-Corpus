# Independent audit: balanced deficit and restricted padding for split WOWII 199

**Mathematical verdict: PASS.** Under the original split-graph hypothesis `tree(G)<=κ(G)+2`, the case `|I|=|C|+1` is traceable. The stated padding corollary also passes under its explicit extra inequality. No mathematical repair was requested. These are scoped arbitrary-order results, not a full resolution of original 199.

The frozen author note is `round_16/induced/split199_balanced_deficit.md`; exact hashes and snapshots are retained with this report. The original row and induced-tree/connectivity definitions were locked in the Round17 split audits and are copied here. In particular tree counts **vertices of a connected induced acyclic subgraph**, not a forest or an edge count.

## 1. Setup and hypotheses

The maximum-independent split partition, its nonempty clique columns, and `κ=min independent-side degree` were independently proved in the prior split audit. The induced star gives `s_c<=k+1` and the induced double star on two clique vertices plus their exclusive independent neighbors gives `|A_c△A_b|<=k`. All row degrees are at least k. For a connected nontrivial noncomplete graph, k≥1 and q=|C|≥k.

The balanced theorem imposes h=|I|=q+1 as an additional restriction. It does not assert that an arbitrary split counterexample has this relation. The proof uses only its stated incidence inequalities; no unproved Hamiltonian factor or matching characterization enters.

## 2. Deficit arithmetic, checked independently

Counting each independent vertex's contribution to unordered column pairs gives exactly
`sum_{c<b}|A_c△A_b| = sum_i r_i(q-r_i)`;
there is no missing factor of two. Since r_i≥k and q−r_i≥0, this is at least
`k(q(q+1)-E_total) >= kq(q-k)`.
The column-size upper bound supplies the second inequality. The symmetric-difference bound gives the upper bound `kq(q-1)/2`. Cancelling positive kq yields `q<=2k-1`; q≥k is already known.

With t=q−k and d=2k−q, we therefore have t≥0,d≥1. The excess `E=sum_i(r_i-k)` and total nonnegative column deficit `W=sum_c(k+1-s_c)` satisfy the exact identity `W=t-E`, so `0<=W<=t`.

For a fixed column A of size s, the sum of its differences with **all q columns**, including its zero self-difference, is
`k(q+1)+s(q-2k)+E-2E_A`, where `E_A=sum_{i∈A}(r_i-k)`.
It is at most k(q−1), and `0<=E_A<=E`, giving `sd>=2k-E`.
The single-column deficit k+1−s is at most W, so
`E<=t-(k+1-s)=s-d-1`.
Substitution in the correct direction yields
`sd>=2k-s+d+1`, equivalently **`(s-1)(d+1)>=2k`**.
This is a lower bound for every column separately, not merely for an average. No hypothesis on a common neighborhood is used.

When k=1, q≤2k−1 forces q=1. Its two independent vertices both meet the sole clique vertex, giving P3, as claimed. Thus the low-parameter boundary causes no division-by-zero or omitted case.

## 3. Two closure stages

For a missing incidence between an independent vertex i and a clique vertex c, the path-closure threshold is exactly `r_i+s_c>=h`: the full clique-vertex degree is q−1+s_c and n=q+h.

A high column has s_c≥t+1=q+1−k, so every missing incidence to it satisfies the threshold using r_i≥k. These edges may be added in any order because degrees never decrease. If ℓ columns were not high, each has deficit at least k+1−t=d+1. Therefore `ℓ(d+1)<=W<=t`.

The per-column bound gives `(s_c-1)(d+1)>=2k>t>=ℓ(d+1)`. Thus every remaining column has s_c≥ℓ+1; indeed integrality gives the stronger s_c≥ℓ+2. After completing all high columns, each independent vertex has degree at least q−ℓ. Hence every missing incidence in a remaining column also meets
`r_i+s_c >= (q-ℓ)+(ℓ+1)=q+1=h`.
The complete split graph with q clique and q+1 independent vertices has an alternating spanning path. Reversing the valid closure additions proves traceability of the original graph.

The closure argument is independently valid and self-contained. Adding a universal vertex converts the path problem into a cycle problem and raises the endpoint degree sum to at least the new order. Deleting a newly added nonedge from a Hamiltonian cycle gives a spanning path between its endpoints. The two sets of splice indices, of total size at least N among N−1 indices, intersect; the displayed reversed suffix produces a cycle avoiding the new edge. Removing the universal vertex gives a spanning path. Nonadjacency rules out degenerate endpoint cuts. This is the classical Bondy–Chvátal rule, not a new theorem or an unreviewed external dependency.

## 4. Restricted padding corollary

Let b=q+1−h and suppose exactly the stated restriction `0<=b<=k+1-m`. Adding b independent vertices adjacent to every clique vertex increases every column size by b, leaving it at most k+1. Symmetric differences are unchanged because the same new elements enter every column. Old row degrees stay at least k, and the new row degrees are q≥k. The augmented matrix meets all hypotheses of the proved balanced theorem.

Deleting the added independent vertices from the resulting spanning path is legitimate. An internal deleted vertex has two distinct clique neighbors, whose edge already exists; bridge them. Added independent vertices cannot be adjacent on the path, and repeated deletions preserve a simple path on the remaining vertices. Endpoint deletions merely shorten it. Every original vertex remains exactly once. Thus the conclusion is a Hamiltonian path of the original graph.

No assertion is made that arbitrary split graphs can be padded within this bound. In particular, padding beyond `k+1-m` would invalidate the column-size hypothesis and is not licensed by this proof.

## 5. Independent finite controls

`check_independent.py` supplies a separate implementation. Its small column-multiset enumeration uses only the original row-degree, column-size and pair-difference restrictions; it does **not** prune using the derived q, deficit or per-column inequalities. It verifies each identity at every surviving matrix. It then randomizes the order of closure edges, the final alternating path, and the reverse-splice choice, checking each degree threshold and every recovered original edge.

Fresh larger examples are built from edge-disjoint injections defining missing incidences, with safe further deletions. The nontrivial affine q=13,h=14,k=8 example is independently checked under thirty row/column relabelings and shuffled closure orders; its low column really requires the second phase. Universal independent vertices are also deleted with explicit bridge checks under the padding condition. Exact counts and the reproducible random seed are in `independent_results.json` and the script.

The author's original 402 balanced-path guards and separate 198 padding-deletion guards are rerun from snapshots. Their finite families and the affine input are supplementary tests, not the proof of arbitrary-order coverage. In particular, the certificate does not rely on a solver or assume that its finite design families exhaust all possible split graphs.

## Scope and priority

Accepted conclusions: original199 for the additional balanced-deficit subclass and the explicitly bounded padding subclass. The previously accepted κ≤3 and small-maximum-column results remain separate. General split 199 and unrestricted 199 are not closed. Classical closure and counting tools are credited, and worldwide publication priority is not certified by this audit. Parent owns final standalone TeX/PDF formatting and visual QA.

### Final independent counts

All **6,824** independently constructed spanning paths pass: **6,276** small column multisets with q≤6 enumerated without the derived deficit pruning, **518** fresh injection/deletion designs, and **30** independently relabelled genuine second-stage examples. Maximum order is **81**. The run checks **156,577** valid closure additions (270 in stage two) and performs **27,518** actual reverse path repairs. It also verifies **944** padding deletions with **774** actual clique-edge bridges. The author counts reproduce exactly except runtime.
