"""Independent column enumeration, shuffled closure, and padding controls."""
from itertools import combinations,permutations
from pathlib import Path
from collections import Counter
import random,json,time
import networkx as nx
rng=random.Random(1991809);start=time.monotonic();stats=Counter();grammar=Counter()

def run(cols,k,kind):
 q=len(cols);h=q+1;row=[sum(i in T for T in cols) for i in range(h)];sizes=list(map(len,cols))
 assert min(row)>=k and max(sizes)<=k+1 and all(cols)
 assert all(len(S^T)<=k for S,T in combinations(cols,2))
 t=q-k;d=2*k-q;E=sum(r-k for r in row);W=sum(k+1-s for s in sizes)
 assert k<=q<=2*k-1 and W==t-E and 0<=W<=t
 for c,A in enumerate(cols):
  EA=sum(row[i]-k for i in A);lhs=sum(len(A^B) for B in cols)
  assert lhs==k*(q+1)+len(A)*(q-2*k)+E-2*EA and lhs<=k*(q-1)
  assert (len(A)-1)*(d+1)>=2*k
 high=[c for c,S in enumerate(cols) if len(S)>=t+1];low=[c for c in range(q) if c not in high]
 assert len(low)*(d+1)<=W and all(s>=len(low)+1 for s in sizes)
 n=q+h;A=[set(range(q))-{c} for c in range(q)]+[set() for _ in range(h)]
 for c,S in enumerate(cols):
  for i in S:A[c].add(q+i);A[q+i].add(c)
 original=[S.copy() for S in A];log=[]
 for phase,C in enumerate([high,low]):
  missing=[(c,q+i) for c in C for i in range(h) if q+i not in A[c]];rng.shuffle(missing)
  for u,v in missing:
   assert len(A[u])+len(A[v])>=n-1;A[u].add(v);A[v].add(u);log.append((u,v));stats['closure_edges_'+str(phase+1)]+=1
 I=list(range(q,n));C=list(range(q));rng.shuffle(I);rng.shuffle(C)
 P=[I[0]]
 for c,i in zip(C,I[1:]):P.extend([c,i])
 for u,v in reversed(log):
  A[u].remove(v);A[v].remove(u)
  assert len(A[u])+len(A[v])>=n-1
  if not any({a,b}=={u,v} for a,b in zip(P,P[1:])):continue
  stats['reverse_reroutings']+=1;dummy=n;cycle=[dummy]+P;N=n+1;pos=cycle.index(u)
  direction=-1 if cycle[(pos+1)%N]==v else 1
  Q=[cycle[(pos+direction*j)%N] for j in range(N)];assert Q[-1]==v
  def adjacent(x,y):return x==dummy or y==dummy or y in A[x]
  pivots=[j for j in range(N-1) if adjacent(u,Q[j+1]) and adjacent(v,Q[j])];assert pivots
  j=rng.choice(pivots);cycle=Q[:j+1]+Q[j+1:][::-1];p=cycle.index(dummy);P=cycle[p+1:]+cycle[:p]
  assert all(b in A[a] for a,b in zip(P,P[1:]))
 assert A==original and len(P)==len(set(P))==n
 assert all(b in A[a] for a,b in zip(P,P[1:]))
 # Direct independent deletion/bridging of universal independent padding.
 universal=[q+i for i in range(h) if row[i]==q]
 for b in range(1,min(3,len(universal),h-2)+1):
  removed=set(rng.sample(universal,b));R=[v for v in P if v not in removed]
  for j,v in enumerate(P):
   if v in removed and 0<j<len(P)-1:
    assert P[j-1]<q and P[j+1]<q;stats['padding_bridges']+=1
  assert all(v in A[u] for u,v in zip(R,R[1:]))
  assert b<=k+1-(max(sizes)-b)
  stats['padding_cases']+=1
 stats['graphs_'+kind]+=1;stats['low_column_cases']+=bool(low);stats['maximum_order']=max(stats['maximum_order'],n)

# No deficit/rank bound is used to prune this small incidence grammar.
for q in range(1,7):
 h=q+1
 for k in range(1,q+1):
  types=[set(T) for size in range(1,min(h,k+1)+1) for T in combinations(range(h),size)]
  def visit(cols,first,rows):
   rem=q-len(cols)
   if any(r+rem<k for r in rows):return
   if sum(max(0,k-r) for r in rows)>rem*(k+1):return
   if rem==0:
    run(cols,k,'small_unpruned');grammar[(q,k)]+=1;return
   for j in range(first,len(types)):
    T=types[j]
    if all(len(T^S)<=k for S in cols):visit(cols+[T],j,[r+(i in T) for i,r in enumerate(rows)])
  visit([],0,[0]*h)

# Fresh dense designs: t independently sampled, edge-disjoint row injections
# make every missing-column size t and every missing-row size at most t.
for q in range(4,41):
 h=q+1
 for t in range(1,q//3+1):
  k=q-t
  for rep in range(2):
   missing=[set() for _ in range(q)]
   for color in range(t):
    B=nx.Graph();left=list(range(q));right=list(range(q,q+h));B.add_nodes_from(left,bipartite=0);B.add_nodes_from(right,bipartite=1)
    edges=[(c,q+i) for c in left for i in range(h) if i not in missing[c]];rng.shuffle(edges);B.add_edges_from(edges)
    M=nx.algorithms.bipartite.maximum_matching(B,top_nodes=left);assert all(c in M for c in left)
    for c in left:missing[c].add(M[c]-q)
   cols=[set(range(h))-T for T in missing]
   choices=[(c,i) for c,T in enumerate(cols) for i in T];rng.shuffle(choices)
   for c,i in choices:
    if sum(i in T for T in cols)<=k:continue
    T=cols[c]-{i}
    if T and all(len(T^S)<=k for j,S in enumerate(cols) if j!=c):cols[c]=T
   run(cols,k,'fresh_injection')

example=json.loads(Path('wowii_rounds/round_16/induced/balanced_deficit_second_stage_example.json').read_text())
for _ in range(30):
 p=list(range(14));rng.shuffle(p);cols=[{p[i] for i in T} for T in example['columns']];rng.shuffle(cols)
 run(cols,8,'affine_second_stage_relabel')
print(json.dumps({'status':'PASS','statistics':dict(stats),'unpruned_small_grammar':{str(k):v for k,v in grammar.items()},'seconds':time.monotonic()-start,'scope':'Universal proof is analytic; independent shuffled forward/reverse closure and padding are finite controls. Small q<=6 grammar uses only the original incidence inequalities, not the derived deficit bounds.'},indent=2))
