#!/usr/bin/env python3
"""Exact reverse-closure guards for the balanced-deficit split theorem."""
from pathlib import Path
from itertools import combinations
from collections import Counter
import json,random,time

def construct(cols,k):
 q=len(cols);h=q+1;n=q+h
 rows=[{c for c,T in enumerate(cols) if i in T} for i in range(h)]
 assert k>=1 and min(map(len,rows))>=k
 assert all(cols) and max(map(len,cols))<=k+1
 assert all(len(a^b)<=k for a,b in combinations(cols,2))
 assert k<=q<=2*k-1
 t=q-k;d=2*k-q
 E=sum(len(R)-k for R in rows);W=sum(k+1-len(T) for T in cols)
 assert W==t-E and 0<=W<=t
 assert all((len(T)-1)*(d+1)>=2*k for T in cols)
 high=[c for c,T in enumerate(cols) if len(T)>=t+1]
 low=[c for c,T in enumerate(cols) if len(T)<=t]
 assert len(low)*(d+1)<=W
 assert all(len(T)>=len(low)+1 for T in cols)
 adj=[set() for _ in range(n)]
 for c,T in enumerate(cols):
  adj[c]=set(range(q))-{c}
  for i in T:adj[c].add(q+i);adj[q+i].add(c)
 added=[];phase_added=[0,0]
 for phase,order in enumerate([high,low]):
  for c in order:
   for i in range(h):
    u=q+i
    if c in adj[u]:continue
    assert len(adj[u])+len(adj[c])>=n-1
    added.append((u,c));phase_added[phase]+=1;adj[u].add(c);adj[c].add(u)
 assert all(len(adj[q+i])==q for i in range(h))
 P=[q]
 for i in range(1,h):P.extend([i-1,q+i])
 repairs=0
 for u,v in reversed(added):
  adj[u].remove(v);adj[v].remove(u)
  assert len(adj[u])+len(adj[v])>=n-1
  if not any({a,b}=={u,v} for a,b in zip(P,P[1:])):continue
  repairs+=1;w=n;cyc=P+[w];N=n+1;j=cyc.index(u)
  step=-1 if cyc[(j+1)%N]==v else 1
  Q=[cyc[(j+step*t)%N] for t in range(N)]
  assert Q[0]==u and Q[-1]==v
  def edge(a,b):return a==w or b==w or b in adj[a]
  cut=next(j for j in range(N-1) if edge(u,Q[j+1]) and edge(Q[j],v))
  cyc=Q[:cut+1]+Q[cut+1:][::-1]
  z=cyc.index(w);P=cyc[z+1:]+cyc[:z]
  assert all(b in adj[a] for a,b in zip(P,P[1:]))
 assert len(P)==n and set(P)==set(range(n))
 assert all(b in adj[a] for a,b in zip(P,P[1:]))
 return P,dict(low_columns=len(low),first_stage_added=phase_added[0],second_stage_added=phase_added[1],reverse_repairs=repairs)

start=time.monotonic();total=0;cases=Counter();stats=Counter();low_example=None
def run(cols,k,label):
 global total
 P,result=construct(cols,k);total+=1;cases[label]+=1;stats.update(result)
 return P,result
# Exhaustive multisets for q<=5. Necessary proven deficit bounds prune
# impossible columns; the scope is stated rather than claimed graph-complete.
for q in range(1,6):
 h=q+1
 for k in range((q+2)//2,q+1):
  d=2*k-q;t=q-k
  minimum=max(1,1+(2*k+d)//(d+1),k+1-t)
  types=[set(T) for s in range(minimum,min(k+1,h)+1) for T in combinations(range(h),s)]
  def visit(cols,start_type,degrees,deficit):
   remaining=q-len(cols)
   if deficit>t or any(r+remaining<k for r in degrees):return
   if not remaining:
    if min(degrees)==k:run(cols,k,'small_column_multisets')
    return
   for j in range(start_type,len(types)):
    T=types[j];newdef=deficit+k+1-len(T)
    if newdef<=t and all(len(T^S)<=k for S in cols):
     visit(cols+[T],j,[r+(i in T) for i,r in enumerate(degrees)],newdef)
  visit([],0,[0]*h,0)
# Circulant dense matrices and safe incidence deletions.
rng=random.Random(1991622)
for q in range(2,31):
 h=q+1
 for k in range((2*q+2)//3,q+1):
  base=[{(j+a)%h for a in range(k+1)} for j in range(q)]
  run(base,k,'circulant')
  cols=[T.copy() for T in base]
  edges=[(c,i) for c,T in enumerate(cols) for i in T];rng.shuffle(edges)
  for c,i in edges:
   if sum(i in T for T in cols)<=k:continue
   candidate=cols[c]-{i}
   if candidate and all(len(candidate^T)<=k for j,T in enumerate(cols) if j!=c):cols[c]=candidate
  run(cols,k,'circulant_after_deletions')
# Blowups of the Fano-complement construction; one universal I vertex.
fano=[set(T) for T in combinations(range(1,8),3) if T[0]^T[1]^T[2]==0]
assert len(fano)==7
for scale in range(1,9):
 cols=[]
 for L in fano:
  T={7*scale}|{(i-1)*scale+j for i in range(1,8) if i not in L for j in range(scale)}
  cols.extend([T.copy() for _ in range(scale)])
 run(cols,4*scale,'Fano_complement_blowup')
# A genuine second-stage design: q=13, h=14, k=8, one column of size 5.
# The other twelve columns are complements of 2-core + 3-affine-point sets.
A=set(range(5));V=set(range(14));cols=[A.copy()]
parallel=[]
for slope in range(3):
 parallel.append([{5+3*x+(slope*x+intercept)%3 for x in range(3)} for intercept in range(3)])
parallel.append([{5+3*x+y for y in range(3)} for x in range(3)])
for j,lines in enumerate(parallel,start=1):
 excluded=1+j%4
 leaves=[a for a in range(5) if a not in {j,excluded}]
 assert len(leaves)==3
 for leaf,line in zip(leaves,lines):cols.append(V-({j,leaf}|line))
P,result=run(cols,8,'affine_second_stage_design')
assert result['low_columns']==1 and result['second_stage_added']==9
low_example=dict(columns=[sorted(T) for T in cols],k=8,q=13,h=14,path=P,closure=result)
Path(__file__).with_name('balanced_deficit_second_stage_example.json').write_text(json.dumps(low_example,indent=2)+'\n')
out=dict(status='PASS',total_constructed_paths=total,case_counts=dict(cases),operation_counts=dict(stats),seconds=time.monotonic()-start,scope='Exact reverse-closure construction; q<=5 admissible column-multiset grammar, circulant matrices through q30, Fano-complement blowups, and an affine second-stage design. Finite guards are not the proof.',new_original_closures=0)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
