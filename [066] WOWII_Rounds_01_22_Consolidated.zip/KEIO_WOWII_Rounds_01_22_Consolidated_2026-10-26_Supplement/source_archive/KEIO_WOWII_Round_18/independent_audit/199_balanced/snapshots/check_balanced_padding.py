#!/usr/bin/env python3
"""Supplementary exact checks of deletion in the padding corollary.
Reuses only the named author constructor, not its top-level test runner.
This is not an independent audit or a proof by finite verification.
"""
from pathlib import Path
from itertools import combinations
import ast,json,time
source=Path(__file__).with_name('check_balanced_deficit.py').read_text()
module=ast.parse(source)
fn=next(x for x in module.body if isinstance(x,ast.FunctionDef) and x.name=='construct')
env={'combinations':combinations}
exec(compile(ast.Module(body=[fn],type_ignores=[]),'author_balanced_constructor','exec'),env)
construct=env['construct'];start=time.monotonic();count=bridges=0

def run(cols,k,removed):
 global count,bridges
 q=len(cols);h=q+1
 assert all(i in T for i in removed for T in cols)
 P,_=construct(cols,k)
 original=set(range(h))-set(removed)
 for i in removed:
  v=q+i;j=P.index(v)
  if 0<j<len(P)-1:
   assert P[j-1]<q and P[j+1]<q;bridges+=1
  P.remove(v)
 assert set(P)==set(range(q))|{q+i for i in original}
 assert len(P)==len(set(P))
 def edge(a,b):
  if a<q and b<q:return a!=b
  if a>=q and b>=q:return False
  if a>=q:a,b=b,a
  return b-q in cols[a]
 assert all(edge(a,b) for a,b in zip(P,P[1:]))
 reduced=[T-set(removed) for T in cols]
 m=max(map(len,reduced));b=len(removed)
 assert b==q+1-len(original) and b<=k+1-m
 count+=1

for q in range(2,21):
 cols=[set(range(q+1)) for _ in range(q)]
 for b in range(1,q):run(cols,q,set(range(b)))
fano=[set(T) for T in combinations(range(1,8),3) if T[0]^T[1]^T[2]==0]
for scale in range(1,9):
 cols=[]
 for L in fano:
  T={7*scale}|{(i-1)*scale+j for i in range(1,8) if i not in L for j in range(scale)}
  cols.extend([T.copy() for _ in range(scale)])
 run(cols,4*scale,{7*scale})
out={'status':'PASS','padding_deletion_cases':count,'actual_clique_bridge_deletions':bridges,'seconds':time.monotonic()-start,'scope':'Exact padding/deletion certificates on complete-split families and Fano-complement blowups; supplementary, not an independent audit.','new_original_closures':0}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
