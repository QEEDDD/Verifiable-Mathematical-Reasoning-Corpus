# The balanced-deficit split case of WOWII 199

**Complete scoped partial proof; independent audit pending. This does not
close the original conjecture. No worldwide novelty claim is made.**

## Statement and original scope

Let G be a finite simple connected noncomplete split graph. Let V=C∪I be a
split partition with I maximum, and put q=|C| and k=κ(G). Write τ(G) for the
maximum vertex order of an induced tree. Suppose

    τ(G)≤k+2,                  |I|=q+1.

Then G has a Hamiltonian path.

The original WOWII 199 hypothesis is precisely τ(G)−2≤κ(G), for connected
simple graphs of order greater than one. The equality |I|=|C|+1 is an
additional restriction in this partial theorem; it is not assumed to follow
for every possible counterexample.

The proof below also works directly for an incidence matrix with row degrees
at least k, column sizes at most k+1, and pairwise column symmetric differences
at most k. Exact equality of k with the connectivity is unnecessary for that
matrix statement.

## 1. Locked split-graph inequalities

For c∈C write A_c=N(c)∩I, s_c=|A_c|, and for i∈I write r_i=d_C(i).
The standard split connectivity formula gives r_i≥k. An induced star and an
induced double-star give, respectively,

    s_c≤k+1,                |A_c△A_b|≤k.                 (1)

The latter induced tree has vertices c,b and the independent vertices in
the symmetric difference; common independent neighbors are omitted. It has
order 2+|A_c△A_b|. We choose I maximum, so every column is nonempty.

We may assume k≥2. When k=1 the calculation in the next section gives q=1,
and the graph is the three-vertex path. All formulas below also apply to
that case.

## 2. The available deficit budget

Let E_total=Σ_i r_i=Σ_c s_c. Counting pairwise column differences by rows gives

    Σ_{c<b}|A_c△A_b| = Σ_i r_i(q−r_i).

Since k≤r_i≤q and |I|=q+1,

    Σ_i r_i(q−r_i)
      ≥ k Σ_i(q−r_i)
      = k(q(q+1)−E_total)
      ≥ kq(q−k).

The last inequality uses E_total≤q(k+1). On the other hand (1) bounds the
same sum by kq(q−1)/2. Consequently

    k≤q≤2k−1.                                             (2)

Put

    t=q−k≥0,                  d=2k−q≥1.

The excess of the row degrees above k is

    E=Σ_i(r_i−k)≥0.

The total column deficit below k+1 is

    W=Σ_c(k+1−s_c)
      =q(k+1)−k(q+1)−E
      =t−E≤t.                                               (3)

All individual deficits in this sum are nonnegative.

## 3. Every column has a quantitative lower bound

Fix a column A=A_c of size s, and put

    E_A=Σ_{i∈A}(r_i−k).

Sum its symmetric differences with all q columns, including its zero
difference with itself. Counting membership row by row gives the exact
identity

    Σ_b |A△A_b|
      = Σ_{i∈A}(q−r_i)+Σ_{i∉A}r_i
      = k(q+1)+s(q−2k)+E−2E_A.

By (1), this is at most k(q−1). Since 0≤E_A≤E, it follows that

    sd≥2k+E−2E_A≥2k−E.                                    (4)

The deficit of this particular column is k+1−s. By (3),

    E≤t−(k+1−s)=s−d−1.

Substituting this into (4) yields

    sd≥2k−s+d+1,
    hence                 (s−1)(d+1)≥2k.                  (5)

This lower bound holds for every column, not merely an average column.

## 4. Two stages of classical Hamiltonian-path closure

We use the classical closure rule: for nonadjacent vertices u,v in an
n-vertex graph, adding uv preserves traceability whenever

    d(u)+d(v)≥n−1.                                         (6)

A self-contained proof is given below. In a split graph with h=|I|=q+1,
a missing incidence ic satisfies (6) whenever

    r_i+s_c≥h,

because d(c)=q−1+s_c and n=q+h.

First call a column **high** if s_c≥t+1=q+1−k. Its missing incidences all
satisfy (6), since r_i≥k. Add all of them, successively, making every high
column adjacent to all of I. Degrees only increase during this procedure.

Let ℓ be the number of columns that were not high. Each has s_c≤t, and
therefore contributes at least

    (k+1)−t=d+1

to W. By (3),

    ℓ(d+1)≤W≤t.                                           (7)

By (5), every column satisfies

    (s_c−1)(d+1)≥2k>t≥ℓ(d+1).

In particular s_c≥ℓ+1 (indeed the strict inequality gives the slightly
stronger s_c≥ℓ+2). After the first closure stage, every independent vertex
has degree at least q−ℓ, the number of high columns. Thus every remaining
missing incidence satisfies

    r_i+s_c≥(q−ℓ)+(ℓ+1)=q+1=h.

Apply (6) again to fill all remaining columns. The final graph is the
complete split graph with q clique vertices and q+1 independent vertices.
It has an alternating spanning path. Reverse all closure steps to obtain a
spanning path in the original graph. ∎

## 5. A padding corollary

Under the original split hypotheses, let h=|I| and m=max_c s_c. Suppose

    0≤q+1−h≤k+1−m.                                        (8)

Then G is traceable. To see this, add b=q+1−h new independent vertices, each
adjacent to all clique vertices. The new columns have size s_c+b≤k+1,
their pairwise symmetric differences are unchanged, and every row degree
is at least k. The preceding matrix theorem applies. Remove the added
independent vertices from its spanning path; whenever one was internal,
join its two clique neighbors using a clique edge. This produces a
spanning path of G. Condition (8) is a genuine restriction, not a reduction
of every split graph to the balanced-deficit case.

## Appendix: attribution and proof of the closure rule

Rule (6) is the standard Hamiltonian-path form of Bondy–Chvátal closure,
not a new theorem. Add a universal vertex w to an n-vertex graph G, and call
the resulting graph H, of order N=n+1. The inequality in (6) becomes

    d_H(u)+d_H(v)≥N.

If a Hamiltonian cycle in H+uv uses uv, remove that edge and write the
resulting Hamiltonian path as u=v₁,v₂,…,v_N=v. Among the N−1 indices j, the
sets defined by uv_{j+1}∈E(H) and v_jv∈E(H) have total cardinality at least N.
Some index belongs to both. Reversing the corresponding suffix gives the
Hamiltonian cycle

    v₁,…,v_j,v_N,v_{N−1},…,v_{j+1},v₁

in H. Delete w to obtain a Hamiltonian path of G. If the original cycle did
not use uv, deletion of w already suffices.

Primary attribution: J. A. Bondy and V. Chvátal,
[*A method in graph theory* (1976)](https://doi.org/10.1016/0012-365X(76)90078-9).
The original WOWII statement is locked in the pinned source archive linked
in this directory's source record. Finite guards are supplementary checks,
not the proof.
