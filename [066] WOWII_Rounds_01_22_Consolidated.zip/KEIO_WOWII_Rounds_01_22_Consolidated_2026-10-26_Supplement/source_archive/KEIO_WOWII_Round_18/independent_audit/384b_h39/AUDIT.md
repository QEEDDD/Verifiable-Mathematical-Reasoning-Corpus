# Independent audit: h = 39 exclusion for WOWII 384b

**Verdict: PASS — a proved partial reduction, not closure of 384b.**

Audited author manuscript `round_18/twodomination/matching_h39.tex`, SHA-256
`3c8e13f187eecd5250fa05458d198040671e2c344f740aaa8d469ace90a3194b`.
The result excludes exactly h=39. Together with the earlier audited exclusions,
the residual high-vertex range is 11–38; the representative order bound remains 42.
No source-priority or full-conjecture claim is made by this mathematical audit.

## Universal argument

1. A maximum cut permits omission of at least ceil(h/2) high vertices. Since the low vertices have triangle counts only 0 and 1, h=39 criticality forces k=20, t=41, all high triangle counts distinct and at least 2, and both low counts present. The full-degree rank argument is valid: an untouched neighbor in a neighborhood has at least the center's triangle count, is therefore high, and must be strictly higher-ranked. This yields the displayed bounds and independently recomputed profile 3^2,4^3,5^4,6^5,7^6,8^7,9^6,10^6.
2. DeLaViña–Goddard–Henning–Pepper–Vaughan (2011), Theorem 3, gives gamma_2 <= mu(H)+|L| without a low-vertex independence hypothesis. Its primary cached paper, definitions, alternating-path proof, and applicability were freshly audited in the companion h40 audit (`round_17/independent_audit/384b_h40/AUDIT.md`). Criticality forces a near-perfect matching, with unrestricted unmatched vertex. This is the only substantive published input here.
3. The P/Q low-triangle dichotomy is exhaustive. A triangle consisting entirely of low vertices would be a whole connected K3 component. In Q, x is isolated in G[L]; a component containing a count-zero low vertex therefore supplies a distinct low vertex adjacent to a high root, by connectedness. Its extra high adjacencies cause no problem: uncredited support remains selected.
4. The artificial-neighbor construction is pointwise valid using full degrees, including the matched partner. Every filler is compensated by an uncredited selected low neighbor. Sets may be asymmetric. The proof deliberately repairs **artificial** badness, even when actual support already suffices. Pair repairs and the unmatched repair are simultaneously valid, using initial selected neighbors and each vertex's own matched partner only.
5. P and basic Q low omissions affect unselected vertices only at the omitted low vertex itself, whose two neighbors remain selected. The overlapping Q exchange is valid: the support-two root u is not initially selected and is not ordinarily added; its artificially support-one partner q is ordinarily added. Replace q by u and omit x. Vertex q retains one actual initial neighbor plus u. It cannot be adjacent to x (x has precisely the two Q roots as neighbors), so this initial support is not lost. Other matching pairs never relied on subsequently added q. The other Q root is in S. Thus no unselected vertex is harmed. This remains true if q was actually already well-supported: the conservative artificial-repair algorithm still deliberately included it. The exchange event is disjoint from the basic Q omission. There is at most one support-two root, hence at most one credited exchange.
6. The two exchange event counts correctly distinguish whether the other Q root belongs to A_q. Their minimum is a valid lower bound independent of this choice. Pair-event categories, badness numerators, unmatched-weight loss, and both base low-omission numerators are correct.
7. All beta weights are at most zeta, so summing matching-edge inequalities loses at most zeta for the unmatched vertex, regardless of its type. Overinclusive type inequalities are harmless. The exact expectation is strictly below 19, giving an integral 2-dominating set of size at most |L|+18 and the contradiction.

## Independent exact verification

`check_independent.py` was written independently, using closed-case pair-event formulas instead of the author's three-category summation, and enumerating actual root indices rather than only collapsed types.

- All **1,814** integer inequalities pass: 1,249 Q and 565 P.
- All **28,899 Q placements** on the 39 actual ranked vertices, plus all **39 P placements**, pass. They collapse to the author's 359 types.
- Independent worst bounds are Q = 5617583945/295774596 and P = 16662763795/887323788.
- Strict margins below 19 are respectively **2133379/295774596** and **196388177/887323788**.
- Direct subset enumeration independently checks **9,316 pair-formula cases**, **354 exchange-formula cases**, and **456,640 event samples**.
- Physical repairs on **2,700 independently generated actual graphs** and **604,800 initial high subsets** all yield valid 2-dominating sets. These include disconnected high cores, adjacent low vertices, asymmetric artificial sets, repeated/overlapping credited roots, unmatched support-two roots, Q roots matched to each other, and extra low support at an ordinary matched partner. Actual controls execute **6,154 extra Q exchanges**, 60,480 P omissions, and 120,960 basic Q omissions.
- The author checker was rerun from the snapshot. Its full JSON certificate agrees byte-for-byte with the supplied certificate.

The finite integer inequalities and placement sweep are proof dependencies, fully reproduced with exact arithmetic. Small physical graph tests corroborate, but do not replace, the universal repair argument.

## Reproduction and limits

Run `python check_independent.py`; read `independent_results.json`. The author checker and manuscript are frozen in `snapshots/`; `author_rerun.json` records its rerun. No solver is a verification dependency. No assumption that H is connected or that low vertices are independent is used. Earlier detailed attachment-stability classifications and order reductions are not needed to exclude h=39.
