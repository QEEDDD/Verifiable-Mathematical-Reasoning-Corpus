"""Independent closed-case arithmetic, physical repairs and boundary placements."""
from math import comb
from fractions import Fraction
from itertools import combinations,product
from collections import Counter
import random,json,time
start=time.monotonic();rng=random.Random(3843918)
def C(n,k):return comb(n,k) if 0<=k<=n else 0
h,s=39,14;D=C(h,s)
profile=[min(d for d in range(3,h) if d*(d-1)>=2*(i+1) and d*(d-2)>=3*i+2-h) for i in range(1,h+1)]
B0=dict(zip(range(3,11),(383804427,364489027,291476815,203279727,104890051,41134373,-62663615,-161677327)))
B1=dict(zip(range(3,11),(0,0,0,0,-101591575,-212045947,-284255827,-323629527)));zeta=max(B0.values())
def beta(a,r,kind):return B0[a] if r==0 else B1[a] if r==1 else 0 if kind=='Q' else -zeta

def bad(a,r,hh=h,ss=s):
 return C(hh-1-a,ss)+a*C(hh-1-a,ss-1) if r==0 else C(hh-a,ss) if r==1 else 0

def pair(a,r,b,t,c,hh=h,ss=s):
 d,e=a-r,b-t;N=hh-d-e+c
 if r==2 or t==2:return 0
 if r==t==1:return C(N,ss)
 if r==1:return C(N,ss)+(e-1-c)*C(N,ss-1)
 if t==1:return C(N,ss)+(d-1-c)*C(N,ss-1)
 return (d+e-2-c)*C(N,ss-1)+(d-1-c)*(e-1-c)*C(N,ss-2)
def extra(a,hh=h,ss=s):return min(C(hh-a-1,ss-1),(a-1)*C(hh-a-2,ss-2))
checks=Counter();mins={}
for kind,rs in [('Q',range(3)),('P',(0,2))]:
 types=list(product(range(3,11),rs));slacks=[]
 for j,(a,r) in enumerate(types):
  assert beta(a,r,kind)<=zeta
  for b,t in types[j:]:
   for c in range(min(a-r,b-t)):
    value=pair(a,r,b,t,c)
    if kind=='Q' and r==2 and t==0:value+=extra(b)
    if kind=='Q' and t==2 and r==0:value+=extra(a)
    slack=value-beta(a,r,kind)-beta(b,t,kind);assert slack>=0;slacks.append(slack)
 checks[kind]=len(slacks);mins[kind]=min(slacks)

# All 28,899 actual Q root placements in the 39-vertex degree profile,
# not merely the author's collapsed type loop.
maxnum={};arg={};unique=set();placements=Counter()
for kind in ('Q','P'):
 g=lambda a,r:bad(a,r)-beta(a,r,kind)
 omission=C(h-2,s-2) if kind=='Q' else C(h-1,s-1)
 base=s*D+sum(g(a,0) for a in profile)+zeta-omission
 if kind=='Q':
  configs=((u,v,w) for u,v in combinations(range(h),2) for w in range(h))
 else:configs=((u,) for u in range(h))
 for loc in configs:
  credit=Counter()
  if kind=='Q':
   u,v,w=loc;credit[u]+=1;credit[v]+=1;credit[w]+=1
   key=(kind,profile[u],profile[v],profile[w],w in (u,v))
  else:credit[loc[0]]=2;key=(kind,profile[loc[0]])
  num=base+sum(g(profile[u],r)-g(profile[u],0) for u,r in credit.items())
  assert num<19*D;placements[kind]+=1;unique.add(key)
  if kind not in maxnum or num>maxnum[kind]:maxnum[kind]=num;arg[kind]=[profile[u] for u in loc]
assert len(unique)==359

# Direct support-event enumeration, using bit masks and the piecewise count.
formula_cases=sample_tests=exchange_cases=0
for hh in range(4,11):
 for a in range(3,min(6,hh-1)+1):
  for b in range(a,min(6,hh-1)+1):
   for r,t in product(range(3),repeat=2):
    d,e=a-r,b-t
    for c in range(max(0,d+e-hh),min(d,e)):
     common=((1<<c)-1)<<2;left=((1<<(d-1-c))-1)<<(2+c);right=((1<<(e-1-c))-1)<<(d+1)
     A=2|common|left;B=1|common|right;count=[0]*(hh+1)
     for S in range(1<<hh):
      x=r+(A&S).bit_count();y=t+(B&S).bit_count()
      if not(S&3) and x<2 and y<2 and x+y>=1:count[S.bit_count()]+=1
      sample_tests+=1
     for ss in range(hh+1):assert count[ss]==pair(a,r,b,t,c,hh,ss);formula_cases+=1
  A=1|sum(1<<i for i in range(2,a+1))
  for v in (2,a+1):
   if v>=hh:continue
   count=[0]*(hh+1)
   for S in range(1<<hh):
    if not(S&3) and S>>v&1 and (A&S).bit_count()==1:count[S.bit_count()]+=1
   for ss in range(hh+1):
    value=C(hh-a-1,ss-1) if A>>v&1 else (a-1)*C(hh-a-2,ss-2)
    assert count[ss]==value;exchange_cases+=1

# Actual graph tests: all low vertices selected initially, then credited
# omissions and the possible support-two-root exchange are performed.
def add(A,neighbors):
 v=len(A);A.append(0)
 for u in neighbors:A[u]|=1<<v;A[v]|=1<<u
 return v

def high_edge(A,u,v):A[u]|=1<<v;A[v]|=1<<u
physical=Counter()
for hh in (5,7,9):
 for rep in range(180):
  H=[0]*hh
  for u in range(0,hh-1,2):high_edge(H,u,u+1)
  for u,v in combinations(range(hh),2):
   if rng.randrange(4)==0:high_edge(H,u,v)
  for boundary in ('P','Q_distinct','Q_overlap','Q_unmatched','Q_paired_roots'):
   A=H.copy();credit=[0]*hh;kind='P' if boundary=='P' else 'Q'
   if boundary=='P':
    u=0;x=add(A,[u]);y=add(A,[u,x]);credit[u]=2;roots=(u,)
   else:
    u,v,w=(0,2,4) if boundary=='Q_distinct' else (hh-1,0,hh-1) if boundary=='Q_unmatched' else (0,1,0) if boundary=='Q_paired_roots' else (0,2,0)
    high_edge(A,u,v);x=add(A,[u,v]);credit[u]+=1;credit[v]+=1
    z=add(A,[w]+([1] if boundary=='Q_overlap' and rep%2 else []));credit[w]+=1;roots=(u,v,w)
   # Uncredited degree-two connectors make the whole graph connected even
   # when its high core is disconnected. A pendant P2 forces low adjacency.
   for j in range(2,hh,2):add(A,[0,j])
   low=add(A,[hh-1]);add(A,[low])
   for u in range(hh):
    while A[u].bit_count()<3:add(A,[u])
   forced=((1<<len(A))-1)^((1<<hh)-1);lowcounts=[(A[u]&forced).bit_count() for u in range(hh)]
   artificial=[]
   for u in range(hh):
    a=min(hh-1,A[u].bit_count());d=a-credit[u];actual=[v for v in range(hh) if A[u]>>v&1]
    mate=u^1 if u<hh-1 else None
    rng.shuffle(actual);chosen=[] if mate is None else [mate]
    chosen+=(v for v in actual if v not in chosen)
    chosen=chosen[:d]
    fillers=[v for v in range(hh) if v!=u and v not in chosen];rng.shuffle(fillers);chosen+=fillers[:d-len(chosen)]
    artificial.append(sum(1<<v for v in chosen))
    assert len(chosen)==d and (mate is None or mate in chosen)
   for S in range(1<<hh):
    support=[credit[u]+(artificial[u]&S).bit_count() for u in range(hh)]
    assert all((A[u]&S).bit_count()+lowcounts[u]>=support[u] for u in range(hh))
    selected=S|forced
    for u in range(0,hh-1,2):
     v=u+1;bu=not(S>>u&1) and support[u]<2;bv=not(S>>v&1) and support[v]<2
     if bu and bv:
      if support[u]==support[v]==0:selected|=(1<<u)|(1<<v)
      elif support[u]==0:selected|=1<<u
      else:selected|=1<<v
     else:
      if bu:selected|=1<<u
      if bv:selected|=1<<v
    if not(S>>(hh-1)&1) and support[hh-1]<2:selected|=1<<(hh-1)
    if kind=='P':
     if S>>roots[0]&1:selected&=~(1<<x);physical['P_omissions']+=1
    else:
     u,v,w=roots
     if S>>u&1 and S>>v&1:selected&=~(1<<x);physical['Q_base_omissions']+=1
     if w in (u,v) and w<hh-1:
      q=w^1;other=v if w==u else u
      if credit[q]==0 and not(S>>w&1) and not(S>>q&1) and S>>other&1 and (artificial[q]&S).bit_count()==1:
       assert selected>>q&1 and not(selected>>w&1)
       selected=(selected&~(1<<q))|(1<<w);selected&=~(1<<x);physical['Q_extra_exchanges']+=1
    assert all(selected>>u&1 or (A[u]&selected).bit_count()>=2 for u in range(len(A)))
    physical['initial_sets']+=1
   physical['graphs']+=1

print(json.dumps({'status':'PASS','degree_multiplicities':dict(Counter(profile)),'denominator':D,'inequality_counts':dict(checks),'minimum_slacks':mins,'actual_vertex_placements':dict(placements),'distinct_type_placements':len(unique),'worst_upper_bounds':{k:str(Fraction(v,D)) for k,v in maxnum.items()},'strict_margins':{k:str(19-Fraction(v,D)) for k,v in maxnum.items()},'worst_root_types':arg,'direct_pair_formula_cases':formula_cases,'explicit_event_samples':sample_tests,'direct_exchange_formula_cases':exchange_cases,'physical_controls':dict(physical),'seconds':time.monotonic()-start,'scope':'Exact arithmetic proves the finite certificate; direct event and actual graph repair controls independently corroborate the universal argument.'},indent=2))
