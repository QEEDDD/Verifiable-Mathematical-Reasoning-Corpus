#!/usr/bin/env python3
"""Exact, standard-library certificate for the h39 boundary paired repair."""
from math import comb
from collections import Counter
from fractions import Fraction as F
from itertools import combinations_with_replacement
from pathlib import Path
import json
H,S=39,14
C=lambda n,k:comb(n,k) if 0<=k<=n else 0
DEN=C(H,S)
profile=[next(d for d in range(3,H) if C(d,2)>=i+1 and d*(d-2)>=3*i+2-H)
         for i in range(1,H+1)]
COUNT=Counter(profile)
assert COUNT=={3:2,4:3,5:4,6:5,7:6,8:7,9:6,10:6}
B0={3:383804427,4:364489027,5:291476815,6:203279727,
    7:104890051,8:41134373,9:-62663615,10:-161677327}
B1={3:0,4:0,5:0,6:0,7:-101591575,8:-212045947,9:-284255827,10:-323629527}
ZETA=383804427

def bad(a,r):
    d=a-r
    return C(H-1-d,S)+(d*C(H-1-d,S-1) if r==0 else 0) if r<2 else 0

def saving(a,r,b,t,c):
    d=a-r;e=b-t;out=0
    for i in range(2):
        for j in range(2):
            for k in range(2):
                if r+i+j<=1 and t+k+j<=1 and r+t+i+k+2*j>=1:
                    out+=C(d-1-c,i)*C(c,j)*C(e-1-c,k)*C(H-d-e+c,S-i-j-k)
    return out

def extra(a):return min(C(H-a-1,S-1),(a-1)*C(H-a-2,S-2))
def beta(a,r,kind):
    return B0[a] if r==0 else B1[a] if r==1 else 0 if kind=='Q' else -ZETA

def rat(x):return dict(numerator=x.numerator,denominator=x.denominator,decimal=float(x))
checks={}
for kind in ['Q','P']:
    types=[(a,r) for a in COUNT for r in ([0,1,2] if kind=='Q' else [0,2])]
    rows=[]
    for i,(a,r) in enumerate(types):
        assert beta(a,r,kind)<=ZETA
        for b,t in types[i:]:
            for c in range(max(0,a-r+b-t-H),min(a-r,b-t)):
                q=saving(a,r,b,t,c)
                if kind=='Q' and r==2 and t==0:q+=extra(b)
                if kind=='Q' and t==2 and r==0:q+=extra(a)
                slack=q-beta(a,r,kind)-beta(b,t,kind)
                assert slack>=0,(kind,a,r,b,t,c,slack)
                rows.append(dict(a=a,r=r,b=b,t=t,common=c,slack=slack))
    checks[kind]=rows
placements=[]

def evaluate(kind,loc,ct):
    assert sum(ct.values())==H and min(ct.values())>=0
    omit=C(H-2,S-2) if kind=='Q' else C(H-1,S-1)
    numerator=S*DEN+sum(n*(bad(a,r)-beta(a,r,kind)) for (a,r),n in ct.items())+ZETA-omit
    upper=F(numerator,DEN)
    assert upper<19,(kind,loc,upper)
    placements.append(dict(kind=kind,placement=loc,upper=rat(upper),margin=rat(19-upper)))

for a,b in combinations_with_replacement(sorted(COUNT),2):
    if a==b and COUNT[a]<2:continue
    for c in COUNT:
        ct=Counter({(d,0):n for d,n in COUNT.items()})
        ct[a,0]-=1;ct[b,0]-=1;ct[a,1]+=1;ct[b,1]+=1
        # Three distinct roots, even if their degree lower bounds coincide.
        if ct[c,0]>0:
            dd=ct.copy();dd[c,0]-=1;dd[c,1]+=1
            evaluate('Q',dict(a=a,b=b,c=c,overlap=False),dd)
        # The extra support is incident to one of the two Q roots.
        if c in (a,b):
            dd=ct.copy();dd[c,1]-=1;dd[c,2]+=1
            evaluate('Q',dict(a=a,b=b,c=c,overlap=True),dd)
for a in COUNT:
    ct=Counter({(d,0):n for d,n in COUNT.items()});ct[a,0]-=1;ct[a,2]+=1
    evaluate('P',dict(root=a),ct)
assert len(placements)==359
worst={kind:max((x for x in placements if x['kind']==kind),
               key=lambda x:F(x['upper']['numerator'],x['upper']['denominator'])) for kind in ['Q','P']}
# Direct set-counting controls for the general support-saving and exchange events.
from itertools import combinations
controls=exchange_controls=0
for h in range(4,9):
    for sample in range(1,h):
        sets=[set(T) for T in combinations(range(h),sample)]
        for a in range(3,min(6,h-1)+1):
            for r in range(3):
                d=a-r
                for b in range(a,min(6,h-1)+1):
                    for t in range(3):
                        e=b-t
                        for c in range(max(0,d+e-h),min(d,e)):
                            common=set(range(2,2+c));pos=2+c
                            left=set(range(pos,pos+d-1-c));pos+=d-1-c
                            right=set(range(pos,pos+e-1-c))
                            Av={1}|common|left;Aw={0}|common|right
                            direct=0
                            for T in sets:
                                if 0 in T or 1 in T:continue
                                x=r+len(Av&T);y=t+len(Aw&T)
                                direct+=int(x<=1 and y<=1 and x+y>=1)
                            formula=0
                            for i in range(2):
                                for j in range(2):
                                    for k in range(2):
                                        if r+i+j<=1 and t+k+j<=1 and r+t+i+k+2*j>=1:
                                            formula+=C(d-1-c,i)*C(c,j)*C(e-1-c,k)*C(h-d-e+c,sample-i-j-k)
                            assert direct==formula
                            controls+=1
            # q=1, its matched prepaid root u=0; test both locations of v.
            Aq={0}|set(range(2,a+1))
            for v in [2,a+1]:
                if v>=h:continue
                direct=sum(0 not in T and 1 not in T and v in T and len(Aq&T)==1 for T in sets)
                formula=C(h-a-1,sample-1) if v in Aq else (a-1)*C(h-a-2,sample-2)
                assert direct==formula
                exchange_controls+=1

result=dict(scope='Exact finite arithmetic for the h39 boundary paired-repair proof; independent audit pending.',
 h=H,sample_size=S,denominator=DEN,degree_multiplicities=dict(COUNT),
 beta_0=B0,beta_1=B1,beta_Q_2=0,beta_P_2=-ZETA,zeta=ZETA,
 inequality_counts={kind:len(rows) for kind,rows in checks.items()},
 placement_count=len(placements),direct_event_controls=controls,
 direct_exchange_controls=exchange_controls,worst_cases=worst,
 inequalities=checks,placements=placements)
Path(__file__).with_name('matching_h39_certificate.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('inequalities','placements')},indent=2))
