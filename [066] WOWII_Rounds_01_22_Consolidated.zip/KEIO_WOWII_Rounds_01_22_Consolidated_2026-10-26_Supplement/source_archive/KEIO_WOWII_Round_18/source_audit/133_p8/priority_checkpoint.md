# Bounded antecedent check: P8-free local-independence classification

Date: 26 October 2026. This is a source-priority checkpoint, not mathematical approval and not a worldwide-priority certificate.

## Candidate scope

The worker proposes that a connected graph with no C4 as a **subgraph**, no induced P8, and α(G[N(v)])≥3 at every vertex is one of Petersen, Heawood, Heawood with one edge contracted, or the 13-vertex graph obtained from Heawood by one Y–Δ move. Only the last, triangle-containing branch is proposed as additional work. The consequent weighted inequality is 2m−3t<4n, where t counts triangles. This remains a partial application to WOWII133, not an unrestricted closure.

## Findings

**No exact prior triangle-containing classification or exact full-class weighted inequality was located in this bounded check.** The first three cases are already the precise theorem of Chudnovsky–Stacho and must be credited as prior work. The fourth graph itself is also long known; no claim to inventing that graph is justified by this check.

### 1. Exact earlier triangle-free classification

Maria Chudnovsky and Juraj Stacho, _3-colorable subclasses of P8-free graphs_, SIAM J. Discrete Math.32(2)(2018),1111–1138, DOI10.1137/16M1104858. [Author manuscript](https://web.math.princeton.edu/~mchudnov/p8free1.pdf), dated 1 October2017, Theorem1. A connected girth-at-least-five P8-free graph is Petersen, Heawood, Heawood with one edge contracted, or has a vertex of degree at most two. The cached primary full text was rechecked. Because λ(v)=d(v) in triangle-free graphs, this is exactly the proposed first-three branch, not just vaguely related coloring work. The paper's other headline theorems add no triangles/no C5, or no induced C4 and C5, and concern coloring; these are not the proposed unrestricted triangle-containing local-independence classification.

### 2. The 13-vertex graph is an established graph

Ryo Hanaki, Ryo Nikkuni, Kouki Taniyama and Akiko Yamazaki, _On intrinsically knotted or completely 3-linked graphs_, Pacific J. Math.252(2011),407–425, DOI10.2140/pjm.2011.252.407. [Author version](https://arxiv.org/abs/1006.0698), v4,21 January2011; first submission3 June2010. The introduction identifies C₁₄ as the Heawood graph, and Figure1.3 (visually checked, author PDFp4) has C₁₃→C₁₄, with arrows denoting one ΔY exchange. Thus its inverse is the Y–Δ–Heawood graph. These labels belong to a named Heawood family and **C₁₃ here is not a cycle**. The paper studies intrinsic knotting/linking, not the P8/local-independence classification. This corroborates the explicit inverse description in Erick Gonzalez and Oscar Vega's “The Topological Symmetry Group of C13,” [Fresno State2021 symposium proceedings](https://academics.fresnostate.edu/grants/documents/Proceedings%20of%20the%202021%20Symposium.pdf),p28. The construction is prior; the classification claim still needs its own proof and bounded priority wording.

### 3. Newer square-free structure source has additional restrictions

Ran Chen and Baogang Xu, _Structure and linear-Pollyanna for some square-free graphs_, Discrete Math.349(6)(2026),114979, DOI10.1016/j.disc.2026.114979. [Primary arXiv author text](https://arxiv.org/abs/2407.18506); [publisher record](https://www.sciencedirect.com/science/article/pii/S0012365X26000038). The full2024 author version and current publisher statements were checked. Theorem1.5 assumes connectedness, no clique cutset, and no universal clique (publisher wording: universal vertex), and requires additionally bull-free or hammer-free. It gives a girth-five graph or a clique blowup of one. Corollary1.1 adds P8 but retains the bull/hammer exclusion and is a chromatic bound. Those exclusions are not present in the proposed class. Neither this source's statements nor its structural hypotheses can simply be substituted for the candidate theorem.

### 4. Known bisimplicial antecedent covers only a restricted branch

Maria Chudnovsky and Paul Seymour, _Even-hole-free graphs still have bisimplicial vertices_, J. Combin. Theory Ser.B161(2023),331–381, DOI10.1016/j.jctb.2023.02.009. [Primary author abstract/version](https://arxiv.org/abs/1909.10967); [current author manuscript](https://web.math.princeton.edu/~pds/papers/bisimplicial2/paper.pdf). Every nonempty even-hole-free graph has a vertex whose neighborhood is the union of two cliques. It follows immediately that such a vertex has λ≤2. This disposes of the even-hole-free branch of the min-λ≥3 question, but allows C6/C8-containing graphs to remain and is not the requested four-graph classification. The primary abstract explicitly corrects a serious flaw in the older2008 proof; cite the corrected result rather than treating that original proof as verified. Here the theorem/primary abstract were checked, not the full long proof.

## Fresh public-record check

Four all-state GitHub issue/PR searches were completed on26 October2026; queries, counts, timestamps and full returned bodies are saved beside this note. Formal Conjectures Heawood:0; Agentic Conjectures Heawood:0. Exact GraphConjecture133:3, comprising the known floor-removal issue5717/PR5727 plus an unrelated160 source-fidelity issue. Formal Conjectures “local independence”:13; the relevant bodies concern other numbered conjectures, statement intake, or an unrelated Erdős problem, not the proposed P8 classification. Search is over titles/bodies, **not all comments, attachments or all websites**. No complete prior theorem can be ruled out merely from these zero/excluded hits.

## Boundaries

Focused web queries included P8/P_8-free, C4/square-free, diamond-free, Heawood/Y–Δ, local independence, weighted density and bisimplicial vertices. The primary results above were compared by actual hypotheses, not only matching titles. No exact collision was found in the sources inspected, but this is not exhaustive bibliographic coverage. No new mathematical claim is validated by search absence; no worldwide-first or currently-open curator certification is made.
