# Radius-critical antecedent and comparison limitation

S. Fajtlowicz, “A characterization of radius-critical graphs,” *Journal of Graph Theory* **12**(4) (1988), 529–532, DOI [10.1002/jgt.3190120409](https://doi.org/10.1002/jgt.3190120409), is a relevant classical precursor. The indexed primary scan states that every radius-critical graph is a ciliate. The ciliates include even cycles with equal-length pendant paths, with paths and cycles as limiting forms. In particular, the equal-depth pendant-arm cores occurring in the present radius-five and decorated-cycle arguments are classical ciliate configurations, not newly introduced graph families.

Our asserted classification concerns all vertices and edges of a graph under additional induced-path and strong C4-exclusion hypotheses. In addition to a ciliate core, it allows matching edges among attachment vertices and triangles on cycle edges, and it must rule out further cross-attachment edges. The classical radius-critical statement alone does not establish those assertions. The preceding round's one-layer statement also retained an explicit dominating-cycle hypothesis.

This comparison is bounded: the source auditor confirmed the bibliographic record, indexed theorem statement, and definition, but access to the complete four-page primary scan was blocked by a CoCalc HTML redirect and inaccessible Wiley full text. We therefore do not claim an exhaustive full-paper comparison or worldwide priority. No exact prior decorated classification was found in the focused search. The mathematical proofs and the separately recorded source review should be distinguished.

The already delivered Round16 archive remains unchanged. This note is supplemental related-work context for the next manuscript.
