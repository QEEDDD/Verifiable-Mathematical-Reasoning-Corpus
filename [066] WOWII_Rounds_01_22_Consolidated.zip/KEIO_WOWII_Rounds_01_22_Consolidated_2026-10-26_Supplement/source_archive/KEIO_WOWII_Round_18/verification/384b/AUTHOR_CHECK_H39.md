# Author checks

- Exact binomial inequalities: Q1,249; P565; all pass.
- Boundary type placements:351 Q +8 P =359; all strict upper bounds below19.
- Small direct set controls:3,198 pair-saving parameter cases and138 exchange cases; all pass.
- WorstQ margin2133379/295774596; worstP margin196388177/887323788.
- Four-page PDF compiled with no remaining warnings/overfull boxes; all four rendered pages visually inspected.
- Independent audit pending. No full closure or novelty claim.

Frozen authoritative hashes:
```
3c8e13f187eecd5250fa05458d198040671e2c344f740aaa8d469ace90a3194b  matching_h39.tex
b462f1b60db5d65594178c9ee2e33fb9125434c1be96d9b32a84df6d67c0009d  check_matching_h39.py
```
