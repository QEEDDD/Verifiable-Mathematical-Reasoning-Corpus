# Independent audit: eleven P9-free local-independence cores

**PASS — a computer-assisted arbitrary-order classification and density theorem.**

The exact finite proof certificate, its implementation, universal extension argument, density induction, and precise original-WOWII133 corollary pass. Original133 is proved here only for the stated parameter ranges, not in full.

## Pinned files

- `p9_min_local_classification.md`: `95dbb738b47e234f4d2edf648222a54aea9cda2d5612cfb4efe6c8e70980ed96`.
- `manuscript.tex`: `bab20ad65bf5ec822cf573e1cae5824de798d06e5b1431eec72b86d72a2cb894`.
- `p9_core_certificate.json.gz`: `9d76bd6ba46c60a43175f792e0e67517c4d19b22b068917eeee5e34327544e1b`.
- `verify_p9_certificate.py`: `432b727c810c197778506a0be1d80a9f3675627e7a646f36f30ad88ab96dc4ba`.

All are in `snapshots/`. The optional builder is not a trusted proof dependency. No mathematical repair was required. Later status-only revisions, if any, must be identified separately.

## 1. Exhaustive extension rules

Strong C4 exclusion means no four-cycle as a subgraph, including one with chords. It forces every neighborhood to be a matching plus isolates, so lambda(v)=d(v)−t(v), L=2m−3t, and vertex-deletion cost 2lambda(v)−t(v).

The deficient-pivot lemma is valid: if all new neighbors of a pivot touched old neighbors, the matching property would pair them with different old isolates and permit no further neighborhood edges. These replacements preserve neighborhood independence, contradicting the assumed increase from below three to at least three. A new neighbor anticomplete to the old pivot neighborhood therefore exists.

Its exact contacts contain the pivot, avoid the old pivot neighbors, and have no two vertices with a common old neighbor. The latter is precisely the condition excluding a new C4. In triangle-free mode, independent contacts are additionally necessary and sufficient to avoid a new triangle. No further contact restrictions are silently imposed.

The proof correctly treats an already qualifying induced core as **accepting, not terminal**. If it is proper in a connected target, some exterior vertex has a nonempty contact set. Every such legal contact set is considered, without the deficient-pivot restrictions. This is essential: finding a small qualifying core alone would not classify all its supergraphs.

The six root modes cover every target. A graph containing a triangle starts at C3. Otherwise minimum local independence at least three equals minimum degree at least three, so the finite graph contains a cycle. A shortest cycle is induced, has length at least five, and cannot have length at least ten in a P9-free graph. Thus one of the triangle-free roots C5,…,C9 applies.

## 2. Exact binary region coverage and path persistence

A contact region (S,R) represents compatible selected contacts S and undecided possible contacts R. The verified include branch adds v and removes precisely the vertices incompatible with v; those removed vertices are forced absent in every legal completion containing v. The exclude branch omits v. These disjoint branches cover all legal completions.

The forbidden-path-box rule is sound. The displayed path is induced with the currently selected contacts. If the new vertex lies on that path, the verifier requires that no undecided contact lies on the path. Future contacts can therefore add no chord to it. If the new vertex is not on the path, all path edges are old and no new contact can change it. Merely finding a P9 in a partial extension would not have sufficed; the actual certificate checks the stronger persistence condition in every box.

A retained leaf has no undecided contacts and a nonempty selected set. Its explicit permutation maps the exact extension to a state of order one greater in the same mode. The only empty-contact leaves occur at accepting states and cannot represent a connected extension.

Starting from a root embedded in a target graph, either the state equals the target and its accepting map identifies a model, or one of the two extension rules gives a legal nonempty contact set. Following that set through the partition cannot reach a persistent P9 or an empty-contact leaf. It must yield a larger embedded state. Finite closure and strict order increase prevent an infinite chain. Thus the process reaches the whole graph at an accepting model, or contradicts the target's hypotheses. No initial order bound is assumed. Observed maximum state order 45 is not a cutoff.

## 3. Independent standard-library proof checker

`check_independent.py` imports no author code, canonical-labeling package, or graph library. It uses explicit sets for symbolic regions, edge-set equality for permutations, a separate forbidden-set path search for model P9-freeness, and an additional exhaustive powerset trace on small domains and all accepting states.

Exact results in `independent_results.json`:

- **13,930 graph states**, all checked for simple undirected structure, strong C4 exclusion, connectedness, and the declared triangle-free mode.
- Six exact cycle roots with the correct modes.
- **442,204 contact-tree nodes**, comprising **214,137 exact binary splits**, **207,299 persistent-P9 boxes**, **20,757 retained-extension permutations**, and **11 empty-contact leaves**.
- **170,642 rejected boxes have undecided contacts**, up to 36 at a rejection; their persistence conditions are explicitly checked, not assumed from a path at the minimal contact set.
- Eleven accepting states have minimum local independence at least three and exact maps to the specified models. Their proper-extension contact trees receive the same complete audit as all other states.
- All **13,930 states are root-reachable** and form a closed order-increasing directed proof graph. A separate reverse-order closure check passes.
- Independently enumerate **3,938,341 candidate subsets** across **10,476 small or accepting-state domains**. All **719,342 legal contact sets** are traced through the binary trees; the resulting leaf path is rechecked under the **complete** contact set, or its exact retained permutation is rechecked. This corroborates the symbolic partition proof without pretending to enumerate the enormous full powerset at order45.
- Every model is independently checked for connectedness, C4 exclusion, P9-freeness, minimum local independence, L, triangle count, and induced-five-cycle count. All eleven (n,m,t,c5) fingerprints differ, proving pairwise nonisomorphism.
- Both Markdown and TeX graph6 tables are independently decoded and agree exactly with all eleven certificate adjacency arrays, including padding-bit validation.

`check_model_identities.py` independently constructs Petersen as KG(5,2) and Heawood as the incidence graph of the seven lines of PG(2,2), then constructs its edge contraction and Y–Delta graph. Explicit checked permutations identify models M4, M10, M9 and M0 respectively. It also checks **1,472 local independent subsets** directly, independently confirming the neighborhood independence values.

The author's main verifier and table verifier were rerun successfully from the snapshots. Structural counts, model invariants and certificate hash agree; elapsed time naturally differs. The optional builder was inspected for the advertised absence of an imposed cutoff, but its correctness is immaterial: the portable certificate verifies branch closure directly.

The finite certificate is an essential proof component, not merely exploratory evidence. The independent exact implementation passes it. Neither a graph catalog nor an optimizer is involved.

## 4. Density and exact original133 consequence

For a vertex with lambda<=2, deleting it costs at most four units of L. Strong C4/P9 exclusion is hereditary. Induction on positive order, allowing disconnected graphs and treating the one-vertex base explicitly, therefore proves L<4n unless every component is one of the models. Each model has L<4n, so this final case also passes. The classification and density arguments require no external graph-classification theorem.

The original statement uses induced-path **vertex** order and the **unrounded** average local independence. In the C4-present case the exponent is zero and a geodesic gives p>=r+1. In the strong-C4-free case the prior all-ell<=4 result is retained. For 4<ell<=5, the new density theorem forces p>=9:

- r<=4: 9>=r+ell;
- r=5: the already independently audited P10-free radius-five classification has L=2n−t<=2n, so ell>4 forces p>=10>=5+ell;
- r>=6: the classical bound p>=2r−1>=r+5>=r+ell applies.

Thus **all connected graphs with ell<=5** satisfy original133. The same p>=9 implication also covers r=2,ell<=7 and r=3,ell<=6, using the prior ell<=4 theorem at the lower endpoints. Nothing here proves unrestricted original133.

Dependencies are explicit and already independently audited: the general ell<=4 manuscript (Round15), the radius-five classification (`round_18/independent_audit/133_radius5/`), and the classical radius bound. The latter was freshly checked in the primary Erdős–Saks–Sós paper, *Maximum induced trees in graphs* (1986), Section II, printed pp.64–65, Theorem2.2, including its Fan Chung attribution and proof; printed p.62 defines p as the number of vertices of an induced path. Cached primary PDF SHA-256: `1ebe0c89c4c4f42bbe657cc09621bfa0fd04f8b5eddba595a103b64be21c8d50`, path `sources/references/erdos_saks_sos_1986.pdf`.

The earlier Chudnovsky–Stacho classification is contextual here, not required to establish the eleven-model theorem. Classical individual graphs and operations are credited. Worldwide-priority verification is a separate source gate and is not certified by this mathematical audit.

## 5. Consolidation and reproduction

The complete standalone `manuscript.tex` was read and preserves all proof steps and the precise corollary, including accepting-state proper extensions and the no-undecided-chord test. No mathematical change from the audited note was found. Parent owns PDF compilation, visual QA and final delivery-format comparison.

From this audit directory run:

```
python check_independent.py
python check_model_identities.py
```

All data needed by these standard-library scripts are in `snapshots/`. The complete prior-source PDFs need not be redistributed.
