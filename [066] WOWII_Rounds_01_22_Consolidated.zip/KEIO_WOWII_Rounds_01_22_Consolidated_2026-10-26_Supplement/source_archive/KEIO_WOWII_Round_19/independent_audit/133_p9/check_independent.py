"""Independent P9 proof checker: set-based region partition verification,
edge-set isomorphisms, exhaustive small contact powersets, and model invariants.
Standard library only; imports no author verifier or builder.
"""
import gzip,json,hashlib,time,re
from pathlib import Path
from itertools import combinations
from collections import Counter,defaultdict
ROOT=Path(__file__).resolve().parent;start=time.monotonic()
def bits(m):
 while m:
  b=m&-m;yield b.bit_length()-1;m-=b

def check_graph(a,tf=False):
 n=len(a);assert n>0 and all(type(x)==int and 0<=x<1<<n for x in a)
 ns=[set(bits(x)) for x in a]
 assert all(i not in ns[i] for i in range(n))
 assert all((j in ns[i])==(i in ns[j]) for i,j in combinations(range(n),2))
 assert all(len(ns[i]&ns[j])<=1 for i,j in combinations(range(n),2))
 if tf:assert all(not(ns[i]&ns[j]) for i in range(n) for j in ns[i])
 seen={0};todo=[0]
 while todo:
  u=todo.pop()
  for v in ns[u]-seen:seen.add(v);todo.append(v)
 assert len(seen)==n
 return ns

def local(ns,u):return len(ns[u])-sum(v in ns[w] for v,w in combinations(ns[u],2))
def extend(a,S):
 n=len(a);return [x|((1<<n) if i in S else 0) for i,x in enumerate(a)]+[sum(1<<v for v in S)]
def path(a,P):
 assert len(P)==9 and len(set(P))==9 and all(type(v)==int and 0<=v<len(a) for v in P)
 assert all(a[u]>>v&1 for u,v in zip(P,P[1:]))
 assert sum(bool(a[u]>>v&1) for u,v in combinations(P,2))==8

def iso(a,b,P):
 assert len(a)==len(b)==len(P) and set(P)==set(range(len(a)))
 EA={frozenset((P[i],P[j])) for i in range(len(a)) for j in bits(a[i])}
 EB={frozenset((i,j)) for i in range(len(b)) for j in bits(b[i])}
 assert EA==EB

def longest(a,cap=9):
 best=0
 def visit(last,blocked,used,depth):
  nonlocal best
  best=max(best,depth)
  if best>=cap:return
  for v in bits(a[last]&~blocked&~used):
   visit(v,blocked|a[last],used|(1<<v),depth+1)
   if best>=cap:return
 for u in range(len(a)):
  visit(u,0,1<<u,1)
  if best>=cap:break
 return best

def decode(s):
 n=ord(s[0])-63;raw=''.join(format(ord(c)-63,'06b') for c in s[1:]);a=[0]*n;pos=0
 assert 1<=n<=62 and all(63<=ord(c)<=126 for c in s)
 for j in range(1,n):
  for i in range(j):
   if raw[pos]=='1':a[i]|=1<<j;a[j]|=1<<i
   pos+=1
 assert len(raw)-pos<6 and set(raw[pos:])<={'0'}
 return a

raw=(ROOT/'snapshots/p9_core_certificate.json.gz').read_bytes();data=json.loads(gzip.decompress(raw));states=data['states'];models=data['models'];roots=data['roots']
assert len(models)==11 and len(roots)==len(set(roots))==6
for rid,n in zip(roots,(3,5,6,7,8,9)):
 assert type(rid)==int and 0<=rid<len(states)
 cyc=[sum(1<<v for v in ((u-1)%n,(u+1)%n)) for u in range(n)]
 assert states[rid]['adjacency']==cyc and states[rid]['trianglefree']==(n!=3)

# Read table data, rather than assume model labels/name metadata.
md=(ROOT/'snapshots/p9_min_local_classification.md').read_text();table=[]
for line in md.splitlines():
 if re.match(r'\| M\d+ ',line):
  cells=[x.strip() for x in line.split('|')[1:-1]];table.append((int(cells[0][1:]),cells[1].strip('`'),list(map(int,cells[2:]))))
assert len(table)==11
model_rows=[]
for mid,a in enumerate(models):
 ns=check_graph(a);assert all(local(ns,u)>=3 for u in range(len(a)))
 p=longest(a);assert p<9
 n=len(a);m=sum(len(x) for x in ns)//2
 triangles=sum(j in ns[i] and k in ns[i] and k in ns[j] for i,j,k in combinations(range(n),3))
 L=sum(local(ns,u) for u in range(n));assert L==2*m-3*triangles and L<4*n
 c5=0
 for V in combinations(range(n),5):
  U=set(V)
  if all(len(ns[u]&U)==2 for u in U):c5+=1
 assert table[mid][0]==mid and decode(table[mid][1])==a and table[mid][2]==[n,m,triangles,L,c5]
 model_rows.append(dict(model=mid,n=n,m=m,t=triangles,L=L,c5=c5,p=p))
assert len({(r['n'],r['m'],r['t'],r['c5']) for r in model_rows})==11
# Independently decode all TeX graph6 rows as well.
tex=(ROOT/'snapshots/manuscript.tex').read_text();tex_strings=[]
for line in tex.splitlines():
 if re.match(r'\$M_\{\d+\}\$&',line):
  val=line.split('\\texttt{',1)[1].split('}',1)[0].replace('\\{','{').replace('\\_','_');tex_strings.append(val)
assert len(tex_strings)==11 and all(decode(s)==a for s,a in zip(tex_strings,models))

counts=Counter();orders=Counter();arcs=[];accepts=[];small_states=0;small_subsets=0;small_legal=0
for sid,st in enumerate(states):
 a=st['adjacency'];n=len(a);tf=st['trianglefree'];assert type(tf)==bool
 ns=check_graph(a,tf);orders[n]+=1
 compat=[{w for w in range(n) if w!=v and not(ns[v]&ns[w]) and (not tf or w not in ns[v])} for v in range(n)]
 if 'model' in st:
  mid=st['model'];assert type(mid)==int and 0<=mid<11 and all(local(ns,u)>=3 for u in range(n))
  iso(a,models[mid],st['model_map']);base=set();available=set(range(n));accepts.append(sid)
 else:
  u=st['pivot'];assert type(u)==int and 0<=u<n and local(ns,u)<3;base={u};available=compat[u]-ns[u]
 tree=st['contact_tree'];todo=[(tree,base,available)]
 while todo:
  node,S,R=todo.pop();counts['contact_nodes']+=1
  assert not S&R and all(S-{v}<=compat[v] for v in S) and all(S<=compat[v] for v in R)
  keys=set(node)
  if keys=={'split','include','exclude'}:
   v=node['split'];assert type(v)==int and v in R;remaining=R-{v}
   todo.append((node['exclude'],S,remaining));todo.append((node['include'],S|{v},remaining&compat[v]));counts['split_nodes']+=1
  elif keys=={'path'}:
   P=node['path'];path(extend(a,S),P)
   if n in P:assert R.isdisjoint(P)
   counts['P9_boxes']+=1
   if R:counts['P9_boxes_with_undecided']+=1;counts['maximum_undecided_at_rejection']=max(counts['maximum_undecided_at_rejection'],len(R))
   if n not in P:counts['P9_boxes_entirely_old']+=1
  elif keys=={'empty'}:
   assert node['empty'] is True and not S and not R and 'model'in st;counts['empty_leaves']+=1
  else:
   assert keys=={'target','map'} and S and not R
   tid=node['target'];assert type(tid)==int and 0<=tid<len(states)
   assert states[tid]['trianglefree']==tf and len(states[tid]['adjacency'])==n+1
   iso(extend(a,S),states[tid]['adjacency'],node['map']);arcs.append((sid,tid));counts['retained_permutations']+=1
 # Independently trace every legal contact in small candidate powersets,
 # and every contact powerset at ALL accepting states, through the tree.
 # This corroborates the universal symbolic partition check above.
 if len(available)<=10 or 'model'in st:
  small_states+=1;V=sorted(available);q=len(V);small_subsets+=1<<q
  conflicts=[sum(1<<j for j,w in enumerate(V) if j!=i and w not in compat[v]) for i,v in enumerate(V)]
  valid=bytearray(1<<q);valid[0]=1
  for mask in range(1<<q):
   if mask:
    b=mask&-mask;j=b.bit_length()-1;rest=mask^b
    valid[mask]=valid[rest] and not(rest&conflicts[j])
   if not valid[mask]:continue
   S=base|{V[j] for j in bits(mask)};node=tree
   while 'split'in node:node=node['include' if node['split']in S else 'exclude']
   if 'path'in node:path(extend(a,S),node['path'])
   elif 'target'in node:iso(extend(a,S),states[node['target']]['adjacency'],node['map'])
   else:assert not S and node=={'empty':True}
   small_legal+=1
assert len(accepts)==11
adj=defaultdict(list)
for u,v in arcs:adj[u].append(v)
reach=set(roots);todo=list(roots)
while todo:
 for v in adj[todo.pop()]:
  if v not in reach:reach.add(v);todo.append(v)
assert len(reach)==len(states)
closed=set()
for sid in sorted(range(len(states)),key=lambda i:len(states[i]['adjacency']),reverse=True):
 assert all(t in closed for t in adj[sid]);closed.add(sid)
assert len(closed)==len(states)
assert counts['contact_nodes']==counts['split_nodes']+counts['P9_boxes']+counts['empty_leaves']+counts['retained_permutations']

out={'status':'PASS','certificate_sha256':hashlib.sha256(raw).hexdigest(),'states':len(states),'roots':roots,'accepting_states':accepts,'maximum_state_order':max(orders),'state_order_counts':dict(sorted(orders.items())),**counts,'reachable_states':len(reach),'closed_states':len(closed),'explicit_contact_control_states':small_states,'all_candidate_subsets_in_controls':small_subsets,'legal_contacts_traced_in_controls':small_legal,'model_invariants':model_rows,'graph6_MD_and_TeX_rows_verified':11,'seconds':time.monotonic()-start,'scope':'All symbolic contact partitions and proof witnesses independently verified; arbitrary-order force requires the separately audited extension and connected-extension arguments.'}
print(json.dumps(out,indent=2))
