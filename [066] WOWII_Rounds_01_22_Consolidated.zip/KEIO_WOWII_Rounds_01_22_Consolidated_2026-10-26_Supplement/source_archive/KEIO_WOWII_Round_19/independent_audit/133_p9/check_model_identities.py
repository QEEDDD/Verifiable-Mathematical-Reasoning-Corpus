"""Independent direct local-independence and classical-model identities."""
from pathlib import Path
from itertools import combinations
import json,gzip
R=Path(__file__).resolve().parent;models=json.loads(gzip.open(R/'snapshots/p9_core_certificate.json.gz').read())['models']
def graph(n,E):
 A=[0]*n
 for u,v in E:A[u]|=1<<v;A[v]|=1<<u
 return A

def iso(A,B):
 n=len(A);p={};used=set()
 def search():
  if len(p)==n:return [p[i] for i in range(n)]
  u=max((i for i in range(n) if i not in p),key=lambda i:(sum(A[i]>>j&1 for j in p),A[i].bit_count()))
  for v in range(n):
   if v in used or A[u].bit_count()!=B[v].bit_count():continue
   if any(bool(A[u]>>x&1)!=bool(B[v]>>y&1) for x,y in p.items()):continue
   p[u]=v;used.add(v);out=search()
   if out is not None:return out
   del p[u];used.remove(v)
  return None
 P=search();assert P is not None
 assert all(bool(A[i]>>j&1)==bool(B[P[i]]>>P[j]&1) for i,j in combinations(range(n),2))
 return P
lines=[T for T in combinations(range(1,8),3) if T[0]^T[1]^T[2]==0]
H=graph(14,[(u-1,7+j) for j,T in enumerate(lines) for u in T]);neighbors=[u for u in range(14) if H[0]>>u&1]
Y=H.copy()
for u,v in combinations(neighbors,2):Y[u]|=1<<v;Y[v]|=1<<u
Y=[sum(1<<j for j,v in enumerate(range(1,14)) if Y[u]>>v&1) for u in range(1,14)]
v=neighbors[0];remain=[u for u in range(14) if u!=v];idx={u:i for i,u in enumerate(remain)};E=set()
for u,w in combinations(range(14),2):
 if H[u]>>w&1:
  u1,w1=(0 if u==v else u),(0 if w==v else w)
  if u1!=w1:E.add((idx[u1],idx[w1]))
C=graph(13,E);pairs=list(combinations(range(5),2));P=graph(10,[(i,j) for i,j in combinations(range(10),2) if not(set(pairs[i])&set(pairs[j]))])
identities=[dict(model=i,name=name,permutation=iso(models[i],A)) for i,name,A in [(0,'Y_Delta_Heawood',Y),(4,'Petersen',P),(9,'edge_contracted_Heawood',C),(10,'Heawood',H)]]
localsets=0
for A in models:
 for u in range(len(A)):
  N=[v for v in range(len(A)) if A[u]>>v&1];alpha=0
  for S in range(1<<len(N)):
   I=[N[j] for j in range(len(N)) if S>>j&1];localsets+=1
   if all(not(A[v]>>w&1) for v,w in combinations(I,2)):alpha=max(alpha,len(I))
  assert alpha==len(N)-sum(bool(A[v]>>w&1) for v,w in combinations(N,2)) and alpha>=3
print(json.dumps(dict(status='PASS',classical_model_identities=identities,local_independent_subsets_checked=localsets),indent=2))
