# Eleven local-independence cores for P9-free graphs

**KEIO — 26 October 2026.**

**Status:** proposed computer-assisted classification and density theorem. A closed finite branching certificate and its pure-Python verifier pass. Independent mathematical/implementation review is pending; no full original WOWII133 closure or worldwide-priority claim is made. This is separate from the frozen, already audited P8 theorem.

## 1. Exact statements

All graphs are finite and simple. Four-cycles are excluded as subgraphs, including cycles with chords. Let p(G) be the maximum induced-path vertex order, r(G) the radius, λ(v)=α(G[N(v)]), L=Σλ(v), and ell=L/n without rounding.

In a C4-subgraph-free graph each neighborhood induces a matching plus isolates. If t(v) counts triangles through v and t counts all triangles, then

    λ(v)=d(v)−t(v),  L=2m−3t,
    L(G)−L(G−v)=2d(v)−3t(v)=2λ(v)−t(v).

**Theorem A (proposed).** Every connected C4-subgraph-free P9-free graph with λ(v)≥3 for every vertex is isomorphic to exactly one of the eleven graphs in the following table. Conversely each listed graph satisfies these hypotheses.

The graph6 strings specify each model completely. Equivalent adjacency bitmasks are stored in the certificate. The final column counts induced five-cycles; the tuples (n,m,t,c5) distinguish all eleven isomorphism types.

| Model | graph6 | n | m | t | L | c5 |
|---|---|---:|---:|---:|---:|---:|
| M0 | `L{OcA?_F?b@S@o` | 13 | 21 | 1 | 39 | 12 |
| M1 | `M{OcA?_F?b@S@a@P?` | 14 | 24 | 1 | 45 | 21 |
| M2 | `O{OcA?_F?a@P@_@OaDOPI` | 16 | 30 | 4 | 48 | 24 |
| M3 | `N{OcA?_E?g@_@sAiAK_` | 15 | 27 | 1 | 51 | 30 |
| M4 | `IheA@GUAo` | 10 | 15 | 0 | 30 | 12 |
| M5 | `MheA@GUA_QCA?a@@_` | 14 | 23 | 0 | 46 | 17 |
| M6 | `LheA@GUA_QCA?J` | 13 | 21 | 0 | 42 | 18 |
| M7 | `KheA@GQA?K_M` | 12 | 18 | 0 | 36 | 9 |
| M8 | `KheA@GQA?H_Y` | 12 | 18 | 0 | 36 | 8 |
| M9 | `LheA@GQA?H?YOE` | 13 | 20 | 0 | 40 | 8 |
| M10 | `MhEKA?_C_Q?c?i?T?` | 14 | 21 | 0 | 42 | 0 |

**Corollary B (proposed).** Every nonempty C4-subgraph-free P9-free graph satisfies L(G)<4|V(G)|.

**Original WOWII133 consequence (proposed).** Combined with the earlier proved ell≤4 range and radius-five classification, Corollary B proves original WOWII133 for **all connected graphs with ell≤5**. It also covers radius two with ell≤7 and radius three with ell≤6. The unrestricted conjecture remains open in this work.

## 2. The forced extension lemma

**Lemma 1.** Suppose F is an induced subgraph of a C4-subgraph-free graph G, every vertex of G has local independence at least three, and u∈V(F) has λ_F(u)<3. Then some x∈V(G)\V(F) is adjacent to u and anticomplete to N_F(u).

**Proof.** Neighborhoods of u in both graphs are matchings plus isolates. If every new neighbor were adjacent to an old neighbor in N_F(u), each would be matched to a distinct old isolate: an additional neighborhood edge at either endpoint would violate the matching property. Replacing old isolates by matched pairs does not increase neighborhood independence. This contradicts λ_G(u)>λ_F(u). ∎

The contact set S=N_G(x)∩V(F) thus satisfies

    u∈S, S∩N_F(u)=∅,
    N_F(v)∩N_F(w)=∅ for all distinct v,w∈S.

The last condition is necessary and sufficient to prevent a new four-cycle. If the target graph G is triangle-free, also require that S be independent in F. These are the only restrictions on the contact set needed before testing P9-freeness.

A second rule is needed when F already has local independence at least three. If F is a proper induced subgraph of a connected target G, connectedness supplies a new vertex with a **nonempty** contact set in F. In this case there is no designated deficient vertex and no anticompleteness-to-a-neighborhood requirement. Every nonempty contact set satisfying the C4 condition (and the triangle-free condition when applicable) must be considered. This prevents the invalid inference that locating a finite core automatically classifies all of its proper supergraphs.

## 3. Six initial states cover every target graph

If G contains a triangle, begin with an induced C3. Otherwise λ(v)=d(v)≥3, so the finite graph G has a cycle. A shortest cycle is induced and has length at least five. Its length is at most nine: an induced cycle with at least ten vertices contains an induced P9. Thus a triangle-free target contains one of C5,C6,C7,C8,C9 as an induced subgraph.

The certificate therefore has exactly six roots: C3 in unrestricted mode, and C5 through C9 in triangle-free mode. Triangle-free mode restricts all later contact sets to be independent; the unrestricted triangle-root branch imposes no additional triangle prohibition.

## 4. Complete contact-set partitions

The certificate represents contact possibilities by binary partition trees, rather than explicitly listing an exponentially large powerset.

For a fixed state F, a contact-tree node is interpreted as a pair (S,R): the contacts in S are already selected, while vertices of R remain available for selection. The sets are disjoint. Every pair of selected contacts has no common neighbor; in triangle-free mode selected contacts are also pairwise nonadjacent. All vertices of R are compatible with S.

At a state with deficient vertex u, the root region is

    S={u},
    R={v≠u : uv∉E(F), N_F(u)∩N_F(v)=∅}.

At a state with no deficient vertex, the root region is S=∅, R=V(F); the empty final contact set is discarded because the extension must be connected to F.

A binary split selects v∈R. Its two children are exactly:

- **include:** (S∪{v}, (R\{v})∩Compat(v));
- **exclude:** (S, R\{v}).

Here Compat(v) is the set of vertices sharing no neighbor with v, additionally excluding neighbors of v in triangle-free mode. This partitions all admissible completions of the current selected contacts. Contacts incompatible with an included vertex are forced absent, not silently omitted from the search.

There are three leaf types:

1. **Forbidden-path box.** The certificate supplies an induced P9 in F+x when N_F(x)=S. If x lies on the path, no undecided vertex of R lies on the path. Thus no future contact can destroy that induced P9: additional edges only join x to vertices outside the path. If x is absent from the displayed path, the path is entirely in F and is unchanged regardless of future contacts. The entire region may therefore be rejected.
2. **Retained extension.** Here R=∅ and S≠∅. The certificate supplies a target state of order |V(F)|+1 and an exact adjacency-preserving permutation from F+x to that state, in the same mode.
3. **Empty contact set.** Here S=R=∅, and the state is an accepting state with no deficient vertex. This represents no connected extension and may be discarded.

These rules give a direct, independently checkable proof that every legal extension is either forbidden or represented. In particular, finding a path in a partial contact set does **not** suffice to reject it: the verifier checks that no undecided contact can add a chord to the displayed path.

## 5. Accepting models, closure, and arbitrary-order validity

Every state either specifies a vertex of local independence at most two or is an **accepting** state. An accepting state has local independence at least three everywhere and includes an explicit isomorphism to one of M0,…,M10. Crucially, accepting states still contain full contact trees for all possible proper connected extensions, using the second rule in Section 2.

The closed certificate has the following verified counts:

| item | count |
|---|---:|
| graph states | 13,930 |
| maximum state order | 45 |
| initial roots | 6 |
| accepting model states | 11 |
| contact-tree nodes | 442,204 |
| binary split nodes | 214,137 |
| forbidden-P9 boxes | 207,299 |
| retained-extension permutations | 20,757 |
| empty-contact leaves | 11 |
| unaccounted branches or cutoff frontier | 0 |

The builder uses **no order or state cutoff**. Maximum order 45 is an observed property of the closed finite certificate, not a restriction on target graphs. Canonical labeling is used only by the optional builder, never as a trusted proof step. Every merge is backed by an explicit graph isomorphism checked on all adjacency pairs.

The compressed certificate is `p9_core_certificate.json.gz`, SHA256

    9d76bd6ba46c60a43175f792e0e67517c4d19b22b068917eeee5e34327544e1b.

The standard-library-only program `verify_p9_certificate.py` verifies all state graphs, selected deficient vertices, model maps, exact include/exclude regions, forbidden-path witnesses and their no-repair condition, retained-extension permutations, root graphs and modes, and reachability. It also checks each model's connectivity, C4 exclusion, P9-freeness, local independence, L, and induced-five-cycle count. The fingerprints (n,m,t,c5) are all distinct, establishing the eleven models' pairwise nonisomorphism.

**Proof of Theorem A from the certificate.** Choose an initial cycle in G as in Section 3, and embed the corresponding root as an induced subgraph. Suppose a state F has been embedded. If F=G, no deficient vertex can exist, so the accepting-state map identifies G with a listed model. Otherwise, if F is deficient, Lemma 1 supplies a new vertex and its legal contact set. If F is accepting, connectedness supplies an exterior neighbor of F and its nonempty legal contact set. In either case follow that exact contact set through the binary partition tree. A forbidden-path leaf is impossible because its displayed induced P9 persists under the chosen contacts, hence would lie in G. An empty-contact leaf is impossible because the chosen set is nonempty. Therefore a retained leaf gives an induced embedding of a state with one more vertex.

This process cannot continue indefinitely: all transitions increase order and the certificate has finitely many states. It therefore reaches F=G at an accepting state, or would contradict the certificate's closure. Consequently G is one of the eleven models, at arbitrary order. Conversely the verifier directly checks all required properties of every model. ∎

## 6. Density induction

**Proof of Corollary B.** Induct on n, allowing disconnected graphs. A vertex with λ(v)≤2 has deletion cost

    L(G)−L(G−v)=2λ(v)−t(v)≤4.

For n>1, the induction hypothesis gives L(G)<4n; the one-vertex case is immediate. If there is no such vertex, each connected component is a model from Theorem A. Every model in the table satisfies L<4n. Summing over components completes the proof. ∎

## 7. Exact original-WOWII133 coverage

The original statement is p≥r+ell^χ, where χ=1 exactly when G has no C4 as a subgraph. With a four-cycle present, a geodesic gives p≥r+1 and settles the exponent-zero case.

Assume G is C4-subgraph-free. The already proved ell≤4 range is retained. If 4<ell≤5, Corollary B forces p≥9. This proves p≥r+ell for r≤4. (At radius one ell<2 anyway: deleting a universal vertex leaves a matching plus isolates.) At radius five, the independently audited P10-free radius-five classification has ell≤2, so ell>4 forces p≥10≥5+ell. At radius r≥6, the classical Chung bound p≥2r−1 gives p≥r+5≥r+ell. Thus **all connected graphs with ell≤5** satisfy original WOWII133.

The same new density bound gives p≥9 whenever ell>4, hence also proves the additional ranges r=2,ell≤7 and r=3,ell≤6, using the earlier ell≤4 coverage at their lower endpoints.

No claim is made here for unrestricted ell. In particular, the original conjecture is not fully closed.

## 8. Reproduction, dependencies, and limitations

Run `python verify_p9_certificate.py` beside `p9_core_certificate.json.gz`. No third-party Python package is required. The builder `build_p9_certificate.py` optionally reproduces the certificate using pynauty; its canonicalization is not trusted by the verifier. The first verifier run passed all mathematical checks but failed while assembling its mixed-type output dictionary (a Counter/string TypeError). That output-only bug was corrected; the rerun completed with PASS. No successful result is claimed from the failed output attempt.

The finite branching certificate is a **proof dependency**, not merely supplementary evidence. Earlier random searches and the order-bounded exploratory completion runs are not proof dependencies. The final builder has no such cutoff, and the verifier certifies branch closure directly.

For the conjecture corollary, the dependencies are the previous general ell≤4 proof, the independently audited radius-five classification, and the classical p≥2r−1 theorem of Erdős–Saks–Sós, credited there to Fan Chung. The classification/density proof itself does not require an external graph-classification theorem.

The earlier P8 classification credited Chudnovsky–Stacho's triangle-free theorem (SIAM J. Discrete Math.32(2)(2018),1111–1138, DOI10.1137/16M1104858); its three classical exceptions occur among the present models. M0 is the known Y–Delta–Heawood graph, labeled C13 in the Heawood family, not the cycle C13; see Hanaki–Nikkuni–Taniyama–Yamazaki, Pacific J. Math.252(2011),407–425, DOI10.2140/pjm.2011.252.407. No novelty claim is made for any individual graph or operation.

A bounded primary-source search has not located the exact eleven-graph local-independence classification or full-class L<4n consequence. The planar P9-subgraph extremal problem, induced-C4 coloring hardness results, and P9 odd-girth-at-least-seven results have different hypotheses. This is not a certification of worldwide priority. Independent mathematical and implementation audit remains required before publication.
