"""Check the paper's explicit graph6 table against the certified models."""
import gzip,json,re
from pathlib import Path
R=Path(__file__).resolve().parent;d=json.loads(gzip.decompress((R/'p9_core_certificate.json.gz').read_bytes()))
def decode(s):
 n=ord(s[0])-63;bits=[]
 for c in s[1:]:bits.extend((ord(c)-63>>k)&1 for k in range(5,-1,-1))
 a=[0]*n;k=0
 for j in range(1,n):
  for i in range(j):
   if bits[k]:a[i]|=1<<j;a[j]|=1<<i
   k+=1
 return a
rows=[]
for line in (R/'p9_min_local_classification.md').read_text().splitlines():
 if re.match(r'\| M\d+ \|',line):
  parts=[s.strip() for s in line.split('|')[1:-1]];idx=int(parts[0][1:]);g6=parts[1].strip('`');assert decode(g6)==d['models'][idx];rows.append(idx)
assert rows==list(range(11))
out={'status':'PASS','model_rows':11,'scope':'exact graph6 transcription check against certificate adjacency arrays'}
(R/'verification_model_table.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
