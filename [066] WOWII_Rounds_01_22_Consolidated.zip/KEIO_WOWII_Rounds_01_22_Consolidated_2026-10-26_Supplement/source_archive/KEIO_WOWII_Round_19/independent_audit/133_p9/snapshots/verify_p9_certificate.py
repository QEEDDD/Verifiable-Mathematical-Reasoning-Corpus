"""Standard-library-only verifier for the P9 branching certificate.

A branch partitions all compatible contact sets. A pruned box contains an
explicit induced P9 that NO remaining contact can destroy. Retained leaves
carry exact isomorphisms. Accepting states are among eleven explicit models,
but their proper connected extensions are checked too. No size cap is used.
"""
import collections,gzip,hashlib,itertools,json,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent;start=time.time();counts=collections.Counter();arcs=[]
def verts(m):
 while m:
  b=m&-m;m-=b;yield b.bit_length()-1

def check_graph(a,tf=False):
 n=len(a);assert all(type(x)==int and 0<=x<(1<<n) for x in a)
 assert all(not(a[i]>>i&1) for i in range(n))
 assert all(bool(a[i]>>j&1)==bool(a[j]>>i&1) for i in range(n) for j in range(i))
 assert all((a[i]&a[j]).bit_count()<=1 for i in range(n) for j in range(i))
 if tf:assert all(not(a[i]&a[j]) for i in range(n) for j in range(i) if a[i]>>j&1)
def local(a,u):
 ns=list(verts(a[u]));return len(ns)-sum(bool(a[v]>>w&1) for k,v in enumerate(ns) for w in ns[:k])
def connected(a):
 seen={0};todo=[0]
 while todo:
  u=todo.pop()
  for v in verts(a[u]):
   if v not in seen:seen.add(v);todo.append(v)
 return len(seen)==len(a)
def isomap(a,b,p):
 assert len(a)==len(b)==len(p) and sorted(p)==list(range(len(a)))
 assert all(sum(1<<p[j] for j in verts(a[i]))==b[p[i]] for i in range(len(a)))
def extension(a,S):return [x|((1<<len(a)) if S>>i&1 else 0) for i,x in enumerate(a)]+[S]
def pathcheck(a,p):
 assert len(p)==9 and len(set(p))==9 and all(type(v)==int and 0<=v<len(a) for v in p)
 assert all(bool(a[p[i]]>>p[j]&1)==(j==i+1) for i in range(9) for j in range(i+1,9))
def has_P9(a):
 def rec(p,used):
  if len(p)==9:return True
  for u in verts(a[p[-1]]&~used):
   if a[u]&used==1<<p[-1] and rec(p+[u],used|(1<<u)):return True
  return False
 return any(rec([u],1<<u) for u in range(len(a)))

p=ROOT/'p9_core_certificate.json.gz';raw=p.read_bytes();data=json.loads(gzip.decompress(raw));assert data['format']=='p9-strong-c4-min-local3-branch-certificate-v1'
states=data['states'];models=data['models'];roots=data['roots'];assert len(models)==11 and len(roots)==6
assert states[roots[0]]['adjacency']==[6,5,3] and not states[roots[0]]['trianglefree']
for rid,n in zip(roots[1:],range(5,10)):
 assert states[rid]['adjacency']==[(1<<((u-1)%n))|(1<<((u+1)%n)) for u in range(n)] and states[rid]['trianglefree']
model_data=[]
for a in models:
 check_graph(a);assert connected(a) and all(local(a,u)>=3 for u in range(len(a))) and not has_P9(a)
 L=sum(local(a,u) for u in range(len(a)));assert L<4*len(a)
 m=sum(x.bit_count() for x in a)//2;t=(2*m-L)//3;assert L==2*m-3*t
 c5=0
 for ss in itertools.combinations(range(len(a)),5):
  mask=sum(1<<v for v in ss)
  if all((a[v]&mask).bit_count()==2 for v in ss):c5+=1
 # A simple 2-regular graph on five vertices is necessarily a five-cycle.
 model_data.append({'n':len(a),'m':m,'t':t,'L':L,'induced_C5_count':c5})

for sid,state in enumerate(states):
 a=state['adjacency'];tf=state['trianglefree'];assert type(tf)==bool;check_graph(a,tf);assert connected(a)
 n=len(a);counts['states']+=1
 compat=[sum(1<<w for w in range(n) if w!=v and not(a[v]&a[w]) and (not tf or not(a[v]>>w&1))) for v in range(n)]
 if 'model' in state:
  mid=state['model'];assert 0<=mid<len(models) and all(local(a,u)>=3 for u in range(n));isomap(a,models[mid],state['model_map']);S=0;R=(1<<n)-1;counts['accepting_states']+=1
 else:
  u=state['pivot'];assert 0<=u<n and local(a,u)<3;S=1<<u;R=compat[u]&~a[u]&~S
 def visit(node,S,R):
  counts['contact_nodes']+=1;assert not(S&R)
  if 'split' in node:
   assert set(node)=={'split','include','exclude'};v=node['split'];assert type(v)==int and 0<=v<n and R>>v&1
   rest=R&~(1<<v);counts['split_nodes']+=1
   visit(node['include'],S|(1<<v),rest&compat[v]);visit(node['exclude'],S,rest);return
  if 'path' in node:
   assert set(node)=={'path'};b=extension(a,S);pathcheck(b,node['path'])
   # Extra contacts affect only edges at the new vertex n. If it is in
   # the witness, no undecided contact may be another witness vertex.
   if n in node['path']:assert not(R&sum(1<<v for v in node['path'] if v<n))
   counts['pruned_boxes']+=1;return
  if 'empty' in node:
   assert set(node)=={'empty'} and node['empty'] is True and S==0 and R==0 and 'model' in state;counts['empty_contacts']+=1;return
  assert set(node)=={'target','map'} and R==0 and S!=0
  tid=node['target'];assert 0<=tid<len(states) and states[tid]['trianglefree']==tf
  isomap(extension(a,S),states[tid]['adjacency'],node['map']);arcs.append((sid,tid));counts['retained_extensions']+=1
 visit(state['contact_tree'],S,R)
# Explicitly certify that the finite directed graph is reachable from the six roots.
reach=set(roots);out=collections.defaultdict(list)
for s,t in arcs:out[s].append(t)
todo=list(roots)
while todo:
 for t in out[todo.pop()]:
  if t not in reach:reach.add(t);todo.append(t)
assert reach==set(range(len(states)))
assert len({(x['n'],x['m'],x['t'],x['induced_C5_count']) for x in model_data})==11
counts=dict(counts)
counts.update({'status':'PASS','models':11,'maximum_state_order':max(len(s['adjacency']) for s in states),'certificate_sha256':hashlib.sha256(raw).hexdigest(),'elapsed_seconds':time.time()-start})
result=dict(counts);result['model_invariants']=model_data;result['scope']='closed finite branching proof certificate, not an order-bounded negative search; mathematical completion argument supplied separately'
(ROOT/'verification_p9_certificate.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
