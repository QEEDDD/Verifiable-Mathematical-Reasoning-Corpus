from itertools import product
import json
from pathlib import Path
counts=dict(matrices=0,accepted=0,strict_without_hamming=0,boundary_hamming=0,closure_additions=0,hamilton_paths=0)
def close(q,h,cols):
 n=q+h; adj=[((1<<q)-1)^(1<<j) for j in range(q)]+[0]*h
 for j,c in enumerate(cols):
  for i in range(h):
   if c>>i&1:adj[j]|=1<<(q+i);adj[q+i]|=1<<j
 original=adj[:];adds=[]
 while True:
  found=False
  for j in range(q):
   for i in range(h):
    v=q+i
    if not adj[j]>>v&1 and adj[j].bit_count()+adj[v].bit_count()>=n-1:
     adj[j]|=1<<v;adj[v]|=1<<j;adds.append((j,v));found=True
  if not found:break
 assert all((adj[j]>>q)==(1<<h)-1 for j in range(q)),(q,h,cols)
 # Construct complete-split alternating path, reverse each closure exactly.
 path=[]
 for i in range(h):path.extend([i,q+i])
 path.extend(range(h,q))
 for u,v in reversed(adds):
  adj[u]^=1<<v;adj[v]^=1<<u
  if all(adj[a]>>b&1 for a,b in zip(path,path[1:])):continue
  # Universal-vertex cycle proof, implemented independently with index sets.
  ext=[a|(1<<n) for a in adj]+[(1<<n)-1]
  cyc=path+[n]
  idx=next(i for i in range(n+1) if {cyc[i],cyc[(i+1)%(n+1)]}=={u,v})
  seq=cyc[idx+1:]+cyc[:idx+1]
  a,b=seq[0],seq[-1]
  j=next(j for j in range(n) if (ext[a]>>seq[j+1]&1) and (ext[seq[j]]>>b&1))
  cyc=seq[:j+1]+list(reversed(seq[j+1:]));w=cyc.index(n);path=cyc[w+1:]+cyc[:w]
  assert len(set(path))==n and all(adj[a]>>b&1 for a,b in zip(path,path[1:]))
 assert adj==original
 return len(adds)
for q in range(1,5):
 for h in range(1,q+1):
  for cols in product(range(1,1<<h),repeat=q):
   counts['matrices']+=1
   rows=[sum(c>>i&1 for c in cols) for i in range(h)]
   for k in range(1,q+1):
    if q>2*k or min(rows)<k or max(c.bit_count() for c in cols)>k+1:continue
    if q==2*k and any((a^b).bit_count()>k for a in cols for b in cols):continue
    counts['accepted']+=1;counts['strict_without_hamming' if q<2*k else 'boundary_hamming']+=1
    counts['closure_additions']+=close(q,h,cols);counts['hamilton_paths']+=1
counts['status']='PASS';print(json.dumps(counts,indent=2));Path(__file__).with_name('independent_results.json').write_text(json.dumps(counts,indent=2)+'\n')
