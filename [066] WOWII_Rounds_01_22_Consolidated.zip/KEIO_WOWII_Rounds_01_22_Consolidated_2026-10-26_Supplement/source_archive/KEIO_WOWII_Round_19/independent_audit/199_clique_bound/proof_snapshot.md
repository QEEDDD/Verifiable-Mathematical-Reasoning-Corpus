# Descending closure when the clique side has at most twice the connectivity

**Complete proposed scoped proof; independent audit pending. Original WOWII
199 remains unresolved. No worldwide novelty claim.**

## 1. Main incidence theorem

Let V=C∪I be a split partition, with q=|C|, h=|I|≤q, and all columns
A_c=N(c)∩I nonempty. Suppose an integer k≥1 satisfies

    d_C(i)≥k,         |A_c|≤k+1,         |A_c△A_b|≤k,
    q≤2k.

Then the graph is traceable. When q<2k, the pairwise symmetric-difference
condition is unnecessary; it is used only in the boundary q=2k.

For the original WOWII 199 hypothesis τ(G)≤κ(G)+2, choose a split partition
with I maximum and put k=κ(G). As proved in the preceding audited notes,
these incidence inequalities follow from the induced star and double star,
and k is the minimum independent-side degree. The parameter τ counts
vertices of a connected induced tree.

The already independently audited balanced-deficit theorem handles h=q+1
at all k. Section 5 below verifies h≤q+1 directly, so together these results
prove original 199 throughout the split subclass q≤2κ(G). They do not cover
all split graphs or arbitrary connected graphs.

## 2. A descending closure criterion

Sort the original column sizes as

    1≤s₁≤s₂≤⋯≤s_q.

Put a=q−h≥0. If h≤k+1, every missing incidence satisfies the classical
Hamiltonian-path closure threshold: its independent endpoint has degree
at least k, and its clique endpoint has degree at least q, so their sum is
at least k+q≥q+h−1. Thus all incidences can be filled.

Assume henceforth h≥k+2. In particular q≥k+2 and q−k≥a+2. A sufficient
condition for traceability is

    s_j≥j−a                 for 1≤j≤q−k.                  (C)

For j≤a+1 this follows already from nonempty columns. For the other
indices it is a substantive size condition.

To prove sufficiency, complete the columns in descending index order.
The columns with j≥q−k have size at least

    s_{q−k}≥q−k−a=h−k.

Thus their missing incidences satisfy r_i+s_j≥h using r_i≥k. For each
later index j<q−k, the q−j columns of larger index have already been
completed. Every independent vertex therefore has degree at least q−j.
By (C),

    r_i+s_j≥(q−j)+(j−a)=q−a=h.

For a split graph of order n=q+h, the full degree of a clique vertex is
q−1+s_j, so r_i+s_j≥h is exactly the path-closure threshold n−1.
The final complete split graph is traceable because h≤q. Reversing the
closure additions proves the criterion. The classical closure rule is
reproved in Section 6.

## 3. The deficit budget when q<2k

Let r_i=d_C(i), and define the nonnegative row excess and column deficit

    E=Σ_i(r_i−k),       W=Σ_c(k+1−|A_c|).

Counting all incidences gives

    W=q(k+1)−kh−E=q+ka−E≤q+ka.                             (1)

Suppose condition (C) fails at an index j. Since j≤a+1 cannot fail, we have

    a+2≤j≤q−k,          s_j≤j−a−1.

The first j columns each have deficit at least k+a+2−j. Therefore

    W≥f(j):=j(k+a+2−j).                                    (2)

The quadratic f is concave. On the interval [a+2,q−k], its minimum is at
an endpoint. Relative to the budget B=q+ka, the endpoint values are

    f(a+2)−B = 2k−q,
    f(q−k)−B = (h−k−1)(2k−q).                              (3)

When q<2k both values are strictly positive, because h≥k+2. Thus (2)
contradicts (1). Condition (C) holds, proving traceability in this case.
No pairwise column-distance bound entered this argument.

## 4. The boundary q=2k

Now both endpoint differences in (3) are zero. If E>0, (1) gives W<B,
whereas f(j)≥B, so again (C) cannot fail.

Suppose (C) fails and E=0. Every row degree is exactly k, and W=B. Equality
must hold throughout (2). The quadratic is strictly concave, so a failing
index must be an endpoint of [a+2,k], unless those endpoints coincide.
Moreover, exactly j columns have size j−a−1, and every other column has
size k+1. Any smaller low column or any positive deficit in another column
would make W>B. Thus only two patterns are possible.

### Pattern A: singleton columns

Here j=a+2. There are a+2 singleton columns and 2k−a−2=h−2 columns of size
k+1. Since h≥k+2, there are at least k high columns.

Choose a singleton {v}. Comparing it with a high column using
|A_c△A_b|≤k forces that high column to contain v: otherwise the difference
would have size k+2. Therefore v sees every high column and its own
singleton column, giving degree at least k+1. This contradicts E=0.
Pattern A is impossible.

### Pattern B: k low columns and k high columns

Here j=k. Put

    ℓ=k−a−1=h−k−1≥1.

There are k columns of size ℓ and k columns of size k+1; every independent
vertex still has degree exactly k. First complete all k high columns.
Their missing incidences satisfy closure because

    r_i+(k+1)≥2k+1≥h.

Let U be the union of the original low columns. Every i∈U has at least one
low-column neighbor. After the high columns are completed, it has degree
at least k+1. Consequently every missing incidence from U into a low
column satisfies

    r_i+ℓ≥k+1+ℓ=h.

Fill all low columns to all vertices of U.

We claim |U|≥ℓ+1. Otherwise |U|=ℓ, so all k low columns equal U. Each
vertex of U originally had its k neighbors in these low columns and,
because its original degree was exactly k, had no high-column neighbor.
Thus every high column was disjoint from U. Its symmetric difference with
any low column would have size

    (k+1)+ℓ=h>k,

contradicting the hypothesis. This proves the claim.

After completing the low columns to U, their size is at least ℓ+1. Every
vertex outside U has degree at least k from the completed high columns.
Hence its missing low-column incidences satisfy

    r_i+s_c≥k+(ℓ+1)=h.

Fill these remaining incidences. All columns are now complete, and reverse
closure gives a spanning path. When the two endpoint patterns coincide,
Pattern A already rules the configuration out; no extra case is needed.
This proves the main incidence theorem. ∎

## 5. Two consequences for the original split hypothesis

### 5.1 The independent side is never larger than q+1

For arbitrary h, the row and column bounds give kh≤q(k+1). Counting
unordered column differences gives

    Σ_{c<b}|A_c△A_b|=Σ_i r_i(q−r_i)
      ≥k(qh−Σ_i r_i)≥kq(h−k−1).

The same sum is at most kq(q−1)/2. If h≥q+2, the incidence count forces
q≥2k, while the difference count forces q≤2k−3, a contradiction. Thus
h≤q+1. The prior audited balanced-deficit theorem handles h=q+1, and the
main theorem handles all other h when q≤2k.

### 5.2 The equal-size case h=q always has q≤2k

Under h=q, the same pair count gives q≤2k+1. Suppose equality holds.
Equality is then required in both lower-bound steps. Thus every column
has size k+1, and each row degree is either k or q: equality in
r_i(q−r_i)≥k(q−r_i) has precisely those alternatives.

The total row excess is then

    E=q(k+1)−kq=q=2k+1.

If u rows have degree q, their excess is u(q−k)=u(k+1). This cannot equal
2k+1, which is not divisible by k+1 for k≥1. Therefore q≤2k. The main
incidence theorem proves traceability for every equal-size split instance
of original 199, including the cases with maximum column k+1 that were
outside the restricted padding theorem.

## 6. Classical closure rule and attribution

If uv is a nonedge of an n-vertex graph F with d(u)+d(v)≥n−1, adding uv
preserves traceability. Only the backward implication needs proof. Adjoin
a universal vertex w, obtaining H of order N=n+1. A spanning path in F+uv
becomes a Hamiltonian cycle in H+uv, and d_H(u)+d_H(v)≥N. If that cycle uses
uv, delete uv to obtain a path u=v₁,…,v_N=v. The sets of indices j with
uv_{j+1}∈E(H) and v_jv∈E(H) have total size at least N among N−1 indices.
At an intersection index, the order

    v₁,…,v_j,v_N,v_{N−1},…,v_{j+1},v₁

is a Hamiltonian cycle avoiding uv. Delete w. If the original cycle did not
use uv, delete w directly. This is the classical Bondy–Chvátal argument,
not a new closure theorem: J. A. Bondy and V. Chvátal, *A method in graph
theory*, Discrete Mathematics 15 (1976), 111–135,
https://doi.org/10.1016/0012-365X(76)90078-9.

## 7. Remaining scope

The result does not resolve the original conjecture. Combining it with the
prior audited split partials, a remaining split counterexample would need
k≥4, q≥2k+1, h≤q−1, failure of the explicit padding condition, and failure
of k≥2m−2. These are necessary conditions for an unresolved case, not a
construction of one. No degree-bound path-factor shortcut or 1-toughness
sufficiency is assumed. Independent audit of this new note is pending.
