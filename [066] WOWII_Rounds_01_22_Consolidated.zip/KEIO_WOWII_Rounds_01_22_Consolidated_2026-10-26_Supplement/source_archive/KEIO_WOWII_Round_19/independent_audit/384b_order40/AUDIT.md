# Independent audit: representative order at most 40 for WOWII384b

**PASS — conditional reductions all have completed audits; original384b remains open.**

Author TeX SHA-256: `5a479e566f75a386e3626f3a3632b9a9bd0d6f452b3f8a5e0f44cbff736ecda6`.
Author checker SHA-256: `dbbba05071efdb895a21cdeeb8b125e005f75c285c4f74fa944e3d5d8be1f31f`.
Rational input table SHA-256: `9d3663fc0c9fd01813a51e30a87c715819cf8f1266c3b550f485e4e2920c4521`.
The full TeX and proof inputs were read. No mathematical repair was requested.

## Dependencies checked rather than inferred

- Critical omission equality k=ceil(h/2), the rank profile, and the published matching bound have earlier completed audits, including the fresh primary DGH-PV Theorem3 review in Round17.
- `round_09/twodomination/attachment_stability.tex` was reread. Its maximum-cut proof gives G[L] independent for even h and at most one edge for odd h. This stronger fact is not replaced by the weaker published vertex-cover bound. Low-path reorientations and the independent orientation of two low-edge components justify the odd assertion.
- `round_16/independent_audit/384b_order42/AUDIT.md` and its leaf reduction were reread. A counterexample representative keeps the same high set and triangle-value set, has at most one leaf, and preserves critical k by the omission-lifting monotonicity and maximum-cut lower bound. The exceptional even two-leaf configuration is ruled out by omitting its support together with a maximum-cut set in the remainder. That audit's earlier deletion-count repair remains explicit and is not needed anew here: the present argument counts in an already trimmed representative.
- The new h34,36,38 exclusions pass in the companion independent audit; all prior high-order exclusions already passed. Thus remaining h are 11–33,35,37, in particular h<=37.

## Universal counting and omission argument

The degree-two vertices contain an independent set of size at least n2−1, since the low graph has at most one edge. Such a set is omittable; hence n2<=k+1. Together with at most one leaf this gives n<=h+ceil(h/2)+2, at most40 for h<=25.

If a trimmed representative still has n>=41 and 26<=h<=37, it has at least40−h degree-two vertices. Choose an initial uniform13-set of high vertices and select all low vertices, then use the conservative artificial-neighbor paired repair. A perfect or near-perfect matching exists from the critical equality and published bound.

If the low graph is independent, every degree-two vertex has two high neighbors; omit it exactly when both were initially sampled. All omissions are simultaneous: every omitted low vertex keeps both neighbors selected, and every high vertex that loses low support was already selected. No previously omitted high vertex loses support. Linearity of expectation gives credit at least(40−h)q, q=13*12/[h(h−1)].

If the unique low edge exists, it has a degree-two endpoint x; otherwise two adjacent leaves would be the entire connected graph, contrary to h>=26. Because it is the only low edge, x has one high neighbor. Omit x when that neighbor is sampled, leaving its low neighbor selected. At most two degree-two vertices belong to the edge; all others have two high neighbors and can be omitted by the previous rule. These omissions are mutually compatible, including in pendant triangles, nontriangle low paths, and leaf–degree-two edges. Their expected credit is at least p+(38−h)q, p=13/h. Since h>=26, p>=2q, so this is at least(40−h)q. No independence between omission events is required.

The matched-repair calculation uses full-degree profiles, not high-core degrees, and artificially bad vertices are repaired even if actual support suffices. Deleting the credited low vertices is still safe by the preceding selected-high observation. The odd unmatched beta loss is bounded by zeta; it is not assumed that the unmatched vertex has a particular rank.

## Independent exact computation

`check_independent.py` imports no author code. It reconstructs every profile, calculates badness by conditioning on the focal vertex being outside the sample, independently counts the low-support pair categories, and verifies all rational inequalities before comparing with the supplied input fields.

- All **1,992 pair inequalities** pass.
- All **12 strict margins** for h26–37 match the supplied table exactly and are positive; the smallest is h37: **4477009/104778450**.
- Independent actual-graph controls cover **1,600 graphs** and **384,000 initial high subsets**, evenly divided among independent low graphs, pendant triangles, nontriangle degree-two low edges, and leaf–degree-two edges. Every final set is directly checked to be 2-dominating.
- All **13,600 exact low-omission expectations** in those controls agree with p+m*q or m*q as appropriate.
- The author checker was rerun from the snapshot; its JSON output agrees byte-for-byte with the supplied certificate.

All finite arithmetic is rational. During checker development an audit-script zero was initially an integer and introduced a floating-point zero in an even-case expression; it was corrected to Fraction(0) before the successful exact rerun. This was an independent-checker issue, not a manuscript defect, and no result is claimed from that failed attempt.

The positive margins contradict the critical size gamma_2=|L|+floor(h/2) whenever the representative has order at least41. Thus every counterexample, if any exists, has a connected representative of order at most40. This does not bound the order of every original counterexample, nor certify an exhaustive order40 search. Parent owns final delivery formatting and visual QA.
