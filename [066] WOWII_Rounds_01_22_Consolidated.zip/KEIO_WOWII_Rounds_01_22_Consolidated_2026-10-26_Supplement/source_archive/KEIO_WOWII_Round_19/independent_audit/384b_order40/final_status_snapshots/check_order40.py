#!/usr/bin/env python3
"""Exact fixed-size paired-alteration certificate for the order40 reduction."""
from collections import Counter
from fractions import Fraction as F
from math import comb
from pathlib import Path
import json
HERE=Path(__file__).parent
DATA=json.loads((HERE/'order40_dual_input.json').read_text())
C=lambda n,k:comb(n,k) if 0<=k<=n else 0
out=[];checks=0
assert [r['h'] for r in DATA]==list(range(26,38))
for row in DATA:
    h=row['h'];s=13;odd=h%2;den=C(h,s)
    profile=[next(d for d in range(3,h) if C(d,2)>=i+1 and d*(d-2)>=3*i+2-h)
             for i in range(1,h+odd)]
    if not odd:profile=[3]+profile
    counts=Counter(profile);types=sorted(counts)
    assert row['types']==types and row['s']==s
    weights=list(map(F,row['weights']));beta=dict(zip(types,weights))
    zeta=weights[-1] if odd else F(0)
    assert len(weights)==len(types)+odd
    if odd:assert max(beta.values())<=zeta
    bad=lambda d:C(h-1-d,s)+d*C(h-1-d,s-1)
    pairchecks=0;minslack=None
    for a in types:
        for b in types:
            if b<a:continue
            for c in range(max(0,a+b-h),min(a,b)):
                saving=(a+b-2-c)*C(h-a-b+c,s-1)+(a-1-c)*(b-1-c)*C(h-a-b+c,s-2)
                slack=saving-beta[a]-beta[b]
                assert slack>=0
                pairchecks+=1;minslack=slack if minslack is None else min(minslack,slack)
    checks+=pairchecks
    bound=F(s*den+sum(counts[d]*(bad(d)-beta[d]) for d in types)+zeta,den)
    q=F(s*(s-1),h*(h-1));p=F(s,h)
    independent_credit=(40-h)*q
    lowedge_credit=p+(38-h)*q
    assert p>=2*q and lowedge_credit>=independent_credit
    upper=bound-independent_credit;target=h//2;margin=target-upper
    assert margin>0 and str(margin)==row['margin']
    out.append(dict(h=h,degree_multiplicities=dict(counts),sample_size=s,
                    beta={d:str(beta[d]) for d in types},zeta=str(zeta),
                    pair_inequalities=pairchecks,minimum_pair_slack=str(minslack),
                    high_cost_bound=str(bound),independent_low_credit=str(independent_credit),
                    lowedge_credit=str(lowedge_credit),final_upper=str(upper),strict_margin=str(margin)))
result=dict(scope='Independently audited exact arithmetic for the conditional counterexample representative bound40.',
 prerequisites=['h>=38 excluded by the cited audited/companion proofs',
                'critical counterexamples admit leaf trimming to at most one leaf',
                'G[L] independent for even h and has at most one edge for odd h'],
 sample_size=13,high_orders_checked=list(range(26,38)),pair_inequalities=checks,rows=out)
(HERE/'order40_certificate.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
