# Independent audit: matching-edge sampling at h=34,36,38

**PASS — three additional high-order exclusions, not a full resolution of 384b.**

Author TeX SHA-256: `56636f0f24deaf437d31c63e752df73a9ee646f26fb63599362fffe99a586c96`.
Author checker SHA-256: `4302fa8328884ccd425218fa022c6a10530065db4300beb33d1558c1dec50d7b`.
Both are frozen in `snapshots/`. The full standalone TeX was read; no proof repair was required.

## Universal proof

Criticality at even h forces k=h/2 and gamma_2=|L|+h/2. At least h−1 high vertices have distinct triangle counts at least two: at most two distinct low counts can occur, and t>=h+1. The full-degree rank estimate allows the one exceptional high vertex among the h−i neighbors with triangle count at least that of rank i. Thus the displayed inequalities and all three profiles are valid. The exceptional vertex needs only the defining full-degree lower bound three.

The published DGH-PV (2011) Theorem 3, gamma_2<=mu(H)+|L|, forces a perfect matching. This primary theorem and its proof were freshly audited in Round17 h40; no low-independence condition is required. Artificial support uses actual high neighbors and fillers compensated by selected low neighbors; the matched partner is always retained. The sets may be asymmetric. This pointwise comparison does not depend on the sampling distribution.

The new sampling is independent **between matching edges**, not between their endpoints: choose neither with probability1/5 and each particular endpoint with probability2/5. The focal edge's outcome is independent of all external contributions X,Y. Conservative artificial-badness repair has cost2 at (0,0), cost0 when both supports are at least2, and cost1 otherwise when the focal pair is unselected. If exactly one endpoint is selected, the other already has one actual selected neighbor, and needs repair only at external support zero. The displayed W formula follows. Repairs on distinct edges are simultaneously valid using initial support and the actual matched partner.

The four colors record precisely the two artificial-neighborhood membership bits. Every external matching is determined, for this distribution, by its six nonzero/nonzero edge counts and the unmatched color populations that are paired with zeros. The three capacity inequalities are necessary and sufficient with an unlimited supply of zero-colored vertices. Ignoring the actual zero supply only enlarges the pattern domain; therefore it is safe for an upper bound. Zero–zero edges have no effect. The nine-state product and the author loops enumerate all patterns without an independence error. All powers of five and integer weights are exact.

The verified potential inequality holds edgewise for every external configuration. Linearity of expectation permits summing these inequalities over the actual matching, even though different repair costs are correlated. The strict margins force an integral 2-dominating set smaller than the critical value.

## Independent exact implementation

`check_independent.py` imports no author code. It generates pairing multisets by recursively removing a first available colored vertex and pairing it with a zero or another color; this is distinct from the author's six nested edge-count loops. It computes the repair probability from truncated coefficients using the independent identity

W = [3P(X=0)+P(X=1)+3P(Y=0)+P(Y=1)−P(X=0,Y=1)−P(X=1,Y=0)−P(X=1,Y=1)]/5.

This identity follows by inclusion-exclusion from the actual repair costs. It does not use the author's capped nine-state formula.

Results:

- All **12,556 patterns**, all **36 unordered type pairs**, and all potential inequalities pass. Every independently computed pair maximum agrees with the author certificate.
- **1,049 distinct small patterns** are also checked by direct weighted sampling over **570,141 outcomes**, independently comparing actual focal-pair repairs with the coefficient formula.
- **400 fresh actual graphs**, with disconnected high cores allowed and compensated asymmetric artificial neighborhoods, pass all **108,000 matching-edge sampling outcomes**. The resulting sets are directly checked to be 2-dominating, and exact expected selected counts obey the summed potentials.
- Independently reconstructed profiles give exact margins:
  - h34: 7831/1953125;
  - h36: 52806/390625;
  - h38: 545447/1953125.
- The author's checker was rerun from its snapshot; its output certificate agrees byte-for-byte with the supplied file.

The finite potential-table verification is a proof dependency; the small physical graphs are corroboration only. No optimizer, graph catalog, or floating-point calculation is required for verification.

## Scope

Together with the earlier audited exclusions, the remaining high orders are 11–33,35,37. The separate order40 audit establishes the new representative order bound. Neither result constitutes an exhaustive residual search or a full closure. Parent handles final formatting and PDF visual QA.
