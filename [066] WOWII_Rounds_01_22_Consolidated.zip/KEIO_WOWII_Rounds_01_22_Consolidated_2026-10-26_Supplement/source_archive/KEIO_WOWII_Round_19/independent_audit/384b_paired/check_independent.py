"""Independent enumeration by recursive colored pair deletion; exact low-degree
probability coefficients instead of the author's capped nine-state product."""
from functools import lru_cache
from itertools import product,combinations
from collections import Counter
from fractions import Fraction as F
from math import comb
from pathlib import Path
import json,random,time
start=time.monotonic();ROOT=Path(__file__).resolve().parent
E=((0,1),(0,2),(0,3),(1,1),(1,2),(1,3),(2,2),(2,3),(3,3));loc={e:i for i,e in enumerate(E)}
COL=((0,0),(1,0),(0,1),(1,1));W=dict(zip(range(3,11),(295986688,206041600,140654080,95296000,64396800,43481600,30569984,25344512)));DEN=10**9
@lru_cache(None)
def patterns(pop):
 if not any(pop):return frozenset({(0,)*9})
 first=next(i+1 for i,x in enumerate(pop) if x);left=list(pop);left[first-1]-=1;out=set()
 for mate in range(4):
  if mate and not left[mate-1]:continue
  rest=left.copy()
  if mate:rest[mate-1]-=1
  idx=loc[tuple(sorted((first,mate)))]
  for P in patterns(tuple(rest)):
   Q=list(P);Q[idx]+=1;out.add(tuple(Q))
 return frozenset(out)

def edges(P):return [e for e,n in zip(E,P) for _ in range(n)]
def cost(P):
 # W=(3P(X=0)+P(X=1)+3P(Y=0)+P(Y=1)
 #     -P(0,1)-P(1,0)-P(1,1))/5. Keep only degree<=1 terms.
 px=[1,0];py=[1,0];joint={(0,0):1};den=1
 for z,w in edges(P):
  dx=Counter({0:1});dy=Counter({0:1});di=Counter({(0,0):1})
  for col in (z,w):
   x,y=COL[col];dx[x]+=2;dy[y]+=2;di[x,y]+=2
  px=[px[0]*dx[0],px[1]*dx[0]+px[0]*dx[1]]
  py=[py[0]*dy[0],py[1]*dy[0]+py[0]*dy[1]]
  nxt=Counter()
  for (x,y),weight in joint.items():
   for (u,v),mult in di.items():
    if x+u<=1 and y+v<=1:nxt[x+u,y+v]+=weight*mult
  joint=nxt;den*=5
 return F(3*px[0]+px[1]+3*py[0]+py[1]-joint.get((0,1),0)-joint.get((1,0),0)-joint.get((1,1),0),5*den)

def direct(P):
 ed=edges(P);num=0;samples=0
 for choice in product(range(3),repeat=len(ed)+1):
  x=y=0;weight=1
  for e,z in zip(ed,choice[1:]):
   if z:
    color=e[z-1];a,b=COL[color];x+=a;y+=b;weight*=2
  own=choice[0];selected=[own==1,own==2]
  if own:weight*=2
  support=[x+selected[1],y+selected[0]]
  bad=[not selected[i] and support[i]<2 for i in range(2)]
  repairs=sum(bad)
  if all(bad) and max(support)>=1:repairs=1
  num+=repairs*weight;samples+=1
 return F(num,5**(len(ed)+1)),samples

rows=[];npatterns=0;direct_patterns=set();direct_samples=0;minslack=None
for a in range(3,11):
 for b in range(a,11):
  maximum=F(-1);count=0;attaining=None
  for c in range(min(a,b)):
   for P in sorted(patterns((a-1-c,b-1-c,c))):
    value=cost(P);slack=F(W[a]+W[b],DEN)-value;assert slack>=0
    minslack=slack if minslack is None else min(minslack,slack)
    count+=1
    if value>maximum:maximum=value;attaining=(c,P)
    if sum(P)<=5 and P not in direct_patterns:
     exact,tests=direct(P);assert value==exact;direct_patterns.add(P);direct_samples+=tests
  npatterns+=count;rows.append(dict(a=a,b=b,count=count,maximum=str(maximum),attaining=attaining))
assert npatterns==12556
# Compare every independently obtained pair maximum, after all calculations.
author=json.loads((ROOT/'snapshots/paired_sampling_even_certificate.json').read_text())
for row,old in zip(rows,author['pair_rows']):
 assert (row['a'],row['b'],row['count'])==(old['a'],old['b'],old['patterns'])
 assert F(row['maximum'])==F(old['maximum']['numerator'],old['maximum']['denominator'])
bounds=[]
for h in (34,36,38):
 ds=[3]+[min(d for d in range(3,h) if d*(d-1)>=2*(i+1) and d*(d-2)>=3*i+2-h) for i in range(1,h)]
 U=F(2*h,5)+sum(F(W[d],DEN) for d in ds);margin=F(h,2)-U;assert margin>0
 bounds.append(dict(h=h,profile=dict(Counter(ds)),upper=str(U),margin=str(margin)))

# Actual-graph repairs with complete enumeration of all matching-edge choices.
def edge(A,u,v):A[u]|=1<<v;A[v]|=1<<u
def add(A,neighbors):
 v=len(A);A.append(0)
 for u in neighbors:edge(A,u,v)
 return v
rng=random.Random(193438);physical=Counter()
for h in (6,8,10,12):
 for trial in range(100):
  A=[0]*h
  for u in range(0,h,2):edge(A,u,u+1)
  for u,v in combinations(range(h),2):
   if rng.randrange(5)==0:edge(A,u,v)
  for u in range(2,h,2):add(A,[0,u])
  l=add(A,[0]);add(A,[l])
  for u in range(h):
   while A[u].bit_count()<3:add(A,[u])
  lo=((1<<len(A))-1)^((1<<h)-1);art=[];types=[]
  for u in range(h):
   a=min(10,h-1,A[u].bit_count());types.append(a)
   neigh=[v for v in range(h) if v!=(u^1) and A[u]>>v&1];rng.shuffle(neigh)
   chosen=[u^1]+neigh[:a-1]
   filler=[v for v in range(h) if v!=u and v not in chosen];rng.shuffle(filler)
   chosen+=filler[:a-len(chosen)];art.append(sum(1<<v for v in chosen));assert len(chosen)==a
  total=0
  for outcomes in product(range(3),repeat=h//2):
   S=sum(1<<(2*j+z-1) for j,z in enumerate(outcomes) if z);weight=2**sum(bool(z) for z in outcomes);D=S|lo
   support=[(art[u]&S).bit_count() for u in range(h)]
   assert all((A[u]&(S|lo)).bit_count()>=support[u] for u in range(h))
   for u in range(0,h,2):
    v=u+1;bad=[not(S>>u&1) and support[u]<2,not(S>>v&1) and support[v]<2]
    if all(bad) and max(support[u],support[v])>=1:
     chosen=u if support[u]==0 else v;D|=1<<chosen
    else:
     if bad[0]:D|=1<<u
     if bad[1]:D|=1<<v
   assert all(D>>u&1 or (A[u]&D).bit_count()>=2 for u in range(len(A)))
   total+=weight*(D&((1<<h)-1)).bit_count();physical['outcomes']+=1
  expectation=F(total,5**(h//2));bound=F(2*h,5)+sum(F(W[a],DEN) for a in types)
  assert expectation<=bound;physical['graphs']+=1

out={'status':'PASS','color_pair_patterns':npatterns,'unordered_type_pairs':len(rows),'minimum_potential_slack':str(minslack),'direct_distinct_patterns':len(direct_patterns),'direct_outcomes':direct_samples,'bounds':bounds,'physical_controls':dict(physical),'pair_rows':rows,'seconds':time.monotonic()-start,'scope':'Exact independent finite arithmetic plus physical controls; universal pairing coverage and support argument audited separately.'}
print(json.dumps(out,indent=2))
