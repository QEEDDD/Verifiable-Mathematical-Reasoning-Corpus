#!/usr/bin/env python3
"""Exact color-pair enumeration for matching-edge sampling at p=4/5.
Standalone standard library; no floating-point or optimizer is used.
"""
from collections import Counter
from fractions import Fraction as F
from itertools import product
from math import comb
from pathlib import Path
import json
COL={0:(0,0),1:(1,0),2:(0,1),3:(1,1)}
# Repair-cost upper potentials, denominator 10^9.
WEIGHT={3:295986688,4:206041600,5:140654080,6:95296000,
        7:64396800,8:43481600,9:30569984,10:25344512}
DEN=10**9

def patterns(a,b,c,zero_limit=None):
    na=a-1-c;nb=b-1-c;nc=c
    for aa in range(na//2+1):
      for ab in range(min(na-2*aa,nb)+1):
       for ac in range(min(na-2*aa-ab,nc)+1):
        for bb in range((nb-ab)//2+1):
         for bc in range(min(nb-ab-2*bb,nc-ac)+1):
          for cc in range((nc-ac-bc)//2+1):
            sa=na-2*aa-ab-ac;sb=nb-2*bb-ab-bc;sc=nc-2*cc-ac-bc
            singles=sa+sb+sc
            if zero_limit is not None and (singles>zero_limit or (zero_limit-singles)%2):continue
            edges=[(0,1,sa),(0,2,sb),(0,3,sc),(1,1,aa),(1,2,ab),
                   (1,3,ac),(2,2,bb),(2,3,bc),(3,3,cc)]
            yield tuple((x,y,n) for x,y,n in edges if n)

def distribution(edges):
    # Counts are capped at two. Each external matching edge independently
    # contributes no vertex with weight1, or either endpoint with weight2.
    state={(0,0):1};den=1
    for x,y,mult in edges:
        for _ in range(mult):
            nxt=Counter()
            for (i,j),v in state.items():
                nxt[i,j]+=v
                for color in [x,y]:
                    dx,dy=COL[color]
                    nxt[min(2,i+dx),min(2,j+dy)]+=2*v
            state=dict(nxt);den*=5
    return state,den

def repair_cost(edges):
    state,den=distribution(edges)
    num=0
    for (x,y),count in state.items():
        g=2 if x==y==0 else 0 if x==y==2 else 1
        # Own pair: neither selected(weight1), or one endpoint(weight2 each).
        num+=count*(g+2*(x==0)+2*(y==0))
    return F(num,5*den)

def direct_cost(edges):
    ed=[(x,y) for x,y,m in edges for _ in range(m)]
    total=0
    for choices in product(range(3),repeat=len(ed)+1):
        x=y=0;weight=1
        for (a,b),choice in zip(ed,choices[1:]):
            if choice:
                weight*=2;dx,dy=COL[a if choice==1 else b];x+=dx;y+=dy
        own=choices[0]
        if own==0:
            cost=2 if x==y==0 else 0 if x>=2 and y>=2 else 1
        else:
            weight*=2;cost=int(y==0) if own==1 else int(x==0)
        total+=weight*cost
    return F(total,5**(len(ed)+1))

rows=[];total=0
for a in range(3,11):
    for b in range(a,11):
        maxcost=F(-1);maxpattern=None;npat=0
        for c in range(min(a,b)):
            for edges in patterns(a,b,c):
                value=repair_cost(edges)
                assert value<=F(WEIGHT[a]+WEIGHT[b],DEN),(a,b,c,value)
                npat+=1
                if value>maxcost:maxcost=value;maxpattern=dict(common=c,edges=edges)
        total+=npat
        rows.append(dict(a=a,b=b,patterns=npat,
                         maximum=dict(numerator=maxcost.numerator,denominator=maxcost.denominator),
                         attaining_pattern=maxpattern,
                         potential_slack=str(F(WEIGHT[a]+WEIGHT[b],DEN)-maxcost)))
assert total==12556
# Direct physical-outcome controls on every feasible small color pairing.
controls=outcomes=0
for h in [6,8,10]:
    for a in range(3,min(5,h-1)+1):
        for b in range(a,min(5,h-1)+1):
            for c in range(max(0,a+b-h),min(a,b)):
                for edges in patterns(a,b,c,zero_limit=h-a-b+c):
                    assert repair_cost(edges)==direct_cost(edges)
                    controls+=1;outcomes+=3**(sum(n for x,y,n in edges)+1)

bounds=[]
for h in [34,36,38]:
    profile=[3]+[next(d for d in range(3,h) if comb(d,2)>=i+1 and d*(d-2)>=3*i+2-h)
                 for i in range(1,h)]
    counts=Counter(profile)
    upper=F(2*h,5)+sum(counts[d]*F(WEIGHT[d],DEN) for d in counts)
    assert upper<F(h,2),(h,upper)
    margin=F(h,2)-upper
    bounds.append(dict(h=h,degree_multiplicities=dict(counts),upper=str(upper),
                      upper_decimal=float(upper),margin=str(margin),margin_decimal=float(margin)))
result=dict(scope='Exact finite color-pair enumeration; independently audited even h34,36,38 exclusion.',
 sample_probability='4/5 per matching edge, each endpoint2/5, neither1/5',
 potential_denominator=DEN,potentials=WEIGHT,type_pairs=len(rows),color_pair_patterns=total,
 direct_small_pairing_controls=controls,direct_sampling_outcomes=outcomes,bounds=bounds,pair_rows=rows)
Path(__file__).with_name('paired_sampling_even_certificate.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='pair_rows'},indent=2))
