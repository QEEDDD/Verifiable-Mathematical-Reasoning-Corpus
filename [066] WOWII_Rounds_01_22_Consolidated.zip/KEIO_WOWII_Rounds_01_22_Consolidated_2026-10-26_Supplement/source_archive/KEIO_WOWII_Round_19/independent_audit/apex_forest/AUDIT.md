# Independent root audit: triangle-free apex forests

PASS for the stated unrestricted-order subclass, not full original61.

Full proof and final standalone TeX read. A maximum matching makes its unmatched set independent. Triangle-freeness ensures the two chosen matched neighbors of an unmatched nonleaf belong to distinct matching edges with five distinct vertices. In the adjacent-partner branch the five-cycle and remaining matching edges are vertex-disjoint; in the nonadjacent-partner branch both inserted edges are absent, the switch preserves every degree, and triangle+edge+remaining matching edges are disjoint. Their vertex-cover lower bounds yield the strict residue inequality via the classical residue≤independence theorem. No assumption that the switched graph remains triangle-free is needed or made.

For a cyclic graph with an acyclic ordinary maximum matching, some cycle vertex is unmatched, giving the lemma. The apex-forest argument separates nu_ac≤nu−1 from equality and uses f=n−1 only in the cyclic feedback-vertex-one case. The forest case and singleton boundary are valid. A diametral path is induced; alternate matching edges have endpoint-induced forest, proving nu_ac≥ceil(D/2). The C4 ordinary-matching counterexample is within the advertised subclass. The nontrianglefree boundary example is correct.

Independent fresh checker imports no author code. All172 nonempty triangle-free atlas graphs through order7, including disconnected graphs, were checked;792 ordinary maximum matchings,574 unmatched-nonleaf choices,55 C5 certificates and519 degree-preserving switches passed. Exact independence number of the covering-certificate graph was separately enumerated. All157 apex forests passed the full bound. The analytic proof, not these finite checks, establishes arbitrary order.

Final TeX preserves the full argument and adds precise classical attribution: FMS residue bound; Fajtlowicz degree-realization/switch method; GHHL acyclic matchings; Fuerst–Rautenbach unmatched independent-feedback-set observation. Source gate is separately recorded under round20/source_audit/apex_forest and does not certify worldwide novelty. No mathematical repair requested.

Final TeX SHA256: 4df8b15b1e8f4cffe7d7f0d17df46430260ebe790e19e578a02bf57c9468460f
