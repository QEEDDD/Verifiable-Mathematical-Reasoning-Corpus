import networkx as nx
from itertools import combinations
from pathlib import Path
import json
R=dict(trianglefree_graphs=0,maximum_matchings=0,unmatched_nonleaf_cases=0,c5_cases=0,switch_cases=0,apex_forests=0)
def residue(G):
 d=sorted((x for _,x in G.degree()),reverse=True)
 while d and d[0]:
  x=d.pop(0)
  for i in range(x):d[i]-=1
  d.sort(reverse=True)
 return len(d)
def matches(G,V):
 if not V:yield ();return
 v=min(V);rest=V-{v}
 yield from matches(G,rest)
 for w in G[v]:
  if w in rest:
   for tail in matches(G,rest-{w}):yield ((v,w),)+tail
def forest(G):return G.number_of_edges()==G.number_of_nodes()-nx.number_connected_components(G)
def alpha(G):
 n=len(G);V=list(G)
 return max((len(S) for k in range(n+1) for S in combinations(V,k) if not G.subgraph(S).number_of_edges()),default=0)
for G in nx.graph_atlas_g()[1:]:
 if any(nx.triangles(G).values()):continue
 R['trianglefree_graphs']+=1;n=len(G);r=residue(G);ms=list(matches(G,set(G)));nu=max(map(len,ms));ac=max(len(m) for m in ms if forest(G.subgraph({v for e in m for v in e})))
 for M in ms:
  if len(M)!=nu:continue
  R['maximum_matchings']+=1;partner={a:b for e in M for a,b in (e,e[::-1])}
  for x in set(G)-set(partner):
   if G.degree(x)<2:continue
   R['unmatched_nonleaf_cases']+=1;u,v=sorted(G[x])[:2];a,b=partner[u],partner[v]
   assert len({x,u,v,a,b})==5 and not G.has_edge(u,v)
   if G.has_edge(a,b):R['c5_cases']+=1;H=G
   else:
    R['switch_cases']+=1;H=G.copy();H.remove_edges_from([(u,a),(v,b)]);H.add_edges_from([(u,v),(a,b)])
    assert sorted(dict(H.degree()).values())==sorted(dict(G.degree()).values()) and residue(H)==r
   assert alpha(H)<=n-nu-1 and r<=n-nu-1
 if forest(G) or any(forest(G.subgraph(set(G)-{v})) for v in G):
  R['apex_forests']+=1;f=n if forest(G) else n-1;assert f>=r+ac
  if nx.is_connected(G):assert ac>=(nx.diameter(G)+1)//2
R['status']='PASS';print(json.dumps(R,indent=2));Path(__file__).with_name('independent_results.json').write_text(json.dumps(R,indent=2)+'\n')
