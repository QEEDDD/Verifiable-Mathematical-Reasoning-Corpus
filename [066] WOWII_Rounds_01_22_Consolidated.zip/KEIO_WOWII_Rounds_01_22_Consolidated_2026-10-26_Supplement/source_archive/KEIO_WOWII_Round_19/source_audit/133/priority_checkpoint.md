# Separate P9/local-independence priority checkpoint

Date: 26 October 2026, 07:37 UTC. Read-only primary-source research. This does not modify the frozen P8 packet, validate the proposed mathematics, or certify worldwide priority.

## Candidate being screened

The worker reports a proposed classification of connected graphs with no C4 as a **subgraph**, no induced P9, and local independence lambda(v)=alpha(G[N(v)]) at least 3 at every vertex: eleven graphs, seven triangle-free and four containing triangles. Reported (n,L), with L=sum lambda(v)=2m-3t in this class, are respectively

- triangle-free: (10,30), (14,46), (13,42), (12,36), (12,36), (13,40), (14,42);
- triangle-containing: (13,39), (14,45), (16,48), (15,51).

The associated proposed global density statement is L<4n for strong-C4-free P9-free graphs. The classification certificate and its arbitrary-order completeness proof were pending independent mathematical audit at this checkpoint. This remains a partial route to WOWII133, not a full closure.

## Bounded finding

**No exact prior eleven-graph classification, equivalent minimum-local-independence theorem, or exact full-class weighted density inequality was located in this pass.** This is a bounded negative finding, not a claim that no such result exists. The P8 subcase and several individual graphs are established antecedents; extending their scope to P9 needs its own proof.

### Precisely relevant earlier result

Chudnovsky–Stacho, _3-colorable subclasses of P8-free graphs_, SIAM J. Discrete Math.32(2)(2018),1111–1138, DOI10.1137/16M1104858, [author manuscript](https://web.math.princeton.edu/~mchudnov/p8free1.pdf), Theorem1: a connected girth-at-least-five P8-free graph is Petersen, Heawood, Heawood with one edge contracted, or has a vertex of degree at most two. The cached full text was rechecked, including its theorem statements and bibliography. This is exact prior work for the corresponding P8 triangle-free subcase, not a P9 classification. Its first-part acknowledgment also credits joint work with Paul Seymour. The previously recovered Hanaki–Nikkuni–Taniyama–Yamazaki Heawood-family source establishes the 13-vertex Y–Delta–Heawood graph as prior construction; see the separate P8 checkpoint for precise references. No graph-construction novelty is inferred here.

### Primary near-matches excluded by their actual hypotheses

1. Alberto Rojas and Maya Stein, _3-Colouring P_t-free graphs without short odd cycles_, [arXiv:2008.04845](https://arxiv.org/abs/2008.04845), first submitted 11 August 2020. The primary author PDF was retrieved; introduction, main statements and structural-lemma hypotheses were checked. Theorem1.1 gives a polynomial-time 3-coloring algorithm for odd t>=9 and odd girth at least t-2; Theorem1.2 specializes to (P9,C3,C5)-free graphs. Thus t=9 excludes C5 as well as triangles, and the theorem is algorithmic, not a minimum-degree classification or weighted density bound. Its structural Lemmas5.12/5.24 are potentially relevant to that restricted branch, but no implication to the entire proposed class was established here.
2. Serge Gaspers, Shenwei Huang and Daniel Paulusma, _Colouring Square-Free Graphs without Long Induced Paths_, STACS2018, [primary proceedings PDF](https://drops.dagstuhl.de/opus/volltexte/2018/8492/pdf/LIPIcs-STACS-2018-35.pdf). The full text was downloaded and the main statements/Section4 construction checked. Its square exclusion is **induced C4**, and Theorem14 concerns coloring hardness in (C4,3P3,P3+P6,2P5,P9)-free graphs. The construction uses large cliques. It is not a theorem for the strong-C4-free class and neither settles nor contradicts the proposed classification.
3. Yongxin Lan and Yongtang Shi, _Extremal P8-free/P9-free planar graphs_, author manuscript 23 November2020, [primary author PDF](https://cfc.nankai.edu.cn/_upload/article/files/81/18/f83d37e449ebaf1b2f4141fa59be/9588dfc0-1400-4088-9ad3-394d6a2ffcc2.pdf). The first-page definition and principal theorem statements were checked: paths are forbidden as **subgraphs**, and the hosts are planar. These are two extra restrictions, so its extremal edge counts are not the proposed induced-path/local-independence inequality.
4. Brandstaedt–Mosca P9-free efficient-domination/dominating-induced-matching algorithm sources and Micek–Wiechert's P9-free bipartite online-coloring work surfaced. Available primary abstracts/statements concern algorithms (some adding maximum degree at most three), not the requested minimum-degree/local-independence classification. These were not treated as full-text-excluded antecedents.
5. The Chen–Xu 2026 square-free/linear-Pollyanna paper and corrected Chudnovsky–Seymour even-hole-free bisimplicial theorem remain applicable only with their extra hypotheses. Their scope and access limits are documented in the P8 checkpoint; neither was promoted to an unrestricted P9 result.

## Public-record check

Fresh all-state GitHub title/body API searches for P9 in google-deepmind/formal-conjectures and umaia1234/agentic-conjectures, and for girth+133 in Formal Conjectures, each returned zero. Raw responses and query/time summary are saved beside this note. The earlier same-day exact133 and local-independence queries are in the P8 checkpoint. These searches do not cover every comment, attachment, alternate notation or repository.

Focused web queries combined P9/P_9, girth five, strong C4, diamond, minimum degree, local independence, Petersen/Heawood, density, 2m and eleven-graph classification. Many apparent matches use induced-C4 rather than subgraph-C4, ordinary rather than induced paths, or different algorithmic conclusions. No exact prior result was identified in the sources actually inspected; lack of an indexed match is not a priority certificate.

## Safe use

Credit the exact P8 antecedent and known graph constructions. Describe the P9 work only at its actual mathematical-audit stage. If validated, the supportable priority wording is: no exact antecedent was located in this bounded primary-source check. No currently-open curator certification, full133 closure, or worldwide-first claim follows.
