# Bounded antecedent review: triangle-free apex forests

26 October 2026, 07:42–07:47 UTC. Source review only, not mathematical verification. Target manuscript: `round_18/independence/apex_forest_theorem.md` and its TeX companion.

## Finding

**No exact prior statement was located for the unmatched-nonleaf residue strictness lemma or for `f(G) >= res(G)+nu_ac(G)` on triangle-free graphs with feedback-vertex number at most one.** This bounded finding is not a novelty certificate. Several precise components are classical or explicitly stated in earlier papers and should be credited as such.

The candidate lemma says: if a maximum matching of a triangle-free n-vertex graph leaves a vertex of degree at least two unmatched, then `res(G) <= n-nu(G)-1`. The proposed proof uses either a C5 plus disjoint matching edges or a degree-preserving switch creating a triangle plus disjoint matching edges in another realization. The proposed consequence for feedback-vertex number at most one yields the stronger half-diameter subclass bound, not unrestricted WOWII61.

## Exact antecedents and distinctions

### 1. Residue and degree-sequence realization method

O. Favaron, M. Mahéo and J.-F. Saclé, **On the residue of a graph**, J. Graph Theory15(1)(1991),39–64, [DOI10.1002/jgt.3190150107](https://doi.org/10.1002/jgt.3190150107), is the established `res(H)<=alpha(H)` source. Degree-sequence dependence is part of the residue definition. Griggs–Kleitman later gave a short proof: **Independence and the Havel–Hakimi residue**, Discrete Math.127(1994),209–212, [DOI10.1016/0012-365X(92)00479-B](https://doi.org/10.1016/0012-365X(92)00479-B). Neither input is a new lemma here.

Siemion Fajtlowicz's **Written on the Wall**, July2004 version, [primary author catalogue](https://independencenumber.wordpress.com/wp-content/uploads/2012/08/wow-july2004.pdf), printed p.37, explicitly discusses

`b(d)=min{alpha(H): H realizes d}`

as the best degree-sequence-only independence bound, attributing this viewpoint to Favaron–Mahéo–Saclé. The same page discusses two-edge switching in Havel–Hakimi realization arguments and controlling independence during the switches. The page was visually checked because the local PDF text extraction has a broken font mapping; its PNG is retained. This is a direct antecedent for the general realization-switch strategy. It does **not** state the proposed unmatched-nonleaf theorem. Do not describe the general switch technique as newly invented.

**Access limitation:** the full FMS1991 publisher PDF request returned HTTP403. Its primary bibliographic record and definition were accessible, and the standard inequality is explicitly restated in later primary papers; the entire 1991 article was not read in this pass. No assertion is made that it contains no related intermediate lemma. No access restriction was bypassed. The complete Griggs–Kleitman paper was also not newly recovered.

### 2. Acyclic matching definition, ordering, and path values

W. Goddard, S.M. Hedetniemi, S.T. Hedetniemi and R. Laskar, **Generalized subgraph-restricted matchings in graphs**, Discrete Math.293(2005),129–138, [DOI10.1016/j.disc.2004.08.027](https://doi.org/10.1016/j.disc.2004.08.027); [primary author manuscript](https://people.computing.clemson.edu/~goddard/papers/generalizedMatchings.pdf), dated7 October2004, full text retrieved and checked.

- Section1.1(6) defines acyclic matching through the graph induced by its saturated vertices, exactly the candidate's convention.
- Section2 gives induced matching <= acyclic matching <= uniquely restricted matching <= ordinary matching. The distinctions in the candidate manuscript are therefore appropriate and classical.
- Theorem3 gives `beta_P(P_n)=floor(n/2)` whenever the induced-hereditary property P includes all paths. Consequently, taking a matching in an induced diametral path to obtain `nu_ac(G)>=ceil(D/2)` is a standard path consequence, not a separate new ingredient.
- Section1 observes `2 nu_ac(G)<=f(G)`. This is not the candidate's additive residue inequality and does not by itself imply it.

No Havel–Hakimi residue or apex-forest inequality appears in the checked full text.

### 3. Maximum acyclic matchings and independent feedback sets

M. Fürst and D. Rautenbach, **On some hard and some tractable cases of the maximum acyclic matching problem**, Annals of Operations Research279(2019),291–300, [DOI10.1007/s10479-019-03311-1](https://doi.org/10.1007/s10479-019-03311-1); [arXiv:1710.08236](https://arxiv.org/abs/1710.08236),23 October2017. Full primary manuscript retrieved and checked.

The conclusion, author p.9, explicitly notes that the vertices unsaturated by an acyclic **ordinary maximum matching** form an independent feedback vertex set. This is exactly the preliminary matching/feedback-set observation used in the proposed cyclic corollary. Credit it rather than presenting that observation as new.

Theorem5 states that **every** maximum matching is acyclic iff every component is a tree or an odd cycle. This quantifier is stronger than existence of some acyclic maximum matching (`nu_ac=nu`) and cannot replace it. The paper does not state a residue strictness result. Its equality-complexity theorem concerns bipartite graphs with partite sets A,B, |A|<=|B|, matching number |A|, and maximum degree at most4; it does not assume a perfect matching of the whole graph. A later abstract's loose “perfect matching” paraphrase should not be propagated.

### 4. Induced-forest optimization viewpoint

J. Baste and D. Rautenbach, **Degenerate Matchings and Edge Colorings**, [arXiv:1702.02358](https://arxiv.org/abs/1702.02358),2017. Full primary author PDF retrieved; its definitions, results and conclusion screened. Section4 explicitly identifies acyclic-matching optimization with maximizing the ordinary matching number over induced forests, and relates induced forests to feedback vertex sets. This is earlier conceptual context, not the additive residue inequality; no residue result was located there.

### 5. Other residue-equality literature already cached

Barrus–Molnar, **Graphs with the strong Havel–Hakimi property**, Graphs Combin.32(2016),1689–1697, DOI10.1007/s00373-015-1674-7, [arXiv:1505.00085](https://arxiv.org/abs/1505.00085), gives `res=alpha` for its hereditary strong-HH class. It does not characterize all residue equality cases, so reversing this implication to claim the new strictness lemma is a prior corollary would be unjustified. The cached primary full text was re-screened.

Kadrawi–Levit, **Annihilation, Independence, and Residue: Sharp Matching Bounds for the Annihilation Gap and a TxGraffiti Application**, [arXiv:2607.01438](https://arxiv.org/abs/2607.01438),1 July2026, treats annihilation-minus-independence bounds and uses the classical residue comparison. Its matching-number/equality theorems are not the stated unmatched-nonleaf or apex-forest result. The previously recovered full text and relevant residue section were reused; no duplicate download was needed.

## Public-record searches and limits

Fresh all-state GitHub title/body searches returned:

- Formal Conjectures `residue acyclic`:2, concerning the different WOWII59 counterexample and basic graph-invariant tests;
- Formal Conjectures `residue matching`:8, comprising that WOWII59 report, basic small-graph tests, and unrelated arithmetic/source-status matters;
- Formal Conjectures `residue unmatched`:0;
- Agentic Conjectures `apex forest`:0.

All returned bodies relevant to graphs were inspected; raw responses, counts and retrieval times are retained. No matching prior theorem was found. These queries do not scan every comment, attachment, repository or alternate notation. Same-day/earlier exact61 status records are in `round_17/source_audit/61`; historical O and a Lean open label are not treated as evidence of worldwide unresolved status.

Focused web queries also used residue/Havel–Hakimi/depth with matching, unsaturated/unmatched/nonleaf, strictness/equality, degree-preserving realizations, acyclic matching, induced forest, feedback vertex and apex/unicyclic terminology. No exact antecedent was located in the inspected sources. An absent search hit is not evidence that no result exists.

## Safe attribution and status

The established residue inequality, matching-cover bound, two-edge-switch method, acyclic matching definition/path observation, and the independent-feedback-set observation are prior ingredients. The exact local strictness certificate and its stated apex-forest consequence may be reported as independently established partial results if the mathematical audit approves them, with priority left uncertified. This note neither verifies that proof nor closes unrestricted61. Compact packaging can include this note, API summary and provenance; full third-party PDFs can remain in the research cache.
