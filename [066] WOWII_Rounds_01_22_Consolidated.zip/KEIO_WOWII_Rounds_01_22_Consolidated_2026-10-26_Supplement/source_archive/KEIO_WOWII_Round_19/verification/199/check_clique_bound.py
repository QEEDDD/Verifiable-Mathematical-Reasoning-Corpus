#!/usr/bin/env python3
"""Exact constructive guard for the q<=2k split incidence theorem.
Checks arbitrary-order proof branches; finite controls are not the proof.
"""
from pathlib import Path
from itertools import combinations
from collections import Counter
import random,json,time

def construct(cols,h,k):
 q=len(cols);n=q+h;a=q-h
 assert 1<=h<=q<=2*k and k>=1 and all(cols)
 rows=[{c for c,T in enumerate(cols) if i in T} for i in range(h)]
 assert min(map(len,rows))>=k and max(map(len,cols))<=k+1
 distance_ok=all(len(S^T)<=k for S,T in combinations(cols,2))
 if q==2*k:assert distance_ok
 E=sum(len(R)-k for R in rows);W=sum(k+1-len(T) for T in cols);B=q+k*a
 assert W==B-E
 ordered=sorted(range(q),key=lambda c:len(cols[c]))
 failures=[j for j in range(1,q-k+1) if len(cols[ordered[j-1]])<j-a]
 phases=[]
 if h<=k+1:
  assert not failures;phases=[(ordered,set(range(h)))];case='small_independent_side'
 elif not failures:
  phases=[(ordered[::-1],set(range(h)))];case='descending_columns'
 else:
  assert q==2*k and E==0
  for j in failures:
   assert a+2<=j<=q-k
   f=j*(k+a+2-j)
   assert f==B==W and j in {a+2,k}
   assert all(len(cols[c])==j-a-1 for c in ordered[:j])
   assert all(len(cols[c])==k+1 for c in ordered[j:])
  # The singleton endpoint pattern contradicts a degree-k row.
  assert a+2 not in failures
  ell=h-k-1;low=ordered[:k];high=ordered[k:]
  assert ell>=1 and len(low)==len(high)==k
  assert all(len(cols[c])==ell for c in low)
  assert all(len(cols[c])==k+1 for c in high)
  U=set().union(*(cols[c] for c in low));assert len(U)>=ell+1
  phases=[(high,set(range(h))),(low,U),(low,set(range(h))-U)]
  case='boundary_low_union'
 adj=[set() for _ in range(n)]
 for c,T in enumerate(cols):
  adj[c]=set(range(q))-{c}
  for i in T:adj[c].add(q+i);adj[q+i].add(c)
 added=[];stage_added=[]
 for order,target in phases:
  added_here=0
  for c in order:
   for i in sorted(target):
    u=q+i
    if c in adj[u]:continue
    assert len(adj[u])+len(adj[c])>=n-1
    added.append((u,c));added_here+=1;adj[u].add(c);adj[c].add(u)
  stage_added.append(added_here)
 assert all(len(adj[q+i])==q for i in range(h))
 P=[q]
 for i in range(1,h):P.extend([i-1,q+i])
 P.extend(range(h-1,q))
 repairs=0
 for u,v in reversed(added):
  adj[u].remove(v);adj[v].remove(u)
  assert len(adj[u])+len(adj[v])>=n-1
  if not any({x,y}=={u,v} for x,y in zip(P,P[1:])):continue
  repairs+=1;w=n;cyc=P+[w];N=n+1;j=cyc.index(u)
  step=-1 if cyc[(j+1)%N]==v else 1
  Q=[cyc[(j+step*t)%N] for t in range(N)]
  assert Q[0]==u and Q[-1]==v
  def edge(x,y):return x==w or y==w or y in adj[x]
  cut=next(j for j in range(N-1) if edge(u,Q[j+1]) and edge(Q[j],v))
  cyc=Q[:cut+1]+Q[cut+1:][::-1];z=cyc.index(w);P=cyc[z+1:]+cyc[:z]
  assert all(y in adj[x] for x,y in zip(P,P[1:]))
 assert len(P)==n and set(P)==set(range(n))
 assert all(y in adj[x] for x,y in zip(P,P[1:]))
 return P,dict(case=case,reverse_repairs=repairs,added_edges=len(added),phase_added=stage_added,distance_ok=distance_ok)

start=time.monotonic();total=0;cases=Counter();families=Counter();stats=Counter();rng=random.Random(1991927)
def run(cols,h,k,family):
 global total
 P,R=construct(cols,h,k);total+=1;cases[R['case']]+=1;families[family]+=1
 stats['reverse_repairs']+=R['reverse_repairs'];stats['closure_additions']+=R['added_edges']
 stats['satisfies_original_distance_bound']+=int(R['distance_ok'])
 stats['broader_q_lt_2k_only']+=int(not R['distance_ok'])
 return P,R

# Small column-multiset grammar. The q<2k statement deliberately permits
# matrices that do not meet the stronger original pair-distance condition.
for q in range(1,6):
 for h in range(1,min(q,9-q)+1):
  for k in range((q+1)//2,q+1):
   types=[set(T) for s in range(1,min(h,k+1)+1) for T in combinations(range(h),s)]
   def visit(cols,start_type,degrees):
    remaining=q-len(cols)
    if any(r+remaining<k for r in degrees):return
    if not remaining:
     if min(degrees)==k:run(cols,h,k,'small_column_multisets')
     return
    for j in range(start_type,len(types)):
     T=types[j]
     if q<2*k or all(len(T^S)<=k for S in cols):
      visit(cols+[T],j,[r+(i in T) for i,r in enumerate(degrees)])
   visit([],0,[0]*h)
# Seeded q<2k incidence matrices from cyclic injections plus safe additions.
for k in range(2,21):
 for _ in range(50):
  q=rng.randrange(k,2*k);h=rng.randrange(1,q+1)
  shifts=rng.sample(range(q),k);offsets=rng.sample(range(q),h);perm=list(range(q));rng.shuffle(perm)
  cols=[set() for _ in range(q)]
  for i,offset in enumerate(offsets):
   for shift in shifts:cols[perm[(offset+shift)%q]].add(i)
  for T in cols:
   if not T:T.add(rng.randrange(h))
  missing=[(c,i) for c,T in enumerate(cols) for i in range(h) if i not in T];rng.shuffle(missing)
  for c,i in missing:
   if len(cols[c])<k+1 and rng.random()<0.2:cols[c].add(i)
  run(cols,h,k,'seeded_strict_clique_bound')
# q=2k boundary families from Fano complements and repeated clique columns.
fano=[set(T) for T in combinations(range(1,8),3) if T[0]^T[1]^T[2]==0]
for scale in range(1,11):
 cols=[]
 for L in fano:
  T={7*scale}|{(i-1)*scale+j for i in range(1,8) if i not in L for j in range(scale)}
  cols.extend([T.copy() for _ in range(scale)])
 cols += [cols[0].copy() for _ in range(scale)]
 run(cols,7*scale+1,4*scale,'boundary_Fano_extensions')
 for _ in range(5):
  kept={7*scale}|set(rng.sample(range(7*scale),rng.randrange(1,7*scale+1)))
  remap={old:new for new,old in enumerate(sorted(kept))}
  reduced=[{remap[i] for i in T&kept} for T in cols]
  run(reduced,len(kept),4*scale,'boundary_Fano_row_deletions')
# Genuine exceptional Pattern B: a grid's repeated row triples/sets and
# complements of its repeated column sets have matching point degrees.
examples=[]
for side in range(3,8):
 for repeats in range(side-1,side+3):
  k=side*repeats;q=2*k;h=k+side+1;V=set(range(h))
  assert h>=side*side
  low=[{side*x+y for y in range(side)} for x in range(side) for _ in range(repeats)]
  high=[V-{side*x+y for x in range(side)} for y in range(side) for _ in range(repeats)]
  cols=low+high;P,R=run(cols,h,k,'boundary_grid_low_union')
  assert R['case']=='boundary_low_union' and len(R['phase_added'])==3
  if side==3 and repeats==2:examples.append(dict(k=k,q=q,h=h,columns=[sorted(T) for T in cols],path=P,operations=R))
Path(__file__).with_name('boundary_low_union_example.json').write_text(json.dumps(examples[0],indent=2)+'\n')
out=dict(status='PASS',total_constructed_paths=total,case_counts=dict(cases),family_counts=dict(families),operation_counts=dict(stats),seconds=time.monotonic()-start,scope='Constructive exact checks, not proof by enumeration. Small multisets q<=5,h<=q,q+h<=9; seeded strict bound; Fano extensions; scalable genuine low-union boundary designs.',new_original_closures=0)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
