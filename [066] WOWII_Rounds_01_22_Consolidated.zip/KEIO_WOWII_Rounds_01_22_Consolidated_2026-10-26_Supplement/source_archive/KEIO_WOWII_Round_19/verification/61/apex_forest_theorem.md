# Triangle-free apex forests: an acyclic-matching and half-diameter bound

**Status:** complete argument, submitted for independent audit. This is a
restricted-family result. Original WOWII #61 on arbitrary triangle-free
graphs, and the stronger arbitrary-triangle-free half-diameter bound,
remain unproved here. Publication priority has not been certified.

Let `r(G)` be ordinary Havel--Hakimi residue, `f(G)` maximum induced forest
order, `nu(G)` ordinary maximum matching size, and `nu_ac(G)` maximum
**acyclic matching** size: the subgraph induced by all matching endpoints
must be a forest. This is the standard acyclic matching notion, not merely
uniquely restricted matching. The terminology originates with Goddard,
Hedetniemi, Hedetniemi and Laskar, *Generalized subgraph-restricted matchings
in graphs*, Discrete Mathematics 293 (2005), 129--138,
DOI 10.1016/j.disc.2004.08.027; the definition is also explicitly given in
Baste--Rautenbach, *Degenerate Matchings and Edge Colorings*,
arXiv:1702.02358.

The only residue input is the established `r(H)<=alpha(H)` for every
finite simple graph H (Favaron--Maheo--Sacle, *On the residue of a graph*,
J. Graph Theory 15 (1991), 39--64, DOI 10.1002/jgt.3190150107), and the fact
that residue depends only on the degree sequence. The elementary matching
bound `alpha(H)<=|H|-nu(H)` follows because every vertex cover meets every
edge of a maximum matching.

## 1. A strict residue certificate from an unmatched nonleaf

**Lemma.** Let G be a triangle-free graph on n vertices. If some maximum
matching M leaves a vertex x of degree at least two unmatched, then

`r(G) <= n-nu(G)-1`.

**Proof.** An unmatched vertex cannot be adjacent to another unmatched
vertex, since adding their edge would enlarge M. Choose distinct neighbors
u,v of x, and write `ua,vb` for their incident matching edges. Triangle-
freeness gives `uv` absent, so these are two distinct matching edges and
`x,u,v,a,b` are five distinct vertices.

If `ab` is an edge, G contains the five-cycle

`x-u-a-b-v-x`.

This cycle is vertex-disjoint from the `nu-2` remaining matching edges.
Any vertex cover of G therefore has size at least
`3+(nu-2)=nu+1`, and `r(G)<=alpha(G)<=n-nu-1`.

If `ab` is absent, delete `ua,vb` and add `uv,ab`. Both added edges were
absent and all four endpoints are distinct, so the new graph G' has the
same degree sequence. It contains the mutually vertex-disjoint triangle
`x,u,v`, edge `a,b`, and `nu-2` remaining edges of M. Any vertex cover
has at least `2+1+(nu-2)=nu+1` vertices. Consequently

`r(G)=r(G')<=alpha(G')<=n-nu-1`.

These two cases exhaust the possibilities. QED.

The lemma does not require acyclicity of M or assume that G is bipartite.
It gives a useful structural consequence: if a triangle-free graph satisfies
`r(G)=n-nu(G)`, every vertex left unmatched by **any** maximum matching has
degree at most one.

## 2. Cyclic graphs with an acyclic maximum ordinary matching

**Corollary.** If G is triangle-free and cyclic and
`nu_ac(G)=nu(G)`, then `r(G)<=n-nu(G)-1`.

**Proof.** Choose an acyclic matching M of size nu. Its endpoint-induced
graph is a forest. The unmatched set R is independent, because M is
maximum. Since G contains a cycle, that cycle must meet R; a vertex x of
the cycle in R has at least two neighbors. The lemma applies. QED.

The condition here is that an **ordinary maximum matching can be chosen
acyclic**. It is not the false assertion that an arbitrary maximum
matching, or an arbitrary uniquely restricted matching, is acyclic.

## 3. The apex-forest theorem

**Theorem.** If G is triangle-free and deleting at most one vertex makes
it a forest, then

`f(G) >= r(G)+nu_ac(G)`.

**Proof.** If G is a forest, every matching is acyclic and
`f(G)=n>=r(G)+nu(G)=r(G)+nu_ac(G)` by the elementary matching bound.

Otherwise G is cyclic and has feedback-vertex number exactly one, so
`f(G)=n-1`. If `nu_ac<=nu-1`, then

`r(G)+nu_ac(G) <= (n-nu)+(nu-1)=n-1=f(G)`.

If `nu_ac=nu`, the preceding corollary instead gives

`r(G)+nu_ac(G) <= (n-nu-1)+nu=n-1=f(G)`.

This proves both cases. QED.

No special maximum-degree assumption is imposed on the feedback vertex.
The graph may have arbitrarily many cycles through that vertex; the result
is not limited to unicyclic graphs.

## 4. Original-statement consequence and boundary

In a connected graph of diameter D, a diametral path is induced. A matching
of size `floor((D+1)/2)=ceil(D/2)` along that path is acyclic in G, because
its endpoints induce a subgraph of that induced path. Thus

`nu_ac(G) >= ceil(D/2)`.

For every connected triangle-free graph of feedback-vertex number at most
one we have proved

`f(G) >= r(G)+ceil(D/2) >= r(G)+ceil(D/3)`.

The latter is original #61 on this entire subclass, with no diameter
restriction. The single-vertex graph has D=0, f=r=1 and is included.
This is NOT a closure for all triangle-free graphs: feedback-vertex number
at least two remains outside this proof. The unrestricted acyclic-matching
candidate also remains unproved.

Triangle-freeness cannot simply be dropped: a triangle with a pendant leaf
at each of two distinct triangle vertices has `f=4`, `r=3`, `nu_ac=2`,
and D=3, violating both stronger displayed bounds. Likewise ordinary
matching number cannot replace acyclic matching number even inside the
feedback-vertex-one subclass: C4 has `f=3`, `r=2`, `nu=2`, `nu_ac=1`.

## 5. Explicit classical-ingredient credits

The unmatched vertices of an acyclic ordinary maximum matching form an
independent feedback vertex set; this is explicitly stated in the
Conclusion of Fuerst--Rautenbach, *On some hard and some tractable cases
of the maximum acyclic matching problem*, arXiv:1710.08236 (2017),
published Annals of Operations Research 279 (2019), 291--300,
DOI 10.1007/s10479-019-03311-1. The observation in Section2 is therefore
credited, not new. The strict residue conclusion additionally uses the
local five-cycle/two-switch certificate in Section1.

The ordinary path matching formula is standard and is included in
Goddard et al. Theorem3 for path-containing matching restrictions.
Finally, the degree-realization minimum-independence viewpoint and
two-edge switching method are explicitly discussed by Fajtlowicz,
*Written on the Wall*, July2004 version, p37. Neither general technique
is claimed as new. The exact strict residue/apex statements remain
subject to the separate source-priority gate.
