"""Finite test of an auxiliary candidate, not a proof."""
import argparse,functools,json,sys,time
from pathlib import Path
import networkx as nx
from control_common import invariants,residue

def acyclic_matching(G):
 n=len(G);A=[sum(1<<v for v in G[u]) for u in G]
 @functools.lru_cache(None)
 def pm(S):
  if not S:return 1
  if S.bit_count()%2:return 0
  u=(S&-S).bit_length()-1;T=S&~(1<<u);N=A[u]&T;t=0
  while N:
   z=N&-N;N^=z;t+=pm(T&~z)
   if t>=2:return 2
  return t
 def forest(S):
  while S:
   for u in range(n):
    if S>>u&1 and (A[u]&S).bit_count()<=1:S^=1<<u;break
   else:return False
  return True
 vals=[S for S in range(1<<n) if pm(S)==1 and forest(S)]
 S=max(vals,key=int.bit_count)
 return S.bit_count()//2,S

def main():
 p=argparse.ArgumentParser();p.add_argument('--graphs',default=str(Path(__file__).with_name('triangle_free_connected_2_to_9.g6')));p.add_argument('--atlas',action='store_true');a=p.parse_args()
 out={'scope':'unproved candidate f>=res+acyclic_matching','checked':0,'equalities':0};st=time.monotonic()
 graphs=nx.graph_atlas_g() if a.atlas else nx.read_graph6(a.graphs)
 for G in graphs:
  if not len(G) or not nx.is_connected(G):continue
  out['checked']+=1;al,f,_=invariants(G);r=residue(G);ur,S=acyclic_matching(G)
  if f<r+ur:
   out.update(status='COUNTEREXAMPLE',g6=nx.to_graph6_bytes(G,header=False).decode().strip(),edges=list(G.edges()),f=f,residue=r,alpha=al,acyclic_matching=ur,endpoints=[v for v in G if S>>v&1],diameter=nx.diameter(G),seconds=time.monotonic()-st);break
  out['equalities']+=f==r+ur
 else:out.update(status='FINITE_PASS_ONLY',seconds=time.monotonic()-st)
 print(json.dumps(out,indent=2))
if __name__=='__main__':main()
