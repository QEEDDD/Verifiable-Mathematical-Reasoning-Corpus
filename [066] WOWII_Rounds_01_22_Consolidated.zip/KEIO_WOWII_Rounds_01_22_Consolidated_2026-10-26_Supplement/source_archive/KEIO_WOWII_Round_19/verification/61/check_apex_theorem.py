"""Author exact small checks, including every maximum matching and local certificate."""
import functools,itertools,json,sys,time
from pathlib import Path
import networkx as nx
from control_common import invariants,residue
from check_acyclic_matching import acyclic_matching
st=time.monotonic();out={'scope':'author finite checks, not independent audit or proof substitute','triangle_free_graphs':0,'all_maximum_matchings':0,'unmatched_nonleaf_cases':0,'C5_certificates':0,'switched_triangle_certificates':0,'cyclic_with_acyclic_maximum':0,'feedback_number_at_most_one':0,'cyclic_apex_forests':0}
for G in nx.read_graph6(str(Path(__file__).with_name('triangle_free_connected_2_to_9.g6'))):
 n=len(G);out['triangle_free_graphs']+=1;A=[sum(1<<v for v in G[u]) for u in G]
 @functools.lru_cache(None)
 def nu(S):
  if not S:return 0
  u=(S&-S).bit_length()-1;T=S&~(1<<u);v=nu(T);N=A[u]&T
  while N:
   z=N&-N;N^=z;v=max(v,1+nu(T&~z))
  return v
 def matchings(S,k,M):
  if not S:
   if not k:yield M
   return
  u=(S&-S).bit_length()-1;T=S&~(1<<u)
  if nu(T)==k:yield from matchings(T,k,M)
  N=A[u]&T
  while N:
   z=N&-N;N^=z;v=z.bit_length()-1
   if 1+nu(T&~z)==k:yield from matchings(T&~z,k-1,M+[(u,v)])
 nm=nu((1<<n)-1);r=residue(G);_,f,_=invariants(G);ac,_=acyclic_matching(G)
 for M in matchings((1<<n)-1,nm,[]):
  out['all_maximum_matchings']+=1;mate={}
  for u,v in M:mate[u]=v;mate[v]=u
  for x in G:
   if x in mate or len(G[x])<2:continue
   out['unmatched_nonleaf_cases']+=1;assert r<=n-nm-1
   for u,v in itertools.combinations(G[x],2):
    assert u in mate and v in mate and not G.has_edge(u,v)
    a,b=mate[u],mate[v];assert len({x,u,v,a,b})==5
    rest=[e for e in M if u not in e and v not in e]
    if G.has_edge(a,b):
     out['C5_certificates']+=1;C=[x,u,a,b,v];assert all(G.has_edge(i,j) for i,j in zip(C,C[1:]+C[:1]));parts=[C]+[list(e) for e in rest];lower=3+len(rest)
    else:
     out['switched_triangle_certificates']+=1;H=G.copy();H.remove_edges_from([(u,a),(v,b)]);H.add_edges_from([(u,v),(a,b)]);assert dict(H.degree())==dict(G.degree())
     assert all(H.has_edge(*e) for e in [(x,u),(u,v),(v,x),(a,b)]+rest)
     parts=[[x,u,v],[a,b]]+[list(e) for e in rest];lower=2+1+len(rest)
    V=[w for P in parts for w in P];assert len(V)==len(set(V)) and lower==nm+1
 if f<n and ac==nm:
  out['cyclic_with_acyclic_maximum']+=1;assert r<=n-nm-1
 if f>=n-1:
  out['feedback_number_at_most_one']+=1;out['cyclic_apex_forests']+=f<n
  assert f>=r+ac and f>=r+(nx.diameter(G)+1)//2
out.update(status='PASS',seconds=time.monotonic()-st);print(json.dumps(out,indent=2))
