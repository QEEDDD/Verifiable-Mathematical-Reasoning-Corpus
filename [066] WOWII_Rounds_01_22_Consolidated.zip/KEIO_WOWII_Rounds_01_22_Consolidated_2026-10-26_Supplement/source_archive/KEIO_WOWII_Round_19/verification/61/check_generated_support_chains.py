"""Generated unbounded-feedback-class controls; independent generic C++ f enumeration."""
import argparse,json,random,subprocess,time
from pathlib import Path
import networkx as nx
from check_minimum_matching_geodesic import check
p=argparse.ArgumentParser();p.add_argument('--engine',default='/tmp/r19_exact_forest');a=p.parse_args();rng=random.Random(190061);st=time.monotonic();graphs=[]
# Explicit even-diameter double-link chains reach feedback number three.
for k in range(2,8):
 G=nx.path_graph(2*k+1)
 for j in range(1,k):x=len(G);G.add_edges_from([(2*j-1,x),(x,2*j+1)])
 graphs.append(G)
while len(graphs)<406:
 k=rng.randrange(2,9);even=bool(rng.randrange(2));D=2*k if even else 2*k-1;G=nx.path_graph(D+1)
 if even:U=list(range(1,2*k,2))
 else:
  h=rng.randrange(k+1);U=[2*j+1 if j<h else 2*j for j in range(k)]
 for u,v in zip(U,U[1:]):
  if abs(u-v)!=2:continue
  for _ in range(rng.randrange(3)):
   x=len(G);G.add_edges_from([(u,x),(v,x)])
 for u in U:
  if u in [0,D]:continue
  if rng.randrange(2):G.add_edge(u,len(G))
 if len(G)<=22:graphs.append(G)
input_data=''.join(str(len(G))+' '+' '.join(str(sum(1<<v for v in G[u])) for u in G)+'\n' for G in graphs)
Path(__file__).with_name('generated_support_chains.tsv').write_text(input_data)
ret=subprocess.run([a.engine],input=input_data,text=True,capture_output=True,check=True);forests=list(map(int,ret.stdout.split()));assert len(forests)==len(graphs)
out={'scope':'generated candidate-class controls, not independent proof audit','seed':190061,'graphs':len(graphs),'even':0,'odd':0,'max_order':0,'max_diameter':0,'max_feedback_number':0,'multiple_feedback_cases':0,'switches':0}
for G,f in zip(graphs,forests):
 dist=dict(nx.all_pairs_shortest_path_length(G));D=max(max(L.values()) for L in dist.values());k=(D+1)//2;assert len(nx.max_weight_matching(G,maxcardinality=True))==k
 u,v=next((u,v) for u in G for v in G if dist[u][v]==D);P=nx.shortest_path(G,u,v);t=check(G,P,f)
 out['even' if D%2==0 else 'odd']+=1;out['max_order']=max(out['max_order'],len(G));out['max_diameter']=max(out['max_diameter'],D);out['max_feedback_number']=max(out['max_feedback_number'],t);out['multiple_feedback_cases']+=t>=2;out['switches']+=t
out.update(status='PASS_FINITE_CONTROLS_ONLY',seconds=time.monotonic()-st);print(json.dumps(out,indent=2))
