"""Author exact structural/certificate check for the separate unreviewed candidate."""
import functools,itertools,json,time
from pathlib import Path
import networkx as nx
from control_common import invariants,residue

def check(G,P,exact_f=None):
 D=len(P)-1;k=(D+1)//2;n=len(G);R=set(G)-set(P);idx={v:i for i,v in enumerate(P)}
 assert not G.subgraph(R).number_of_edges()
 for x in R:
  J=sorted(idx[y] for y in G[x]);assert 1<=len(J)<=2 and (len(J)==1 or J[1]-J[0]==2)
 if D%2==0:
  assert all(idx[y]%2 for x in R for y in G[x])
  U=P[1::2];A=P[:-1:2]
 else:
  O={idx[y] for x in R for y in G[x] if idx[y]%2};E={idx[y] for x in R for y in G[x] if not idx[y]%2}
  assert not O or not E or max(O)<min(E)
  h=(max(O)+1)//2 if O else 0
  U=[P[2*j+1] if j<h else P[2*j] for j in range(k)]
  A=[P[2*j] if j<h else P[2*j+1] for j in range(k)]
 assert len(U)==len(A)==k and not G.subgraph(A).number_of_edges()
 mate=dict(zip(U,A));assert all(G.has_edge(u,mate[u]) for u in U)
 Q=nx.Graph();Q.add_nodes_from(U);common={}
 for u,v in itertools.combinations(U,2):
  C=set(G[u])&set(G[v])
  if len(C)>=2:
   assert abs(idx[u]-idx[v])==2
   Q.add_edge(u,v);common[frozenset([u,v])]=C
 assert nx.is_forest(Q) and max(dict(Q.degree()).values(),default=0)<=2
 for B in nx.biconnected_components(G):
  if len(B)<3:continue
  good=[e for e,C in common.items() if set(B)==set(e)|C]
  assert len(good)==1
  e=good[0];C=common[e];assert G.subgraph(B).number_of_edges()==2*len(C)
 L=nx.max_weight_matching(Q,maxcardinality=True);t=len(L)
 if exact_f is not None:assert exact_f==n-t,(nx.to_graph6_bytes(G,header=False),exact_f,n-t)
 H=G.copy();parts=[];selected=set()
 for u,v in L:
  a,b=mate[u],mate[v];x=next(iter(common[frozenset([u,v])]-set(P)))
  assert len({x,u,v,a,b})==5 and not H.has_edge(u,v) and not H.has_edge(a,b)
  H.remove_edges_from([(u,a),(v,b)]);H.add_edges_from([(u,v),(a,b)])
  parts.extend([[x,u,v],[a,b]]);selected.update([u,v])
 for u in U:
  if u not in selected:parts.append([u,mate[u]])
 assert dict(H.degree())==dict(G.degree())
 V=[v for B in parts for v in B];assert len(V)==len(set(V))
 lower=0
 for B in parts:
  assert all(H.has_edge(u,v) for u,v in itertools.combinations(B,2));lower+=len(B)-1
 assert lower==k+t and residue(G)<=n-k-t
 if n<=12:
  al,_,_=invariants(H);assert al<=n-k-t
 return t

def main():
 st=time.monotonic();out={'scope':'candidate proof author controls, no independent audit','graphs':0,'even':0,'odd':0,'diametral_paths':0,'simultaneous_switches':0,'max_feedback_number':0}
 for G in nx.read_graph6(Path(__file__).with_name('triangle_free_connected_2_to_9.g6')):
  D=nx.diameter(G);k=(D+1)//2
  if len(nx.max_weight_matching(G,maxcardinality=True))!=k:continue
  out['graphs']+=1;out['even' if D%2==0 else 'odd']+=1;_,f,_=invariants(G)
  dist=dict(nx.all_pairs_shortest_path_length(G))
  for u,v in itertools.combinations(G,2):
   if dist[u][v]!=D:continue
   for P in nx.all_shortest_paths(G,u,v):
    t=check(G,P,f);out['diametral_paths']+=1;out['simultaneous_switches']+=t;out['max_feedback_number']=max(out['max_feedback_number'],t)
 out.update(status='PASS_FINITE_CONTROLS_ONLY',seconds=time.monotonic()-st);print(json.dumps(out,indent=2))
if __name__=='__main__':main()
