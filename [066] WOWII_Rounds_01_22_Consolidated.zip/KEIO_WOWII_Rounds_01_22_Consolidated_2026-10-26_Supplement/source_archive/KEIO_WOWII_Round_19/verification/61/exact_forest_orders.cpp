#include <algorithm>
#include <cstdint>
#include <iostream>
#include <vector>
using namespace std;
int main(){int n;while(cin>>n){if(n>24)return 2;vector<uint32_t>a(n);for(auto &x:a)cin>>x;uint32_t lim=1u<<n;vector<uint8_t>F(lim);F[0]=1;int best=0;for(uint32_t S=1;S<lim;S++){uint32_t t=S;while(t){int u=__builtin_ctz(t);t&=t-1;if(__builtin_popcount(a[u]&S)<=1){F[S]=F[S^(1u<<u)];break;}}if(F[S])best=max(best,__builtin_popcount(S));}cout<<best<<'\n';}}
