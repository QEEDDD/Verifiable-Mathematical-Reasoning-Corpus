# Independent audit: h=37 exclusion for WOWII384b

**PASS — an additional high-order exclusion, not a full conjecture closure.**

Pinned author TeX: `b9e29e3c197d68cdb9abf044c30f4e156abbdf2b656012ffd79624ee09db3214`.
Checker: `7c2969b57632439eebc2dce8396ec1853a1dc7b428bd31c248b7abb0778d4429`.
Certificate: `fc5452ed187028d802f100047853fbfaf80c72cb7d4cec8b0bbd1d2beab74327`.
The complete standalone TeX, structural proof, implementation and exact certificate were audited. No proof repair was requested.

## 1. Essential-edge structural argument

Criticality gives k=19, t=39, gamma_2=|L|+18, pairwise distinct high triangle counts at least two, and both low counts. The full-degree rank argument and profile 3^2,4^3,5^4,6^5,7^6,8^7,9^5,10^5 are valid and were independently recomputed.

The primary DGH-PV (2011) Theorem3 states its matching bound for **any graph**, not only connected graphs. Its exact statement was reread in `round_08/source_audit/new_routes/DGH_PV_kdomination2011.txt`; the full proof was already audited in Round17 h40. Thus the essential-edge argument legitimately applies it to G−e even when e is a bridge.

If both endpoints of an essential high-core edge have full degree at least four, deleting it leaves the high set and low set unchanged. Its core matching number drops exactly one: deleting the edge from any maximum matching gives the lower bound mu−1, and essentiality rules out mu. Edge-addition monotonicity gives gamma_2(G)<=gamma_2(G−e), contradicting the matching bound and equality at G. Therefore every essential edge has a full-degree-three endpoint. No triangle-count preservation under edge deletion is needed.

For an essential Q edge uv and its degree-two triangle vertex x, let u be the cubic endpoint. Its third neighbor w must be adjacent to v, because x has only u,v as neighbors and u must lie on at least two triangles. If w were low, it would also have precisely u,v as neighbors. The vertices u,x,w are then a pendant diamond at v. Holding v's cut color fixed, choosing u with v and x,w opposite gives four crossing edges; putting u opposite gives only three. Thus every maximum cut has u,v together and both low vertices good on the other side. The high sides have sizes19 and18, because either high side is omittable and k=19. The side containing x,w can then omit either19 high vertices plus one low or18 high plus both lows, contradicting k=19. Hence w is high. The cubic vertex u has exactly two triangles and therefore rank one and type3.

The local diamond calculation was separately enumerated. Additional atlas controls check the published matching bound on1,252 nonempty small graphs, including358 equality cases. This tiny equality catalog has no essential high-core edge, so it is **not** claimed as nonvacuous evidence for the essential-edge lemma; the universal argument above is decisive.

## 2. Near-perfect matching sampling

The published bound forces a matching of size18. Every matched edge independently chooses neither endpoint with probability1/4, or either particular endpoint with probability3/8. The unmatched singleton is independently selected with probability3/8. Thus every high vertex has marginal3/8 and E|S|=111/8.

Artificial-neighbor sets use full-degree lower bounds; fillers are compensated by selected low neighbors. A matched partner is always included. Asymmetry is allowed. Repairs are deliberately based on artificial support even when actual support is already sufficient. Their simultaneous validity uses only initial selected neighbors and the vertex's own actual matched partner.

For a focal matched pair, the outside colors A,B,C give its two neighborhood-membership bits. The actual unmatched vertex is explicitly included as a singleton of any available color, or color zero. Removing it from the corresponding population leaves paired external vertices. The six nonzero edge counts plus zero partners cover every actual external matching. Unlimited zero fillers only enlarge the domain, safely. The singleton's independent generating factor is (5+3x^iy^j)/8; each external matching edge contributes (2+3x^iy^j+3x^i'y^j')/8. The focal pair is independent of those choices.

For the unmatched focal vertex, j matching edges containing two of its artificial neighbors contribute (2+6x)/8 each; the other marked neighbors contribute (5+3x)/8. Multiplying the probability of support at most one by its independent unselected probability5/8 is correct. The common additive zeta bounds the unmatched correction regardless of its rank.

## 3. Low-triangle cases and the 5/32 repair

The P/Q dichotomy is exhaustive because a triangle with no high root would be the whole connected component. In P, omitting one private low vertex when its root was initially selected is safe and saves3/8.

For Q, if a maximum matching avoids uv, the roots belong to independent matching choices or one is the singleton. Their joint initial selection probability is9/64. Omitting x on that event cannot harm any unselected high vertex.

If uv is essential, use its cubic root u and the proved high common neighbor w. Replace the generic repair **only on uv**:

- If neither root is selected and w is selected, leave both roots out and keep x; each has two selected neighbors x,w.
- If neither root nor w is selected, select both roots and omit x; net repair cost1.
- If exactly one root is selected, add the other and omit x; net repair cost0.

Both roots cannot initially be selected under this sampler. The omitted low x has only these two roots as neighbors. Other repair guarantees use initial selected vertices and their own matching partners, never later generic additions at uv. Hence replacing this pair's repair preserves all other guarantees, including compensated artificial supports. Since w is on another matching edge or is the singleton, its selection is independent of uv, and the net repair expectation is exactly (1/4)(5/8)=5/32.

It is legitimate to remove this pair's **potential bound** from the summed generic expectation and replace it by5/32; no independence between different pair costs is assumed. Type(u)=3, while the other potential is at least the minimum of the eight entries. The resulting bound is therefore uniform.

## 4. Independent exact arithmetic and actual-graph tests

`check_independent.py` uses a recursive colored-pair removal enumerator rather than the author's six nested count loops. It calculates probabilities via low-degree univariate/bivariate coefficients and the identity

W=[5P(X=0)+2P(X=1)+5P(Y=0)+2P(Y=1)−2P(0,1)−2P(1,0)−2P(1,1)]/8,

rather than the author's capped nine-state formula. Unmatched costs are independently evaluated by a direct binomial probability formula for support zero or one.

- All **37,022 patterns**, **36 pair maxima**, and **32 unmatched inequalities** pass. Every maximum and unmatched value agrees with the author certificate.
- Direct enumeration checks **1,519 distinct small patterns** over **587,070 sampling outcomes**.
- **1,280 actual graphs** and **230,400 complete matching/singleton outcomes** directly validate generic repair, P omissions, avoidable-Q omissions, and the cubic-Q replacement. Compensated asymmetric artificial sets are included.
- **320 physical cubic-Q graphs** independently give exact net pair expectation5/32, including w matched elsewhere and w as the singleton. These controls test the direct repair and need not assume that uv is essential in the small test graph.
- Generic expectation bound: **18090352599/1000000000**.
- Strict margins below18:
  - P: **284647401/1000000000**;
  - avoidable Q: **50272401/1000000000**;
  - cubic/essential Q: **12757487/100000000**.
- The author checker was rerun from the frozen snapshot and reproduces its certificate byte-for-byte.

The finite integer/rational table is a proof dependency; the small physical and atlas controls are not substitutes for the universal argument.

## Scope and consolidation

Every connected graph with h=37 satisfies384b. Combined with earlier exclusions, the residual high orders are11–33,35. The separate order39 audit gives a representative order bound. Neither result is an exhaustive residual search or a full closure. The standalone author TeX was read in full and matches the accepted proof; parent owns final formatting and visual QA.
