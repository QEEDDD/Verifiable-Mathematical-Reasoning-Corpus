# Final author TeX consolidation

**PASS.** `round_20/twodomination/paired_sampling_h37.tex`, SHA-256 `790789191ef20ed7e11e92a7ea6d53373f8af576253304a5891066bddf784879`, matches the fully audited mathematics. The final diff changes only completed-audit status wording. Checker differences, if present, change only the output scope string; certificate data are identical after removing that string. Original and final snapshots and exact diffs are retained. Parent owns delivery copying and PDF visual QA.

Final delivery `deliverables/384b_h37.tex`, SHA-256 `790789191ef20ed7e11e92a7ea6d53373f8af576253304a5891066bddf784879`, is byte-identical to the final author source. PASS. Parent owns PDF visual QA.
