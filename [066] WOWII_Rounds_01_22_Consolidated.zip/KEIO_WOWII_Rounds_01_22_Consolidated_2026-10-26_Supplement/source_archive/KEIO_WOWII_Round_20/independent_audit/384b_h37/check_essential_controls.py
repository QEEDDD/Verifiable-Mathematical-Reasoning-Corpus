"""Finite corroboration of the universal essential-edge implication.
The packaged graph list was extracted from NetworkX's graph atlas; the
checker below uses only the standard library. The proof does not need it.
"""
from functools import lru_cache
from itertools import combinations,product
from pathlib import Path
from collections import Counter
import json
R=Path(__file__).resolve().parent;counts=Counter()
def matching(A):
 @lru_cache(None)
 def rec(S):
  if not S:return 0
  b=S&-S;u=b.bit_length()-1;T=S^b;best=rec(T)
  for v in range(len(A)):
   if A[u]>>v&1 and T>>v&1:best=max(best,1+rec(T^(1<<v)))
  return best
 return rec((1<<len(A))-1)
for A in json.loads((R/'atlas_control_graphs.json').read_text()):
 n=len(A);H=[u for u in range(n) if A[u].bit_count()>=3];L=n-len(H)
 B=[sum(1<<j for j,v in enumerate(H) if A[u]>>v&1) for u in H];mu=matching(B)
 k=max(S.bit_count() for S in range(1<<n) if all(not(S>>u&1) or (A[u]&~S).bit_count()>=2 for u in range(n)))
 gamma=n-k;assert gamma<=mu+L;counts['graphs']+=1
 if gamma==mu+L:
  counts['matching_bound_tight']+=1
  for i,j in combinations(range(len(H)),2):
   if B[i]>>j&1:
    C=B.copy();C[i]&=~(1<<j);C[j]&=~(1<<i)
    if matching(C)<mu:
     assert min(A[H[i]].bit_count(),A[H[j]].bit_count())==3;counts['essential_edges_in_tight_graphs']+=1
# Exact pendant-diamond cut contribution with v fixed to0.
maxima={}
for U in (0,1):
 vals=[]
 for X,W in product((0,1),repeat=2):
  C=[U,0,X,W];E=[(0,1),(0,2),(0,3),(1,2),(1,3)];cross=sum(C[u]!=C[v] for u,v in E);vals.append(cross)
 maxima[str(U)]=max(vals)
assert maxima=={'0':4,'1':3}
print(json.dumps(dict(status='PASS',**counts,diamond_cut_maxima_given_u=maxima,scope='Finite diagnostic support only; essential-edge and diamond arguments are proved universally in the audited manuscript.'),indent=2))
