"""Independent colored-pair recursion, probability coefficients, and direct
cubic-root/low-omission repairs for h37. Standard library only."""
from functools import lru_cache
from itertools import product,combinations
from collections import Counter
from fractions import Fraction as F
from pathlib import Path
import json,random,time
ROOT=Path(__file__).resolve().parent;start=time.monotonic()
E=((0,1),(0,2),(0,3),(1,1),(1,2),(1,3),(2,2),(2,3),(3,3));loc={e:i for i,e in enumerate(E)};COL=((0,0),(1,0),(0,1),(1,1))
W=dict(zip(range(3,11),(341385154,248550156,177279951,125316621,88287832,61517419,43816963,32792315)));Z=107833599;DEN=10**9
@lru_cache(None)
def patterns(pop):
 if not any(pop):return frozenset({(0,)*9})
 first=next(i+1 for i,x in enumerate(pop) if x);left=list(pop);left[first-1]-=1;out=set()
 for mate in range(4):
  if mate and not left[mate-1]:continue
  rest=left.copy()
  if mate:rest[mate-1]-=1
  idx=loc[tuple(sorted((first,mate)))]
  for P in patterns(tuple(rest)):
   Q=list(P);Q[idx]+=1;out.add(tuple(Q))
 return frozenset(out)
def edges(P):return [e for e,n in zip(E,P) for _ in range(n)]
def paircost(P,single):
 px=[1,0];py=[1,0];joint={(0,0):1};den=1
 factors=[[(0,0,2),(*COL[z],3),(*COL[w],3)] for z,w in edges(P)]+[[(0,0,5),(*COL[single],3)]]
 for factor in factors:
  dx=Counter();dy=Counter();di=Counter()
  for x,y,m in factor:dx[x]+=m;dy[y]+=m;di[x,y]+=m
  px=[px[0]*dx[0],px[1]*dx[0]+px[0]*dx[1]];py=[py[0]*dy[0],py[1]*dy[0]+py[0]*dy[1]]
  nxt=Counter()
  for (x,y),weight in joint.items():
   for (u,v),mult in di.items():
    if x+u<=1 and y+v<=1:nxt[x+u,y+v]+=weight*mult
  joint=nxt;den*=8
 return F(5*px[0]+2*px[1]+5*py[0]+2*py[1]-2*(joint.get((0,1),0)+joint.get((1,0),0)+joint.get((1,1),0)),8*den)
def direct(P,single):
 ed=edges(P);num=samples=0
 for choices in product(range(3),repeat=len(ed)+1):
  for sing in range(2):
   x,y=COL[single] if sing else (0,0);weight=3 if sing else 5
   for (z,w),choice in zip(ed,choices[1:]):
    weight*=2 if choice==0 else 3
    if choice:a,b=COL[z if choice==1 else w];x+=a;y+=b
   own=choices[0];weight*=2 if own==0 else 3;sel=[own==1,own==2];sup=[x+sel[1],y+sel[0]];bad=[not sel[i] and sup[i]<2 for i in range(2)]
   repairs=sum(bad)
   if all(bad) and max(sup)>0:repairs=1
   num+=weight*repairs;samples+=1
 return F(num,8**(len(ed)+2)),samples
rows=[];pattern_count=0;controls=set();sample_count=0;minslack=None
for a in range(3,11):
 for b in range(a,11):
  maximum=F(-1);count=0
  for c in range(min(a,b)):
   pop=(a-1-c,b-1-c,c)
   for single in range(4):
    if single and pop[single-1]==0:continue
    rest=list(pop)
    if single:rest[single-1]-=1
    for P in sorted(patterns(tuple(rest))):
     val=paircost(P,single);slack=F(W[a]+W[b],DEN)-val;assert slack>=0
     minslack=slack if minslack is None else min(minslack,slack);count+=1;maximum=max(maximum,val)
     if sum(P)<=4 and (P,single) not in controls:
      v,n=direct(P,single);assert val==v;controls.add((P,single));sample_count+=n
  pattern_count+=count;rows.append(dict(a=a,b=b,patterns=count,maximum=str(maximum)))
assert pattern_count==37022
unmatched=[]
for a in range(3,11):
 values=[]
 for j in range(a//2+1):
  l=a-2*j;P0=F(1,4)**j*F(5,8)**l
  P1=(j*F(3,4)*F(1,4)**(j-1)*F(5,8)**l if j else 0)+(l*F(3,8)*F(5,8)**(l-1)*F(1,4)**j if l else 0)
  val=F(5,8)*(P0+P1);assert val<=F(W[a]+Z,DEN);values.append(str(val))
 unmatched.append(dict(a=a,values=values))
profile=[min(d for d in range(3,37) if d*(d-1)>=2*(i+1) and d*(d-2)>=3*i+2-37) for i in range(1,38)]
B=F(111,8)+sum(F(W[a],DEN) for a in profile)+F(Z,DEN)
upper={'P':B-F(3,8),'Q_avoidable':B-F(9,64),'Q_cubic':B-F(W[3]+min(W.values()),DEN)+F(5,32)}
assert all(v<18 for v in upper.values())
author=json.loads((ROOT/'snapshots/paired_sampling_h37_certificate.json').read_text())
for r,a in zip(rows,author['pair_rows']):assert all(r[k]==a[k] for k in r)
for r,a in zip(unmatched,author['unmatched_checks']):assert r['a']==a['a'] and r['values']==a['costs_by_double_neighbor_pairs']
assert str(B)==author['generic_high_cost']

# Actual graph tests with near-perfect matching and independent singleton.
def edge(A,u,v):A[u]|=1<<v;A[v]|=1<<u
def add(A,ns):
 v=len(A);A.append(0)
 for u in ns:edge(A,u,v)
 return v
rng=random.Random(2037);physical=Counter();netchecks=0
for h in (5,7,9,11):
 for rep in range(80):
  for case in ('generic','P','Q_avoidable','Q_cubic'):
   A=[0]*h
   for u in range(0,h-1,2):edge(A,u,u+1)
   for u,v in combinations(range(h),2):
    if case=='Q_cubic' and u==0:continue
    if rng.randrange(5)==0:edge(A,u,v)
   x=None;root=0;w=2 if rep%2 else h-1
   if case=='P':x=add(A,[0]);add(A,[0,x])
   if case=='Q_avoidable':edge(A,0,2);x=add(A,[0,2])
   if case=='Q_cubic':edge(A,0,w);edge(A,1,w);x=add(A,[0,1])
   # Connect all high vertices without changing the special root's degree.
   for u in range(2,h):add(A,[1,u])
   for u in range(h):
    while A[u].bit_count()<3:add(A,[u,1 if u!=1 else 2])
   if case=='Q_cubic':assert A[0].bit_count()==3
   HIGH=(1<<h)-1;LOW=((1<<len(A))-1)^HIGH;art=[];types=[]
   for u in range(h):
    a=min(h-1,10,A[u].bit_count());types.append(a);mate=u^1 if u<h-1 else None
    ns=[v for v in range(h) if A[u]>>v&1 and v!=mate];rng.shuffle(ns)
    chosen=(([mate] if mate is not None else [])+ns)[:a];fill=[v for v in range(h) if v!=u and v not in chosen];rng.shuffle(fill);chosen+=fill[:a-len(chosen)]
    art.append(sum(1<<v for v in chosen));assert len(chosen)==a
   total=specialnum=0
   for choices in product(range(3),repeat=h//2):
    for single in range(2):
     S=sum(1<<(2*i+z-1) for i,z in enumerate(choices) if z)|((1<<(h-1)) if single else 0)
     weight=(3 if single else 5)
     for z in choices:weight*=2 if z==0 else 3
     D=S|LOW;sup=[(art[u]&S).bit_count() for u in range(h)]
     assert all((A[u]&D).bit_count()>=sup[u] for u in range(h))
     for u in range(0,h-1,2):
      v=u+1
      if case=='Q_cubic' and u==0:continue
      bad=[not(S>>u&1) and sup[u]<2,not(S>>v&1) and sup[v]<2]
      if all(bad) and max(sup[u],sup[v])>0:D|=1<<(u if sup[u]==0 else v)
      else:
       if bad[0]:D|=1<<u
       if bad[1]:D|=1<<v
     if not single and sup[-1]<2:D|=1<<(h-1)
     if case=='P' and S&1:D&=~(1<<x)
     if case=='Q_avoidable' and S&1 and S&4:D&=~(1<<x)
     if case=='Q_cubic':
      if S&3 or not(S>>w&1):D|=3;D&=~(1<<x)
      net=((D&3).bit_count()-(S&3).bit_count())-(not(D>>x&1));specialnum+=weight*net
     assert all(D>>u&1 or (A[u]&D).bit_count()>=2 for u in range(len(A)))
     total+=weight*((D&HIGH).bit_count()-(len(A)-h-(D&LOW).bit_count()));physical['outcomes']+=1
   den=8**(h//2+1);bound=F(3*h,8)+sum(F(W[a],DEN) for a in types)+F(Z,DEN)
   if case=='P':bound-=F(3,8)
   if case=='Q_avoidable':bound-=F(9,64)
   if case=='Q_cubic':
    bound-=F(W[types[0]]+W[types[1]],DEN);bound+=F(5,32);assert F(specialnum,den)==F(5,32);netchecks+=1
   assert F(total,den)<=bound
   physical[case]+=1;physical['graphs']+=1
print(json.dumps(dict(status='PASS',color_patterns=pattern_count,type_pairs=len(rows),minimum_slack=str(minslack),unmatched_inequalities=sum(len(r['values']) for r in unmatched),direct_distinct_patterns=len(controls),direct_sampling_outcomes=sample_count,profile=dict(Counter(profile)),generic_bound=str(B),upper_bounds={k:str(v) for k,v in upper.items()},strict_margins={k:str(18-v) for k,v in upper.items()},physical_controls=dict(physical),exact_cubic_net_cost_checks=netchecks,pair_rows=rows,unmatched=unmatched,seconds=time.monotonic()-start),indent=2))
