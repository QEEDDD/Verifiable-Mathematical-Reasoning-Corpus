#!/usr/bin/env python3
"""Exact certificate: near-perfect matching sampling at p=3/4, singleton3/8."""
from collections import Counter
from fractions import Fraction as F
from itertools import product
from math import comb
from pathlib import Path
import json
COL={0:(0,0),1:(1,0),2:(0,1),3:(1,1)}
LAMBDA={3:341385154,4:248550156,5:177279951,6:125316621,
        7:88287832,8:61517419,9:43816963,10:32792315}
ZETA=107833599;DEN=10**9

def patterns(na,nb,nc,zero_limit=None):
 for aa in range(na//2+1):
  for ab in range(min(na-2*aa,nb)+1):
   for ac in range(min(na-2*aa-ab,nc)+1):
    for bb in range((nb-ab)//2+1):
     for bc in range(min(nb-ab-2*bb,nc-ac)+1):
      for cc in range((nc-ac-bc)//2+1):
       sa=na-2*aa-ab-ac;sb=nb-2*bb-ab-bc;sc=nc-2*cc-ac-bc;singles=sa+sb+sc
       if zero_limit is not None and (singles>zero_limit or (zero_limit-singles)%2):continue
       ed=[(0,1,sa),(0,2,sb),(0,3,sc),(1,1,aa),(1,2,ab),(1,3,ac),(2,2,bb),(2,3,bc),(3,3,cc)]
       yield tuple((x,y,n) for x,y,n in ed if n)

def distribution(edges,singleton):
 state={(0,0):1};den=1
 for x,y,m in edges:
  for _ in range(m):
   nxt=Counter()
   for (i,j),v in state.items():
    nxt[i,j]+=2*v
    for color in (x,y):
     dx,dy=COL[color];nxt[min(2,i+dx),min(2,j+dy)]+=3*v
   state=dict(nxt);den*=8
 # A zero singleton is harmless; dropping its factor preserves probability1.
 if singleton:
  nxt=Counter();dx,dy=COL[singleton]
  for (i,j),v in state.items():
   nxt[i,j]+=5*v;nxt[min(2,i+dx),min(2,j+dy)]+=3*v
  state=dict(nxt);den*=8
 return state,den

def pair_cost(edges,singleton):
 state,den=distribution(edges,singleton)
 num=sum(v*(2*(2 if i==j==0 else 0 if i==j==2 else 1)+3*(i==0)+3*(j==0)) for (i,j),v in state.items())
 return F(num,8*den)

def direct_cost(edges,singleton):
 ed=[(x,y) for x,y,n in edges for _ in range(n)];out=0
 for choices in product(range(3),repeat=len(ed)+1):
  for single in range(2):
   weight=5 if single==0 else 3;x=y=0
   if single:dx,dy=COL[singleton];x+=dx;y+=dy
   for (a,b),choice in zip(ed,choices[1:]):
    if choice==0:weight*=2
    else:
     weight*=3;dx,dy=COL[a if choice==1 else b];x+=dx;y+=dy
   own=choices[0]
   if own==0:weight*=2;cost=2 if x==y==0 else 0 if x>=2 and y>=2 else 1
   else:weight*=3;cost=int(y==0) if own==1 else int(x==0)
   out+=weight*cost
 return F(out,8**(len(ed)+2))

rows=[];npatterns=0
for a in range(3,11):
 for b in range(a,11):
  worst=F(-1);arg=None;count=0
  for c in range(min(a,b)):
   pop={0:None,1:a-1-c,2:b-1-c,3:c}
   for color in range(4):
    if color and not pop[color]:continue
    na=pop[1]-(color==1);nb=pop[2]-(color==2);nc=pop[3]-(color==3)
    for edges in patterns(na,nb,nc):
     value=pair_cost(edges,color)
     assert value<=F(LAMBDA[a]+LAMBDA[b],DEN),(a,b,c,color,value)
     count+=1
     if value>worst:worst=value;arg=dict(common=c,singleton_color=color,edges=edges)
  npatterns+=count
  rows.append(dict(a=a,b=b,patterns=count,maximum=str(worst),attaining=arg,
                   potential_slack=str(F(LAMBDA[a]+LAMBDA[b],DEN)-worst)))
unmatched=[]
for a in range(3,11):
 vals=[]
 for j in range(a//2+1):
  # j matching edges contain two of its artificial neighbors; all other
  # marked vertices occur singly on matching edges.
  state,den=distribution(((1,1,j),(0,1,a-2*j)),0)
  value=F(5,8)*sum(F(v,den) for (i,k),v in state.items() if i<=1)
  assert value<=F(LAMBDA[a]+ZETA,DEN)
  vals.append(str(value))
 unmatched.append(dict(a=a,costs_by_double_neighbor_pairs=vals))
# Direct finite outcome controls on small feasible pairings.
controls=outcomes=0
for h in (5,7,9):
 for a in range(3,min(5,h-1)+1):
  for b in range(a,min(5,h-1)+1):
   for c in range(max(0,a+b-h),min(a,b)):
    pop={0:h-a-b+c,1:a-1-c,2:b-1-c,3:c}
    for color in range(4):
     if not pop[color]:continue
     for edges in patterns(pop[1]-(color==1),pop[2]-(color==2),pop[3]-(color==3),pop[0]-(color==0)):
      assert pair_cost(edges,color)==direct_cost(edges,color)
      controls+=1;outcomes+=2*3**(sum(n for x,y,n in edges)+1)
h=37
profile=[next(d for d in range(3,h) if comb(d,2)>=i+1 and d*(d-2)>=3*i+2-h) for i in range(1,h+1)]
ct=Counter(profile)
base=F(3*h,8)+sum(ct[a]*F(LAMBDA[a],DEN) for a in ct)+F(ZETA,DEN)
P=base-F(3,8)
Q_avoidable=base-F(9,64)
Q_essential=base-F(LAMBDA[3]+min(LAMBDA.values()),DEN)+F(5,32)
assert max(P,Q_avoidable,Q_essential)<18
result=dict(scope='Independently audited exact h37 matched-sampling arithmetic.',h=h,
 profile_multiplicities=dict(ct),potential_denominator=DEN,potentials=LAMBDA,zeta=ZETA,
 type_pairs=len(rows),color_pair_patterns=npatterns,direct_controls=controls,direct_sampling_outcomes=outcomes,
 generic_high_cost=str(base),generic_high_cost_decimal=float(base),
 P_upper=str(P),P_margin=str(18-P),Q_avoidable_upper=str(Q_avoidable),Q_avoidable_margin=str(18-Q_avoidable),
 Q_essential_upper=str(Q_essential),Q_essential_margin=str(18-Q_essential),
 unmatched_checks=unmatched,pair_rows=rows)
Path(__file__).with_name('paired_sampling_h37_certificate.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('pair_rows','unmatched_checks')},indent=2))
