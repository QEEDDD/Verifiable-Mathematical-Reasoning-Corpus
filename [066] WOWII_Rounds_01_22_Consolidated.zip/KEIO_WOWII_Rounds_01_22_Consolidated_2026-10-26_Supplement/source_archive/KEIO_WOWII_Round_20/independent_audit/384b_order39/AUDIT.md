# Independent audit: counterexample representative order at most39

**PASS, including the previously unaddressed h=25 boundary.** This is a partial reduction, not a resolution of WOWII384b.

Pinned author TeX: `38f1d0528497ffd9feba30e7e0da9d0bf2fc289368fc9dc18a1b6f053064a44a`.
Checker: `8680b5f250b9c08705cbda52fa40fd90d7875d62cb2d727c08d0c9762c2c89cb`.
Rational input: `e7a811832f7e363892145cd91f56fc258188a96a970d46e1d60a62058d4372e0`.
All are snapshotted. The full standalone TeX was read; no repair was required.

## Universal reduction and dependencies

The argument explicitly uses the audited Round9 low-degree stability theorem, the audited Round16 one-leaf representative reduction, prior high-order exclusions, and the newly audited h37 theorem. These now leave h11–33,35. The previous order40 argument and its dependency review are at `round_19/independent_audit/384b_order40/AUDIT.md`.

In the trimmed representative, at least n2−1 degree-two vertices are independent and hence omittable; thus n2<=ceil(h/2)+1. With at most one leaf, n<=h+ceil(h/2)+2. This gives n<=38 only for h<=24. The manuscript correctly does **not** reuse the old h<=25/order40 bound to claim order39.

For25<=h<=35 and n>=40, there are at least39−h degree-two vertices. Under uniform13-high-vertex sampling, each independent low vertex with two high neighbors can be omitted when both are sampled, with probability q=156/[h(h−1)]. All high vertices losing a selected low neighbor were initially selected, so these omissions are simultaneously safe after conservative high repair.

If the low graph has its unique possible edge, select a degree-two endpoint x. It has exactly one high neighbor and can be omitted when that neighbor is sampled, while the other low endpoint remains selected. At most two degree-two vertices lie on the low edge. Hence the total low credit is at least p+(37−h)q, where p=13/h. Since h>=25, p>=2q; **at h=25 equality holds**. This credit therefore dominates(39−h)q. Pendant triangles, nontriangle low edges and leaf–degree-two edges are all covered. No independence between low omission events is assumed.

The fixed-size high repair formula, full-degree profile, perfect/near-perfect matching, and unmatched zeta correction are exactly those already audited for order40. For h26–35, the input potentials are unchanged and were compared entry-for-entry with the pinned order40 input; only one q of low credit is removed. At h25, the new all-zero potentials are valid because pair savings are nonnegative. Ordinary alteration already provides the necessary strict margin.

## Independent exact checks

The independent checker reconstructs all profiles, evaluates focal badness by conditional hypergeometric probabilities, derives pair savings from support categories, verifies each rational inequality, then compares the exact margins. It imports no author code.

- All **1,748 pair inequalities** and **11 strict margins** for h25–35 pass.
- The h25 boundary is explicitly checked:
  - profile3^2,4^3,5^4,6^5,7^5,8^4,9^2;
  - all beta and zeta entries zero;
  - B25=**18383017/1300075**;
  - both independent and low-edge credit = **91/25**;
  - strict margin = **1950156/1300075**.
- The smallest margin is at h35: **14875937/369084450**, still positive.
- The h26–35 weights and types agree exactly with the audited previous table copied into `snapshots/prior_order40_dual_input.json`.
- Fresh seeded physical controls cover **1,600 actual graphs**, **384,000 initial high subsets**, and **13,600 exact low-omission expectations**. They include independent low graphs, pendant triangles, nontriangle low edges, and leaf–degree-two edges; every final set is directly checked to be 2-dominating.
- The author checker was rerun from the snapshot and reproduces the supplied certificate byte-for-byte.

The positive expected-size margins contradict critical gamma_2=|L|+floor(h/2) whenever the reduced representative has n>=40. Thus some connected counterexample representative has order at most39 if any counterexample exists. This is not an upper bound on every original counterexample and does not assert an exhaustive order39 search.

Parent owns delivery formatting and PDF visual QA. No full solved-conjecture increment or worldwide-priority claim is certified by this audit.
