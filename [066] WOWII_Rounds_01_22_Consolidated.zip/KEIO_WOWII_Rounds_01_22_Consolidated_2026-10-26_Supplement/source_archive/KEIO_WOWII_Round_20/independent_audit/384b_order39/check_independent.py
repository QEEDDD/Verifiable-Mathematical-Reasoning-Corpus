"""Independent exact order39 margins and simultaneous actual-graph repairs."""
from math import comb
from fractions import Fraction as F
from collections import Counter
from itertools import combinations
from pathlib import Path
import json,random,time
ROOT=Path(__file__).resolve().parent;start=time.monotonic()
def C(n,k):return comb(n,k) if 0<=k<=n else 0
inputs=json.loads((ROOT/'snapshots/order39_dual_input.json').read_text());rows=[];nchecks=0
for row in inputs:
 h=row['h'];s=13;D=C(h,s);odd=h%2
 profile=([3] if not odd else [])+[min(d for d in range(3,h) if d*(d-1)>=2*(i+1) and d*(d-2)>=3*i+2-h) for i in range(1,h+odd)]
 counts=Counter(profile);types=sorted(counts);assert types==row['types']
 beta=dict(zip(types,map(F,row['weights'])));zeta=F(row['weights'][-1]) if odd else F(0)
 assert len(row['weights'])==len(types)+odd
 if odd:assert all(zeta>=b for b in beta.values())
 bad={}
 for a in types:
  # Condition on the focal vertex not sampled, then use hypergeometric support.
  bad[a]=F(h-s,h)*F(C(h-1-a,s)+a*C(h-1-a,s-1),C(h-1,s))
 minslack=None;count=0
 for a in types:
  for b in types:
   if a>b:continue
   for c in range(max(0,a+b-h),min(a,b)):
    left=a-1-c;right=b-1-c;neutral=h-a-b+c
    # Direct low support categories: one selected common, left only,
    # right only, or one selected in each exclusive set.
    saving=(c+left+right)*C(neutral,s-1)+left*right*C(neutral,s-2)
    slack=saving-beta[a]-beta[b];assert slack>=0;count+=1
    minslack=slack if minslack is None else min(minslack,slack)
 B=F(s)+sum(counts[a]*(bad[a]-beta[a]/D) for a in types)+zeta/D
 p=F(s,h);q=F(s*(s-1),h*(h-1));assert p>=2*q
 low=(39-h)*q;lowedge=p+(37-h)*q;assert lowedge>=low
 U=B-low;margin=F(h//2)-U;assert margin>0
 assert B==F(row['baseline']) and low==F(row['credit']) and U==F(row['upper']) and margin==F(row['margin'])
 rows.append(dict(h=h,profile=dict(counts),pair_checks=count,min_slack=str(minslack),high_bound=str(B),independent_credit=str(low),lowedge_credit=str(lowedge),margin=str(margin)));nchecks+=count
prior={r['h']:r for r in json.loads((ROOT/'snapshots/prior_order40_dual_input.json').read_text())}
assert all(r['weights']==prior[r['h']]['weights'] and r['types']==prior[r['h']]['types'] for r in inputs if r['h']>=26)
assert all(F(x)==0 for x in inputs[0]['weights']) and rows[0]['h']==25 and rows[0]['high_bound']=='18383017/1300075' and rows[0]['margin']=='1950156/1300075'
assert [r['h'] for r in rows]==list(range(25,36)) and nchecks==1748
assert all(h+(h+1)//2+2<=39 for h in range(11,25))

# Simultaneous low omission on actual graphs. The artificial supports are
# deliberately conservative and may be asymmetric, with compensated fillers.
def edge(A,u,v):A[u]|=1<<v;A[v]|=1<<u
def add(A,ns):
 v=len(A);A.append(0)
 for u in ns:edge(A,u,v)
 return v
rng=random.Random(203939);physical=Counter();omission_expectations=0
for h in (6,7,8,9):
 for rep in range(100):
  H=[0]*h
  for u in range(0,h-1,2):edge(H,u,u+1)
  for u,v in combinations(range(h),2):
   if rng.randrange(4)==0:edge(H,u,v)
  for branch in ('independent','pendant_triangle','nontriangle_low_edge','leaf_low_edge'):
   A=H.copy();special=None
   if branch=='pendant_triangle':
    special=add(A,[0]);add(A,[0,special])
   elif branch=='nontriangle_low_edge':
    special=add(A,[0]);add(A,[2,special])
   elif branch=='leaf_low_edge':
    special=add(A,[0]);add(A,[special])
   else:add(A,[0])
   for u in range(1,h):add(A,[0,u])
   for u in range(h):
    while A[u].bit_count()<3:add(A,[u,(u+1)%h])
   ALL=(1<<len(A))-1;HIGH=(1<<h)-1;LOW=ALL^HIGH;art=[]
   for u in range(h):
    a=min(h-1,10,A[u].bit_count());mate=u^1 if u<h-h%2 else None
    actual=[v for v in range(h) if A[u]>>v&1 and v!=mate];rng.shuffle(actual)
    chosen=([mate] if mate is not None else [])+actual
    chosen=chosen[:a];filler=[v for v in range(h) if v!=u and v not in chosen];rng.shuffle(filler)
    chosen+=filler[:a-len(chosen)];art.append(sum(1<<v for v in chosen));assert len(chosen)==a
   lows=[u for u in range(h,len(A)) if A[u].bit_count()==2 and not(A[u]&LOW)]
   omcount=[0]*(h+1)
   for S in range(1<<h):
    D=S|LOW;sup=[(art[u]&S).bit_count() for u in range(h)]
    assert all((A[u]&D).bit_count()>=sup[u] for u in range(h))
    for u in range(0,h-1,2):
     v=u+1;bad=[not(S>>u&1) and sup[u]<2,not(S>>v&1) and sup[v]<2]
     if all(bad) and max(sup[u],sup[v])>0:D|=1<<(u if sup[u]==0 else v)
     else:
      if bad[0]:D|=1<<u
      if bad[1]:D|=1<<v
    if h%2 and not(S>>(h-1)&1) and sup[-1]<2:D|=1<<(h-1)
    omitted=0
    for u in lows:
     if A[u]&S==A[u]:D&=~(1<<u);omitted+=1
    if special is not None and A[special]&S:
     # The special endpoint has exactly one high neighbor.
     assert (A[special]&HIGH).bit_count()==1
     D&=~(1<<special);omitted+=1
    assert all(D>>u&1 or (A[u]&D).bit_count()>=2 for u in range(len(A)))
    omcount[S.bit_count()]+=omitted;physical['initial_sets']+=1
   for s in range(h+1):
    expected=len(lows)*F(s*(s-1),h*(h-1))+(F(s,h) if special is not None else 0)
    assert F(omcount[s],C(h,s))==expected;omission_expectations+=1
   physical[branch]+=1;physical['graphs']+=1
print(json.dumps({'status':'PASS','pair_inequalities':nchecks,'strict_margins':rows,'physical_controls':dict(physical),'exact_low_omission_expectations':omission_expectations,'seconds':time.monotonic()-start,'scope':'Order39 finite arithmetic independently reproduced; finite physical tests corroborate the universal simultaneous-omission proof.'},indent=2))
