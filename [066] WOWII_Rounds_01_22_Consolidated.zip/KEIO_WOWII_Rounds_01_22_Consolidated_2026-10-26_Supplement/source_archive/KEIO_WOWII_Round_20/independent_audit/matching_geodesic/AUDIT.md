# Independent audit: minimum ordinary matching on a diametral path

## Verdict

**PASS for the stated unrestricted-order subclass.** For every finite simple
connected triangle-free graph `G`, with diameter `D` and ordinary matching
number `nu(G)=k=ceil(D/2)`, the candidate proves

`f(G) >= res(G)+k`,

where `f` is the maximum order of an induced forest and `res` is the
Havel–Hakimi residue. This is a **partial result for original WOWII #61**, not
closure of the full conjecture. This audit does not establish publication
priority or worldwide novelty.

Audited source:
`round_19/independence/minimum_matching_geodesic.md`.
Final snapshot SHA256:
`436f04012245c011292f82e7664c6eb3970e0dcb7ce7efa3876be2c402a94ceb`.

The proof was checked analytically independently of the author's finite
controls. The fresh checker here imports no author code and uses no author
catalog. Its finite controls are supporting evidence, not the arbitrary-order
proof. The only residue facts used are the supplied classical facts
`res(H)<=alpha(H)` for every finite simple graph and invariance under a
preserved degree sequence.

## 1. Geodesic restriction and even parity

A path of length `D` has a matching of size `ceil(D/2)=k`. An edge with both
ends outside a fixed diametral path would be disjoint from such a matching,
contradicting `nu(G)=k`. Thus the off-path set `R` is independent. Every
outside vertex has a neighbor on the path, since it is not isolated and has
no neighbor in `R`.

If an outside vertex has neighbors at indices `i<j` with `j-i>2`, replacing
the path segment by its two incident edges gives a shorter walk between the
diametral endpoints, contrary to their distance. Triangle-freeness excludes
index difference one. Hence an outside neighborhood is one path vertex, or
exactly two path vertices whose indices differ by two. In particular, there
cannot be three path neighbors, and all neighbors have one parity.

When `D=2k`, the two subpaths on either side of any even-indexed path vertex
have perfect matchings. Their union is a size-`k` matching leaving exactly
that vertex unmatched. An outside neighbor would extend it. Thus only the
odd vertices can have outside attachments. The proposed `k` supports and
partners are consequently valid; the remaining even endpoint is simply a
pendant vertex at the last support. Every intervening even path vertex is
the unique on-path internal vertex of one consecutive-support link. No
extra edge can be omitted by this description: the path is induced, `R` is
independent, and all its neighborhoods were classified above.

## 2. Odd parity and the bridge

For `D=2k-1`, the path matching pairs indices `(0,1),(2,3),...`. Suppose an
outside even attachment index `e` precedes an outside odd attachment index
`o`. Their outside witnesses are distinct, because an outside vertex cannot
have neighbors of both parities. The path

`x,p_e,p_(e+1),...,p_o,y`

is simple, has unmatched ends, and alternates nonmatching/matching edges,
starting and ending with nonmatching edges. The path segment begins and
ends with matching edges because `e` is even and `o` odd. Toggling these
edges therefore raises the matching cardinality by one. This establishes
the forbidden order without invoking an unproved structural theorem.

All odd attachment indices must precede all even ones. The proposed split
`h` exists, including when either attachment set is empty. At indices below
`2h` the odd vertices are supports, and at indices at least `2h` the even
vertices are supports. Therefore every outside vertex sees only supports,
and each of its two-neighbor attachments is inside one of the two chains.

If `0<h<k`, the boundary edge joins the last left support to the first right
support. There is no other cross-chain edge: path chords are absent, `R` is
independent, and an outside vertex cannot see the two support parities.
Consequently this edge is a bridge. The partners on opposite sides nearest
the boundary are at indices `2h-2` and `2h+1`, a difference of three, so no
partner edge crosses the split. All other partner pairs have the same
parity and are nonadjacent. Empty chains at `h=0,k` cause no exception.

This is a necessary structural description relative to the already fixed
diametral path, not an assertion that arbitrary pendant additions preserve
its prescribed diameter. For example, attaching a new pendant vertex to an
odd-case path endpoint can increase the diameter. The independent generated
controls explicitly avoid that mistake.

## 3. Exact feedback-vertex number, including arbitrary link multiplicity

Each link with `c` internal vertices is exactly `K_(2,c)`. Distinct links
have disjoint internal vertices, even when adjacent links share a support.
The support-chain skeleton (with the optional bridge) is a tree. A simple
cycle cannot traverse two links: doing so would require returning through
a separating support, or traversing a bridge. Thus a link is cyclic exactly
when `c>=2`, and every cycle lies inside one such bad link.

Deleting a vertex cover of the bad-link graph `Q` destroys all cyclic
links. Each component of `Q` is a path, so if it has `ell` edges, both its
minimum vertex-cover size and maximum matching size are `ceil(ell/2)`.
This follows by choosing alternate internal positions for a cover and
alternate edges for a matching; the matching itself proves the cover lower
bound. Summing over components gives a feedback-vertex set of size
`t=nu(Q)`.

**Independent lower bound (simpler than normalization):** take a matching
of `t` bad links. In each choose two distinct internal vertices. The two
supports and these two vertices form a 4-cycle. These `t` cycles are
vertex-disjoint, because the chosen support pairs are disjoint and link
internals belong to only one link. Every feedback-vertex set must meet each
cycle. Thus `tau(G)>=t`, proving `tau(G)=t` and `f(G)=n-t`.

The source's alternative normalization argument is also valid. If no
support of a bad `K_(2,c)` link is deleted, at most one internal vertex may
remain, so at least `c-1>=1` internal vertices were deleted. Restoring those
vertices and instead deleting one support cannot create a cycle in that
link, cannot create a cycle in another link, and never increases the
number deleted. Internal vertices belonging to different links are
disjoint, so successive replacements do not consume one deletion twice.
Deleting a pendant vertex is unnecessary. This proves a support-only
optimum, with no exception at `c=2`, `c>2`, isolated supports, or adjacent
bad links.

## 4. Simultaneous switching and cover certificate

For every edge `uv` in a maximum matching of `Q`, one internal vertex lies
on the original path and at least one additional common neighbor `x` lies
outside it. The original path-matching partners `a,b` are distinct from
each other and from `u,v,x`. The two removed edges `ua,vb` exist. The added
edges `uv,ab` do not: consecutive supports within a chain are at path
index distance two, and all partners form an independent set.

Different selected bad links use disjoint support pairs. The original
matching maps distinct supports to distinct partners, and all these
partners lie on the original path, disjoint from all supports and all
outside witnesses. An outside degree-two witness belongs to a unique
link. Hence the five-vertex switch domains are pairwise disjoint. In
particular, no inserted edge equals another inserted edge, no inserted
edge is later removed, no loop is formed, and the operations commute.
Every affected vertex loses and gains exactly one incident edge. This is
per-vertex degree preservation, not merely equality of the sorted degree
lists.

The `xuv` triangle survives because the switch removes only matched
support-partner edges, never `xu` or `xv`. The new `ab` edge is disjoint from
that triangle. All original matching edges not incident with the `2t`
selected supports survive. Across the entire graph these are disjoint
subgraphs: `t` triangles, `t` partner edges, and `k-2t` old matching edges.
Since `Q` has `k` vertices, `2t<=k`, so the last count cannot be negative.
Any vertex cover therefore has size at least

`2t+t+(k-2t)=k+t`.

Additional edges among these pieces are harmless: this argument uses
vertex-disjoint subgraphs, not induced components. The switched graph is
not required to remain triangle-free, connected, or to retain the old
diameter or matching number. The residue inequality applies to every
finite simple realization, so none of those stronger properties is needed.
Consequently

`res(G)=res(G')<=alpha(G')<=n-k-t=f(G)-k`.

## 5. Boundary audit

- `D=0`: connectedness gives `K1`; `f=res=1`, `k=0`.
- `D=1`: finite simple connected triangle-free graphs of diameter one give
  `K2`; the empty bad-link certificate yields the bound.
- `D=2`, `k=1`: the classification is a star. There are no links and `t=0`.
- No off-path vertices: both parity arguments remain valid. In the odd
  case every `h` is legal; the resulting graph is just the original path.
- Empty odd/even attachment sets: `h=0` or `h=k` is legitimate where
  permitted. A singleton support chain has no links.
- `t=0`, no bad links, or no links: no switches are made; the original
  matching is the required cover certificate.
- `c=2` and arbitrarily large `c`: a bad link always has an outside witness;
  the feedback argument and switch do not assume exactly one such witness.
- Several adjacent bad links: only a matching of them is switched;
  nonselected neighboring links cannot invalidate the certificate.
- Multiple separated bad-link components, and both odd support chains:
  the cover sizes and cycle packings add across components.
- `2t=k`: there are zero unused matching edges, not a missing case.
- The unbounded family is valid for every `k>=1`. At `k=1`, the two pendant
  vertices attached to the one support are distinct, giving `P3`. In
  general every support edge is replaced by two internally disjoint
  two-edge paths, and one pendant is added at each end support. Its
  diameter is `2k`, its support vertex cover has size `k`, and its
  diametral path has a size-`k` matching, so its matching number is `k`.
  Its all-bad `Q` is a path on `k` vertices; hence its feedback number is
  `floor(k/2)`, unbounded with `k`.

No unresolved mathematical repair remains. The author accepted the three
precision edits requested here: explicit finite/simple scope, explicit
link-internal-vertex disjointness, and the `k>=1` / two-distinct-pendants
wording of the example. The simpler disjoint-cycle lower bound above is
available for later TeX consolidation; the audited MD retains its valid
normalization argument.

## 6. Independent computational evidence

Run:

```sh
python check_independent.py
```

Requires Python with NetworkX installed (audited version `3.7`). In this
workspace the existing library was used with
`PYTHONPATH=/tmp/wowii_deps`; no dependency was downloaded or changed.
The exact output is in `independent_results.json`; `run.log` repeats it.

The checker examines all 90 connected triangle-free nonempty graphs in the
built-in atlas through order 7, of which 32 satisfy the hypothesis. For
these it examines every oriented diametral path, every legal odd split,
every maximum bad-link matching, and every possible outside witness for
each selected link. It independently constructs another 301 test graphs,
including both diameter parities, every split boundary through `k=8`, mixed
connector multiplicities, separated bad-link runs, and literal prefixes of
the unbounded family.

Across the combined run:

- 333 eligible graph instances; maximum order 404, maximum feedback number 50;
- 520 chosen/oriented diametral paths and 650 support decompositions;
- 240 graphs with generic exhaustive-subset exact FVS calculations, compared
  with the claimed value across 557 decompositions;
- 682 exact FVS certificates using disjoint 4-cycles and explicit forest
  deletions, including all larger instances;
- 764 simultaneous-switch configurations, containing 1,482 individual
  switches;
- 598 generic exact independence-number computations on switched graphs;
- direct per-vertex degree equality, exact residue equality, and the final
  inequality in every tested certificate.

The large-instance FVS certificates do not assert brute-force enumeration:
they explicitly verify `t` vertex-disjoint cycles and a size-`t` deletion
leaving a forest, independently witnessing both bounds. Neither these
finite instances nor the author's separate tests establish arbitrary order;
the analytic verification above does.
