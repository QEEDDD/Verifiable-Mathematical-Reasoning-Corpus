# Final standalone TeX consolidation audit

**PASS — full text read, no omitted hypothesis or unjustified strengthening.**

Audited file: `round_20/independence/manuscript.tex`.
SHA256: `0fa44736f3dde2fc657f9a4e1ca9cf30724f3e73fbd59903f362dde168dd25a3`.
A byte-identical copy is retained as `manuscript_snapshot.tex`.

The earlier audited MD is unchanged, at SHA256
`436f04012245c011292f82e7664c6eb3970e0dcb7ce7efa3876be2c402a94ceb`.
No additional finite tests were needed or run for this text-only
consolidation; the existing independent checker/results remain applicable.

## Entire-proof comparison

- The theorem, abstract, and scope consistently require finite simple
  connected triangle-free graphs and the **ordinary** matching equality
  `nu(G)=ceil(D/2)`. The conclusion is precisely the previously audited
  half-diameter bound. `f`, feedback-vertex number, vertex-cover number,
  independence number, and Havel–Hakimi residue are distinguished correctly.
- Off-path independence and the singleton/two-neighbor classification are
  fully justified. The even-parity exposed-vertex matching argument is
  retained. The odd-parity augmenting path and permissible split `h` are
  complete, including distinct outside witnesses and empty attachment sets.
- Both support-chain descriptions retain independent matching partners and
  the unique optional bridge. The text correctly warns that this is a
  necessary description relative to the fixed geodesic, not a claim that
  arbitrary pendant additions preserve its diameter.
- The exact FVS proof uses the approved simplification. A vertex cover of
  the bad-link path-union gives the upper bound. A matching of `t` bad links
  yields `t` vertex-disjoint four-cycles because support pairs are disjoint
  and internal vertices belong to unique links. This is a complete lower
  bound, replacing—not weakening—the MD's valid normalization argument.
- Simultaneous switches retain all five distinct vertices, absent inserted
  edges, disjoint switch domains, and per-vertex degree preservation. The
  `t` triangles, `t` new partner edges, and `k-2t` remaining matching edges
  are vertex-disjoint. The text explicitly permits additional edges and
  does not require the switched graph to retain triangle-freeness,
  connectedness, diameter, or its old matching number.
- The final residue/independence/cover chain is unchanged and valid.
  Degeneracies `D=0,1,2`, `t=0`, `h=0,k`, `2t=k`, empty chains and arbitrary
  link multiplicities are preserved. The unbounded family states `k>=1`
  and uses two distinct pendants at `k=1`; its new explicit count `n=3k`
  follows from `k+2(k-1)+2` and is correct. Its claimed diameter, matching
  number, and FVS number match the audited construction. It does not claim
  equality in the main inequality for every member.
- The independent-control summary accurately reports the saved results:
  333 eligible instances, 32 atlas graphs and 301 generated instances,
  maximum order 404 and feedback number 50. Exact small-instance forest
  calculations and large-instance two-sided certificates are distinguished.

## Scope and separate responsibilities

This remains a restricted result for original WOWII #61, not a full closure
for all triangle-free or all connected graphs. Classical residue and
switch inputs are credited, and the final text expressly disclaims any
worldwide novelty/publication-priority certification. Bibliographic
source-priority verification is a separate gate, not supplied by this
proof audit.

No mathematical repair is requested. Compilation, PDF layout, and visual
QA belong to the parent task and are not claimed by this text audit.
