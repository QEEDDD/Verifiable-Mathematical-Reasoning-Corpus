#!/usr/bin/env python3
"""Independent checks. Imports no author code or catalog.

The atlas is NetworkX's built-in graph atlas. Generated families are built
here from raw path/attachment edges. Exact small FVS and independence are
computed generically, not from the proposed support formula. Large FVS
values have explicit disjoint-cycle lower / forest-after-deletion upper
certificates. Finite checks supplement, and do not replace, AUDIT.md.
"""
from collections import Counter
from functools import lru_cache
from itertools import combinations, product
from pathlib import Path
import hashlib
import json
import networkx as nx

OUT = Path(__file__).resolve().parent
COUNT = Counter()
LARGE = []
BOUNDARY = set()

def forest(G):
    return G.number_of_edges() == len(G) - nx.number_connected_components(G)

def residue(G):
    d = sorted((v for _, v in G.degree()), reverse=True)
    while d and d[0]:
        v = d.pop(0)
        assert 0 <= v <= len(d)
        for j in range(v):
            d[j] -= 1
            assert d[j] >= 0
        d.sort(reverse=True)
    return len(d)

def masks(G):
    V = list(G)
    ix = {v:i for i,v in enumerate(V)}
    return [sum(1 << ix[w] for w in G[v]) for v in V]

def exact_alpha(G):
    A = masks(G)
    @lru_cache(None)
    def go(S):
        if not S:
            return 0
        # Maximum current degree branching; zero-degree vertices are free.
        inds = [i for i in range(len(A)) if S >> i & 1]
        free = [i for i in inds if not A[i] & S]
        if free:
            return len(free) + go(S & ~sum(1 << i for i in free))
        v = max(inds, key=lambda i:(A[i] & S).bit_count())
        T = S & ~(1 << v)
        return max(go(T), 1 + go(T & ~A[v]))
    return go((1 << len(A)) - 1)

def exact_fvs(G):
    # Enumerate all deletion subsets by increasing cardinality. A generic
    # union-find cycle check; no support, link, or path formula is used.
    V = list(G)
    E = list(G.edges())
    for q in range(len(V) + 1):
        for deleted in combinations(V, q):
            D = set(deleted)
            parent = {v:v for v in V if v not in D}
            def root(v):
                while parent[v] != v:
                    parent[v] = parent[parent[v]]
                    v = parent[v]
                return v
            ok = True
            for u,v in E:
                if u in D or v in D:
                    continue
                ru,rv = root(u),root(v)
                if ru == rv:
                    ok = False
                    break
                parent[ru] = rv
            if ok:
                return q
    raise AssertionError('unreachable')

def all_max_matchings(G):
    def rec(V):
        if not V:
            yield ()
            return
        v = min(V)
        rest = V - {v}
        yield from rec(rest)
        for w in sorted(set(G[v]) & rest):
            for tail in rec(rest - {w}):
                yield ((v,w),) + tail
    M = list(rec(set(G)))
    t = max(map(len, M), default=0)
    return [m for m in M if len(m) == t]

def min_path_cover(Q):
    C = set()
    for comp in nx.connected_components(Q):
        if len(comp) == 1:
            continue
        start = min(v for v in comp if Q.degree(v) == 1)
        order = [start]
        prev = None
        while True:
            nxt = [v for v in Q[order[-1]] if v != prev]
            if not nxt:
                break
            prev = order[-1]
            order.append(nxt[0])
        assert set(order) == comp
        C.update(order[1::2])
    assert all(u in C or v in C for u,v in Q.edges())
    return C

def audit_path(G, P, nu, D, tau_exact, all_choices=True, preferred_h=None):
    n = len(G)
    k = (D + 1)//2
    COUNT['diametral_path_orientations'] += 1
    if D == 0:
        assert n == 1 and nu == 0 and residue(G) == 1
        BOUNDARY.add('D=0 singleton')
        return 0
    R = set(G) - set(P)
    assert not G.subgraph(R).number_of_edges()
    assert G.subgraph(P).number_of_edges() == D
    ix = {v:i for i,v in enumerate(P)}
    for x in R:
        ids = sorted(ix[v] for v in G[x])
        assert len(ids) in (1,2)
        if len(ids) == 2:
            assert ids[1] - ids[0] == 2
    if not R:
        BOUNDARY.add('R empty')
    O = {ix[v] for x in R for v in G[x] if ix[v] % 2}
    E = {ix[v] for x in R for v in G[x] if not ix[v] % 2}
    if D % 2 == 0:
        assert not E
        variants = [None]
    else:
        assert not any(e < o for e in E for o in O)
        variants = [h for h in range(k+1)
                    if all(o < 2*h for o in O) and all(e >= 2*h for e in E)]
        if not O: BOUNDARY.add('odd O empty')
        if not E: BOUNDARY.add('odd E empty')
        if not all_choices:
            h = preferred_h if preferred_h is not None else variants[0]
            assert h in variants
            variants = [h]
    if k == 1: BOUNDARY.add('k=1')
    for h in variants:
        COUNT['support_decompositions'] += 1
        if h is None:
            U = [P[2*j+1] for j in range(k)]
            A = [P[2*j] for j in range(k)]
            chains = [U]
            bridge = None
        else:
            U = [P[2*j+1] if j < h else P[2*j] for j in range(k)]
            A = [P[2*j] if j < h else P[2*j+1] for j in range(k)]
            chains = [U[:h], U[h:]]
            bridge = (U[h-1], U[h]) if 0 < h < k else None
            BOUNDARY.add('odd h=0' if h == 0 else 'odd h=k' if h == k else 'odd two nonempty chains')
        assert len(set(U + A)) == 2*k
        assert not G.subgraph(A).number_of_edges()
        partner = dict(zip(U,A))
        assert all(G.has_edge(u,a) for u,a in partner.items())
        assert all(set(G[x]) <= set(U) for x in R)
        Q = nx.Graph()
        Q.add_nodes_from(U)
        common = {}
        link_edges = set()
        for chain in chains:
            for u,v in zip(chain, chain[1:]):
                W = set(G[u]) & set(G[v])
                assert W and W.isdisjoint(U)
                assert len(W & set(P)) == 1
                common[frozenset((u,v))] = W
                for x in W:
                    assert set(G[x]) == {u,v}
                    link_edges.update((frozenset((x,u)), frozenset((x,v))))
                if len(W) >= 2:
                    Q.add_edge(u,v)
                    BOUNDARY.add('link c=2' if len(W) == 2 else 'link c>2')
                else:
                    BOUNDARY.add('good link c=1')
        if bridge:
            assert G.has_edge(*bridge)
            assert frozenset(bridge) in {frozenset(e) for e in nx.bridges(G)}
        for u,v in G.edges():
            if frozenset((u,v)) in link_edges:
                continue
            if bridge and frozenset((u,v)) == frozenset(bridge):
                continue
            assert (G.degree(u) == 1 and v in U) or (G.degree(v) == 1 and u in U)
        assert forest(Q) and max((Q.degree(u) for u in Q), default=0) <= 2
        C = min_path_cover(Q)
        t = len(nx.max_weight_matching(Q, maxcardinality=True))
        assert len(C) == t and forest(G.subgraph(set(G)-C))
        if tau_exact is not None:
            assert tau_exact == t
            COUNT['exact_fvs_comparisons'] += 1
        if t == 0: BOUNDARY.add('t=0')
        if t >= 2: BOUNDARY.add('multiple simultaneous switches')
        if 2*t == k: BOUNDARY.add('no unused matching edges')
        if all_choices:
            matchings = all_max_matchings(Q)
        else:
            matchings = [tuple(nx.max_weight_matching(Q, maxcardinality=True))]
        for L in matchings:
            COUNT['maximum_bad_link_matchings'] += 1
            used_cycles = set()
            for u,v in L:
                W = sorted(common[frozenset((u,v))])
                cyc = {u,v,W[0],W[1]}
                assert len(cyc) == 4 and not cyc & used_cycles
                assert all(G.has_edge(a,b) for a,b in ((u,W[0]),(W[0],v),(v,W[1]),(W[1],u)))
                used_cycles |= cyc
            # These t disjoint cycles plus the size-t forest deletion C
            # independently certify the exact FVS value even at large order.
            assert len(L) == t
            COUNT['cycle_forest_exact_certificates'] += 1
            options = [sorted(common[frozenset(e)] & R) for e in L]
            assert all(options)
            if not all_choices:
                options = [q[:1] for q in options]
            for witnesses in product(*options):
                H = G.copy()
                occupied = set()
                selected_supports = set()
                pieces = []
                for (u,v),x in zip(L,witnesses):
                    a,b = partner[u],partner[v]
                    assert len({u,v,a,b,x}) == 5
                    assert not H.has_edge(u,v) and not H.has_edge(a,b)
                    H.remove_edges_from([(u,a),(v,b)])
                    H.add_edges_from([(u,v),(a,b)])
                    pieces += [({u,v,x},2), ({a,b},1)]
                    selected_supports.update((u,v))
                pieces += [({u,partner[u]},1) for u in U if u not in selected_supports]
                for verts,needed in pieces:
                    assert not occupied & verts
                    occupied |= verts
                    assert H.subgraph(verts).number_of_edges() == len(verts)*(len(verts)-1)//2
                assert sum(z for _,z in pieces) == k+t
                assert dict(G.degree()) == dict(H.degree())
                assert residue(G) == residue(H) <= n-k-t
                if n <= 22:
                    assert exact_alpha(H) <= n-k-t
                    COUNT['exact_switched_alpha_checks'] += 1
                COUNT['switch_configurations'] += 1
                COUNT['individual_switches'] += t
        COUNT['max_feedback'] = max(COUNT['max_feedback'],t)
        COUNT['max_order'] = max(COUNT['max_order'],n)
        assert n-t >= residue(G)+k
    return t

def audit_graph(G, paths=None, all_choices=True, preferred_h=None, label=None):
    assert nx.is_connected(G) and not any(nx.triangles(G).values())
    n = len(G)
    D = nx.diameter(G)
    nu = len(nx.max_weight_matching(G,maxcardinality=True))
    assert nu == (D+1)//2
    COUNT['eligible_graphs'] += 1
    tau = exact_fvs(G) if n <= 24 else None
    if tau is not None:
        COUNT['generic_exact_fvs_graphs'] += 1
    if paths is None:
        paths = []
        for u,ds in nx.all_pairs_shortest_path_length(G):
            for v,d in ds.items():
                if d == D:
                    paths.extend(nx.all_shortest_paths(G,u,v))
    fvs_values = set()
    for P in paths:
        assert len(P) == D+1 and nx.shortest_path_length(G,P[0],P[-1]) == D
        fvs_values.add(audit_path(G,P,nu,D,tau,all_choices,preferred_h))
    assert len(fvs_values) == 1
    certified_tau = fvs_values.pop()
    if label:
        LARGE.append(dict(label=label,n=n,diameter=D,matching=nu,residue=residue(G),
                          exact_fvs_by_subsets=tau,certified_fvs=certified_tau,
                          induced_forest_order=n-certified_tau,
                          inequality_slack=n-certified_tau-residue(G)-(D+1)//2))
    return certified_tau

# Every connected triangle-free atlas graph, all oriented diametral paths,
# every valid odd split h, every maximum bad-link matching and extra witness.
for G in nx.graph_atlas_g()[1:]:
    if not nx.is_connected(G) or any(nx.triangles(G).values()):
        continue
    COUNT['connected_trianglefree_atlas_graphs'] += 1
    if len(nx.max_weight_matching(G,maxcardinality=True)) != (nx.diameter(G)+1)//2:
        COUNT['atlas_graphs_outside_scope'] += 1
        continue
    COUNT['eligible_atlas_graphs'] += 1
    before = COUNT['diametral_path_orientations']
    audit_graph(G)
    COUNT['atlas_oriented_diametral_paths'] += COUNT['diametral_path_orientations'] - before

def make_graph(k, odd, h, extras, leaves):
    D = 2*k-1 if odd else 2*k
    G = nx.path_graph(D+1)
    U = [2*j+1 if not odd or j<h else 2*j for j in range(k)]
    chains = [U[:h],U[h:]] if odd else [U]
    links = [(u,v) for c in chains for u,v in zip(c,c[1:])]
    for i,(u,v) in enumerate(links):
        for _ in range(extras(i,len(links))):
            x = len(G)
            G.add_edges_from([(x,u),(x,v)])
    for i,u in enumerate(U):
        if u in (0,D):
            continue  # Endpoint pendants would make the chosen P non-diametral.
        for _ in range(leaves(i,k)):
            G.add_edge(len(G),u)
    return G,list(range(D+1))

# Independently designed patterns: no bad links, one, all, alternating,
# mixed 1/2/3 extra connectors; all split boundaries included.
for k in range(1,9):
    for odd in (False,True):
        hs = range(k+1) if odd else [k]
        for h in hs:
            for pattern in range(5):
                extra = (lambda i,m:0) if pattern == 0 else (lambda i,m:int(i==m//2)) if pattern == 1 else (lambda i,m:1) if pattern == 2 else (lambda i,m:int(i%2==0)) if pattern == 3 else (lambda i,m:i%4)
                leaves = lambda i,k:(i+pattern)%3
                G,P = make_graph(k,odd,h,extra,leaves)
                COUNT['generated_graphs'] += 1
                audit_graph(G,[P],all_choices=(len(G)<=24),preferred_h=h if odd else None)

# Substantially larger arbitrary-order-family prefixes and separated
# bad-link runs, both parity choices, endpoint split and internal bridge.
for k in (12,31,64,101):
    for odd,h in ((False,k),(True,0),(True,k),(True,k//2)):
        for dense in (True,False):
            extra = (lambda i,m:1+(i%3)) if dense else (lambda i,m:(i%5 in (0,1,3)))
            G,P = make_graph(k,odd,h,extra,lambda i,k:int(i in (0,k-1)))
            label = f'k{k}_'+('odd_h'+str(h) if odd else 'even')+('_dense' if dense else '_gapped')
            COUNT['large_generated_graphs'] += 1
            audit_graph(G,[P],all_choices=False,preferred_h=h if odd else None,label=label)

# The paper's literal family, including its single-support degeneracy.
for k in (1,2,3,4,5,8,15,32,100):
    G = nx.Graph()
    G.add_nodes_from(range(k))
    for u in range(k-1):
        for _ in range(2):
            x=len(G)
            G.add_edges_from([(u,x),(u+1,x)])
    G.add_edge(0,len(G))
    G.add_edge(k-1,len(G))
    assert nx.diameter(G)==2*k
    assert len(nx.max_weight_matching(G,maxcardinality=True))==k
    # A fresh shortest diametral path is not the path used by make_graph.
    P=nx.shortest_path(G,len(G)-2,len(G)-1)
    assert audit_graph(G,[P],all_choices=(len(G)<=24),label=f'literal_unbounded_family_k{k}') == k//2
    COUNT['literal_unbounded_family_graphs'] += 1

# Scope controls: familiar cycles do not accidentally satisfy the hypothesis.
for m in range(4,13):
    G=nx.cycle_graph(m)
    assert len(nx.max_weight_matching(G,maxcardinality=True)) > (nx.diameter(G)+1)//2
    COUNT['excluded_cycle_controls'] += 1

R = dict(status='PASS',counts=dict(COUNT),boundaries=sorted(BOUNDARY),large_examples=LARGE,
         networkx_version=nx.__version__,author_code_imported=False,
         proof_snapshot_sha256=hashlib.sha256((OUT/'proof_snapshot.md').read_bytes()).hexdigest(),
         limitations='Atlas completeness only through order 7; generated controls not exhaustive. Arbitrary order follows from the analytic audit, not these finite checks.')
(OUT/'independent_results.json').write_text(json.dumps(R,indent=2)+'\n')
print(json.dumps(R,indent=2))
