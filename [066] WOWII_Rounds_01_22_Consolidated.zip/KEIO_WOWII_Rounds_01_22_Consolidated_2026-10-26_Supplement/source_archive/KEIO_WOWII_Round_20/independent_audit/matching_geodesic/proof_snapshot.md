# Proof candidate: triangle-free graphs with the minimum geodesic matching number

**Status:** complete candidate argument, not independently audited. This is
separate from the apex-forest manuscript. No general triangle-free or full
original WOWII #61 closure is claimed; source-priority review is pending.

Let G be a finite simple connected triangle-free graph, let D be its diameter, and put
`k=ceil(D/2)`. Suppose its **ordinary** matching number is exactly k. We
claim

`f(G) >= r(G)+k`.

Unlike the apex-forest result, this class allows unbounded feedback-vertex
number. The only residue input will again be `r(H)<=alpha(H)` for every
same-degree realization H.

## 1. All vertices off a diametral path are independent

Fix a diametral path `P=p_0,...,p_D`, which is induced. Its matching of size
k is already an ordinary maximum matching. If two vertices off P were
adjacent, their edge could be added to that path matching. Thus the set R
of vertices outside P is independent. Connectedness implies that every
vertex of R has a neighbor on P.

For `x in R`, any two neighbors `p_i,p_j` satisfy `|i-j|<=2`; otherwise the
walk `p_i-x-p_j` shortens the corresponding subpath of the geodesic P.
Triangle-freeness rules out consecutive neighbor indices. Consequently
`N(x)` is a singleton or exactly `{p_i,p_(i+2)}`. In particular every
outside vertex has degree one or two and all its neighbors have one parity.

## 2. Even diameter: one support chain

Let `D=2k`. For each even index `2j`, the path has a k-edge matching that
leaves precisely `p_(2j)` unmatched. An outside neighbor of that vertex
would extend this matching by one edge, impossible. Hence every outside
neighbor index is odd.

Choose supports `u_i=p_(2i-1)`, `1<=i<=k`, and fix the path matching

`M={u_i a_i : 1<=i<=k}`, where `a_i=p_(2i-2)`.

The unmatched path endpoint is `p_(2k)`. The graph consists exactly of:

- the supports in path order;
- one or more internally disjoint two-edge paths between consecutive
  supports (the original middle even vertex plus any outside common
  neighbors);
- pendant vertices at individual supports.

There are no other edges. All matching partners `a_i` are independent.

## 3. Odd diameter: two support chains joined by one bridge

Let `D=2k-1`, with fixed maximum path matching
`M={p_(2j)p_(2j+1):0<=j<k}`. Write E for even path indices with an outside
neighbor, and O for odd such indices.

There cannot be `e in E` and `o in O` with `e<o`. Indeed choose outside
neighbors x of `p_e` and y of `p_o`. They are distinct because every
outside vertex has neighbors of only one parity. Then

`x,p_e,p_(e+1),...,p_o,y`

is an M-augmenting path: the segment starts and ends with matching edges,
so exchanging alternating edges increases the matching size by one.
Therefore **all odd attachment indices precede all even attachment
indices**.

Choose `h in {0,...,k}` so every outside odd attachment index is less
than `2h`, while every outside even attachment index is at least `2h`.
For example, if O is nonempty take `h=(max(O)+1)/2`, and if O is empty
take h=0. In each matching pair choose its support and partner as follows:

- for `j<h`, support `u_j=p_(2j+1)`, partner `a_j=p_(2j)`;
- for `j>=h`, support `u_j=p_(2j)`, partner `a_j=p_(2j+1)`.

Every outside vertex is adjacent only to supports. The left support chain
uses odd indices and the right support chain uses even indices. Consecutive
supports within either chain are connected by one or more internally
disjoint two-edge paths. If both chains are nonempty, the path edge
`p_(2h-1)p_(2h)` is their sole connection and is a bridge. Other outside
vertices are pendant at one support. Again all matching partners are
independent; in particular no edge joins partners across the boundary,
whose closest possible indices differ by three.

The cases h=0 or h=k simply give one chain. If R is empty, any permitted
choice gives the original path.

## 4. Exact feedback-vertex number

In either parity, call a link between consecutive supports **bad** if it
has at least two internally disjoint two-edge paths. The bad-link graph Q
has the supports as vertices and the bad links as edges. It is a disjoint
union of paths: one support path in the even case, or at most two in the
odd case, with the optional bridge excluded.

Every cycle of G lies within a single link. Indeed an internal support
separates the portions to its left and right, and the optional bridge
separates the two chains; a simple cycle cannot leave a link and return
through its only separating support. A link with c internal vertices is
`K_(2,c)` and is cyclic precisely when c>=2.

A vertex cover of Q is a feedback-vertex set of G. Conversely a minimum
feedback-vertex set can be chosen among the supports. A deleted pendant
vertex never helps. If a bad link has neither support deleted, at least
c-1 of its c internal vertices must be deleted; replace those deletions
by one support of that link, never increasing the number deleted. Each internal vertex belongs to exactly one link, so deletions charged to
different links are disjoint. Applying this replacement to all such links
yields a support set covering Q.
It follows that the feedback-vertex number is

`tau(G)=vc(Q)=nu(Q)`.

The last equality is elementary for a disjoint union of paths: on a path
component with ell edges, both quantities are `ceil(ell/2)`.
Write `t=nu(Q)`, so `f(G)=n-t`.

## 5. Disjoint same-degree cover certificates

Choose a matching L of t bad links in Q. For every selected link uv, choose
an **extra** common neighbor x outside the original path; such a vertex
exists because the link has at least two internal vertices, exactly one
of which is on P. Let a,b be the partners of u,v in the fixed maximum
path matching M. These five vertices are distinct.

For each selected link make the switch

`ua,vb -> uv,ab`.

The added support edge uv was absent because these supports were at
distance two on P. The partner edge ab was absent because all partners
are independent. Selected links have disjoint support pairs, hence their
matching partners are also disjoint. The chosen outside witnesses are
distinct, since each outside vertex belongs to only one link. Thus all
switches can be performed simultaneously and preserve every degree.

The resulting graph G' contains pairwise vertex-disjoint subgraphs:

- t triangles, one on each `{x,u,v}`;
- t new partner edges `ab`;
- the `k-2t` unused edges of M.

Each vertex cover of G' therefore has at least

`2t+t+(k-2t)=k+t`

vertices. Hence

`r(G)=r(G')<=alpha(G')<=n-k-t=f(G)-k`,

which proves the claimed inequality.

If D=0, G is the single vertex and the inequality is immediate; k>=1 was
implicitly used in the support-chain notation. The acyclic case t=0 is
also covered by the unchanged matching certificate.

## 6. Exact scope and an unbounded-feedback example

We have a candidate proof of the half-diameter bound, and hence original
#61, under the extra condition `nu(G)=ceil(D/2)`. No conclusion for the
remaining ordinary matching numbers is obtained by this argument.

For unbounded feedback number, take k>=1 supports in a path, put two common
neighbors between every consecutive support pair, and put one pendant
vertex at each end support (two distinct pendant vertices at the same
support when k=1). The graph has diameter `2k`, matching number
k, and feedback-vertex number `floor(k/2)`. Thus this scope is not contained
in feedback-vertex number at most one. The construction is precisely an
independent blow-up of a path with alternating singleton support bags and
two-vertex internal connector bags.
