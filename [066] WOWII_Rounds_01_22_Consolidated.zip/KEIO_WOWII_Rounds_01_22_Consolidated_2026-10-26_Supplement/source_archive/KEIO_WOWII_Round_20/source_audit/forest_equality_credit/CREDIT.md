# Late precise credit for the forest-equality neighborhood observation

Verified 26 October 2026, 08:08 UTC. This note preserves an antecedent for future consolidation; it does not edit the immutable Round 17 delivery.

**Primary source:** Karen Gunderson, Karen Meagher, Joy Morris and Venkata Raghu Tej Pantangi, *Induced forests in some distance-regular graphs*, arXiv:2301.05207 (submitted 12 January 2023), [arXiv record](https://arxiv.org/abs/2301.05207), [author PDF](https://www.cs.uleth.ca/~morris/Research/CRG-1.pdf), related published DOI [10.1016/j.dam.2023.12.003](https://doi.org/10.1016/j.dam.2023.12.003).

Section 5, printed page 13, explicitly records the following necessary neighborhood condition when the largest induced forest has order `alpha(G)+1`: relative to a maximum independent set `I`, adjacent vertices outside `I` have a common neighbor in `I`, while nonadjacent outside vertices have at least two common neighbors in `I`. Their forest-order notation is `tau`, not our feedback-vertex number.

Consequently, the elementary implication `triangle-free and f=alpha+1 => bipartite` is an immediate corollary of this prior observation: an edge outside `I` would form a triangle with its common neighbor in `I`, so the complement of `I` must also be independent. This is our explicit inference from the cited observation.

This credit applies to the elementary preliminary neighborhood/bipartiteness step of the Round 17 argument. It does **not** supply the additional Havel–Hakimi residue equality classification. No claim is made that the full classification is prior or globally new. Future combined manuscripts should cite this observation directly.

The author PDF was inspected with the browser; a local research copy and text extraction are retained when retrieval succeeds. No long verbatim passage is reproduced here.
