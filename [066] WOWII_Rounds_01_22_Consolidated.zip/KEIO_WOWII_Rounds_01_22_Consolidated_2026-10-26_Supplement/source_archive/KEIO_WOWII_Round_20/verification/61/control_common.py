"""Exact small controls and explicit degree-switch certificates for the note.
This is author validation, not an independent audit or proof by computation.
"""
import argparse, collections, functools, hashlib, itertools, json, time
from pathlib import Path
import networkx as nx

def residue(G):
 D=sorted([len(G[u]) for u in G],reverse=True)
 while D and D[0]:
  d=D.pop(0)
  for j in range(d):D[j]-=1
  D.sort(reverse=True)
 return len(D)

def invariants(G):
 n=len(G);adj=[sum(1<<v for v in G[u]) for u in G]
 @functools.lru_cache(None)
 def alpha(S):
  if not S:return 0
  u=(S&-S).bit_length()-1
  return max(alpha(S&~(1<<u)),1+alpha(S&~((1<<u)|adj[u])))
 def forest(S):
  while S:
   for u in range(n):
    if S>>u&1 and (adj[u]&S).bit_count()<=1:S^=1<<u;break
   else:return False
  return True
 a=alpha((1<<n)-1);mx=[]
 for vv in itertools.combinations(range(n),a):
  S=sum(1<<v for v in vv)
  if all(not adj[u]&S for u in vv):mx.append(set(vv))
 f=next(k for k in range(n,-1,-1) if any(forest(sum(1<<v for v in vv)) for vv in itertools.combinations(range(n),k)))
 return a,f,mx
