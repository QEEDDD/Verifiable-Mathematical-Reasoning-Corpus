# Independent audit: Hall equality and exact independent-side degree-two factors

**PASS — structural and subclass reductions only; original WOWII199 and its general split case remain open.**

Frozen note: `round_21/induced/hall_equality_classification.md`, SHA-256
`99c1e6cf3f6e2f8fc8deaec6495525e22b1ae498cc297903f5d5edb95b86cc8e`.
Author checker: `416f175888f44c5ed27b57efdbf04793b04553d3770d8abd2283545dc493c877`.
The full note, including Section7, was independently read. No mathematical repair was requested.

## 1. Scope and previously known steps

The matrix hypotheses are: nonempty columns A_c, row degrees at least k>=1, column sizes at most k+1, and pairwise column symmetric differences at most k. No exact row minimum is needed. For the original split problem, a maximum independent side makes every clique column nonempty; the familiar connectivity identity and induced star/double-star argument give these hypotheses. Any induced tree in a split graph has at most two clique vertices, so the claimed exact star/double-star description is valid. The invariant is induced connected-tree **vertex order**, not edge count or maximum forest order.

The Hall-minus-one inequality and the outside-neighborhood strengthening are explicitly **prior Round09/11 steps**, not newly counted results. Their repeated proofs are nevertheless sound. Restriction to S retains every neighbor of each selected row; symmetric differences cannot increase. With p=|S| and t=|N(S)|, a hypothetical p>=t+2 forces t>=2k by incidence counting and t<=2k−3 by difference counting. If N(S) is proper, comparison to an outside column lowers every restricted column size to at most k and gives ordinary Hall. A deficient set with full neighborhood must consequently be the whole I with h=q+1. The classical matching consequence is precisely Hall's theorem.

## 2. Exact classification of a tight proper-neighborhood set

Suppose nonempty S has |N(S)|=|S|=p and Q=N(S) is proper in C. Equality in the incidence count forces every S-row to have degree k and every restricted Q-column to have size k.

For c in Q and d outside Q, A_d is disjoint from S, so the symmetric-difference bound reads

k + |(A_c minus S) symmetric_difference A_d| <= k.

Thus all outside columns and all remainders A_c minus S equal a common B. Since outside columns are nonempty, B is nonempty. The global column-size bound leaves room for only one element of B. Hence B={x}. Every row outside S union {x} would have degree zero, which is impossible. The resulting block is exactly the stated k-regular p-by-p matrix, with a universal row x and outside singleton columns {x}.

The pair-difference sum is exactly pk(p−k), so the upper bound kp(p−1)/2 gives p<=2k−1. Division is legitimate because p>=k>=1. The converse also passes: within-block distances are the explicitly retained condition, block-to-singleton distance is k, row degrees are k or q, and q>=p+1>=k. The p=k=1 boundary is included.

The nonempty-column assumption is essential to conclude |B|=1 rather than zero; the manuscript identifies it and uses it correctly.

## 3. Traceability consequences and substantive prior inputs

Keep all p block columns and one outside singleton column d. The retained graph has q'=p+1=h<=2k, row degrees at least k, nonempty columns of size at most k+1, and unchanged pair-difference bounds. It therefore satisfies the exact **matrix**, not merely original graph-connectivity, version of the audited Round19 clique-size theorem.

That dependency was read afresh in `round_19/induced/manuscript.tex`, Sections2–4, SHA-256 `2ac3670001a1b19dbc1719892bcf8f5e6b585ab8a33d162c9fbe472ae84c063b`, together with the root's independent audit. The descending closure threshold, deficit quadratic, strict case, and both q=2k boundary patterns are sufficient. In particular the low-column-union completion in PatternB is not silently omitted. This is not an inference of traceability from Hall's condition alone.

In the retained Hamiltonian path, d has a neighbor y. It is either a clique vertex or x. Every deleted singleton column is adjacent to both d and y and to every other deleted clique vertex. Replacing edge dy by a chain through all deleted columns gives a spanning path of the original graph. The retained graph has at least four vertices, so the path-neighbor step has no degenerate singleton exception.

If a tight S instead has full neighborhood, |S|=q and the earlier order bound gives h=q or h=q+1. The equal-size case is the audited Round19 consequence; its divisibility argument forces q<=2k. The balanced case is the independently audited Round18 theorem, author TeX SHA-256 `a015fec418cd4b9bfa0d4618d638bf14d30c925f952a365933f4d387fe6cc849`. No unreviewed AI theorem is silently substituted.

Consequently any remaining nontraceable split instance must satisfy strict Hall on every nonempty S. The additional k>=4, q>=2k+1, h<=q−1 and failure of previously proved padding/small-column regimes are correctly described as combinations of earlier audited reductions, not a new full closure.

## 4. Section7: exact I-degree-two factor

Assume k>=3 and strict Hall. For every S, the required capacity inequality is

sum_c min(2,|A_c intersect S|) >= 2|S|.

The empty and singleton cases are immediate. If all nonempty restricted columns have size at least two, strict Hall gives an even stronger bound. Otherwise choose a restricted singleton {v} and put S'=S minus {v}. Comparing every column with that singleton after restriction shows r'_c=|A_c intersect S'|<=k. This holds whether or not the compared column contains v.

Hence the capacity at S' is at least (2/k) times its total incidences, at least 2|S'|. Adding v increases the chosen singleton column's contribution by one. If the desired capacity at S failed, integrality would force equality throughout the lower bound at S'. For k>=3, min(2,r)>(2/k)r at every integer1<=r<=k−1. Thus every positive r'_c=k, and equality in the row bound forces every S'-row to have degree exactly k. Therefore |N(S')|=|S'|, contradicting strict Hall on the nonempty S'. This proves the capacity inequality universally.

The flow-cut expression is correct: with source-side row set S, each column contributes the lesser of its outgoing capacity2 and the number of incidences from S. The cut capacity is exactly 2(|I|−|S|)+sum min(2,|A_c intersect S|), minimized independently over column sides. Integral max-flow/min-cut therefore supplies distinct incidence edges of degree exactly2 at each I vertex and at most2 at each C vertex.

Every nontrivial factor component is an alternating cycle or a C-ended path; isolated vertices can only be in C. **Cycles are not eliminated.** The manuscript makes no inference from this factor alone to traceability.

The k=2 guard is correct: columns {v},{v,a,b},{a},{b} satisfy all hypotheses and strict Hall, but their full-set capacity is5<6. The displayed seven-vertex path is valid in its split graph. It is a sharpness example for the factor hypothesis, not an original199 counterexample.

## 5. Independent finite controls

`check_independent.py` imports no author code and uses only the standard library. Its finite domain includes every nonempty column multiset with1<=h,q<=6 and h+q<=10; every k satisfying the original incidence hypotheses is checked, with no derived Hall or equality pruning.

- **1,199,537 column multisets** considered; **7,471 qualifying parameter instances**.
- **103,353 row-subset tests**, including **1,150 tight sets** and **56 tight proper-neighborhood sets**; every equality classification passes.
- **1,039 tight graphs** independently verified traceable by exact Hamiltonian endpoint subset-DP.
- **5,757 strict-Hall k>=3 parameter instances** independently produce exact I-degree-two factors via residual-capacity-matrix augmenting flows. The author uses a different adjacency-list reverse-edge implementation.
- The unique small k=2 capacity failure is reproduced, and its explicit spanning path is checked.
- **1,152 fresh scalable equality-family spanning paths**, through order198, constructed with independent forward/reverse closure and singleton insertion: **225,216 closure additions**, **18,538 reverse reroutings**, and **32,256 inserted singleton columns**.
- **70 larger strict-Hall matrices**, through order316, yield exact factors. Their components explicitly include **217 alternating cycles** and **247 C-ended paths**, plus isolated C vertices. These cycles are retained and reported, not incorrectly treated as a Hamiltonian path.

The author's checker was also rerun. Its snapshot needed only a path-resolution adjustment from HERE.parents[1] to HERE.parents[3] to locate the explicitly credited Round19 construction. All mathematical code remained unchanged. Every reported count and factor output agrees with the author result; only elapsed time differs. The original and rerun programs and outputs are retained.

All computation here is corroboration of analytic results, not a finite-certificate dependency or an exhaustive original-conjecture search. Worldwide priority is outside this audit. Parent handles any future standalone-TeX consolidation and visual QA.
