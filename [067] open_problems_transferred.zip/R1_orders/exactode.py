# R1: exact (over Q) reconstruction of guessed ODEs by multi-modular CRT + rational reconstruction,
# and exact local analysis (log-free solution dimension) at rational points. Exploration tool.
import flint
from fractions import Fraction
from math import isqrt
from odeguess import guess_ode

PRIMES = [2305843009213693951, 2305843009213693921, 2305843009213693907, 2305843009213693723, 2305843009213693693, 2305843009213693669, 2305843009213693613, 2305843009213693561, 2305843009213693549, 2305843009213693487, 2305843009213693421, 2305843009213693373]

def ratrecon(a, m):
    a %= m
    r0, r1 = m, a
    s0, s1 = 0, 1
    lim = isqrt(m//2)
    while r1 > lim:
        q = r0 // r1
        r0, r1 = r1, r0 - q*r1
        s0, s1 = s1, s0 - q*s1
    if s1 == 0 or abs(s1) > lim:
        return None
    return Fraction(r1, s1)

def crt(residues, moduli):
    x, m = 0, 1
    for r, p in zip(residues, moduli):
        # solve x + m*k = r mod p
        k = ((r - x) * pow(m, -1, p)) % p
        x = x + m*k
        m = m*p
    return x % m, m

def exact_ode(seq, r, D, nprimes=6):
    """Assumes nullity 1. Normalize: first nonzero coefficient (in fixed order) = 1."""
    vecs = []
    for p in PRIMES[:nprimes]:
        ops = guess_ode(seq, r, D, p)
        assert ops is not None and len(ops) == 1, (p, None if ops is None else len(ops))
        op = ops[0]
        flat = []
        for k in range(r+1):
            flat += op[k]
        # normalize by the first nonzero entry
        piv = next(i for i, c in enumerate(flat) if c % p)
        inv = pow(flat[piv], -1, p)
        vecs.append((piv, [c*inv % p for c in flat]))
    pivs = set(v[0] for v in vecs)
    assert len(pivs) == 1
    n = len(vecs[0][1])
    out = []
    for i in range(n):
        x, m = crt([v[1][i] for v in vecs], PRIMES[:nprimes])
        fr = ratrecon(x, m)
        assert fr is not None, "reconstruction failed; use more primes"
        out.append(fr)
    # clear denominators
    from math import lcm
    L = 1
    for f in out:
        L = lcm(L, f.denominator)
    ints = [int(f*L) for f in out]
    op = {k: ints[k*(D+1):(k+1)*(D+1)] for k in range(r+1)}
    return op

def check_ode(op, seq, nmax=None):
    """Verify exactly that op annihilates F up to t^nmax."""
    r = max(op.keys())
    if nmax is None:
        nmax = len(seq) - r - 1
    for N in range(nmax):
        tot = 0
        for k, cs in op.items():
            for j, c in enumerate(cs):
                if c == 0:
                    continue
                m = N - j
                if m < 0:
                    continue
                ff = 1
                for i in range(k):
                    ff *= (m+k-i)
                tot += c*ff*seq[m+k]
        if tot != 0:
            return False, N
    return True, nmax

def shift_op(op, a):
    """Return op in local variable u=t-a: dict k -> list of Fraction coefficients in u."""
    out = {}
    for k, cs in op.items():
        # q(a+u) = sum_j c_j (a+u)^j
        res = [Fraction(0)]*len(cs)
        for j, c in enumerate(cs):
            if c == 0:
                continue
            # binomial expansion
            from math import comb
            for i in range(j+1):
                res[i] += c * comb(j, i) * Fraction(a)**(j-i)
        out[k] = res
    return out

def local_structure(op, a):
    """At t=a: compute shift s, indicial polynomial roots (rational), and the dimension of
    log-free Laurent solutions (exactly)."""
    loc = shift_op(op, a)
    r = max(loc.keys())
    # find s = min over (l-k)
    s = min(l - k for k, cs in loc.items() for l, c in enumerate(cs) if c != 0)
    # P_j(e) = sum_k loc[k][s+k+j] * ff(e,k), applied to u^e gives coefficient of u^{e+s+j}
    maxl = max(len(cs) for cs in loc.values())
    def Pj(j, e):
        tot = Fraction(0)
        for k, cs in loc.items():
            l = s + k + j
            if 0 <= l < len(cs) and cs[l] != 0:
                ff = Fraction(1)
                for i in range(k):
                    ff *= (e - i)
                tot += cs[l]*ff
        return tot
    # integer roots of indicial polynomial P_0 in a window
    introots = [e for e in range(-60, 60) if Pj(0, e) == 0]
    if not introots:
        return s, introots, None
    emin, emax = min(introots), max(introots)
    # unknown coefficients c_e for e in [emin, emax]; equations: coefficient of u^{E+s} for E in [emin, emax]:
    # sum_{j>=0} P_j(E-j) c_{E-j} = 0
    idx = {e: i for i, e in enumerate(range(emin, emax+1))}
    rows = []
    for E in range(emin, emax+1):
        row = [Fraction(0)]*len(idx)
        for j in range(0, E-emin+1):
            row[idx[E-j]] += Pj(j, E-j)
        rows.append(row)
    M = flint.fmpq_mat(len(rows), len(idx), [flint.fmpq(x.numerator, x.denominator) for row in rows for x in row])
    rank = M.rank()
    logfree = len(idx) - rank
    return s, introots, logfree

def log_structure(op, a, J):
    """Dimension of local solutions at t=a of the form sum_{j<=J} A_j(u) log^j u with A_j Laurent
    series having integer exponents (= dim ker (T-1)^{J+1} on the integer-exponent part)."""
    import sympy
    loc = shift_op(op, a)
    s = min(l - k for k, cs in loc.items() for l, c in enumerate(cs) if c != 0)
    def Pcoeffs(j):
        # P_j(theta) as list of polynomial coefficients in theta (Fractions)
        poly = [Fraction(0)]
        for k, cs in loc.items():
            l = s + k + j
            if 0 <= l < len(cs) and cs[l] != 0:
                ff = [Fraction(1)]
                for i in range(k):
                    # multiply by (theta - i)
                    nf = [Fraction(0)]*(len(ff)+1)
                    for t_, c in enumerate(ff):
                        nf[t_+1] += c
                        nf[t_] -= i*c
                    ff = nf
                if len(ff) > len(poly):
                    poly += [Fraction(0)]*(len(ff)-len(poly))
                for t_, c in enumerate(ff):
                    poly[t_] += cs[l]*c
        return poly
    def peval_der(poly, x, r):
        # r-th derivative of poly at x, divided by r!
        tot = Fraction(0)
        from math import comb as C
        for t_, c in enumerate(poly):
            if t_ >= r and c != 0:
                tot += c*C(t_, r)*Fraction(x)**(t_-r)
        return tot
    P0 = Pcoeffs(0)
    introots = [e for e in range(-60, 60) if peval_der(P0, e, 0) == 0]
    emin, emax = min(introots), max(introots)
    Ps = [Pcoeffs(j) for j in range(0, emax-emin+1)]
    unk = [(m, j) for m in range(emin, emax+1) for j in range(J+1)]
    idx = {u: i for i, u in enumerate(unk)}
    rows = []
    for M in range(emin, emax+1):
        for jp in range(J+1):
            row = [Fraction(0)]*len(unk)
            for l in range(0, M-emin+1):
                for j in range(jp, J+1):
                    # binom(j, j-jp) * P_l^{(j-jp)}(M-l) ; with P^{(r)}/r! * r! ... use exact derivative
                    from math import comb as C, factorial as F
                    r = j - jp
                    coef = C(j, r) * peval_der(Ps[l], M-l, r) * F(r)
                    row[idx[(M-l, j)]] += coef
            rows.append(row)
    Mx = flint.fmpq_mat(len(rows), len(unk), [flint.fmpq(x.numerator, x.denominator) for row in rows for x in row])
    return len(unk) - Mx.rank()
