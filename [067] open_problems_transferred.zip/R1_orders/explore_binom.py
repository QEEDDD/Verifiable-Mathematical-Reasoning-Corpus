import sys
sys.path.insert(0, '.')
from rook_data import rook_flint
from guess import find_min, charpoly_from, P
from math import comb
import flint
for d in [2,3,4,5,6]:
    N = {2:40,3:80,4:160,5:260,6:420}[d]
    a = rook_flint(d, N)
    b = [sum((-1)**(M-n)*comb(M,n)*a[n] for n in range(M+1)) for M in range(N+1)]
    res = find_min(b, d, {2:6,3:10,4:20,5:35,6:50}[d])
    for r, v in res.items():
        if v is None or isinstance(v, str):
            continue
        D, nb, bas = v
        cp, degs = charpoly_from(bas[0], r, D)
        f = flint.nmod_poly(cp, P)
        print("d=%d: b_N minimal recurrence order %d, degree %d, degs %s, charpoly factor:" % (d, r, D, degs), f.factor())
        break
    print("   b[:8] =", b[:8])
