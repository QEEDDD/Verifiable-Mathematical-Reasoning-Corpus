import sys
sys.path.insert(0, '.')
from rook_data import rook_flint
from exactode import exact_ode
params = {2: (2, 2, 40), 3: (3, 5, 80), 4: (5, 11, 200)}
for d in [2,3,4]:
    r, D, N = params[d]
    seq = rook_flint(d, N)
    op = exact_ode(seq, r, D, nprimes=8)
    print("d=%d: coefficient of d^0 (constants are solutions iff zero):" % d, op[0])
