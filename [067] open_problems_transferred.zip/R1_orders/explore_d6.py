import sys, time
sys.path.insert(0, '.')
from rook_data import rook_flint
from odeguess import guess_ode, P
import flint
d = 6
t0 = time.time()
seq = rook_flint(d, 900)
print("computed seq", time.time()-t0, flush=True)
done = False
for r in range(9, 16):
    for D in range(20, 60, 2):
        ops = guess_ode(seq, r, D)
        if ops is None:
            print("insufficient data r=%d D=%d" % (r, D), flush=True)
            break
        if ops:
            print("d=6: ODE order %d degree <=%d nullity %d" % (r, D, len(ops)), flush=True)
            done = True
            break
    if done:
        break
    print("no ODE of order %d up to degree tried" % r, flush=True)
