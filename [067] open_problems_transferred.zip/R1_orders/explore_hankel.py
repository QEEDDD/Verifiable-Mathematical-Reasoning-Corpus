import sys
sys.path.insert(0, '.')
from rook_data import rook_flint
import flint
for d in [2,3,4,5]:
    a = rook_flint(d, 60)
    out0, out1, out2 = [], [], []
    for N in range(1, 25):
        H0 = flint.fmpz_mat([[a[i+j] for j in range(N)] for i in range(N)]).det()
        H1 = flint.fmpz_mat([[a[i+j+1] for j in range(N)] for i in range(N)]).det()
        # moments of (c-1): shifted sequence b_n = sum_k binom(n,k)(-1)^{n-k} a_k  (Hausdorff on [1,c0] => positivity of a_{i+j+1}-a_{i+j})
        H2 = flint.fmpz_mat([[a[i+j+1]-a[i+j] for j in range(N)] for i in range(N)]).det()
        out0.append(1 if H0>0 else (0 if H0==0 else -1))
        out1.append(1 if H1>0 else (0 if H1==0 else -1))
        out2.append(1 if H2>0 else (0 if H2==0 else -1))
    print("d=%d sign det(a_{i+j}) N=1..24:" % d, out0)
    print("     sign det(a_{i+j+1}):", out1)
    print("     sign det(a_{i+j+1}-a_{i+j}):", out2)
