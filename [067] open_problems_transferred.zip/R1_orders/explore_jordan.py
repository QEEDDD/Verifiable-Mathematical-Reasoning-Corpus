import sys
sys.path.insert(0, '.')
from rook_data import rook_flint
from exactode import exact_ode, check_ode, log_structure
from fractions import Fraction
params = {3: (3, 5, 80), 4: (5, 11, 200), 5: (8, 20, 420)}
for d in [3, 4, 5]:
    r, D, N = params[d]
    seq = rook_flint(d, N)
    op = exact_ode(seq, r, D, nprimes=8)
    dims = [log_structure(op, Fraction(1), J) for J in range(0, 4)]
    print("d=%d order %d at t=1: dim ker(T-1)^k for k=1..4:" % (d, r), dims)
