import sys
sys.path.insert(0, '.')
from rook_data import rook_flint
from exactode import ratrecon, crt, PRIMES
from guess import nullspace_mod
import sympy as sp
from math import lcm
n = sp.symbols('n')
def exact_rec(seq, r, D, nprimes=8):
    vecs = []
    for p in PRIMES[:nprimes]:
        b = nullspace_mod(seq, r, D, p)
        assert b is not None and len(b) == 1
        v = b[0]
        piv = next(i for i, c in enumerate(v) if c % p)
        inv = pow(v[piv], -1, p)
        vecs.append([c*inv % p for c in v])
    out = []
    for i in range(len(vecs[0])):
        x, m = crt([v[i] for v in vecs], PRIMES[:nprimes])
        fr = ratrecon(x, m)
        assert fr is not None
        out.append(fr)
    L = 1
    for f in out: L = lcm(L, f.denominator)
    ints = [int(f*L) for f in out]
    polys = [sum(ints[j*(D+1)+e]*n**e for e in range(D+1)) for j in range(r+1)]
    return polys
params = {2:(2,1,40), 3:(3,4,80), 4:(4,9,160), 5:(5,18,260)}
for d in [2,3,4,5]:
    r, D, N = params[d]
    seq = rook_flint(d, N)
    polys = exact_rec(seq, r, D)
    # verify exactly on all data
    ok = all(sum(polys[j].subs(n, nn)*seq[nn+j] for j in range(r+1)) == 0 for nn in range(0, N-r))
    print("d=%d: recurrence order %d degree %d verified on data: %s" % (d, r, D, ok))
    print("   leading p_%d(n) =" % r, sp.factor(polys[r]))
    print("   trailing p_0(n) =", sp.factor(polys[0]))
