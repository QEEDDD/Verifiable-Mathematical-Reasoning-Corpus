import sys
sys.path.insert(0, '.')
from guess import find_min, charpoly_from, P
from math import comb
import flint
def f2(n, j):
    return comb(n, j) - (comb(n, j-1) if j >= 1 else 0)
def y2(beta, N):
    return [sum(f2(n, j)**beta for j in range(0, n//2+1)) for n in range(N+1)]
for beta in [1, 2, 3, 4, 5, 6, 7]:
    N = 200
    seq = y2(beta, N)
    res = find_min(seq, 8, 30)
    for r, v in res.items():
        if v is None or isinstance(v, str):
            continue
        D, nb, bas = v
        cp, degs = charpoly_from(bas[0], r, D)
        f = flint.nmod_poly(cp, P)
        print("beta=%d k=2: minimal recurrence order %d degree %d; charpoly factors:" % (beta, r, D), f.factor())
        break
