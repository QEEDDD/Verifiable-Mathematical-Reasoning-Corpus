import sys
sys.path.insert(0, '.')
from guess import nullspace_mod, charpoly_from, P
from math import comb
import flint
def f2(n, j):
    return comb(n, j) - (comb(n, j-1) if j >= 1 else 0)
def y2(beta, N):
    return [sum(f2(n, j)**beta for j in range(0, n//2+1)) for n in range(N+1)]
for beta in [7, 9]:
    N = 700
    seq = y2(beta, N)
    found = None
    for r in range(4, 9):
        for D in range(10, 130, 4):
            b = nullspace_mod(seq, r, D)
            if b is None:
                print("beta=%d r=%d D=%d insufficient data" % (beta, r, D), flush=True)
                break
            if b:
                found = (r, D, b)
                break
        if found:
            break
    if found:
        r, D, b = found
        cp, degs = charpoly_from(b[0], r, D)
        print("beta=%d: order %d degree<=%d, charpoly:" % (beta, r, D), flint.nmod_poly(cp, P).factor(), flush=True)
