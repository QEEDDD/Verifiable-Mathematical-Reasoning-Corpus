import sys
sys.path.insert(0, '.')
from rook_data import rook_flint
from guess import find_min, charpoly_from, P
import flint
for d in [2,3,4,5]:
    N = {2:40, 3:80, 4:160, 5:260}[d]
    seq = rook_flint(d, N)
    res = find_min(seq, d, {2:4,3:10,4:20,5:35}[d])
    for r, v in res.items():
        if v is None or isinstance(v, str):
            print("d=%d r=%d:"%(d,r), v)
        else:
            D, nb, b = v
            cp, degs = charpoly_from(b[0], r, D)
            # characteristic polynomial sum_j cp[j] T^j  (mod p): factor mod p
            f = flint.nmod_poly(cp, P)
            print("d=%d r=%d: minimal degree D=%d, nullity %d, degs %s, charpoly factors mod p:"%(d,r,D,nb,degs), f.factor())
