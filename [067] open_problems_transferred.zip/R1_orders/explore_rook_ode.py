import sys
sys.path.insert(0, '.')
from rook_data import rook_flint
from odeguess import guess_ode, indicial, indicial_inf, root_to_rational, P
from fractions import Fraction
import flint

def roots_rational(poly):
    out = []
    for f, m in poly.factor()[1]:
        if f.degree() == 1:
            c = f.coeffs()
            rt = (-int(c[0]) * pow(int(c[1]), P-2, P)) % P
            out.append((root_to_rational(rt), m))
        else:
            out.append(('deg%d' % f.degree(), m))
    return out

for d in [2, 3, 4, 5]:
    N = {2: 60, 3: 150, 4: 300, 5: 500}[d]
    seq = rook_flint(d, N)
    found = False
    for r in range(1, 12):
        for D in range(1, 40):
            ops = guess_ode(seq, r, D)
            if ops is None:
                break
            if ops:
                found = True
                break
        if found:
            break
    op = ops[0]
    print("d=%d: minimal ODE order %d with degree %d (nullity %d)" % (d, r, D, len(ops)))
    lc = flint.nmod_poly(op[r], P)
    print("  leading coeff roots:", roots_rational(lc))
    tm = []
    for m in range(0, (d+1)//2):
        tm.append(Fraction(m+1, d+1-m)**(d-2*m))
    pts = [Fraction(0)] + tm + [Fraction(1)]
    for pt in pts:
        a = pt.numerator * pow(pt.denominator, P-2, P) % P
        s, ip = indicial(op, a)
        print("  t=%s: shift %d, exponents:" % (pt, s), roots_rational(ip))
    s, ip = indicial_inf(op)
    print("  t=inf: exponents (t^-e):", roots_rational(ip))
