# R1 exploration: local data of the guessed minimal ODE for d=4 (order 5, degree 11), with the d/dt factor removed.
# Purpose: decide whether an irreducibility (Fuchs relation) argument can prove sharpness for d=4.
import sys
from fractions import Fraction
sys.path.insert(0, '.')
import sympy as sp
from rook_data import rook_flint
from exactode import exact_ode, check_ode

d, r, D, N = 4, 5, 11, 200
seq = rook_flint(d, N)
op = exact_ode(seq, r, D, nprimes=8)
print("check_ode:", check_ode(op, seq))
print("coefficient of d^0 is zero:", all(c == 0 for c in op[0]))
t = sp.symbols('t')
coef = {k: sp.Poly(list(reversed(op[k])), t) for k in op}     # op[k] lists low->high
L1 = {k-1: coef[k] for k in range(1, r+1)}                      # L1 acts on y = F'
m = r - 1
lc = L1[m]
print("leading coefficient of L1 factored:", sp.factor_list(lc.as_expr()))

def indicial_at(Lop, a):
    """indicial polynomial (in e) at t=a (a rational), operator dict k-> Poly in t"""
    e, u = sp.symbols('e u')
    loc = {k: sp.Poly(sp.expand(p.as_expr().subs(t, a + u)), u) for k, p in Lop.items()}
    s = min(mon[0] - k for k, p in loc.items() for mon in p.monoms() if p.coeff_monomial(u**mon[0]) != 0)
    ind = 0
    for k, p in loc.items():
        c = p.coeff_monomial(u**(s + k)) if s + k >= 0 else 0
        ff = 1
        for i in range(k):
            ff *= (e - i)
        ind += c*ff
    return sp.factor(sp.expand(ind)), s

def indicial_inf(Lop):
    e = sp.symbols('e')
    # t^j d^k on t^{-e}: ff(-e,k) t^{j-k-e}; leading: max j-k
    s = max(mon[0] - k for k, p in Lop.items() for mon in p.monoms() if p.coeff_monomial(t**mon[0]) != 0)
    ind = 0
    for k, p in Lop.items():
        if s + k >= 0:
            c = p.coeff_monomial(t**(s + k))
            ff = 1
            for i in range(k):
                ff *= (-e - i)
            ind += c*ff
    return sp.factor(sp.expand(ind)), s

for a in [sp.Integer(0), sp.Rational(1, 625), sp.Rational(1, 4), sp.Integer(1)]:
    ip, s = indicial_at(L1, a)
    print("L1 at t=%s: indicial %s" % (a, ip))
ip, s = indicial_inf(L1)
print("L1 at infinity (solutions ~ t^-e): indicial %s" % ip)
# other factors of the leading coefficient
for f, mult in sp.factor_list(lc.as_expr())[1]:
    fp = sp.Poly(f, t)
    if fp.degree() >= 1 and not any(fp.eval(a) == 0 for a in [0, sp.Rational(1, 625), sp.Rational(1, 4), 1]):
        print("extra factor", f, "multiplicity", mult)
        if mult == 1:
            # exponents 0..m-2 and rho = m-1 - c_{m-1}/c_m' at roots of f
            cm1 = L1[m-1].as_expr()
            dcm = sp.diff(lc.as_expr(), t)
            # compute cm1 * inverse(dcm) mod f
            inv = sp.invert(dcm, f, t)
            rho = sp.rem(sp.expand(cm1*inv), f, t)
            print("   extra exponent m-1 - c_{m-1}/c_m' =", sp.simplify(m - 1 - rho))
