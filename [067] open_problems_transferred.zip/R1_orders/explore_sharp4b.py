# R1 exploration: holomorphic (= log-free, integer exponents >= 0) solution counts of L1 (d=4) at t_0, t_1, 1,
# and of M4 = L1*d/dt, to see whether "M4 annihilates F4 and L1 irreducible" would suffice for sharpness at d=4.
import sys
from fractions import Fraction
sys.path.insert(0, '.')
from rook_data import rook_flint
from exactode import exact_ode, local_structure, log_structure

seq = rook_flint(4, 200)
op = exact_ode(seq, 5, 11, nprimes=8)
L1 = {k-1: op[k] for k in range(1, 6)}
for a in [Fraction(1, 625), Fraction(1, 4), Fraction(1)]:
    s, ir, lf = local_structure(L1, a)
    s2, ir2, lf2 = local_structure(op, a)
    print("t=%s: L1 integer exponents %s, log-free solutions %s (of 4);  M4 integer exponents %s, log-free %s (of 5)"
          % (a, ir, lf, ir2, lf2))
    if a == 1:
        for J in [0, 1, 2]:
            print("   L1: dim of solutions with log-degree <= %d: %s;  M4: %s" % (J, log_structure(L1, a, J), log_structure(op, a, J)))
