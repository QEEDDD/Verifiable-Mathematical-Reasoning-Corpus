import sys, time
sys.path.insert(0, '.')
from rook_data import rook_flint
from exactode import exact_ode, check_ode, local_structure
from fractions import Fraction
params = {2: (2, 2, 40), 3: (3, 5, 80), 4: (5, 11, 200), 5: (8, 20, 420)}
for d in [2, 3, 4, 5]:
    r, D, N = params[d]
    t0 = time.time()
    seq = rook_flint(d, N)
    op = exact_ode(seq, r, D, nprimes=8)
    ok = check_ode(op, seq)
    print("d=%d: exact ODE order %d degree %d verified on %s coefficients (%.1fs)" % (d, r, D, ok, time.time()-t0))
    pts = [Fraction(1)] + [Fraction(m+1, d+1-m)**(d-2*m) for m in range((d+1)//2)] + [Fraction(0)]
    for a in pts:
        s, ir, lf = local_structure(op, a)
        print("   t=%s: lc-multiplicity %d, integer indicial roots %s, log-free solutions %s -> rk(T-1)>=%s" % (a, s + r, ir, lf, None if lf is None else r - lf))
