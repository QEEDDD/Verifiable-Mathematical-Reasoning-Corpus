# R1: simple recurrence guesser (exploration only; not used as proof).
# Finds polynomial recurrences sum_{j=0}^r p_j(n) a(n+j) = 0, deg p_j <= D, via nullspace mod p.
import flint

P = 2**61 - 1  # prime modulus (flint nmod requires < 2^64)

def nullspace_mod(seq, r, D, p=P, nstart=0):
    """Return a basis of the nullspace (list of coefficient vectors) mod p.
    Unknown ordering: c[j*(D+1)+e] is coefficient of n^e in p_j."""
    nunk = (r+1)*(D+1)
    rows = []
    N = len(seq)
    for n in range(nstart, N - r):
        row = []
        for j in range(r+1):
            a = seq[n+j] % p
            pw = 1
            for e in range(D+1):
                row.append(a*pw % p)
                pw = pw*n % p
        rows.append(row)
    if len(rows) < nunk + 5:
        return None  # not enough equations
    M = flint.nmod_mat(rows, p)
    X, nullity = M.nullspace()
    basis = []
    for col in range(nullity):
        basis.append([int(X[i, col]) for i in range(nunk)])
    return basis

def find_min(seq, rmax, Dmax, p=P):
    """For each order r find minimal degree D with a nontrivial solution."""
    res = {}
    for r in range(1, rmax+1):
        for D in range(0, Dmax+1):
            b = nullspace_mod(seq, r, D, p)
            if b is None:
                res[r] = ('insufficient data at D=%d' % D)
                break
            if len(b) > 0:
                res[r] = (D, len(b), b)
                break
        else:
            res[r] = None
    return res

def charpoly_from(vec, r, D, p=P):
    """Coefficients of n^Dtop in p_j, where Dtop = max degree actually used."""
    polys = [vec[j*(D+1):(j+1)*(D+1)] for j in range(r+1)]
    degs = []
    for q in polys:
        dg = -1
        for e in range(D, -1, -1):
            if q[e] % p != 0:
                dg = e
                break
        degs.append(dg)
    Dt = max(degs)
    return [q[Dt] % p for q in polys], degs
