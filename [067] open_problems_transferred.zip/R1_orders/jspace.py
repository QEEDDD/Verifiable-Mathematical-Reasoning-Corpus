# R1: dimension of the formal space spanned by J(i,k) = int_0^oo e^{-s} s^k l^{d-i} l'^i ds
# modulo the integration-by-parts relations
#   (1+i) J(i,k) = k J(i,k-1) + (d-i) J(i+1,k) + i n J(i-1,k-1),  valid for k >= i-d+1,
# where l = l_n(s) satisfies s l'' = n l - s l'.  Unknowns: J(i,k), 0<=i<=d, i-d <= k <= K.
# Computation over F_p with a random value of n (generic), to find the quotient dimension.
import random, sys
import flint

def quotient_dim(d, K, p=2**61-1, nval=None, return_basis_test=None):
    if nval is None:
        nval = random.randrange(10**6, 10**9)
    unk = [(i, k) for i in range(d+1) for k in range(i-d, K+1)]
    idx = {u: j for j, u in enumerate(unk)}
    rows = []
    for i in range(d+1):
        for k in range(i-d+1, K+1):
            row = [0]*len(unk)
            # (1+i)J(i,k) - k J(i,k-1) - (d-i) J(i+1,k) - i n J(i-1,k-1) = 0
            row[idx[(i, k)]] = (row[idx[(i, k)]] + 1 + i) % p
            if (i, k-1) in idx:
                row[idx[(i, k-1)]] = (row[idx[(i, k-1)]] - k) % p
            if i+1 <= d:
                if (i+1, k) not in idx:
                    continue  # k < (i+1)-d impossible here since k>=i-d+1
                row[idx[(i+1, k)]] = (row[idx[(i+1, k)]] - (d-i)) % p
            if i-1 >= 0:
                row[idx[(i-1, k-1)]] = (row[idx[(i-1, k-1)]] - i*nval) % p
            rows.append(row)
    M = flint.nmod_mat(rows, p)
    rk = M.rank()
    # quotient dimension of the span of unknowns with k in a "low" window, measured as:
    # total unknowns - rank, but unknowns with large k near K are under-constrained (truncation).
    return len(unk) - rk, len(unk), rk

def span_dim(d, K, targets, p=2**61-1, nval=None):
    """Dimension of the image of span(targets) in the quotient (truncated at K)."""
    if nval is None:
        nval = random.randrange(10**6, 10**9)
    unk = [(i, k) for i in range(d+1) for k in range(i-d, K+1)]
    idx = {u: j for j, u in enumerate(unk)}
    rel = []
    for i in range(d+1):
        for k in range(i-d+1, K+1):
            row = [0]*len(unk)
            row[idx[(i, k)]] += 1 + i
            row[idx[(i, k-1)]] -= k
            if i+1 <= d:
                row[idx[(i+1, k)]] -= (d-i)
            if i-1 >= 0:
                row[idx[(i-1, k-1)]] -= i*nval
            rel.append([x % p for x in row])
    R = flint.nmod_mat(rel, p)
    r0 = R.rank()
    tg = []
    for t in targets:
        row = [0]*len(unk)
        row[idx[t]] = 1
        tg.append(row)
    M = flint.nmod_mat(rel + tg, p)
    return M.rank() - r0

if __name__ == "__main__":
    for d in range(1, 8):
        # dimension of span of J(i,k) with 0<=k<=k0 modulo relations, for growing truncation K
        res = []
        for K in [d+4, d+8, 2*d+12]:
            targets = [(i, k) for i in range(d+1) for k in range(0, 4)]
            res.append(span_dim(d, K, targets))
        # candidate basis: J(0,0..d-1)
        b1 = span_dim(d, 2*d+12, [(0, k) for k in range(d)])
        b2 = span_dim(d, 2*d+12, [(0, k) for k in range(d)] + [(i, k) for i in range(d+1) for k in range(0, 4)])
        print("d=%d: dim span{J(i,k):k in 0..3} for K-truncations %s ; dim span{J(0,0..d-1)} = %d ; with all = %d" % (d, res, b1, b2))
