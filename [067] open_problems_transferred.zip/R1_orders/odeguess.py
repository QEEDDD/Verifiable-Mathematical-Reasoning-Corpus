# R1: ODE guessing modulo a prime and local exponent computation (exploration tool).
import flint
from math import comb

P = 2**61 - 1

def guess_ode(seq, r, D, p=P):
    """Find operators sum_{k<=r, j<=D} c_{kj} t^j d^k annihilating F=sum seq[n] t^n (mod p).
    Returns list of operators as dict k -> list of coefficients (poly in t, low->high)."""
    M = len(seq) - r - 1
    nunk = (r+1)*(D+1)
    rows = []
    for N in range(0, M):
        row = []
        for k in range(r+1):
            for j in range(D+1):
                m = N - j
                if m < 0:
                    row.append(0)
                    continue
                # [t^m] d^k F = (m+k)!/m! a_{m+k}
                ff = 1
                for i in range(k):
                    ff = ff*(m+k-i) % p
                row.append(ff*(seq[m+k] % p) % p)
        rows.append(row)
    if len(rows) < nunk + 10:
        return None
    A = flint.nmod_mat(rows, p)
    X, nul = A.nullspace()
    ops = []
    for c in range(nul):
        vec = [int(X[i, c]) for i in range(nunk)]
        op = {k: vec[k*(D+1):(k+1)*(D+1)] for k in range(r+1)}
        ops.append(op)
    return ops

def poly_shift(coeffs, a, p=P):
    """coefficients of q(a+u) in u."""
    q = flint.nmod_poly(coeffs, p)
    # compose with (u + a)
    return [int(c) for c in q(flint.nmod_poly([a % p, 1], p)).coeffs()]

def indicial(op, a, p=P):
    """Indicial polynomial (in e) of op at t=a (finite point), and shift s.
    op: dict k-> coeffs in t."""
    r = max(op.keys())
    sh = {k: poly_shift(op[k], a, p) for k in op}
    best = None
    for k, cs in sh.items():
        for l, c in enumerate(cs):
            if c % p:
                s = l - k
                if best is None or s < best:
                    best = s
    # collect terms with l - k = best
    poly = flint.nmod_poly([0], p)
    for k, cs in sh.items():
        l = best + k
        if 0 <= l < len(cs) and cs[l] % p:
            ff = flint.nmod_poly([1], p)
            for i in range(k):
                ff = ff * flint.nmod_poly([(-i) % p, 1], p)
            poly = poly + ff * cs[l]
    return best, poly

def indicial_inf(op, p=P):
    """Indicial polynomial at infinity in terms of exponent e for solutions ~ t^{-e}."""
    # substitute t = 1/u: d/dt = -u^2 d/du. Easier: use theta form. t^j d^k = t^{j-k} theta_ff(k)
    # theta = t d/dt; t^k d^k = theta(theta-1)...(theta-k+1). Solutions t^{-e}: theta -> -e.
    # term c t^j d^k acting on t^{-e}: c * ff(-e,k) * t^{j-k-e}. Leading at infinity: max (j-k).
    best = None
    for k, cs in op.items():
        for j, c in enumerate(cs):
            if c % p:
                s = j - k
                if best is None or s > best:
                    best = s
    poly = flint.nmod_poly([0], p)
    for k, cs in op.items():
        j = best + k
        if 0 <= j < len(cs) and cs[j] % p:
            ff = flint.nmod_poly([1], p)
            for i in range(k):
                ff = ff * flint.nmod_poly([(-i) % p, -1 % p], p)  # (-e - i)
            poly = poly + ff * cs[j]
    return best, poly

def modinv(a, p=P):
    return pow(a % p, p-2, p)

def root_to_rational(x, p=P, bound=10**9):
    """Rational reconstruction of x mod p."""
    # standard extended Euclid rational reconstruction
    a0, a1 = p, x % p
    b0, b1 = 0, 1
    import math
    lim = math.isqrt(p//2)
    while a1 > lim:
        q = a0 // a1
        a0, a1 = a1, a0 - q*a1
        b0, b1 = b1, b0 - q*b1
    if b1 == 0:
        return None
    from fractions import Fraction
    fr = Fraction(a1, b1)
    if abs(fr.numerator) > bound or abs(fr.denominator) > bound:
        return None
    return fr
