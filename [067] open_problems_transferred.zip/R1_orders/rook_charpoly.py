# R1: characteristic polynomials of the (proved, Proposition R1:prop:soft) recurrences for 2 <= d <= 6.
# Run:  python3 -I rook_charpoly.py
# The characteristic polynomial of sum_j K_j(n) a_{n+j} = 0 is sum_j lc_j T^j, lc_j = coefficient of n^D in K_j.
# Checks (exactly, over Q) that it is proportional to (T-1)^{floor(d/2)} prod_{0<=m<d/2} (T - 1/t_m),
# t_m = ((m+1)/(d+1-m))^{d-2m}  (Conjecture R1:conj:sharp, last clause).
import sys
sys.path.insert(0, '.')
import sympy as sp
from fractions import Fraction
from rook_data import rook_flint
from rook_softproof import exact_rec, KZ

T = sp.symbols('T')
for d in range(2, 7):
    D = KZ[d]
    N = (d + 1)*(D + 1) + d + 40
    seq = rook_flint(d, N)
    K, _ = exact_rec(seq, d, D)
    cp = sum(sp.Integer(K[j][D])*T**j for j in range(d + 1))
    target = (T - 1)**(d//2)
    for m in range((d + 1)//2):
        target *= (T - sp.Rational(d + 1 - m, m + 1)**(d - 2*m))
    ratio = sp.cancel(cp/sp.expand(target))
    print("d=%d: charpoly = %s ;  proportional to (T-1)^%d prod (T-1/t_m): %s"
          % (d, sp.factor(cp), d//2, ratio.is_number))
    # trailing coefficient polynomial degree check: the n^D coefficients of K_0 nonzero (order exactly d at infinity)
