# R1: checks of the closed forms used in Proposition R1:prop:small (d = 2, 3).
# Run:  python3 -I rook_closed_forms.py
# Exact truncated power series with Fractions (no CAS); constants checked with mpmath.
import sys
from fractions import Fraction
sys.path.insert(0, '.')
from rook_data import rook_flint

N = 30  # number of coefficients compared

def mul(a, b):
    r = [Fraction(0)]*N
    for i, x in enumerate(a[:N]):
        if x:
            for j, y in enumerate(b[:N - i]):
                r[i+j] += x*y
    return r

def inv(a):  # 1/a, a[0] != 0
    r = [Fraction(0)]*N
    r[0] = 1/Fraction(a[0])
    for n in range(1, N):
        r[n] = -sum(a[k]*r[n-k] for k in range(1, min(n, len(a)-1) + 1))/a[0]
    return r

def sqrt1(a):  # sqrt(a), a[0] = 1
    s = [Fraction(0)]*N
    s[0] = Fraction(1)
    for n in range(1, N):
        s[n] = (a[n] - sum(s[i]*s[n-i] for i in range(1, n)))/2
    return s

def poly(*c):
    return [Fraction(x) for x in c] + [Fraction(0)]*(N - len(c))

print("== closed forms used in Proposition R1:prop:small")
# d = 2
h = mul(poly(1, -1), inv(poly(1, -9)))
F2 = [x/2 for x in sqrt1(h)]
F2[0] += Fraction(1, 2)
seq2 = rook_flint(2, N)
print("d=2: (1+sqrt((1-t)/(1-9t)))/2 = sum a_n^(2) t^n up to t^%d:" % (N-1), all(F2[n] == seq2[n] for n in range(N)))

# d = 3 (van Hoeij's formula, Bostan-Chyzak-van Hoeij-Pech)
z = mul(poly(0, 54, -81), inv(mul(mul(poly(1, -4), poly(1, -4)), poly(1, -4))))   # 27w(2-3w)/(1-4w)^3
G = [Fraction(0)]*N
zk = poly(1)
c = Fraction(1)
for k in range(N):
    if k > 0:
        c = c*Fraction(3*k-2, 3)*Fraction(3*k-1, 3)/((k+1)*k)      # (1/3)_k (2/3)_k / ((2)_k k!)
        zk = mul(zk, z)
    G = [g + c*x for g, x in zip(G, zk)]
integrand = mul([6*x for x in G], inv(mul(poly(1, -4), poly(1, -64))))
F3 = [Fraction(1)] + [integrand[m]/(m+1) for m in range(N-1)]
seq3 = rook_flint(3, N)
print("d=3: 1 + int_0^t 6 2F1(1/3,2/3;2;z(w))/((1-4w)(1-64w)) dw = sum a_n^(3) t^n up to t^%d:" % (N-1),
      all(F3[n] == seq3[n] for n in range(N)))
lhs = [1, -12+(-54), 48+81, -64]       # (1-4w)^3 - 27w(2-3w)
rhs = [1, -66, 129, -64]               # (1-w)^2 (1-64w) expanded by hand; recomputed below
r2 = mul(mul(poly(1, -1), poly(1, -1)), poly(1, -64))
print("(1-4w)^3 - 27w(2-3w) == (1-w)^2(1-64w):", [Fraction(x) for x in lhs] == r2[:4] and all(x == 0 for x in r2[4:]))

import mpmath
mpmath.mp.dps = 40
a, b = mpmath.mpf(1)/3, mpmath.mpf(2)/3
Gf = lambda x: mpmath.hyp2f1(a, b, 2, x)
B = mpmath.gamma(2)/(mpmath.gamma(a)*mpmath.gamma(b))
print("B = Gamma(2)/(Gamma(1/3)Gamma(2/3)) = %s = sqrt(3)/(2 pi): %s" % (mpmath.nstr(B, 15), mpmath.almosteq(B, mpmath.sqrt(3)/(2*mpmath.pi), 1e-30)))
G1 = mpmath.gamma(2)*mpmath.gamma(1)/(mpmath.gamma(mpmath.mpf(5)/3)*mpmath.gamma(mpmath.mpf(4)/3))
print("G(1) = %s (Gauss), hyp2f1 at 1 = %s, nonzero" % (mpmath.nstr(G1, 15), mpmath.nstr(Gf(1), 15)))
# DLMF 15.8.10 with m=1: G(z) = A(z) + B (1-z) log(1-z) h(z), h(z) = 2F1(4/3,5/3;2;1-z).
# Check: (G(1-e) - G(1) - [analytic part to first order]) / (e log e) -> B, via two values of e.
for e in [mpmath.mpf('1e-8'), mpmath.mpf('1e-12')]:
    val = (Gf(1-e) - G1)/(e*mpmath.log(e))
    print("  (G(1-e)-G(1))/(e log e) at e=%s: %s   (B = %s; difference is O(1/log e))" % (mpmath.nstr(e, 3), mpmath.nstr(val, 10), mpmath.nstr(B, 10)))
# jump across the cut: G(x+i0) - G(x-i0) = kappa * y1(x), kappa = -2 pi i B (sign depends on orientation)
y1 = lambda x: (1-x)*mpmath.hyp2f1(mpmath.mpf(4)/3, mpmath.mpf(5)/3, 2, 1-x)
for x in [mpmath.mpf('1.5'), mpmath.mpf(3)]:
    eps = mpmath.mpf('1e-30')
    jump = Gf(x + 1j*eps) - Gf(x - 1j*eps)
    print("  x=%s: jump/(2 pi i B y1(x)) = %s" % (x, mpmath.nstr(jump/(2j*mpmath.pi*B*y1(x)), 12)))
