# R1: diagonal rook paths in d dimensions.
# a_n = [x_1^n ... x_d^n] 1/(1 - sum x_i/(1-x_i)).
# Computes a_n by two independent formulas and checks agreement.
import sys
from math import comb, factorial
from functools import lru_cache
import flint

def rook_direct(d, n):
    """Sum over compositions: a_n = sum_{k_i>=1} multinomial(|k|;k) prod binom(n-1,k_i-1)."""
    if n == 0:
        return 1
    # dynamic programming over coordinates: track total K and the weight prod binom/k_i!
    from fractions import Fraction
    # poly in s: g(s) = sum_k binom(n-1,k-1) s^k / k!  ; a_n = sum_K [g^d]_K K!
    g = {k: Fraction(comb(n-1, k-1), factorial(k)) for k in range(1, n+1)}
    cur = {0: Fraction(1)}
    for _ in range(d):
        nxt = {}
        for K, c in cur.items():
            for k, w in g.items():
                nxt[K+k] = nxt.get(K+k, 0) + c*w
        cur = nxt
    tot = sum(c*factorial(K) for K, c in cur.items())
    assert tot.denominator == 1
    return int(tot)

def rook_flint(d, N):
    """a_n for n=0..N via integer polynomials: G(s)=n! g_n(s), a_n = sum_K [G^d]_K K! / n!^d."""
    out = [1]
    facts = [1]
    for i in range(1, d*N+2):
        facts.append(facts[-1]*i)
    for n in range(1, N+1):
        coeffs = [0]*(n+1)
        for k in range(1, n+1):
            coeffs[k] = comb(n-1, k-1) * (facts[n]//facts[k])
        G = flint.fmpz_poly(coeffs)
        P = G**d
        cl = P.coeffs()
        tot = 0
        for K, c in enumerate(cl):
            if c != 0:
                tot += int(c)*facts[K]
        den = facts[n]**d
        assert tot % den == 0
        out.append(tot//den)
    return out

if __name__ == "__main__":
    for d in range(2, 6):
        seq = rook_flint(d, 12)
        chk = [rook_direct(d, n) for n in range(0, 8)]
        assert seq[:8] == chk, (d, seq[:8], chk)
        print("d=%d:" % d, seq[:10])
    # OEIS A051708 (d=2): 1, 2, 14, 106, 838, 6802, 56190, 470010, ...
    # OEIS A144045 (d=3): 1, 6, 222, 9918, 486924, ...
    print("checks against direct composition sums passed (n<8, d=2..5)")
