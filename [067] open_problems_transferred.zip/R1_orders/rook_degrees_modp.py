# R1: compute the constructive order-d recurrence of Theorem R1.1 modulo a prime p, as a recurrence
# with polynomial coefficients, by evaluating the reduction at many integers n0 (mod p) and solving
# for the polynomial coefficients (rational interpolation through linear algebra).
# Output: the minimal coefficient degree D_ours of the (primitive) constructive recurrence, to be
# compared with the degrees reported by Kauers--Zeilberger (2011, Section 5):
#   d : 2  3  4  5   6   7   8    9    10   11   12
#   deg: 1  4  9  18  31  50  75  108  149  200  261
# This is a consistency check (mod p), not part of the proof.
import sys
import flint

KZ = {2: 1, 3: 4, 4: 9, 5: 18, 6: 31, 7: 50, 8: 75, 9: 108, 10: 149, 11: 200, 12: 261}

def kernel_vector_modp(d, n0, p):
    inv = lambda x: pow(x % p, p-2, p)
    cdiag = [1]
    for i in range(d):
        cdiag.append(cdiag[-1]*(1+i) % p * inv(d-i) % p)
    nb = d + 1          # basis J(0,-d..0); index b+d
    memo = {}
    def vadd(u, v, c):
        for t in range(nb):
            if v[t]:
                u[t] = (u[t] + c*v[t]) % p
    def low(i, k):
        key = (1, i, k)
        if key in memo:
            return memo[key]
        res = [0]*nb
        if i > 0:
            vadd(res, low(i-1, k), i)
            vadd(res, J(i-1, k-1), -k)
            if i >= 2:
                vadd(res, J(i-2, k-1), -(i-1)*n0)
            c = inv(d-i+1)
            res = [x*c % p for x in res]
        memo[key] = res
        return res
    def J0(k):
        key = (0, k)
        if key in memo:
            return memo[key]
        res = [0]*nb
        if k <= 0:
            res[k+d] = 1
        else:
            rhs = [0]*nb
            vadd(rhs, J(d, k-1), k)
            vadd(rhs, J(d-1, k-1), d*n0)
            c = inv(1+d)
            rhs = [x*c % p for x in rhs]
            vadd(rhs, low(d, k), -1)
            ci = inv(cdiag[d])
            res = [x*ci % p for x in rhs]
        memo[key] = res
        return res
    def J(i, k):
        key = (2, i, k)
        if key in memo:
            return memo[key]
        if i == 0:
            res = J0(k)
        else:
            res = [x*cdiag[i] % p for x in J0(k)]
            vadd(res, low(i, k), 1)
        memo[key] = res
        return res
    def pmul(a, b):
        r = [0]*(len(a)+len(b)-1)
        for i, x in enumerate(a):
            if x:
                for j, y in enumerate(b):
                    if y:
                        r[i+j] = (r[i+j] + x*y) % p
        return r
    def padd(a, b):
        r = [0]*max(len(a), len(b))
        for i, x in enumerate(a): r[i] = (r[i]+x) % p
        for i, x in enumerate(b): r[i] = (r[i]+x) % p
        return r
    rows = []
    a, b, ap, bp = [1], [0], [0], [1]
    for j in range(d+1):
        if j > 0:
            m = n0 + j - 1
            im = inv(m+1)
            na = [x*im % p for x in padd(pmul([m % p, 1], a), pmul([0, 1], ap))]
            nbv = [x*im % p for x in padd(pmul([m % p, 1], b), pmul([0, 1], bp))]
            nap = padd(a, ap)
            nbp = padd(b, bp)
            a, b, ap, bp = na, nbv, nap, nbp
        tot = [0]*nb
        # binomial(d,i) a^{d-i} b^i
        apow = [[1]]
        for _ in range(d):
            apow.append(pmul(apow[-1], a))
        bpow = [[1]]
        for _ in range(d):
            bpow.append(pmul(bpow[-1], b))
        from math import comb
        for i in range(d+1):
            P = pmul(apow[d-i], bpow[i])
            cb = comb(d, i) % p
            for k, c in enumerate(P):
                if c:
                    vadd(tot, J(i, k), c*cb)
        assert tot[0] == 0, "coefficient of J(0,-d) nonzero"
        rows.append(tot[1:])
    M = flint.nmod_mat(rows, p)          # (d+1) x d
    MT = M.transpose()
    X, nul = MT.nullspace()
    assert nul == 1, ("kernel dimension", nul)
    c = [int(X[i, 0]) for i in range(d+1)]
    if c[d] == 0:
        return None
    ic = inv(c[d])
    return [x*ic % p for x in c]

def degree_of_recurrence(d, p=2**61-1, start=3, extra=12):
    """Find minimal D such that polynomials q_0..q_d of degree <= D with q_j(n0) = c_j(n0) q_d(n0)."""
    pts = {}
    D = max(1, KZ.get(d, 1) - 3)
    while True:
        need = ((d+1)*(D+1)) // d + extra
        n0 = start
        while len(pts) < need:
            c = kernel_vector_modp(d, n0, p)
            if c is not None:
                pts[n0] = c
            n0 += 1
        rows = []
        for n0v, c in pts.items():
            for j in range(d):
                row = [0]*((d+1)*(D+1))
                pw = 1
                for e in range(D+1):
                    row[j*(D+1)+e] = pw
                    row[d*(D+1)+e] = (-c[j]*pw) % p
                    pw = pw*n0v % p
                rows.append(row)
        A = flint.nmod_mat(rows, p)
        X, nul = A.nullspace()
        if nul >= 1:
            return D, nul, len(pts)
        D += 1

if __name__ == "__main__":
    dmax = int(sys.argv[1]) if len(sys.argv) > 1 else 7
    for d in range(2, dmax+1):
        D, nul, npts = degree_of_recurrence(d)
        print("d=%d: constructive recurrence (mod p) has minimal coefficient degree %d (nullity %d, %d sample points); KZ reported degree %s -> %s"
              % (d, D, nul, npts, KZ.get(d), "MATCH" if KZ.get(d) == D else "DIFFERENT"), flush=True)
