# R1: rigorous "soft proof" (Kauers-Zeilberger's phrase) of the guessed rook recurrences, d <= 5 (d = 6 optional).
# Run:  python3 -I rook_softproof.py          (degree-bound sanity check, then d = 2..5)
#       python3 -I rook_softproof.py 6 7      (only the listed d; slower)
#
# Logic (Proposition R1:prop:soft in section.tex):
#   V(n) is the (d+1) x d matrix with a_{n+j} = sum_b V_{j,b}(n) J_n(0,b) (proof of Theorem R1:thm:upper).
#   Lemma R1:lem:degbound: P_d(n)^d * V_{j,b}(n) * (P_d/P_j)^d ... more precisely, for any polynomial vector
#   K = (K_0..K_d) with deg K_j <= D, the function N_b(n) = P_d(n)^d * sum_j K_j(n) V_{j,b}(n)
#   (P_d(n) = (n+1)...(n+d)) is a polynomial of degree <= B_d = D + floor(d/2) + ceil(d/2) * d^2.
#   Hence: if sum_j K_j(n0) V_{j,b}(n0) = 0 for n0 = 1..B_d+1 and all b, then N_b == 0 and
#   sum_j K_j(n) a_{n+j} = 0 for EVERY n >= 1.  This script
#     (1) checks the degree bound empirically on the entries of V (sanity check of the lemma);
#     (2) reconstructs over Q the unique recurrence of order d and degree D_KZ fitting a_0..a_{N-1}
#         (nullity 1 modulo every prime used => the solution space over Q has dimension <= 1);
#     (3) checks it against all N known terms exactly, and
#     (4) checks K(n0) V(n0) = 0 exactly for n0 = 1..B_d+1, which PROVES it.
import sys
from fractions import Fraction
from math import lcm, prod
sys.path.insert(0, '.')
from rook_data import rook_flint
from rook_upper_num import reduction_vectors
from guess import nullspace_mod
from exactode import ratrecon, crt
import sympy

KZ = {2: 1, 3: 4, 4: 9, 5: 18, 6: 31, 7: 50, 8: 75, 9: 108, 10: 149, 11: 200, 12: 261}

def primes(k):
    out, p = [], 2**61
    while len(out) < k:
        p = sympy.prevprime(p)
        out.append(p)
    return out

PR = primes(40)

def exact_rec(seq, r, D):
    """Unique (nullity 1 mod each prime) recurrence of order r, degree D fitting seq; exact over Q."""
    vecs, piv = [], None
    prev = None
    for t, p in enumerate(PR):
        b = nullspace_mod(seq, r, D, p)
        assert b is not None and len(b) == 1, ("nullity", p, None if b is None else len(b))
        v = b[0]
        if piv is None:
            piv = next(i for i, c in enumerate(v) if c % p)
        assert v[piv] % p != 0
        inv = pow(v[piv], -1, p)
        vecs.append([c*inv % p for c in v])
        if t < 3:
            continue
        out = []
        for i in range(len(v)):
            x, m = crt([w[i] for w in vecs], PR[:t+1])
            f = ratrecon(x, m)
            if f is None:
                out = None
                break
            out.append(f)
        if out is not None and out == prev:
            L = 1
            for f in out:
                L = lcm(L, f.denominator)
            ints = [int(f*L) for f in out]
            return [[ints[j*(D+1)+e] for e in range(D+1)] for j in range(r+1)], t+1
        prev = out
    raise RuntimeError("rational reconstruction did not stabilise")

def ev(poly, x):
    return sum(c*x**e for e, c in enumerate(poly))

def finite_diff_degree(vals):
    """Smallest m such that the (m+1)-th finite differences of vals vanish (None if not detected)."""
    cur = list(vals)
    for m in range(len(vals) - 2):
        cur = [cur[i+1] - cur[i] for i in range(len(cur) - 1)]
        if all(x == 0 for x in cur):
            return m
    return None

def main():
    dlist = [int(x) for x in sys.argv[1:]] or [2, 3, 4, 5]

    print("== 1. sanity check of the degree bound: deg_n of P_j(n)^d V_{j,b}(n) <= floor(d/2) + ceil(d/2)*d*j")
    for d in (range(2, 5) if len(sys.argv) == 1 else []):
        e = (d + 1)//2
        M = d//2 + e*d*d + 6
        V = {n0: reduction_vectors(d, n0) for n0 in range(1, M + 1)}
        worst = []
        for j in range(d + 1):
            for b in range(d):
                vals = [Fraction(prod(range(n0 + 1, n0 + j + 1)))**d * V[n0][j][b] for n0 in range(1, M + 1)]
                dg = finite_diff_degree(vals)
                bound = d//2 + e*d*j
                worst.append((j, b, dg, bound))
                assert dg is not None and dg <= bound, (d, j, b, dg, bound)
        print("d=%d: (j, max actual degree over b, bound):" % d,
              [(j, max(w[2] for w in worst if w[0] == j), d//2 + e*d*j) for j in range(d + 1)])

    print("\n== 2-4. exact guessed recurrence and its rigorous verification")
    for d in dlist:
        D = KZ[d]
        N = (d + 1)*(D + 1) + d + 40
        seq = rook_flint(d, N)
        K, used = exact_rec(seq, d, D)
        # uniqueness also without the equation at n = 0 (in case a candidate recurrence is only claimed for n >= 1)
        b1 = nullspace_mod(seq, d, D, PR[0], nstart=1)
        null1 = None if b1 is None else len(b1)
        degs = [max((e for e, c in enumerate(K[j]) if c), default=-1) for j in range(d + 1)]
        ok_terms = all(sum(ev(K[j], n)*seq[n + j] for j in range(d + 1)) == 0 for n in range(0, N - d + 1))
        e = (d + 1)//2
        B = D + d//2 + e*d*d
        ok = True
        for n0 in range(1, B + 2):
            V = reduction_vectors(d, n0)
            Kn = [ev(K[j], n0) for j in range(d + 1)]
            for b in range(d):
                if sum(Kn[j]*V[j][b] for j in range(d + 1)) != 0:
                    ok = False
        bits = max(abs(c).bit_length() for row in K for c in row)
        print("d=%d: order %d, coefficient degrees %s (max %d = KZ degree %d), nullity 1 mod %d primes, "
              "max coefficient %d bits;" % (d, d, degs, max(degs), D, used, bits))
        print("      satisfies the fitted equations n=0..%d (terms a_0..a_%d) exactly: %s;  K(n0)V(n0)=0 for n0=1..%d (= B_d+1): %s"
              "  => PROVED for all n>=0: %s" % (N - d, N, ok_terms, B + 1, ok, ok and ok_terms))
        print("      nullity of the same system using only the equations n=1..%d (mod one prime): %s" % (N - d, null1))


if __name__ == "__main__":
    main()
