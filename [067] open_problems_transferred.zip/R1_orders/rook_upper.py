# R1: constructive proof check of the order-d recurrence for diagonal rook paths.
# a_n = int_0^oo e^{-s} l_n(s)^d ds,  l_n(s) = sum_{k>=1} binom(n-1,k-1) s^k/k!  (n>=1).
# J(i,k) = int e^{-s} s^k l^{d-i} l'^i ds; relations from integration by parts (see section.tex):
#   (1+i) J(i,k) = k J(i,k-1) + (d-i) J(i+1,k) + i n J(i-1,k-1)    (k >= i-d+1).
# Everything with k>=0 reduces to the d classes J(0,1-d),...,J(0,0); the shift
#   l_{m+1} = ((m+s) l_m + s l_m')/(m+1),  l_{m+1}' = l_m + l_m'
# expresses a_{n+j} in that span, giving d+1 vectors in Q(n)^d, hence a recurrence of order <= d.
# This script (1) checks the integration-by-parts relations numerically for actual n,
# (2) builds the recurrence symbolically over Q(n) and (3) verifies it on exact rook numbers.
import sys
from functools import lru_cache
from fractions import Fraction
from math import comb, factorial
import sympy as sp

n, s = sp.symbols('n s')

def build(d):
    # vectors are dicts: basis index b in {0..d-1} meaning J(0, b-(d-1)) -> coefficient (sympy expr in n)
    def unit(k):
        return {k + d - 1: sp.Integer(1)}
    def add(u, v, c=1):
        w = dict(u)
        for key, val in v.items():
            w[key] = sp.together(w.get(key, 0) + c*val)
        return {kk: vv for kk, vv in w.items() if vv != 0}
    def scale(u, c):
        return {kk: sp.together(c*vv) for kk, vv in u.items() if c*vv != 0}

    memoJ0 = {}
    memo = {}
    def J0(k):
        # J(0,k), k >= 1-d
        if k <= 0:
            return unit(k)
        if k in memoJ0:
            return memoJ0[k]
        # R_{d,k}: (1+d) J(d,k) = k J(d,k-1) + d n J(d-1,k-1); J(d,k) = J(0,k) + lowerpart
        rhs = add(scale(J(d, k-1), k), scale(J(d-1, k-1), d*n))
        low = Jlow(d, k)  # J(d,k) minus J(0,k)
        res = add(scale(rhs, sp.Rational(1, 1+d)), low, -1)
        memoJ0[k] = res
        return res
    def Jlow(i, k):
        # J(i,k) - c_{i,0} J(0,k), where c_{i,0}=1 for all i (shown in the proof); expressed via J(0,k'<k)
        if i == 0:
            return {}
        # J(i,k) = [ i J(i-1,k) - k J(i-1,k-1) - (i-1) n J(i-2,k-1) ] / (d-i+1)
        part = scale(Jlow(i-1, k), i)
        part = add(part, scale(J(i-1, k-1), -k))
        if i >= 2:
            part = add(part, scale(J(i-2, k-1), -(i-1)*n))
        return scale(part, sp.Rational(1, d-i+1))
    def J(i, k):
        assert k >= i - d
        if (i, k) in memo:
            return memo[(i, k)]
        if i == 0:
            res = J0(k)
        else:
            # check c_{i,0} = i/(d-i+1) * c_{i-1,0} with c_{0,0}=1 -> prod_{j=1}^{i} j/(d-j+1)
            c = sp.Integer(1)
            for j in range(1, i+1):
                c = c*sp.Rational(j, d-j+1)
            # c_{i,0} = i!(d-i)!/d!  (equals 1 only for i = d) -- use the true coefficient
            res = add(scale(J0(k), c), Jlow_true(i, k))
        memo[(i, k)] = res
        return res
    def Jlow_true(i, k):
        # J(i,k) - c_{i,0} J(0,k) computed recursively
        if i == 0:
            return {}
        part = scale(Jlow_true(i-1, k), i)
        part = add(part, scale(J(i-1, k-1), -k))
        if i >= 2:
            part = add(part, scale(J(i-2, k-1), -(i-1)*n))
        return scale(part, sp.Rational(1, d-i+1))
    return J, J0, Jlow_true

def recurrence(d):
    J, J0, Jlow_true = build(d)
    # fix J0 for k>=1 with correct c_{d,0}
    # (re-implemented here explicitly to avoid confusion)
    return J

def build_clean(d):
    """Clean implementation: J(i,k) as dict over basis J(0,1-d..0)."""
    memo = {}
    def add(u, v, c=1):
        w = dict(u)
        for key, val in v.items():
            w[key] = sp.cancel(w.get(key, 0) + c*val)
        return {kk: vv for kk, vv in w.items() if vv != 0}
    def scale(u, c):
        out = {}
        for kk, vv in u.items():
            x = sp.cancel(c*vv)
            if x != 0:
                out[kk] = x
        return out
    # c_{i,0}: coefficient of J(0,k) in J(i,k): c_{i+1,0} = (1+i)/(d-i) c_{i,0}  => c_{i,0} = binom(d,i)^{-1}... check
    cdiag = [sp.Integer(1)]
    for i in range(d):
        cdiag.append(cdiag[-1]*sp.Rational(1+i, d-i))
    # low(i,k) := J(i,k) - cdiag[i] J(0,k), depends only on J(.,k-1) etc.
    def low(i, k):
        key = ('low', i, k)
        if key in memo:
            return memo[key]
        if i == 0:
            res = {}
        else:
            # from R_{i-1,k}: i J(i-1,k) = k J(i-1,k-1) + (d-i+1) J(i,k) + (i-1) n J(i-2,k-1)
            # => J(i,k) = [ i J(i-1,k) - k J(i-1,k-1) - (i-1) n J(i-2,k-1) ]/(d-i+1)
            # low(i,k) = [ i low(i-1,k) - k J(i-1,k-1) - (i-1) n J(i-2,k-1) ]/(d-i+1)
            part = scale(low(i-1, k), i)
            part = add(part, scale(Jfull(i-1, k-1), -k))
            if i >= 2:
                part = add(part, scale(Jfull(i-2, k-1), -(i-1)*n))
            res = scale(part, sp.Rational(1, d-i+1))
        memo[key] = res
        return res
    def J0(k):
        key = ('J0', k)
        if key in memo:
            return memo[key]
        if k <= 0:
            assert k >= -d
            res = {k: sp.Integer(1)}
        else:
            # R_{d,k}: (1+d) J(d,k) = k J(d,k-1) + d n J(d-1,k-1)
            # J(d,k) = cdiag[d] J(0,k) + low(d,k)
            rhs = add(scale(Jfull(d, k-1), k), scale(Jfull(d-1, k-1), d*n))
            rhs = scale(rhs, sp.Rational(1, 1+d))
            res = scale(add(rhs, low(d, k), -1), 1/cdiag[d])
        memo[key] = res
        return res
    def Jfull(i, k):
        key = ('J', i, k)
        if key in memo:
            return memo[key]
        assert k >= i - d, (i, k, d)
        if i == 0:
            res = J0(k)
        else:
            res = add(scale(J0(k), cdiag[i]) if k >= -d else {}, low(i, k))
        memo[key] = res
        return res
    return Jfull, cdiag

def shift_coeffs(d, j):
    """(alpha_j, beta_j) polynomials in s over Q(n): l_{n+j} = alpha l_n + beta l_n'."""
    a, b = sp.Integer(1), sp.Integer(0)   # l_n = 1*l_n + 0*l_n'
    ap, bp = sp.Integer(0), sp.Integer(1) # l_n' = 0*l_n + 1*l_n'
    for step in range(j):
        m = n + step
        # l_{m+1} = ((m+s) l_m + s l_m')/(m+1) ; l_{m+1}' = l_m + l_m'
        na = sp.expand(((m+s)*a + s*ap)/(m+1))
        nb = sp.expand(((m+s)*b + s*bp)/(m+1))
        nap = sp.expand(a + ap)
        nbp = sp.expand(b + bp)
        a, b, ap, bp = na, nb, nap, nbp
    return a, b

def recurrence_from_reduction(d):
    Jfull, cdiag = build_clean(d)
    vecs = []
    for j in range(d+1):
        al, be = shift_coeffs(d, j)
        tot = {}
        for i in range(d+1):
            poly = sp.Poly(sp.expand(comb(d, i)*al**(d-i)*be**i), s)
            for (k,), c in poly.terms():
                v = Jfull(i, k)
                for key, val in v.items():
                    tot[key] = sp.cancel(tot.get(key, 0) + c*val)
        # the coefficient of J(0,-d) must vanish (proof, step 4)
        assert sp.simplify(tot.get(-d, 0)) == 0, ("J(0,-d) coefficient nonzero", d, j)
        vecs.append([tot.get(k, 0) for k in range(1-d, 1)])
    M = sp.Matrix(vecs)  # (d+1) x d
    ker = M.T.nullspace()
    assert len(ker) >= 1
    c = ker[0]
    den = sp.lcm([sp.fraction(sp.together(x))[1] for x in c])
    c = [sp.factor(sp.cancel(x*den)) for x in c]
    g = sp.Integer(0)
    for x in c:
        if x != 0:
            g = sp.gcd(g, sp.expand(x))
    c = [sp.factor(sp.cancel(x/g)) for x in c]
    return c, len(ker), M.rank()

if __name__ == "__main__":
    sys.path.insert(0, '.')
    from rook_data import rook_flint
    # (1) numeric check of the integration-by-parts identities for actual n (exact via Gamma integrals)
    def lpoly(nn):
        return [Fraction(0)] + [Fraction(comb(nn-1, k-1), factorial(k)) for k in range(1, nn+1)]
    def pmul(p, q):
        r = [Fraction(0)]*(len(p)+len(q)-1)
        for i, x in enumerate(p):
            if x:
                for j, y in enumerate(q):
                    r[i+j] += x*y
        return r
    def Jnum(d, i, k, nn):
        l = lpoly(nn)
        lp = [l[m+1]*(m+1) for m in range(len(l)-1)]
        P = [Fraction(1)]
        for _ in range(d-i):
            P = pmul(P, l)
        for _ in range(i):
            P = pmul(P, lp)
        # int e^{-s} s^k P(s) ds = sum_m P_m (m+k)!   (requires m+k>=0 for nonzero P_m)
        tot = Fraction(0)
        for m, c in enumerate(P):
            if c:
                assert m + k >= 0
                tot += c*factorial(m+k)
        return tot
    bad = 0
    cnt = 0
    for d in range(1, 6):
        for nn in range(1, 7):
            for i in range(d+1):
                for k in range(i-d+1, 5):
                    lhs = (1+i)*Jnum(d, i, k, nn)
                    rhs = k*Jnum(d, i, k-1, nn) + (d-i)*(Jnum(d, i+1, k, nn) if i < d else 0) + i*nn*(Jnum(d, i-1, k-1, nn) if i > 0 else 0)
                    cnt += 1
                    if lhs != rhs:
                        bad += 1
    print("integration-by-parts relations checked exactly: %d instances, %d failures" % (cnt, bad))
    # check a_n = J(0,0)
    for d in range(1, 6):
        seq = rook_flint(d, 8)
        assert all(Jnum(d, 0, 0, nn) == seq[nn] for nn in range(1, 8))
    print("a_n = int e^{-s} l_n^d ds verified for d=1..5, n=1..7")
    # (2) symbolic recurrence and (3) verification on data
    for d in range(2, 6):
        c, nk, rk = recurrence_from_reduction(d)
        seq = rook_flint(d, 60)
        ok = True
        for nn in range(1, 60-d):
            val = sum(sp.Integer(seq[nn+j])*c[j].subs(n, nn) for j in range(d+1))
            if val != 0:
                ok = False
                break
        degs = [sp.Poly(x, n).degree() if x != 0 else None for x in c]
        print("d=%d: reduction gives recurrence of order %d (kernel dim %d, rank %d), coefficient degrees %s, verified n=1..%d: %s"
              % (d, d, nk, rk, degs, 60-d-1, ok))
        print("   leading coeff:", c[d], " trailing:", c[0])
