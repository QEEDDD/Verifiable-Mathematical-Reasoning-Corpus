# R1: fast check of the constructive order-d recurrence (Theorem R1-rook-upper) at numeric n.
# For a fixed integer n0, all reduction coefficients are rationals; we compute the vectors
# v_j(n0) in Q^d (coordinates of a_{n0+j} in the basis J(0,1-d..0)) and the kernel vector c(n0).
# Checks performed:
#  (a) the coefficient of J(0,-d) vanishes identically (as the proof asserts);
#  (b) sum_j c_j(n0) a_{n0+j} = 0 for the exact rook numbers (independent formula);
#  (c) the kernel is one-dimensional (so the relation is unique up to scaling at n0);
#  (d) c(n0) is proportional to the coefficients of the minimal recurrence found by guessing
#      (exploration tool guess.py, computed mod p), i.e. the proven recurrence IS the guessed one.
import sys
from fractions import Fraction
from math import comb
sys.path.insert(0, '.')
from rook_data import rook_flint

def reduction_vectors(d, n0, jmax=None):
    if jmax is None:
        jmax = d
    memo = {}
    cdiag = [Fraction(1)]
    for i in range(d):
        cdiag.append(cdiag[-1]*Fraction(1+i, d-i))
    def add(u, v, c=1):
        w = dict(u)
        for key, val in v.items():
            w[key] = w.get(key, 0) + c*val
        return {kk: vv for kk, vv in w.items() if vv != 0}
    def scale(u, c):
        return {kk: c*vv for kk, vv in u.items() if c*vv != 0}
    def low(i, k):
        key = ('low', i, k)
        if key in memo:
            return memo[key]
        if i == 0:
            res = {}
        else:
            part = scale(low(i-1, k), i)
            part = add(part, scale(J(i-1, k-1), -k))
            if i >= 2:
                part = add(part, scale(J(i-2, k-1), -(i-1)*n0))
            res = scale(part, Fraction(1, d-i+1))
        memo[key] = res
        return res
    def J0(k):
        key = ('J0', k)
        if key in memo:
            return memo[key]
        if k <= 0:
            assert k >= -d
            res = {k: Fraction(1)}
        else:
            rhs = add(scale(J(d, k-1), k), scale(J(d-1, k-1), d*n0))
            rhs = scale(rhs, Fraction(1, 1+d))
            res = scale(add(rhs, low(d, k), -1), 1/cdiag[d])
        memo[key] = res
        return res
    def J(i, k):
        key = ('J', i, k)
        if key in memo:
            return memo[key]
        assert k >= i - d
        if i == 0:
            res = J0(k)
        else:
            res = add(scale(J0(k), cdiag[i]), low(i, k))
        memo[key] = res
        return res
    # shift polynomials alpha_j(s), beta_j(s) at n=n0 (lists of Fractions, index = power of s)
    def padd(p, q):
        r = [Fraction(0)]*max(len(p), len(q))
        for i, x in enumerate(p): r[i] += x
        for i, x in enumerate(q): r[i] += x
        return r
    def pmul(p, q):
        r = [Fraction(0)]*(len(p)+len(q)-1)
        for i, x in enumerate(p):
            if x:
                for j, y in enumerate(q):
                    if y:
                        r[i+j] += x*y
        return r
    vecs = []
    a, b, ap, bp = [Fraction(1)], [Fraction(0)], [Fraction(0)], [Fraction(1)]
    for j in range(jmax+1):
        if j > 0:
            m = n0 + j - 1
            # l_{m+1} = ((m+s) l_m + s l_m')/(m+1);  l_{m+1}' = l_m + l_m'
            na = [x/(m+1) for x in padd(pmul([Fraction(m), Fraction(1)], a), pmul([Fraction(0), Fraction(1)], ap))]
            nb = [x/(m+1) for x in padd(pmul([Fraction(m), Fraction(1)], b), pmul([Fraction(0), Fraction(1)], bp))]
            nap = padd(a, ap)
            nbp = padd(b, bp)
            a, b, ap, bp = na, nb, nap, nbp
        tot = {}
        for i in range(d+1):
            # binom(d,i) a^{d-i} b^i
            P = [Fraction(comb(d, i))]
            for _ in range(d-i):
                P = pmul(P, a)
            for _ in range(i):
                P = pmul(P, b)
            for k, c in enumerate(P):
                if c:
                    for key, val in J(i, k).items():
                        tot[key] = tot.get(key, 0) + c*val
        assert tot.get(-d, 0) == 0, ("coefficient of J(0,-d) nonzero", d, n0, j)
        vecs.append([tot.get(k, Fraction(0)) for k in range(1-d, 1)])
    return vecs

def kernel_vector(vecs):
    """Left kernel of the (d+1) x d matrix (rows=vecs) over Q: returns basis list."""
    import flint
    rows = len(vecs); cols = len(vecs[0])
    # solve c^T M = 0  <=> M^T c = 0 ; M^T is cols x rows
    MT = flint.fmpq_mat(cols, rows, [flint.fmpq(vecs[r][c_].numerator, vecs[r][c_].denominator) for c_ in range(cols) for r in range(rows)])
    R, rank = MT.rref()
    # nullspace from rref
    piv = []
    rr = 0
    Rl = [[R[i, j] for j in range(rows)] for i in range(cols)]
    pivcols = []
    for i in range(cols):
        for j in range(rows):
            if Rl[i][j] != 0:
                pivcols.append(j)
                break
    free = [j for j in range(rows) if j not in pivcols]
    basis = []
    for f in free:
        v = [flint.fmpq(0)]*rows
        v[f] = flint.fmpq(1)
        for i, pc in enumerate(pivcols):
            v[pc] = -Rl[i][f]
        basis.append(v)
    return basis

if __name__ == "__main__":
    import flint
    from guess import nullspace_mod, P
    for d in range(2, 8):
        seq = rook_flint(d, 40)
        okcount = 0
        for n0 in range(1, 12):
            vecs = reduction_vectors(d, n0)
            ker = kernel_vector(vecs)
            assert len(ker) == 1, (d, n0, len(ker))
            c = ker[0]
            val = sum(c[j]*seq[n0+j] for j in range(d+1))
            assert val == 0, (d, n0, val)
            okcount += 1
        print("d=%d: J(0,-d) never needed; unique relation of order <= %d at n=1..11; annihilates exact rook numbers: %d/11" % (d, d, okcount))
