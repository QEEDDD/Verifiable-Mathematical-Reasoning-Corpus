# R1 verification script for the rook-path section (section.tex, Theorems R1:thm:upper and R1:thm:largeD).
# Run:  python3 -I rook_verify.py
# Every check below is exact (integers/rationals) unless stated otherwise.
import sys
from fractions import Fraction
from math import comb, factorial, exp
sys.path.insert(0, '.')
from rook_data import rook_flint, rook_direct
from rook_upper_num import reduction_vectors, kernel_vector

def header(s):
    print("\n== " + s)

# ---------------------------------------------------------------------------------------------
header("1. rook numbers: brute-force path count vs. multinomial sum vs. integer-polynomial formula")
def rook_paths_bruteforce(d, n):
    # dynamic programming over the grid {0..n}^d, steps = positive multiples of unit vectors
    from itertools import product
    pts = sorted(product(range(n+1), repeat=d), key=sum)
    cnt = {}
    for p in pts:
        if sum(p) == 0:
            cnt[p] = 1
            continue
        tot = 0
        for i in range(d):
            for k in range(1, p[i]+1):
                q = list(p); q[i] -= k
                tot += cnt[tuple(q)]
        cnt[p] = tot
    return cnt[tuple([n]*d)]
ok = True
for d in range(1, 5):
    seq = rook_flint(d, 6)
    for n in range(0, 5 if d <= 3 else 4):
        b = rook_paths_bruteforce(d, n)
        m = rook_direct(d, n)
        ok &= (b == m == seq[n])
print("brute force = multinomial sum = flint formula (d<=4, small n):", ok)

# ---------------------------------------------------------------------------------------------
header("2. Laguerre polynomials l_n(s)=sum_k C(n-1,k-1)s^k/k!: ODE, shift identities, a_n = int e^-s l_n^d")
def lpoly(n):
    return [Fraction(0)] + [Fraction(comb(n-1, k-1), factorial(k)) for k in range(1, n+1)]
def pder(p):
    return [p[i]*i for i in range(1, len(p))] or [Fraction(0)]
def padd(*ps):
    L = max(len(p) for p in ps)
    r = [Fraction(0)]*L
    for p in ps:
        for i, x in enumerate(p):
            r[i] += x
    while len(r) > 1 and r[-1] == 0:
        r.pop()
    return r
def pscale(p, c):
    return [c*x for x in p]
def pshift(p, m):  # multiply by s^m
    return [Fraction(0)]*m + list(p)
def pmul(p, q):
    r = [Fraction(0)]*(len(p)+len(q)-1)
    for i, x in enumerate(p):
        if x:
            for j, y in enumerate(q):
                r[i+j] += x*y
    return r
ok = True
for n in range(1, 13):
    l = lpoly(n); l1 = pder(l); l2 = pder(l1)
    ode = padd(pshift(l2, 1), pshift(l1, 1), pscale(l, -n))
    ok &= all(x == 0 for x in ode)
    ln1 = lpoly(n+1)
    rhs = padd(pscale(l, n), pshift(l, 1), pshift(l1, 1))
    ok &= (padd(pscale(ln1, n+1), pscale(rhs, -1)) == [0])
    ok &= (padd(pder(ln1), pscale(padd(l, l1), -1)) == [0])
    ok &= (l[0] == 0 and l1[0] == 1)
print("s l'' + s l' - n l = 0, (n+1) l_{n+1} = (n+s) l_n + s l_n', l_{n+1}' = l_n + l_n', l(0)=0, l'(0)=1 (n<=12):", ok)
def int_es(p, k=0):
    # int_0^oo e^{-s} s^k p(s) ds
    return sum(c*factorial(m+k) for m, c in enumerate(p) if c)
ok = True
for d in range(1, 6):
    seq = rook_flint(d, 10)
    for n in range(1, 10):
        P = [Fraction(1)]
        for _ in range(d):
            P = pmul(P, lpoly(n))
        ok &= (int_es(P) == seq[n])
print("a_n^{(d)} = int_0^oo e^{-s} l_n(s)^d ds  (d<=5, 1<=n<=9):", ok)

# ---------------------------------------------------------------------------------------------
header("3. integration-by-parts relations (1+i)J(i,k) = kJ(i,k-1) + (d-i)J(i+1,k) + i n J(i-1,k-1), k>=i-d+1")
def Jnum(d, i, k, n):
    l = lpoly(n); lp = pder(l)
    P = [Fraction(1)]
    for _ in range(d-i):
        P = pmul(P, l)
    for _ in range(i):
        P = pmul(P, lp)
    tot = Fraction(0)
    for m, c in enumerate(P):
        if c:
            assert m + k >= 0
            tot += c*factorial(m+k)
    return tot
cnt = bad = 0
for d in range(1, 6):
    for n in range(1, 8):
        for i in range(d+1):
            for k in range(i-d+1, 6):
                lhs = (1+i)*Jnum(d, i, k, n)
                rhs = k*Jnum(d, i, k-1, n)
                if i < d: rhs += (d-i)*Jnum(d, i+1, k, n)
                if i > 0: rhs += i*n*Jnum(d, i-1, k-1, n)
                cnt += 1; bad += (lhs != rhs)
print("instances checked: %d, failures: %d" % (cnt, bad))

# ---------------------------------------------------------------------------------------------
header("4. the reduction (Lemma R1:lem:reduction) and the order-d relation (Theorem R1:thm:upper)")
for d in range(2, 8):
    seq = rook_flint(d, 30)
    allok = True; cd_nonzero = True; c0_nonzero = True
    for n0 in range(1, 13):
        vecs = reduction_vectors(d, n0)        # asserts the J(0,-d) coefficient vanishes
        ker = kernel_vector(vecs)
        allok &= (len(ker) == 1)
        c = ker[0]
        allok &= (sum(Fraction(int(c[j].p), int(c[j].q))*seq[n0+j] for j in range(d+1)) == 0)
        cd_nonzero &= (c[d] != 0); c0_nonzero &= (c[0] != 0)
    print("d=%d: J(0,-d) never occurs; left kernel 1-dim; relation annihilates exact rook numbers (n=1..12): %s; c_d!=0: %s; c_0!=0: %s"
          % (d, allok, cd_nonzero, c0_nonzero))

# ---------------------------------------------------------------------------------------------
header("5. comparison with the minimal-degree recurrences found by guessing (d<=5)")
from guess import nullspace_mod
from exactode import ratrecon, crt, PRIMES
from math import lcm
def exact_rec(seq, r, D, nprimes=8):
    vecs = []
    for p in PRIMES[:nprimes]:
        b = nullspace_mod(seq, r, D, p)
        assert b is not None and len(b) == 1
        v = b[0]
        piv = next(i for i, c in enumerate(v) if c % p)
        inv = pow(v[piv], -1, p)
        vecs.append([c*inv % p for c in v])
    out = []
    for i in range(len(vecs[0])):
        x, m = crt([v[i] for v in vecs], PRIMES[:nprimes])
        out.append(ratrecon(x, m))
    L = 1
    for f in out:
        L = lcm(L, f.denominator)
    ints = [int(f*L) for f in out]
    return [[ints[j*(D+1)+e] for e in range(D+1)] for j in range(r+1)]
params = {2: (1, 40), 3: (4, 80), 4: (9, 160), 5: (18, 260)}
for d, (D, N) in params.items():
    seq = rook_flint(d, N)
    P = exact_rec(seq, d, D)
    ev = lambda poly, x: sum(c*x**e for e, c in enumerate(poly))
    ok = True
    for n0 in range(1, 41):
        c = kernel_vector(reduction_vectors(d, n0))[0]
        pv = [ev(P[j], n0) for j in range(d+1)]
        # proportionality of c and pv
        for j in range(d+1):
            ok &= (Fraction(int(c[j].p), int(c[j].q))*pv[d] == Fraction(int(c[d].p), int(c[d].q))*pv[j])
    print("d=%d: guessed recurrence (order %d, degree %d) is proportional to the constructive one at n=1..40: %s" % (d, d, D, ok))

# ---------------------------------------------------------------------------------------------
header("6. Kauers-Zeilberger Section 8: w_n(d) n!^d / ((nd)! e^{n-1}) -> 1 with error O(1/d) (exact values)")
from mpmath import mp, mpf, e as E
mp.dps = 30
for n in [2, 3, 4]:
    row = []
    for d in [5, 10, 20, 40, 80]:
        # w_n(d) = sum_K [l_n^d]_K K!  computed exactly
        l = lpoly(n)
        P = [Fraction(1)]
        for _ in range(d):
            P = pmul(P, l)
        w = int(int_es(P))
        ratio = mpf(w)*mpf(factorial(n))**d/(mpf(factorial(n*d))*E**(n-1))
        row.append((d, float(ratio), float(d*(ratio-1))))
    print("n=%d: (d, ratio, d*(ratio-1)) =" % n, row)
print("(the last column stays bounded, consistent with 1 + O(1/d); the proof is in section.tex)")

# ---------------------------------------------------------------------------------------------
header("7. combinatorial identity w_n(d) = sum over words of 2^{#adjacent equal pairs} (small cases)")
from itertools import permutations
def word_sum(n, d):
    letters = []
    for i in range(d):
        letters += [i]*n
    tot = 0
    for w in set(permutations(letters)):
        A = sum(1 for t in range(len(w)-1) if w[t] == w[t+1])
        tot += 2**A
    return tot
ok = True
for (n, d) in [(1, 3), (2, 2), (2, 3), (3, 2), (2, 4)]:
    ok &= (word_sum(n, d) == rook_flint(d, n)[n])
print("identity holds for (n,d) in {(1,3),(2,2),(2,3),(3,2),(2,4)}:", ok)

print("\n(part 8, the closed forms for d=2,3, is in rook_closed_forms.py; the rigorous check of the guessed recurrences (d<=7) is in rook_softproof.py)")
