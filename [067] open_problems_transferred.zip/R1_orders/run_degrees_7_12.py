import sys
sys.path.insert(0, '.')
from rook_degrees_modp import degree_of_recurrence, KZ
for d in range(7, 13):
    D, nul, npts = degree_of_recurrence(d)
    print("d=%d: constructive recurrence (mod p) minimal coefficient degree %d (nullity %d, %d points); KZ: %s -> %s"
          % (d, D, nul, npts, KZ[d], "MATCH" if KZ[d] == D else "DIFFERENT"), flush=True)
