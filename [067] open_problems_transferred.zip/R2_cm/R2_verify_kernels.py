# R2_verify_kernels.py
# Checks the analytic facts about the Laplace kernels used in Section R2.
#   c(t) = t/(1-e^{-t})            (density of psi'(x))
#   b(t) = c'(t) = e^t(e^t-1-t)/(e^t-1)^2   (density of Phi(x)=x psi'(x)-1)
#   ell(t) = t c'(t)/c(t) = 1 - t/(e^t-1)
# (K1) (log c)'' < 0  [elementary: 4 sinh^2(t/2) > t^2]
# (K2) ell is strictly concave  <=> (t/(e^t-1))'' > 0 <=> (t-2)e^t+t+2 = sum_{k>=3}(k-2)t^k/k!
# (K3) b is strictly log-concave <=> P(s)=(s-3)e^{3s}+(2s+7)e^{2s}-(2s^2+3s+5)e^s+1 > 0,
#      whose Taylor coefficients are c_n = 3^{n-1}(n-9)+2^n(n+7)-(2n^2+n+5)
# (K4) cosh lemma: tau -> cosh(d tau/2)/cosh((d/2+k)tau) is decreasing (k>=1)
# Run: python3 -I R2_verify_kernels.py
import sympy as sp
import mpmath as mp
from fractions import Fraction

s, t = sp.symbols('s t', positive=True)
ok_all = True
def report(name, ok):
    global ok_all
    ok_all &= bool(ok)
    print(('PASS ' if ok else 'FAIL ') + name)

# (K1)
c = t/(1-sp.exp(-t))
lc2 = sp.simplify(sp.diff(sp.log(c), t, 2) - (1/(4*sp.sinh(t/2)**2) - 1/t**2))
report('(K1) (log c)\'\' == 1/(4 sinh^2(t/2)) - 1/t^2 (symbolic identity)', sp.simplify(lc2.rewrite(sp.exp)) == 0)

# (K2)
f = t/(sp.exp(t)-1)
f2 = sp.simplify(sp.diff(f, t, 2) - sp.exp(t)*((t-2)*sp.exp(t)+t+2)/(sp.exp(t)-1)**3)
report('(K2) (t/(e^t-1))\'\' == e^t[(t-2)e^t+t+2]/(e^t-1)^3', sp.simplify(f2) == 0)
ser = sp.series((t-2)*sp.exp(t)+t+2, t, 0, 12).removeO()
coeffs_ok = all(sp.Poly(ser, t).coeff_monomial(t**k) == (Fraction(k-2, 1) if k >= 3 else 0)/sp.factorial(k) for k in range(0, 12))
report('(K2) Taylor coefficients of (t-2)e^t+t+2 are (k-2)/k! for k>=3 and 0 for k<=2 (checked k<12; general by e^t series)', coeffs_ok)
ell = sp.simplify(t*sp.diff(c, t)/c)
report('(K2) ell(t) = t c\'/c == 1 - t/(e^t-1)', sp.simplify((ell - (1 - t/(sp.exp(t)-1))).rewrite(sp.exp)) == 0)

# (K3)
b = sp.exp(s)*(sp.exp(s)-1-s)/(sp.exp(s)-1)**2
report('(K3) b(t) = d/dt [t/(1-e^{-t})]', sp.simplify(sp.diff(s/(1-sp.exp(-s)), s) - b) == 0)
lb2 = sp.diff(sp.log(b), s, 2)
alt = -(1+(s-1)*sp.exp(s))/(sp.exp(s)-1-s)**2 + 2*sp.exp(s)/(sp.exp(s)-1)**2
report('(K3) (log b)\'\' == -(1+(s-1)e^s)/(e^s-1-s)^2 + 2e^s/(e^s-1)^2', sp.simplify(lb2 - alt) == 0)
P = sp.expand((1+(s-1)*sp.exp(s))*(sp.exp(s)-1)**2 - 2*sp.exp(s)*(sp.exp(s)-1-s)**2)
P_claim = (s-3)*sp.exp(3*s) + (2*s+7)*sp.exp(2*s) - (2*s**2+3*s+5)*sp.exp(s) + 1
report('(K3) P(s) == (s-3)e^{3s}+(2s+7)e^{2s}-(2s^2+3s+5)e^s+1', sp.simplify(P - P_claim) == 0)
def cn(n):
    if n == 0:
        return Fraction(-3) + 7 - 5 + 1
    return Fraction(3)**(n-1)*(n-9) + Fraction(2)**n*(n+7) - (2*n*n+n+5)
cs = [cn(n) for n in range(0, 400)]
ser = sp.series(P_claim, s, 0, 16).removeO()
match = all(sp.Rational(ser.coeff(s, n))*sp.factorial(n) == sp.Rational(cs[n].numerator, cs[n].denominator) for n in range(16))
report('(K3) Taylor coefficients n! [s^n]P equal 3^{n-1}(n-9)+2^n(n+7)-(2n^2+n+5) (n<16)', match)
report('(K3) c_n = 0 for n<=5, c_6=20, c_7=224, c_8=1512', cs[:6] == [0]*6 and cs[6] == 20 and cs[7] == 224 and cs[8] == 1512)
report('(K3) c_n > 0 for 6<=n<400 (exact integers)', all(x > 0 for x in cs[6:]))
# for n>=9: 3^{n-1}(n-9)>=0 and 2^n(n+7) > 2n^2+n+5 (since 2^n >= n^2 for n>=4 and n^2(n+7)>2n^2+n+5)
report('(K3) general n>=9: 2^n(n+7) > 2n^2+n+5 (checked via 2^n>=n^2 for n>=4 and n^3+7n^2>2n^2+n+5)',
       all(2**n >= n*n for n in range(4, 200)) and all(n**3+7*n*n > 2*n*n+n+5 for n in range(2, 200)))
# (the polynomial inequality n^3+5n^2-n-5 = (n+5)(n^2-1) > 0 holds for every n>=2)
report('(K3) identity n^3+7n^2-(2n^2+n+5) == (n+5)(n^2-1)', sp.expand(sp.Symbol('n')**3+7*sp.Symbol('n')**2-(2*sp.Symbol('n')**2+sp.Symbol('n')+5) - (sp.Symbol('n')+5)*(sp.Symbol('n')**2-1)) == 0)
# numerical spot check of log-concavity of b
mp.mp.dps = 40
bf = lambda x: mp.e**x*(mp.e**x-1-x)/(mp.e**x-1)**2
vals = [mp.diff(lambda y: mp.log(bf(y)), mp.mpf(x), 2) for x in ['0.01', '0.5', '1', '3', '7', '15', '30']]
report('(K3) numeric: (log b)\'\' < 0 at sample points ' + str([mp.nstr(v, 5) for v in vals]), all(v < 0 for v in vals))

# (K4)
mp.mp.dps = 30
okk = True
for d in range(0, 8):
    for k in range(1, 6):
        prev = None
        for tau in [mp.mpf(j)/20 for j in range(0, 200)]:
            h = mp.cosh(d*tau/2)/mp.cosh((mp.mpf(d)/2+k)*tau)
            if prev is not None and not (h < prev):
                okk = False
            prev = h
report('(K4) numeric: cosh(d tau/2)/cosh((d/2+k) tau) strictly decreasing on (0,10), d<8, 1<=k<6', okk)
print('ALL PASS' if ok_all else 'SOME CHECK FAILED')
