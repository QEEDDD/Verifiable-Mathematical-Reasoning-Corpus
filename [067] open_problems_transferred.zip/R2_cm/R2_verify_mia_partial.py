# R2_verify_mia_partial.py
# Qi, Math. Inequal. Appl. 24 (2021) 845-855, Remark 4.1 (partial answer, Proposition R2.G).
#   cG(x) = x(x psi'(x)-1) - 1/2 = L[w],  w(t) = e^t[(t-2)e^t+t+2]/(e^t-1)^3,  w(0)=1/6.
#   For (i,j) majorizing (p,q): cG_Lambda = |cG^(i) cG^(j)| - Lambda |cG^(p) cG^(q)| is CM iff Lambda <= inf_t R(t).
# Checks: R(0+) = i!j!/(p!q!), R(inf) = (i+1)!(j+1)!/((p+1)!(q+1)!), R>1 on a grid, refined min of R
# (showing Lambda_* < R(inf), i.e. R is not monotone), and (illustration) the x-ratio with its value at 0+,
# plus the sign change of the Wronskian density (why the method of Theorems R2.B/C does not apply).
import numpy as np
import mpmath as mp
from math import factorial as F
from scipy.optimize import minimize_scalar
ok_all = True
def report(name, ok):
    global ok_all
    ok_all &= bool(ok)
    print(('PASS ' if ok else 'FAIL ') + name)
xg, wg = np.polynomial.legendre.leggauss(800)
s = (xg+1)/2; ws = wg/2
def w(y):
    y = np.asarray(y, float); out = np.empty_like(y)
    sm = y < 1e-2; ys = y[sm]; out[sm] = 1/6-ys**2/60+ys**4/2016
    yl = y[~sm]; E = np.exp(-yl); out[~sm] = ((yl-2)+(yl+2)*E)*E/(1-E)**3
    return out
def we(y):   # w(y) e^{y}, stable for large y (avoids underflow); ratio R is unchanged
    y = np.asarray(y, float); out = np.empty_like(y)
    sm = y < 1e-2; ys = y[sm]; out[sm] = (1/6-ys**2/60+ys**4/2016)*np.exp(ys)
    yl = y[~sm]; E = np.exp(-yl); out[~sm] = ((yl-2)+(yl+2)*E)/(1-E)**3
    return out
def R(t, i, j, p, q):
    K = we(t*s)*we(t*(1-s))
    return np.sum(ws*s**i*(1-s)**j*K)/np.sum(ws*s**p*(1-s)**q*K)
cases = [(2, 0, 1, 1), (3, 0, 2, 1), (3, 1, 2, 2), (4, 0, 2, 2), (4, 0, 3, 1), (5, 1, 3, 3)]
for (i, j, p, q) in cases:
    R0 = F(i)*F(j)/(F(p)*F(q)); Rinf = F(i+1)*F(j+1)/(F(p+1)*F(q+1))
    grid = np.exp(np.linspace(-6, 7, 300))
    vals = np.array([R(t, i, j, p, q) for t in grid])
    k = int(np.argmin(vals))
    res = minimize_scalar(lambda lt: R(np.exp(lt), i, j, p, q), bracket=(np.log(grid[k-1]), np.log(grid[k]), np.log(grid[k+1])))
    report('(i,j;p,q)=%s: R(e^-6)=%.6f ~ R0=%.6f; R(e^7)=%.6f ~ Rinf=%.6f; min R=%.6f at t=%.2f; 1 < min R < Rinf'
           % ((i, j, p, q), vals[0], R0, vals[-1], Rinf, res.fun, np.exp(res.x)),
           abs(vals[0]-R0) < 1e-3 and abs(vals[-1]-Rinf) < 0.02*Rinf and 1 < res.fun < Rinf and vals.min() > 1)
# x-ratio illustration
mp.mp.dps = 60
def Gk(x, k):
    val = x**2*mp.polygamma(k+1, x)+2*k*x*mp.polygamma(k, x)+(k*(k-1)*mp.polygamma(k-1, x) if k >= 2 else 0)
    if k == 0:
        val -= x+mp.mpf(1)/2
    if k == 1:
        val -= 1
    return val
def mu(k):
    return mp.mpf(1)/2 if k == 0 else (mp.mpf(1) if k == 1 else mp.factorial(k)*(k-1)*mp.zeta(k))
for (i, j, p, q) in cases[:4]:
    xs = [mp.mpf(10)**e for e in [-8, -5, -3, -2, -1, -0.5, 0, 0.5, 1, 2]]
    vals = [Gk(x, i)*Gk(x, j)/(Gk(x, p)*Gk(x, q)) for x in xs]
    L = mu(i)*mu(j)/(mu(p)*mu(q))
    print('     illustration (i,j;p,q)=%s: x-ratio at x=1e-8..1e2: %s ; mu-ratio at 0+: %s' % ((i, j, p, q), [mp.nstr(v, 7) for v in vals], mp.nstr(L, 10)))
# Wronskian density sign change
def conv(e1, e2, S):
    S = np.atleast_1d(S)[:, None]; V = s[None, :]
    return S[:, 0]**(e1+e2+1)*np.sum(ws*V**e1*(1-V)**e2*w(S*V)*w(S*(1-V)), axis=1)
for (i, j, p, q) in cases[:2]:
    signs = []
    for t in [5, 20, 40, 60, 80]:
        us = t*s; a = conv(i, j, us); g = conv(p, q, t-us)
        signs.append(np.sign(np.sum(ws*a*g*(t-2*us))))
    print('     (i,j;p,q)=%s: sign of Wronskian density int alpha(u)gamma(t-u)(t-2u)du at t=5,20,40,60,80: %s' % ((i, j, p, q), signs))
print('ALL PASS' if ok_all else 'SOME CHECK FAILED')
