# R2_verify_qa2019_degrees.py
# Qi-Agarwal, J. Inequal. Appl. 2019:36, Sections 5.4-5.5 (completely monotonic degrees).
#   H2 = psi'(x) - Q7/(6x^2(1+x)^4(2+x)^2),  H3 = Q6/(24x^2(x+1)^4(x+2)) - psi'(x),
#   f_lam = psi' - lam(4+8x+5x^2)/(24x(1+x)^3(2+x)^2) - Q7/(6x^2(1+x)^4(2+x)^2) = H2 - lam*g.
# Theorem R2.E: deg H2 = 0, deg H3 = 1.   Theorem R2.F: deg f_0 = 0; 0<deg f_lam<1 (lam<0); deg(-f_mu)=1 (mu>=4).
# Checks:
#  (a) partial fractions of the rational parts; Laplace densities p_H2, p_3, p_g (symbolic + numeric Laplace check)
#  (b) exponential-polynomial identities (symbolic)
#  (c) RIGOROUS: Taylor coefficients of E3=p3'(e^t-1)^2 e^{2t}, EH2=p_H2(e^t-1)^2e^{2t},
#      E4=(4p_g-p_H2)'(e^t-1)^2 e^{2t}, dEg=p_g' e^{2t} are >=0 (exact for N<=N1, analytic tail bound N>N1)
#  (d) boundary behaviour at x->0+, and p_H2'(t)<0 for large t
import sympy as sp
import mpmath as mp
from fractions import Fraction
ok_all = True
def report(name, ok):
    global ok_all
    ok_all &= bool(ok)
    print(('PASS ' if ok else 'FAIL ') + name)

x, t, T = sp.symbols('x t T', positive=True)
R = sp.Rational
Q7 = 6*x**7+51*x**6+181*x**5+345*x**4+399*x**3+283*x**2+120*x+24
Q6 = 24*x**6+156*x**5+412*x**4+621*x**3+523*x**2+242*x+48
R2 = Q7/(6*x**2*(1+x)**4*(2+x)**2)
R3 = Q6/(24*x**2*(x+1)**4*(x+2))
g = (4+8*x+5*x**2)/(24*x*(1+x)**3*(2+x)**2)
R2pf = 1/x**2 + R(43, 6)/(x+1) - R(7, 2)/(x+1)**2 + 2/(x+1)**3 - R(1, 2)/(x+1)**4 - R(37, 6)/(x+2) - R(13, 6)/(x+2)**2
R3pf = 1/x**2 + R(13, 24)/x + R(55, 24)/(x+1) - R(15, 8)/(x+1)**2 + R(35, 24)/(x+1)**3 - R(1, 2)/(x+1)**4 - R(11, 6)/(x+2)
gpf = R(1, 24)/x - R(3, 8)/(x+1) + R(1, 8)/(x+1)**2 - R(1, 24)/(x+1)**3 + R(1, 3)/(x+2) + R(1, 6)/(x+2)**2
report('(a) partial fractions of R2, R3, g', sp.simplify(R2-R2pf) == 0 and sp.simplify(R3-R3pf) == 0 and sp.simplify(g-gpf) == 0)
# densities (inverse Laplace): 1/x^2->t, 1/x->1, (x+a)^{-k} -> t^{k-1}e^{-at}/(k-1)!
c = t/(1-sp.exp(-t))                 # psi'(x) = L[c]
A2 = R(43, 6)-R(7, 2)*t+t**2-t**3/12; B2 = R(37, 6)+R(13, 6)*t
pH2 = c - t - sp.exp(-t)*A2 + sp.exp(-2*t)*B2
P3 = R(55, 24)-R(15, 8)*t+R(35, 48)*t**2-t**3/12
p3 = t + R(13, 24) + sp.exp(-t)*P3 - R(11, 6)*sp.exp(-2*t) - c
Ag = -R(3, 8)+t/8-t**2/48; Bg = R(1, 3)+t/6
pg = R(1, 24) + sp.exp(-t)*Ag + sp.exp(-2*t)*Bg
mp.mp.dps = 30
def lap(expr, xv):
    f = sp.lambdify(t, expr, 'mpmath')
    return mp.quad(lambda s: f(s)*mp.e**(-xv*s), [0, 1, 10, 60, mp.inf])
okL = True
for xv in [mp.mpf('0.5'), mp.mpf(2), mp.mpf(7)]:
    H2v = mp.polygamma(1, xv) - sp.lambdify(x, R2, 'mpmath')(xv)
    H3v = sp.lambdify(x, R3, 'mpmath')(xv) - mp.polygamma(1, xv)
    gv = sp.lambdify(x, g, 'mpmath')(xv)
    okL &= abs(lap(pH2, xv)-H2v) < 1e-20 and abs(lap(p3, xv)-H3v) < 1e-20 and abs(lap(pg, xv)-gv) < 1e-20
report('(a) numeric Laplace transforms of p_H2, p_3, p_g reproduce H2, H3, g at x=0.5,2,7', okL)
lim0 = [sp.limit(pH2, t, 0), sp.limit(p3, t, 0), sp.limit(pg, t, 0)]
report('(a) p_H2(0)=p_3(0)=p_g(0)=0', lim0 == [0, 0, 0])

# (b) exponential polynomials, T=e^t
def to_T(expr):
    return sp.expand(sp.simplify(expr).rewrite(sp.exp).subs(sp.exp(t), T))
cT = t*T/(T-1); bT = T*(T-1-t)/(T-1)**2
E3_claim = T**3*(t**3/12-R(47, 48)*t**2+R(13, 3)*t-R(31, 6)) + T**2*(-t**3/6+R(47, 24)*t**2-R(20, 3)*t+13) + T*(t**3/12-R(47, 48)*t**2+R(10, 3)*t-R(23, 2)) + R(11, 3)
EH2_claim = T**3*(t**3/12-t**2+R(9, 2)*t-R(43, 6)) + T**2*(-t**3/6+2*t**2-R(35, 6)*t+R(41, 2)) + T*(t**3/12-t**2-R(5, 6)*t-R(39, 2)) + R(13, 6)*t+R(37, 6)
dEH2_claim = T**3*(-t**3/12+R(5, 4)*t**2-R(13, 2)*t+R(35, 3)) + T**2*(t**3/6-R(5, 2)*t**2+R(20, 3)*t-R(65, 2)) + T*(-t**3/12+R(5, 4)*t**2+R(19, 6)*t+31) - R(13, 3)*t-R(61, 6)
dEg_claim = T*(t**2/48-t/6+R(1, 2)) - t/3 - R(1, 2)
E4_claim = T**3*(t**3/12-R(7, 6)*t**2+R(35, 6)*t-R(29, 3)) + T**2*(-t**3/6+R(7, 3)*t**2-R(20, 3)*t+R(53, 2)) + T*(t**3/12-R(7, 6)*t**2-R(7, 6)*t-25) + 3*t+R(49, 6)
chk = lambda expr, claim, mult: sp.simplify(sp.expand(expr*mult).subs(sp.exp(t), T) - claim) == 0
def mul_sub(expr, mult):
    e = sp.expand(expr)
    e = e.subs(sp.exp(-t), 1/T).subs(sp.exp(-2*t), 1/T**2).subs(sp.exp(t), T)
    return sp.simplify(e*mult)
p3d = sp.diff(p3, t); pH2d = sp.diff(pH2, t); pgd = sp.diff(pg, t)
def same(expr, mult, claim):
    e = sp.expand(expr).subs({sp.exp(-2*t): T**-2, sp.exp(-t): T**-1, sp.exp(t): T})
    # remaining c, b pieces: rewrite with T
    e = e.subs({1-1/T: (T-1)/T})
    return sp.simplify(sp.together(e*mult) - claim) == 0
report('(b) p_3\'(t)(e^t-1)^2 e^{2t} == E3', same(p3d.subs(sp.exp(-t), 1/T), (T-1)**2*T**2, E3_claim))
report('(b) p_H2(t)(e^t-1)^2 e^{2t} == EH2', same(pH2.subs(sp.exp(-t), 1/T), (T-1)**2*T**2, EH2_claim))
report('(b) p_H2\'(t)(e^t-1)^2 e^{2t} == dEH2', same(pH2d.subs(sp.exp(-t), 1/T), (T-1)**2*T**2, dEH2_claim))
report('(b) p_g\'(t) e^{2t} == dEg', same(pgd.subs(sp.exp(-t), 1/T), T**2, dEg_claim))
report('(b) (4p_g-p_H2)\'(t)(e^t-1)^2 e^{2t} == E4', same((4*pgd-pH2d).subs(sp.exp(-t), 1/T), (T-1)**2*T**2, E4_claim))

# (c) rigorous Taylor-coefficient certificates
def terms_of(E):
    P = sp.Poly(sp.expand(E), T, t)
    return [(k, j, Fraction(int(sp.fraction(cf)[0]), int(sp.fraction(cf)[1]))) for (k, j), cf in P.terms()]
def falling(N, j):
    r = 1
    for i in range(j):
        r *= (N-i)
    return r
def aN(terms, N):
    a = Fraction(0)
    for k, j, q in terms:
        if j > N:
            continue
        if k == 0:
            a += q*falling(N, j) if N == j else 0
        else:
            a += q*falling(N, j)*Fraction(k)**(N-j)
    return a
def certify(name, E, N1=200):
    terms = terms_of(E)
    assert max(k for k, j, q in terms) == 3
    co = [aN(terms, N) for N in range(N1+1)]
    exact_ok = all(a >= 0 for a in co)
    first = next(N for N, a in enumerate(co) if a != 0)
    # u_k(N) = sum_j q_{kj} N^{(j)} k^{3-j}, so that a_N = sum_{k=1}^3 k^{N-3} u_k(N) for N>=2
    Ns = sp.Symbol('N')
    def ff(j):
        r = 1
        for i in range(j):
            r *= (Ns-i)
        return r
    u = {k: sp.expand(sum(sp.Rational(q.numerator, q.denominator)*ff(j)*sp.Integer(k)**(3-j) for kk, j, q in terms if kk == k)) for k in (1, 2, 3)}
    form_ok = all(Fraction(str(sum(sp.Rational(k)**(n-3)*u[k].subs(Ns, n) for k in (1, 2, 3)))) == co[n] for n in range(2, N1+1))
    # tail certificate used in the text: for N>=90, u_3(N) >= N^3/275, |u_2(N)|<=7N^3, |u_1(N)|<=N^3, (3/2)^87/275 > 8
    s = sp.Symbol('s')
    shifted = sp.Poly(sp.expand(275*u[3].subs(Ns, 90+s) - (90+s)**3), s)
    c3_ok = all(cf >= 0 for cf in shifted.all_coeffs())
    def absbound(poly):   # sup_{N>=4} |poly(N)|/N^3 <= sum_j |c_j| 4^{j-3}
        P = sp.Poly(poly, Ns)
        return sum(abs(cf)*sp.Rational(4)**(deg-3) for (deg,), cf in P.terms())
    b2 = absbound(u[2]); b1 = absbound(u[1])
    tail_ok = c3_ok and b2 <= 7 and b1 <= 1 and sp.Rational(3, 2)**87/275 > 8
    report('(c) %s: exact a_N>=0 for N<=%d (first nonzero a_%d=%s); a_N=3^{N-3}u3+2^{N-3}u2+u1 checked; tail N>=90: 275u3-N^3 has nonneg. coeffs in N-90, |u2|<=%s N^3, |u1|<=%s N^3'
           % (name, N1, first, co[first], b2, b1), exact_ok and form_ok and tail_ok)
    print('       u3 =', sp.factor(u[3]), ';  u2 =', sp.factor(u[2]), ';  u1 =', sp.factor(u[1]))
    return co
E3c = certify('E3 = p_3\'(e^t-1)^2e^{2t}', E3_claim)
EH2c = certify('EH2 = p_H2(e^t-1)^2e^{2t}', EH2_claim)
E4c = certify('E4 = (4p_g-p_H2)\'(e^t-1)^2e^{2t}', E4_claim)
N = sp.Symbol('N')
dEg_terms = terms_of(dEg_claim)
report('(c) dEg = p_g\' e^{2t}: a_0=a_1=0 and a_N=(N^2-9N+24)/48>0 for N>=2 (discriminant 81-96<0)',
       aN(dEg_terms, 0) == 0 and aN(dEg_terms, 1) == 0 and all(aN(dEg_terms, n) == Fraction(n*n-9*n+24, 48) for n in range(2, 300)))

# (d) boundary behaviour
mp.mp.dps = 40
H2 = lambda xv: mp.polygamma(1, xv) - sp.lambdify(x, R2, 'mpmath')(xv)
H3 = lambda xv: sp.lambdify(x, R3, 'mpmath')(xv) - mp.polygamma(1, xv)
gf = sp.lambdify(x, g, 'mpmath')
xs0 = mp.mpf('1e-12')
report('(d) H2(0+) = zeta(2)-37/24 = %s > 0 (so deg H2 = 0)' % mp.nstr(mp.zeta(2)-mp.mpf(37)/24, 12),
       abs(H2(xs0)-(mp.zeta(2)-mp.mpf(37)/24)) < 1e-9 and mp.zeta(2) > mp.mpf(37)/24)
report('(d) x*H3(x) -> 13/24 and x*g(x) -> 1/24 as x->0+', abs(xs0*H3(xs0)-mp.mpf(13)/24) < 1e-9 and abs(xs0*gf(xs0)-mp.mpf(1)/24) < 1e-9)
# exponential-polynomial forms (no cancellation for large t)
mp.mp.dps = 80
EH2d_f = sp.lambdify((t, T), dEH2_claim, 'mpmath'); Eg_f = sp.lambdify((t, T), dEg_claim, 'mpmath')
def pH2d_f(s):
    s = mp.mpf(s); TT = mp.e**s
    return EH2d_f(s, TT)/((TT-1)**2*TT**2)
def pgd_f(s):
    s = mp.mpf(s); TT = mp.e**s
    return Eg_f(s, TT)/TT**2
big = [mp.mpf(v) for v in [30, 100, 1000, 10000]]
rat = [(mp.nstr(pH2d_f(s)/(-s**3*mp.e**(-s)/12), 6), mp.nstr(pgd_f(s)/(s**2*mp.e**(-s)/48), 6)) for s in big]
report('(d) p_H2\'(t)/(-t^3e^{-t}/12) and p_g\'(t)/(t^2e^{-t}/48) at t=30,100,1000,10000 (-> 1 like 1-O(1/t)): %s' % rat,
       abs(pH2d_f(big[-1])/(-big[-1]**3*mp.e**(-big[-1])/12)-1) < 0.01 and abs(pgd_f(big[-1])/(big[-1]**2*mp.e**(-big[-1])/48)-1) < 0.01)
for lam in [-1, -100, -10**4]:
    s = mp.mpf(4*abs(lam)+40)
    val = pH2d_f(s) - lam*pgd_f(s)
    report('(d) lam=%d: p_{f_lam}\'(%s) = %s < 0 (so x f_lam is not CM)' % (lam, mp.nstr(s, 6), mp.nstr(val, 5)), val < 0)
# check also: for these lam, p_{f_lam}' > 0 near 0 and the first sign change location
for lam in [-1, -10, -100]:
    f = lambda s, lam=lam: pH2d_f(s) - lam*pgd_f(s)
    grid = [mp.mpf(k)/4 for k in range(1, 4*int(4*abs(lam)+60))]
    first_neg = next((s for s in grid if f(s) < 0), None)
    print('     lam=%d: p_{f_lam}\' > 0 on (0,%s), first negative grid value at t=%s' % (lam, mp.nstr(first_neg-mp.mpf(1)/4, 5), mp.nstr(first_neg, 5)))

print('ALL PASS' if ok_all else 'SOME CHECK FAILED')
