# R2_verify_remark17.py
# Qi, C. R. Math. 360 (2022), Remark 17: for m,n in N, M=m+n,
#   H_Omega = psi^{(M)} [psi^{(m)} psi^{(n)}]' - Omega psi^{(M+1)} psi^{(m)} psi^{(n)}.
# Claimed (Theorem R2.A): H_Omega CM  <=> Omega <= 1 ;  -H_Omega CM <=> Omega >= (M+2)/(M+1).
# Checks (independent of the proofs):
#  (1) x-side: (-1)^j H_1^{(j)}(x) > 0 and (-1)^j (-H_{Om*})^{(j)}(x) > 0, j=0..8, sample x
#  (2) necessity: H_{1+d}(x)<0 for large x;  -H_{Om*-d}(x)<0 for small x
#  (3) the splitting identity H_1 = |psi^(n)|[...]+|psi^(m)|[...] (connection with Qi's Theorem 1)
#  (4) the discrete (Hurwitz) identity for -H_{Om*}
#  (5) t-side: Laplace density D(t)=int_0^t alpha(u)beta(t-u)(2u-t)du > 0 on a grid; alpha/beta increasing
import mpmath as mp
import numpy as np
from math import comb, factorial
mp.mp.dps = 60
ok_all = True
def report(name, ok):
    global ok_all
    ok_all &= bool(ok)
    print(('PASS ' if ok else 'FAIL ') + name)

def pg(k, x):
    return mp.polygamma(k, x)

def triple_deriv(a, b, c, j, x):
    # j-th derivative of psi^(a) psi^(b) psi^(c)
    tot = mp.mpf(0)
    for i in range(j+1):
        for k in range(j-i+1):
            l = j-i-k
            tot += mp.mpf(factorial(j))/(factorial(i)*factorial(k)*factorial(l))*pg(a+i, x)*pg(b+k, x)*pg(c+l, x)
    return tot

def H_deriv(m, n, Om, j, x):
    M = m+n
    return triple_deriv(M, m+1, n, j, x) + triple_deriv(M, m, n+1, j, x) - Om*triple_deriv(M+1, m, n, j, x)

pairs = [(1, 1), (1, 2), (2, 2), (1, 3), (2, 3), (3, 4), (1, 6)]
xs = [mp.mpf(v) for v in ['0.02', '0.1', '0.4', '1', '2.5', '7', '20', '60']]
for (m, n) in pairs:
    M = m+n
    Ostar = mp.mpf(M+2)/(M+1)
    good1 = all((-1)**j*H_deriv(m, n, 1, j, x) > 0 for j in range(9) for x in xs)
    good2 = all((-1)**j*(-H_deriv(m, n, Ostar, j, x)) > 0 for j in range(9) for x in xs)
    report('(1) (m,n)=%s: (-1)^j H_1^(j)>0 and (-1)^j(-H_{Om*})^(j)>0, j<=8, %d points' % ((m, n), len(xs)), good1 and good2)
    d = mp.mpf('0.01')
    nec1 = H_deriv(m, n, 1+d, 0, mp.mpf(10)**4) < 0
    nec2 = -H_deriv(m, n, Ostar-d, 0, mp.mpf(10)**-4) < 0
    report('(2) (m,n)=%s: H_{1.01}(1e4)<0 and -H_{Om*-0.01}(1e-4)<0 (necessity)' % ((m, n),), nec1 and nec2)
    # (3) splitting with Qi's Theorem 1 thresholds m/M, n/M
    x = mp.mpf('0.77')
    A = lambda k: abs(pg(k, x))
    lhs = H_deriv(m, n, 1, 0, x)
    rhs = A(n)*(A(M)*A(m+1) - mp.mpf(m)/M*A(M+1)*A(m)) + A(m)*(A(M)*A(n+1) - mp.mpf(n)/M*A(M+1)*A(n))
    report('(3) (m,n)=%s: splitting identity, rel.err %s' % ((m, n), mp.nstr(abs(lhs-rhs)/abs(lhs), 3)), abs(lhs-rhs) < mp.mpf(10)**-40*abs(lhs))
    # (4) discrete identity
    Z = lambda k: mp.zeta(k+1, x)
    lhs = -H_deriv(m, n, Ostar, 0, x)
    rhs = mp.factorial(M)*mp.factorial(m)*mp.factorial(n)*((m+1)*Z(n)*(Z(M+1)*Z(m)-Z(M)*Z(m+1)) + (n+1)*Z(m)*(Z(M+1)*Z(n)-Z(M)*Z(n+1)))
    report('(4) (m,n)=%s: Hurwitz identity for -H_{Om*}, rel.err %s' % ((m, n), mp.nstr(abs(lhs-rhs)/abs(lhs), 3)), abs(lhs-rhs) < mp.mpf(10)**-40*abs(lhs))

# (5) t-side density
xg, wg = np.polynomial.legendre.leggauss(300)
u = (xg+1)/2; wu = wg/2
def cfun(s):
    s = np.asarray(s, float); out = np.empty_like(s)
    sm = s < 1e-8; out[sm] = 1+s[sm]/2
    ss = s[~sm]; out[~sm] = ss/(-np.expm1(-ss)); return out
def alpha(S, m, n):
    S = np.atleast_1d(S)[:, None]; V = u[None, :]
    return S[:, 0]**(m+n-1)*np.sum(wu*V**(m-1)*(1-V)**(n-1)*cfun(S*V)*cfun(S*(1-V)), axis=1)
for (m, n) in pairs:
    M = m+n
    ts = np.unique(np.concatenate([np.linspace(0.05, 3, 30), np.linspace(3, 120, 120)]))
    Ds = []
    for tt in ts:
        us = tt*u; a = alpha(us, m, n); bt = (tt-us)**(M-1)*cfun(tt-us)
        Ds.append(tt*np.sum(wu*a*bt*(2*us-tt))/(tt*np.sum(wu*a*bt*tt)))
    ratio = alpha(ts, m, n)/(ts**(M-1)*cfun(ts))
    report('(5) (m,n)=%s: normalized density D(t)>0 on grid (min %.3e); alpha/beta increasing' % ((m, n), min(Ds)), min(Ds) > 0 and np.all(np.diff(ratio) > 0))
print('ALL PASS' if ok_all else 'SOME CHECK FAILED')
