# R2_verify_remark18.py
# Qi, C. R. Math. 360 (2022), Remark 18: for m,n,p,q in N with (p,q) majorizing (m,n)
# (p+q=m+n, max(p,q)>max(m,n)) and
#   W_Omega = [psi^(m)psi^(n)][psi^(p)psi^(q)]' - Omega [psi^(m)psi^(n)]'[psi^(p)psi^(q)],
# Theorem R2.B: W_Omega CM <=> Omega >= 1 ; -W_Omega CM <=> Omega <= Omega_* (implicit, 0<Omega_*<1).
# Checks:
#  (1) x-side: (-1)^j W_1^{(j)}(x) > 0 for j=0..8 at sample x
#  (2) necessity of Omega>=1: W_{0.99}(x)<0 for large x
#  (3) t-side: density D(t)=int alpha(u)gamma(t-u)(2u-t)du>0 and alpha/gamma increasing (grid)
#  (4) Claim A of the proof: g=sigma_mn/sigma_pq increasing on (0,1/2]
#  (5) numerical value of Omega_* = min_t M2/M1 for small cases
import mpmath as mp
import numpy as np
from math import factorial
from itertools import product as iprod
from scipy.optimize import minimize_scalar
mp.mp.dps = 60
ok_all = True
def report(name, ok):
    global ok_all
    ok_all &= bool(ok)
    print(('PASS ' if ok else 'FAIL ') + name)

def pg(k, x):
    return mp.polygamma(k, x)

def prod_deriv(orders, j, x):
    # j-th derivative of prod_i psi^(orders[i])(x), multinomial Leibniz
    r = len(orders); tot = mp.mpf(0)
    def rec(i, left, coef, val):
        nonlocal tot
        if i == r-1:
            tot += coef/factorial(left)*val*pg(orders[i]+left, x)
            return
        for a in range(left+1):
            rec(i+1, left-a, coef/factorial(a), val*pg(orders[i]+a, x))
    rec(0, j, mp.mpf(factorial(j)), mp.mpf(1))
    return tot

def W_deriv(m, n, p, q, Om, j, x):
    return (prod_deriv((m, n, p+1, q), j, x) + prod_deriv((m, n, p, q+1), j, x)
            - Om*(prod_deriv((m+1, n, p, q), j, x) + prod_deriv((m, n+1, p, q), j, x)))

quads = [(1, 1, 2, 0), (2, 2, 3, 1), (2, 1, 3, 0), (2, 2, 4, 0), (3, 3, 4, 2), (3, 3, 5, 1), (2, 3, 4, 1), (1, 4, 2, 3), (2, 4, 5, 1)]
quads = [qq for qq in quads if min(qq) >= 1 and qq[0]+qq[1] == qq[2]+qq[3] and max(qq[2:]) > max(qq[:2])]
xs = [mp.mpf(v) for v in ['0.03', '0.2', '0.7', '1.5', '4', '12', '40']]
for (m, n, p, q) in quads:
    good = all((-1)**j*W_deriv(m, n, p, q, 1, j, x) > 0 for j in range(9) for x in xs)
    report('(1) (m,n;p,q)=%s: (-1)^j W_1^(j)(x)>0, j<=8, %d points' % ((m, n, p, q), len(xs)), good)
    report('(2) (m,n;p,q)=%s: W_0.99(1e4) < 0 (necessity of Omega>=1)' % ((m, n, p, q),), W_deriv(m, n, p, q, mp.mpf('0.99'), 0, mp.mpf(10)**4) < 0)

xg, wg = np.polynomial.legendre.leggauss(300)
u = (xg+1)/2; wu = wg/2
def cfun(s):
    s = np.asarray(s, float); out = np.empty_like(s)
    sm = s < 1e-8; out[sm] = 1+s[sm]/2
    ss = s[~sm]; out[~sm] = ss/(-np.expm1(-ss)); return out
def conv(S, m, n):  # density of (-1)^{m+n} psi^(m) psi^(n): (t^{m-1}c)*(t^{n-1}c)
    S = np.atleast_1d(S)[:, None]; V = u[None, :]
    return S[:, 0]**(m+n-1)*np.sum(wu*V**(m-1)*(1-V)**(n-1)*cfun(S*V)*cfun(S*(1-V)), axis=1)
for (m, n, p, q) in quads:
    ts = np.unique(np.concatenate([np.linspace(0.05, 3, 30), np.linspace(3, 120, 120)]))
    Ds = []; r2 = []
    for tt in ts:
        us = tt*u; a = conv(us, m, n); g = conv(tt-us, p, q)
        M1 = np.sum(wu*a*g*us); M2 = np.sum(wu*a*g*(tt-us))
        Ds.append((M1-M2)/(M1+M2)); r2.append(M2/M1)
    ratio = conv(ts, m, n)/conv(ts, p, q)
    report('(3) (m,n;p,q)=%s: normalized density D(t)>0 on grid (min %.3e), alpha/gamma increasing' % ((m, n, p, q), min(Ds)), min(Ds) > 0 and np.all(np.diff(ratio) > 0))
    # (4) Claim A
    vs = np.linspace(1e-3, 0.5, 400)
    sig = lambda a, b, v: v**(a-1)*(1-v)**(b-1)+v**(b-1)*(1-v)**(a-1)
    gg = sig(m, n, vs)/sig(p, q, vs)
    report('(4) (m,n;p,q)=%s: sigma_mn/sigma_pq increasing on (0,1/2]' % ((m, n, p, q),), np.all(np.diff(gg) > 0))
    # (5) Omega_*
    def rr(lt):
        tt = np.exp(lt); us = tt*u; a = conv(us, m, n); g = conv(tt-us, p, q)
        return np.sum(wu*a*g*(tt-us))/np.sum(wu*a*g*us)
    grid = np.linspace(-3, 6, 91); vals = [rr(z) for z in grid]; k = int(np.argmin(vals))
    res = minimize_scalar(rr, bracket=(grid[k-1], grid[k], grid[k+1]))
    print('     Omega_*(%d,%d;%d,%d) ~= %.7f attained near t=%.3f; ratio at t=e^-3: %.6f, at t=e^6: %.6f'
          % (m, n, p, q, res.fun, np.exp(res.x), vals[0], vals[-1]))
print('ALL PASS' if ok_all else 'SOME CHECK FAILED')
