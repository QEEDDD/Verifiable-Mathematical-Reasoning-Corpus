# R2_verify_yhq_remark2.py
# Yin-Han-Qi, Demonstratio Math. 57 (2024), Remark 2 (sign of the elementary function F(x,y)):
#   F(x,y) = 2(1/x - 1/(y-x)) + (1/2)(2^{y-x}/(y-x) - 2^x/x) - (2^{y-x}-2^x)/((y-x)x),  0<x<y/2.
# Proposition R2.D: x(y-x)F(x,y) = 2(x-2)(y-x-2)[ E(y-x-2) - E(x-2) ] with E(s)=(2^s-1)/s (E(0)=ln 2),
#   E strictly increasing, hence sign F = sign((x-2)(y-x-2)); F=0 iff x=2 or y=x+2.
# Checks: symbolic identity; monotonicity of E; random sampling of the sign law; the two guesses.
import sympy as sp
import random
import mpmath as mp
ok_all = True
def report(name, ok):
    global ok_all
    ok_all &= bool(ok)
    print(('PASS ' if ok else 'FAIL ') + name)
x, y = sp.symbols('x y', positive=True)
z = y - x
F = 2*(1/x - 1/z) + sp.Rational(1, 2)*(2**z/z - 2**x/x) - (2**z - 2**x)/(z*x)
u, v = x-2, z-2
ident = sp.simplify(sp.expand(x*z*F - 2*(u*(2**v-1) - v*(2**u-1))))
report('x(y-x)F == 2[(x-2)(2^{y-x-2}-1) - (y-x-2)(2^{x-2}-1)]', ident == 0)
# product form from Remark 2 of the source
Fprod = (1/x - 1/z)*(2 - sp.Rational(1, 2)*(2**z/z - 2**x/x)/(1/z - 1/x) - (2**z - 2**x)/(z - x))
report('agrees with the factorised form printed in Remark 2', sp.simplify(F - Fprod) == 0)
s = sp.symbols('s')
E = (2**s - 1)/s
dE = sp.simplify(sp.diff(E, s))
# E(s) = int_0^1 ln2 * 2^{s r} dr is strictly increasing; numeric check of E' > 0
mp.mp.dps = 30
Ef = lambda ss: (mp.mpf(2)**ss - 1)/ss if ss != 0 else mp.log(2)
okE = all(mp.diff(Ef, mp.mpf(ss)) > 0 for ss in [-30, -5, -1, -0.3, 0.2, 1, 5, 30])
report('E(s)=(2^s-1)/s strictly increasing (numeric spot check; proof: E(s)=ln2*int_0^1 2^{sr}dr)', okE)
Ff = sp.lambdify((x, y), F, 'mpmath')
random.seed(1)
okS = True; cnt = 0
for _ in range(20000):
    xx = mp.mpf(random.uniform(0.001, 30)); yy = 2*xx + mp.mpf(random.uniform(0.0001, 40))
    val = Ff(xx, yy); pred = (xx-2)*(yy-xx-2)
    if pred != 0 and abs(pred) > 1e-6:
        cnt += 1
        if mp.sign(val) != mp.sign(pred):
            okS = False
report('sign F = sign((x-2)(y-x-2)) on %d random points with 0<x<y/2' % cnt, okS)
g1 = all(Ff(mp.mpf(a), mp.mpf(b)) > 0 for a, b in [(2.01, 4.03), (2.5, 5.1), (3, 6.5), (10, 25), (2.0001, 5)])
g2 = all(Ff(mp.mpf(a), mp.mpf(b)) < 0 for a, b in [(1.99, 4.01), (0.1, 4.2), (1, 4.5), (0.5, 40), (1.999, 4.0001)])
report('guess (1): F>0 for 2<x<y/2 (samples); guess (2): F<0 for y>4, 0<x<2 (samples)', g1 and g2)
report('F(2,y)=0 identically', sp.simplify(F.subs(x, 2)) == 0)
print('ALL PASS' if ok_all else 'SOME CHECK FAILED')
