# R2_verify_yhq_remark4.py
# Yin-Han-Qi, Demonstratio Math. 57 (2024) 20240041, Remark 4: Phi(x)=x psi'(x)-1, m,n>=0, M=m+n,
#   G_Lambda = Phi^{(M+1)}[Phi^{(m)}Phi^{(n)}]' - Lambda Phi^{(M+2)} Phi^{(m)}Phi^{(n)}.
# Theorem R2.C: G_Lambda CM <=> Lambda <= 1 ; -G_Lambda CM <=> Lambda >= Lambda*_{m,n} (implicit, >1).
# Checks:
#  (1) x-side: (-1)^j G_1^{(j)}(x) > 0, j=0..8, sample x
#  (2) necessity: G_{1.01}(x) < 0 for large x
#  (3) t-side density D(t)=int alpha(u)beta(t-u)(2u-t)du>0, alpha/beta increasing (grid)
#  (4) Lambda* numerically
#  (5) the splitting identity of Remark R2:rem:C
import mpmath as mp
import numpy as np
from math import factorial
from scipy.optimize import minimize_scalar
mp.mp.dps = 60
ok_all = True
def report(name, ok):
    global ok_all
    ok_all &= bool(ok)
    print(('PASS ' if ok else 'FAIL ') + name)

def Phi(k, x):
    if k == 0:
        return x*mp.polygamma(1, x)-1
    return x*mp.polygamma(k+1, x)+k*mp.polygamma(k, x)

def prod_deriv(orders, j, x):
    r = len(orders); tot = mp.mpf(0)
    def rec(i, left, coef, val):
        nonlocal tot
        if i == r-1:
            tot += coef/factorial(left)*val*Phi(orders[i]+left, x)
            return
        for a in range(left+1):
            rec(i+1, left-a, coef/factorial(a), val*Phi(orders[i]+a, x))
    rec(0, j, mp.mpf(factorial(j)), mp.mpf(1))
    return tot

def G_deriv(m, n, Lam, j, x):
    M = m+n
    return prod_deriv((M+1, m+1, n), j, x)+prod_deriv((M+1, m, n+1), j, x)-Lam*prod_deriv((M+2, m, n), j, x)

pairs = [(0, 0), (0, 1), (1, 1), (0, 2), (1, 2), (2, 2), (0, 4), (2, 3)]
xs = [mp.mpf(v) for v in ['0.03', '0.2', '0.7', '1.5', '4', '12', '40']]
for (m, n) in pairs:
    good = all((-1)**j*G_deriv(m, n, 1, j, x) > 0 for j in range(9) for x in xs)
    report('(1) (m,n)=%s: (-1)^j G_1^(j)(x)>0, j<=8, %d points' % ((m, n), len(xs)), good)
    report('(2) (m,n)=%s: G_1.01(1e4) < 0 (necessity of Lambda<=1)' % ((m, n),), G_deriv(m, n, mp.mpf('1.01'), 0, mp.mpf(10)**4) < 0)

# (5) splitting identity of Remark R2:rem:C (connection with the Phi-majorization theorem of the 2024 survey)
okS = True
for (m, n) in pairs:
    M = m+n
    for x in [mp.mpf('0.05'), mp.mpf('0.7'), mp.mpf(3), mp.mpf(25)]:
        A = lambda k: abs(Phi(k, x))
        G1 = G_deriv(m, n, 1, 0, x)
        b1 = A(M+1)*A(m+1)-mp.mpf(m+1)/(M+2)*A(M+2)*A(m)
        b2 = A(M+1)*A(n+1)-mp.mpf(n+1)/(M+2)*A(M+2)*A(n)
        okS &= abs(G1-(A(n)*b1+A(m)*b2)) < mp.mpf(10)**-40*abs(G1) and b1 > 0 and b2 > 0
report('(5) splitting identity G_1 = |Phi^(n)| b1 + |Phi^(m)| b2 with positive brackets (all pairs, 4 points)', okS)

xg, wg = np.polynomial.legendre.leggauss(300)
u = (xg+1)/2; wu = wg/2
def bfun(s):
    s = np.asarray(s, float); out = np.empty_like(s)
    sm = s < 1e-3; ss = s[sm]; out[sm] = 0.5+ss/6-ss**3/180
    sl = s[~sm]; e = np.exp(-sl); out[~sm] = (1-e-sl*e)/(1-e)**2
    return out
def conv(S, m, n):
    S = np.atleast_1d(S)[:, None]; V = u[None, :]
    return S[:, 0]**(m+n+1)*np.sum(wu*V**m*(1-V)**n*bfun(S*V)*bfun(S*(1-V)), axis=1)
for (m, n) in pairs:
    M = m+n
    ts = np.unique(np.concatenate([np.linspace(0.05, 3, 30), np.linspace(3, 120, 120)]))
    Ds = []
    for tt in ts:
        us = tt*u; a = conv(us, m, n); bt = (tt-us)**(M+1)*bfun(tt-us)
        N1 = np.sum(wu*a*bt*us); N2 = np.sum(wu*a*bt*(tt-us))
        Ds.append((N1-N2)/(N1+N2))
    ratio = conv(ts, m, n)/(ts**(M+1)*bfun(ts))
    report('(3) (m,n)=%s: normalized density >0 on grid (min %.3e), alpha/beta increasing' % ((m, n), min(Ds)), min(Ds) > 0 and np.all(np.diff(ratio) > 0))
    def TT(lt):
        tt = np.exp(lt); us = tt*u; a = conv(us, m, n); bt = (tt-us)**(M+1)*bfun(tt-us)
        return -np.sum(wu*a*bt*us)/np.sum(wu*a*bt*(tt-us))
    grid = np.linspace(-3, 6, 91); vals = [TT(z) for z in grid]; k = int(np.argmin(vals))
    res = minimize_scalar(TT, bracket=(grid[k-1], grid[k], grid[k+1]))
    print('     Lambda*_{%d,%d} ~= %.7f attained near t=%.3f; N1/N2 at t=e^-3: %.6f, at t=e^6: %.6f'
          % (m, n, -res.fun, np.exp(res.x), -vals[0], -vals[-1]))
print('ALL PASS' if ok_all else 'SOME CHECK FAILED')
