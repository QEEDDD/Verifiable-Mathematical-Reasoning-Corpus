#!/usr/bin/env python3
# R3: exact (symbolic) verification of two explicit conjugate-reflection-symmetric potentials
# Floquet isospectral to 0 on the q-cycle, q = 5 and q = 9 (Faust et al., Conjecture 2, odd q).
# Indices are taken in Z/q with the reflection centre at site 0: V_{-j} = conj(V_j).
import sympy as sp

lam = sp.Symbol('lam')

def charpoly_cycle(q, V):
    A = sp.zeros(q, q)
    for j in range(q):
        A[j, (j+1) % q] += 1; A[(j+1) % q, j] += 1
        A[j, j] += V[j]
    return sp.expand((lam*sp.eye(q) - A).det(method='berkowitz'))

# ---------------- q = 5 ----------------
# Fourier coefficients b_h (V_j = sum_h b_h w^{h j}, w = e^{2 pi i/5}):
#   b_0 = 0, b_{1} = -t^4/(2u^3), b_{-1} = -t^6/(2u^3), b_2 = 6/(u^3 t^2), b_{-2} = -t^2/u^3,
#   with t = 24^(1/10) (t^10 = 24) and u = 5^(1/4) (u^4 = 5).  All b_h are real, so V_{-j} = conj(V_j).
t, u, w = sp.symbols('t u w')
q = 5
b = {1: -t**4/(2*u**3), -1: -t**6/(2*u**3), 2: 6/(u**3*t**2), -2: -t**2/u**3}
V = [sp.expand(sum(b[h]*w**((h*j) % q) for h in b)) for j in range(q)]
d = sp.expand(charpoly_cycle(q, V) - charpoly_cycle(q, [0]*q))
# reduce modulo the relations t^10 = 24, Phi_5(w) = 0 and u^2 = sqrt5 = 1 + 2(w + w^4) (which implies u^4 = 5);
# these hold for t = 24^(1/10) > 0, u = 5^(1/4) > 0, w = exp(2 pi i/5).
num, den = sp.fraction(sp.together(d))
G = sp.groebner([t**10 - 24, u**2 - (1 + 2*w + 2*w**4), w**4 + w**3 + w**2 + w + 1], t, u, w, lam, order='lex')
r = G.reduce(sp.expand(num))[1]
print("q=5: numerator of charpoly difference reduces to", r)
assert r == 0
# numerical sanity: the real embedding t,u>0, w=exp(2 pi i/5)
num_vals = {t: sp.Integer(24)**sp.Rational(1, 10), u: sp.Integer(5)**sp.Rational(1, 4), w: sp.exp(2*sp.pi*sp.I/5)}
Vn = [complex(sp.N(Vj.subs(num_vals), 30)) for Vj in V]
print("q=5: V =", [complex(round(z.real, 10), round(z.imag, 10)) for z in Vn])
print("q=5: conjugate-reflection symmetry V_{-j}=conj(V_j):", all(abs(Vn[(-j) % q] - Vn[j].conjugate()) < 1e-12 for j in range(q)),
      " nonzero:", max(abs(z) for z in Vn) > 0.5)

# ---------------- q = 9 ----------------
# V_0 = V_4 = V_{-4} = 0, V_1 = e^{-i pi/6}, V_2 = -e^{-i pi/6}, V_3 = -i, V_{-j} = conj(V_j).
z = sp.Symbol('z')   # z = e^{i pi/6}, Phi_12(z) = z^4 - z^2 + 1
q = 9
V = [0]*q
V[1] = z**11; V[2] = -z**11; V[3] = -z**3
V[8] = z; V[7] = -z; V[6] = z**3
d = sp.expand(charpoly_cycle(q, V) - charpoly_cycle(q, [0]*q))
r = sp.rem(sp.Poly(d, z), sp.Poly(z**4 - z**2 + 1, z))
print("q=9: charpoly difference mod Phi_12(z):", r.as_expr())
assert r.as_expr() == 0
zn = sp.exp(sp.I*sp.pi/6)
Vn = [complex(sp.N(sp.sympify(Vj).subs(z, zn))) for Vj in V]
print("q=9: V =", [complex(round(x.real, 6), round(x.imag, 6)) for x in Vn])
print("q=9: conjugate-reflection symmetry:", all(abs(Vn[(-j) % q] - Vn[j].conjugate()) < 1e-12 for j in range(q)))
print("Both explicit potentials are nonzero, conjugate-reflection symmetric, and Floquet isospectral to 0 (exact).")
