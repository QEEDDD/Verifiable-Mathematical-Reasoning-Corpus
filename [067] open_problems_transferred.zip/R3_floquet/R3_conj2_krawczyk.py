#!/usr/bin/env python3
# R3: computer-assisted existence proofs for Faust et al. Conjecture 2 (odd q).
# For odd q we look for a nonzero potential V on Z/q with V_{-j} = conj(V_j) (conjugate-reflection
# symmetry about site 0; a cyclic shift of the form (v1,...,v_m,v_{m+1},conj v_m,...,conj v_1))
# such that det(lambda - C_q - diag V) = det(lambda - C_q) (C_q = adjacency of the q-cycle).
# For a one-dimensional cycle the Floquet parameter enters only the V-independent constant term,
# so this single identity is equivalent to Floquet isospectrality of V and 0.
# Real coordinates: V_0 = r, V_j = x_j + i y_j, V_{-j} = x_j - i y_j (j=1..m).
# F(x) = Re[coefficients of lambda^{q-1},...,lambda^0 of det(lambda-C-V) - det(lambda-C)] (q equations)
# The imaginary parts vanish identically on this real slice.
# Existence is certified by the Krawczyk test in ball arithmetic (python-flint / Arb).
# For q <= 27 the test is applied to F itself; for q >= 29 to the equivalent, better-conditioned
# system E of values on a Bernstein ellipse (see below).  Each line of output "Krawczyk PASSED"
# certifies a nonzero solution for that q.
# Usage: python3 -I R3_conj2_krawczyk.py 5,7,9,...
import sys, numpy as np
from flint import arb, acb, arb_mat, acb_mat, ctx

def cycle(q):
    C = np.zeros((q, q))
    for j in range(q):
        C[j, (j+1) % q] = 1; C[(j+1) % q, j] = 1
    return C

def M_matrix(q):
    # V = M @ w, w = (r, x_1..x_m, y_1..y_m), complex q x q
    m = q // 2
    M = np.zeros((q, q), dtype=complex)
    M[0, 0] = 1
    for j in range(1, m+1):
        M[j, j] = 1; M[q-j, j] = 1
        M[j, m+j] = 1j; M[q-j, m+j] = -1j
    return M

def numeric_solution(q, seed, maxtr=400):
    rng = np.random.default_rng(seed)
    C = cycle(q); p0 = np.poly(C); M = M_matrix(q)
    def F(w):
        V = M @ w
        return np.real((np.poly(C + np.diag(V)) - p0)[1:]) / np.arange(1, q+1)
    def J(w, h=1e-7):
        Jm = np.zeros((q, q))
        for i in range(q):
            e = np.zeros(q); e[i] = h
            Jm[:, i] = (F(w+e) - F(w-e)) / (2*h)
        return Jm
    for t in range(maxtr):
        w = rng.normal(size=q) * rng.uniform(0.3, 1.5)
        for it in range(300):
            f = F(w); nf = np.linalg.norm(f)
            if nf < 1e-11: break
            dw = np.linalg.lstsq(J(w), -f, rcond=None)[0]; lam = 1.0
            while lam > 1e-6 and np.linalg.norm(F(w + lam*dw)) > nf: lam /= 2
            w = w + lam*dw
            if np.linalg.norm(w) > 50: break
        if np.linalg.norm(F(w)) < 1e-9 and np.linalg.norm(M @ w) > 0.3:
            sv = np.linalg.svd(J(w), compute_uv=False)
            if sv[-1] > 1e-6:
                return w
    return None

# ---------------------------------------------------------------------------------------------
# Second, better-conditioned formulation used for q >= 29 ("ellipse values").
# Let z_k = RHO e^{2 pi i k/q} with RHO = e^{1/q}, and lam_k = z_k + 1/z_k (k = 0..q-1): q distinct points on a Bernstein
# ellipse around [-2,2], with lam_{q-k} = conj(lam_k).  Put G(lam) = det(lam-A)/det(lam-C) - 1.
# Since det(lam-A) - det(lam-C) has degree < q, it vanishes identically iff G(lam_k) = 0 for all k.
# On the slice V_{-j} = conj(V_j) the polynomial det(lam - A) has real coefficients, so
# G(lam_{q-k}) = conj(G(lam_k)); hence the q real equations
#     E(w) = ( G(lam_0), Re G(lam_k), Im G(lam_k) : k = 1..m ) = 0
# are equivalent to Floquet isospectrality.  det(lam_k - C) = z_k^q + z_k^{-q} - 2 = e + 1/e - 2 for
# every k (balanced, nonzero), and with RHO^q = e the map from Chebyshev coefficients of the
# difference polynomial to the values G(lam_k) is well conditioned.  (An earlier version used
# RHO = 2, which is equally rigorous but badly conditioned for large q.)  Jacobian:
# dG/dV_j = -(G+1) [(lam - A)^{-1}]_{jj}.
def RHO(q):
    return np.exp(1.0 / q)

def ellipse_points_float(q):
    m = q // 2
    r = RHO(q)
    return [r * np.exp(2j * np.pi * k / q) + np.exp(-2j * np.pi * k / q) / r for k in range(m + 1)]

def numeric_solution_ellipse(q, seed, maxtr=400):
    rng = np.random.default_rng(seed)
    C = cycle(q); M = M_matrix(q); lams = ellipse_points_float(q)
    dC = [np.linalg.det(l * np.eye(q) - C) for l in lams]
    def FJ(w):
        V = M @ w; A = C + np.diag(V)
        F = np.zeros(q); J = np.zeros((q, q))
        for k, l in enumerate(lams):
            Rl = l * np.eye(q) - A
            ratio = np.linalg.det(Rl) / dC[k]
            dGw = (-ratio * np.diag(np.linalg.inv(Rl))) @ M
            G = ratio - 1
            if k == 0:
                F[0] = G.real; J[0] = dGw.real
            else:
                F[2*k-1] = G.real; J[2*k-1] = dGw.real; F[2*k] = G.imag; J[2*k] = dGw.imag
        return F, J
    for t in range(maxtr):
        w = rng.normal(size=q) * 0.8
        try:
            for it in range(80):
                f, J = FJ(w); nf = np.linalg.norm(f)
                if nf < 1e-13 or not np.isfinite(nf): break
                dw = np.linalg.lstsq(J, -f, rcond=None)[0]; lam = 1.0
                while lam > 1e-6 and not (np.linalg.norm(FJ(w + lam * dw)[0]) < nf): lam /= 2
                w = w + lam * dw
            f, J = FJ(w)
        except np.linalg.LinAlgError:
            continue
        if np.linalg.norm(f) < 1e-11 and np.linalg.norm(M @ w) > 0.3:
            sv = np.linalg.svd(J, compute_uv=False)
            if sv[-1] > 1e-12 * sv[0]:
                return w
    return None

def E_and_J(q, w_balls):
    """Arb ball evaluation of E and of its Jacobian (rigorous enclosures over ball inputs)."""
    m = q // 2
    V = [None] * q
    V[0] = acb(w_balls[0])
    for j in range(1, m + 1):
        V[j] = acb(w_balls[j], w_balls[m + j]); V[q - j] = acb(w_balls[j], -w_balls[m + j])
    Cm = cycle(q)
    Ev = [None] * q; J = arb_mat(q, q)
    pi = arb.pi()
    for k in range(m + 1):
        th = 2 * pi * k / q
        rq = (arb(1) / q).exp()                 # RHO = e^{1/q}, as a ball
        z = acb(rq * th.cos(), rq * th.sin())
        lam = z + 1 / z
        dC = z ** q + 1 / z ** q - 2          # det(lam - C_q) for lam = z + 1/z (cycle identity)
        R = acb_mat(q, q)
        for i in range(q):
            for kk in range(q):
                if Cm[i, kk] != 0:
                    R[i, kk] = acb(-1)
            R[i, i] = lam - V[i]
        ratio = R.det() / dC
        Rinv = R.inv()
        G = ratio - 1
        dG = [-ratio * Rinv[j, j] for j in range(q)]
        rowsJ = []
        dw = [dG[0]] + [dG[j] + dG[q - j] for j in range(1, m + 1)] + [acb(0, 1) * (dG[j] - dG[q - j]) for j in range(1, m + 1)]
        if k == 0:
            Ev[0] = G.real
            for i in range(q): J[0, i] = dw[i].real
        else:
            Ev[2 * k - 1] = G.real; Ev[2 * k] = G.imag
            for i in range(q):
                J[2 * k - 1, i] = dw[i].real; J[2 * k, i] = dw[i].imag
    return Ev, J

def refine_ellipse(q, w, steps=10):
    w = [arb(x) for x in w]
    for it in range(steps):
        Fm, Jm = E_and_J(q, w)
        Jmid = arb_mat([[arb(Jm[i, j].mid()) for j in range(q)] for i in range(q)])
        Fv = arb_mat([[arb(f.mid())] for f in Fm])
        dw = Jmid.solve(Fv)
        w = [arb((w[i] - dw[i, 0]).mid()) for i in range(q)]
    return w

def krawczyk_ellipse(q, w0, rho):
    rho = arb(rho)
    Fm, Jm = E_and_J(q, w0)
    Jmid = arb_mat([[arb(Jm[i, j].mid()) for j in range(q)] for i in range(q)])
    Y = Jmid.inv()
    Y = arb_mat([[arb(Y[i, j].mid()) for j in range(q)] for i in range(q)])
    Xb = [w0[i] + arb(0, rho) for i in range(q)]
    FX, JX = E_and_J(q, Xb)
    Fmv = arb_mat([[f] for f in Fm])
    Id = arb_mat([[arb(1) if i == j else arb(0) for j in range(q)] for i in range(q)])
    D = arb_mat([[Xb[i] - w0[i]] for i in range(q)])
    K = arb_mat([[w0[i]] for i in range(q)]) - Y * Fmv + (Id - Y * JX) * D
    shrink = rho * arb("0.99")
    ok = all((K[i, 0] - w0[i] > -shrink) and (K[i, 0] - w0[i] < shrink) for i in range(q))
    return ok, max(float(K[i, 0].rad()) for i in range(q))

def ball_vec(vals, rad=0):
    return [arb(v, rad) if rad else arb(v) for v in vals]

def charpoly_coeffs(A):
    # A: acb_mat; returns list of acb coefficients of det(lambda - A), leading first
    p = A.charpoly()
    cs = p.coeffs()  # low to high
    return list(reversed(cs))

def F_and_J(q, w_balls):
    # w_balls: list of arb (balls); returns F (list of arb) and J (arb_mat q x q)
    m = q // 2
    # build V as acb
    V = [None]*q
    V[0] = acb(w_balls[0])
    for j in range(1, m+1):
        V[j] = acb(w_balls[j], w_balls[m+j]); V[q-j] = acb(w_balls[j], -w_balls[m+j])
    C = cycle(q)
    A = acb_mat(q, q)
    A0 = acb_mat(q, q)
    for i in range(q):
        for k in range(q):
            if C[i, k] != 0:
                A[i, k] = acb(1); A0[i, k] = acb(1)
        A[i, i] = V[i]
    c = charpoly_coeffs(A); c0 = charpoly_coeffs(A0)
    Fv = [(c[k] - c0[k]).real for k in range(1, q+1)]
    # Jacobian dc_k/dV_j = - [lambda^{q-k}] det(lambda - A_{\hat j})  (k=1..q)
    dV = []
    for j in range(q):
        idx = [i for i in range(q) if i != j]
        Aj = acb_mat(q-1, q-1)
        for a, ia in enumerate(idx):
            for b2, ib in enumerate(idx):
                Aj[a, b2] = A[ia, ib]
        cj = charpoly_coeffs(Aj)   # degree q-1, leading 1
        # coefficient of lambda^{q-k} in det(lambda - A_j): cj index (k-1)
        dV.append([-cj[k-1] for k in range(1, q+1)])
    J = arb_mat(q, q)
    for k in range(q):
        # w-derivatives
        J[k, 0] = dV[0][k].real
        for j in range(1, m+1):
            J[k, j] = (dV[j][k] + dV[q-j][k]).real
            J[k, m+j] = (acb(0, 1)*(dV[j][k] - dV[q-j][k])).real
    return Fv, J

def krawczyk(q, w0, rho):
    # Krawczyk test on the box X = w0 + [-rho, rho]^q (all operations in Arb ball arithmetic).
    # w0: list of arb with zero radius (exact high-precision centres). rho: positive float/str.
    # If K(X) is contained in the interior of X, F has a unique zero in X (Krawczyk/Moore).
    rho = arb(rho)
    Fm, Jm = F_and_J(q, w0)
    Jmid = arb_mat([[arb(Jm[i, j].mid()) for j in range(q)] for i in range(q)])
    Y = Jmid.inv()
    Y = arb_mat([[arb(Y[i, j].mid()) for j in range(q)] for i in range(q)])   # exact approximate inverse
    Xb = [w0[i] + arb(0, rho) for i in range(q)]                               # the box
    FX, JX = F_and_J(q, Xb)
    Fmv = arb_mat([[f] for f in Fm])
    Id = arb_mat([[arb(1) if i == j else arb(0) for j in range(q)] for i in range(q)])
    D = arb_mat([[Xb[i] - w0[i]] for i in range(q)])
    K = arb_mat([[w0[i]] for i in range(q)]) - Y*Fmv + (Id - Y*JX)*D
    ok = True
    shrink = rho * arb("0.99")
    for i in range(q):
        dev = K[i, 0] - w0[i]
        if not ((dev > -shrink) and (dev < shrink)):
            ok = False
    width = max(float(K[i, 0].rad()) for i in range(q))
    return ok, width

def refine(q, w, steps=8):
    # Newton refinement in Arb (centres kept exact, radii dropped)
    w = [arb(x) for x in w]
    for it in range(steps):
        Fm, Jm = F_and_J(q, w)
        Jmid = arb_mat([[arb(Jm[i, j].mid()) for j in range(q)] for i in range(q)])
        Fv = arb_mat([[arb(f.mid())] for f in Fm])
        dw = Jmid.solve(Fv)
        w = [arb((w[i] - dw[i, 0]).mid()) for i in range(q)]
    return w

if __name__ == "__main__":
    qs = [int(a) for a in sys.argv[1].split(",")]
    ctx.prec = 400
    for q in qs:
        if q >= 29:
            # ellipse-value formulation (equivalent system, better conditioned for large q)
            w = numeric_solution_ellipse(q, seed=q)
            if w is None:
                print("q=%d: no numerical solution found" % q, flush=True); continue
            wv = refine_ellipse(q, [float(x) for x in w], steps=6)
            resE = max(abs(float(f.mid())) for f in E_and_J(q, wv)[0])
            ok = False
            for rho in ["1e-30", "1e-40", "1e-50", "1e-60"]:
                ok, width = krawczyk_ellipse(q, wv, rho)
                if ok: break
            wf = [float(x.mid()) for x in wv]
            # independent residual check in the original coefficient formulation (not needed for rigour)
            resC = max(abs(float(f.mid())) for f in F_and_J(q, wv)[0]) if q <= 45 else float("nan")
            print("q=%d: [ellipse system] residual %.2e (coefficient residual %.2e), Krawczyk %s (rho=%s), |w|=%.4f, V_0=%.6f, V_1=%.6f%+.6fi"
                  % (q, resE, resC, "PASSED" if ok else "failed", rho, np.linalg.norm(wf), wf[0], wf[1], wf[q//2+1]), flush=True)
            print("   w =", [round(x, 12) for x in wf], flush=True)
            continue
        w = numeric_solution(q, seed=q)
        if w is None:
            print("q=%d: no numerical solution found" % q, flush=True); continue
        wv = refine(q, [float(x) for x in w], steps=8)
        res = max(abs(float(f.mid())) for f in F_and_J(q, wv)[0])
        ok = False
        for rho in ["1e-30", "1e-40", "1e-50", "1e-60"]:
            ok, width = krawczyk(q, wv, rho)
            if ok: break
        wf = [float(x.mid()) for x in wv]
        print("q=%d: residual %.2e, Krawczyk %s (rho=%s), |w|=%.4f, V_0=%.6f, V_1=%.6f%+.6fi"
              % (q, res, "PASSED" if ok else "failed", rho, np.linalg.norm(wf), wf[0], wf[1], wf[q//2+1]), flush=True)
        print("   w =", [round(x, 12) for x in wf], flush=True)
