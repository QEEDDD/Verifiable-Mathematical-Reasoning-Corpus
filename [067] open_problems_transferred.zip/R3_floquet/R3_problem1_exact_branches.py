#!/usr/bin/env python3
"""R3, Problem 1 of Faust et al. (arXiv:2602.08304), planar case: EXACT rigidity check for the
Hermite-normal-form lattices Gamma = <(a,0),(b,c)> of a given index N = a*c with g1 = gcd(a,b) <= 3
and g2 = c <= 3, modulo the symmetries of Z^2, assuming Theorem R3:thm:structure (proved).

Logic (fully rigorous given the theorem):
  * By (i)-(iii) and 1D rigidity of periods <= 3, the Fourier coefficients b_h vanish for h in
    K1 u K2 u H_D u H_A (in d = 2 this is everything with h1 = 1 or h2 = 1 or h1 = h2^{+-1}).
  * The remaining ("allowed") h come in inverse pairs {h, h^-1}; by (iv) at least one member of
    each pair has b = 0.  A "branch" is a choice of the surviving member in every pair.
  * Symmetry reduction: the Galois group of Q(zeta_L)/Q (exponents e -> k e) and the lattice
    symmetries T in GL_2(Z) (signed permutations with T Gamma = Gamma; e -> T e) permute the
    branch ideals (see branch_orbit_representatives); one branch per orbit is checked.  This
    includes V(n) -> V(-n), i.e. k = -1.
  * For every branch we take the characteristic-polynomial identity
        det(lambda - D(x) - B) = det(lambda - D(x))      (plane-wave form, Lemma R3:lem:planewave)
    at a few random rational points x, with B built from the surviving b's, over the cyclotomic
    field Q(zeta_L), L = a*c (exact arithmetic in Singular with minpoly Phi_L).  If the resulting
    ideal has total length (dp) equal to its local length at the origin (ds), its only zero over C
    is b = 0.  Rigorous criterion used: the quotient is finite-dimensional and every variable is
    nilpotent modulo the ideal (tested by repeated squaring and exact normal forms); for small N
    the total length (dp) is also compared with the local length at the origin (ds).
  * If all branches pass, the lattice admits no nonzero potential Floquet isospectral to 0.
Lattices with no allowed pairs are rigid by the theorem alone (Corollary R3:cor:criterion type).
Usage:  python3 -I R3_problem1_exact_branches.py Nmin Nmax [npoints|auto] [local_max]
        python3 -I R3_problem1_exact_branches.py controls
"""
import sys, math, random, itertools, subprocess, os, time
from fractions import Fraction
import sympy

def igcdex(x, y):
    """(s, t, g) with s*x + t*y = g = gcd(x, y) >= 0."""
    s0, t0, r0, s1, t1, r1 = 1, 0, x, 0, 1, y
    while r1 != 0:
        q = r0 // r1
        s0, s1 = s1, s0 - q * s1; t0, t1 = t1, t0 - q * t1; r0, r1 = r1, r0 - q * r1
    if r0 < 0:
        s0, t0, r0 = -s0, -t0, -r0
    return s0, t0, r0

def hnf(v1, v2):
    """HNF (a,b,c) of the lattice spanned by integer vectors v1, v2: <(a,0),(b,c)>, 0 <= b < a."""
    det = abs(v1[0] * v2[1] - v1[1] * v2[0])
    s, t, g = igcdex(v1[1], v2[1])               # s*v1[1] + t*v2[1] = g
    g, s, t = int(g), int(s), int(t)
    if g < 0:
        g, s, t = -g, -s, -t
    c = g
    a = det // c
    bvec = (s * v1[0] + t * v2[0], s * v1[1] + t * v2[1])
    assert bvec[1] == c
    return (a, bvec[0] % a, c)

def canonical(a, b, c):
    """Smallest HNF among the images of <(a,0),(b,c)> under the 8 symmetries of the square."""
    best = None
    for perm in [(0, 1), (1, 0)]:
        for s0 in (1, -1):
            for s1 in (1, -1):
                def T(v):
                    w = (v[perm[0]] * s0, v[perm[1]] * s1)
                    return w
                h = hnf(T((a, 0)), T((b, c)))
                if best is None or h < best:
                    best = h
    return best

def group(a, b, c):
    L = a * c
    return L, [((c * j) % L, (-b * j + a * l) % L) for j in range(a) for l in range(c)]

def classify(a, b, c):
    L, H = group(a, b, c)
    K1 = [h for h in H if h[1] == 0]; K2 = [h for h in H if h[0] == 0]
    HD = [h for h in H if h[0] == h[1]]; HA = [h for h in H if (h[0] + h[1]) % L == 0]
    bad = set(K1) | set(K2) | set(HD) | set(HA)
    allowed = [h for h in H if h not in bad]
    pairs, seen = [], set()
    for h in allowed:
        if h in seen:
            continue
        mh = ((-h[0]) % L, (-h[1]) % L)
        assert mh != h
        seen.add(h); seen.add(mh); pairs.append((h, mh))
    return L, H, pairs

def singular_script(a, b, c, S, npts, seed, local=True):
    L, H = group(a, b, c); N = len(H)
    rnd = random.Random(seed)
    Phi = sympy.Poly(sympy.cyclotomic_poly(L, sympy.Symbol('w')), sympy.Symbol('w'))
    minpoly = str(Phi.as_expr()).replace("**", "^")
    Sidx = {s: i for i, s in enumerate(S)}
    v = ",".join("b%d" % i for i in range(len(S)))
    lines = ["ring r = (0,w),(%s,l),dp;" % v, "minpoly = %s;" % minpoly, "option(redSB);",
             "ideal I; matrix M[%d][%d]; matrix M0[%d][%d]; poly d; int k; matrix cf;" % (N, N, N, N)]
    off = []
    for i, xi in enumerate(H):
        for j, eta in enumerate(H):
            h = ((xi[0] - eta[0]) % L, (xi[1] - eta[1]) % L)
            if h in Sidx:
                off.append("M[%d,%d]=-b%d;" % (i + 1, j + 1, Sidx[h]))
    wp = lambda e: "w^%d" % (e % L) if e % L else "1"
    for t in range(npts):
        x1 = Fraction(rnd.randint(2, 30), rnd.randint(2, 30)); x2 = Fraction(rnd.randint(2, 30), rnd.randint(2, 30))
        if x1 == 1: x1 = Fraction(7, 3)
        if x2 == 1: x2 = Fraction(5, 11)
        fx = lambda q: "(%d/%d)" % (q.numerator, q.denominator)
        diag = []
        for i, xi in enumerate(H):
            D = "%s*%s+%s*%s+%s*%s+%s*%s" % (fx(x1), wp(xi[0]), fx(1 / x1), wp(-xi[0]),
                                             fx(x2), wp(xi[1]), fx(1 / x2), wp(-xi[1]))
            diag.append("M[%d,%d]=l-(%s); M0[%d,%d]=l-(%s);" % (i + 1, i + 1, D, i + 1, i + 1, D))
        lines.append("M=0;M0=0;" + "".join(diag) + "".join(off))
        lines.append("d = det(M)-det(M0); cf = coeffs(d,l); for(k=1;k<=nrows(cf);k++){I = I + cf[k,1];}")
    lines.append("ring s = (0,w),(%s),dp; minpoly = %s; option(redSB); ideal I = imap(r,I); ideal J = std(I); int tot = vdim(J);" % (v, minpoly))
    # nilpotency of every variable modulo J (J is a standard basis, so reduce() decides membership):
    # f_k = NF(var^(2^k)) by repeated squaring; var is nilpotent iff f_k = 0 once 2^k > tot.
    lines.append("int nil = 1; int e; poly f; int m; if (tot < 0) {nil = 0;} else { for(e=1;e<=nvars(basering);e++){ f = var(e); m = 1; while (m <= tot) { f = reduce(f*f, J); m = 2*m; } if (f != 0) {nil=0;} } }")
    if local:
        lines.append("ring t = (0,w),(%s),ds; minpoly = %s; ideal I = imap(s,I); ideal J = std(I); int mu = vdim(J);" % (v, minpoly))
    else:
        lines.append("int mu = -2;")
    lines.append('print("RESULT tot="+string(tot)+" mu0="+string(mu)+" nilpotent="+string(nil));')
    lines.append("quit;")
    return "\n".join(lines)

def run_branch(a, b, c, S, npts, seed=1, local=True):
    fn = "R3_tmp_%d_%d_%d_%d.sing" % (a, b, c, os.getpid())
    open(fn, "w").write(singular_script(a, b, c, S, npts, seed, local))
    out = subprocess.run(["Singular", "-q", fn], capture_output=True, text=True).stdout
    os.remove(fn)
    res = [l for l in out.splitlines() if "RESULT" in l]
    if not res:
        return None
    r = res[0]
    tot = int(r.split("tot=")[1].split()[0]); mu = int(r.split("mu0=")[1].split()[0]); nil = int(r.split("nilpotent=")[1])
    return tot, mu, nil

def lattice_symmetries(a, b, c):
    """Signed permutation matrices T (as 2x2 tuples) with T(Gamma) = Gamma."""
    out = []
    for perm in [(0, 1), (1, 0)]:
        for s0 in (1, -1):
            for s1 in (1, -1):
                T = lambda v: (v[perm[0]] * s0, v[perm[1]] * s1)
                if hnf(T((a, 0)), T((b, c))) == (a, b, c):
                    out.append((perm, s0, s1))
    return out

def branch_orbit_representatives(a, b, c, pairs):
    """Branches up to the group generated by the Galois action e -> k e (k a unit mod L) and the
    dual action e -> T e of the lattice symmetries T.  Both map branch ideals to branch ideals
    (Galois: sigma_k(I_S) = I_{kS} after renaming variables, since the sample points x are
    rational; T: V -> V o T^{-1} preserves isospectrality and maps b_e to b_{Te}).  Having only
    the origin as a zero is invariant under both, so one branch per orbit suffices."""
    L = a * c
    units = [k for k in range(1, L) if math.gcd(k, L) == 1] if L > 1 else [1]
    syms = lattice_symmetries(a, b, c)
    def act(k, sym, e):
        perm, s0, s1 = sym
        f = (e[perm[0]] * s0, e[perm[1]] * s1)
        return ((k * f[0]) % L, (k * f[1]) % L)
    reps, seen = [], set()
    for choice in itertools.product([0, 1], repeat=len(pairs)):
        S = tuple(sorted(pairs[i][choice[i]] for i in range(len(pairs))))
        if S in seen:
            continue
        orbit = {tuple(sorted(act(k, sym, e) for e in S)) for k in units for sym in syms}
        seen |= orbit
        reps.append(list(S))
    return reps

def check_lattice(a, b, c, npts, local):
    L, H, pairs = classify(a, b, c)
    if not pairs:
        return "rigid by Theorem R3:thm:structure alone (no allowed pairs)"
    t0 = time.time(); worst = 0
    reps = branch_orbit_representatives(a, b, c, pairs)
    for S in reps:
        ok = False
        for n in (npts, 2 * npts, 4 * npts):
            r = run_branch(a, b, c, S, n, 1, local)
            # rigorous criterion: finite length and every variable nilpotent (only zero = origin);
            # when the local length mu0 is computed it must also equal the total length.
            if r is not None and r[0] >= 0 and r[2] == 1 and (not local or r[0] == r[1]):
                ok = True; worst = max(worst, r[0]); break
        if not ok:
            return "NOT DECIDED on branch %s (last result %s)" % (S, r)
    return "EXACT: all %d branches (%d orbit representatives checked%s) have only the zero solution over C (max length %d) [%.1fs]" % (
        2 ** len(pairs), len(reps), ", total = local length" if local else ", nilpotency", worst, time.time() - t0)

def controls():
    """Sanity controls of the Singular pipeline on rectangular lattices qZ+Z, where the free set is
    K1 minus {1} (no structure-theorem constraints): nonzero solutions must be detected for q = 4, 5
    (one-dimensional periods >= 4 are not rigid) and none for q = 3."""
    for q, expect in [(4, False), (5, False), (3, True)]:
        S = [(e, 0) for e in range(1, q)]
        tot, mu, nil = run_branch(q, 0, 1, S, 3)
        only0 = tot >= 0 and tot == mu and nil == 1
        assert (tot == mu) == (nil == 1), "nilpotency test and length test disagree"
        print("control %dZ+Z (free set K1\\{1}): total length %d, local length at 0 %d -> %s  [%s]"
              % (q, tot, mu, "only zero" if only0 else "NONZERO SOLUTIONS",
                 "as expected" if only0 == expect else "UNEXPECTED"), flush=True)

if __name__ == "__main__":
    if sys.argv[1] == "controls":
        controls(); sys.exit(0)
    Nmin, Nmax = int(sys.argv[1]), int(sys.argv[2])
    npts_arg = sys.argv[3] if len(sys.argv) > 3 else "auto"      # "auto" = N + 8 sample points
    local_max = int(sys.argv[4]) if len(sys.argv) > 4 else 10     # compute local lengths for N <= local_max
    print("Exact branch check, Theorem R3:thm:structure assumed; sample points: %s; local lengths for N <= %d"
          % (npts_arg, local_max), flush=True)
    for N in range(Nmin, Nmax + 1):
        classes = {}
        for c in (1, 2, 3):
            if N % c:
                continue
            a = N // c
            for b in range(a):
                if math.gcd(a, b) > 3:
                    continue
                classes.setdefault(canonical(a, b, c), []).append((a, b, c))
        npts = N + 8 if npts_arg == "auto" else int(npts_arg)
        for rep in sorted(classes):
            a, b, c = rep
            assert math.gcd(a, b) <= 3 and c <= 3
            print("N=%d lattice <(%d,0),(%d,%d)>  [class of %s]: %s" % (N, a, b, c, classes[rep], check_lattice(a, b, c, npts, N <= local_max)), flush=True)
