#!/usr/bin/env python3
"""R3, Problem 1 of Faust et al. (arXiv:2602.08304), planar case: MODULAR EVIDENCE (not a proof).
Same branch decomposition as R3_problem1_exact_branches.py (which see for the logic), but each branch
ideal (characteristic-polynomial identity at N+8 random Floquet points) is treated over F_p for a
prime p = 1 mod L (L = a*c), so that the L-th roots of unity lie in F_p.  The test is whether every
variable is nilpotent modulo the ideal, i.e. whether the origin is the only zero over the algebraic
closure of F_p.  A complex solution could reduce to 0 modulo an unlucky prime, so this is evidence.
This is a standalone copy of explore/branch2d.py + explore/branch2d_fast.py (same logic), which
produced explore/sweep_9_22.log and explore/sweep_fast_12_19.log.
Usage:  python3 -I R3_problem1_modp_branches.py Nmin Nmax
"""
import sys, math, random, itertools, subprocess, os, time
import sympy

def group(a, b, c):
    L = a * c
    return L, [((c * j) % L, (-b * j + a * l) % L) for j in range(a) for l in range(c)]

def classify(a, b, c):
    L, H = group(a, b, c)
    K1 = [h for h in H if h[1] == 0]; K2 = [h for h in H if h[0] == 0]
    HD = [h for h in H if h[0] == h[1]]; HA = [h for h in H if (h[0] + h[1]) % L == 0]
    bad = set(K1) | set(K2) | set(HD) | set(HA)
    allowed = [h for h in H if h not in bad]
    pairs, seen = [], set()
    for h in allowed:
        if h in seen:
            continue
        mh = ((-h[0]) % L, (-h[1]) % L)
        seen.add(h); seen.add(mh); pairs.append((h, mh))
    return L, H, pairs

def find_prime(L):
    p = 1000003
    while True:
        p = sympy.nextprime(p)
        if (p - 1) % L == 0:
            return p

def script(a, b, c, S, p, nx, seed=1):
    L, H = group(a, b, c); N = len(H)
    g = sympy.primitive_root(p); z = pow(g, (p - 1) // L, p)
    rnd = random.Random(seed)
    Sidx = {s: i for i, s in enumerate(S)}
    v = ",".join("b%d" % i for i in range(len(S)))
    lines = ["ring r = %d,(%s,l),dp;" % (p, v), "option(redSB);",
             "ideal I; matrix M[%d][%d]; matrix M0[%d][%d]; poly d; int k; matrix cf;" % (N, N, N, N)]
    off = "".join("M[%d,%d]=-b%d;" % (i + 1, j + 1, Sidx[((xi[0] - eta[0]) % L, (xi[1] - eta[1]) % L)])
                  for i, xi in enumerate(H) for j, eta in enumerate(H)
                  if ((xi[0] - eta[0]) % L, (xi[1] - eta[1]) % L) in Sidx)
    for t in range(nx):
        x1 = rnd.randrange(2, p - 1); x2 = rnd.randrange(2, p - 1)
        ix1 = pow(x1, p - 2, p); ix2 = pow(x2, p - 2, p)
        diag = []
        for i, xi in enumerate(H):
            D = (x1 * pow(z, xi[0], p) + ix1 * pow(z, (-xi[0]) % L, p)
                 + x2 * pow(z, xi[1], p) + ix2 * pow(z, (-xi[1]) % L, p)) % p
            diag.append("M[%d,%d]=l-(%d); M0[%d,%d]=l-(%d);" % (i + 1, i + 1, D, i + 1, i + 1, D))
        lines.append("M=0;M0=0;" + "".join(diag) + off)
        lines.append("d = det(M)-det(M0); cf = coeffs(d,l); for(k=1;k<=nrows(cf);k++){I = I + cf[k,1];}")
    lines.append("ring s = %d,(%s),dp; option(redSB); ideal I = imap(r,I); ideal J=std(I); int tot=vdim(J);" % (p, v))
    lines.append("int nil=1; int e; if (tot < 0) {nil = 0;} else { for(e=1;e<=nvars(basering);e++){ if (reduce(var(e)^(tot+1),J)!=0) {nil=0;} } }")
    lines.append('print("RESULT tot="+string(tot)+" onlyorigin="+string(nil));')
    lines.append("quit;")
    return "\n".join(lines)

def check_lattice(a, b, c):
    L, H, pairs = classify(a, b, c)
    if not pairs:
        return "rigid by Theorem R3:thm:structure alone (no allowed pairs)"
    p = find_prime(L); bad = []; t0 = time.time(); maxtot = 0
    for choice in itertools.product([0, 1], repeat=len(pairs) - 1):
        choice = (0,) + choice
        S = [pairs[i][choice[i]] for i in range(len(pairs))]
        fn = "R3_tmpp_%d_%d_%d_%d.sing" % (a, b, c, os.getpid())
        open(fn, "w").write(script(a, b, c, S, p, len(H) + 8))
        out = subprocess.run(["Singular", "-q", fn], capture_output=True, text=True).stdout
        os.remove(fn)
        res = [l for l in out.splitlines() if "RESULT" in l]
        if not res:
            bad.append((S, "noresult")); continue
        tot = int(res[0].split("tot=")[1].split()[0]); oo = int(res[0].split("onlyorigin=")[1])
        maxtot = max(maxtot, tot)
        if oo != 1:
            bad.append((S, tot))
    return "mod p=%d: %d branches, %s (max length %d) [%.1fs]" % (
        p, 2 ** (len(pairs) - 1), "origin is the only zero in every branch" if not bad else "NOT RIGID MOD p: %s" % bad,
        maxtot, time.time() - t0)

if __name__ == "__main__":
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from R3_problem1_exact_branches import canonical
    Nmin, Nmax = int(sys.argv[1]), int(sys.argv[2])
    for N in range(Nmin, Nmax + 1):
        classes = {}
        for c in (1, 2, 3):
            if N % c:
                continue
            a = N // c
            for b in range(a):
                if math.gcd(a, b) <= 3:
                    classes.setdefault(canonical(a, b, c), []).append((a, b, c))
        for rep in sorted(classes):
            a, b, c = rep
            print("N=%d lattice <(%d,0),(%d,%d)> [class of %s]: %s" % (N, a, b, c, classes[rep], check_lattice(a, b, c)), flush=True)
