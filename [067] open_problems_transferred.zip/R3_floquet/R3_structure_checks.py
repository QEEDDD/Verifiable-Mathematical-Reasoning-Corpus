#!/usr/bin/env python3
"""R3: numerical sanity checks for the plane-wave lemma and the first-order structure theorem
(Theorem R3:thm:structure) on 2D lattices Gamma = <(a,0),(b,c)>.  These checks are independent
of the proofs: they test the formulas used in them on explicit examples.
Prints PASS/FAIL lines."""
import numpy as np, itertools, math
rng = np.random.default_rng(2026)

def sites(a, b, c):
    return [(r1, r2) for r2 in range(c) for r1 in range(a)]

def reduce_pt(n, a, b, c):
    n1, n2 = n
    k2 = n2 // c; r2 = n2 - c*k2
    n1p = n1 - k2*b
    k1 = n1p // a; r1 = n1p - a*k1
    return (r1, r2), (k1, k2)

def floquet_position(a, b, c, V, z):
    """Floquet matrix in position space with Bloch conditions f(n+(a,0))=z1 f(n), f(n+(b,c))=z2 f(n)."""
    S = sites(a, b, c); idx = {s: i for i, s in enumerate(S)}; N = len(S)
    L = np.zeros((N, N), dtype=complex)
    for s in S:
        i = idx[s]
        L[i, i] += V[s]
        for e in [(1, 0), (-1, 0), (0, 1), (0, -1)]:
            r, k = reduce_pt((s[0]+e[0], s[1]+e[1]), a, b, c)
            L[i, idx[r]] += z[0]**k[0] * z[1]**k[1]
    return L

def dual_group(a, b, c):
    """H = {h : h1^a = 1, h1^b h2^c = 1}, as complex pairs."""
    H = []
    for j in range(a):
        h1 = np.exp(2j*np.pi*j/a)
        for l in range(c):
            h2 = np.exp(2j*np.pi*(-b*j/(a*c) + l/c))
            H.append((h1, h2))
    return H

def fourier(a, b, c, V, H):
    S = sites(a, b, c); N = len(S)
    return [sum(V[s]*h[0]**(-s[0])*h[1]**(-s[1]) for s in S)/N for h in H]

def planewave(H, bvec, x):
    N = len(H)
    D = np.diag([x[0]*h[0] + 1/(x[0]*h[0]) + x[1]*h[1] + 1/(x[1]*h[1]) for h in H])
    B = np.zeros((N, N), dtype=complex)
    for i, zt in enumerate(H):
        for k, xi in enumerate(H):
            q = (zt[0]/xi[0], zt[1]/xi[1])
            for l, h in enumerate(H):
                if abs(h[0]-q[0]) < 1e-9 and abs(h[1]-q[1]) < 1e-9:
                    B[i, k] = bvec[l]
    return D, B

def report(name, ok):
    print(("PASS " if ok else "FAIL ") + name)

# 1. plane-wave lemma on random lattices / potentials
for (a, b, c) in [(5, 2, 1), (4, 1, 2), (3, 1, 3), (6, 3, 2)]:
    S = sites(a, b, c); V = {s: complex(*rng.normal(size=2)) for s in S}
    H = dual_group(a, b, c); bv = fourier(a, b, c, V, H)
    x = (np.exp(0.3+0.7j), np.exp(-0.2+1.1j))
    z = (x[0]**a, x[0]**b * x[1]**c)                     # z_i = x^{gamma_i}
    p1 = np.poly(floquet_position(a, b, c, V, z))
    D, B = planewave(H, bv, x)
    p2 = np.poly(D + B)
    report("plane-wave lemma: char polys agree for lattice (%d,%d,%d)" % (a, b, c),
           np.max(np.abs(p1-p2)) < 1e-8*max(1, np.max(np.abs(p1))))

# 2. a known non-rectangular isospectral example: Gamma=<(8,0),(4,1)> subset 4Z+Z, V(n)=W(n1)
W = [1+1j, 1-1j, -1+1j, -1-1j]                       # [FLMPRTTZ] support-four potential, period 4
a, b, c = 8, 4, 1
S = sites(a, b, c); V = {s: W[s[0] % 4] for s in S}
okiso = True
for t in range(5):
    z = (np.exp(complex(*rng.normal(size=2))), np.exp(complex(*rng.normal(size=2))))
    pV = np.poly(floquet_position(a, b, c, V, z)); p0 = np.poly(floquet_position(a, b, c, {s: 0 for s in S}, z))
    okiso &= np.max(np.abs(pV-p0)) < 1e-8*np.max(np.abs(p0))
report("example V(n)=W(n1) on <(8,0),(4,1)> is Floquet isospectral to 0", okiso)
H = dual_group(a, b, c); bv = fourier(a, b, c, V, H)
HD = [k for k, h in enumerate(H) if abs(h[0]-h[1]) < 1e-9]
HA = [k for k, h in enumerate(H) if abs(h[0]*h[1]-1) < 1e-9]
Hc = [k for k, h in enumerate(H) if abs(h[0]-1) > 1e-9 and abs(h[1]-1) > 1e-9]
report("(iii) b vanishes on H_D and H_A for this example", max(abs(bv[k]) for k in HD+HA) < 1e-12)
inv = {k: [l for l, g in enumerate(H) if abs(g[0]*H[k][0]-1) < 1e-9 and abs(g[1]*H[k][1]-1) < 1e-9][0] for k in range(len(H))}
report("(iv) pair products vanish on H-circ for this example", max([abs(bv[k]*bv[inv[k]]) for k in Hc] + [0]) < 1e-12)
report("(i) mean zero", abs(bv[[k for k, h in enumerate(H) if abs(h[0]-1) < 1e-9 and abs(h[1]-1) < 1e-9][0]]) < 1e-12)

# 3. (iv) Rayleigh-Schroedinger second-order formula (used in the proof), random b on a lattice
a, b, c = 7, 2, 1
H = dual_group(a, b, c); N = len(H)
bv = list(rng.normal(size=N) + 1j*rng.normal(size=N)); bv[0] = 0   # H[0]=(1,1), mean zero
avec = np.array([0.7+0.2j, -0.4+0.9j])
def branch(eps):
    x = (avec[0]/eps, avec[1]/eps)
    D, B = planewave(H, bv, x)
    ev = np.linalg.eigvals((D+B)*eps)
    alpha1 = avec[0]+avec[1]
    return ev[np.argmin(abs(ev-alpha1))]
eps = 1e-3
second = (branch(eps) - (avec[0]+avec[1]))/eps**2
beta1 = 1/avec[0] + 1/avec[1]
L = lambda h: avec[0]*(1-h[0]) + avec[1]*(1-h[1])
rs = beta1 + sum(bv[inv_k]*bv[k]/L(H[k]) for k in range(1, N)
                 for inv_k in [[l for l, g in enumerate(H) if abs(g[0]*H[k][0]-1) < 1e-9 and abs(g[1]*H[k][1]-1) < 1e-9][0]])
report("(iv) second-order RS coefficient matches numerics (rel.err %.1e)" % (abs(second-rs)/abs(rs)), abs(second-rs)/abs(rs) < 1e-2)

# 4. (iii) mechanism: on the hyperplane a.xi0 = 0 the bounded eigenvalues approach eig(B_PP)
a, b, c = 12, 5, 1        # H_D has 6 elements here
H = dual_group(a, b, c); N = len(H)
HD = [k for k, h in enumerate(H) if abs(h[0]-h[1]) < 1e-9]
bv = list(rng.normal(size=N) + 1j*rng.normal(size=N)); bv[0] = 0
a0 = np.array([1.0, -1.0])                     # a.(1,1) = 0 : fibre through xi0 = 1 is H_D
s = 1e5
D, B = planewave(H, bv, (s*a0[0], s*a0[1]))
ev = np.linalg.eigvals(D+B)
bounded = sorted(ev[np.abs(ev) < 50], key=lambda z: (z.real, z.imag))
BPP = B[np.ix_(HD, HD)]
evP = sorted(np.linalg.eigvals(BPP), key=lambda z: (z.real, z.imag))
ok = len(bounded) == len(HD) and max(min(abs(e-f) for f in bounded) for e in evP) < 1e-3
report("(iii) bounded eigenvalues of D(s a)+B -> eig(B_PP) on the diagonal fibre (|P|=%d)" % len(HD), ok)

# 5. (ii) averaging: leading coefficient as x2 -> infinity equals the 1D Floquet charpoly of the average
a, b, c = 6, 2, 3                            # g1 = gcd(6,2) = 2, so K1 = mu_2
S = sites(a, b, c); V = {s: complex(*rng.normal(size=2)) for s in S}
H = dual_group(a, b, c); bv = fourier(a, b, c, V, H)
x1 = np.exp(0.4+0.3j); s = 1e6
# group with xi_2 = 1 is K1 = {(+-1,1)} (projection lattice p_2(Gamma) = 2Z)
D, B = planewave(H, bv, (x1, s))
ev = np.linalg.eigvals(D+B)
near = sorted(ev[np.abs(ev - s) < 1e3] - s, key=lambda z: (z.real, z.imag))
K1 = [k for k, h in enumerate(H) if abs(h[1]-1) < 1e-9]
# averaged 1D potential on Z/2 has Fourier coefficients b|_{K1}; its 1D Floquet matrix at x1:
Hk = [H[k] for k in K1]
M = np.diag([x1*h[0]+1/(x1*h[0]) for h in Hk]).astype(complex)
for i, zt in enumerate(Hk):
    for j, xi in enumerate(Hk):
        q = zt[0]/xi[0]
        M[i, j] += [bv[k] for k in K1 if abs(H[k][0]-q) < 1e-9][0]
evM = sorted(np.linalg.eigvals(M), key=lambda z: (z.real, z.imag))
report("(ii) eigenvalues near x2 = s converge to the 1D averaged Floquet spectrum",
       len(near) == len(evM) and max(abs(p-q) for p, q in zip(near, evM)) < 1e-4)
