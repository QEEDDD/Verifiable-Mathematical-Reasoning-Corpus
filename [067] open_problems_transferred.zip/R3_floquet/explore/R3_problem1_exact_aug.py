#!/usr/bin/env python3
"""R3: exact (over Q) proof that 0 is the only Floquet-isospectral-to-0 potential for a planar
lattice Gamma = <(a,0),(b,c)> with gcd(a,b) <= 3 and c <= 3, assuming Theorem R3:thm:structure.

Rigorous logic.  Let I_full be the ideal of all spectral invariants, i.e. all coefficients in
lambda and z of det(lambda-L_V(z)) - det(lambda-L_0(z)), in Q[V].  Put
  J = (charpoly identities at a few random rational z) + L + Q,
where
  L = linear forms forced by Theorem R3.10 (i)-(iii) and by 1D rigidity for periods g_j <= 3:
      the sums of V over the fibres of n -> n1 mod g1, n -> n2 mod c, n -> n1+n2 mod |H_D|,
      n -> n1-n2 mod |H_A| all vanish,
  Q = the autocorrelations R(u) = sum_n V(n) V(n+u), u in G.  These vanish because
      b_h b_{h^{-1}} = 0 for all h: by (iv) on H-circ, and because b_h = 0 elsewhere.
Every isospectral V is a zero of J.  If V(J) = {0}, then V(I_full) = {0}.
We test V(J) = {0} by an exact Groebner basis over Q in Singular: vdim(J) equals the local
multiplicity at 0, computed both globally (dp) and locally (ds)."""
import sys, math, random, subprocess, os, time
from fractions import Fraction

def sites(a, b, c):
    return [(r1, r2) for r2 in range(c) for r1 in range(a)]

def reduce_pt(n, a, b, c):
    n1, n2 = n
    k2 = n2 // c; r2 = n2 - c*k2
    n1p = n1 - k2*b
    k1 = n1p // a; r1 = n1p - a*k1
    return (r1, r2), (k1, k2)

def group_sizes(a, b, c):
    # |H_D| = #{h: h1 = h2}, |H_A| = #{h: h1 h2 = 1} computed from the dual description
    L = a*c
    H = [((c*j) % L, (-b*j + a*l) % L) for j in range(a) for l in range(c)]
    hd = sum(1 for h in H if h[0] == h[1]); ha = sum(1 for h in H if (h[0]+h[1]) % L == 0)
    return hd, ha

def script(a, b, c, nz=3, seed=7):
    S = sites(a, b, c); idx = {s: i+1 for i, s in enumerate(S)}; N = len(S)
    g1 = math.gcd(a, b); hd, ha = group_sizes(a, b, c)
    rnd = random.Random(seed)
    lines = ["ring r = 0,(v(1..%d),l),dp;" % N, "option(redSB);", "ideal J; matrix M[%d][%d]; matrix M0[%d][%d]; poly d; int k; matrix cf;" % (N, N, N, N)]
    for t in range(nz):
        z1 = Fraction(rnd.randint(2, 97), rnd.randint(2, 97)); z2 = Fraction(rnd.randint(2, 97), rnd.randint(2, 97))
        ent = {}
        for s in S:
            for e in [(1, 0), (-1, 0), (0, 1), (0, -1)]:
                rr, kk = reduce_pt((s[0]+e[0], s[1]+e[1]), a, b, c)
                val = z1**kk[0] * z2**kk[1]
                ent[(idx[s], idx[rr])] = ent.get((idx[s], idx[rr]), Fraction(0)) + val
        lines.append("M = 0; M0 = 0;")
        for (i, j), val in ent.items():
            lines.append("M[%d,%d] = M[%d,%d] - (%d/%d); M0[%d,%d] = M0[%d,%d] - (%d/%d);" % (i, j, i, j, val.numerator, val.denominator, i, j, i, j, val.numerator, val.denominator))
        for i in range(1, N+1):
            lines.append("M[%d,%d] = M[%d,%d] + l - v(%d); M0[%d,%d] = M0[%d,%d] + l;" % (i, i, i, i, i, i, i, i, i))
        lines.append("d = det(M) - det(M0); cf = coeffs(d, l); for (k=1;k<=nrows(cf);k++) { J = J + cf[k,1]; }")
    # linear fibre sums
    def fibre_sums(keyfun, mod):
        groups = {}
        for s in S:
            groups.setdefault(keyfun(s) % mod, []).append(idx[s])
        return ["+".join("v(%d)" % i for i in g) for g in groups.values()]
    lin = []
    lin += fibre_sums(lambda s: s[0], g1)      # n1 mod g1 is well defined on G since g1 | a, g1 | b
    lin += fibre_sums(lambda s: s[1], c)       # n2 mod c
    # n1+n2 mod |H_D| and n1-n2 mod |H_A| are well defined on G (the subgroups' annihilators)
    lin += fibre_sums(lambda s: s[0]+s[1], hd)
    lin += fibre_sums(lambda s: s[0]-s[1], ha)
    lines.append("J = J + ideal(%s);" % ",".join(lin))
    # autocorrelations
    G = S
    def add(s, u):
        rr, _ = reduce_pt((s[0]+u[0], s[1]+u[1]), a, b, c); return rr
    quad = []
    for u in G:
        if u == (0, 0):
            continue
        quad.append("+".join("v(%d)*v(%d)" % (idx[s], idx[add(s, u)]) for s in S))
    quad.append("+".join("v(%d)^2" % idx[s] for s in S))
    lines.append("J = J + ideal(%s);" % ",".join(quad))
    lines.append("ring s = 0,(v(1..%d)),dp; option(redSB); ideal J = imap(r,J); ideal G = std(J); int tot = vdim(G);" % N)
    lines.append("ring t = 0,(v(1..%d)),ds; ideal J = imap(r,J); ideal G = std(J); int mu = vdim(G);" % N)
    lines.append('print("RESULT (%d,%d,%d) N=%d total=" + string(tot) + " local=" + string(mu));' % (a, b, c, N))
    lines.append("quit;")
    return "\n".join(lines)

def check(a, b, c):
    fn = "aug_%d_%d_%d.sing" % (a, b, c)
    open(fn, "w").write(script(a, b, c))
    t0 = time.time()
    out = subprocess.run(["Singular", "-q", fn], capture_output=True, text=True, timeout=100000).stdout
    os.remove(fn)
    res = [l for l in out.splitlines() if "RESULT" in l]
    if not res:
        return "(%d,%d,%d): no result" % (a, b, c)
    r = res[0]
    tot = int(r.split("total=")[1].split()[0]); mu = int(r.split("local=")[1])
    verdict = "ONLY V=0 (exact)" if tot == mu and tot >= 0 else "NOT DECIDED"
    return r + "  -> " + verdict + "  [%.1fs]" % (time.time()-t0)

if __name__ == "__main__":
    Nmin, Nmax = int(sys.argv[1]), int(sys.argv[2])
    for N in range(Nmin, Nmax+1):
        for c in (1, 2, 3):
            if N % c:
                continue
            a = N // c
            for b in range(a):
                if math.gcd(a, b) > 3:
                    continue
                if c == 1 and 2*b > a:
                    continue          # reflection n1 -> -n1 maps HNF (a,b,1) to (a,a-b,1)
                print(check(a, b, c), flush=True)
