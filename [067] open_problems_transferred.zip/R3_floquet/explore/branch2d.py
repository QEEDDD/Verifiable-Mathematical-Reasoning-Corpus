# Branch checker for 2D lattice Gamma=<(a,0),(b,c)>, Fourier picture over F_p.
# Proven constraints: b vanishes on K1,K2 (when g1,g2<=3), on H_D, H_A; b_h b_{-h}=0.
# For each maximal branch S (one of each inverse pair), build Singular script computing
# whether the char-poly identity forces b_S = 0.
import sys, math, random, itertools, sympy
def group(a,b,c):
    L=a*c
    H=[]
    for j in range(a):
        for l in range(c):
            H.append(((c*j)%L, (-b*j+a*l)%L))
    return L,H
def classify(a,b,c):
    L,H=group(a,b,c)
    zero=(0,0)
    K1=[h for h in H if h[1]==0]          # h2=1
    K2=[h for h in H if h[0]==0]          # h1=1
    HD=[h for h in H if h[0]==h[1]]       # h1=h2
    HA=[h for h in H if (h[0]+h[1])%L==0] # h1 h2 =1
    bad=set(K1)|set(K2)|set(HD)|set(HA)
    allowed=[h for h in H if h not in bad]
    pairs=[]; seen=set()
    for h in allowed:
        if h in seen: continue
        mh=((-h[0])%L,(-h[1])%L)
        seen.add(h); seen.add(mh)
        assert mh!=h, "self-inverse allowed element?"
        pairs.append((h,mh))
    return L,H,K1,K2,HD,HA,allowed,pairs
def find_prime(L):
    p=1000003
    while True:
        p=sympy.nextprime(p)
        if (p-1)%L==0: return p
def singular_branch(a,b,c,S,p,nx=None,seed=1):
    L,H=group(a,b,c); N=len(H)
    idx={h:i for i,h in enumerate(H)}
    g=sympy.primitive_root(p); z=pow(g,(p-1)//L,p)  # primitive L-th root of unity mod p
    rnd=random.Random(seed)
    if nx is None: nx=3*N+5
    lines=[]
    lines.append("ring r = %d,(%s,l),dp;"%(p, ",".join("b%d"%i for i in range(len(S)))))
    lines.append("option(redSB);")
    lines.append("ideal I;")
    lines.append("matrix M[%d][%d]; matrix M0[%d][%d]; poly d; int k; matrix cf;"%(N,N,N,N))
    # B entries: B[xi,eta] = b_{xi-eta}
    Sidx={s:i for i,s in enumerate(S)}
    for t in range(nx):
        x1=rnd.randrange(2,p-1); x2=rnd.randrange(2,p-1)
        ix1=pow(x1,p-2,p); ix2=pow(x2,p-2,p)
        lines.append("M = 0; M0 = 0;")
        for i,xi in enumerate(H):
            D=(x1*pow(z,xi[0],p)+ix1*pow(z,(-xi[0])%L,p)+x2*pow(z,xi[1],p)+ix2*pow(z,(-xi[1])%L,p))%p
            lines.append("M[%d,%d]=l-(%d); M0[%d,%d]=l-(%d);"%(i+1,i+1,D,i+1,i+1,D))
        for i,xi in enumerate(H):
            for j,eta in enumerate(H):
                h=((xi[0]-eta[0])%L,(xi[1]-eta[1])%L)
                if h in Sidx:
                    lines.append("M[%d,%d]=M[%d,%d]-b%d;"%(i+1,j+1,i+1,j+1,Sidx[h]))
        lines.append("d = det(M)-det(M0); cf = coeffs(d,l); for(k=1;k<=nrows(cf);k++){I = I + cf[k,1];}")
        lines.append("I = std(I);")
    lines.append("ring s = %d,(%s),dp; ideal I = imap(r,I); ideal J=std(I); int tot=vdim(J);"%(p, ",".join("b%d"%i for i in range(len(S)))))
    lines.append("ring t = %d,(%s),ds; ideal I = imap(r,I); ideal J=std(I); int mu=vdim(J);"%(p, ",".join("b%d"%i for i in range(len(S)))))
    lines.append('print("RESULT tot="+string(tot)+" mu0="+string(mu));')
    lines.append("quit;")
    return "\n".join(lines)
if __name__=="__main__":
    a,b,c=map(int,sys.argv[1:4])
    L,H,K1,K2,HD,HA,allowed,pairs=classify(a,b,c)
    print("N=",len(H),"|K1|",len(K1),"|K2|",len(K2),"|HD|",len(HD),"|HA|",len(HA),"allowed",len(allowed),"pairs",len(pairs))
