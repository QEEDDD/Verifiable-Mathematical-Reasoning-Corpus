import sys, math, random, itertools, sympy, subprocess, os, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from branch2d import classify, group, find_prime

def singular_branch_fast(a, b, c, S, p, nx=None, seed=1):
    L, H = group(a, b, c); N = len(H)
    g = sympy.primitive_root(p); z = pow(g, (p - 1) // L, p)
    rnd = random.Random(seed)
    if nx is None:
        nx = N + 8
    Sidx = {s: i for i, s in enumerate(S)}
    vars_ = ",".join("b%d" % i for i in range(len(S)))
    lines = ["ring r = %d,(%s,l),dp;" % (p, vars_), "option(redSB);",
             "ideal I; matrix M[%d][%d]; matrix M0[%d][%d]; poly d; int k; matrix cf;" % (N, N, N, N)]
    offd = []
    for i, xi in enumerate(H):
        for j, eta in enumerate(H):
            h = ((xi[0] - eta[0]) % L, (xi[1] - eta[1]) % L)
            if h in Sidx:
                offd.append("M[%d,%d]=-b%d;" % (i + 1, j + 1, Sidx[h]))
    offd = "".join(offd)
    for t in range(nx):
        x1 = rnd.randrange(2, p - 1); x2 = rnd.randrange(2, p - 1)
        ix1 = pow(x1, p - 2, p); ix2 = pow(x2, p - 2, p)
        diag = []
        for i, xi in enumerate(H):
            D = (x1 * pow(z, xi[0], p) + ix1 * pow(z, (-xi[0]) % L, p)
                 + x2 * pow(z, xi[1], p) + ix2 * pow(z, (-xi[1]) % L, p)) % p
            diag.append("M[%d,%d]=l-(%d); M0[%d,%d]=l-(%d);" % (i + 1, i + 1, D, i + 1, i + 1, D))
        lines.append("M=0;M0=0;" + "".join(diag) + offd)
        lines.append("d = det(M)-det(M0); cf = coeffs(d,l); for(k=1;k<=nrows(cf);k++){I = I + cf[k,1];}")
    lines.append("ring s = %d,(%s),dp; option(redSB); ideal I = imap(r,I); ideal J=std(I); int tot=vdim(J);" % (p, vars_))
    lines.append("int nil=1; int e; for(e=1;e<=nvars(basering);e++){ if (reduce(var(e)^(tot+1),J)!=0) {nil=0;} }")
    lines.append('print("RESULT tot="+string(tot)+" onlyorigin="+string(nil));')
    lines.append("quit;")
    return "\n".join(lines)

def check_lattice(a, b, c, log):
    L, H, K1, K2, HD, HA, allowed, pairs = classify(a, b, c)
    p = find_prime(L); npairs = len(pairs)
    if npairs == 0:
        print("lattice", (a, b, c), "N", len(H), "no allowed support -> rigid (first-order lemmas)", file=log, flush=True)
        return True
    bad = []; t0 = time.time(); maxtot = 0
    for choice in itertools.product([0, 1], repeat=npairs - 1):
        choice = (0,) + choice
        S = [pairs[i][choice[i]] for i in range(npairs)]
        fn = "fb_%d_%d_%d.sing" % (a, b, c)
        open(fn, "w").write(singular_branch_fast(a, b, c, S, p))
        out = subprocess.run(["Singular", "-q", fn], capture_output=True, text=True, timeout=20000).stdout
        os.remove(fn)
        res = [l for l in out.splitlines() if "RESULT" in l]
        if not res:
            bad.append((S, "noresult")); continue
        tot = int(res[0].split("tot=")[1].split()[0]); oo = int(res[0].split("onlyorigin=")[1])
        maxtot = max(maxtot, tot)
        if oo != 1:
            bad.append((S, tot))
    print("lattice", (a, b, c), "N", len(H), "pairs", npairs, "branches", 2 ** (npairs - 1), "nonrigid:", bad,
          "maxlen", maxtot, "time %.1fs" % (time.time() - t0), file=log, flush=True)
    return not bad

if __name__ == "__main__":
    Nmin, Nmax = int(sys.argv[1]), int(sys.argv[2]); cs = [int(x) for x in sys.argv[3].split(",")]
    log = open(sys.argv[4], "a")
    for N in range(Nmin, Nmax + 1):
        for c in cs:
            if N % c:
                continue
            a = N // c
            for b in range(a):
                if math.gcd(a, b) > 3:
                    continue
                check_lattice(a, b, c, log)
