# find ONE tau-fixed nonzero isospectral potential for odd q by damped Newton on real Fourier coords
import numpy as np, sys
q=int(sys.argv[1]); seed=int(sys.argv[2]); maxtr=int(sys.argv[3])
rng=np.random.default_rng(seed); m=q//2
C=np.zeros((q,q))
for j in range(q): C[j,(j+1)%q]=1; C[(j+1)%q,j]=1
p0=np.poly(C)
om=np.exp(2j*np.pi/q)
Fmat=np.array([[om**(h*j) for h in range(1,q)] for j in range(q)])  # V = Fmat @ b
def F(b):
    V=Fmat@b
    p=np.poly(C+np.diag(V))
    d=(p-p0)[2:]   # coefficients lambda^{q-2}..lambda^0 (lambda^{q-1} coefficient = -sum V = 0 automatically)
    return np.real(d)
def J(b,h=1e-7):
    n=len(b); f0=F(b); Jm=np.zeros((len(f0),n))
    for i in range(n):
        e=np.zeros(n); e[i]=h; Jm[:,i]=(F(b+e)-F(b-e))/(2*h)
    return Jm
for t in range(maxtr):
    b=rng.normal(size=q-1)*rng.uniform(0.2,1.0)
    for it in range(200):
        f=F(b); nf=np.linalg.norm(f)
        if nf<1e-11: break
        Jm=J(b); db=np.linalg.lstsq(Jm,-f,rcond=None)[0]
        lam=1.0
        while lam>1e-5 and np.linalg.norm(F(b+lam*db))>nf: lam/=2
        b=b+lam*db
        if np.linalg.norm(b)>50: break
    if np.linalg.norm(F(b))<1e-11 and np.linalg.norm(b)>0.05:
        sv=np.linalg.svd(J(b),compute_uv=False)
        print("q",q,"trial",t,"found |b|=%.4f"%np.linalg.norm(b),"min sv %.3e"%sv[-1])
        print("b =",repr(b))
        break
else:
    print("q",q,"no solution found in",maxtr,"trials")
