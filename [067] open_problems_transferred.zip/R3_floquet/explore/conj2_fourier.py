import numpy as np, sys
q=int(sys.argv[1]); ntr=int(sys.argv[2]); seed=int(sys.argv[3])
rng=np.random.default_rng(seed); m=q//2
C=np.zeros((q,q))
for j in range(q): C[j,(j+1)%q]=1; C[(j+1)%q,j]=1
Cp=[np.eye(q)]
for k in range(1,q+1): Cp.append(Cp[-1]@C)
t0=np.array([np.trace(Cp[k]) for k in range(1,q+1)])
om=np.exp(2j*np.pi/q)
# parametrize by real Fourier coefficients b_1..b_{q-1} (b_0=0): V_j = sum_h b_h om^{h j}, j in Z/q (center 0)
def V_of_b(b):
    bb=np.concatenate([[0.0],b])
    return np.array([sum(bb[h]*om**(h*j) for h in range(q)) for j in range(q)])
def F(b):
    V=V_of_b(b); A=C+np.diag(V); P=np.eye(q,dtype=complex); out=[]
    for k in range(2,q+1):
        pass
    P=np.eye(q,dtype=complex); out=[]
    for k in range(1,q+1):
        P=P@A; out.append(np.trace(P))
    d=(np.array(out)-t0)/np.arange(1,q+1)
    return np.real(d[1:])  # k=2..q (k=1 automatically 0)
def Jac(b,h=1e-7):
    n=len(b); f0=F(b); J=np.zeros((len(f0),n))
    for i in range(n):
        e=np.zeros(n); e[i]=h; J[:,i]=(F(b+e)-F(b-e))/(2*h)
    return J
sols=[]
for t in range(ntr):
    b=rng.normal(size=q-1)*rng.uniform(0.2,1.0)
    ok=False
    for it in range(120):
        f=F(b)
        if np.linalg.norm(f)<1e-12: ok=True; break
        J=Jac(b); db=np.linalg.lstsq(J,-f,rcond=None)[0]
        lam=1.0
        while lam>1e-4 and np.linalg.norm(F(b+lam*db))>np.linalg.norm(f): lam/=2
        b=b+lam*db
        if np.linalg.norm(b)>100: break
    if ok and np.linalg.norm(b)>0.05:
        if not any(np.linalg.norm(b-s)<1e-6 for s in sols):
            sols.append(b.copy())
print("q",q,"found",len(sols))
signs=[]
for s in sols:
    J=Jac(s); d=np.linalg.det(J); signs.append(np.sign(d))
    if len(sols)<=12: print(np.round(s,5), "detJ sign", np.sign(d), "|det|=%.3e"%abs(d))
print("sum of Jacobian signs over nonzero real zeros:", int(sum(signs)), " => index at 0 =", -int(sum(signs)))
