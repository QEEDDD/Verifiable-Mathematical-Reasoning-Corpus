# generate msolve input for tau-fixed Floquet-isospectral potentials on Z/q (q odd)
# V_0=r, V_j = x_j + I*y_j, V_{-j} = x_j - I*y_j (j=1..m). Equations: Re of power-sum differences, k=1..q.
import sympy as sp, sys
q=int(sys.argv[1]); m=q//2
xs=sp.symbols('x1:%d'%(m+1)); ys=sp.symbols('y1:%d'%(m+1)); r=sp.Symbol('r')
I=sp.I
V=[None]*q
V[0]=r
for j in range(1,m+1):
    V[j]=xs[j-1]+I*ys[j-1]; V[(-j)%q]=xs[j-1]-I*ys[j-1]
A=sp.zeros(q,q); A0=sp.zeros(q,q)
for j in range(q):
    A[j,(j+1)%q]=1; A[(j+1)%q,j]=1; A0[j,(j+1)%q]=1; A0[(j+1)%q,j]=1
    A[j,j]=V[j]
eqs=[]
P=sp.eye(q); P0=sp.eye(q)
for k in range(1,q+1):
    P=(P*A).applyfunc(sp.expand); P0=P0*A0
    d=sp.expand(P.trace()-P0.trace())
    re,im=d.as_real_imag() if False else (sp.expand((d+sp.conjugate(d))/2), sp.expand((d-sp.conjugate(d))/(2*I)))
    # conjugate treats symbols as complex; instead substitute real symbols
    eqs.append(d)
# make symbols real and split
xr=sp.symbols('x1:%d'%(m+1),real=True); yr=sp.symbols('y1:%d'%(m+1),real=True); rr=sp.Symbol('r',real=True)
sub={**{xs[i]:xr[i] for i in range(m)},**{ys[i]:yr[i] for i in range(m)},r:rr}
out=[]
for d in eqs:
    d=sp.expand(d.subs(sub))
    re=sp.expand(sp.re(d)); im=sp.expand(sp.im(d))
    assert im==0, ("nonzero imaginary part", im)
    out.append(re)
varnames=[str(v) for v in list(xr)+list(yr)+[rr]]
with open(sys.argv[2],'w') as f:
    f.write(",".join(varnames)+"\n0\n")
    f.write(",\n".join(str(e).replace('**','^') for e in out)+"\n")
print("written",sys.argv[2], "num eqs",len(out))
