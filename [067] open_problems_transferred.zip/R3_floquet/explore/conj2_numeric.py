# Explore Faust et al. Conjecture 2 numerically: q odd, V = (v1..vm, r, conj(vm)..conj(v1)) Floquet isospectral to 0 on Z/q.
import numpy as np, sys
rng = np.random.default_rng(int(sys.argv[2]) if len(sys.argv)>2 else 1)
q = int(sys.argv[1])
m = q//2
def free_charpoly(q):
    C = np.zeros((q,q))
    for j in range(q):
        C[j,(j+1)%q]=1; C[(j+1)%q,j]=1
    return np.poly(C), C
p0, C = free_charpoly(q)
def V_from_real(w):
    # w: real vector of length q: x1..xm, y1..ym, r
    x = w[:m]; y = w[m:2*m]; r = w[2*m] if q%2==1 else None
    v = x + 1j*y
    if q%2==1:
        return np.concatenate([v, [r], np.conj(v[::-1])])
    else:
        return np.concatenate([v, np.conj(v[::-1])])
def F(w):
    V = V_from_real(w)
    p = np.poly(C + np.diag(V))
    d = (p - p0)[1:]   # coefficients of lambda^{q-1} ... lambda^0
    return np.real(d)  # imaginary parts vanish by symmetry
def J(w, h=1e-7):
    f0 = F(w); n=len(w)
    Jm = np.zeros((len(f0), n))
    for i in range(n):
        e = np.zeros(n); e[i]=h
        Jm[:,i] = (F(w+e)-F(w-e))/(2*h)
    return Jm
sols=[]
for trial in range(4000):
    w = rng.normal(size=q)*rng.uniform(0.3,2.5)
    ok=False
    for it in range(80):
        f = F(w)
        if np.linalg.norm(f) < 1e-11: ok=True; break
        Jm = J(w)
        try:
            dw = np.linalg.lstsq(Jm, -f, rcond=None)[0]
        except Exception: break
        w = w + dw
        if np.linalg.norm(w) > 1e3: break
    if ok and np.linalg.norm(w) > 1e-4:
        V = V_from_real(w)
        if not any(np.linalg.norm(V - s) < 1e-6 for s in sols):
            sols.append(V)
print("q=",q,"distinct nonzero tau-fixed solutions found:",len(sols))
for s in sols[:40]:
    print(np.round(s,6))
