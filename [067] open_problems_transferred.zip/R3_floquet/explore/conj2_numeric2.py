import numpy as np, sys
q = int(sys.argv[1]); ntr = int(sys.argv[2]); seed=int(sys.argv[3]) if len(sys.argv)>3 else 1
rng = np.random.default_rng(seed)
m = q//2
C = np.zeros((q,q))
for j in range(q):
    C[j,(j+1)%q]=1; C[(j+1)%q,j]=1
# use power sums (traces) instead of char poly coefficients: better scaling
def V_from_real(w):
    x = w[:m]; y = w[m:2*m]
    v = x + 1j*y
    if q%2==1:
        return np.concatenate([v, [w[2*m]], np.conj(v[::-1])])
    return np.concatenate([v, np.conj(v[::-1])])
Cp = [np.eye(q)]
for k in range(1,q+1): Cp.append(Cp[-1]@C)
t0 = np.array([np.trace(Cp[k]) for k in range(1,q+1)])
def F(w):
    V = V_from_real(w)
    A = C + np.diag(V)
    P = np.eye(q, dtype=complex); out=[]
    for k in range(1,q+1):
        P = P@A; out.append(np.trace(P))
    d = (np.array(out)-t0)
    # scale k-th equation by 1/k
    return np.real(d)/np.arange(1,q+1)
def J(w, h=1e-7):
    f0 = F(w); n=len(w)
    Jm = np.zeros((len(f0), n))
    for i in range(n):
        e = np.zeros(n); e[i]=h
        Jm[:,i] = (F(w+e)-F(w-e))/(2*h)
    return Jm
sols=[]
for trial in range(ntr):
    w = rng.normal(size=q)*rng.uniform(0.5,2.0)
    ok=False
    for it in range(100):
        f = F(w)
        if np.linalg.norm(f) < 1e-12: ok=True; break
        Jm = J(w)
        dw = np.linalg.lstsq(Jm, -f, rcond=None)[0]
        # damping
        lam=1.0
        while lam>1e-3 and np.linalg.norm(F(w+lam*dw))>np.linalg.norm(f): lam/=2
        w = w + lam*dw
        if np.linalg.norm(w) > 1e3: break
    if ok and np.linalg.norm(w) > 0.2:
        # check Jacobian rank (nonsingular?)
        sv = np.linalg.svd(J(w), compute_uv=False)
        V = V_from_real(w)
        if not any(np.linalg.norm(V - s[0]) < 1e-5 for s in sols):
            sols.append((V, sv[-1]))
print("q=",q,"nonzero tau-fixed solutions found:",len(sols))
for s,sv in sols:
    print(np.round(s,5), " min sing.val:", "%.2e"%sv)
