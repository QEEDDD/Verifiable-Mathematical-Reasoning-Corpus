import numpy as np, sys
q=int(sys.argv[1]); seed=int(sys.argv[2]); nsol=int(sys.argv[3]); maxtr=int(sys.argv[4])
rng=np.random.default_rng(seed); m=q//2
C=np.zeros((q,q))
for j in range(q): C[j,(j+1)%q]=1; C[(j+1)%q,j]=1
p0=np.poly(C); om=np.exp(2j*np.pi/q)
Fm=np.array([[om**(h*j) for h in range(1,q)] for j in range(q)])
def F(b): return np.real((np.poly(C+np.diag(Fm@b))-p0)[2:])
def J(b,h=1e-7):
    n=len(b); Jm=np.zeros((q-1,n))
    for i in range(n):
        e=np.zeros(n); e[i]=h; Jm[:,i]=(F(b+e)-F(b-e))/(2*h)
    return Jm
found=0
for t in range(maxtr):
    b=rng.normal(size=q-1)*rng.uniform(0.2,1.0)
    for it in range(300):
        f=F(b); nf=np.linalg.norm(f)
        if nf<1e-11: break
        db=np.linalg.lstsq(J(b),-f,rcond=None)[0]; lam=1.0
        while lam>1e-5 and np.linalg.norm(F(b+lam*db))>nf: lam/=2
        b=b+lam*db
        if np.linalg.norm(b)>50: break
    if np.linalg.norm(F(b))<1e-10 and np.linalg.norm(b)>0.05:
        pos=b[:m]; neg=b[m:][::-1]   # b_h for h=1..m ; b_{-h} for h=1..m
        print("q",q,"sol |b+|=%.3f |b-|=%.3f"%(np.linalg.norm(pos),np.linalg.norm(neg)), " ratios |b_h/b_-h|:", np.round(np.abs(pos/neg),3))
        found+=1
        if found>=nsol: break
