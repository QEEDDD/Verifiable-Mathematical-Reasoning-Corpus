import numpy as np, sys, itertools
# search tau-fixed solutions with prescribed zero pattern (sparse ansatz)
q = int(sys.argv[1]); ntr=int(sys.argv[2]); seed=int(sys.argv[3])
rng=np.random.default_rng(seed)
m=q//2
C = np.zeros((q,q))
for j in range(q):
    C[j,(j+1)%q]=1; C[(j+1)%q,j]=1
Cp=[np.eye(q)]
for k in range(1,q+1): Cp.append(Cp[-1]@C)
t0=np.array([np.trace(Cp[k]) for k in range(1,q+1)])
def V_from_real(w):
    v = w[:m]+1j*w[m:2*m]
    return np.concatenate([v,[w[2*m]],np.conj(v[::-1])])
def F(w):
    V=V_from_real(w); A=C+np.diag(V); P=np.eye(q,dtype=complex); out=[]
    for k in range(1,q+1):
        P=P@A; out.append(np.trace(P))
    return np.real(np.array(out)-t0)/np.arange(1,q+1)
def solve(w0, mask):
    w=w0*mask
    for it in range(150):
        f=F(w)
        if np.linalg.norm(f)<1e-12: return w
        h=1e-7; n=len(w); Jm=np.zeros((q,n))
        for i in range(n):
            if mask[i]==0: continue
            e=np.zeros(n); e[i]=h; Jm[:,i]=(F(w+e)-F(w-e))/(2*h)
        dw=np.linalg.lstsq(Jm,-f,rcond=None)[0]*mask
        lam=1.0
        while lam>1e-4 and np.linalg.norm(F(w+lam*dw))>np.linalg.norm(f): lam/=2
        w=w+lam*dw
        if np.linalg.norm(w)>1e3: return None
    return None
# try patterns: zero some of the complex entries v_j (both real and imag) and/or r
found={}
for zs in range(0,m+1):
    for Z in itertools.combinations(range(m),zs):
        for rz in [0,1]:
            mask=np.ones(q)
            for j in Z: mask[j]=0; mask[m+j]=0
            if rz: mask[2*m]=0
            nfree=int(mask.sum())
            cnt=0
            for t in range(ntr):
                w=solve(rng.normal(size=q)*rng.uniform(0.5,2),mask)
                if w is not None and np.linalg.norm(w)>0.2:
                    cnt+=1
                    V=V_from_real(w)
                    key=(Z,rz)
                    found.setdefault(key,[])
                    if not any(np.linalg.norm(V-s)<1e-5 for s in found[key]): found[key].append(V)
            if (Z,rz) in found:
                print("zero v-indices",Z,"r zero" if rz else "", "free real dims",nfree,"#sols",len(found[(Z,rz)]))
                for s in found[(Z,rz)][:3]: print("   ",np.round(s,5))
