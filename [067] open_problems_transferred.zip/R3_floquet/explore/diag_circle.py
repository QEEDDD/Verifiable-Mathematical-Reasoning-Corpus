import time, sys, os, warnings
import numpy as np
warnings.filterwarnings("ignore")
src = open(os.path.join(sys.argv[1], 'R3_conj2_krawczyk.py')).read().split('if __name__')[0]
exec(src)
q = int(sys.argv[2]); r = float(sys.argv[3]); sc = float(sys.argv[4]); ntr = int(sys.argv[5])
rng = np.random.default_rng(1)
C = cycle(q); M = M_matrix(q); m = q // 2
lams = [r * np.exp(2j * np.pi * k / q) for k in range(m + 1)]
dC = [np.linalg.det(l * np.eye(q) - C) for l in lams]
def FJ(w):
    V = M @ w; A = C + np.diag(V)
    F = np.zeros(q); J = np.zeros((q, q))
    for k, l in enumerate(lams):
        Rl = l * np.eye(q) - A
        ratio = np.linalg.det(Rl) / dC[k]
        dGw = (-ratio * np.diag(np.linalg.inv(Rl))) @ M
        G = ratio - 1
        if k == 0:
            F[0] = G.real; J[0] = dGw.real
        else:
            F[2*k-1] = G.real; J[2*k-1] = dGw.real; F[2*k] = G.imag; J[2*k] = dGw.imag
    return F, J
succ = 0; t0 = time.time()
for t in range(ntr):
    w = rng.normal(size=q) * sc
    mu = 1e-3
    for it in range(300):
        f, J = FJ(w); nf = np.linalg.norm(f)
        if nf < 1e-13: break
        # Levenberg-Marquardt step
        JTJ = J.T @ J; g = J.T @ f
        while True:
            dw = np.linalg.solve(JTJ + mu * np.diag(np.diag(JTJ) + 1e-12), -g)
            fn = np.linalg.norm(FJ(w + dw)[0])
            if np.isfinite(fn) and fn < nf:
                w = w + dw; mu = max(mu / 3, 1e-12); break
            mu *= 4
            if mu > 1e8: break
        if mu > 1e8: break
    nf = np.linalg.norm(FJ(w)[0])
    ok = nf < 1e-10 and np.linalg.norm(M @ w) > 0.3
    succ += ok
    print("try %d: it %d |F| %.1e |w| %.2f %s" % (t, it, nf, np.linalg.norm(w), "OK" if ok else ""), flush=True)
print("successes", succ, "of", ntr, "time %.1fs" % (time.time() - t0))
