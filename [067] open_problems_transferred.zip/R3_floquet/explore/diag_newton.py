import time, sys, os, warnings
import numpy as np
warnings.filterwarnings("ignore")
q = int(sys.argv[2]); r = float(sys.argv[3]); sc = float(sys.argv[4]); ntr = int(sys.argv[5]); maxit = int(sys.argv[6])
src = open(os.path.join(sys.argv[1], 'R3_conj2_krawczyk.py')).read().split('if __name__')[0]
exec(src)
rng = np.random.default_rng(7)
C = cycle(q); M = M_matrix(q); m = q // 2
lams = [r * np.exp(2j * np.pi * k / q) + np.exp(-2j * np.pi * k / q) / r for k in range(m + 1)]
dC = [np.linalg.det(l * np.eye(q) - C) for l in lams]
def FJ(w):
    V = M @ w; A = C + np.diag(V)
    F = np.zeros(q); J = np.zeros((q, q))
    for k, l in enumerate(lams):
        Rl = l * np.eye(q) - A
        ratio = np.linalg.det(Rl) / dC[k]
        dGw = (-ratio * np.diag(np.linalg.inv(Rl))) @ M
        G = ratio - 1
        if k == 0:
            F[0] = G.real; J[0] = dGw.real
        else:
            F[2*k-1] = G.real; J[2*k-1] = dGw.real; F[2*k] = G.imag; J[2*k] = dGw.imag
    return F, J
succ = 0; t0 = time.time()
for t in range(ntr):
    w = rng.normal(size=q) * sc
    hist = []
    for it in range(maxit):
        f, J = FJ(w); nf = np.linalg.norm(f); hist.append(nf)
        if nf < 1e-13 or not np.isfinite(nf): break
        dw = np.linalg.lstsq(J, -f, rcond=None)[0]; lam = 1.0
        while lam > 1e-6 and not (np.linalg.norm(FJ(w + lam*dw)[0]) < nf): lam /= 2
        w = w + lam * dw
    nf = np.linalg.norm(FJ(w)[0]); sv = np.linalg.svd(FJ(w)[1], compute_uv=False)
    ok = nf < 1e-10 and np.linalg.norm(M @ w) > 0.3
    succ += ok
    print("try %d: it %d |F| %.1e |w| %.2f cond %.1e %s  hist %s" % (t, it, nf, np.linalg.norm(w), sv[0]/sv[-1], "OK" if ok else "", " ".join("%.0e" % h for h in hist[::max(1, len(hist)//8)])), flush=True)
print("successes", succ, "of", ntr, "time %.1fs" % (time.time() - t0))
