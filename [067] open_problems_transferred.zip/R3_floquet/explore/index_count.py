# count real tau-fixed solutions (Fourier-real coords) and the sum of Jacobian signs; report growth
import numpy as np, sys
q=int(sys.argv[1]); seed=int(sys.argv[2]); maxtr=int(sys.argv[3])
rng=np.random.default_rng(seed); m=q//2
C=np.zeros((q,q))
for j in range(q): C[j,(j+1)%q]=1; C[(j+1)%q,j]=1
p0=np.poly(C); om=np.exp(2j*np.pi/q)
Fm=np.array([[om**(h*j) for h in range(1,q)] for j in range(q)])
def F(b): return np.real((np.poly(C+np.diag(Fm@b))-p0)[2:])/np.arange(2,q+1)
def J(b,h=1e-7):
    n=len(b); Jm=np.zeros((q-1,n))
    for i in range(n):
        e=np.zeros(n); e[i]=h; Jm[:,i]=(F(b+e)-F(b-e))/(2*h)
    return Jm
sols=[]; signs=[]
for t in range(maxtr):
    b=rng.normal(size=q-1)*rng.uniform(0.1,1.2)
    for it in range(150):
        f=F(b); nf=np.linalg.norm(f)
        if nf<1e-13: break
        db=np.linalg.lstsq(J(b),-f,rcond=None)[0]; lam=1.0
        while lam>1e-5 and np.linalg.norm(F(b+lam*db))>nf: lam/=2
        b=b+lam*db
        if np.linalg.norm(b)>30: break
    if np.linalg.norm(F(b))<1e-12 and np.linalg.norm(b)>0.05:
        if not any(np.linalg.norm(b-s)<1e-7 for s in sols):
            sols.append(b.copy()); signs.append(int(np.sign(np.linalg.det(J(b)))))
    if (t+1)%2000==0: print("trials",t+1,"distinct",len(sols),"sum signs",sum(signs),flush=True)
print("FINAL q",q,"distinct",len(sols),"sum of Jacobian signs",sum(signs),"=> index at 0 would be",-sum(signs),"if complete")
