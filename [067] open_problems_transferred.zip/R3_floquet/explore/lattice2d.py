# Generate Singular script for the spectral-invariant ideal of a 2D HNF lattice Gamma=<(a,0),(b,c)>
import sys, math
def sites(a,b,c):
    return [(r1,r2) for r2 in range(c) for r1 in range(a)]
def reduce(n,a,b,c):
    n1,n2=n
    k2=n2//c; r2=n2-c*k2
    n1p=n1-k2*b
    k1=n1p//a; r1=n1p-a*k1
    return (r1,r2),(k1,k2)
def floquet_entries(a,b,c):
    S=sites(a,b,c); idx={s:i for i,s in enumerate(S)}
    ent={}  # (i,j) -> list of (k1,k2)
    for s in S:
        for e in [(1,0),(-1,0),(0,1),(0,-1)]:
            t=(s[0]+e[0],s[1]+e[1])
            r,k=reduce(t,a,b,c)
            ent.setdefault((idx[s],idx[r]),[]).append(k)
    return S,ent
def zmono(k):
    k1,k2=k
    parts=[]
    if k1>0: parts.append("z1^%d"%k1)
    if k1<0: parts.append("y1^%d"%(-k1))
    if k2>0: parts.append("z2^%d"%k2)
    if k2<0: parts.append("y2^%d"%(-k2))
    return "*".join(parts) if parts else "1"
def singular_script(a,b,c,extra=""):
    S,ent=floquet_entries(a,b,c); N=len(S)
    lines=[]
    lines.append("ring r = 0,(v(1..%d),l,z1,z2,y1,y2),dp;"%N)
    lines.append("matrix M[%d][%d];"%(N,N))
    lines.append("matrix M0[%d][%d];"%(N,N))
    for (i,j),ks in ent.items():
        expr="+".join(zmono(k) for k in ks)
        lines.append("M[%d,%d] = M[%d,%d] - (%s); M0[%d,%d] = M0[%d,%d] - (%s);"%(i+1,j+1,i+1,j+1,expr,i+1,j+1,i+1,j+1,expr))
    for i in range(N):
        lines.append("M[%d,%d] = M[%d,%d] + l - v(%d); M0[%d,%d] = M0[%d,%d] + l;"%(i+1,i+1,i+1,i+1,i+1,i+1,i+1,i+1,i+1))
    lines.append("poly d = det(M) - det(M0);")
    lines.append("ideal Q = z1*y1-1, z2*y2-1;")
    lines.append("d = reduce(d, std(Q));")
    lines.append("matrix cf = coef(d, l*z1*z2*y1*y2);")
    lines.append("ideal I; int i; for (i=1;i<=ncols(cf);i++) { I = I + cf[2,i]; }")
    lines.append("ring s = 0,(v(1..%d)),dp; ideal I = imap(r,I); %s"%(N,extra))
    lines.append("option(redSB); ideal J = std(I); int tot = vdim(J);")
    lines.append("ring t = 0,(v(1..%d)),ds; ideal I = imap(s,I); ideal J = std(I); int mu = vdim(J);"%N)
    lines.append('print("lattice (%d,%d,%d) N=%d total length " + string(tot) + " local mult at 0 = " + string(mu));'%(a,b,c,N))
    lines.append("quit;")
    return "\n".join(lines)
if __name__=="__main__":
    a,b,c=map(int,sys.argv[1:4])
    print(singular_script(a,b,c))
