import mpmath as mp
mp.mp.dps=120
q=5
def V_of(x1,x2,y1,y2,r):
    return [r, mp.mpc(x1,y1), mp.mpc(x2,y2), mp.mpc(x2,-y2), mp.mpc(x1,-y1)]
def F(*w):
    V=V_of(*w)
    A=mp.matrix(q,q); A0=mp.matrix(q,q)
    for j in range(q):
        A[j,(j+1)%q]=1; A[(j+1)%q,j]=1; A0[j,(j+1)%q]=1; A0[(j+1)%q,j]=1; A[j,j]=V[j]
    P=mp.eye(q); P0=mp.eye(q); out=[]
    for k in range(1,q+1):
        P=P*A; P0=P0*A0
        out.append(mp.re(sum(P[i,i] for i in range(q))-sum(P0[i,i] for i in range(q))))
    return out
sol=mp.findroot(F,[-0.787806, 1.364857, 1.34085, -1.16257, -1.154102])
V=V_of(*sol)
om=mp.exp(2j*mp.pi/q)
b=[sum(V[j]*om**(-h*j) for j in range(q))/q for h in range(q)]
for h in range(q): print(h, mp.nstr(b[h],25))
P1=b[1]*b[4]; P2=b[2]*b[3]
for name,val in [("b1",mp.re(b[1])),("b2",mp.re(b[2])),("b3",mp.re(b[3])),("b4",mp.re(b[4])),("b1/b4",mp.re(b[1]/b[4])),("b2/b3",mp.re(b[2]/b[3])),("b1*b2",mp.re(b[1]*b[2])),("b1^2",mp.re(b[1]**2)),("b4^2",mp.re(b[4]**2)),("r",mp.re(V[0])),("b1^2*b3",mp.re(b[1]**2*b[3])),("b4^2*b2",mp.re(b[4]**2*b[2])),("b1*b2^2",mp.re(b[1]*b[2]**2)),("b4*b3^2",mp.re(b[4]*b[3]**2))]:
    print(name, mp.nstr(val,30))
    for deg in (8,12,16,20,24):
        p=mp.findpoly(val,deg,maxcoeff=10**12)
        if p: print("   minpoly deg",deg,":",p); break
