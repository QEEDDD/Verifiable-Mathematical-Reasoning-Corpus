import mpmath as mp
mp.mp.dps=120
q=5
def V_of(x1,x2,y1,y2,r):
    return [r, mp.mpc(x1,y1), mp.mpc(x2,y2), mp.mpc(x2,-y2), mp.mpc(x1,-y1)]
def F(*w):
    V=V_of(*w)
    A=mp.matrix(q,q); A0=mp.matrix(q,q)
    for j in range(q):
        A[j,(j+1)%q]=1; A[(j+1)%q,j]=1; A0[j,(j+1)%q]=1; A0[(j+1)%q,j]=1; A[j,j]=V[j]
    P=mp.eye(q); P0=mp.eye(q); out=[]
    for k in range(1,q+1):
        P=P*A; P0=P0*A0
        out.append(mp.re(sum(P[i,i] for i in range(q))-sum(P0[i,i] for i in range(q))))
    return out
sol=mp.findroot(F,[-0.787806, 1.364857, 1.34085, -1.16257, -1.154102])
V=V_of(*sol)
om=mp.exp(2j*mp.pi/q)
b=[mp.re(sum(V[j]*om**(-h*j) for j in range(q))/q) for h in range(q)]
B={1:b[1],2:b[2],-1:b[4],-2:b[3]}
x=B[1]**2*B[-2]
print("unit u = b1^2 b_-2 =", mp.nstr(x,40), "minpoly:", mp.findpoly(x,12,maxcoeff=10**15))
print("u^2 =", mp.nstr(x**2,40), mp.findpoly(x**2,6,maxcoeff=10**15))
print("P1 = b1 b_-1 =", mp.nstr(B[1]*B[-1],30), " 6/(5 sqrt5)=", mp.nstr(6/(5*mp.sqrt(5)),30))
print("r =", mp.nstr(mp.re(V[0]),30), mp.findpoly(mp.re(V[0]),12,maxcoeff=10**15))
print("r^2 =", mp.findpoly(mp.re(V[0])**2,12,maxcoeff=10**15))
for v in V: print(mp.nstr(v,20))
print("|V1|^2", mp.findpoly(abs(V[1])**2,12,maxcoeff=10**15), "|V2|^2", mp.findpoly(abs(V[2])**2,12,maxcoeff=10**15))
print("Re V1", mp.findpoly(mp.re(V[1]),16,maxcoeff=10**15))
print("V1^5?", mp.nstr(V[1]**5,20), " V2^5", mp.nstr(V[2]**5,20), " r^5", mp.nstr(mp.re(V[0])**5,20))
