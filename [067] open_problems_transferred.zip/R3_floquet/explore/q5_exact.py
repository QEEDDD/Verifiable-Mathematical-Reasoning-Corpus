import mpmath as mp
mp.mp.dps=60
q=5
def F(*w):
    x1,x2,y1,y2,r = w
    V=[r, mp.mpc(x1,y1), mp.mpc(x2,y2), mp.mpc(x2,-y2), mp.mpc(x1,-y1)]  # positions 0,1,2,-2,-1
    A=mp.matrix(q,q)
    for j in range(q):
        A[j,(j+1)%q]=1; A[(j+1)%q,j]=1; A[j,j]=V[j]
    A0=mp.matrix(q,q)
    for j in range(q):
        A0[j,(j+1)%q]=1; A0[(j+1)%q,j]=1
    P=mp.eye(q); P0=mp.eye(q); out=[]
    for k in range(1,q+1):
        P=P*A; P0=P0*A0
        out.append(mp.re(sum(P[i,i] for i in range(q))-sum(P0[i,i] for i in range(q))))
    return out
# initial guess from numerics: positions -2..2 = (v1,v2,r,conj v2, conj v1); here index j=1 -> conj v2? use guess
g=[-0.787806, 1.364857, 1.34085, -1.16257, -1.154102]
sol=mp.findroot(F, g)
print(sol)
x1,x2,y1,y2,r=sol
for val,name in [(r,'r'),(x1,'x1'),(y1,'y1'),(x2,'x2'),(y2,'y2'),(x1**2+y1**2,'|V1|^2'),(x2**2+y2**2,'|V2|^2')]:
    print(name, mp.nstr(val,30), mp.findpoly(val, 12, maxcoeff=10**6))
