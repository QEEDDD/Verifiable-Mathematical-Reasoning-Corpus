import numpy as np, sys
q=int(sys.argv[1]); seed=int(sys.argv[2]); maxtr=int(sys.argv[3])
rng=np.random.default_rng(seed); m=q//2
C=np.zeros((q,q))
for j in range(q): C[j,(j+1)%q]=1; C[(j+1)%q,j]=1
p0=np.poly(C); om=np.exp(2j*np.pi/q)
Fm=np.array([[om**(h*j) for h in range(1,q)] for j in range(q)])
def F(b): return np.real((np.poly(C+np.diag(Fm@b))-p0)[2:])
def J(b,h=1e-7):
    n=len(b); Jm=np.zeros((q-1,n))
    for i in range(n):
        e=np.zeros(n); e[i]=h; Jm[:,i]=(F(b+e)-F(b-e))/(2*h)
    return Jm
sols=[]
for t in range(maxtr):
    b=rng.normal(size=q-1)*rng.uniform(0.2,1.0)
    for it in range(200):
        f=F(b); nf=np.linalg.norm(f)
        if nf<1e-12: break
        db=np.linalg.lstsq(J(b),-f,rcond=None)[0]; lam=1.0
        while lam>1e-5 and np.linalg.norm(F(b+lam*db))>nf: lam/=2
        b=b+lam*db
        if np.linalg.norm(b)>50: break
    if np.linalg.norm(F(b))<1e-11 and np.linalg.norm(b)>0.05 and not any(np.linalg.norm(b-s)<1e-6 for s in sols):
        sols.append(b.copy())
print("found",len(sols))
import math
fact=math.factorial(q-1)
rows=[]
for b in sols:
    B={h:(b[h-1] if h<=m else None) for h in range(1,m+1)}
    for h in range(1,m+1): B[-h]=b[q-h-1]
    r=[ (B[h]/B[-h])**q for h in range(1,m+1)]
    P=[B[h]*B[-h] for h in range(1,m+1)]
    rows.append((r,P))
# look for nice values
for r,P in rows:
    flags=[]
    for h,x in enumerate(r,1):
        for name,val in [("1/(q-1)!",1/fact),("(q-1)!",fact)]:
            if abs(x-val)/abs(val)<1e-6: flags.append((h,name))
    if flags: print("NICE:",flags, np.round(r,8), np.round(P,8))
print("sample r^q values (h=1):", sorted(set(np.round([rr[0][0] for rr in rows],6)))[:40])
