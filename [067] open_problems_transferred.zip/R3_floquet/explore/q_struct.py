import mpmath as mp, numpy as np, sys
q=int(sys.argv[1]); ntr=int(sys.argv[2]); seed=int(sys.argv[3])
m=q//2
# numeric search in real Fourier coordinates, then refine with mpmath
rng=np.random.default_rng(seed)
C=np.zeros((q,q))
for j in range(q): C[j,(j+1)%q]=1; C[(j+1)%q,j]=1
p0=np.poly(C); om=np.exp(2j*np.pi/q)
Fm=np.array([[om**(h*j) for h in range(1,q)] for j in range(q)])
def F(b): return np.real((np.poly(C+np.diag(Fm@b))-p0)[2:])
def J(b,h=1e-7):
    n=len(b); Jm=np.zeros((q-1,n))
    for i in range(n):
        e=np.zeros(n); e[i]=h; Jm[:,i]=(F(b+e)-F(b-e))/(2*h)
    return Jm
sols=[]
for t in range(ntr):
    b=rng.normal(size=q-1)*rng.uniform(0.2,1.0)
    for it in range(200):
        f=F(b); nf=np.linalg.norm(f)
        if nf<1e-12: break
        db=np.linalg.lstsq(J(b),-f,rcond=None)[0]; lam=1.0
        while lam>1e-5 and np.linalg.norm(F(b+lam*db))>nf: lam/=2
        b=b+lam*db
        if np.linalg.norm(b)>50: break
    if np.linalg.norm(F(b))<1e-11 and np.linalg.norm(b)>0.05 and not any(np.linalg.norm(b-s)<1e-6 for s in sols):
        sols.append(b.copy())
print("found",len(sols))
mp.mp.dps=60
omm=mp.exp(2j*mp.pi/q)
def Fmp(*bb):
    V=[sum(bb[h-1]*omm**(h*j) for h in range(1,q)) for j in range(q)]
    A=mp.matrix(q,q); A0=mp.matrix(q,q)
    for j in range(q):
        A[j,(j+1)%q]=1; A[(j+1)%q,j]=1; A0[j,(j+1)%q]=1; A0[(j+1)%q,j]=1; A[j,j]=V[j]
    P=mp.eye(q); P0=mp.eye(q); out=[]
    for k in range(2,q+1):
        pass
    P=mp.eye(q); out=[]
    for k in range(1,q+1):
        P=P*A; P0=P0*A0
        out.append(mp.re(sum(P[i,i] for i in range(q))-sum(P0[i,i] for i in range(q))))
    return out[1:]
for s in sols[:int(sys.argv[4])]:
    bb=mp.findroot(Fmp,[mp.mpf(x) for x in s])
    B={}
    for h in range(1,q):
        hh=h if h<=m else h-q
        B[hh]=bb[h-1]
    print("solution:", [mp.nstr(B[h],8) for h in sorted(B)])
    for h in range(1,m+1):
        P=B[h]*B[-h]; r=B[h]/B[-h]
        print("  h=%d P_h=%s  P_h*sqrt(q)=%s  r_h^q=%s"%(h,mp.nstr(P,12),mp.nstr(P*mp.sqrt(q),12),mp.nstr(r**q,12)), " minpoly(P^2):",mp.findpoly(P**2,6,maxcoeff=10**9), " minpoly(r^q):", mp.findpoly(r**q,4,maxcoeff=10**9))
