# Check structure: are all solutions for rectangular lattice q1 Z + q2 Z separable?
# Generate Singular script: ideal I of spectral invariants (position space), then
# J = I + (separability conditions). Compare vdim(I) and vdim(I + sep)?? Instead: compute
# the "non-separable part" ideal: add equations forcing the separable projection to vanish
# and see whether only V=0 remains, i.e., check that the cross Fourier part vanishes on V(I).
import sys
sys.path.insert(0,'.')
from lattice2d import floquet_entries, zmono
q1,q2=map(int,sys.argv[1:3])
a,b,c=q1,0,q2
S,ent=floquet_entries(a,b,c); N=len(S)
idx={s:i for i,s in enumerate(S)}
lines=[]
lines.append("ring r = 0,(v(1..%d),l,z1,z2,y1,y2),dp;"%N)
lines.append("matrix M[%d][%d]; matrix M0[%d][%d];"%(N,N,N,N))
for (i,j),ks in ent.items():
    expr="+".join(zmono(k) for k in ks)
    lines.append("M[%d,%d] = M[%d,%d] - (%s); M0[%d,%d] = M0[%d,%d] - (%s);"%(i+1,j+1,i+1,j+1,expr,i+1,j+1,i+1,j+1,expr))
for i in range(N):
    lines.append("M[%d,%d] = M[%d,%d] + l - v(%d); M0[%d,%d] = M0[%d,%d] + l;"%(i+1,i+1,i+1,i+1,i+1,i+1,i+1,i+1,i+1))
lines.append("poly d = det(M) - det(M0); ideal Q = z1*y1-1, z2*y2-1; d = reduce(d, std(Q));")
lines.append("matrix cf = coef(d, l*z1*z2*y1*y2); ideal I; int i; for (i=1;i<=ncols(cf);i++) { I = I + cf[2,i]; }")
lines.append("ring s = 0,(v(1..%d)),dp; ideal I = imap(r,I); option(redSB); ideal J = std(I); int tot = vdim(J);"%N)
# cross part: V(n1,n2) - rowmean(n1) - colmean(n2) + totalmean ; separable iff all vanish
cross=[]
for (n1,n2),i in idx.items():
    row=[idx[(n1,m)] for m in range(q2)]
    col=[idx[(m,n2)] for m in range(q1)]
    allv=list(range(N))
    expr="%d*v(%d) - %d*(%s) - %d*(%s) + (%s)"%(q1*q2,i+1, q1, "+".join("v(%d)"%(k+1) for k in row), q2, "+".join("v(%d)"%(k+1) for k in col), "+".join("v(%d)"%(k+1) for k in allv))
    cross.append(expr)
lines.append("ideal C = %s;"%(",".join(cross)))
# separable solutions: J + C ; compare lengths
lines.append("ideal JS = std(J + C); int sep = vdim(JS);")
lines.append('print("rect %d x %d: total length " + string(tot) + ", length of separable part " + string(sep));'%(q1,q2))
# also check radical membership of cross part: is each cross coordinate nilpotent mod J?
lines.append("int k; int nil=1; for(k=1;k<=size(C);k++){ if (reduce(C[k]^(%d), J)!=0) {nil=0;} }"%(N))
lines.append('print("cross part nilpotent (power N) mod I: " + string(nil));')
lines.append("quit;")
open("rect_%d_%d.sing"%(q1,q2),"w").write("\n".join(lines))
