import sys, itertools, subprocess, time, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from branch2d import classify, singular_branch, find_prime
a,b,c=map(int,sys.argv[1:4])
L,H,K1,K2,HD,HA,allowed,pairs=classify(a,b,c)
p=find_prime(L)
print("lattice",(a,b,c),"N",len(H),"pairs",len(pairs),"p",p, flush=True)
results=[]
npairs=len(pairs)
if npairs==0:
    print("no allowed support: rigid by first-order lemmas"); sys.exit()
for choice in itertools.product([0,1],repeat=npairs-1):
    choice=(0,)+choice   # fix first pair choice by inversion symmetry
    S=[pairs[i][choice[i]] for i in range(npairs)]
    scr=singular_branch(a,b,c,S,p)
    fn="br_%d_%d_%d.sing"%(a,b,c)
    open(fn,"w").write(scr)
    t0=time.time()
    out=subprocess.run(["Singular","-q",fn],capture_output=True,text=True,timeout=3600).stdout
    res=[l for l in out.splitlines() if "RESULT" in l]
    print("S=",S,res,"%.1fs"%(time.time()-t0), flush=True)
    results.append(res)
    os.remove(fn)
