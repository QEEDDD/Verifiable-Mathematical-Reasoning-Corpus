#!/bin/bash
# exact (over Q) position-space check: total length == local multiplicity at 0  <=> only V=0
N=$1
for c in 1 2 3; do
  if [ $((N % c)) -ne 0 ]; then continue; fi
  a=$((N / c))
  for ((b=0;b<a;b++)); do
    g=$(python3 -I -c "import math;print(math.gcd($a,$b))")
    if [ $g -le 3 ]; then
      if [ $c -eq 1 ] && [ $((2*b)) -gt $a ]; then continue; fi
      python3 -I lattice2d.py $a $b $c > ex_${a}_${b}_${c}.sing
      timeout 20000 Singular -q ex_${a}_${b}_${c}.sing 2>&1 | tail -1
      rm -f ex_${a}_${b}_${c}.sing
    fi
  done
done
