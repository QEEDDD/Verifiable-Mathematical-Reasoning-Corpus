#!/bin/bash
# run all HNF lattices with given N=a*c
N=$1
for c in 1 2 3; do
  if [ $((N % c)) -ne 0 ]; then continue; fi
  a=$((N / c))
  for ((b=0;b<a;b++)); do
    g=$(python3 -I -c "import math;print(math.gcd($a,$b))")
    if [ $g -le 3 ]; then
      python3 -I lattice2d.py $a $b $c > t_${a}_${b}_${c}.sing
      timeout 1800 Singular -q t_${a}_${b}_${c}.sing 2>&1 | tail -1
      rm -f t_${a}_${b}_${c}.sing
    fi
  done
done
