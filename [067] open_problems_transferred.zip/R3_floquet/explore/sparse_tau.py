# search tau-symmetric sparse potentials (symmetric support about 0) for odd q
import numpy as np, sys, itertools
from scipy.optimize import least_squares
q=int(sys.argv[1]); maxsupp=int(sys.argv[2]); ntr=int(sys.argv[3])
m=q//2
C=np.zeros((q,q))
for j in range(q): C[j,(j+1)%q]=1; C[(j+1)%q,j]=1
p0=np.poly(C)
rng=np.random.default_rng(0)
def make(pos, w):
    # pos: list of positive positions (1..m) with complex values; center real value w[0] if use_center
    V=np.zeros(q,dtype=complex)
    V[0]=w[0]
    for i,p in enumerate(pos):
        V[p]=w[1+2*i]+1j*w[2+2*i]; V[-p]=w[1+2*i]-1j*w[2+2*i]
    return V
def res(w,pos):
    V=make(pos,w); d=(np.poly(C+np.diag(V))-p0)[1:]
    return np.real(d)/np.maximum(1,np.arange(1,q+1))
found=[]
for npos in range(1,maxsupp+1):
    for pos in itertools.combinations(range(1,m+1),npos):
        nun=1+2*npos
        if nun>=q: continue
        best=1e9
        for t in range(ntr):
            w0=rng.normal(size=nun)
            r=least_squares(res,w0,args=(pos,),xtol=1e-15,ftol=1e-15,gtol=1e-15,max_nfev=4000)
            V=make(pos,r.x)
            if np.linalg.norm(V)>0.1: best=min(best,np.linalg.norm(r.fun))
            if np.linalg.norm(r.fun)<1e-10 and np.linalg.norm(V)>0.1:
                found.append((pos,np.round(V,5))); break
        print("q",q,"pos",pos,"best residual %.2e"%best, flush=True)
print("FOUND:",found)
