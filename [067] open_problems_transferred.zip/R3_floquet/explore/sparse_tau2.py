import numpy as np, sys, itertools
from scipy.optimize import least_squares
q=int(sys.argv[1]); npos=int(sys.argv[2]); ntr=int(sys.argv[3]); center=int(sys.argv[4])
m=q//2
C=np.zeros((q,q))
for j in range(q): C[j,(j+1)%q]=1; C[(j+1)%q,j]=1
p0=np.poly(C)
rng=np.random.default_rng(1)
def make(pos,w):
    V=np.zeros(q,dtype=complex); off=0
    if center: V[0]=w[0]; off=1
    for i,p in enumerate(pos):
        V[p]=w[off+2*i]+1j*w[off+1+2*i]; V[-p]=w[off+2*i]-1j*w[off+1+2*i]
    return V
def res(w,pos):
    V=make(pos,w); d=(np.poly(C+np.diag(V))-p0)[1:]
    return np.real(d)/np.maximum(1,np.arange(1,q+1))
for pos in itertools.combinations(range(1,m+1),npos):
    nun=center+2*npos
    for t in range(ntr):
        r=least_squares(res,rng.normal(size=nun),args=(pos,),xtol=1e-15,ftol=1e-15,gtol=1e-15,max_nfev=3000)
        V=make(pos,r.x)
        if np.linalg.norm(r.fun)<1e-10 and np.linalg.norm(V)>0.1:
            print("q",q,"pos",pos,"center",center,"V=",np.round(V,5),"|V|:",np.round(np.abs(V),4),flush=True); break
print("done q",q,"npos",npos,"center",center)
