import sys, itertools, subprocess, time, os, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from branch2d import classify, singular_branch, find_prime
Nmin,Nmax=int(sys.argv[1]),int(sys.argv[2])
for N in range(Nmin,Nmax+1):
    for c in (1,2,3):
        if N%c: continue
        a=N//c
        for b in range(a):
            if math.gcd(a,b)>3: continue
            L,H,K1,K2,HD,HA,allowed,pairs=classify(a,b,c)
            p=find_prime(L)
            npairs=len(pairs)
            if npairs==0:
                print("lattice",(a,b,c),"N",N,"no allowed support -> rigid (first-order lemmas)",flush=True); continue
            bad=[]; maxtot=0; t0=time.time()
            for choice in itertools.product([0,1],repeat=npairs-1):
                choice=(0,)+choice
                S=[pairs[i][choice[i]] for i in range(npairs)]
                fn="sw_%d_%d_%d.sing"%(a,b,c)
                open(fn,"w").write(singular_branch(a,b,c,S,p))
                out=subprocess.run(["Singular","-q",fn],capture_output=True,text=True,timeout=7200).stdout
                os.remove(fn)
                res=[l for l in out.splitlines() if "RESULT" in l]
                if not res: bad.append((S,"noresult")); continue
                tot=int(res[0].split("tot=")[1].split()[0]); mu=int(res[0].split("mu0=")[1])
                maxtot=max(maxtot,tot)
                if tot!=mu: bad.append((S,tot,mu))
            print("lattice",(a,b,c),"N",N,"pairs",npairs,"branches",2**(npairs-1),"nonrigid branches:",bad,"maxlen",maxtot,"time %.1fs"%(time.time()-t0),flush=True)
