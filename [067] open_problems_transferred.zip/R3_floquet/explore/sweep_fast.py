import sys, math, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from branch2d_fast import check_lattice
Nmin,Nmax=int(sys.argv[1]),int(sys.argv[2]); cs=[int(x) for x in sys.argv[3].split(",")]
log=open(sys.argv[4],"a")
for N in range(Nmin,Nmax+1):
    for c in cs:
        if N%c: continue
        a=N//c
        for b in range(a):
            if math.gcd(a,b)>3: continue
            if c==1 and b>a//2: continue   # reflection n1 -> -n1 maps b to a-b
            check_lattice(a,b,c,log)
