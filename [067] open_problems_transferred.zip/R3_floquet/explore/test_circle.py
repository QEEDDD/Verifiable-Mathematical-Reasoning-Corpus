import time, sys, os, warnings
warnings.filterwarnings("ignore")
src = open(os.path.join(sys.argv[1], 'R3_conj2_krawczyk.py')).read().split('if __name__')[0]
exec(src)
from flint import ctx
ctx.prec = 400
for q in [int(x) for x in sys.argv[2].split(',')]:
    t = time.time(); w = numeric_solution_circle(q, q, maxtr=int(sys.argv[3]))
    print(q, 'found' if w is not None else 'none', '%.1fs' % (time.time() - t), flush=True)
    if w is not None:
        t = time.time(); wv = refine(q, [float(x) for x in w], steps=10)
        res = max(abs(float(f.mid())) for f in F_and_J(q, wv)[0]); print('refined residual %.2e  %.1fs' % (res, time.time() - t), flush=True)
        t = time.time(); ok, width = krawczyk(q, wv, '1e-30'); print('krawczyk', ok, '%.1fs' % (time.time() - t), flush=True)
