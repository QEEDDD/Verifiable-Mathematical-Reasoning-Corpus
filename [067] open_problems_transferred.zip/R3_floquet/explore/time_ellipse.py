import time, sys, os, warnings
warnings.filterwarnings("ignore")
src = open(os.path.join(sys.argv[1], 'R3_conj2_krawczyk.py')).read().split('if __name__')[0]
exec(src)
from flint import ctx
ctx.prec = 400
q = int(sys.argv[2])
t = time.time(); w = numeric_solution_ellipse(q, q, maxtr=int(sys.argv[3])); print("search", q, w is not None, "%.1fs" % (time.time() - t), flush=True)
import numpy as np
w0 = [arb(float(x)) for x in (w if w is not None else np.ones(q) * 0.3)]
t = time.time(); E_and_J(q, w0); print("E_and_J %.1fs" % (time.time() - t), flush=True)
t = time.time(); F_and_J(q, w0); print("F_and_J %.1fs" % (time.time() - t), flush=True)
