# Independent check of the explicit q=5 and q=9 potentials (Theorem R3:thm:explicit).
import mpmath as mp
mp.mp.dps = 60
def charpoly_diff(V):
    q = len(V)
    A = mp.matrix(q, q)
    for j in range(q):
        A[j, (j+1) % q] += 1; A[(j+1) % q, j] += 1
    # coefficients via evaluation at q+1 points and solving Vandermonde is ill-conditioned;
    # instead use Faddeev-LeVerrier on A+diag V and A.
    def flv(M):
        n = M.rows; c = [mp.mpc(1)]; Mk = mp.zeros(n, n); I = mp.eye(n)
        for k in range(1, n+1):
            Mk = M*Mk + c[-1]*I
            ck = -sum(( M*Mk)[i, i] for i in range(n))/k
            c.append(ck)
        return c
    B = A.copy()
    for j in range(q): B[j, j] += V[j]
    c1 = flv(B); c0 = flv(A)
    return max(abs(c1[k]-c0[k]) for k in range(q+1))
# q=5
w = mp.exp(2j*mp.pi/5); t = mp.mpf(24)**(mp.mpf(1)/10); u = mp.mpf(5)**(mp.mpf(1)/4)
b = {1: -t**4/(2*u**3), -1: -t**6/(2*u**3), 2: 6/(u**3*t**2), -2: -t**2/u**3}
V5 = [sum(b[h]*w**(h*j) for h in b) for j in range(5)]
print("q=5 V:", [mp.nstr(v, 10) for v in V5])
print("q=5 symmetry max|V_{-j}-conj V_j| =", mp.nstr(max(abs(V5[(-j) % 5]-mp.conj(V5[j])) for j in range(5)), 5))
print("q=5 max coeff diff =", mp.nstr(charpoly_diff(V5), 5))
# q=9
e = mp.exp(-1j*mp.pi/6)
V9 = [0]*9
V9[0] = 0; V9[4] = 0; V9[-4 % 9] = 0
V9[1] = e; V9[-1 % 9] = mp.conj(e)
V9[2] = -e; V9[-2 % 9] = -mp.conj(e)
V9[3] = -1j; V9[-3 % 9] = 1j
V9 = [mp.mpc(v) for v in V9]
print("q=9 symmetry max =", mp.nstr(max(abs(V9[(-j) % 9]-mp.conj(V9[j])) for j in range(9)), 5))
print("q=9 max coeff diff =", mp.nstr(charpoly_diff(V9), 5))
# negative control: perturb
V9b = list(V9); V9b[0] = mp.mpf('0.1')
print("q=9 perturbed control diff =", mp.nstr(charpoly_diff(V9b), 5))
