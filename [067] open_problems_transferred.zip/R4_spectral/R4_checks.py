#!/usr/bin/env python3
# R4 independent numerical checks of the lemmas/theorems in section.tex (not part of the proofs).
import numpy as np, itertools, networkx as nx
from scipy.optimize import minimize
rng = np.random.default_rng(20261023)

def lap(n, edges, w):
    L = np.zeros((n, n))
    for (a, b), x in zip(edges, w):
        L[a, a] += x; L[b, b] += x; L[a, b] -= x; L[b, a] -= x
    return L
def red(L): return np.sort(np.linalg.eigvalsh(L))[1:]

print("== 1. Missing-edge inequality lambda_n >= n/(n-2) lambda_2 on random non-complete weightings")
worst = 9
for t in range(3000):
    n = rng.integers(3, 9)
    E = [e for e in itertools.combinations(range(n), 2)]
    drop = rng.choice(len(E), size=rng.integers(1, len(E)), replace=False)
    Ek = [E[i] for i in range(len(E)) if i not in set(drop[:1])]   # at least one missing pair
    w = rng.exponential(size=len(Ek)) * (rng.random(len(Ek)) < 0.8)
    s = red(lap(n, Ek, w))
    if s[0] > 1e-9: worst = min(worst, s[-1] / s[0] / (n / (n - 2)))
print("   min over samples of (lambda_n/lambda_2)/(n/(n-2)) =", round(worst, 6), "(must be >= 1)")

print("== 2. Matching family witnesses (Theorem matching): sigma_r is NOT reachable on G (local search),")
print("      reachable on G+e (exact).  Example n=6: F={01,23,45? no} -> use F = M u {e}, e sharing a vertex")
def best_fit(n, E, target, starts=60):
    best = 9
    for s in range(starts):
        x0 = rng.random(len(E)) + 0.1
        f = lambda x: np.sum((red(lap(n, E, x * x)) - target) ** 2)
        r = minimize(f, x0, method='Nelder-Mead', options={'maxiter': 20000, 'xatol': 1e-12, 'fatol': 1e-16})
        best = min(best, r.fun)
    return best
n = 6
allE = list(itertools.combinations(range(n), 2))
M = [(0, 1), (2, 3)]; e = (1, 2)            # F = M u {e} is a path (not a matching); F\{e}=M
G = [f for f in allE if f not in M + [e]]
H = G + [e]
alpha = 1.0
sig = np.sort([(n - 2) * alpha] * 2 + [n * alpha] * (n - 1 - 2))
print("   G+e uniform realises sigma_r exactly:", np.allclose(red(lap(n, H, [alpha] * len(H))), sig))
print("   best squared residual for sigma_r on G (should stay clearly > 0):", round(best_fit(n, G, sig), 6))
M2 = [(0, 1), (2, 3), (4, 5)]; e2 = (4, 5)  # F = M_3 (matching), F\{e} = M_2
G2 = [f for f in allE if f not in M2]; H2 = G2 + [e2]
sig2 = np.sort([(n - 2) * alpha] * 2 + [n * alpha] * (n - 3))
print("   K6-M2 uniform realises its facet spectrum:", np.allclose(red(lap(n, H2, [alpha] * len(H2))), sig2))
print("   best squared residual on K6-M3 (should stay > 0):", round(best_fit(n, G2, sig2), 6))

print("== 3. Singular-limit lemma: bounded eigenvalues -> quotient pencil (random graph)")
n = 7
Gr = nx.gnp_random_graph(n, 0.6, seed=3)
while not nx.is_connected(Gr): Gr = nx.gnp_random_graph(n, 0.6, seed=int(rng.integers(1000)))
E = list(Gr.edges()); Gam = [E[0], E[2]] if len(E) > 3 else [E[0]]
w0 = rng.exponential(size=len(E))
comp = nx.connected_components(nx.Graph(Gam + [(v, v) for v in range(n)]))
parts = [sorted(c) for c in comp]; h = len(parts); idx = {v: i for i, p in enumerate(parts) for v in p}
LQ = np.zeros((h, h))
for (a, b), x in zip(E, w0):
    if (a, b) in Gam: continue
    i, j = idx[a], idx[b]
    if i != j: LQ[i, i] += x; LQ[j, j] += x; LQ[i, j] -= x; LQ[j, i] -= x
Mm = np.diag([len(p) for p in parts]).astype(float)
xi = np.sort(np.linalg.eigvals(np.linalg.solve(Mm, LQ)).real)
for T in [1e2, 1e4, 1e6]:
    w = np.array([T if f in Gam else x for f, x in zip(E, w0)])
    ev = np.sort(np.linalg.eigvalsh(lap(n, E, w)))
    print(f"   t={T:.0e}: bounded part {np.round(ev[:h], 5)}  vs pencil {np.round(xi, 5)}; next eigenvalue {ev[h]:.3e}")

print("== 4. Hadwiger example P4 -> C4 (had 2 -> 3): witness sigma(t) of C4 with equal bottom pair")
# C4 = 0-1-2-3-0 ; e = (3,0) ; parts {0},{1},{2,3}? use partition into 3 connected parts pairwise adjacent
n = 4; G = [(0, 1), (1, 2), (2, 3)]; H = G + [(3, 0)]
parts = [[0], [1], [2, 3]]; m = [1, 1, 2]
for t in [10.0, 100.0]:
    w = {(2, 3): t, (0, 1): m[0] * m[1] / n, (1, 2): m[1] * m[2] / n, (3, 0): m[2] * m[0] / n}
    sig = red(lap(n, H, [w[f] for f in H]))
    print(f"   t={t}: sigma(t)={np.round(sig,5)}; best residual on P4 = {best_fit(n, G, sig, 40):.3e}")

print("== 5. Lift identity E[N_A]=(n+1)/2 U(A) and N ~ Uniform{1..n} (Monte Carlo)")
for n in [4, 6]:
    X = rng.exponential(size=(200000, n)); mn = X.min(axis=1, keepdims=True)
    adm = X <= (n + 1) * mn; N = adm.sum(axis=1)
    print(f"   n={n}: P(N=k) =", np.round(np.bincount(N, minlength=n + 1)[1:] / len(N), 4), " (should be 1/n each)")
    # A = {max/min >= 3} on R^{n-1}
    cnt = 0
    for x, a in zip(X[:50000], adm[:50000]):
        for j in np.nonzero(a)[0]:
            mu = np.delete(x, j) - x[j] / (n + 1)
            cnt += (mu.max() >= 3 * mu.min())
    Y = rng.exponential(size=(200000, n - 1)); UA = np.mean(Y.max(axis=1) >= 3 * Y.min(axis=1))
    print(f"   n={n}: E[N_A]={cnt/50000:.4f}  vs (n+1)/2*U(A)={(n+1)/2*UA:.4f}")
