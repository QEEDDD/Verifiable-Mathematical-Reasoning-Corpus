#!/usr/bin/env python3
# R4 -- exact check of Remark R4:rem:dichotomy (n=6):
# for the domino D = P2 x P3 and the long diagonal e joining opposite corners, the two classical
# extremal problems do NOT separate D from D+e:
#     max lambda_2/tr (D) = max lambda_2/tr (D+e) = 1/11,   min lambda_n/tr (D) = min lambda_n/tr (D+e) = 1/3,
# although P(D+e) > P(D) (certificate in q3_certs_n6.json, re-checked here with mpmath at 60 digits).
# Run:  python3 -I R4_domino.py
import json, itertools
from fractions import Fraction as Fr
import sympy as sp
import mpmath as mp

D = [(0, 1), (0, 3), (0, 5), (1, 2), (2, 3), (3, 4), (4, 5)]   # atlas labelling (rows 1-0-5 / 2-3-4)
e = (1, 4)
n = 6
t = sp.symbols('t')

def lap(edges, w):
    L = sp.zeros(n, n)
    for (a, b), x in zip(edges, w):
        L[a, a] += x; L[b, b] += x; L[a, b] -= x; L[b, a] -= x
    return L

def roots_exact(L):
    p = sp.factor(L.charpoly(t).as_expr())
    return p, sorted(sp.roots(sp.Poly(L.charpoly(t).as_expr(), t)).items())

print("== 1. Weighting of D attaining lambda_2/tr = 1/11 (outer rungs 1/22, middle rung 1/22, row edges 1/11)")
w = {(1, 2): Fr(1, 22), (4, 5): Fr(1, 22), (0, 3): Fr(1, 22),
     (0, 1): Fr(1, 11), (0, 5): Fr(1, 11), (2, 3): Fr(1, 11), (3, 4): Fr(1, 11)}
L1 = lap(D, [sp.Rational(w[f].numerator, w[f].denominator) for f in D])
p, r = roots_exact(L1)
print("   trace =", L1.trace(), "; char. poly =", p)
print("   eigenvalues (with multiplicity):", r)

print("== 2. Test vector x=(1,-1,-3,-1,1,3): every edge of D+e has |x_a-x_b|=2, sum x=0, |x|^2=22")
x = [1, -1, -3, -1, 1, 3]
print("   sum x =", sum(x), "; |x|^2 =", sum(v * v for v in x))
print("   |dx| on D+e edges:", [abs(x[a] - x[b]) for a, b in D + [e]])
print("   => for every w>=0 on D+e with tr L = 1:  lambda_2 <= x^T L x/|x|^2 = 4*(1/2)/22 = 1/11.")

print("== 3. Weighting of D attaining lambda_n/tr = 1/3 (outer rungs 1/9, middle rung 1/18, row edges 1/18)")
w2 = {(1, 2): Fr(1, 9), (4, 5): Fr(1, 9), (0, 3): Fr(1, 18),
      (0, 1): Fr(1, 18), (0, 5): Fr(1, 18), (2, 3): Fr(1, 18), (3, 4): Fr(1, 18)}
L2 = lap(D, [sp.Rational(w2[f].numerator, w2[f].denominator) for f in D])
p2, r2 = roots_exact(L2)
print("   trace =", L2.trace(), "; eigenvalues:", r2)
y = [1, -1, 1, -1, 1, -1]   # bipartition {0,2,4} | {1,3,5}
print("== 4. Bipartition vector y: |dy| on D+e edges:", [abs(y[a] - y[b]) for a, b in D + [e]],
      "; |y|^2 =", sum(v * v for v in y), "; sum y =", sum(y))
print("   => for every w>=0 on D+e with tr L = 1:  lambda_n >= y^T L y/|y|^2 = 4*(1/2)/6 = 1/3.")

print("== 5. The stored certificate for (D, e) re-checked independently with mpmath (60 digits)")
mp.mp.dps = 60
data = json.load(open('q3_certs_n6.json'))
c = [c for c in data['certs'] if sorted(map(tuple, c['G'])) == sorted(D) and sorted(c['e']) == sorted(e)][0]
wq = [mp.mpf(Fr(s).numerator) / Fr(s).denominator for s in c['w']]
EH = [tuple(f) for f in c['G']] + [tuple(c['e'])]
Lm = mp.zeros(n, n)
for (a, b), v in zip(EH, wq):
    Lm[a, a] += v; Lm[b, b] += v; Lm[a, b] -= v; Lm[b, a] -= v
sig = sorted(mp.eigsy(Lm)[0])[1:]
Y = mp.matrix([[mp.mpf(Fr(s).numerator) / Fr(s).denominator for s in row] for row in c['Y']])
H = mp.eye(n) - mp.ones(n, n) / n
th = sorted(mp.eigsy(H * Y * H)[0])
# drop the eigenvalue belonging to the all-ones vector (HYH 1 = 0): remove the entry closest to 0
# whose eigenvector is ~ 1; simpler: compute on an orthonormal basis of 1^perp
U = mp.matrix(n, n - 1)
for k in range(n - 1):          # Helmert basis of 1^perp
    for i in range(k + 1): U[i, k] = 1 / mp.sqrt((k + 1) * (k + 2))
    U[k + 1, k] = -(k + 1) / mp.sqrt((k + 1) * (k + 2))
th = sorted(mp.eigsy(U.T * Y * U)[0])
val = sum(a * b for a, b in zip(th, sorted(sig, reverse=True)))
edge_ok = all(Fr(c['Y'][a][a]) + Fr(c['Y'][b][b]) - 2 * Fr(c['Y'][a][b]) <= 0 for a, b in map(tuple, c['G']))
print("   witness weights >= 0:", all(Fr(s) >= 0 for s in c['w']), "; edge constraints b^T Y b <= 0 (exact):", edge_ok)
print("   sum theta_asc * sigma_desc =", mp.nstr(val, 20), "(> 0 => sigma not in R(D))")
print("   normalised witness spectrum sigma/tr =", [mp.nstr(s / sum(sig), 8) for s in sig])
print("   its lambda_2/tr =", mp.nstr(sig[0] / sum(sig), 10), "<= 1/11 =", mp.nstr(mp.mpf(1) / 11, 10),
      "; lambda_n/tr =", mp.nstr(sig[-1] / sum(sig), 10), ">= 1/3")
