#!/usr/bin/env python3
# R4 / EJT Question 4 (suspension) -- numerical evidence quoted in section.tex and status.md.
# NOT part of any proof.  Run:  python3 -I R4_q4_numerics.py
#  A. gamma_n = inf_theta g(theta),  g(theta) = ((n+1)/2) E_{r~rho_n}[1/N(theta,r)],
#     rho_n(r) = 2(n-1)(1+2r)^{-n};  g is integrated exactly (piecewise constant N, closed-form tail).
#     Also checks that the theta-average of g is 1 (lift identity).
#  B. Best "rank rule" (select the admissible index of rank k among N with prob. phi(k,N)):
#     LP for max_phi min_theta of the output density; < 1 means rank rules cannot prove Conj. R4:conj:cone.
#  C. Monte Carlo test of the cone-lifting inequality U_n(J(A)) >= U_{n-1}(A) for many symmetric cones A.
import numpy as np
from scipy.optimize import minimize, linprog
rng = np.random.default_rng(4)

def tail(a, n):                      # rho_n([a, inf))
    return (1 + 2 * a) ** (-(n - 1))

def pieces(th, n):
    """(mass, N, k) for the pieces of r in [0,inf) on which N(theta,r) and the rank k of the
    inserted entry (n+1)r/n among nu are constant."""
    th = np.sort(np.asarray(th, float)); th = th / th.sum(); m = th[0]
    bps = {0.0, m}
    for d in th:
        if d / (n + 2) < m: bps.add(d / (n + 2))
        if d - (n + 1) * m > m: bps.add(d - (n + 1) * m)
        bps.add(d)                     # rank of the inserted entry changes at r = theta_i
    bps = sorted(bps) + [np.inf]
    out = []
    for a, b in zip(bps[:-1], bps[1:]):
        r = a * (1 + 1e-9) + 1e-14 if b == np.inf else (a + b) / 2
        N = 1 + (np.sum(th <= (n + 2) * r) if r < m else np.sum(th <= (n + 1) * m + r))
        k = min(1 + np.sum(th < r), N)
        out.append((tail(a, n) - (0.0 if b == np.inf else tail(b, n)), N, k))
    return out

def g(th, n):
    return (n + 1) / 2 * sum(mass / N for mass, N, k in pieces(th, n))

print("== A. gamma_n (uniform-random choice among admissible indices)")
for n in range(3, 9):
    X = rng.exponential(size=(6000, n - 1))
    vals = np.array([g(x, n) for x in X])
    best, bD = 9.0, None
    for x in X[np.argsort(vals)[:8]]:
        r = minimize(lambda z: g(np.abs(z) + 1e-12, n), x, method='Nelder-Mead',
                     options={'maxiter': 3000, 'xatol': 1e-10, 'fatol': 1e-12})
        if r.fun < best: best, bD = r.fun, np.sort(np.abs(r.x)) / np.abs(r.x).sum()
    print(f"   n={n}: average of g over uniform theta = {vals.mean():.4f} (lift identity: 1);"
          f"  gamma_n ~ {best:.4f}  (trivial bound (n+1)/(2n) = {(n+1)/(2*n):.4f});"
          f"  minimiser theta ~ {np.round(bD, 3)}")

print("== B. best rank-based selection rule (LP over sampled directions, validated on fresh ones)")
def rank_rule(n, S=2500):
    keys = [(k, N) for N in range(1, n + 1) for k in range(1, N + 1)]
    idx = {kk: i for i, kk in enumerate(keys)}
    th_list = list(rng.exponential(size=(S, n - 1)))
    for s in range(S // 3):
        x = rng.exponential(size=n - 1); x[rng.random(n - 1) < 0.5] *= rng.choice([1e-3, 1e-2, 1e-1])
        th_list.append(x)
    def row(th):
        v = np.zeros(len(keys))
        for mass, N, k in pieces(th, n): v[idx[(k, N)]] += mass
        return (n + 1) / 2 * v
    A = np.array([row(th) for th in th_list])
    nv = len(keys) + 1
    c = np.zeros(nv); c[-1] = -1
    Aub = np.hstack([-A, np.ones((len(A), 1))])
    Aeq = []
    for N in range(1, n + 1):
        rr = np.zeros(nv)
        for k in range(1, N + 1): rr[idx[(k, N)]] = 1
        Aeq.append(rr)
    res = linprog(c, A_ub=Aub, b_ub=np.zeros(len(A)), A_eq=np.array(Aeq), b_eq=np.ones(n),
                  bounds=[(0, 1)] * len(keys) + [(None, None)], method='highs')
    phi = res.x[:-1]
    worst = min(row(th) @ phi for th in rng.exponential(size=(8000, n - 1)))
    return res.x[-1], worst
for n in [3, 4, 5, 6]:
    lp, fresh = rank_rule(n)
    print(f"   n={n}: max over rank rules of min_theta density: LP {lp:.4f}, fresh-sample min {fresh:.4f}"
          "  (a value < 1 means no rank rule proves the conjecture)")

print("== C. Monte Carlo: U_n(J(A)) versus U_{n-1}(A) for symmetric cones A (ratio should be >= 1)")
def cone_tests(m):
    T = {}
    for C in [1.2, 2.0, 5.0]:
        T[f"max/min <= {C}"] = (lambda C: lambda x: x[..., -1] <= C * x[..., 0])(C)
    kap = (m + 1) / (m - 1)
    T[f"max/min >= {kap:.3f} (= R(K_{m+1}-e))"] = lambda x: x[..., -1] >= kap * x[..., 0]
    for kp in [1.5, 3.0]:
        T[f"max/min >= {kp}"] = (lambda kp: lambda x: x[..., -1] >= kp * x[..., 0])(kp)
    for q in [0.3, 0.8]:
        T[f"x1 >= {q} x2 (bottom pair close)"] = (lambda q: lambda x: x[..., 0] >= q * x[..., 1])(q)
        T[f"x(m-1) >= {q} x(m) (top pair close)"] = (lambda q: lambda x: x[..., -2] >= q * x[..., -1])(q)
    for cc in [0.3, 0.7]:
        T[f"x1 >= {cc}*mean"] = (lambda cc: lambda x: x[..., 0] >= cc * x.mean(axis=-1))(cc)
        T[f"x1 <= {cc}*mean"] = (lambda cc: lambda x: x[..., 0] <= cc * x.mean(axis=-1))(cc)
    T["(x1<=0.3 mean) or (max/min<=1.5)"] = lambda x: (x[..., 0] <= 0.3 * x.mean(axis=-1)) | (x[..., -1] <= 1.5 * x[..., 0])
    T["0.5 x2 <= x1 <= 0.8 x2"] = lambda x: (x[..., 0] >= 0.5 * x[..., 1]) & (x[..., 0] <= 0.8 * x[..., 1])
    return T
for n in [3, 4, 5, 6, 8]:
    m = n - 1; M = 300000
    s = np.sort(rng.exponential(size=(M, n)), axis=1)
    adm = s <= (n + 1) * s[:, :1]
    Y = np.sort(rng.exponential(size=(M, m)), axis=1)
    worst = (9, None)
    for name, f in cone_tests(m).items():
        NA = np.zeros(M, int)
        for k in range(n):
            mu = np.delete(s, k, axis=1) - s[:, k:k + 1] / (n + 1)
            NA += (adm[:, k] & f(mu)).astype(int)
        PJ = np.mean(NA >= 1); UA = np.mean(f(Y)); UA_lift = 2 * NA.mean() / (n + 1)
        ratio = PJ / UA if UA > 0 else np.nan
        if ratio < worst[0]: worst = (ratio, name)
        print(f"   n={n:d} {name:42s} U_n(J(A))={PJ:.4f}  U_(n-1)(A)={UA:.4f} (via lift {UA_lift:.4f})  ratio={ratio:.4f}")
    print(f"   n={n}: smallest ratio {worst[0]:.4f} for cone '{worst[1]}'")
