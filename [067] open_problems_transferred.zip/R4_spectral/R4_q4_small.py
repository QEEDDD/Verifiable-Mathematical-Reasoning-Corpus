#!/usr/bin/env python3
# R4 / EJT Question 4 for all graphs on at most four vertices -- computer-assisted, exact certification.
#
# For G on 4 vertices with (relaxed) ordered region A_G in R^3 (a<=b<=c), the uniform join gives
#     P(G v K1) >= U_4(J(A_G)) = Pr[ some admissible j with mu^(j)(nu) in A_G ],  nu ~ Exp(1)^4,
# (Lemma R4:lem:join and eq. R4:eq:Jbound).  We certify  U_4(J(A_G)) > P(G)  rigorously:
#   * sorted nu via Renyi spacings; its direction e = E/sum(E) is uniform on the 3-simplex;
#   * dyadic boxes in (e2,e3,e4); exact box mass 6*vol(box & simplex) by inclusion-exclusion;
#   * a box is certified if for some k the k-th removal is admissible and mu^(k) lies in A_G
#     on the whole box -- first a fast floating-point pass, then EXACT re-verification of every
#     certified box with exact rational interval arithmetic;
#   * the certified mass (an exact rational) is a lower bound for U_4(J(A_G)).
# Regions (nonnegative weights) from Erchenko-Jakobson-Tsypin, Theorems 3.1, 4.1, 5.1, 6.1:
#   K13: (6x^2-2xy-2xz+yz)(6y^2-2xy-2yz+xz)(6z^2-2xz-2yz+xy) <= 0
#   C4 : max >= (x+y+z)/2                    paw: sqrt3|x-y| >= x+y for some pair
#   P4 : max >= (x+y+z)/2 and (9(x^3+y^3+z^3)-13U+62xyz)^2 <= (3S-2P)^2 (9S-14P)
# For ordered a<=b<=c these are checked (part 1) to coincide off the boundary with the simple forms
#   K13: f1=6a^2-2ab-2ac+bc >= 0 and f2=6b^2-2ab-2bc+ac <= 0 ;  C4: c >= a+b ;  paw: c >= (2+sqrt3) a ;
#   P4 : b > 2a and c(b-2a) >= b(b-a).
# Volumes P(G): exact values from the four-vertex census (EJT; manuscript K-015 of the series); re-estimated by MC here.
# Run:  python3 -I R4_q4_small.py
import numpy as np, sys, time
from fractions import Fraction as Fr
import mpmath as mp
rng = np.random.default_rng(2026)

# ---------------------------------------------------------------- part 1: region forms
def ejt(name, x, y, z):
    if name == 'K13':
        return (6*x*x-2*x*y-2*x*z+y*z)*(6*y*y-2*x*y-2*y*z+x*z)*(6*z*z-2*x*z-2*y*z+x*y) <= 0
    if name == 'C4':
        return np.maximum(np.maximum(x, y), z) >= (x+y+z)/2
    if name == 'paw':
        s = np.sqrt(3)
        return (s*abs(x-y) >= x+y) | (s*abs(x-z) >= x+z) | (s*abs(y-z) >= y+z)
    if name == 'P4':
        S = x*x+y*y+z*z; P = x*y+x*z+y*z; U = x*x*(y+z)+y*y*(x+z)+z*z*(x+y)
        lhs = (9*(x**3+y**3+z**3)-13*U+62*x*y*z)**2; rhs = (3*S-2*P)**2*(9*S-14*P)
        return (np.maximum(np.maximum(x, y), z) >= (x+y+z)/2) & (lhs <= rhs)
def simple(name, a, b, c):
    if name == 'K13': return (6*a*a-2*a*b-2*a*c+b*c >= 0) & (6*b*b-2*a*b-2*b*c+a*c <= 0)
    if name == 'C4': return c >= a+b
    if name == 'paw': return c >= (2+np.sqrt(3))*a
    if name == 'P4': return (b > 2*a) & (c*(b-2*a) >= b*(b-a))
print("== 0. P(G) re-computed independently: P(G) = 12 * iint_Omega dp dq/(1+p+q)^3, p=b/a, q=c/a")
mp.mp.dps = 30
_s3 = mp.sqrt(3)
def vol_quad(lo_q, hi_q, p0, p1):
    # 6 * int_{p0}^{p1} [(1+p+lo)^-2 - (1+p+hi)^-2] dp   (hi may be inf)
    f = lambda p: (1+p+lo_q(p))**-2 - (0 if hi_q(p) == mp.inf else (1+p+hi_q(p))**-2)
    return 6*mp.quad(f, [p0, p1])
VOLQ = {
    'K13': vol_quad(lambda p: 2*p*(3*p-1)/(2*p-1), lambda p: (6-2*p)/(2-p), 1, 2)
           + vol_quad(lambda p: 2*p*(3*p-1)/(2*p-1), lambda p: mp.inf, 2, mp.inf),
    'P4': vol_quad(lambda p: p*(p-1)/(p-2), lambda p: mp.inf, 2, 2+mp.sqrt(2)) +
          vol_quad(lambda p: p*(p-1)/(p-2), lambda p: mp.inf, 2+mp.sqrt(2), mp.inf),
    'paw': vol_quad(lambda p: 2+_s3, lambda p: mp.inf, 1, 2+_s3) + vol_quad(lambda p: p, lambda p: mp.inf, 2+_s3, mp.inf),
    'C4': vol_quad(lambda p: 1+p, lambda p: mp.inf, 1, mp.inf)}
for k_, v_ in VOLQ.items():
    print(f"   {k_:4s}: quadrature P(G) = {mp.nstr(v_, 15)}")
print("== 1. EJT regions vs. the ordered forms used below (random points, permuted inputs)")
X = rng.exponential(size=(1_000_000, 3)) * rng.exponential(size=(1_000_000, 1))
Srt = np.sort(X, axis=1)
for name in ['K13', 'C4', 'paw', 'P4']:
    e = ejt(name, X[:, 0], X[:, 1], X[:, 2]); s = simple(name, Srt[:, 0], Srt[:, 1], Srt[:, 2])
    print(f"   {name:4s}: disagreements {np.sum(e != s)} of {len(e)}; volume (MC) {s.mean():.4f}")

# ---------------------------------------------------------------- part 2: certification
# Coordinates: sorted nu = (s1<s2<s3<s4) with spacings s1=E1/4, s2-s1=E2/3, s3-s2=E3/2, s4-s3=E4
# (Renyi), E i.i.d. Exp(1); the direction e=E/sum(E) is uniform on the 3-simplex, and all events
# are scale-invariant.  Boxes in (e2,e3,e4) in [0,1]^3, e1 = 1-e2-e3-e4; mass = 6*vol(box & {e2+e3+e4<=1}).
# s_i are affine in (e2,e3,e4):  (const, c2, c3, c4)
SF = [(Fr(1, 4), Fr(-1, 4), Fr(-1, 4), Fr(-1, 4)),
      (Fr(1, 4), Fr(1, 12), Fr(-1, 4), Fr(-1, 4)),
      (Fr(1, 4), Fr(1, 12), Fr(1, 4), Fr(-1, 4)),
      (Fr(1, 4), Fr(1, 12), Fr(1, 4), Fr(3, 4))]
def lin_sub(p, q, cq=Fr(1)): return tuple(pi - cq*qi for pi, qi in zip(p, q))
FORMS = []
for k in range(4):   # removal of s_k; mu = (s_i - s_k/5)_{i != k}, already sorted
    FORMS.append([lin_sub(SF[i], SF[k], Fr(1, 5)) for i in range(4) if i != k])
KAP_HI = Fr(373205080757, 10**11)   # > 2+sqrt(3) = 3.7320508075688...
KAP_LO = Fr(373205080756, 10**11)   # < 2+sqrt(3)

# --- numpy interval helpers (float pass); intervals are (lo, hi) arrays
def imul(x, y):
    p = np.stack([x[0]*y[0], x[0]*y[1], x[1]*y[0], x[1]*y[1]])
    return (p.min(axis=0), p.max(axis=0))
def iadd(x, y): return (x[0]+y[0], x[1]+y[1])
def isub(x, y): return (x[0]-y[1], x[1]-y[0])
def isc(c, x): return (c*x[0], c*x[1]) if c >= 0 else (c*x[1], c*x[0])
def iaff(form, L, H):
    lo = np.full(L.shape[0], float(form[0])); hi = lo.copy()
    for j in range(3):
        cj = float(form[j+1])
        if cj == 0: continue
        if cj > 0: lo = lo + cj*L[:, j]; hi = hi + cj*H[:, j]
        else: lo = lo + cj*H[:, j]; hi = hi + cj*L[:, j]
    return (lo, hi)
def status_np(name, a, b, c, eps=1e-13):
    """(certainly_in, certainly_out) of A_G for mu=(a,b,c) given as intervals"""
    if name == 'C4':
        d = isub(c, iadd(a, b)); return d[0] > eps, d[1] < -eps
    if name == 'paw':
        d1 = isub(c, isc(float(KAP_HI), a)); d2 = isub(c, isc(float(KAP_LO), a))
        return d1[0] > eps, d2[1] < -eps
    if name == 'K13':
        bm2a = isub(b, isc(2.0, a))
        f1 = iadd(isub(isc(6.0, imul(a, a)), isc(2.0, imul(a, b))), imul(c, bm2a))
        f2 = iadd(imul(b, isub(isub(isc(6.0, b), isc(2.0, a)), isc(2.0, c))), imul(a, c))
        return (f1[0] > eps) & (f2[1] < -eps), (f1[1] < -eps) | (f2[0] > eps)
    if name == 'P4':
        bm2a = isub(b, isc(2.0, a))
        g = isub(imul(c, bm2a), imul(b, isub(b, a)))
        return (bm2a[0] > eps) & (g[0] > eps), (bm2a[1] < -eps) | (g[1] < -eps)

# --- exact rational intervals
def emul(x, y):
    ps = [x[0]*y[0], x[0]*y[1], x[1]*y[0], x[1]*y[1]]
    return (min(ps), max(ps))
def eadd(x, y): return (x[0]+y[0], x[1]+y[1])
def esub(x, y): return (x[0]-y[1], x[1]-y[0])
def esc(c, x): return (c*x[0], c*x[1]) if c >= 0 else (c*x[1], c*x[0])
def eaff(form, L, H):
    lo = Fr(form[0]); hi = Fr(form[0])
    for j in range(3):
        cj = Fr(form[j+1])
        if cj == 0: continue
        if cj > 0: lo += cj*L[j]; hi += cj*H[j]
        else: lo += cj*H[j]; hi += cj*L[j]
    return (lo, hi)
def certain_exact(name, a, b, c):
    if name == 'C4': return esub(c, eadd(a, b))[0] > 0
    if name == 'paw': return esub(c, esc(KAP_HI, a))[0] > 0
    if name == 'K13':
        bm2a = esub(b, esc(2, a))
        f1 = eadd(esub(esc(6, emul(a, a)), esc(2, emul(a, b))), emul(c, bm2a))
        f2 = eadd(emul(b, esub(esub(esc(6, b), esc(2, a)), esc(2, c))), emul(a, c))
        return f1[0] > 0 and f2[1] < 0
    if name == 'P4':
        bm2a = esub(b, esc(2, a))
        g = esub(emul(c, bm2a), emul(b, esub(b, a)))
        return bm2a[0] > 0 and g[0] > 0
def mass_exact(L, H):
    # 6 * vol( [L,H] & {x1+x2+x3 <= 1} ) by inclusion-exclusion over the corners
    tot = Fr(0)
    for S in range(8):
        sgn = -1 if bin(S).count('1') % 2 else 1
        r = 1 - sum(H[j] if (S >> j) & 1 else L[j] for j in range(3))
        if r > 0: tot += sgn * r**3
    return tot   # = 6 * (1/6) * sum
def mass_float(L, H):
    tot = np.zeros(L.shape[0])
    for S in range(8):
        sgn = -1.0 if bin(S).count('1') % 2 else 1.0
        r = 1 - sum(np.where((S >> j) & 1, H[:, j], L[:, j]) for j in range(3))
        tot += sgn * np.maximum(r, 0.0)**3
    return tot
def exact_certify(name, bx):
    L = [Fr(int(bx[j][0]), int(bx[j][2])) for j in range(3)]
    H = [Fr(int(bx[j][1]), int(bx[j][2])) for j in range(3)]
    for k in range(4):
        a = eaff(FORMS[k][0], L, H)
        if not a[0] > 0: continue
        b = eaff(FORMS[k][1], L, H); c = eaff(FORMS[k][2], L, H)
        if certain_exact(name, a, b, c):
            return mass_exact(L, H)
    return None

def run(name, depth):
    lev = 0; lo = np.zeros((1, 3), np.int64); hi = np.ones((1, 3), np.int64)
    cert_boxes = []; float_cert = 0.0
    while True:
        D = 2.0**lev
        L = lo/D; H = hi/D
        inside = (L.sum(axis=1) < 1)            # box meets the simplex
        lo, hi, L, H = lo[inside], hi[inside], L[inside], H[inside]
        cin = np.zeros(len(lo), bool); cout = np.ones(len(lo), bool)
        for k in range(4):
            a = iaff(FORMS[k][0], L, H)
            b = iaff(FORMS[k][1], L, H); c = iaff(FORMS[k][2], L, H)
            i_in, i_out = status_np(name, a, b, c)
            cin |= (a[0] > 1e-13) & i_in
            cout &= (a[1] < -1e-13) | i_out
        m = mass_float(L, H)
        float_cert += m[cin].sum()
        for idx in np.nonzero(cin)[0]:
            cert_boxes.append([(lo[idx, j], hi[idx, j], 2**lev) for j in range(3)])
        und = ~cin & ~cout
        print(f"   [{name}] level {lev}: boxes {len(lo)}, certified (float) {float_cert:.5f}, "
              f"undecided mass {m[und].sum():.5f} in {und.sum()} boxes", flush=True)
        if lev == depth or und.sum() == 0: break
        lo, hi = lo[und]*2, hi[und]*2
        mid = (lo+hi)//2
        nl = []; nh = []
        for i in range(8):
            sel = [(i >> j) & 1 for j in range(3)]
            nl.append(np.stack([np.where(sel[j], mid[:, j], lo[:, j]) for j in range(3)], 1))
            nh.append(np.stack([np.where(sel[j], hi[:, j], mid[:, j]) for j in range(3)], 1))
        lo = np.concatenate(nl); hi = np.concatenate(nh); lev += 1
    t = time.time(); LB = Fr(0); bad = 0
    for bx in cert_boxes:
        mm = exact_certify(name, bx)
        if mm is None: bad += 1
        else: LB += mm
    return LB, len(cert_boxes), bad, time.time()-t

mp.mp.dps = 40
s33 = mp.sqrt(33); s5 = mp.sqrt(5)
PG = {'K13': mp.mpf(1)/11 + 8*s33/363*mp.log((161+17*s33)/128),
      'P4': mp.mpf(9)/10 + 3*s5/25*mp.log((3-s5)/(3+s5)),
      'paw': mp.mpf(9)/13, 'C4': mp.mpf(3)/4}
for k_ in PG:   # closed forms (census) must agree with the independent quadrature of part 0
    assert abs(PG[k_] - VOLQ[k_]) < mp.mpf(10)**-20, k_
    PG[k_] = max(PG[k_], VOLQ[k_]) + mp.mpf(10)**-20   # compare against a safe upper value
print("== 2. Certified lower bounds for U_4(J(A_G)) <= P(G v K1), compared with P(G)")
depth = int(sys.argv[1]) if len(sys.argv) > 1 else 8
for name in ['K13', 'P4', 'paw', 'C4']:
    LB, nb, bad, dt = run(name, depth)
    lbf = mp.mpf(LB.numerator)/LB.denominator
    print(f"   {name}: exact certified mass LB = {mp.nstr(lbf, 12)} from {nb} boxes "
          f"({bad} failed exact re-check, {dt:.0f}s);  P(G) = {mp.nstr(PG[name], 12)};  "
          f"LB - P(G) = {mp.nstr(lbf-PG[name], 6)}  =>  {'P(G v K1) > P(G) CERTIFIED' if lbf > PG[name] else 'not certified'}",
          flush=True)
print("== 3. Remaining connected non-complete graphs on <= 4 vertices (known exact values):")
print("   P3 (n=3): P(P3 v K1)=P(K4-e)=9/10 > P(P3)=1/2;  K4-e (n=4): P(K5-e)=1-1/C(9,3)=83/84 > P(K4-e)=9/10.")
