#!/usr/bin/env python3
# R4 -- numerical sanity check (not a proof) of the four-vertex regions of Erchenko-Jakobson-Tsypin
# used in R4_q4_small.py (ordered a<=b<=c):
#   K13: 6a^2-2ab-2ac+bc >= 0 >= 6b^2-2ab-2bc+ac ;  P4: b>2a, c(b-2a) >= b(b-a) ;
#   paw: c >= (2+sqrt3)a ;  C4: c >= a+b.
# (1) necessity: spectra of random nonnegative weightings satisfy the inequalities;
# (2) sufficiency (the direction used for the lower bound): random interior points of each region
#     are matched by a weighting (least squares from several starts; residual ~ 0).
# Run:  python3 -I R4_regions_check.py
import numpy as np
from scipy.optimize import least_squares
rng = np.random.default_rng(99)
GR = {'K13': [(0, 1), (0, 2), (0, 3)], 'P4': [(0, 1), (1, 2), (2, 3)],
      'paw': [(0, 1), (1, 2), (0, 2), (2, 3)], 'C4': [(0, 1), (1, 2), (2, 3), (3, 0)]}
def inA(name, a, b, c, tol=0.0):
    if name == 'K13': return (6*a*a-2*a*b-2*a*c+b*c >= -tol) and (6*b*b-2*a*b-2*b*c+a*c <= tol)
    if name == 'P4': return (b-2*a >= -tol) and (c*(b-2*a)-b*(b-a) >= -tol)
    if name == 'paw': return c-(2+np.sqrt(3))*a >= -tol
    if name == 'C4': return c-a-b >= -tol
def spec(E, w):
    L = np.zeros((4, 4))
    for (i, j), x in zip(E, w):
        L[i, i] += x; L[j, j] += x; L[i, j] -= x; L[j, i] -= x
    return np.sort(np.linalg.eigvalsh(L))[1:]
for name, E in GR.items():
    bad = 0
    for _ in range(20000):
        w = rng.exponential(size=len(E)) * (rng.random(len(E)) < 0.9)
        s = spec(E, w); t = s.sum()
        if t <= 0: continue
        s = s/t
        if not inA(name, *s, tol=1e-9): bad += 1
    worst = 0.0; tried = 0
    while tried < 60:
        x = np.sort(rng.exponential(size=3)); x = x/x.sum()
        if not inA(name, *x, tol=-1e-3): continue      # strictly inside (margin 1e-3)
        tried += 1
        best = 9.0
        for s0 in range(25):
            r = least_squares(lambda z: spec(E, z*z)-x, rng.random(len(E))+0.05, xtol=1e-15, ftol=1e-15, gtol=1e-15)
            best = min(best, np.max(np.abs(r.fun)))
            if best < 1e-10: break
        worst = max(worst, best)
    print(f"{name:4s}: necessity violations {bad}/20000 random weightings; "
          f"sufficiency: worst residual over {tried} interior targets = {worst:.2e}")
