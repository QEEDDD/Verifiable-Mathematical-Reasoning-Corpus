#!/usr/bin/env python3
# R4 / EJT Question 3 (connected version) -- certificate GENERATOR.
# For every connected non-complete graph G on n vertices and every nonedge e (up to Aut(G)),
# search for a witness spectrum sigma in R(G+e) \ R(G) with an exact certificate:
#   * w : nonnegative rational weights on E(G+e);  sigma = nonzero spectrum of L(w)
#   * Y : rational symmetric n x n matrix with  b_f^T Y b_f <= 0  for every f in E(G)
#   * sum_i theta_i(asc) * sigma_i(desc) > 0, theta = spectrum of H Y H on 1^perp.
# Validity (von Neumann): if L' in S_L^{>=0}(G) had spectrum sigma, then
#   sum theta_asc sigma_desc <= tr(Y L') = sum_f w'_f b_f^T Y b_f <= 0.
# Certificates are written to JSON; verification is done separately by q3_verify.py
import numpy as np, networkx as nx, itertools, sys, json
from fractions import Fraction
from networkx.algorithms.isomorphism import GraphMatcher
rng=np.random.default_rng(7)

def incid(n, edges):
    B=np.zeros((n,len(edges)))
    for k,(a,b) in enumerate(edges): B[a,k]=1; B[b,k]=-1
    return B
def fval(B, w, c):
    L=(B*w)@B.T
    ev,X=np.linalg.eigh(L)
    ev=ev[1:]; X=X[:,1:]
    return c@ev, ((B.T@X)**2)@c, ev, X
def hmax(B, c, iters=800, starts=4):
    m=B.shape[1]; best=-1e9; bw=None
    for s in range(starts):
        w=np.full(m,0.5/m) if s==0 else rng.dirichlet(np.ones(m))*0.5
        bv=-1e9; bwl=w.copy()
        for it in range(iters):
            v,g,_,_=fval(B,w,c)
            if v>bv: bv=v; bwl=w.copy()
            g=g-g.max()
            w=w*np.exp(2.0*g/(np.abs(g).max()+1e-12)/np.sqrt(it+1))
            w=0.5*w/w.sum()
        if bv>best: best=bv; bw=bwl
    return best,bw
def nonedge_orbits(G):
    n=G.number_of_nodes()
    autos=list(GraphMatcher(G,G).isomorphisms_iter())
    seen=set(); reps=[]
    for a,b in itertools.combinations(range(n),2):
        if G.has_edge(a,b): continue
        key=frozenset([a,b])
        if key in seen: continue
        seen|=set(frozenset([s[a],s[b]]) for s in autos); reps.append((a,b))
    return reps
def candidate_cs(n, extra=16):
    m=n-1; cs=[]
    for k in range(1,m): cs.append(np.array([1.0]*k+[0.0]*(m-k)))
    for k in range(1,m): cs.append(np.array([0.0]*(m-k)+[-1.0]*k))
    for t in [0.5,1,2,4]: cs.append(np.array([1.0]+[0.0]*(m-2)+[-t]))
    if m>=3:
        for t in [0.5,1,2]: cs.append(np.array([1.0,1.0]+[0.0]*(m-3)+[-t]))
    for r in range(extra): cs.append(np.sort(rng.normal(size=m))[::-1])
    return cs
def U_basis(n):
    # orthonormal basis of 1^perp
    M=np.eye(n)-np.ones((n,n))/n
    q,_=np.linalg.qr(M[:, :n-1]); return q[:, :n-1]
def find_Y(n, EG, sigma_desc, Y0):
    # maximize  g(S)=sum theta_asc(S) sigma_desc  s.t.  b_f'^T S b_f' <= 0 (f in E(G)),  ||S||_F<=1
    U=U_basis(n); Bp=[U.T@(np.eye(n)[a]-np.eye(n)[b]) for a,b in EG]
    S=U.T@Y0@U; S=(S+S.T)/2; S/=np.linalg.norm(S)+1e-15
    best=None; bestval=-1e9
    for it in range(6000):
        th,V=np.linalg.eigh(S)
        g=th@sigma_desc
        cons=np.array([b@S@b for b in Bp]); viol=cons.max()
        val=g-10.0*max(viol,0)
        if viol<=1e-12 and g>bestval: bestval=g; best=S.copy()
        # supergradient of g, minus gradient of max violated constraints
        G=(V*sigma_desc)@V.T
        if viol>0:
            j=int(np.argmax(cons)); G=G-10.0*np.outer(Bp[j],Bp[j])
        S=S+0.02/np.sqrt(it+1)*G; S=(S+S.T)/2; S/=max(1.0,np.linalg.norm(S))
    if best is None: return None,-1e9
    Y=U@best@U.T
    return Y,bestval
def rat(x,D=10**6): return Fraction(int(round(x*D)),D)
def run(n, out):
    graphs=[G for G in nx.graph_atlas_g() if G.number_of_nodes()==n and nx.is_connected(G) and G.number_of_edges()<n*(n-1)//2]
    cs=candidate_cs(n)
    certs=[]; fails=[]
    for gi,G in enumerate(graphs):
        EG=list(G.edges()); BG=incid(n,EG)
        hG=[hmax(BG,c) for c in cs]
        for (a,b) in nonedge_orbits(G):
            EH=EG+[(a,b)]; BH=incid(n,EH)
            gaps=[]
            for c,(hg,wg) in zip(cs,hG):
                hh,wh=hmax(BH,c)
                gaps.append(((hh-hg)/np.abs(c).sum(),c,wh,wg))
            gaps.sort(key=lambda t:-t[0])
            ok=False
            for gap,c,wh,wg in gaps[:6]:
                if gap<1e-6: break
                wq=[rat(x) for x in wh]
                wf=np.array([float(x) for x in wq])
                L=(BH*wf)@BH.T; sig=np.sort(np.linalg.eigvalsh(L))[1:][::-1]
                # natural dual start from G-optimum eigenvectors
                LG=(BG*wg)@BG.T; ev,X=np.linalg.eigh(LG); X=X[:,1:]
                Y0=(X*c)@X.T   # c on ascending eigenvectors
                M0=max((np.eye(n)[p]-np.eye(n)[q])@Y0@(np.eye(n)[p]-np.eye(n)[q]) for p,q in EG)
                Y0=Y0-(M0/2)*(np.eye(n)-np.ones((n,n))/n)
                Y,val=find_Y(n,EG,sig,Y0)
                if Y is None or val<=1e-9: continue
                # rationalize Y and shift so that constraints hold exactly
                Yq=[[rat(Y[i,j],10**8) for j in range(n)] for i in range(n)]
                for i in range(n):
                    for j in range(i): Yq[i][j]=Yq[j][i]
                Mx=max(Yq[p][p]+Yq[q][q]-2*Yq[p][q] for p,q in EG)
                if Mx>0:   # subtract (Mx/2) H to make all edge values <=0
                    for i in range(n):
                        for j in range(n):
                            Yq[i][j]-= (Mx/2)*((1 if i==j else 0)-Fraction(1,n))
                certs.append({"n":n,"G":[list(e) for e in EG],"e":[a,b],"w":[str(x) for x in wq],
                              "Y":[[str(x) for x in row] for row in Yq],"gap_est":float(gap),"margin_est":float(val)})
                ok=True; break
            if not ok:
                fails.append({"G":[list(e) for e in EG],"e":[a,b],"bestgap":float(gaps[0][0])})
                print("FAIL",EG,(a,b),gaps[0][0],flush=True)
        print(f"graph {gi+1}/{len(graphs)} done; certs={len(certs)} fails={len(fails)}",flush=True)
    json.dump({"certs":certs,"fails":fails},open(out,"w"))
    print("n",n,"certs",len(certs),"fails",len(fails))
if __name__=="__main__":
    run(int(sys.argv[1]), sys.argv[2])
