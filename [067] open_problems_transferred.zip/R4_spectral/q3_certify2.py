#!/usr/bin/env python3
# R4 / EJT Question 3 -- faster certificate GENERATOR (v2).
# Same certificate format as q3_certify.py (verified by q3_verify.py):
#   w >= 0 rational weights on E(G)+[e]  -> witness sigma = nonzero spectrum of L(w) (in R(G+e));
#   Y rational symmetric with b_f^T Y b_f <= 0 on E(G) and  sum theta_asc sigma_desc > 0
#   (theta = spectrum of HYH on 1^perp), which excludes sigma from R(G) by von Neumann.
# Strategy: for c in a short list of concave functionals (first lambda_2/tr, then -lambda_n/tr, ...)
# take a near-maximizer w of c.lambda over the trace-one weightings of G+e, then try to find Y.
import numpy as np, networkx as nx, itertools, sys, json
from fractions import Fraction
from networkx.algorithms.isomorphism import GraphMatcher
rng=np.random.default_rng(11)
def incid(n, edges):
    B=np.zeros((n,len(edges)))
    for k,(a,b) in enumerate(edges): B[a,k]=1; B[b,k]=-1
    return B
def hmax(B, c, iters=500, starts=3):
    m=B.shape[1]; best=-1e9; bw=None
    for s in range(starts):
        w=np.full(m,0.5/m) if s==0 else rng.dirichlet(np.ones(m))*0.5
        for it in range(iters):
            L=(B*w)@B.T; ev,X=np.linalg.eigh(L); ev=ev[1:]; X=X[:,1:]
            v=c@ev
            if v>best: best=v; bw=w.copy()
            g=((B.T@X)**2)@c; g=g-g.max()
            w=w*np.exp(2.0*g/(np.abs(g).max()+1e-12)/np.sqrt(it+1)); w=0.5*w/w.sum()
    return best,bw
def orbits(G):
    n=G.number_of_nodes(); autos=list(GraphMatcher(G,G).isomorphisms_iter()); seen=set(); reps=[]
    for a,b in itertools.combinations(range(n),2):
        if G.has_edge(a,b) or frozenset([a,b]) in seen: continue
        seen|=set(frozenset([s[a],s[b]]) for s in autos); reps.append((a,b))
    return reps
def U_basis(n):
    M=np.eye(n)-np.ones((n,n))/n; q,_=np.linalg.qr(M[:, :n-1]); return q[:, :n-1]
def find_Y(n, EG, sig_desc, Y0, iters=4000):
    U=U_basis(n); Bp=np.array([U.T@(np.eye(n)[a]-np.eye(n)[b]) for a,b in EG])
    S=U.T@Y0@U; S=(S+S.T)/2; S/=np.linalg.norm(S)+1e-15
    best=None; bestval=-1e9
    for it in range(iters):
        th,V=np.linalg.eigh(S); g=th@sig_desc
        cons=np.einsum('fi,ij,fj->f',Bp,S,Bp); viol=cons.max()
        if viol<=0 and g>bestval: bestval=g; best=S.copy()
        G=(V*sig_desc)@V.T
        if viol>0:
            j=int(np.argmax(cons)); G=G-10.0*np.outer(Bp[j],Bp[j])
        S=S+0.03/np.sqrt(it+1)*G; S=(S+S.T)/2; S/=max(1.0,np.linalg.norm(S))
    if best is None: return None,-1e9
    return U@best@U.T,bestval
def rat(x,D): return Fraction(int(round(x*D)),D)
def certify_pair(n, EG, e, cs):
    EH=EG+[e]; BH=incid(n,EH); BG=incid(n,EG)
    for c in cs:
        hh,wh=hmax(BH,c)
        wq=[rat(x,10**6) for x in wh]
        wf=np.array([float(x) for x in wq])
        L=(BH*wf)@BH.T; ev,X=np.linalg.eigh(L); X=X[:,1:]
        sig=np.sort(ev[1:])[::-1]
        # natural start: Y0 = sum c_i x_i x_i^T from the witness eigenvectors, shifted to satisfy G-edges
        Y0=(X*c)@X.T
        M0=max((BG[:,k]@Y0@BG[:,k]) for k in range(BG.shape[1]))
        Y0=Y0-(M0/2)*(np.eye(n)-np.ones((n,n))/n)
        Y,val=find_Y(n,EG,sig,Y0)
        if Y is None or val<=1e-7: continue
        Yq=[[rat(Y[i,j],10**9) for j in range(n)] for i in range(n)]
        for i in range(n):
            for j in range(i): Yq[i][j]=Yq[j][i]
        Mx=max(Yq[p][p]+Yq[q][q]-2*Yq[p][q] for p,q in EG)
        if Mx>0:
            for i in range(n):
                for j in range(n): Yq[i][j]-=(Mx/2)*((1 if i==j else 0)-Fraction(1,n))
        return {"n":n,"G":[list(x) for x in EG],"e":list(e),"w":[str(x) for x in wq],
                "Y":[[str(x) for x in row] for row in Yq],"c":[float(x) for x in c],"margin_est":float(val)}
    return None
def main(n,out,start=0,stop=None):
    m=n-1
    cs=[np.array([1.0]+[0.0]*(m-1)), np.array([0.0]*(m-1)+[-1.0])]
    for k in range(2,m): cs.append(np.array([1.0]*k+[0.0]*(m-k)))
    for k in range(2,m): cs.append(np.array([0.0]*(m-k)+[-1.0]*k))
    for t in [0.5,1,2]: cs.append(np.array([1.0]+[0.0]*(m-2)+[-t]))
    for r in range(6): cs.append(np.sort(rng.normal(size=m))[::-1])
    graphs=[G for G in nx.graph_atlas_g() if G.number_of_nodes()==n and nx.is_connected(G) and G.number_of_edges()<n*(n-1)//2]
    graphs=graphs[start:stop]
    certs=[]; fails=[]
    for gi,G in enumerate(graphs):
        EG=list(G.edges())
        for e in orbits(G):
            cert=certify_pair(n,EG,e,cs)
            if cert is None: fails.append({"G":[list(x) for x in EG],"e":list(e)}); print("FAIL",EG,e,flush=True)
            else: certs.append(cert)
        print(f"[{start+gi}] graphs done {gi+1}/{len(graphs)} certs={len(certs)} fails={len(fails)}",flush=True)
        json.dump({"certs":certs,"fails":fails},open(out,"w"))
    print("DONE n",n,"certs",len(certs),"fails",len(fails))
if __name__=="__main__":
    n=int(sys.argv[1]); out=sys.argv[2]
    start=int(sys.argv[3]) if len(sys.argv)>3 else 0
    stop=int(sys.argv[4]) if len(sys.argv)>4 else None
    main(n,out,start,stop)
