#!/usr/bin/env python3
# Extra effort for pairs where q3_certify2.py failed: many functionals, longer optimisation,
# several starting points for Y (including duals built from the G-optimal weighting).
import numpy as np, json, sys
from fractions import Fraction
sys.path.insert(0, '.')
import importlib.util
spec=importlib.util.spec_from_file_location("c2","q3_certify2.py"); c2=importlib.util.module_from_spec(spec); spec.loader.exec_module(c2)
rng=np.random.default_rng(5)
def try_pair(n,EG,e,cs,tries=3):
    EH=EG+[tuple(e)]; BH=c2.incid(n,EH); BG=c2.incid(n,EG)
    Hn=np.eye(n)-np.ones((n,n))/n
    best=None
    for c in cs:
        hh,wh=c2.hmax(BH,c,iters=1500,starts=5)
        hg,wg=c2.hmax(BG,c,iters=1500,starts=5)
        gap=(hh-hg)/np.abs(c).sum()
        if gap<1e-5: continue
        wq=[c2.rat(x,10**6) for x in wh]; wf=np.array([float(x) for x in wq])
        L=(BH*wf)@BH.T; ev,X=np.linalg.eigh(L); sig=np.sort(ev[1:])[::-1]
        starts=[]
        X=X[:,1:]; starts.append((X*c)@X.T)
        LG=(BG*wg)@BG.T; evg,XG=np.linalg.eigh(LG); XG=XG[:,1:]; starts.append((XG*c)@XG.T)
        for t in range(tries): starts.append(rng.normal(size=(n,n)))
        for Y0 in starts:
            Y0=(Y0+Y0.T)/2
            M0=max(BG[:,k]@Y0@BG[:,k] for k in range(BG.shape[1]))
            Y0=Y0-(M0/2)*Hn
            Y,val=c2.find_Y(n,EG,sig,Y0,iters=20000)
            if Y is not None and val>1e-7:
                Yq=[[c2.rat(Y[i,j],10**9) for j in range(n)] for i in range(n)]
                for i in range(n):
                    for j in range(i): Yq[i][j]=Yq[j][i]
                Mx=max(Yq[p][p]+Yq[q][q]-2*Yq[p][q] for p,q in EG)
                if Mx>0:
                    for i in range(n):
                        for j in range(n): Yq[i][j]-=(Mx/2)*((1 if i==j else 0)-Fraction(1,n))
                return {"n":n,"G":[list(x) for x in EG],"e":list(e),"w":[str(x) for x in wq],
                        "Y":[[str(x) for x in row] for row in Yq],"c":[float(x) for x in c],"margin_est":float(val),"gap":float(gap)}
        print("   c",np.round(c,3),"gap",gap,"no Y found",flush=True)
    return None
if __name__=="__main__":
    n=int(sys.argv[1]); files=sys.argv[2:-1]; out=sys.argv[-1]
    fails=[]
    for f in files: fails+=json.load(open(f))["fails"]
    m=n-1
    cs=[np.array([0.0]*(m-1)+[-1.0]), np.array([1.0]+[0.0]*(m-1))]
    for k in range(2,m): cs.append(np.array([0.0]*(m-k)+[-1.0]*k)); cs.append(np.array([1.0]*k+[0.0]*(m-k)))
    for t in [0.25,0.5,1,2,4,8]: cs.append(np.array([1.0]+[0.0]*(m-2)+[-t]))
    for r in range(30): cs.append(np.sort(rng.normal(size=m))[::-1])
    certs=[]; still=[]
    for fl in fails:
        EG=[tuple(x) for x in fl["G"]]; e=tuple(fl["e"])
        print("pair",EG,e,flush=True)
        cert=try_pair(n,EG,e,cs)
        if cert: certs.append(cert); print("  certified with c",np.round(cert["c"],3),"margin",cert["margin_est"],flush=True)
        else: still.append(fl); print("  STILL FAILING",flush=True)
    json.dump({"certs":certs,"fails":still},open(out,"w"))
