#!/usr/bin/env python3
# R4 / EJT Question 3 -- independent VERIFIER of the certificates produced by q3_certify.py.
# Exact rational arithmetic (fractions / python-flint fmpq) + rigorous ball arithmetic (arb) for
# eigenvalue enclosures.  For each connected non-complete graph G on n vertices (networkx atlas)
# and each Aut(G)-orbit of nonedges e, checks that some certificate proves R(G+e) != R(G):
#  (1) w >= 0 rational weights on E(G)+[e]; sigma = nonzero spectrum of L(w) (so sigma in R(G+e));
#  (2) Y rational symmetric with b_f^T Y b_f <= 0 for all f in E(G)  (exact);
#  (3) rigorous lower bound of  min_pi sum_i theta_i sigma_pi(i)  (= sum theta_asc sigma_desc) is > 0,
#      theta = eigenvalues of H Y H restricted to 1^perp.
# Then sigma is not in R(G) (von Neumann trace inequality), hence P(G+e) > P(G).
import sys, json, itertools
from fractions import Fraction
import flint, networkx as nx
from networkx.algorithms.isomorphism import GraphMatcher
flint.ctx.prec = 200

def fq(s): return flint.fmpq(Fraction(s).numerator, Fraction(s).denominator)
def nonzero_roots(M, n):
    p = M.charpoly()                       # degree n, divisible by x (M 1 = 0)
    co = [p[i] for i in range(n+1)]
    assert co[0] == 0, "constant term must vanish"
    q = flint.fmpq_poly(co[1:])            # p/x
    roots = []
    for r, mult in q.complex_roots():
        assert r.imag.contains(0), "non-real root?"
        roots += [r.real]*mult
    assert len(roots) == n-1
    return roots
def lap(n, edges, w):
    L = flint.fmpq_mat(n, n)
    for (a, b), x in zip(edges, w):
        L[a, a] += x; L[b, b] += x; L[a, b] -= x; L[b, a] -= x
    return L
def check_cert(c):
    n = c["n"]; EG = [tuple(e) for e in c["G"]]; a, b = c["e"]
    G = nx.Graph(); G.add_nodes_from(range(n)); G.add_edges_from(EG)
    assert nx.is_connected(G) and G.number_of_edges() < n*(n-1)//2
    assert not G.has_edge(a, b) and a != b
    w = [fq(x) for x in c["w"]]
    assert len(w) == len(EG)+1 and all(x >= 0 for x in w)
    L = lap(n, EG+[(a, b)], w)
    sig = nonzero_roots(L, n)
    Y = flint.fmpq_mat(n, n, [fq(x) for row in c["Y"] for x in row])
    for i in range(n):
        for j in range(n): assert Y[i, j] == Y[j, i]
    for (p, q) in EG:
        assert Y[p, p] + Y[q, q] - 2*Y[p, q] <= 0, "edge constraint violated"
    H = flint.fmpq_mat(n, n, [flint.fmpq(1 if i == j else 0) - flint.fmpq(1, n) for i in range(n) for j in range(n)])
    th = nonzero_roots(H*Y*H, n)
    # rigorous lower bound of min over permutations of sum theta_i sigma_pi(i)
    prods = [[(th[i]*sig[j]).lower() for j in range(n-1)] for i in range(n-1)]
    lb = min(sum(prods[i][pi[i]] for i in range(n-1)) for pi in itertools.permutations(range(n-1)))
    return lb > 0, lb

def coverage(n, certs):
    graphs = [G for G in nx.graph_atlas_g() if G.number_of_nodes() == n and nx.is_connected(G)
              and G.number_of_edges() < n*(n-1)//2]
    missing = 0; total = 0
    byG = {}
    for c in certs:
        byG.setdefault(tuple(sorted(tuple(sorted(e)) for e in c["G"])), []).append(c)
    for G in graphs:
        key = tuple(sorted(tuple(sorted(e)) for e in G.edges()))
        autos = list(GraphMatcher(G, G).isomorphisms_iter())
        seen = set()
        for a, b in itertools.combinations(range(n), 2):
            if G.has_edge(a, b) or frozenset([a, b]) in seen: continue
            orb = set(frozenset([s[a], s[b]]) for s in autos); seen |= orb; total += 1
            if not any(frozenset(c["e"]) in orb for c in byG.get(key, [])):
                missing += 1; print("UNCOVERED:", key, (a, b))
    return total, missing

if __name__ == "__main__":
    data = json.load(open(sys.argv[1])); n = int(sys.argv[2])
    good = []; bad = 0; minlb = None
    for c in data["certs"]:
        ok, lb = check_cert(c)
        if ok:
            good.append(c); minlb = lb if minlb is None or lb < minlb else minlb
        else:
            bad += 1; print("certificate FAILED:", c["G"], c["e"], lb)
    total, missing = coverage(n, good)
    print(f"n={n}: certificates checked={len(data['certs'])}, valid={len(good)}, invalid={bad}; "
          f"(G,nonedge-orbit) pairs={total}, uncovered={missing}; smallest certified lower bound={minlb}")
