"""R5 verification script 6: the individual steps of the proof of Theorem R5:thm:favard.

Checks:
 (1) discrete sine transform identity
       (2/N) sum_{i=1}^{N-1} (pi - i pi/N) sin(i j pi/N) = (pi/N) cot(j pi/(2N));
 (2) sign property sgn(B - sigma) = sgn sin(N theta) on (0, 2 pi) for the Favard
     interpolant sigma (dense grid);
 (3) int_0^infty sin^4(v)/v^3 dv = log 2  (numerical quadrature);
 (4) I(nu) = int_0^{pi/2} sin^4(nu u)/sin^3(u) du <= nu^2 log 2 + log nu + 1.21
     and the resulting bound (12/pi)(log 2 + (log nu + 1.21)/nu^2) < pi for nu >= 5;
 (5) the explicit lower-bound pairs of part (c): equal moments up to degree k and
     W1(p,q) >= (pi/k)(1 - 5 k^{-1/2}) for k = 4..300 (exact 1-D W1).
Run:  python3 -I R5_favard_proof_check.py
"""
import math
import numpy as np
import mpmath as mp


def check_dst():
    worst = 0.0
    for N in range(2, 60):
        for j in range(1, N):
            lhs = 2.0 / N * sum((math.pi - i * math.pi / N) * math.sin(i * j * math.pi / N) for i in range(1, N))
            rhs = math.pi / N / math.tan(j * math.pi / (2 * N))
            worst = max(worst, abs(lhs - rhs))
    print("(1) DST identity: max error over N<60: %.2e" % worst)
    assert worst < 1e-10


def check_sign():
    bad = 0
    for n in [1, 2, 3, 5, 8, 13, 30]:
        Np = n + 1
        th = np.linspace(1e-6, 2 * np.pi - 1e-6, 400001)
        lam = [(j * np.pi / (2 * Np)) / np.tan(j * np.pi / (2 * Np)) for j in range(1, n + 1)]
        sig = sum(2 * lam[j - 1] * np.sin(j * th) / j for j in range(1, n + 1))
        Th = (np.pi - th) - sig
        s = np.sin(Np * th)
        mask = np.abs(s) > 1e-6
        bad += int(np.sum(np.sign(Th[mask]) != np.sign(s[mask])))
    print("(2) sign property violations on dense grids: %d" % bad)
    assert bad == 0


def check_log2():
    mp.mp.dps = 30
    val = mp.quadosc(lambda v: mp.sin(v) ** 4 / v ** 3, [0, mp.inf], omega=2)
    print("(3) int_0^inf sin^4 v / v^3 dv = %s ; log 2 = %s" % (mp.nstr(val, 20), mp.nstr(mp.log(2), 20)))
    assert abs(val - mp.log(2)) < 1e-8   # quadosc accuracy; exact value by Frullani (see proof)


def check_I():
    mp.mp.dps = 25
    worst = -1e9
    for nu in range(3, 202, 2):
        I = mp.quad(lambda u: mp.sin(nu * u) ** 4 / mp.sin(u) ** 3, mp.linspace(0, mp.pi / 2, 4 * nu + 1))
        bound = nu ** 2 * mp.log(2) + mp.log(nu) + mp.mpf('1.21')
        worst = max(worst, I - bound)
        if nu in (3, 5, 7, 21, 101, 201):
            C = nu * (2 * nu ** 2 + 1) / mp.mpf(3)
            exact_const = (2 * nu - 2) * 4 / (mp.pi * C) * I
            print("    nu=%3d  I=%s  bound=%s  N*E[2|sin|]=%s  analytic bound=%s" % (
                nu, mp.nstr(I, 10), mp.nstr(bound, 10), mp.nstr(exact_const, 6),
                mp.nstr(12 / mp.pi * (mp.log(2) + (mp.log(nu) + mp.mpf('1.21')) / nu ** 2), 6)))
    print("(4) max of I(nu) - bound over odd nu in [3,201]: %s (must be <= 0)" % mp.nstr(worst, 6))
    assert worst <= 0
    assert 12 / mp.pi * (mp.log(2) + (mp.log(5) + mp.mpf('1.21')) / 25) < mp.pi


def w1_discrete(xp, wp, xq, wq):
    xs = np.concatenate([xp, xq])
    o = np.argsort(xs)
    xs = xs[o]
    m = np.concatenate([wp, -wq])[o]
    F = np.cumsum(m)[:-1]
    return float(np.sum(np.abs(F) * np.diff(xs)))


def check_lower():
    worst_ratio = 1e9
    worst_mom = 0.0
    for k in range(4, 301):
        D = math.ceil(math.sqrt(k))
        Np = k + 1 + 2 * D
        j = np.arange(Np + 1)
        th = j * np.pi / Np
        x = np.cos(th)
        w = np.full(Np + 1, 1.0 / Np)
        w[0] *= 0.5
        w[-1] *= 0.5
        c = w * np.sin(th) ** (2 * D) * (-1.0) ** j
        pos = c > 0
        neg = c < 0
        xp, wp = x[pos], c[pos] / c[pos].sum()
        xq, wq = x[neg], -c[neg] / (-c[neg]).sum()
        # moments of T_1..T_k
        thp, thq = np.arccos(xp), np.arccos(xq)
        mom = max(abs(np.sum(wp * np.cos(l * thp)) - np.sum(wq * np.cos(l * thq))) for l in range(1, k + 1))
        worst_mom = max(worst_mom, mom)
        W = w1_discrete(xp, wp, xq, wq)
        bound = (math.pi / k) * (1 - 5 / math.sqrt(k))
        if bound > 0:
            worst_ratio = min(worst_ratio, W / bound)
        else:
            assert W > 0
    print("(5) lower-bound pairs, k=4..300: max moment mismatch %.2e; min over k>25 of W1/[(pi/k)(1-5/sqrt k)] = %.4f (>= 1)" % (
        worst_mom, worst_ratio))
    assert worst_mom < 1e-9 and worst_ratio >= 1


if __name__ == "__main__":
    check_dst()
    check_sign()
    check_log2()
    check_I()
    check_lower()
    print("all assertions passed")
