"""R5 verification script 1: the Polyanskiy--Wu Gompertz critical-point conjecture.

Conjecture (Polyanskiy--Wu, arXiv:2008.08244, Sec. 5.2): for every probability
measure pi on [-a,a], the convolution (pi*h)(x) = int h(x-y) pi(dy), with the
Gompertz/Gumbel-min density h(x) = exp(x - e^x), has at most O(a) critical points.

We check, independently of the written proof:
  (1) the identity |Gamma(1 - i w)|^2 = pi w / sinh(pi w)  (Fourier transform of h);
  (2) the tail bound T(a) = H(-a/2) + 1 - H(a/2) <= 2 exp(-a/2);
  (3) for pi_a(dy) proportional to (1 + sin(w y)) dy on [-a,a] with
      w = (a - 4 log 2)/pi, we count the local maxima of pi_a*h on a fine grid
      (exact formula via incomplete Gamma functions, 60-digit arithmetic) and
      compare with the proved lower bound floor(w a/(2 pi)) - 1;
  (4) one value of pi_a*h is recomputed by direct numerical quadrature, as an
      independent check of the incomplete-Gamma formula;
  (5) the refined asymmetric window (Remark in section.tex) gives about a^2/pi^2.
Run:  python3 -I R5_gompertz_check.py
"""
import mpmath as mp

mp.mp.dps = 60


def h(s):
    return mp.e ** (s - mp.e ** s)


def check_fourier():
    print("(1) |Gamma(1-iw)|^2 versus pi w/sinh(pi w):")
    for w in [mp.mpf('0.3'), mp.mpf(2), mp.mpf(7.5), mp.mpf(19)]:
        lhs = abs(mp.gamma(1 - 1j * w)) ** 2
        rhs = mp.pi * w / mp.sinh(mp.pi * w)
        # independent check of hhat(w) = int e^{-iws} h(s) ds by quadrature
        quad = mp.quad(lambda s: mp.e ** (-1j * w * s) * h(s), [-60, -10, 0, 5])
        print("   w=%-5s  |Gamma|^2=%s  ratio=%s  |quad-Gamma|=%s" % (
            mp.nstr(w, 4), mp.nstr(lhs, 12), mp.nstr(lhs / rhs, 15),
            mp.nstr(abs(quad - mp.gamma(1 - 1j * w)), 5)))


def H(x):
    return 1 - mp.e ** (-mp.e ** x)


def check_tail():
    print("(2) tail T(a) = H(-a/2)+1-H(a/2) <= 2 exp(-a/2):")
    for a in [1, 4, 8, 16, 40, 100]:
        a = mp.mpf(a)
        T = H(-a / 2) + 1 - H(a / 2)
        print("   a=%-4s T=%s  bound=%s  ok=%s" % (mp.nstr(a, 4), mp.nstr(T, 8),
              mp.nstr(2 * mp.e ** (-a / 2), 8), T <= 2 * mp.e ** (-a / 2)))


def f_window(x, lo, hi, w):
    """int_{lo}^{hi} (1 + sin(w y)) h(x-y) dy, exact via incomplete Gamma."""
    # int_lo^hi h(x-y) dy = H(x-lo) - H(x-hi)
    base = H(x - lo) - H(x - hi)
    # int_lo^hi e^{iwy} h(x-y) dy = e^{iwx} int_{x-hi}^{x-lo} e^{-iws} h(s) ds
    #   = e^{iwx} * gammainc(1-iw, e^{x-hi}, e^{x-lo})
    osc = mp.e ** (1j * w * x) * mp.gammainc(1 - 1j * w, mp.e ** (x - hi), mp.e ** (x - lo))
    return base + mp.im(osc)


def count_local_max(vals):
    c = 0
    for i in range(1, len(vals) - 1):
        if vals[i] > vals[i - 1] and vals[i] > vals[i + 1]:
            c += 1
    return c


def check_counts():
    print("(3) symmetric construction pi_a ~ (1+sin(w y)) on [-a,a], w=(a-4log2)/pi:")
    print("    a    w      grid-count of local maxima in [-a/2,a/2]   proved bound   a^2/(2pi^2)")
    for a in [8, 12, 16, 24, 32, 48]:
        a = mp.mpf(a)
        w = (a - 4 * mp.log(2)) / mp.pi
        # amplitude check |hhat(w)| > 2 T(a)
        amp = abs(mp.gamma(1 - 1j * w))
        T = H(-a / 2) + 1 - H(a / 2)
        period = 2 * mp.pi / w
        npts = int(mp.ceil(a / period * 48))
        xs = [-a / 2 + a * k / npts for k in range(npts + 1)]
        vals = [f_window(x, -a, a, w) for x in xs]
        cnt = count_local_max(vals)
        bound = int(mp.floor(w * a / (2 * mp.pi))) - 1
        print("   %3d  %6.3f   %5d  (|hhat|/2T=%s)                %5d        %7.1f" % (
            int(a), float(w), cnt, mp.nstr(amp / (2 * T), 4), bound,
            float(a * a / (2 * mp.pi ** 2))))
        assert cnt >= bound, "count below proved bound"
        assert amp > 2 * T


def check_quadrature():
    print("(4) incomplete-Gamma formula versus direct quadrature:")
    a = mp.mpf(12)
    w = (a - 4 * mp.log(2)) / mp.pi
    for x in [mp.mpf('-3.1'), mp.mpf('0.7'), mp.mpf('4.2')]:
        exact = f_window(x, -a, a, w)
        pts = [-a] + [-a + k * (2 * a) / 400 for k in range(1, 400)] + [a]
        quad = mp.quad(lambda y: (1 + mp.sin(w * y)) * h(x - y), pts)
        print("   x=%s  formula=%s  quad=%s  diff=%s" % (mp.nstr(x, 3), mp.nstr(exact, 20),
              mp.nstr(quad, 20), mp.nstr(exact - quad, 3)))


def check_asymmetric():
    print("(5) refined window: density 1+sin(w y) on [-a,a], local maxima counted on")
    print("    the whole line; w = 2a/pi - (2/pi)log a (heuristic optimum):")
    for a in [12, 24, 36]:
        a = mp.mpf(a)
        w = 2 * a / mp.pi - (2 / mp.pi) * mp.log(a)
        period = 2 * mp.pi / w
        npts = int(mp.ceil(2 * a / period * 48))
        xs = [-a + 2 * a * k / npts for k in range(npts + 1)]
        vals = [f_window(x, -a, a, w) for x in xs]
        cnt = count_local_max(vals)
        print("   a=%d  w=%.3f  local maxima=%d   a^2/pi^2=%.1f" % (int(a), float(w), cnt,
              float(a * a / mp.pi ** 2)))


if __name__ == "__main__":
    check_fourier()
    check_tail()
    check_quadrature()
    check_counts()
    check_asymmetric()
    print("all assertions passed")
