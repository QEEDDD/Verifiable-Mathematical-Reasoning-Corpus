"""R5 verification script 3: the Jackson constant in Chebyshev moment matching.

Musco--Musco--Rosenblatt--Singh (arXiv:2408.12385v3, COLT 2025) prove
W1(p,q) <= 36/k + Gamma and write "we believe the constants can be improved, at
least to 2 pi/k + Gamma, and possibly further"; the 36 comes from the constant 18 in
Jackson's theorem (Fact 12), for which "strong numerical evidence suggests that this
18 can be improved to pi" (citing Braverman--Krishnan--Musco, Appendix C.2).

Checks (independent of the written proofs):
 (a) Favard damping lambda_k = (k t) cot(k t), t = pi/(2(n+1)): exact sup error over
     1-Lipschitz periodic functions = (1/2pi) int |Theta_n|, compared with pi/(2(n+1));
     monotonicity 1 = lambda_0 > ... > lambda_n > 0.
 (b) BKM Jackson damping (N = 4z, b = (g*g)*(g*g), g = ones(2z+1)): sharp constant
     N * sup_{x0} sup_{f Lip-1} |f - f_N|(x0) = N * max_theta0 E_K|cos th0 - cos(th0 - t)|,
     checked <= pi and compared with the limit 12 log 2/pi.
 (c) Random pairs (p,q): W1 <= pi/(k+1) + Gamma, Gamma^2 = sum_{j<=k} (dm_j)^2/j^2.
 (d) Lower-bound construction: localized Lobatto measures give pairs with equal
     Chebyshev moments up to degree m and W1 close to pi/m.
Run:  python3 -I R5_jackson_check.py
"""
import numpy as np
from fractions import Fraction
import math


# ---------------- (a) Favard factors ----------------
def favard_lambda(n):
    t = math.pi / (2 * (n + 1))
    lam = [1.0] + [(k * t) / math.tan(k * t) for k in range(1, n + 1)]
    return lam


def periodic_lip_constant(lam, M=400000):
    """(1/2pi) int_0^{2pi} |Theta(t)| dt, Theta(t) = (pi - t) - 2 sum_{k<=n} lam_k sin(kt)/k."""
    n = len(lam) - 1
    t = (np.arange(M) + 0.5) * (2 * np.pi / M)
    th = np.pi - t
    for k in range(1, n + 1):
        th -= 2 * lam[k] * np.sin(k * t) / k
    return np.mean(np.abs(th))


def check_favard():
    print("(a) Favard damping: sharp Lipschitz constant versus pi/(2(n+1))")
    for n in [1, 2, 3, 5, 8, 13, 21, 34, 55]:
        lam = favard_lambda(n)
        mono = all(lam[i] > lam[i + 1] for i in range(n)) and lam[n] > 0
        c = periodic_lip_constant(lam)
        print("   n=%3d  constant=%.8f  pi/(2(n+1))=%.8f  ratio=%.6f  decreasing&positive=%s" % (
            n, c, math.pi / (2 * (n + 1)), c / (math.pi / (2 * (n + 1))), mono))
        assert mono and abs(c / (math.pi / (2 * (n + 1))) - 1) < 1e-4


# ---------------- (b) BKM Jackson damping ----------------
def jackson_coeffs(z):
    """Exact normalised Jackson coefficients b_0..b_N, N=4z (BKM: (g*g)*(g*g))."""
    g = [1] * (2 * z + 1)
    gg = np.convolve(g, g)
    c = np.convolve(gg, gg)          # length 8z+1, centre index 4z
    N = 4 * z
    centre = c[N]
    return [Fraction(int(c[N + k]), int(centre)) for k in range(N + 1)], N


def jackson_sharp_constant(z, nt=20001, nth=721):
    b, N = jackson_coeffs(z)
    bf = np.array([float(x) for x in b])
    t = np.linspace(-np.pi, np.pi, nt)
    K = np.ones_like(t)
    for k in range(1, N + 1):
        K += 2 * bf[k] * np.cos(k * t)
    assert K.min() > -1e-9, "Jackson kernel must be nonnegative"
    w = np.full(nt, (t[1] - t[0]) / (2 * np.pi))
    w[0] *= 0.5
    w[-1] *= 0.5
    best = 0.0
    for th0 in np.linspace(0, np.pi, nth):
        val = np.sum(w * np.abs(np.cos(th0) - np.cos(th0 - t)) * K)
        best = max(best, val)
    upper = np.sum(w * 2 * np.abs(np.sin(t / 2)) * K)
    return N * best, N * upper, bf


def check_jackson():
    print("(b) BKM Jackson damping: N * sharp constant (should be <= pi = %.5f; limit 12 log2/pi = %.5f)" % (
        math.pi, 12 * math.log(2) / math.pi))
    for z in [1, 2, 3, 4, 6, 8, 12, 16, 24, 32, 48]:
        c, u, bf = jackson_sharp_constant(z)
        dec = all(bf[i] > bf[i + 1] for i in range(len(bf) - 1)) and bf[-1] >= 0
        print("   z=%3d N=%4d  sharp=%.5f  (2|sin(t/2)| bound: %.5f)  coefficients decreasing=%s" % (
            z, 4 * z, c, u, dec))
        assert c <= math.pi and u <= math.pi


# ---------------- (c) random pairs ----------------
def w1_discrete(xp, wp, xq, wq):
    xs = np.concatenate([xp, xq])
    order = np.argsort(xs)
    xs = xs[order]
    mass = np.concatenate([wp, -wq])[order]
    F = np.cumsum(mass)[:-1]
    return np.sum(np.abs(F) * np.diff(xs))


def cheb_moments(x, w, k):
    th = np.arccos(np.clip(x, -1, 1))
    return np.array([np.sum(w * np.cos(j * th)) for j in range(1, k + 1)])


def check_random(seed=1):
    rng = np.random.default_rng(seed)
    print("(c) random pairs: max over trials of W1 - (pi/(k+1) + Gamma)  (must be <= 0)")
    worst = -1e9
    for trial in range(3000):
        k = int(rng.integers(1, 40))
        n1, n2 = int(rng.integers(1, 30)), int(rng.integers(1, 30))
        # mix of clustered and spread atoms
        xp = np.clip(rng.normal(rng.uniform(-1, 1), rng.uniform(0.01, 1), n1), -1, 1)
        xq = np.clip(rng.normal(rng.uniform(-1, 1), rng.uniform(0.01, 1), n2), -1, 1)
        wp = rng.dirichlet(np.ones(n1))
        wq = rng.dirichlet(np.ones(n2))
        W = w1_discrete(xp, wp, xq, wq)
        dm = cheb_moments(xp, wp, k) - cheb_moments(xq, wq, k)
        G = math.sqrt(np.sum(dm ** 2 / np.arange(1, k + 1) ** 2))
        worst = max(worst, W - (math.pi / (k + 1) + G))
    print("   worst slack = %.4f" % worst)
    assert worst <= 1e-12


# ---------------- (d) near-extremal moment-matching pairs ----------------
def lobatto_pair(Nn, D):
    """Signed measure mu = sum_j w_j (-1)^j rho(x_j) delta_{x_j}, x_j = cos(j pi/N),
    rho(x) = (1-x^2)^D; mu annihilates polynomials of degree <= N-1-2D."""
    j = np.arange(Nn + 1)
    th = j * np.pi / Nn
    x = np.cos(th)
    wl = np.full(Nn + 1, 1.0 / Nn)
    wl[0] *= 0.5
    wl[-1] *= 0.5
    rho = np.sin(th) ** (2 * D)
    c = wl * rho
    sgn = (-1.0) ** j
    pos = sgn > 0
    p_w, q_w = c[pos], c[~pos]
    tot = 0.5 * (p_w.sum() + q_w.sum())
    return x[pos], p_w / p_w.sum(), x[~pos], q_w / q_w.sum(), Nn - 1 - 2 * D, c, sgn


def check_lower():
    print("(d) localized Lobatto pairs: equal Chebyshev moments up to degree m, W1 * m / pi -> 1")
    for Nn in [50, 200, 800, 3200]:
        D = int(round(math.sqrt(Nn)))
        xp, wp, xq, wq, mdeg, c, sgn = lobatto_pair(Nn, D)
        # moment check (positive and negative parts have equal mass for D>=1 ... normalise both)
        dm = cheb_moments(xp, wp, mdeg) - cheb_moments(xq, wq, mdeg)
        W = w1_discrete(xp, wp, xq, wq)
        print("   N=%5d D=%3d  m=%5d  max|moment diff|=%.2e  W1=%.6f  W1*m/pi=%.4f  pi/(m+1)=%.6f" % (
            Nn, D, mdeg, np.max(np.abs(dm)), W, W * mdeg / math.pi, math.pi / (mdeg + 1)))
        assert np.max(np.abs(dm)) < 1e-9


if __name__ == "__main__":
    check_favard()
    check_jackson()
    check_random()
    check_lower()
    print("all assertions passed")
