"""R5 verification script 2: modes of mixtures of two analytic strongly log-concave densities.

Question (Polyanskiy--Wu, arXiv:2008.08244, Sec. 5.5): a convex combination of k
analytic, strongly log-concave densities can have Omega(k^2) modes; is this tight?

Construction checked here (k = 2):
   f_{+-}(x) = c * exp( -(x -+ 1)^2/2 + (eps/w^2) cos(w x) ),
   m(x) = (f_+(x) + f_-(x))/2 .
Each f_{+-} is entire and (log f)'' = -1 - eps cos(w x) lies in [-1-eps, -1+eps].
We verify:
  (1) the normalising constants of f_+ and f_- coincide (so m is an equal-weight mixture);
  (2) (log f)'' stays in [-1-eps,-1+eps] on a dense grid (finite differences);
  (3) the number of strict local maxima of m, counted on a fine grid in high precision,
      against the proved lower bound  floor(w X/pi) - 1  (two sides), X = (3 eps/(2w))^(1/3);
  (4) growth of the number of modes like w^(2/3).
Run:  python3 -I R5_modes_check.py
"""
import mpmath as mp

mp.mp.dps = 50


def logf(x, s, eps, w):
    return -(x - s) ** 2 / 2 + (eps / w ** 2) * mp.cos(w * x)


def normaliser(s, eps, w):
    return mp.quad(lambda x: mp.e ** logf(x, s, eps, w),
                   mp.linspace(-14 + s, 14 + s, 400))


def m(x, eps, w):
    # common factor removed: m(x) ~ exp((eps/w^2)cos(wx)) * (phi(x-1)+phi(x+1))
    return mp.e ** ((eps / w ** 2) * mp.cos(w * x)) * (mp.e ** (-(x - 1) ** 2 / 2) + mp.e ** (-(x + 1) ** 2 / 2))


def count_strict_max(vals):
    return sum(1 for i in range(1, len(vals) - 1) if vals[i] > vals[i - 1] and vals[i] > vals[i + 1])


def main():
    eps = mp.mpf('0.5')
    print("(1) equal normalisers of f_+ and f_- (eps=0.5, w=40):")
    Zp, Zm = normaliser(1, eps, 40), normaliser(-1, eps, 40)
    print("    Z_+ = %s   Z_- = %s   diff = %s" % (mp.nstr(Zp, 25), mp.nstr(Zm, 25), mp.nstr(Zp - Zm, 3)))
    assert abs(Zp - Zm) < mp.mpf(10) ** (-35)

    print("(2) second derivative of log f_+ on a grid (eps=0.5, w=40):")
    w = mp.mpf(40)
    hstep = mp.mpf(10) ** (-12)
    lo, hi = mp.mpf(10), mp.mpf(-10)
    for k in range(4001):
        x = -5 + 10 * mp.mpf(k) / 4000
        d2 = (logf(x + hstep, 1, eps, w) - 2 * logf(x, 1, eps, w) + logf(x - hstep, 1, eps, w)) / hstep ** 2
        lo, hi = min(lo, d2), max(hi, d2)
    print("    min (log f)'' = %s,  max (log f)'' = %s   (should lie in [-1.5,-0.5])" % (mp.nstr(lo, 8), mp.nstr(hi, 8)))
    assert lo >= -1.5 - mp.mpf('1e-6') and hi <= -0.5 + mp.mpf('1e-6')

    print("(3)-(4) number of strict local maxima of m on the window |x| <= 1.5 X:")
    print("       w        X        grid count   proved lower bound (maxima)   w^(2/3)")
    for wv in [100, 1000, 10000, 100000]:
        w = mp.mpf(wv)
        X = (3 * eps / (2 * w)) ** (mp.mpf(1) / 3)
        period = 2 * mp.pi / w
        L = mp.mpf('1.5') * X
        npts = int(mp.ceil(2 * L / period * 40))
        xs = [-L + 2 * L * k / npts for k in range(npts + 1)]
        vals = [m(x, eps, w) for x in xs]
        cnt = count_strict_max(vals)
        # points x_j = (pi/2 + j pi)/w, j >= 0, lying in (0, X]
        nj = int(mp.floor((w * X - mp.pi / 2) / mp.pi)) + 1 if w * X >= mp.pi / 2 else 0
        # sign of (log m)' at x_j is -(-1)^j; a + to - change between x_{2i+1}, x_{2i+2}
        bound = max(0, (nj - 1) // 2)     # local maxima in (0,X]; doubled by symmetry
        print("   %7d  %.5f   %8d        >= %d per side (%d total)            %.1f" % (
            wv, float(X), cnt, bound, 2 * bound, float(w ** (mp.mpf(2) / 3))))
        assert cnt >= 2 * bound
    print("all assertions passed")


if __name__ == "__main__":
    main()
