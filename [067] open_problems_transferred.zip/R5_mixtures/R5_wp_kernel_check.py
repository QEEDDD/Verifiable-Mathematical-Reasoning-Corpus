"""R5 verification script 4: deterministic ingredients of the proof of Theorem R5:thm:wp.

Checks, independently of the written proof:
 (1) Lemma R5:lem:kernel(i): for the Jackson kernel J_{n,rho} on [-1,1],
       P(|U|>v) <= (pi/2)^{2 rho} (n v)^{1-2 rho}   (0<v<=1),
       E|U|^q   <= (1 + q (pi/2)^{2 rho}/(2 rho-1-q)) n^{-q}   (1<=q<2 rho-1);
 (2) Lemma R5:lem:kernel(ii): S^* f = (f o fold) * J is a trigonometric polynomial
     of degree Lambda = rho (n-1) in pi*y, with coefficients |c_l| <= sup|f|,
     and S^* f is 1-Lipschitz when f is (random piecewise-linear f);
 (3) Lemma R5:lem:kernel(iii): Taylor conversion errors of random trigonometric
     polynomials obey the stated bounds;
 (4) the deterministic chain behind (R5:eq:wpchain):
       W_p(mu,nu) <= 2 (E|U|^p)^{1/p} + W_1(S mu, S nu)^{1/p}
     for random discrete mu, nu on [0,1].
Run:  python3 -I R5_wp_kernel_check.py
"""
import math
import numpy as np

rng = np.random.default_rng(11)


def jackson_density(n, rho, M=400001):
    u = np.linspace(-1, 1, M)
    with np.errstate(invalid='ignore', divide='ignore'):
        r = np.sin(n * np.pi * u / 2) / np.sin(np.pi * u / 2)
    r[np.abs(u) < 1e-14] = n
    w = r ** (2 * rho)
    du = u[1] - u[0]
    w /= np.sum(w) * du
    return u, w, du


def check_tails():
    worst_tail, worst_mom = -1.0, -1.0
    for n in [2, 3, 5, 10, 25, 60]:
        for rho in [2, 3, 4]:
            u, w, du = jackson_density(n, rho)
            for v in [0.01, 0.05, 0.1, 0.3, 0.7]:
                tail = np.sum(w[np.abs(u) > v]) * du
                bound = (np.pi / 2) ** (2 * rho) * (n * v) ** (1 - 2 * rho)
                worst_tail = max(worst_tail, tail / bound)
            for q in [1, 1.5, 2, 3]:
                if q < 2 * rho - 1:
                    mom = np.sum(np.abs(u) ** q * w) * du
                    bound = (1 + q * (np.pi / 2) ** (2 * rho) / (2 * rho - 1 - q)) * n ** (-q)
                    worst_mom = max(worst_mom, mom / bound)
    print("(1) max tail/bound = %.3f, max moment/bound = %.3f (both must be <= 1)" % (worst_tail, worst_mom))
    assert worst_tail <= 1 and worst_mom <= 1


def fold(z):
    z = np.mod(z, 2.0)
    return np.where(z > 1, 2 - z, z)


def check_adjoint():
    worst_coef, worst_lip, worst_tailcoef = 0.0, 0.0, 0.0
    M = 4096                      # periodic grid x_k = 2k/M on [0,2); kernel indexed by u_k = x_k wrapped to [-1,1)
    xg = 2 * np.arange(M) / M
    y = np.where(xg >= 1, xg - 2, xg)    # kernel abscissae (index 0 <-> u = 0)
    for trial in range(30):
        n, rho = int(rng.integers(2, 12)), int(rng.integers(2, 4))
        Lam = rho * (n - 1)
        # random 1-Lipschitz piecewise-linear f on [0,1] with f(0)=0
        knots = np.sort(np.concatenate([[0, 1], rng.random(8)]))
        slopes = rng.uniform(-1, 1, len(knots) - 1)
        vals = np.concatenate([[0], np.cumsum(slopes * np.diff(knots))])
        f = lambda x: np.interp(x, knots, vals)
        ftilde = f(fold(xg))
        # kernel sampled on the same periodic grid
        with np.errstate(invalid='ignore', divide='ignore'):
            r = np.sin(n * np.pi * y / 2) / np.sin(np.pi * y / 2)
        r[np.abs(y) < 1e-14] = n
        J = r ** (2 * rho)
        J /= J.sum() * (2.0 / M)
        # S^* f(y) = int ftilde(y+u) J(u) du  (circular convolution; J even)
        Sf = np.real(np.fft.ifft(np.fft.fft(ftilde) * np.conj(np.fft.fft(J)))) * (2.0 / M)
        c = np.fft.fft(Sf) / M      # coefficients of e^{i pi l y} (up to phase)
        l = np.fft.fftfreq(M, d=1.0 / M)
        tailc = np.max(np.abs(c[np.abs(l) > Lam]))
        worst_tailcoef = max(worst_tailcoef, tailc)
        worst_coef = max(worst_coef, np.max(np.abs(c)) / np.max(np.abs(vals)))
        # Lipschitz constant of S^* f restricted to [0,1] (grid points x_k <= 1)
        mask = (xg <= 1)
        lip = np.max(np.abs(np.diff(Sf[mask])) / (2.0 / M))
        worst_lip = max(worst_lip, lip)
    print("(2) max |c_l| beyond degree Lambda = %.2e; max |c_l|/sup|f| = %.3f; max Lipschitz const = %.4f" % (
        worst_tailcoef, worst_coef, worst_lip))
    assert worst_tailcoef < 1e-10 and worst_coef <= 1 + 1e-9 and worst_lip <= 1 + 1e-6


def check_taylor():
    """High-precision check (the bounds are far below double precision)."""
    import mpmath as mp
    mp.mp.dps = 150
    worst0, worst1 = mp.mpf(0), mp.mpf(0)
    ys = [mp.mpf(k) / 200 for k in range(201)]
    for trial in range(25):
        Lam = int(rng.integers(1, 9))
        D = 9 * Lam + 1 + int(rng.integers(0, 6))
        c = [mp.mpc(float(rng.normal()), float(rng.normal())) for _ in range(2 * Lam + 1)]
        cmax = max(abs(x) for x in c)
        e0max, e1max = mp.mpf(0), mp.mpf(0)
        for y in ys:
            g = gp = T = Tp = mp.mpc(0)
            for idx, l in enumerate(range(-Lam, Lam + 1)):
                z = 1j * mp.pi * l
                g += c[idx] * mp.e ** (z * y)
                gp += c[idx] * z * mp.e ** (z * y)
                base = c[idx] * mp.e ** (z / 2)
                h = y - mp.mpf(1) / 2
                s0 = sum((z * h) ** d / mp.factorial(d) for d in range(D + 1))
                s1 = sum(z * (z * h) ** (d - 1) / mp.factorial(d - 1) for d in range(1, D + 1))
                T += base * s0
                Tp += base * s1
            e0max = max(e0max, abs(g - T))
            e1max = max(e1max, abs(gp - Tp))
        worst0 = max(worst0, e0max / ((2 * Lam + 1) * cmax * mp.mpf(2) ** (-D - 1)))
        worst1 = max(worst1, e1max / ((2 * Lam + 1) * mp.pi * Lam * cmax * mp.mpf(2) ** (-D)))
    print("(3) Taylor conversion (150 digits): max error/bound = %s (values), %s (derivatives); must be <= 1" % (
        mp.nstr(worst0, 4), mp.nstr(worst1, 4)))
    assert worst0 <= 1 and worst1 <= 1


def w_p_discrete(xp, wp, xq, wq, p, ugrid=100000):
    u = (np.arange(ugrid) + 0.5) / ugrid
    def Q(xs, ws):
        o = np.argsort(xs)
        c = np.cumsum(ws[o])
        return xs[o][np.minimum(np.searchsorted(c, u), len(xs) - 1)]
    return np.mean(np.abs(Q(xp, wp) - Q(xq, wq)) ** p) ** (1.0 / p)


def check_chain():
    worst = -1.0
    for trial in range(200):
        p = float(rng.choice([1.5, 2, 3, 4]))
        n1, n2 = int(rng.integers(1, 15)), int(rng.integers(1, 15))
        xp, xq = rng.random(n1), rng.random(n2)
        wp, wq = rng.dirichlet(np.ones(n1)), rng.dirichlet(np.ones(n2))
        width = rng.uniform(0.01, 0.4)
        # smoothing by U ~ uniform[-width, width], discretised with 201 atoms
        U = np.linspace(-width, width, 201)
        wu = np.full(201, 1 / 201)
        Sx_p = fold(xp[:, None] + U[None, :]).ravel()
        Sw_p = (wp[:, None] * wu[None, :]).ravel()
        Sx_q = fold(xq[:, None] + U[None, :]).ravel()
        Sw_q = (wq[:, None] * wu[None, :]).ravel()
        lhs = w_p_discrete(xp, wp, xq, wq, p)
        W1s = w_p_discrete(Sx_p, Sw_p, Sx_q, Sw_q, 1)
        rhs = 2 * np.mean(np.abs(U) ** p) ** (1 / p) + W1s ** (1 / p)
        worst = max(worst, lhs - rhs)
    print("(4) chain W_p <= 2(E|U|^p)^(1/p) + W_1(S mu,S nu)^(1/p): max violation = %.3e (must be <= ~1e-4)" % worst)
    assert worst <= 1e-4


if __name__ == "__main__":
    check_tails()
    check_adjoint()
    check_taylor()
    check_chain()
    print("all assertions passed")
