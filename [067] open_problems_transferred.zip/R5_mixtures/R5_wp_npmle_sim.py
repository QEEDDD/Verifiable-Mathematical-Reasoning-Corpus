"""R5 verification script 5: Monte Carlo check of the W_p rate of the binomial NPMLE.

Theorem (section.tex, Thm R5:wp): for fixed p in [1,inf), every NPMLE satisfies
  sup_G E W_p(Ghat, G)  ~  min{1, 1/t + 1/sqrt(t log N) + N^{-1/(2p)}} .
The new term relative to p = 1 is N^{-1/(2p)}.  We simulate:
  (A) G = (delta_{0.2}+delta_{0.8})/2, t = 4000 (so the N^{-1/(2p)} term dominates):
      E W_1 should scale like N^{-1/2}, E W_2 like N^{-1/4}, E W_3 like N^{-1/6};
  (B) G = Uniform[0,1], N = 20000, t varying: E W_p should track 1/sqrt(t log N).
The NPMLE is computed on a grid of 2001 points by EM (KKT gap reported).
Run:  python3 -I R5_wp_npmle_sim.py
"""
import numpy as np
from scipy.stats import binom

rng = np.random.default_rng(2026)
GRID = np.linspace(0, 1, 2001)


def npmle(counts_vals, counts_mult, t, iters=1500):
    logA = binom.logpmf(counts_vals[:, None], t, GRID[None, :])
    A = np.exp(logA - logA.max(axis=1, keepdims=True))
    scale = logA.max(axis=1)
    # start from the (slightly smoothed) empirical law of X/t: much closer to the optimum
    w = np.full(len(GRID), 1e-3 / len(GRID))
    np.add.at(w, np.round(counts_vals / t * (len(GRID) - 1)).astype(int), counts_mult)
    w /= w.sum()
    n = counts_mult.sum()
    for _ in range(iters):
        f = A @ w
        g = A.T @ (counts_mult / f) / n
        w = w * g
        w /= w.sum()
    f = A @ w
    D = A.T @ (counts_mult / f) / n
    return w, D.max() - 1.0


def wp_discrete_vs(G_quantile, w, p, ugrid=20000):
    u = (np.arange(ugrid) + 0.5) / ugrid
    c = np.cumsum(w)
    idx = np.minimum(np.searchsorted(c, u), len(GRID) - 1)
    qhat = GRID[idx]
    return np.mean(np.abs(qhat - G_quantile(u)) ** p) ** (1.0 / p)


def simulate(G_sampler, G_quantile, N, t, reps, ps):
    out = {p: [] for p in ps}
    gaps = []
    for _ in range(reps):
        th = G_sampler(N)
        X = rng.binomial(t, th)
        vals, mult = np.unique(X, return_counts=True)
        w, gap = npmle(vals, mult.astype(float), t)
        gaps.append(gap)
        for p in ps:
            out[p].append(wp_discrete_vs(G_quantile, w, p))
    return {p: np.mean(out[p]) for p in ps}, max(gaps)


def two_point_sampler(N):
    return np.where(rng.random(N) < 0.5, 0.2, 0.8)


def two_point_quantile(u):
    return np.where(u <= 0.5, 0.2, 0.8)


def main():
    ps = [1, 2, 3]
    print("(A) two-point G, t=4000: E W_p and E W_p * N^{1/(2p)} (should be roughly constant)")
    print("     N     W1      W2      W3     W1*N^.5  W2*N^.25  W3*N^(1/6)  KKT gap")
    resA = []
    for N in [100, 400, 1600, 6400]:
        r, gap = simulate(two_point_sampler, two_point_quantile, N, 4000, 8, ps)
        resA.append((N, r))
        print("  %5d  %.4f  %.4f  %.4f   %.3f    %.3f     %.3f     %.1e" % (
            N, r[1], r[2], r[3], r[1] * N ** 0.5, r[2] * N ** 0.25, r[3] * N ** (1 / 6), gap), flush=True)
    # fitted log-log slopes
    Ns = np.log([x[0] for x in resA])
    for p in ps:
        ys = np.log([x[1][p] for x in resA])
        slope = np.polyfit(Ns, ys, 1)[0]
        print("   fitted slope for p=%d: %.3f   (theory -1/(2p) = %.3f)" % (p, slope, -1 / (2 * p)))

    print("(B) uniform G, N=20000: E W_p * sqrt(t log N) (should stay bounded as t grows)")
    print("     t     W1      W2      W3    W1*sqrt(tL)  W2*sqrt(tL)  W3*sqrt(tL)  KKT gap")
    N = 20000
    L = np.log(np.e * N)
    for t in [10, 40, 160, 640]:
        r, gap = simulate(lambda n: rng.random(n), lambda u: u, N, t, 6, ps)
        s = np.sqrt(t * L)
        print("  %5d  %.4f  %.4f  %.4f    %.3f       %.3f       %.3f     %.1e" % (
            t, r[1], r[2], r[3], r[1] * s, r[2] * s, r[3] * s, gap), flush=True)


if __name__ == "__main__":
    main()
