# exact check of closed forms g_k(theta) for the clean pair families, using sympy algebraic arithmetic
import sympy as sp
I = sp.I
w = sp.Rational(-1,2) + sp.sqrt(3)*I/2          # omega
z6 = sp.Rational(1,2) + sp.sqrt(3)*I/2          # primitive 6th root e^{i pi/3}
def g(k, t):
    return sp.nsimplify(sp.expand(t**(k+1) - 2*t**k + 1))
def theta(zeta, k):
    return sp.simplify(2*(zeta**k - 1)/(zeta**(k+1) - 1))
bad = []
for k in range(3, 80):
    # F4a: k = 1 mod 4: theta = 1 - i; g = 1 - (-1)^((k-1)/4) 2^((k+1)/2)
    if k % 4 == 1:
        t = 1 - I
        assert sp.simplify(theta(I, k) - t) == 0
        val = sp.expand(t**(k+1) - 2*t**k + 1)
        if sp.simplify(val - (1 - (-1)**((k-1)//4) * 2**((k+1)//2))) != 0: bad.append(('F4a', k))
        val2 = sp.expand((I*t)**(k+1) - 2*(I*t)**k + 1)
        if sp.simplify(val2 - val) != 0: bad.append(('F4a-partner', k))
    # F4b: k = 2 mod 4: theta = 2(1-i); g = 1 + (-1)^((k+2)/4) 2^((3k+2)/2)
    if k % 4 == 2:
        t = 2*(1 - I)
        assert sp.simplify(theta(I, k) - t) == 0
        val = sp.expand(t**(k+1) - 2*t**k + 1)
        if sp.simplify(val - (1 + (-1)**((k+2)//4) * 2**((3*k+2)//2))) != 0: bad.append(('F4b', k))
    # F3: k = 1 mod 3: theta = -2 omega; g = 1 - (-2)^(k+1)
    if k % 3 == 1:
        t = -2*w
        assert sp.simplify(theta(w, k) - t) == 0
        val = sp.expand(t**(k+1) - 2*t**k + 1)
        if sp.simplify(val - (1 - (-2)**(k+1))) != 0: bad.append(('F3', k))
    # F6, s = k mod 6 in {1,2,3,4}
    s = k % 6
    if s in (1, 2, 3, 4):
        t = theta(z6, k)
        val = sp.simplify(sp.expand(t**(k+1) - 2*t**k + 1))
        if s == 1:
            e = (k+1)//2; m = (k+1-2)//6
            target = None  # g(theta) = (stuff) ; compare norms below
        print(k, s, sp.nsimplify(sp.simplify(t)), sp.factor(sp.simplify(val*sp.conjugate(val))) if k < 30 else '')
print("closed-form mismatches:", bad)
