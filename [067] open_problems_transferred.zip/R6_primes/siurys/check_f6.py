# exact arithmetic in Z[omega]: (a,b) = a + b*omega, omega^2 = -1 - omega
def mul(x, y):
    a, b = x; c, d = y
    # (a + b w)(c + d w) = ac + (ad+bc) w + bd w^2 = (ac - bd) + (ad + bc - bd) w
    return (a*c - b*d, a*d + b*c - b*d)
def pw(x, n):
    r = (1, 0)
    while n:
        if n & 1: r = mul(r, x)
        x = mul(x, x); n >>= 1
    return r
def add(x, y): return (x[0]+y[0], x[1]+y[1])
bad = []
for k in range(8, 400, 6):          # k = 2 mod 6
    t = (1, -1)                      # 1 - omega
    val = add(add(pw(t, k+1), mul((-2, 0), pw(t, k))), (1, 0))
    target = ((-3)**(k//2) + 1, 0)
    if val != target: bad.append(k)
    # partner zeta*theta with zeta = -omega^2 = 1 + omega
    z = (1, 1)
    t2 = mul(z, t)
    val2 = add(add(pw(t2, k+1), mul((-2, 0), pw(t2, k))), (1, 0))
    if val2 != val: bad.append(('partner', k))
print("F6 (s=2) closed form g(1-omega) = (-3)^(k/2)+1 mismatches:", bad)
# F3 partner check and F3 closed form for many k
bad3 = []
for k in range(4, 400, 3):
    t = (0, -2)  # -2 omega
    val = add(add(pw(t, k+1), mul((-2, 0), pw(t, k))), (1, 0))
    if val != (1 - (-2)**(k+1), 0): bad3.append(k)
    t2 = mul((0, 1), t)  # omega * theta
    val2 = add(add(pw(t2, k+1), mul((-2, 0), pw(t2, k))), (1, 0))
    if val2 != val: bad3.append(('partner', k))
print("F3 closed form g(-2 omega) = 1-(-2)^(k+1) mismatches:", bad3)
