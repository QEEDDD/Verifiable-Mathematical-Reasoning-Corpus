default(parisizemax, 4*10^9);
pairnorm(k,d) = { my(P=polcyclo(d), Z=Mod(x,P), s=k%d, H); if(s==0 || (k+1)%d==0, return(0));
  H = 2^(k+1)*(Z^s-1)^k*Z^s*(1-Z) + (Z^(s+1)-1)^(k+1); abs(polresultant(P, lift(H))); }
k=60; FB=10^7;
{
foreach([122,183,244,305,366,427,488,549,610], d, my(t0=getabstime(), N=pairnorm(k,d));
  if(N!=0, my(F=factor(N, FB)); for(i=1,#F[,1], my(p=F[i,1]); if(p>2 && d%p!=0 && p<10^15 && isprime(p), print("P ",k," ",d," ",p))));
  print1("# d=",d," done in ",(getabstime()-t0)\1000,"s\n"));
}
quit
