default(parisizemax, 4*10^9);
pairnorm(k,d) = { my(P=polcyclo(d), Z=Mod(x,P), s=k%d, H); if(s==0 || (k+1)%d==0, return(0));
  H = 2^(k+1)*(Z^s-1)^k*Z^s*(1-Z) + (Z^(s+1)-1)^(k+1); abs(polresultant(P, lift(H))); }
FB=10^7;
{
foreach(KS, k, my(q=k+1);
  for(m=2,12, my(d=q*m, N=pairnorm(k,d));
    if(N!=0, my(F=factor(N, FB)); for(i=1,#F[,1], my(p=F[i,1]); if(p>2 && d%p!=0 && p<10^15 && isprime(p), print("P ",k," ",d," ",p))))));
}
quit
