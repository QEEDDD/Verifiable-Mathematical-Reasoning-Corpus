"""numpy-accelerated certificates for the k-step recurrence mod p (p < 2^31)."""
import numpy as np

def functional_rows_np(k, p, c, d, count):
    r = np.zeros(k, dtype=np.int64); r[0] = 1
    N = 0
    rows = np.zeros((count, k), dtype=np.int64)
    for j in range(count):
        target = c + d * j
        while N < target:
            last = r[-1]
            nr = np.empty_like(r)
            nr[0] = last
            nr[1:] = (r[:-1] + last) % p
            r = nr
            N += 1
        rows[j] = r
    return rows

def kernel_vector_np(M, p):
    """nonzero x with M x = 0 mod p (M: m x k int64), or None."""
    A = M.copy() % p
    m, k = A.shape
    where = -np.ones(k, dtype=np.int64)
    rank = 0
    for col in range(k):
        if rank == m:
            break
        nz = np.nonzero(A[rank:, col])[0]
        if len(nz) == 0:
            continue
        piv = rank + nz[0]
        if piv != rank:
            A[[rank, piv]] = A[[piv, rank]]
        inv = pow(int(A[rank, col]), p - 2, p)
        A[rank] = (A[rank] * inv) % p
        f = A[:, col].copy(); f[rank] = 0
        nzr = np.nonzero(f)[0]
        if len(nzr):
            A[nzr] = (A[nzr] - (f[nzr, None] * A[rank][None, :]) % p) % p
        where[col] = rank
        rank += 1
    free = [c for c in range(k) if where[c] == -1]
    if not free:
        return None
    fc = free[0]
    x = np.zeros(k, dtype=np.int64); x[fc] = 1
    for col in range(k):
        if where[col] != -1:
            x[col] = (-A[where[col], fc]) % p
    return [int(v) for v in x]

def ap_pattern_np(k, p, d, c):
    if p >= 2**31:
        from siurys_search import ap_pattern
        return ap_pattern(k, p, d, c)
    rows = functional_rows_np(k, p, c, d, k)
    x = kernel_vector_np(rows, p)
    if x is None:
        return None
    xv = np.array(x, dtype=np.int64)
    assert np.all((rows @ xv) % p == 0) if p < 2**25 else all(sum(int(a)*int(b) for a,b in zip(row, x)) % p == 0 for row in rows)
    return x
