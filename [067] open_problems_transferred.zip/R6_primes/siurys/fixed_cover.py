#!/usr/bin/env python3
"""
Fixed (k-independent) coverings for all k in a residue class r mod D.

A d-periodic sequence y over F_p with zero period sum that satisfies y_n = y_{n-1}+...+y_{n-s}
(cyclically) satisfies the k-step recurrence for EVERY k == s (mod d):
   sum_{i=1}^k y_{n-i} = ((k-s)/d) * (period sum) + sum_{i=1}^s y_{n-i} = y_n.
Such y exist iff some d-th roots of unity zeta != 1 are roots of g_s(X) = X^{s+1}-2X^s+1 mod p;
their span has dimension r, and y can be made to vanish on r-1 chosen classes mod d.
Mod 2: if l | (r+1) and l | D then every l-periodic 0/1 pattern with an even number of ones
per period is a solution for all k == r (mod D) (since then l | k+1).
Usage: python3 -I fixed_cover.py D r1 r2 ...   (or D all) ; options via env.
"""
import sys, os, json, time
from math import gcd
from functools import reduce
import numpy as np
from scipy.optimize import milp, LinearConstraint, Bounds
from scipy.sparse import lil_matrix, csr_matrix
import sympy as sp

def lcm(a, b): return a // gcd(a, b) * b

def periodic_space(p, d, s):
    """basis (mod p) of d-periodic sequences (vectors of length d) with
    y_n = sum_{i=1}^s y_{n-i} (indices mod d) and sum y = 0."""
    rows = []
    for n in range(d):
        row = [0] * d
        row[n] = (row[n] + 1) % p
        for i in range(1, s + 1):
            row[(n - i) % d] = (row[(n - i) % d] - 1) % p
        rows.append(row)
    rows.append([1] * d)
    M = sp.Matrix(rows)
    # nullspace mod p via sympy GF arithmetic
    from sympy.polys.matrices import DomainMatrix
    from sympy import GF
    dm = DomainMatrix.from_Matrix(M).convert_to(GF(p))
    ns = dm.nullspace().to_Matrix()
    basis = [[int(ns[i, j]) % p for j in range(ns.shape[1])] for i in range(ns.shape[0])]
    return basis

def candidate_primes(d, s, B):
    """primes p <= B (p not dividing d) such that a d-th root of unity != 1 is a root of g_s mod p:
    p divides Res(Phi_delta, g_s) for some delta | d, delta > 1."""
    X = sp.symbols('X')
    gs = X**(s + 1) - 2 * X**s + 1
    cands = set()
    for de in sp.divisors(d):
        if de == 1: continue
        R = abs(sp.resultant(sp.cyclotomic_poly(de, X), gs, X))
        if R == 0: continue
        f = sp.factorint(R, limit=B)
        for q in f:
            if sp.isprime(q) and q > 2 and d % q != 0 and q <= 10**12:
                cands.add(int(q))
    return sorted(cands)

def ap_possible(p, d, basis, e):
    """is there a nonzero y in span(basis) (d-periodic) vanishing on all n == 0 (mod e)?"""
    from sympy.polys.matrices import DomainMatrix
    from sympy import GF
    rows = [[b[n] for b in basis] for n in range(0, d, e)]
    M = sp.Matrix(rows)
    ns = DomainMatrix.from_Matrix(M).convert_to(GF(p)).nullspace().to_Matrix()
    return ns.shape[0] > 0

def build_options(D, r, B=10**6, dmax=None):
    opts = []  # (prime, modulus, capacity, s, kind, d_period)
    seen = set()
    for d in sp.divisors(D):
        if d < 3: continue
        if dmax and d > dmax: continue
        s = r % d
        if s in (0, 1, d - 1): continue
        for p in candidate_primes(d, s, B):
            basis = periodic_space(p, d, s)
            if len(basis) >= 2:
                opts.append((p, d, len(basis) - 1, s, 'R', d))
            if len(basis) >= 1:
                for e in sp.divisors(d):
                    if e < 2 or e == d: continue
                    if (p, e) in seen: continue
                    if ap_possible(p, d, basis, e):
                        seen.add((p, e))
                        opts.append((p, e, 1, s, 'A', d))
    return opts

def solve(D, r, opts, time_limit=120):
    """MILP: choose for each prime at most one option and <= capacity classes; optional mod-2 pattern
    with period l = gcd(r+1, D) (if l >= 3) leaving 2 classes mod l uncovered."""
    l = gcd(r + 1, D)
    use2 = l >= 3
    mods = [o[1] for o in opts] + ([l] if use2 else [])
    if not mods: return None
    L = reduce(lcm, mods, 1)
    zvars = [(oi, c) for oi, o in enumerate(opts) for c in range(o[1])]
    nz, nu = len(zvars), len(opts)
    nb = l if use2 else 0   # binary: class t mod l left odd (exactly 2 chosen)
    nv = nz + nu + nb
    primes = sorted(set(o[0] for o in opts))
    nrows = L + nu + len(primes) + (1 if use2 else 0)
    A = lil_matrix((nrows, nv)); lb = np.zeros(nrows); ub = np.zeros(nrows)
    byd = {}
    for vi, (oi, c) in enumerate(zvars):
        byd.setdefault(opts[oi][1], {}).setdefault(c, []).append(vi)
    for n in range(L):
        for d, cl in byd.items():
            for vi in cl.get(n % d, []):
                A[n, vi] = 1
        if use2:
            A[n, nz + nu + (n % l)] = -1     # need odd coverage iff class n mod l is an 'odd' class
            lb[n], ub[n] = 0, np.inf
        else:
            lb[n], ub[n] = 1, np.inf
    for vi, (oi, c) in enumerate(zvars):
        A[L + oi, vi] = 1
    for oi, o in enumerate(opts):
        A[L + oi, nz + oi] = -o[2]; lb[L + oi], ub[L + oi] = -np.inf, 0
    for j, p in enumerate(primes):
        for oi, o in enumerate(opts):
            if o[0] == p: A[L + nu + j, nz + oi] = 1
        lb[L + nu + j], ub[L + nu + j] = 0, 1
    if use2:
        row = L + nu + len(primes)
        for t in range(l): A[row, nz + nu + t] = 1
        lb[row], ub[row] = 2, 2
    cost = np.zeros(nv); cost[nz:nz + nu] = 1
    res = milp(c=cost, constraints=[LinearConstraint(csr_matrix(A), lb, ub)], integrality=np.ones(nv),
               bounds=Bounds(0, 1), options={"time_limit": time_limit, "disp": False})
    if res.x is None: return None
    x = np.round(res.x).astype(int)
    chosen = {}
    for vi, (oi, c) in enumerate(zvars):
        if x[vi]: chosen.setdefault(oi, []).append(c)
    odd = [t for t in range(l) if use2 and x[nz + nu + t]]
    return chosen, (l, odd) if use2 else None

def construct(opts, chosen):
    pats = []
    for oi, cls in chosen.items():
        p, e, cap, s, kind, d = opts[oi]
        basis = periodic_space(p, d, s)
        if kind == 'A':
            cls = sorted(set(n for c in cls for n in range(c % e, d, e)))   # all positions mod d of the class mod e
        # find combination vanishing at classes cls (positions mod d)
        M = sp.Matrix([[b[c] for b in basis] for c in cls]) if cls else sp.zeros(0, len(basis))
        from sympy.polys.matrices import DomainMatrix
        from sympy import GF
        if cls:
            ns = DomainMatrix.from_Matrix(M).convert_to(GF(p)).nullspace().to_Matrix()
            coef = [int(ns[0, j]) % p for j in range(ns.shape[1])]
        else:
            coef = [1] + [0] * (len(basis) - 1)
        y = [sum(coef[j] * basis[j][n] for j in range(len(basis))) % p for n in range(d)]
        pats.append((p, d, s, sorted(cls), y))
    return pats

def certify(D, r, pats, two):
    """Checks valid for every k == r (mod D): each y is d-periodic (by construction), has zero sum,
    satisfies the s-step recurrence cyclically with s == r (mod d), is nonzero, vanishes on its classes;
    mod-2 pattern has period l | gcd(r+1,D) and even weight; union covers Z/L."""
    for (p, d, s, cls, y) in pats:
        assert s == r % d and s not in (0, 1, d - 1)
        assert sum(y) % p == 0, "zero sum"
        assert all((y[n] - sum(y[(n - i) % d] for i in range(1, s + 1))) % p == 0 for n in range(d)), "s-step"
        assert any(y), "nonzero"
        assert all(y[c] == 0 for c in cls)
    mods = [d for (_, d, _, _, _) in pats]
    if two:
        l, odd = two
        assert (r + 1) % l == 0 and D % l == 0 and len(odd) % 2 == 0 and len(odd) >= 2
        mods.append(l)
    L = reduce(lcm, mods, 1)
    cov = bytearray(L)
    if two:
        l, odd = two
        for n in range(L):
            if n % l not in odd: cov[n] = 1
    for (p, d, s, cls, y) in pats:
        for n in range(L):
            if y[n % d] == 0: cov[n] = 1
    assert len(set(p for (p, _, _, _, _) in pats)) == len(pats)
    return all(cov), L

if __name__ == "__main__":
    D = int(sys.argv[1])
    rs = list(range(D)) if sys.argv[2] == 'all' else [int(t) for t in sys.argv[2:]]
    B = int(os.environ.get("PB", "1000000"))
    out = {}
    for r in rs:
        t0 = time.time()
        opts = build_options(D, r, B)
        sol = solve(D, r, opts) if opts else None
        if not sol:
            print(f"D={D} r={r}: no fixed covering ({len(opts)} options) [{time.time()-t0:.0f}s]", flush=True)
            out[r] = None
            continue
        chosen, two = sol
        pats = construct(opts, chosen)
        ok, L = certify(D, r, pats, two)
        desc = "; ".join(f"{p}: {len(cls)} cls mod {d} (s={s})" for (p, d, s, cls, y) in pats)
        print(f"D={D} r={r}: fixed covering {'OK' if ok else 'BAD'} with {len(pats)} odd primes"
              f"{' + 2 (period %d)' % two[0] if two else ''}, L={L} [{time.time()-t0:.0f}s] :: {desc}", flush=True)
        out[r] = {"two": two, "patterns": [(p, d, s, cls, y) for (p, d, s, cls, y) in pats], "ok": ok}
    json.dump({str(k): v for k, v in out.items()}, open(f"fixed_D{D}_{rs[0]}_{rs[-1]}.json", "w"))
