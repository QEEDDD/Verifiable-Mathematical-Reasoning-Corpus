\\ (1) pair patterns: primes p | N_{d,k} (partial factorization, bound FB) for d <= DMAX
\\ (2) root-of-unity patterns: r = number of roots of f_k mod p that are d-th roots of unity (r>=2 gives r-1 classes mod d)
\\ output: "P k d p"  and "R k d p r"
pairnorm(k,d) = {
  my(P=polcyclo(d), Z=Mod(x,P), s=k%d, H);
  if(s==0 || (k+1)%d==0, return(0));
  H = 2^(k+1)*(Z^s-1)^k*Z^s*(1-Z) + (Z^(s+1)-1)^(k+1);
  abs(polresultant(P, lift(H)));
}
gs(s) = x^(s+1) - 2*x^s + 1;
rootsunity(k,d,p) = { my(s=k%d, G); if(d%p==0, return(0));
  G = gcd(Mod(1,p)*(x^d-1)/(x-1), Mod(1,p)*gs(s)); poldegree(G) + ((k-1)%p==0) };
KLIST = [12, 16];
DMAX = 130; FB = 10^7;
{
for(ii=1,#KLIST, my(k=KLIST[ii]);
  for(d=3,DMAX,
    my(N=pairnorm(k,d));
    if(N!=0, my(F=factor(N, FB)); for(i=1,#F[,1], my(p=F[i,1]); if(p>2 && d%p!=0 && isprime(p) && p<10^12, print("P ",k," ",d," ",p))));
    \\ root of unity patterns: candidate primes divide Res(Phi_delta, g_s) for delta | d
    my(s=k%d); if(s<=1 || s==d-1, next);
    my(cands=List());
    fordiv(d, de, if(de>1, my(R=abs(polresultant(polcyclo(de), gs(s)))); if(R!=0, my(F=factor(R, FB)); for(i=1,#F[,1], my(p=F[i,1]); if(p>2 && isprime(p) && p<10^9, listput(cands,p))))));
    cands = Set(Vec(cands));
    for(i=1,#cands, my(p=cands[i], r=rootsunity(k,d,p)); if(r>=2, print("R ",k," ",d," ",p," ",r)));
  ));
}
quit
