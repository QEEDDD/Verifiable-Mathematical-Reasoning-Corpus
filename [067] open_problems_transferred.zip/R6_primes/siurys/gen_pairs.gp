\\ Candidate primes p admitting a "pair" pattern of modulus d for the k-step recurrence.
\\ Output lines: k d p1 p2 ...
pairnorm(k,d) = {
  my(P=polcyclo(d), Z=Mod(x,P), s=k%d, H);
  if(s==0 || (k+1)%d==0, return(0));
  H = 2^(k+1)*(Z^s-1)^k*Z^s*(1-Z) + (Z^(s+1)-1)^(k+1);
  abs(polresultant(P, lift(H)));
}
KMIN = 3; KMAX = 130; DMAX = 64; PMAX = 100000;
PR = primes([3, PMAX]);
{
for(k=KMIN,KMAX,
  for(d=3,DMAX, my(N=pairnorm(k,d)); if(N==0,next);
     my(v=List()); for(i=1,#PR, my(p=PR[i]); if(d%p!=0 && N%p==0, listput(v,p)));
     if(#v>0, my(s=Str(k," ",d)); for(i=1,#v, s=concat(s,Str(" ",v[i]))); print(s))));
}
quit
