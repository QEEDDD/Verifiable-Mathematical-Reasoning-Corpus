#!/usr/bin/env python3
"""
Targeted covering search for the k where the pipeline failed (e.g. k = 60, 72).
Uses the same certified option types as the pipeline ('P' = one full class mod d, certified by k
consecutive zeros on the class; 'R' = d-periodic solutions vanishing on up to r-1 classes), but
tries moduli L0 built from the moduli that are actually available for this k (e.g. 7 | L0), ranked by
the covering density sum_{options with d | L0} cap/d.  No mod-2 pattern (useless when k+1 is prime).
Writes certs/k<k>.json in the pipeline format (re-verified independently by verify_siurys_certs.py).
Usage: python3 -I hard_k.py k [LMAX] [time_limit] [ntries]
"""
import sys, os, json, time, itertools
from math import gcd
from functools import reduce
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import siurys_milp2 as M2
from fastla import ap_pattern_np
from siurys_pipeline import finalize, precertify

def lcm(a, b): return a // gcd(a, b) * b

def divisors(n): return [d for d in range(1, n + 1) if n % d == 0]

if __name__ == "__main__":
    k = int(sys.argv[1])
    LMAX = int(sys.argv[2]) if len(sys.argv) > 2 else 1200
    TL = float(sys.argv[3]) if len(sys.argv) > 3 else 300
    NTRY = int(sys.argv[4]) if len(sys.argv) > 4 else 8
    here = os.path.dirname(os.path.abspath(__file__))
    cache = os.path.join(here, f"prec_k{k}.json")
    t0 = time.time()
    if os.path.exists(cache):
        opts = [tuple(o) for o in json.load(open(cache))]
    else:
        opts = precertify(k, os.path.join(here, f"ext_k{k}.txt"))
        json.dump(opts, open(cache, "w"))
    print(f"k={k}: {len(opts)} certified options ({time.time()-t0:.0f}s)", flush=True)
    # candidate L0: numbers <= LMAX, score = sum cap/d over options with d | L0 (one option per prime: take best)
    def score(L0):
        best = {}
        for (typ, p, d, cap) in opts:
            if L0 % d == 0:
                best[p] = max(best.get(p, 0), cap / d)
        return sum(best.values())
    cands = sorted(((score(L0), L0) for L0 in range(6, LMAX + 1)), key=lambda t: (-t[0] / (1 + 0.0004 * t[1])))
    cands = [c for c in cands if c[0] >= float(os.environ.get("SMIN", "1.15"))][:NTRY]
    print("trying L0 (score):", [(L0, round(s, 3)) for s, L0 in cands], flush=True)
    banned = set()
    for s, L0 in cands:
        for attempt in range(5):
            cur = [o for o in opts if (o[0], o[1], o[2]) not in banned]
            t1 = time.time()
            try:
                sol, status = M2.solve(k, cur, L0, False, TL)
            except Exception as ex:
                print(f"  L0={L0}: MILP error {ex}", flush=True); sol = None; status = 'err'
            print(f"  L0={L0} (score {s:.3f}): status {status} ({time.time()-t1:.0f}s)", flush=True)
            if sol is None:
                break
            chosen, b = sol
            cur2 = [o for o in cur if L0 % o[2] == 0]
            pats, bad = [], False
            for oi, cls in chosen.items():
                typ, p, d, kap = cur2[oi]
                x = ap_pattern_np(k, p, d, cls[0]) if typ == 'P' else M2.ru_pattern(k, p, d, cls)
                if x is None:
                    banned.add((typ, p, d)); bad = True
                    print("   certification failed for", typ, p, d, cls, flush=True)
                    continue
                pats.append((typ, p, d, sorted(cls), x))
            if bad:
                continue
            rec = finalize(k, pats, None)
            rec["found"] = True; rec["how"] = f"hard_k L0={L0}"
            print(f"k={k}: L0={L0}, {len(pats)} primes, cover={rec['cover']}, direct={rec['direct']} "
                  f"({time.time()-t0:.0f}s)", flush=True)
            if rec["cover"] and rec["direct"]:
                json.dump(rec, open(os.path.join(here, "certs", f"k{k}.json"), "w"))
                sys.exit(0)
            break
    print(f"k={k}: NOT FOUND by hard_k", flush=True)
    sys.exit(1)
