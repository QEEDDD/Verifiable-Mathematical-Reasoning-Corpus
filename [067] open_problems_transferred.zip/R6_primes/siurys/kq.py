#!/usr/bin/env python3
"""
Covering search for k with k+1 = q prime (e.g. k = 60, q = 61), combining
  * the prime 2: x_n odd exactly for n == a, b (mod q)   (Lemma 'two'; here a = 0),
  * odd primes with pair patterns of modulus d = q*m (vanishing on one class mod q*m), and
  * odd primes with pair patterns of modulus d coprime to q.
Only n == a, b (mod q) must be covered by odd primes.  Writing n = a + q*t (side a) or n = b + q*t
(side b), a pattern on the class c mod d covers, on side s, the t with s + q*t == c (mod d).
For fixed b this is a linear covering problem on two copies of Z/Lt; solved by MILP (HiGHS).
All patterns are re-certified (k consecutive zeros on the class) and the final certificate is
written in the pipeline format (checked independently by verify_siurys_certs.py).
Usage: python3 -I k60.py k Lt b1,b2,... [time_limit]
"""
import sys, os, json, time
from math import gcd
from functools import reduce
import numpy as np
from scipy.optimize import milp, LinearConstraint, Bounds
from scipy.sparse import lil_matrix, csr_matrix
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fastla import ap_pattern_np
from siurys_pipeline import finalize

def lcm(a, b): return a // gcd(a, b) * b

def main():
    k = int(sys.argv[1]); q = k + 1
    Lt = int(sys.argv[2])
    bs = [int(v) for v in sys.argv[3].split(',')]
    TL = float(sys.argv[4]) if len(sys.argv) > 4 else 300
    here = os.path.dirname(os.path.abspath(__file__))
    opts = [tuple(o) for o in json.load(open(os.path.join(here, f"prec_k{k}.json"))) if o[0] == 'P']
    extra = []
    qfile = os.path.join(here, f"extq_k{k}.txt")
    if not os.path.exists(qfile): qfile = os.path.join(here, f"ext61_k{k}.txt")
    for l in open(qfile):
        t = l.split()
        if t[0] == 'P':
            d, p = int(t[2]), int(t[3])
            if ap_pattern_np(k, p, d, 0) is not None:
                extra.append(('P', p, d, 1))
    opts = opts + extra
    # usable: coprime d with d | Lt, or d = q*m with m | Lt
    if Lt == 0:
        def sc(L):
            best = {}
            for (typ, p, d, cap) in opts:
                if d % q == 0 and L % (d // q) == 0: best[p] = max(best.get(p, 0), q / d)
                elif d % q != 0 and L % d == 0: best[p] = max(best.get(p, 0), 2.0 / d)
            return sum(best.values())
        cands = sorted(((sc(L), L) for L in range(6, 2521)), key=lambda t: -t[0] / (1 + 0.0004 * t[1]))[:int(os.environ.get("NLT", "3"))]
        print("Lt candidates (score; need >= 2):", [(L, round(s, 3)) for s, L in cands], flush=True)
        Lts = [L for s, L in cands]
    else:
        Lts = [Lt]
    for Lt in Lts:
        if run(k, q, Lt, opts, bs, TL, here) == 0:
            return 0
    return 1

def run(k, q, Lt, opts, bs, TL, here):
    use = []
    for (typ, p, d, cap) in opts:
        if d % q == 0 and Lt % (d // q) == 0:
            use.append((p, d, d // q, 'q'))
        elif d % q != 0 and Lt % d == 0:
            use.append((p, d, d, 'c'))
    print(f"k={k}: {len(use)} usable options for Lt={Lt} "
          f"(q-type: {[(p, d) for (p, d, m, ty) in use if ty == 'q']})", flush=True)
    a = 0
    for b in bs:
        t0 = time.time()
        qinv = {}
        # variables
        var = []   # (opt index, side or None, class)
        for oi, (p, d, m, ty) in enumerate(use):
            if ty == 'q':
                for side in (0, 1):
                    for c in range(m): var.append((oi, side, c))
            else:
                for c in range(d): var.append((oi, None, c))   # class c mod d in n-space
        nz = len(var); nu = len(use)
        primes = sorted(set(u[0] for u in use))
        nrows = 2 * Lt + nu + len(primes)
        A = lil_matrix((nrows, nz + nu)); lb = np.zeros(nrows); ub = np.zeros(nrows)
        # coverage rows: side s in {0,1} (value a or b), t in Z/Lt
        sval = (a, b)
        for vi, (oi, side, c) in enumerate(var):
            p, d, m, ty = use[oi]
            if ty == 'q':
                # n-class: sval[side] + q*c (mod d), covers t == c (mod m) on that side
                for t in range(c, Lt, m):
                    A[side * Lt + t, vi] = 1
            else:
                for s in (0, 1):
                    # t with sval[s] + q t == c (mod d)  <=>  t == (c - sval[s]) * q^{-1} (mod d)
                    t0_ = ((c - sval[s]) * pow(q, -1, d)) % d
                    for t in range(t0_, Lt, d):
                        A[s * Lt + t, vi] = 1
        for r in range(2 * Lt):
            lb[r], ub[r] = 1, np.inf
        for vi, (oi, side, c) in enumerate(var):
            A[2 * Lt + oi, vi] = 1
        for oi in range(nu):
            A[2 * Lt + oi, nz + oi] = -1; lb[2 * Lt + oi], ub[2 * Lt + oi] = -np.inf, 0
        for j, p in enumerate(primes):
            for oi, u in enumerate(use):
                if u[0] == p: A[2 * Lt + nu + j, nz + oi] = 1
            lb[2 * Lt + nu + j], ub[2 * Lt + nu + j] = 0, 1
        cost = np.zeros(nz + nu); cost[nz:] = 1
        res = milp(c=cost, constraints=[LinearConstraint(csr_matrix(A), lb, ub)],
                   integrality=np.ones(nz + nu), bounds=Bounds(0, 1),
                   options={"time_limit": TL, "disp": False})
        print(f"  b={b}: MILP status {res.status} ({time.time()-t0:.0f}s)", flush=True)
        if res.x is None:
            continue
        x = np.round(res.x).astype(int)
        pats = []
        for vi, (oi, side, c) in enumerate(var):
            if not x[vi]: continue
            p, d, m, ty = use[oi]
            ncls = ((sval[side] + q * c) % d) if ty == 'q' else c
            xv = ap_pattern_np(k, p, d, ncls)
            assert xv is not None, (p, d, ncls)
            pats.append(('P', p, d, [ncls], xv))
        rec = finalize(k, pats, b)
        rec["found"] = True; rec["how"] = f"k60.py Lt={Lt} b={b}"
        print(f"k={k}: {len(pats) + 1} primes, cover={rec['cover']}, direct={rec['direct']}, L={rec['L']}", flush=True)
        if rec["cover"] and rec["direct"]:
            json.dump(rec, open(os.path.join(here, "certs", f"k{k}.json"), "w"))
            return 0
    return 1

if __name__ == "__main__":
    sys.exit(main())
