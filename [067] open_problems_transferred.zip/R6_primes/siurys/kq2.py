#!/usr/bin/env python3
"""
Variant of kq.py (k+1 = q prime) that also uses type-R options (periodic solutions vanishing on up
to cap classes mod d) and several files of q-type candidates.  Same two-sided MILP: the prime 2 is
odd exactly on n == 0, b (mod q); odd primes must cover n = 0 + q t and n = b + q t for all t.
Usage: python3 -I kq2.py k Lt b1,b2,... time_limit qfile1[,qfile2...]
"""
import sys, os, json, time
from math import gcd
import numpy as np
from scipy.optimize import milp, LinearConstraint, Bounds
from scipy.sparse import lil_matrix, csr_matrix
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fastla import ap_pattern_np
from siurys_pipeline import finalize
import siurys_milp2 as M2

def main():
    k = int(sys.argv[1]); q = k + 1
    Lt = int(sys.argv[2]); bs = [int(v) for v in sys.argv[3].split(',')]
    TL = float(sys.argv[4]); qfiles = sys.argv[5].split(',')
    here = os.path.dirname(os.path.abspath(__file__))
    opts = [tuple(o) for o in json.load(open(os.path.join(here, f"prec_k{k}.json")))]
    for qf in qfiles:
        for l in open(os.path.join(here, qf)):
            t = l.split()
            if t and t[0] == 'P':
                d, p = int(t[2]), int(t[3])
                if ap_pattern_np(k, p, d, 0) is not None:
                    opts.append(('P', p, d, 1))
    use = []   # (p, d, m, ty, cap)
    for (typ, p, d, cap) in opts:
        if typ == 'P' and d % q == 0 and Lt % (d // q) == 0:
            use.append((p, d, d // q, 'q', 1))
        elif d % q != 0 and Lt % d == 0:
            use.append((p, d, d, 'c' if typ == 'P' else 'r', cap))
    print(f"k={k} Lt={Lt}: {len(use)} usable options; q-type {[(u[0], u[1]) for u in use if u[3] == 'q']}; "
          f"R-type {[(u[0], u[1], u[4]) for u in use if u[3] == 'r']}", flush=True)
    for b in bs:
        t0 = time.time()
        sval = (0, b)
        var = []
        for oi, (p, d, m, ty, cap) in enumerate(use):
            if ty == 'q':
                for side in (0, 1):
                    for c in range(m): var.append((oi, side, c))
            else:
                for c in range(d): var.append((oi, None, c))
        nz, nu = len(var), len(use)
        primes = sorted(set(u[0] for u in use))
        nrows = 2 * Lt + nu + len(primes)
        A = lil_matrix((nrows, nz + nu)); lb = np.zeros(nrows); ub = np.zeros(nrows)
        for vi, (oi, side, c) in enumerate(var):
            p, d, m, ty, cap = use[oi]
            if ty == 'q':
                for t in range(c, Lt, m): A[side * Lt + t, vi] = 1
            else:
                qi = pow(q, -1, d)
                for s in (0, 1):
                    st = ((c - sval[s]) * qi) % d
                    for t in range(st, Lt, d): A[s * Lt + t, vi] = 1
        lb[:2 * Lt] = 1; ub[:2 * Lt] = np.inf
        for vi, (oi, side, c) in enumerate(var):
            A[2 * Lt + oi, vi] = 1
        for oi, u in enumerate(use):
            A[2 * Lt + oi, nz + oi] = -u[4]; lb[2 * Lt + oi], ub[2 * Lt + oi] = -np.inf, 0
        for j, p in enumerate(primes):
            for oi, u in enumerate(use):
                if u[0] == p: A[2 * Lt + nu + j, nz + oi] = 1
            lb[2 * Lt + nu + j], ub[2 * Lt + nu + j] = 0, 1
        cost = np.zeros(nz + nu); cost[nz:] = 1
        res = milp(c=cost, constraints=[LinearConstraint(csr_matrix(A), lb, ub)],
                   integrality=np.ones(nz + nu), bounds=Bounds(0, 1),
                   options={"time_limit": TL, "disp": False})
        print(f"  b={b}: MILP status {res.status} ({time.time()-t0:.0f}s)", flush=True)
        if res.x is None:
            continue
        x = np.round(res.x).astype(int)
        chosen = {}
        for vi, (oi, side, c) in enumerate(var):
            if x[vi]:
                p, d, m, ty, cap = use[oi]
                ncls = ((sval[side] + q * c) % d) if ty == 'q' else c
                chosen.setdefault(oi, []).append(ncls)
        pats = []
        for oi, cls in chosen.items():
            p, d, m, ty, cap = use[oi]
            if ty == 'r':
                xv = M2.ru_pattern(k, p, d, sorted(cls)); typ = 'R'
            else:
                assert len(cls) == 1
                xv = ap_pattern_np(k, p, d, cls[0]); typ = 'P'
            assert xv is not None, (p, d, cls)
            pats.append((typ, p, d, sorted(cls), xv))
        rec = finalize(k, pats, b)
        rec["found"] = True; rec["how"] = f"kq2.py Lt={Lt} b={b}"
        print(f"k={k}: {len(pats) + 1} primes, cover={rec['cover']}, direct={rec['direct']}, L={rec['L']}", flush=True)
        if rec["cover"] and rec["direct"]:
            json.dump(rec, open(os.path.join(here, "certs", f"k{k}.json"), "w"))
            return 0
    return 1

if __name__ == "__main__":
    sys.exit(main())
