import sys
sys.path.insert(0,'.')
from siurys_search import ap_pattern
from siurys_milp2 import ru_pattern, load
datafile, k = sys.argv[1], int(sys.argv[2])
out = open(sys.argv[3], 'w')
opts = load(datafile, k)
good = 0
for (typ, p, d, kap) in opts:
    if typ == 'P':
        ok = ap_pattern(k, p, d, 0) is not None
        if ok: out.write(f"P {k} {d} {p}\n"); good += 1
    else:
        # largest capacity actually achievable: dim of d-periodic space minus 1
        from siurys_milp2 import periodic_space
        r = len(periodic_space(k, p, d))
        if r >= 2:
            out.write(f"R {k} {d} {p} {r}\n"); good += 1
print("certified options:", good, "of", len(opts))
