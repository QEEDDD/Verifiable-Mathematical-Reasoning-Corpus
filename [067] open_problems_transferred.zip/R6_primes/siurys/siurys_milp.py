#!/usr/bin/env python3
"""
MILP covering search (scipy.optimize.milp / HiGHS) for Siurys's conjecture.
Patterns: optional mod-2 pattern (odd exactly on n == 0, b mod k+1) and odd primes p with a
solution vanishing on a whole class c mod d (certified afterwards by exact linear algebra).
Usage: python3 -I siurys_milp.py pairs_file kmin kmax [outfile]
"""
import sys, json, time
from math import gcd
from functools import reduce
import numpy as np
from scipy.optimize import milp, LinearConstraint, Bounds
from scipy.sparse import lil_matrix, csr_matrix

sys.path.insert(0, '.')
from siurys_search import load_pairs, ap_pattern, sequence_mod

def lcm(a, b):
    return a // gcd(a, b) * b

def divisors(n):
    return [d for d in range(1, n + 1) if n % d == 0]

def milp_cover(k, options, L, use2, time_limit=60):
    """options: list of (p,d) with d | L (and (k+1) | L if use2).
    Returns list of (p,d,c) [+ ('b', b)] or None."""
    k1 = k + 1
    var = []  # (p,d,c)
    for (p, d) in options:
        for c in range(d):
            var.append((p, d, c))
    nb = k1 - 1 if use2 else 0
    nv = len(var) + nb
    if nv == 0:
        return None
    primes = sorted(set(p for (p, d) in options))
    rows = []
    # coverage constraints: for r in [0,L): sum x_{p,d,r mod d} - [use2 and r mod k1 == s != 0] y_s >= [r not covered by 2 ? ...]
    A = lil_matrix((L + len(primes) + (1 if use2 else 0), nv))
    lb = np.zeros(A.shape[0]); ub = np.zeros(A.shape[0])
    idx = {}
    for i, (p, d, c) in enumerate(var):
        idx.setdefault((d, c), []).append(i)
    for r in range(L):
        for (p, d) in options:
            pass
    # build coverage rows efficiently
    by_d = {}
    for i, (p, d, c) in enumerate(var):
        by_d.setdefault(d, {}).setdefault(c, []).append(i)
    for r in range(L):
        for d, cl in by_d.items():
            for i in cl.get(r % d, []):
                A[r, i] = 1
        if use2:
            s = r % k1
            if s == 0:
                lb[r], ub[r] = 1, np.inf          # class 0 mod k+1: odd terms, need odd prime
            else:
                A[r, len(var) + s - 1] = -1       # need odd prime iff s == b
                lb[r], ub[r] = 0, np.inf
        else:
            lb[r], ub[r] = 1, np.inf
    for j, p in enumerate(primes):
        row = L + j
        for i, (pp, d, c) in enumerate(var):
            if pp == p:
                A[row, i] = 1
        lb[row], ub[row] = 0, 1
    if use2:
        row = L + len(primes)
        for s in range(1, k1):
            A[row, len(var) + s - 1] = 1
        lb[row], ub[row] = 1, 1
    cons = LinearConstraint(csr_matrix(A), lb, ub)
    cost = np.ones(nv)
    if use2:
        cost[len(var):] = 0
    res = milp(c=cost, constraints=[cons], integrality=np.ones(nv), bounds=Bounds(0, 1),
               options={"time_limit": time_limit, "disp": False})
    if res.x is None or res.status not in (0,):
        return None
    x = np.round(res.x).astype(int)
    sol = [var[i] for i in range(len(var)) if x[i] == 1]
    if use2:
        bs = [s for s in range(1, k1) if x[len(var) + s - 1] == 1]
        sol.append(('b', bs[0]))
    return sol

def certify_and_build(k, sol):
    k1 = k + 1
    patterns = []
    b = None
    for item in sol:
        if item[0] == 'b':
            b = item[1]
    if b is not None:
        init2 = [1 if (i % k1) in (0, b) else 0 for i in range(k)]
        patterns.append((2, 0, 0, init2))
    failed = []
    for item in sol:
        if item[0] == 'b':
            continue
        p, d, c = item
        x = ap_pattern(k, p, d, c)
        if x is None:
            failed.append((p, d))
        else:
            patterns.append((p, d, c, x))
    return patterns, b, failed

def covering_check(k, patterns, b):
    k1 = k + 1
    mods = [d for (p, d, c, x) in patterns if p != 2]
    L = reduce(lcm, mods + ([k1] if b is not None else []), 1)
    cov = bytearray(L)
    for (p, d, c, x) in patterns:
        if p == 2:
            seq2 = sequence_mod(k, x, 2, 2 * k1 + k)
            assert all(seq2[i] == seq2[i + k1] for i in range(k1 + k))
            for n in range(L):
                if seq2[n % k1] == 0:
                    cov[n] = 1
        else:
            for n in range(c, L, d):
                cov[n] = 1
    return all(cov), L

def initial_values(k, patterns):
    P = 1
    for (p, d, c, x) in patterns:
        P *= p
    vals = []
    for i in range(k):
        a, m = 0, 1
        for (p, d, c, x) in patterns:
            t = ((x[i] - a) * pow(m, -1, p)) % p
            a, m = a + m * t, m * p
        vals.append(a + P)
    t = 0
    while reduce(gcd, vals) != 1:
        vals[t % k] += P
        t += 1
    return vals, P

def direct_check(k, patterns, vals, N):
    seq = list(vals)
    s = sum(seq)
    while len(seq) < N:
        seq.append(s)
        s = 2 * s - seq[-1 - k]
    primes = [p for (p, d, c, x) in patterns]
    for n, v in enumerate(seq):
        if not any(v % p == 0 and v > p for p in primes):
            return False
    return True

L_CANDIDATES = [12, 24, 36, 48, 60, 72, 120, 144, 180, 240, 360, 720]

def solve(k, cand, time_limit=60):
    cand = sorted(set(cand))
    banned = set()
    for use2 in (True, False):
        for L0 in L_CANDIDATES:
            L = lcm(L0, k + 1) if use2 else L0
            if L > 6000:
                continue
            opts = [(p, d) for (p, d) in cand if L0 % d == 0 and (p, d) not in banned]
            if not opts:
                continue
            for attempt in range(6):
                sol = milp_cover(k, opts, L, use2, time_limit)
                if sol is None:
                    break
                patterns, b, failed = certify_and_build(k, sol)
                if failed:
                    banned.update(failed)
                    opts = [o for o in opts if o not in banned]
                    continue
                return patterns, b, L
    return None

if __name__ == "__main__":
    fname, kmin, kmax = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
    out = sys.argv[4] if len(sys.argv) > 4 else None
    pairs = load_pairs(fname)
    results = {}
    for k in range(kmin, kmax + 1):
        t0 = time.time()
        r = solve(k, pairs.get(k, []))
        if r is None:
            print(f"k={k}: no covering found ({time.time()-t0:.1f}s)", flush=True)
            results[k] = None
            continue
        patterns, b, L = r
        ok, Lc = covering_check(k, patterns, b)
        vals, P = initial_values(k, patterns)
        okd = direct_check(k, patterns, vals, 2 * Lc + 3 * k + 50) if Lc < 20000 else direct_check(k, patterns, vals, 3 * k + 2000)
        desc = []
        for (p, d, c, x) in patterns:
            desc.append(f"2|x_n unless n=0,{b} (mod {k+1})" if p == 2 else f"{p}|x_n for n={c} (mod {d})")
        print(f"k={k}: {len(patterns)} primes, cover Z/{Lc}: {ok}, direct check: {okd} ({time.time()-t0:.1f}s) :: " + "; ".join(desc), flush=True)
        results[k] = {"patterns": [(p, d, c) for (p, d, c, x) in patterns], "b": b, "L": Lc,
                      "cover_ok": ok, "direct_ok": okd, "initial_values": [str(v) for v in vals]}
    if out:
        with open(out, "w") as fh:
            json.dump(results, fh)
    bad = [k for k, v in results.items() if not v or not (v["cover_ok"] and v["direct_ok"])]
    print("SUMMARY: solved", sum(1 for v in results.values() if v and v["cover_ok"] and v["direct_ok"]), "unsolved/failed:", bad)
