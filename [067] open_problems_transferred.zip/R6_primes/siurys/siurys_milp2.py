#!/usr/bin/env python3
"""
MILP covering search with two pattern types for the k-step recurrence mod p:
  'P' (pair):  one class c mod d, certified by k consecutive zeros on the class;
  'R' (roots of unity): r = dim of d-periodic solutions mod p; vanish on up to r-1 chosen classes
                        mod d, certified by C^d v = v (d-periodicity) and zeros at the chosen classes.
Optionally the mod-2 pattern (odd exactly on n == 0, b mod k+1).
Usage: python3 -I siurys_milp2.py datafile k L0 [use2] [timelimit]
"""
import sys, json, time
from math import gcd
from functools import reduce
import numpy as np
from scipy.optimize import milp, LinearConstraint, Bounds
from scipy.sparse import lil_matrix, csr_matrix
sys.path.insert(0, '.')
from siurys_search import ap_pattern, sequence_mod, kernel_vector

def lcm(a, b):
    return a // gcd(a, b) * b

def matmul_mod(A, B, p):
    n = len(A)
    Bt = list(zip(*B))
    return [[sum(a * b for a, b in zip(row, col)) % p for col in Bt] for row in A]

def companion(k):
    C = [[0] * k for _ in range(k)]
    for i in range(k - 1):
        C[i][i + 1] = 1
    C[k - 1] = [1] * k
    return C

def matpow_mod(M, e, p):
    n = len(M)
    R = [[int(i == j) for j in range(n)] for i in range(n)]
    B = [row[:] for row in M]
    while e:
        if e & 1:
            R = matmul_mod(R, B, p)
        B = matmul_mod(B, B, p)
        e >>= 1
    return R

def nullspace_mod(M, p):
    """basis of {v : M v = 0} mod p."""
    rows = [r[:] for r in M]
    n = len(rows[0])
    where = [-1] * n
    rank = 0
    for col in range(n):
        piv = next((i for i in range(rank, len(rows)) if rows[i][col] % p), None)
        if piv is None:
            continue
        rows[rank], rows[piv] = rows[piv], rows[rank]
        inv = pow(rows[rank][col], p - 2, p)
        rows[rank] = [(v * inv) % p for v in rows[rank]]
        for i in range(len(rows)):
            if i != rank and rows[i][col] % p:
                f = rows[i][col]
                rows[i] = [(a - f * b) % p for a, b in zip(rows[i], rows[rank])]
        where[col] = rank
        rank += 1
    basis = []
    for fc in range(n):
        if where[fc] != -1:
            continue
        v = [0] * n
        v[fc] = 1
        for col in range(n):
            if where[col] != -1:
                v[col] = (-rows[where[col]][fc]) % p
        basis.append(v)
    return basis

def periodic_space(k, p, d):
    Cd = matpow_mod(companion(k), d, p)
    M = [[(Cd[i][j] - (i == j)) % p for j in range(k)] for i in range(k)]
    return nullspace_mod(M, p)

def ru_pattern(k, p, d, classes):
    """d-periodic solution mod p vanishing at the given classes; certified."""
    B = periodic_space(k, p, d)
    if len(B) < len(classes) + 1:
        return None
    # y_n for basis vectors: first d terms
    vals = [sequence_mod(k, b, p, d + k) for b in B]
    # solve sum_i a_i vals[i][c] = 0 for c in classes
    rows = [[vals[i][c] for i in range(len(B))] for c in classes]
    if rows:
        a = kernel_vector(rows, len(B), p)
    else:
        a = [1] + [0] * (len(B) - 1)
    if a is None:
        return None
    x = [sum(a[i] * B[i][t] for i in range(len(B))) % p for t in range(k)]
    if not any(x):
        return None
    seq = sequence_mod(k, x, p, 2 * d + k)
    assert all(seq[i] == seq[i + d] for i in range(d + k)), "not d-periodic"
    assert all(seq[c] == 0 for c in classes)
    return x

def load(datafile, k):
    opts = []
    for line in open(datafile):
        t = line.split()
        if int(t[1]) != k:
            continue
        if t[0] == 'P':
            opts.append(('P', int(t[3]), int(t[2]), 1))
        elif t[0] == 'R':
            opts.append(('R', int(t[3]), int(t[2]), int(t[4]) - 1))
    return opts

def solve(k, opts, L0, use2=False, time_limit=600):
    k1 = k + 1
    opts = [o for o in opts if L0 % o[2] == 0]
    if not opts:
        return None, 'no-options'
    L = lcm(L0, k1) if use2 else L0
    # variables: z_{o,c} for each option and class; u_o for each option; y_b (if use2)
    zvars = []
    for oi, (typ, p, d, kap) in enumerate(opts):
        for c in range(d):
            zvars.append((oi, c))
    nz, nu = len(zvars), len(opts)
    nb = (k1 - 1) if use2 else 0
    nv = nz + nu + nb
    primes = sorted(set(o[1] for o in opts))
    nrows = L + nu + len(primes) + (1 if use2 else 0)
    A = lil_matrix((nrows, nv))
    lb, ub = np.zeros(nrows), np.zeros(nrows)
    byd = {}
    for vi, (oi, c) in enumerate(zvars):
        byd.setdefault(opts[oi][2], {}).setdefault(c, []).append(vi)
    for r in range(L):
        for d, cl in byd.items():
            for vi in cl.get(r % d, []):
                A[r, vi] = 1
        if use2:
            s = r % k1
            if s == 0:
                lb[r], ub[r] = 1, np.inf
            else:
                A[r, nz + nu + s - 1] = -1
                lb[r], ub[r] = 0, np.inf
        else:
            lb[r], ub[r] = 1, np.inf
    for vi, (oi, c) in enumerate(zvars):
        A[L + oi, vi] = 1
    for oi, (typ, p, d, kap) in enumerate(opts):
        A[L + oi, nz + oi] = -kap
        lb[L + oi], ub[L + oi] = -np.inf, 0
    for j, p in enumerate(primes):
        for oi, o in enumerate(opts):
            if o[1] == p:
                A[L + nu + j, nz + oi] = 1
        lb[L + nu + j], ub[L + nu + j] = 0, 1
    if use2:
        row = L + nu + len(primes)
        for s in range(1, k1):
            A[row, nz + nu + s - 1] = 1
        lb[row], ub[row] = 1, 1
    cost = np.zeros(nv)
    cost[nz:nz + nu] = 1
    res = milp(c=cost, constraints=[LinearConstraint(csr_matrix(A), lb, ub)],
               integrality=np.ones(nv), bounds=Bounds(0, 1),
               options={"time_limit": time_limit, "disp": False})
    if res.x is None:
        return None, res.status
    x = np.round(res.x).astype(int)
    chosen = {}
    for vi, (oi, c) in enumerate(zvars):
        if x[vi]:
            chosen.setdefault(oi, []).append(c)
    b = None
    if use2:
        b = [s for s in range(1, k1) if x[nz + nu + s - 1]][0]
    return (chosen, b), res.status

if __name__ == "__main__":
    datafile, k, L0 = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
    use2 = len(sys.argv) > 4 and sys.argv[4] == '1'
    tl = float(sys.argv[5]) if len(sys.argv) > 5 else 600
    opts = load(datafile, k)
    banned = set()
    for attempt in range(10):
        cur = [o for o in opts if (o[0], o[1], o[2]) not in banned]
        t0 = time.time()
        sol, status = solve(k, cur, L0, use2, tl)
        print(f"k={k} L0={L0} use2={use2}: MILP status {status} in {time.time()-t0:.1f}s", flush=True)
        if sol is None:
            break
        chosen, b = sol
        cur2 = [o for o in cur if L0 % o[2] == 0]
        pats, bad = [], False
        for oi, cls in chosen.items():
            typ, p, d, kap = cur2[oi]
            if typ == 'P':
                assert len(cls) == 1
                xv = ap_pattern(k, p, d, cls[0])
            else:
                xv = ru_pattern(k, p, d, cls)
            if xv is None:
                banned.add((typ, p, d))
                bad = True
                print("   certification failed for", typ, p, d, cls)
            else:
                pats.append((typ, p, d, sorted(cls), xv))
        if bad:
            continue
        # covering check
        mods = [d for (_, _, d, _, _) in pats] + ([k + 1] if use2 else [])
        L = reduce(lcm, mods, 1)
        cov = bytearray(L)
        if use2:
            for n in range(L):
                if n % (k + 1) not in (0, b):
                    cov[n] = 1
        for (typ, p, d, cls, xv) in pats:
            for c in cls:
                for n in range(c, L, d):
                    cov[n] = 1
        primes = [p for (_, p, _, _, _) in pats] + ([2] if use2 else [])
        print(f"   covering with {len(primes)} primes, check over Z/{L}: {all(cov)}")
        for (typ, p, d, cls, xv) in pats:
            print(f"     {typ} p={p} d={d} classes={cls}")
        # explicit initial values
        allp = [(p, xv) for (_, p, _, _, xv) in pats]
        if use2:
            allp.append((2, [1 if (i % (k + 1)) in (0, b) else 0 for i in range(k)]))
        P = reduce(lambda u, v: u * v, [p for p, _ in allp], 1)
        vals = []
        for i in range(k):
            a, m = 0, 1
            for (p, xv) in allp:
                t = ((xv[i] - a) * pow(m, -1, p)) % p
                a, m = a + m * t, m * p
            vals.append(a + P)
        t = 0
        while reduce(gcd, vals) != 1:
            vals[t % k] += P
            t += 1
        seq = list(vals)
        s = sum(seq)
        N = 2 * L + 3 * k + 100
        while len(seq) < N:
            seq.append(s)
            s = 2 * s - seq[-1 - k]
        okd = all(any(v % p == 0 and v > p for p in primes) for v in seq)
        print(f"   gcd(initial)=1, direct check of first {N} terms (each divisible by a smaller covering prime): {okd}")
        json.dump({"k": k, "patterns": [(typ, p, d, cls) for (typ, p, d, cls, _) in pats], "b": b,
                   "initial": [str(v) for v in vals], "L": L, "cover": all(cov), "direct": okd},
                  open(f"cover_k{k}.json", "w"))
        break
