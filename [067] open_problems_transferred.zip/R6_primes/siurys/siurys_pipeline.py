#!/usr/bin/env python3
"""Pipeline: for each k find a certified covering (Siurys's conjecture), save JSON certificates."""
import sys, json, time, subprocess, os
from math import gcd
from functools import reduce
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from siurys_search import load_pairs, search_k, sequence_mod
from fastla import ap_pattern_np
import siurys_milp as M1
import siurys_milp2 as M2

def lcm(a, b):
    return a // gcd(a, b) * b

def certify_solution_A_or_B(k, res):
    strategy, sol, L = res
    pats = []
    b = None
    if strategy == 'A':
        Lam = reduce(lcm, [key[1] for (key, p, m, cls) in sol], 1)
        b = Lam % (k + 1)
        for (key, p, m, cls) in sol:
            d = key[1]; c = ((k + 1) * cls) % d
            x = ap_pattern_np(k, p, d, c)
            if x is None: return None, [(p, d)]
            pats.append(('P', p, d, [c], x))
    else:
        for (key, p, d, cls) in sol:
            x = ap_pattern_np(k, p, d, cls)
            if x is None: return None, [(p, d)]
            pats.append(('P', p, d, [cls], x))
    return (pats, b), []

def finalize(k, pats, b):
    k1 = k + 1
    mods = [d for (_, _, d, _, _) in pats] + ([k1] if b is not None else [])
    L = reduce(lcm, mods, 1)
    cov = bytearray(L)
    if b is not None:
        for n in range(L):
            if n % k1 not in (0, b): cov[n] = 1
    for (typ, p, d, cls, x) in pats:
        for c in cls:
            for n in range(c, L, d): cov[n] = 1
    allp = [(p, x) for (_, p, _, _, x) in pats]
    if b is not None:
        allp.append((2, [1 if (i % k1) in (0, b) else 0 for i in range(k)]))
    P = reduce(lambda u, v: u * v, [p for p, _ in allp], 1)
    vals = []
    for i in range(k):
        a, m = 0, 1
        for (p, x) in allp:
            t = ((x[i] - a) * pow(m, -1, p)) % p
            a, m = a + m * t, m * p
        vals.append(a + P)
    t = 0
    while reduce(gcd, vals) != 1:
        vals[t % k] += P; t += 1
    primes = [p for p, _ in allp]
    seq = list(vals); s = sum(seq)
    N = min(2 * L + 3 * k + 100, 20000)
    while len(seq) < N:
        seq.append(s); s = 2 * s - seq[-1 - k]
    okd = all(any(v % p == 0 and v > p for p in primes) for v in seq)
    return {"k": k, "patterns": [(typ, p, d, cls) for (typ, p, d, cls, _) in pats], "b": b,
            "L": L, "cover": bool(all(cov)), "direct": okd, "initial": [str(v) for v in vals]}

GP_EXT = r'''
pairnorm(k,d) = { my(P=polcyclo(d), Z=Mod(x,P), s=k%%d, H); if(s==0 || (k+1)%%d==0, return(0));
  H = 2^(k+1)*(Z^s-1)^k*Z^s*(1-Z) + (Z^(s+1)-1)^(k+1); abs(polresultant(P, lift(H))); }
gs(s) = x^(s+1) - 2*x^s + 1;
rootsunity(k,d,p) = { my(s=k%%d, G); if(d%%p==0, return(0));
  G = gcd(Mod(1,p)*(x^d-1)/(x-1), Mod(1,p)*gs(s)); poldegree(G) + ((k-1)%%p==0) };
k=%d; DMAX=%d; FB=%d;
{
for(d=3,DMAX, my(N=pairnorm(k,d));
  if(N!=0, my(F=factor(N, FB)); for(i=1,#F[,1], my(p=F[i,1]); if(p>2 && d%%p!=0 && isprime(p) && p<10^15, print("P ",k," ",d," ",p))));
  my(s=k%%d); if(s<=1 || s==d-1, next);
  my(cands=List());
  fordiv(d, de, if(de>1, my(R=abs(polresultant(polcyclo(de), gs(s)))); if(R!=0, my(F=factor(R, FB)); for(i=1,#F[,1], my(p=F[i,1]); if(p>2 && isprime(p) && p<10^9, listput(cands,p))))));
  cands = Set(Vec(cands));
  for(i=1,#cands, my(p=cands[i], r=rootsunity(k,d,p)); if(r>=2, print("R ",k," ",d," ",p," ",r))));
}
quit
'''

def extended_candidates(k, dmax, fb):
    script = GP_EXT % (k, dmax, fb)
    out = subprocess.run(["gp", "-q", "-s", "800000000"], input=script, capture_output=True, text=True, timeout=7200).stdout
    fname = f"ext_k{k}.txt"
    open(fname, "w").write(out)
    return fname

def precertify(k, fname):
    good = []
    for (typ, p, d, kap) in M2.load(fname, k):
        if typ == 'P':
            if ap_pattern_np(k, p, d, 0) is not None:
                good.append(('P', p, d, 1))
        else:
            if p < 2**31:
                r = len(M2.periodic_space(k, p, d))
                if r >= 2: good.append(('R', p, d, r - 1))
    return good

def milp2_try(k, opts, L0s, tl):
    for use2 in (True, False):
        for L0 in L0s:
            if use2 and lcm(L0, k + 1) > 8000: continue
            try:
                sol, status = M2.solve(k, opts, L0, use2, tl)
            except Exception as ex:
                print(f"   k={k} L0={L0}: MILP error {ex}", flush=True)
                continue
            if sol is None: continue
            chosen, b = sol
            cur = [o for o in opts if L0 % o[2] == 0]
            pats = []
            ok = True
            for oi, cls in chosen.items():
                typ, p, d, kap = cur[oi]
                x = ap_pattern_np(k, p, d, cls[0]) if typ == 'P' else M2.ru_pattern(k, p, d, cls)
                if x is None: ok = False; break
                pats.append((typ, p, d, sorted(cls), x))
            if ok:
                return pats, b
    return None

if __name__ == "__main__":
    pairsfile, kmin, kmax, outdir = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), sys.argv[4]
    os.makedirs(outdir, exist_ok=True)
    pairs = load_pairs(pairsfile)
    for k in range(kmin, kmax + 1):
        outf = os.path.join(outdir, f"k{k}.json")
        if os.path.exists(outf): continue
        t0 = time.time(); found = None; how = ""
        cand = list(pairs.get(k, []))
        for attempt in range(20):
            res = search_k(k, cand)
            if res is None: break
            r, failed = certify_solution_A_or_B(k, res)
            if r: found = r; how = "dfs-" + res[0]; break
            cand = [c for c in cand if c not in failed]
        if not found:
            fname = extended_candidates(k, 96, 10**7)
            opts = precertify(k, fname)
            r = milp2_try(k, opts, [24, 36, 48, 60, 72, 120, 144, 180, 240, 360, 720], 120)
            if r: found = r; how = "milp-ext"
        if not found:
            print(f"k={k}: NOT FOUND ({time.time()-t0:.0f}s)", flush=True)
            json.dump({"k": k, "found": False}, open(outf, "w"))
            continue
        pats, b = found
        rec = finalize(k, pats, b); rec["found"] = True; rec["how"] = how
        json.dump(rec, open(outf, "w"))
        print(f"k={k}: {how}, {len(rec['patterns']) + (1 if b is not None else 0)} primes, cover={rec['cover']}, direct={rec['direct']} ({time.time()-t0:.0f}s)", flush=True)
