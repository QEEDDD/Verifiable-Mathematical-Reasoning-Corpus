#!/usr/bin/env python3
"""
Covering search for k-step Fibonacci-like sequences of composite numbers (Siurys's conjecture).

x_n = x_{n-1} + ... + x_{n-k}.  For each k we look for
  * optionally the 'mod 2 pattern': any (k+1)-periodic 0/1 pattern with exactly two 1's
    (positions a,b mod k+1) is a solution mod 2;
  * odd primes p with a solution mod p vanishing on a whole residue class c mod d
    ("AP pattern"), certified by k consecutive zeros on that class;
such that every n >= 0 is covered.  Candidates (p,d) come from pairs_*.txt (PARI output),
but every pattern actually used is re-certified here by exact linear algebra mod p.
"""
import sys
from math import gcd
from functools import reduce

def lcm(a, b):
    return a // gcd(a, b) * b

def load_pairs(fname):
    data = {}
    with open(fname) as fh:
        for line in fh:
            t = list(map(int, line.split()))
            k, d, ps = t[0], t[1], t[2:]
            for p in ps:
                data.setdefault(k, []).append((p, d))
    return data

# ---------------------------------------------------------------- linear algebra mod p
def functional_rows(k, p, c, d, count):
    """rows r_N (as lists mod p) with x_N = r_N . (x_0..x_{k-1}) for N = c + d j, j < count."""
    r = [0] * k
    r[0] = 1
    N = 0
    rows = []
    for j in range(count):
        target = c + d * j
        while N < target:
            last = r[-1]
            r = [last] + [(r[i - 1] + last) % p for i in range(1, k)]
            N += 1
        rows.append(r[:])
    return rows

def kernel_vector(rows, k, p):
    """nonzero x with rows . x == 0 mod p, or None."""
    M = [row[:] for row in rows]
    pivcols = []
    rank = 0
    where = [-1] * k
    for col in range(k):
        piv = None
        for i in range(rank, len(M)):
            if M[i][col] % p:
                piv = i
                break
        if piv is None:
            continue
        M[rank], M[piv] = M[piv], M[rank]
        inv = pow(M[rank][col], p - 2, p)
        M[rank] = [(v * inv) % p for v in M[rank]]
        for i in range(len(M)):
            if i != rank and M[i][col] % p:
                f = M[i][col]
                Mi, Mr = M[i], M[rank]
                M[i] = [(Mi[t] - f * Mr[t]) % p for t in range(k)]
        where[col] = rank
        rank += 1
        if rank == len(M):
            break
    free = [c for c in range(k) if where[c] == -1]
    if not free:
        return None
    fc = free[0]
    x = [0] * k
    x[fc] = 1
    for col in range(k):
        if where[col] != -1:
            x[col] = (-M[where[col]][fc]) % p
    return x

def ap_pattern(k, p, d, c):
    """initial vector mod p of a nonzero solution vanishing on n == c (mod d), n >= c;
    certified by vanishing at c + d j for j = 0..k-1 (Cayley-Hamilton for C^d)."""
    rows = functional_rows(k, p, c, d, k)
    x = kernel_vector(rows, k, p)
    if x is None:
        return None
    assert all(sum(a * b for a, b in zip(row, x)) % p == 0 for row in rows)
    return x

def sequence_mod(k, init, p, N):
    seq = list(init)
    s = sum(seq) % p
    while len(seq) < N:
        nxt = s % p
        seq.append(nxt)
        s = (s + nxt - seq[-1 - k]) % p
    return seq[:N]

# ---------------------------------------------------------------- covering DFS
def cover_line(options, L, maxdepth, node_limit=200000):
    """options: list of (key, prime, m); choose distinct primes, each one class mod m (m | L),
    covering Z/L.  Returns list of (key, prime, m, class) or None."""
    covered = bytearray(L)
    used = set()
    sol = []
    opts = sorted(options, key=lambda o: o[2])
    nodes = [0]

    def first_uncovered(start):
        i = covered.find(0, start)
        return i

    def dfs(start, depth):
        nodes[0] += 1
        if nodes[0] > node_limit:
            return False
        r = first_uncovered(start)
        if r == -1:
            return True
        if depth == maxdepth:
            return False
        # simple bound: remaining uncovered count vs max coverage per option
        tried_m = set()
        for (key, p, m) in opts:
            if p in used:
                continue
            if (m, p) in tried_m:
                continue
            tried_m.add((m, p))
            newly = [i for i in range(r % m, L, m) if not covered[i]]
            for i in newly:
                covered[i] = 1
            used.add(p)
            sol.append((key, p, m, r % m))
            if dfs(r, depth + 1):
                return True
            sol.pop()
            used.discard(p)
            for i in newly:
                covered[i] = 0
        return False

    ok = dfs(0, 0)
    return list(sol) if ok else None

def search_k(k, pairs, maxdepth=8, Lcap=50000):
    res = {}
    k1 = k + 1
    # ---- strategy A: mod-2 pattern + j-line covering of C_0 (and C_b, b = Lambda mod k+1)
    optsA = []
    for (p, d) in pairs:
        g = gcd(d, k1)
        m = d // g
        optsA.append(((p, d), p, m))
    ms = sorted(set(o[2] for o in optsA))
    best = None
    for Lmax in (2, 4, 6, 8, 12, 16, 24, 30, 36, 48, 60, 72, 120, 144, 240, 360, 720):
        sub = [o for o in optsA if Lmax % o[2] == 0]
        if not sub:
            continue
        L = reduce(lcm, [o[2] for o in sub], 1)
        sol = cover_line(sub, L, maxdepth)
        if sol:
            Lam = reduce(lcm, [key[1] for (key, p, m, cls) in sol], 1)
            if Lam % k1 != 0:
                best = ('A', sol, Lam)
                break
    if best:
        return best
    # ---- strategy B: full covering of the n-line by AP patterns (no prime 2)
    for Lmax in (12, 24, 36, 48, 60, 72, 120, 144, 180, 240, 360, 720, 840, 1260, 2520):
        sub = [((p, d), p, d) for (p, d) in pairs if Lmax % d == 0]
        if not sub:
            continue
        L = reduce(lcm, [o[2] for o in sub], 1)
        if L > Lcap:
            continue
        sol = cover_line(sub, L, maxdepth)
        if sol:
            return ('B', sol, L)
    return None

# ---------------------------------------------------------------- construction & verification
def crt_pair(a1, m1, a2, m2):
    g = gcd(m1, m2)
    assert g == 1
    t = ((a2 - a1) * pow(m1, -1, m2)) % m2
    return a1 + m1 * t, m1 * m2

def build(k, strategy, sol):
    k1 = k + 1
    patterns = []  # (p, init vector mod p, description)
    if strategy == 'A':
        Lam = reduce(lcm, [key[1] for (key, p, m, cls) in sol], 1)
        a, b = 0, Lam % k1
        assert b != a
        init2 = [1 if (i % k1) in (a, b) else 0 for i in range(k)]
        patterns.append((2, init2, f"mod 2: odd exactly for n == {a},{b} (mod {k1})"))
        for (key, p, m, cls) in sol:
            d = key[1]
            # class on the j-line: j == cls (mod m)  <->  n = (k+1) j  ==  (k+1)*cls (mod d)
            c = (k1 * cls) % d
            x = ap_pattern(k, p, d, c)
            assert x is not None, ("pattern failed", k, p, d, c)
            patterns.append((p, x, f"mod {p}: zero for n == {c} (mod {d})"))
    else:
        for (key, p, d, cls) in sol:
            x = ap_pattern(k, p, d, cls)
            assert x is not None
            patterns.append((p, x, f"mod {p}: zero for n == {cls} (mod {d})"))
    # CRT
    A, M = 0, 1
    for (p, x, _) in patterns:
        pass
    inits = []
    for i in range(k):
        a, m = 0, 1
        for (p, x, _) in patterns:
            a, m = crt_pair(a, m, x[i] % p, p)
        inits.append(a)
    P = reduce(lambda u, v: u * v, [p for (p, x, _) in patterns], 1)
    maxp = max(p for (p, x, _) in patterns)
    # make positive, larger than all covering primes, and coprime overall
    vals = [a + P for a in inits]  # a + P > P > maxp
    t = 0
    while reduce(gcd, vals) != 1:
        t += 1
        vals[t % k] += P
    return patterns, vals, P

def verify(k, patterns, vals, N):
    """check x_n (n < N) is divisible by some covering prime p < x_n (exact integers)."""
    seq = list(vals)
    s = sum(seq)
    while len(seq) < N:
        seq.append(s)
        s = s + s - seq[-1 - k]
    primes = [p for (p, _, _) in patterns]
    for n, v in enumerate(seq):
        if not any(v % p == 0 and v > p for p in primes):
            return False, n
    # periodic certificate: pattern zero sets cover Z (checked on one full period)
    return True, None

def zero_sets_cover(k, patterns, strategy, sol):
    # Each odd pattern is certified (k consecutive zeros on its class).  For the mod-2 pattern the
    # sequence is (k+1)-periodic.  Covering of all n >= 0 is then a statement about residues:
    k1 = k + 1
    mods = [k1] + [int(desc.split("(mod ")[1].rstrip(")")) for (p, _, desc) in patterns[1:]] if strategy == 'A' \
        else [int(desc.split("(mod ")[1].rstrip(")")) for (p, _, desc) in patterns]
    L = reduce(lcm, mods, 1)
    cov = bytearray(L)
    for (p, x, desc) in patterns:
        if p == 2:
            seq2 = sequence_mod(k, x, 2, 2 * k1 + k)
            assert all(seq2[i] == seq2[i + k1] for i in range(k1 + k))  # (k+1)-periodic
            for n in range(L):
                if seq2[n % k1] == 0:
                    cov[n] = 1
        else:
            c = int(desc.split("n == ")[1].split(" ")[0])
            d = int(desc.split("(mod ")[1].rstrip(")"))
            for n in range(c % d, L, d):
                cov[n] = 1
    return all(cov), L

def solve_k(k, cand):
    """search, then certify every used pattern; drop failing candidates and retry."""
    cand = list(cand)
    for attempt in range(50):
        res = search_k(k, cand)
        if res is None:
            return None
        strategy, sol, L = res
        failed = []
        for item in sol:
            key, p = item[0], item[1]
            d = key[1]
            if strategy == 'A':
                c = ((k + 1) * item[3]) % d
            else:
                c = item[3]
            if ap_pattern(k, p, d, c) is None:
                failed.append(key)
        if not failed:
            return res
        cand = [pd for pd in cand if pd not in failed]
    return None

if __name__ == "__main__":
    fname = sys.argv[1]
    kmin, kmax = int(sys.argv[2]), int(sys.argv[3])
    pairs = load_pairs(fname)
    summary = []
    for k in range(kmin, kmax + 1):
        res = solve_k(k, pairs.get(k, []))
        if res is None:
            print(f"k={k}: NO COVERING FOUND", flush=True)
            summary.append((k, None))
            continue
        strategy, sol, L = res
        patterns, vals, P = build(k, strategy, sol)
        okcov, Lc = zero_sets_cover(k, patterns, strategy, sol)
        okv, bad = verify(k, patterns, vals, 3 * k + 400)
        desc = "; ".join(d for (_, _, d) in patterns)
        print(f"k={k}: strategy {strategy}, {len(patterns)} primes, covering of Z/{Lc}: {okcov}, "
              f"direct check of first {3*k+400} terms: {okv}  [{desc}]", flush=True)
        summary.append((k, (strategy, [p for (p, _, _) in patterns], okcov and okv)))
    good = [k for k, r in summary if r and r[2]]
    badk = [k for k, r in summary if not (r and r[2])]
    print("\nSUMMARY: verified k:", len(good), "failed k:", badk)
