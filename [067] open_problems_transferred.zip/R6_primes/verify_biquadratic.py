#!/usr/bin/env python3
"""
R6 verification script for Target A (Hahn--Ismailescu--Kim--Kim biquadratic conjecture).

Checks:
 (1) The ten explicit quartics of Table 1 of arXiv:2608.05309 (as transcribed):
     irreducible, Galois group V4 (cubic resolvent splits over Q), Pisot,
     Theorem-6 congruences, and floor(alpha^n) mod 6 for 1 <= n <= NMAX.
 (2) The construction of Theorem R6.A in several real biquadratic fields
     K = Q(sqrt p, sqrt q), including a field with no coprime radicand pair:
     a Pisot unit u = e_p^x e_q^y e_r^z, its order m modulo 6 Z[sp,sq,sr],
     the numbers alpha_j = 4 u^{jm}; exact minimal polynomial (characteristic
     polynomial of the integral multiplication matrix), the congruence
     minpoly == (z-4)^4 (mod 6), the inequality sum_{i>=2}|sigma_i(alpha)| < 1,
     and floor(alpha^n) mod 6 for 1 <= n <= NMAX (exact traces; the sign of the
     conjugate tail is fixed numerically with a certified precision margin).
Run with: python3 -I verify_biquadratic.py
"""
import sys
from math import gcd, isqrt
import sympy as sp
import mpmath as mp

NMAX = 120
z = sp.symbols('z')

def squarefree_part(n):
    r = 1
    for p, e in sp.factorint(n).items():
        if e % 2:
            r *= p
    return r

def power_sums(c, N):
    """c = [1, c1, c2, c3, c4] monic quartic z^4 + c1 z^3 + ... ; returns s_0..s_N."""
    s = [4]
    for n in range(1, N + 1):
        acc = 0
        for i in range(1, min(n - 1, 4) + 1):
            acc += c[i] * s[n - i]
        if n <= 4:
            acc += n * c[n]
        else:
            acc += c[4] * s[n - 4] if n - 4 >= 0 and 4 > min(n - 1, 4) else 0
        s.append(-acc)
    return s

def power_sums_check(c, N):
    # independent recomputation via the companion matrix trace
    C = sp.zeros(4, 4)
    for i in range(3):
        C[i + 1, i] = 1
    for i in range(4):
        C[i, 3] = -c[4 - i]
    out, P = [4], sp.eye(4)
    for n in range(1, N + 1):
        P = P * C
        out.append(P.trace())
    return out

def resolvent_splits(c):
    _, c1, c2, c3, c4 = c
    R = sp.Poly(z**3 - c2*z**2 + (c1*c3 - 4*c4)*z - (c1**2*c4 - 4*c2*c4 + c3**2), z)
    return sum(sp.roots(R, filter='Q').values()) == 3

TABLE = [
    [1, -46, -6, 20, 4], [1, -52, -51, 2, 1], [1, -52, -84, -40, -5],
    [1, -58, -30, 14, 1], [1, -64, 0, 8, 1], [1, -64, -51, 2, 4],
    [1, -76, 36, 44, -23], [1, -76, -48, -4, 1], [1, -82, 21, 20, -5],
    [1, -100, 15, 14, -2]]

def floor_from_tail(T, E):
    # alpha^n = T - E with E not an integer (alpha^n irrational) -> floor = T - ceil(E)
    return T - int(mp.ceil(E))

def check_table():
    print("== Part 1: HIKK Table 1 quartics ==")
    allok = True
    for c in TABLE:
        f = sp.Poly(sum(ci * z ** (4 - i) for i, ci in enumerate(c)), z)
        irr, v4 = f.is_irreducible, resolvent_splits(c)
        a, b, cc, d = -c[1], c[2], -c[3], c[4]
        cong = (a % 6 == 4 and b % 3 == 0 and cc % 6 == 4 and d % 3 == 1)
        s = power_sums(c, NMAX)
        assert s[:30] == power_sums_check(c, 29), "Newton sums mismatch"
        prec = 3 * NMAX + 100
        with mp.workdps(prec):
            rts = sorted([mp.re(r) for r in mp.polyroots(c, maxsteps=500, extraprec=6 * prec)])
            big, small = rts[-1], rts[:-1]
            pisot = big > 1 and all(abs(r) < 1 for r in small)
            S = sum(abs(r) for r in small)
            bad = []
            for n in range(1, NMAX + 1):
                E = mp.fsum([r ** n for r in small])
                dist = min(abs(E - mp.floor(E)), abs(mp.ceil(E) - E))
                assert dist > mp.mpf(10) ** (-(prec - 40)), "precision"
                fl = floor_from_tail(s[n], E)
                if fl % 6 not in (3, 4):
                    bad.append((n, fl % 6))
        print(f"{f.as_expr()}: irreducible={irr} V4={v4} Pisot={pisot} alpha~{mp.nstr(big, 10)} "
              f"sum|small|={mp.nstr(S, 5)} Thm6-congruences={cong}; n<={NMAX} with floor mod 6 not in {{3,4}}: {bad}")
        allok &= irr and v4 and pisot and cong and all(n < 3 for n, _ in bad)
    print("Part 1: all ten quartics are biquadratic Pisot with the property for 3<=n<=%d: %s" % (NMAX, allok))
    return allok

class Biquad:
    """Arithmetic in the order Z[sp, sq, sr], sp=sqrt p, sq=sqrt q, sr=sqrt r, r = pq/gcd(p,q)^2."""
    def __init__(self, p, q):
        g = gcd(p, q)
        self.p, self.q, self.g, self.r = p, q, g, p * q // (g * g)
        assert squarefree_part(self.r) == self.r and self.r not in (1, p, q)
        P, Q, R, G = p, q, self.r, g
        # sp*sq = G*sr ; sp*sr = (P/G)*sq ; sq*sr = (Q/G)*sp
        self.tab = {(0, 0): (1, 0), (0, 1): (1, 1), (0, 2): (1, 2), (0, 3): (1, 3),
                    (1, 1): (P, 0), (2, 2): (Q, 0), (3, 3): (R, 0),
                    (1, 2): (G, 3), (1, 3): (P // G, 2), (2, 3): (Q // G, 1)}
    def mul(self, x, y):
        res = [0, 0, 0, 0]
        for i in range(4):
            if x[i]:
                for j in range(4):
                    if y[j]:
                        c, k = self.tab[(min(i, j), max(i, j))]
                        res[k] += c * x[i] * y[j]
        return res
    def pow(self, x, n, mod=None):
        r, b = [1, 0, 0, 0], list(x)
        while n:
            if n & 1:
                r = self.mul(r, b)
                r = [t % mod for t in r] if mod else r
            b = self.mul(b, b)
            b = [t % mod for t in b] if mod else b
            n >>= 1
        return r
    def matrix(self, x):
        cols = [self.mul(x, e) for e in ([1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1])]
        return sp.Matrix(4, 4, lambda i, j: cols[j][i])
    def conj(self, x, s, t):
        return x[0] + s * x[1] * mp.sqrt(self.p) + t * x[2] * mp.sqrt(self.q) + s * t * x[3] * mp.sqrt(self.r)

def pell_unit(D):
    b = 1
    while True:
        for sgn in (1, -1):
            a2 = D * b * b + sgn
            a = isqrt(a2)
            if a > 0 and a * a == a2:
                return (a, b)
        b += 1

def pisot_unit(K):
    eps = [pell_unit(D) for D in (K.p, K.q, K.r)]
    with mp.workdps(50):
        logs = [mp.log(a + b * mp.sqrt(D)) for D, (a, b) in zip((K.p, K.q, K.r), eps)]
    best = None
    for x in range(1, 15):
        for y in range(1, 15):
            for w in range(1, 15):
                X, Y, W = x * logs[0], y * logs[1], w * logs[2]
                if X < Y + W and Y < X + W and W < X + Y:
                    cand = (x + y + w, x, y, w)
                    best = cand if best is None or cand < best else best
    _, x, y, w = best
    u = [1, 0, 0, 0]
    for idx, e, (a, b) in ((1, x, eps[0]), (2, y, eps[1]), (3, w, eps[2])):
        v = [a, 0, 0, 0]; v[idx] = b
        u = K.mul(u, K.pow(v, e))
    return u, eps, (x, y, w)

def order_mod6(K, u):
    m, cur = 1, [t % 6 for t in u]
    while cur != [1, 0, 0, 0]:
        cur = [t % 6 for t in K.mul(cur, u)]
        m += 1
    return m

def check_field(p, q, NJ=2):
    K = Biquad(p, q)
    u, eps, ex = pisot_unit(K)
    signs = [(1, 1), (1, -1), (-1, 1), (-1, -1)]
    with mp.workdps(80):
        cu = [K.conj(u, s, t) for s, t in signs]
        assert cu[0] > 1 and all(abs(c) < 1 for c in cu[1:]), "u is not a Pisot unit"
    m = order_mod6(K, u)
    print(f"-- K=Q(sqrt{p},sqrt{q}) (radicands {p},{q},{K.r}); units {eps}, exponents {ex}; "
          f"u~{mp.nstr(cu[0], 8)}, |small conj| {[mp.nstr(abs(c), 4) for c in cu[1:]]}; ord(u mod 6)={m}")
    j = 1
    with mp.workdps(80):
        while 4 * sum(abs(c) ** (j * m) for c in cu[1:]) >= 1:
            j += 1
    ok = True
    for jj in range(j, j + NJ):
        e = jj * m
        alpha = [4 * t for t in K.pow(u, e)]
        cp = sp.Poly(K.matrix(alpha).charpoly(z).as_expr(), z)
        co = cp.all_coeffs()
        irr = cp.is_irreducible
        cong6 = all((a1 - b1) % 6 == 0 for a1, b1 in zip(co, sp.Poly((z - 4) ** 4, z).all_coeffs()))
        A, B, C, D = -co[1], co[2], -co[3], co[4]
        thm6 = (A % 6 == 4 and B % 3 == 0 and C % 6 == 4 and D % 3 == 1)
        s = power_sums([1, co[1], co[2], co[3], co[4]], NMAX)
        assert s[:12] == power_sums_check([1, co[1], co[2], co[3], co[4]], 11)
        with mp.workdps(50):
            lg_alpha = float(mp.log10(K.conj(alpha, 1, 1)))
        dps = int(NMAX * (lg_alpha + 2)) + 200
        bad = []
        with mp.workdps(dps):
            conjs = [K.conj(alpha, s1, t1) for s1, t1 in signs]
            S = sum(abs(c) for c in conjs[1:])
            pis = conjs[0] > 1 and S < 1
            for n in range(1, NMAX + 1):
                if s[n] % 6 != 4:
                    bad.append(('trace', n))
                E = mp.fsum([c ** n for c in conjs[1:]])
                assert abs(E) > mp.mpf(10) ** (-(dps - 60)), "precision"
                fl = floor_from_tail(s[n], E)
                if fl % 6 not in (3, 4) or fl < 4:
                    bad.append(n)
        ok &= irr and cong6 and thm6 and pis and not bad
        print(f"   j={jj}: alpha=4u^{e} (~10^{lg_alpha:.2f}); minpoly irreducible={irr}; minpoly==(z-4)^4 mod 6: {cong6}; "
              f"Thm6 congruences: {thm6}; Pisot & sum|small conj|={mp.nstr(S, 4)}<1: {pis}; "
              f"T_n==4 mod 6 and floor mod 6 in {{3,4}} for 1<=n<={NMAX}: {not bad}")
        if jj == j:
            print(f"      minimal polynomial: {cp.as_expr()}")
    return ok

if __name__ == "__main__":
    ok1 = check_table()
    print("\n== Part 2: construction of Theorem R6.A in sample real biquadratic fields ==")
    ok2 = True
    for (p, q) in [(2, 3), (2, 5), (3, 5), (2, 7), (5, 13), (6, 10), (3, 7), (11, 13)]:
        ok2 &= check_field(p, q)
    print("\nPart 2: all checks passed:", ok2)
    sys.exit(0 if (ok1 and ok2) else 1)
