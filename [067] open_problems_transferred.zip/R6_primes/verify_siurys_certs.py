#!/usr/bin/env python3
"""
Independent verifier for the per-k certificates of Theorem R6.B(c) (Siurys's conjecture).

Each certificate (siurys/certs/k<k>.json) gives positive integers a_0..a_{k-1} and a list of
patterns.  Only the integers a_i are trusted as data; everything else is re-derived:
  * gcd(a_0..a_{k-1}) = 1 and min a_i > every covering prime;
  * for the prime 2 (if used, with b): x_n mod 2 is (k+1)-periodic [checked on n < 2k+1, which
    suffices because both x_{n+k+1} and x_n satisfy the recurrence] and x_n is odd only for
    n = 0, b (mod k+1);
  * type 'P' (p, d, [c]): x_{c+dj} = 0 mod p for j = 0..k-1.  The sequence z_j = x_{c+dj} mod p
    satisfies a linear recurrence of order k (characteristic polynomial of C^d, Cayley-Hamilton),
    hence z_j = 0 for all j >= 0;
  * type 'R' (p, d, [c1,..]): x_{n+d} = x_n mod p for n < k (hence for all n), and x_c = 0 mod p
    for each listed class c < d;
  * the union of the zero classes (and the even classes from 2) is all of Z/L, L = lcm of moduli.
Then every x_n (n >= 0) has a prime divisor p from the list with p < x_n, so it is composite.
Run: python3 -I verify_siurys_certs.py [certdir]
"""
import sys, os, json
from math import gcd
from functools import reduce

def lcm(a, b): return a // gcd(a, b) * b

def seq_mod(init, p, N):
    k = len(init)
    s = [v % p for v in init]
    t = sum(s) % p
    while len(s) < N:
        s.append(t)
        t = (2 * t - s[-1 - k]) % p
    return s

def verify(rec):
    k = rec["k"]
    a = [int(v) for v in rec["initial"]]
    assert len(a) == k and all(v > 0 for v in a)
    if reduce(gcd, a) != 1:
        return False, "gcd"
    k1 = k + 1
    primes, mods = [], []
    covered_classes = []   # (modulus, residue)
    b = rec.get("b")
    if b is not None:
        s2 = seq_mod(a, 2, 2 * k1 + k)
        if not all(s2[n] == s2[n + k1] for n in range(k1 + k)):
            return False, "mod2 period"
        odd = [r for r in range(k1) if s2[r] == 1]
        if sorted(odd) != sorted({0, b}):
            return False, "mod2 pattern"
        primes.append(2); mods.append(k1)
        for r in range(k1):
            if s2[r] == 0:
                covered_classes.append((k1, r))
    for (typ, p, d, cls) in rec["patterns"]:
        primes.append(p); mods.append(d)
        if typ == 'P':
            c = cls[0]
            s = seq_mod(a, p, c + d * (k - 1) + 1)
            if any(s[c + d * j] for j in range(k)):
                return False, f"P-certificate p={p}"
            covered_classes.append((d, c % d))
        else:
            s = seq_mod(a, p, d + k + max(cls) + 1)
            if any((s[n + d] - s[n]) % p for n in range(k)):
                return False, f"R-periodicity p={p}"
            for c in cls:
                if s[c] % p:
                    return False, f"R-zero p={p}"
                covered_classes.append((d, c % d))
    if len(set(primes)) != len(primes):
        return False, "repeated prime"
    if min(a) <= max(primes):
        return False, "size"
    L = reduce(lcm, mods, 1)
    cov = bytearray(L)
    for (d, r) in covered_classes:
        cov[r::d] = b'\x01' * len(range(r, L, d))
    if not all(cov):
        return False, "cover"
    return True, f"{len(primes)} primes, L={L}"

if __name__ == "__main__":
    certdir = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(os.path.abspath(__file__)), "siurys", "certs")
    ok_k, bad_k, missing = [], [], []
    nprimes = {}
    files = sorted((f for f in os.listdir(certdir) if f.startswith("k") and f.endswith(".json")),
                   key=lambda f: int(f[1:-5]))
    for f in files:
        rec = json.load(open(os.path.join(certdir, f)))
        k = rec["k"]
        if not rec.get("found", True):
            missing.append(k); continue
        ok, info = verify(rec)
        (ok_k if ok else bad_k).append(k)
        if ok:
            nprimes[k] = len(rec["patterns"]) + (1 if rec.get("b") is not None else 0)
        print(f"k={k}: {'VERIFIED' if ok else 'FAILED'} ({info})")
    print(f"\nverified: {len(ok_k)} values of k in [{min(ok_k) if ok_k else '-'}, {max(ok_k) if ok_k else '-'}]; "
          f"failed: {bad_k}; no certificate found: {missing}")
    rng = set(range(min(ok_k), max(ok_k) + 1)) if ok_k else set()
    print("all k in that range verified:", rng == set(ok_k))
    k0 = 2
    while k0 + 1 in set(ok_k):
        k0 += 1
    print(f"K0 = largest K with every 3 <= k <= K verified: {k0}; verified k beyond K0: "
          f"{sorted(k for k in ok_k if k > k0)}")
    if nprimes:
        lo, hi = min(nprimes.values()), max(nprimes.values())
        print(f"number of primes per covering: min {lo}, max {hi} (max attained at k = "
              f"{[k for k in nprimes if nprimes[k] == hi]})")
