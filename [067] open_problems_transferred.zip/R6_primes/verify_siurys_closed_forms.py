#!/usr/bin/env python3
"""
Exact checks of the closed forms in Lemma R6:lem:families (and of Remark R6:rem:obstruction(ii)),
using exact arithmetic in Z[i] and Z[omega] (Fractions where needed), for all k up to KMAX.

g_k(X) = X^{k+1} - 2 X^k + 1.
 (I)   k = 1 mod 4:  g_k(1-i) = g_k(1+i) = 1 - (-1)^{(k-1)/4} 2^{(k+1)/2};  theta=1-i equals 2(z^k-1)/(z^{k+1}-1), z=i
 (II)  k = 2 mod 4:  g_k(2-2i) = g_k(2+2i) = 1 + (-1)^{(k+2)/4} 2^{(3k+2)/2}; theta = 2(z^k-1)/(z^{k+1}-1), z=i
 (III) k = 1 mod 3:  g_k(-2w) = g_k(-2w^2) = 1 - (-2)^{k+1};  theta = 2(z^k-1)/(z^{k+1}-1), z=w
 (IV)  k = 2 mod 6:  g_k(1-w) = g_k(1-w^2) = (-3)^{k/2} + 1;  theta = 2(z^k-1)/(z^{k+1}-1), z=-w^2
 (rem) k = 3 mod 12: g_k(4(1-w)/3) = 1 - 2^{2k+1}/3^{(k+1)/2} (rational), z = -w^2
Also checks the side conditions: norms of theta-1 and zeta*theta-1 (units, or 5, or 3 as stated).
Run: python3 -I verify_siurys_closed_forms.py [KMAX]
"""
import sys
from fractions import Fraction as Fr

class GI:  # a + b i
    def __init__(s, a, b=0): s.a, s.b = Fr(a), Fr(b)
    def __add__(s, o): o = o if isinstance(o, GI) else GI(o); return GI(s.a + o.a, s.b + o.b)
    def __sub__(s, o): o = o if isinstance(o, GI) else GI(o); return GI(s.a - o.a, s.b - o.b)
    def __mul__(s, o): o = o if isinstance(o, GI) else GI(o); return GI(s.a*o.a - s.b*o.b, s.a*o.b + s.b*o.a)
    __rmul__ = __mul__
    def __pow__(s, n):
        r, b = GI(1), s
        while n:
            if n & 1: r = r * b
            b = b * b; n >>= 1
        return r
    def __eq__(s, o): o = o if isinstance(o, GI) else GI(o); return s.a == o.a and s.b == o.b
    def norm(s): return s.a*s.a + s.b*s.b
    def conj(s): return GI(s.a, -s.b)

class EI:  # a + b w, w^2 = -1 - w
    def __init__(s, a, b=0): s.a, s.b = Fr(a), Fr(b)
    def __add__(s, o): o = o if isinstance(o, EI) else EI(o); return EI(s.a + o.a, s.b + o.b)
    def __sub__(s, o): o = o if isinstance(o, EI) else EI(o); return EI(s.a - o.a, s.b - o.b)
    def __mul__(s, o):
        o = o if isinstance(o, EI) else EI(o)
        return EI(s.a*o.a - s.b*o.b, s.a*o.b + s.b*o.a - s.b*o.b)
    __rmul__ = __mul__
    def __pow__(s, n):
        r, b = EI(1), s
        while n:
            if n & 1: r = r * b
            b = b * b; n >>= 1
        return r
    def __eq__(s, o): o = o if isinstance(o, EI) else EI(o); return s.a == o.a and s.b == o.b
    def norm(s): return s.a*s.a - s.a*s.b + s.b*s.b
    def conj(s): return EI(s.a - s.b, -s.b)   # w -> w^2 = -1 - w

def g(k, t):
    return t**(k + 1) - 2 * t**k + 1

def theta_of(z, k):
    # returns theta with (z^{k+1}-1) theta = 2 (z^k - 1), checked by the caller via multiplication
    return None

KMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 400
I = GI(0, 1); W = EI(0, 1)
bad = []
counts = dict(I=0, II=0, III=0, IV=0, rem=0)
for k in range(3, KMAX + 1):
    if k % 4 == 1:
        t = GI(1, -1)
        assert (I**(k + 1) - 1) * t == 2 * (I**k - 1)
        v = 1 - (-1)**((k - 1)//4) * 2**((k + 1)//2)
        if not (g(k, t) == v and g(k, I * t) == v and I * t == t.conj()): bad.append(('I', k))
        counts['I'] += 1
    if k % 4 == 2:
        t = GI(2, -2)
        assert (I**(k + 1) - 1) * t == 2 * (I**k - 1)
        v = 1 + (-1)**((k + 2)//4) * 2**((3*k + 2)//2)
        if not (g(k, t) == v and g(k, I * t) == v and I * t == t.conj()): bad.append(('II', k))
        counts['II'] += 1
    if k % 3 == 1:
        t = EI(0, -2)
        assert (W**(k + 1) - 1) * t == 2 * (W**k - 1)
        v = 1 - (-2)**(k + 1)
        if not (g(k, t) == v and g(k, W * t) == v and W * t == t.conj()): bad.append(('III', k))
        counts['III'] += 1
    Z6 = EI(1, 1)            # -w^2 = 1 + w, primitive 6th root of unity
    if k % 6 == 2:
        t = EI(1, -1)
        assert (Z6**(k + 1) - 1) * t == 2 * (Z6**k - 1)
        v = (-3)**(k//2) + 1
        if not (g(k, t) == v and g(k, Z6 * t) == v and Z6 * t == t.conj()): bad.append(('IV', k))
        counts['IV'] += 1
    if k % 12 == 3:
        t = EI(Fr(4, 3), Fr(-4, 3))
        assert (Z6**(k + 1) - 1) * t == 2 * (Z6**k - 1)
        v = 1 - Fr(2**(2*k + 1), 3**((k + 1)//2))
        if not (g(k, t) == v and g(k, Z6 * t) == v): bad.append(('rem', k))
        counts['rem'] += 1
print("closed forms checked for 3 <= k <=", KMAX, "; number of k per family:", counts)
print("mismatches:", bad)
# side conditions (norms)
print("norms of theta-1, zeta*theta-1:",
      "(I)", (GI(1, -1) - 1).norm(), (GI(1, 1) - 1).norm(),
      "(II)", (GI(2, -2) - 1).norm(), (GI(2, 2) - 1).norm(),
      "(III)", (EI(0, -2) - 1).norm(), (EI(0, -2).conj() - 1).norm(),
      "(IV)", (EI(1, -1) - 1).norm(), (EI(1, -1).conj() - 1).norm())
print("orders: i^4=1, i^2!=1:", I**4 == 1 and not I**2 == 1, "; w^3=1:", W**3 == 1,
      "; (1+w)^6=1, (1+w)^2!=1, (1+w)^3!=1:", Z6**6 == 1 and not Z6**2 == 1 and not Z6**3 == 1)
sys.exit(1 if bad else 0)
