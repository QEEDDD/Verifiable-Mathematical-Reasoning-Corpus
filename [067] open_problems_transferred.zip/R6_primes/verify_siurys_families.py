#!/usr/bin/env python3
"""
R6 verification for Target B (Siurys's k-step conjecture): the explicit families.

For each k in [KMIN, KMAX] lying in one of the families of Theorem R6.B:
  I   : k = 1 (mod 4):  mod-2 pattern (odd only on two odd classes mod k+1)
        + two odd primes p | M_k = 2^((k+1)/2) - (-1)^((k-1)/4) on classes 1, 3 mod 4;
  II  : k = 2 (mod 4):  four primes p != 2,5 dividing A_k = 1 + (-1)^((k+2)/4) 2^((3k+2)/2),
        classes 0,1,2,3 mod 4;
  III : k = 1 (mod 3):  three primes p != 2,3 dividing B_k = (-2)^(k+1) - 1, classes 0,1,2 mod 3;
  IV  : k = 2 (mod 6), k >= 8: mod-2 pattern (odd only on n = 0, 3 mod k+1)
        + two primes p >= 5 dividing C_k = 3^(k/2) + (-1)^(k/2), classes 0, 3 mod 6;
the script finds the needed primes among the small prime factors of the closed-form integer,
then CERTIFIES every pattern independently (exact linear algebra mod p: k consecutive zeros on
the arithmetic progression, which by Cayley-Hamilton for C^d forces vanishing on the whole
progression), checks that the zero sets cover Z, builds explicit coprime initial values by CRT,
and checks directly that the first terms are composite.  It also checks the Zsigmondy counts used
in the proofs (number of usable primitive divisors) for every k of the unconditional classes.
Run: python3 -I verify_siurys_families.py [KMIN KMAX]
"""
import sys, os
from math import gcd
from functools import reduce
import sympy as sp
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "siurys"))
from fastla import ap_pattern_np

def lcm(a, b): return a // gcd(a, b) * b

def seq_mod(k, init, p, N):
    s = list(init); t = sum(s) % p
    while len(s) < N:
        s.append(t); t = (2 * t - s[-1 - k]) % p
    return s

def small_primes(n, need, exclude, limit=10**6):
    n = abs(n)
    f = sp.factorint(n, limit=limit)
    ps = sorted(p for p in f if sp.isprime(p) and p not in exclude)
    return ps

def family(k):
    if k % 4 == 1: return 'I'
    if k % 4 == 2: return 'II'
    if k % 3 == 1: return 'III'
    if k % 6 == 2 and k >= 8: return 'IV'
    return None

def build(k, fam):
    pats = []   # (p, d, c, init)
    two = None
    if fam == 'I':
        M = 2 ** ((k + 1) // 2) - (-1) ** ((k - 1) // 4)
        ps = small_primes(M, 2, {2})
        if len(ps) < 2: return None
        for p, c in zip(ps[:2], (1, 3)):
            x = ap_pattern_np(k, p, 4, c)
            if x is None: return ('FAIL', p)
            pats.append((p, 4, c, x))
        two = (1, 3)
    elif fam == 'II':
        A = 1 + (-1) ** ((k + 2) // 4) * 2 ** ((3 * k + 2) // 2)
        ps = small_primes(A, 4, {2, 5})
        if len(ps) < 4: return None
        for p, c in zip(ps[:4], (0, 1, 2, 3)):
            x = ap_pattern_np(k, p, 4, c)
            if x is None: return ('FAIL', p)
            pats.append((p, 4, c, x))
    elif fam == 'III':
        B = (-2) ** (k + 1) - 1
        ps = small_primes(B, 3, {2, 3})
        if len(ps) < 3: return None
        for p, c in zip(ps[:3], (0, 1, 2)):
            x = ap_pattern_np(k, p, 3, c)
            if x is None: return ('FAIL', p)
            pats.append((p, 3, c, x))
    elif fam == 'IV':
        C = 3 ** (k // 2) + (-1) ** (k // 2)
        ps = small_primes(C, 2, {2, 3})
        if len(ps) < 2: return None
        for p, c in zip(ps[:2], (0, 3)):
            x = ap_pattern_np(k, p, 6, c)
            if x is None: return ('FAIL', p)
            pats.append((p, 6, c, x))
        two = (0, 3)
    return pats, two

def check(k, pats, two):
    k1 = k + 1
    mods = [d for (_, d, _, _) in pats] + ([k1] if two else [])
    L = reduce(lcm, mods, 1)
    cov = bytearray(L)
    allp = [(p, x) for (p, _, _, x) in pats]
    if two:
        a, b = two
        x2 = [1 if (i % k1) in (a, b) else 0 for i in range(k)]
        s2 = seq_mod(k, x2, 2, 2 * k1 + k)
        assert all(s2[i] == s2[i + k1] for i in range(k1 + k))      # (k+1)-periodic mod 2
        for n in range(L):
            if s2[n % k1] == 0: cov[n] = 1
        allp.append((2, x2))
    for (p, d, c, x) in pats:
        for n in range(c, L, d): cov[n] = 1
    if not all(cov): return False, "cover"
    P = reduce(lambda u, v: u * v, [p for p, _ in allp], 1)
    vals = []
    for i in range(k):
        a, m = 0, 1
        for (p, x) in allp:
            t = ((x[i] - a) * pow(m, -1, p)) % p
            a, m = a + m * t, m * p
        vals.append(a + P)
    t = 0
    while reduce(gcd, vals) != 1:
        vals[t % k] += P; t += 1
    seq = list(vals); s = sum(seq)
    N = 3 * k + 60
    while len(seq) < N:
        seq.append(s); s = 2 * s - seq[-1 - k]
    primes = [p for p, _ in allp]
    ok = all(any(v % p == 0 and v > p for p in primes) for v in seq)
    return ok, "direct"

def zsigmondy_counts(k):
    """number of usable primitive-divisor primes guaranteed by the proof (orders = exponents)."""
    if k % 8 == 5 and k >= 13:     # I with M_k = 2^m + 1
        m = (k + 1) // 2; return 2   # 3 and a primitive divisor of 2^(2m)-1
    if k % 24 == 17:               # I with M_k = 2^m - 1, 3 | m
        return 2
    if k % 8 == 2 and k >= 18:     # II with 2^M - 1, divisors delta of M except 1,4 (6 does not divide M)
        M = (3 * k + 2) // 2
        assert M % 3 != 0
        return len([dd for dd in sp.divisors(M) if dd not in (1, 4)])
    if k % 12 == 7 and k >= 19:    # III with 2^(k+1)-1, delta in {4, (k+1)/2, k+1}
        return len({4, (k + 1) // 2, k + 1})
    return None

if __name__ == "__main__":
    KMIN = int(sys.argv[1]) if len(sys.argv) > 1 else 11
    KMAX = int(sys.argv[2]) if len(sys.argv) > 2 else 160
    stats = {}
    zs_ok = True
    for k in range(KMIN, KMAX + 1):
        zc = zsigmondy_counts(k)
        if zc is not None:
            need = {1: 2, 2: 4}.get(k % 4, 3)
            if k % 12 == 7: need = 3
            zs_ok &= zc >= need
        fam = family(k)
        if fam is None:
            stats.setdefault('none', []).append(k); continue
        r = build(k, fam)
        if r is None:
            stats.setdefault(fam + ':few-small-primes', []).append(k); continue
        if r[0] == 'FAIL':
            print(f"k={k}: family {fam} pattern certification FAILED at p={r[1]}"); stats.setdefault('FAIL', []).append(k); continue
        pats, two = r
        ok, why = check(k, pats, two)
        stats.setdefault(fam + (':ok' if ok else ':BAD'), []).append(k)
        if not ok: print(f"k={k}: family {fam} check failed ({why})")
    for key in sorted(stats):
        v = stats[key]
        print(f"{key}: {len(v)} values of k" + (f" -> {v}" if len(v) <= 40 else f" (first: {v[:20]})"))
    print("Zsigmondy counts in unconditional classes sufficient for all k in range:", zs_ok)
    print("Any certification failure:", 'FAIL' in stats or any(k.endswith(':BAD') for k in stats))
