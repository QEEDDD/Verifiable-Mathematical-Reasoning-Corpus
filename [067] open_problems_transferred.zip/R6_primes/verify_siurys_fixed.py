#!/usr/bin/env python3
"""
Verifier for the class-wide ("fixed") coverings of Theorem R6.B(a'), e.g. k == 11, 71 (mod 120).

Data: for a residue r mod D, a mod-2 pattern of period l (l | gcd(r+1, D)) with an even number of
'odd' classes, and odd primes p with d-periodic vectors y (d | D) and s = r mod d.  Checked:
  * y has zero sum mod p and satisfies y_n = y_{n-1}+...+y_{n-s} cyclically (indices mod d);
    then for EVERY k == s (mod d), n -> y_{n mod d} satisfies the k-step recurrence mod p, because
    sum_{i=1}^k y_{n-i} = ((k-s)/d)*sum(y) + sum_{i=1}^s y_{n-i};
  * y is nonzero and vanishes at the listed positions;
  * the mod-2 pattern: l | r+1 and l | D, so l | k+1 for every k == r (mod D); an l-periodic 0/1 sequence
    with even weight per period is (k+1)-periodic with even weight, hence a solution mod 2;
  * distinct primes; the zero classes cover Z/L.
In addition, for k = r, r+D, r+2D (k >= 3) explicit coprime initial values are built by CRT and the first
3k+200 terms are checked to be composite (each divisible by a smaller covering prime).
Run: python3 -I verify_siurys_fixed.py [json files]
"""
import sys, json, os, glob
from math import gcd
from functools import reduce

def lcm(a, b): return a // gcd(a, b) * b

def check_class(D, r, rec):
    two = rec["two"]
    pats = rec["patterns"]
    mods = []
    for (p, d, s, cls, y) in pats:
        assert D % d == 0 and s == r % d and s not in (0, 1, d - 1)
        assert len(y) == d and sum(y) % p == 0
        assert all((y[n] - sum(y[(n - i) % d] for i in range(1, s + 1))) % p == 0 for n in range(d))
        assert any(v % p for v in y)
        assert all(y[c] % p == 0 for c in cls)
        mods.append(d)
    primes = [p for (p, _, _, _, _) in pats]
    if two:
        l, odd = two
        assert (r + 1) % l == 0 and D % l == 0 and len(odd) % 2 == 0 and len(odd) >= 2
        mods.append(l); primes.append(2)
    assert len(set(primes)) == len(primes)
    L = reduce(lcm, mods, 1)
    cov = bytearray(L)
    if two:
        for n in range(L):
            if n % l not in odd: cov[n] = 1
    for (p, d, s, cls, y) in pats:
        for n in range(L):
            if y[n % d] % p == 0: cov[n] = 1
    assert all(cov), "cover"
    # explicit instances
    for k in (r, r + D, r + 2 * D):
        if k < 3: continue
        res = [(p, [y[i % d] % p for i in range(k)]) for (p, d, s, cls, y) in pats]
        if two:
            res.append((2, [0 if (i % l) not in odd else 1 for i in range(k)]))
        P = reduce(lambda u, v: u * v, [p for p, _ in res], 1)
        vals = []
        for i in range(k):
            a, m = 0, 1
            for (p, x) in res:
                t = ((x[i] - a) * pow(m, -1, p)) % p
                a, m = a + m * t, m * p
            vals.append(a + P)
        t = 0
        while reduce(gcd, vals) != 1:
            vals[t % k] += P; t += 1
        seq = list(vals); s_ = sum(seq)
        while len(seq) < 3 * k + 200:
            seq.append(s_); s_ = 2 * s_ - seq[-1 - k]
        assert all(any(v % p == 0 and v > p for p in primes) for v in seq), f"direct k={k}"
    return L, primes

if __name__ == "__main__":
    files = sys.argv[1:] or glob.glob(os.path.join(os.path.dirname(os.path.abspath(__file__)), "siurys", "fixed_D*.json"))
    total = []
    for f in files:
        D = int(os.path.basename(f).split('_')[1][1:])
        data = json.load(open(f))
        for r, rec in sorted(data.items(), key=lambda t: int(t[0])):
            if not rec: continue
            L, primes = check_class(D, int(r), rec)
            total.append((D, int(r)))
            print(f"k == {r} (mod {D}): fixed covering VERIFIED; primes {sorted(primes)}, L = {L}; "
                  f"explicit instances k = {r}, {int(r)+D}, {int(r)+2*D} checked")
    print("verified residue classes:", total)
