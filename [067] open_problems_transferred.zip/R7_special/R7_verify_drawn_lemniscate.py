"""R7 verification for the drawn-lemniscate question of Mani & Rubinstein-Salzedo
(Arnold Math. J. 2015, Remark 1.4): which n-division points of the lemniscate are
constructible with straightedge and compass when the lemniscate is drawn?

Checks (each prints PASS/FAIL):
 1. inversion in the unit circle maps L:(x^2+y^2)^2=x^2-y^2 onto H: X^2-Y^2=1;
    L cap circle  is  circle cap conic, L cap line is a quartic (degree bookkeeping).
 2. circle u^2+v^2+Du+Ev+F=0 meets uv=1/2 exactly at roots of u^4+Du^3+Fu^2+(E/2)u+1/4.
 3. explicit drawn-lemniscate constructions of 2^(1/3) and cos(20 deg): the circle is
    built, inverted, intersected with L numerically (points verified on L to 1e-40),
    inverted back, and the root read off.
 4. arithmetic: |(Z[i]/n)^*| is 3-smooth  <=>  n = 2^a 3^b p_1...p_r with distinct
    Pierpont primes p_i in {7} or p_i = 1 mod 4   (n <= 20000).
 5. Galois check: for odd n in {3,5,7,9,11,13} the n-division polynomial of y^2=x^3-x,
    factored over Q(i), has the factor through x = wp(2*varpi/n) (the lemniscate
    division value 1/sl(2varpi/n)^2) of degree |(Z[i]/n)^*|/2.
Run: python3 -I R7_verify_drawn_lemniscate.py
"""
import sympy as sp
import mpmath as mp
import cypari2
pari = cypari2.Pari(); pari.allocatemem(10**9)
ok_all = True
def report(name, cond):
    global ok_all
    print(('PASS ' if cond else 'FAIL ') + name); ok_all = ok_all and bool(cond)

# 1. inversion
X, Y, x, y = sp.symbols('X Y x y', real=True)
xi, yi = X/(X**2+Y**2), Y/(X**2+Y**2)
Lexpr = (xi**2+yi**2)**2 - (xi**2-yi**2)
report('1a. inverse image of L is X^2-Y^2=1', sp.simplify(sp.factor(Lexpr*(X**2+Y**2)**2) - (1-(X**2-Y**2))) == 0 or sp.simplify(Lexpr*(X**2+Y**2)**2 + (X**2-Y**2-1)) == 0)
D, E, F, a, b, c = sp.symbols('D E F a b c')
# on L, x^2+y^2 = -(Dx+Ey+F) for a point of the circle, so (x^2+y^2)^2 = (Dx+Ey+F)^2: a conic
conic = sp.expand((D*x+E*y+F)**2 - (x**2-y**2))
report('1b. L cap circle = circle cap conic (degree of conic = 2)', sp.Poly(conic, x, y).total_degree() == 2)
t = sp.symbols('t')
quart = sp.Poly(sp.expand(((x**2+y**2)**2-(x**2-y**2)).subs(y, (-c-a*x)/b)*b**4), x)
report('1c. L cap line gives a quartic in x', quart.degree() == 4)

# 2. hyperbola uv=1/2 and circle
u = sp.symbols('u')
expr = sp.expand((u**2 + (1/(2*u))**2 + D*u + E/(2*u) + F)*u**2)
report('2. circle cap (uv=1/2) <=> u^4+Du^3+Fu^2+(E/2)u+1/4=0', sp.expand(expr - (u**4+D*u**3+F*u**2+E*u/2+sp.Rational(1,4))) == 0)

# 3. explicit constructions
mp.mp.dps = 60
def solve_via_lemniscate(coeffs, target):
    """coeffs: real monic quartic u^4+a3u^3+a2u^2+a1u+a0, a0>0. Scale so constant=1/4,
    build circle in (u,v) coords, rotate by -45deg to (X,Y) coords of H: X^2-Y^2=1,
    invert circle in unit circle, intersect with L, invert back, rotate, unscale."""
    a3, a2, a1, a0 = [mp.mpf(q) for q in coeffs]
    lam = (1/(4*a0))**(mp.mpf(1)/4)      # u = lam*w turns the quartic into u^4+Du^3+Fu^2+(E/2)u+1/4
    Dc, Fc, Ec = a3*lam, a2*lam**2, 2*a1*lam**3
    # circle in (u,v): center (-Dc/2,-Ec/2), radius^2 = (Dc^2+Ec^2)/4 - Fc
    cu, cv = -Dc/2, -Ec/2; R2 = (Dc**2+Ec**2)/4 - Fc
    # (u,v) = ((X+Y)/sqrt2, (X-Y)/sqrt2)  => uv = (X^2-Y^2)/2
    s2 = mp.sqrt(2)
    cX, cY = (cu+cv)/s2, (cu-cv)/s2
    # invert circle |Z-C|^2=R2 in unit circle: image circle center C/(|C|^2-R2), radius sqrt(R2)/||C|^2-R2|
    C2 = cX**2+cY**2
    den = C2 - R2
    # intersect the inverted circle (or line, if the circle passes through O) with L,
    # using the rational parametrization x = tt(1+tt^2)/(1+tt^4), y = tt(1-tt^2)/(1+tt^4)
    pts = []
    if abs(den) > mp.mpf('1e-30'):
        icX, icY, iR = cX/den, cY/den, mp.sqrt(R2)/abs(den)
        g = lambda tt: (tt*(1+tt**2)/(1+tt**4)-icX)**2 + (tt*(1-tt**2)/(1+tt**4)-icY)**2 - iR**2
    else:
        # circle through O: |Z|^2 = 2Re(Z conj C)  ->  image line 2(cX x + cY y) = 1
        g = lambda tt: 2*(cX*tt*(1+tt**2)/(1+tt**4) + cY*tt*(1-tt**2)/(1+tt**4)) - 1
    grid = [mp.mpf(k)/50 for k in range(-1000, 1001)]
    for k in range(len(grid)-1):
        if g(grid[k])*g(grid[k+1]) < 0:
            r = mp.findroot(g, (grid[k], grid[k+1]), solver='bisect' if False else 'anderson')
            pts.append(r)
    sols = []
    for tt in pts:
        px, py = tt*(1+tt**2)/(1+tt**4), tt*(1-tt**2)/(1+tt**4)
        onL = (px**2+py**2)**2 - (px**2-py**2)
        n2 = px**2+py**2
        PX, PY = px/n2, py/n2                                   # back to H
        uu = (PX+PY)/s2                                         # u-coordinate
        sols.append((uu/lam, onL))   # w = u/lam
    best = min(sols, key=lambda z: abs(z[0]-target))
    return best, sols
# 3a. cube root of 2: w^3-2 = 0; multiply by (w+1): w^4+w^3-2w-2 has constant -2<0 -> use (w-1):
# (w^3-2)(w-1) = w^4 - w^3 - 2w + 2  (constant 2>0)
(best, sols) = solve_via_lemniscate((-1, 0, -2, 2), mp.cbrt(2))
report('3a. 2^(1/3) obtained from drawn lemniscate (error %s, |on-L residual| %s)' % (mp.nstr(abs(best[0]-mp.cbrt(2)),3), mp.nstr(abs(best[1]),3)), abs(best[0]-mp.cbrt(2)) < mp.mpf('1e-40') and abs(best[1]) < mp.mpf('1e-40'))
# 3b. trisection: cos(20deg) root of 8w^3-6w-1=0 -> w^3 - (3/4)w - 1/8; times (w-1): constant 1/8 >0
# (w^3-0.75w-0.125)(w-1) = w^4 - w^3 - 0.75w^2 + 0.625w + 0.125
(best, sols) = solve_via_lemniscate(('-1', '-0.75', '0.625', '0.125'), mp.cos(mp.pi/9))
report('3b. cos(pi/9) obtained from drawn lemniscate (error %s)' % mp.nstr(abs(best[0]-mp.cos(mp.pi/9)),3), abs(best[0]-mp.cos(mp.pi/9)) < mp.mpf('1e-40') and abs(best[1]) < mp.mpf('1e-40'))

# 4. arithmetic criterion
def phi_gauss(n):
    res = 1
    for p, e in sp.factorint(n).items():
        if p == 2:
            res *= 2**(2*e-1)
        elif p % 4 == 1:
            res *= p**(2*(e-1))*(p-1)**2
        else:
            res *= p**(2*(e-1))*(p*p-1)
    return res
def smooth3(m):
    while m % 2 == 0: m //= 2
    while m % 3 == 0: m //= 3
    return m == 1
def pierpont(p):
    return sp.isprime(p) and smooth3(p-1)
def cs_form(n):
    for p, e in sp.factorint(n).items():
        if p in (2, 3): continue
        if e > 1: return False
        if not (pierpont(p) and (p == 7 or p % 4 == 1)): return False
    return True
bad = [n for n in range(1, 20001) if smooth3(phi_gauss(n)) != cs_form(n)]
report('4. |(Z[i]/n)^*| 3-smooth <=> Cox-Shurman form, n<=20000', bad == [])
print('   n<=100 admissible (drawn lemniscate):', [n for n in range(1, 101) if cs_form(n)])
print('   n<=100 admissible but not by ruler/compass alone (Abel):', [n for n in range(1, 101) if cs_form(n) and not all((p == 2) or (sp.isprime(p) and (p-1) & (p-2) == 0 and e == 1) for p, e in sp.factorint(n).items())])

# 5. Galois-degree check
mp.mp.dps = 120
varpi = 2*mp.quad(lambda s: 1/mp.sqrt(1-s**4), [0, 1])
def sl(uu):
    # lemniscatic sine via Jacobi: sl(u) = sd(sqrt2 u | m=1/2)/sqrt2
    return mp.ellipfun('sd', mp.sqrt(2)*uu, m=mp.mpf(1)/2)/mp.sqrt(2)
report('5a. sl(varpi/2) = 1', abs(sl(varpi/2) - 1) < mp.mpf('1e-40'))
K = pari.nfinit('t^2+1')
Ecurve = pari.ellinit([-1, 0])
allok = True
for n in [3, 5, 7, 9, 11, 13]:
    psi = pari.elldivpol(Ecurve, n)
    X0 = 1/sl(2*varpi/n)**2
    fac = pari.nffactor(K, psi)
    degs = []
    deg_through = None
    bestv = None
    for i in range(int(pari.matsize(fac)[0])):
        fpol = fac[i, 0]
        d = int(pari.poldegree(fpol))
        degs.append(d)
        # evaluate factor at X0 (coefficients are polmods in t, t = i); relative residual
        coeffs = [pari.lift(pari.polcoef(fpol, j)) for j in range(d+1)]
        cc = []
        for cj in coeffs:
            re_ = pari.polcoef(cj, 0, 't'); im_ = pari.polcoef(cj, 1, 't')
            cc.append(mp.mpf(int(pari.numerator(re_)))/int(pari.denominator(re_)) + 1j*mp.mpf(int(pari.numerator(im_)))/int(pari.denominator(im_)))
        val = abs(sum(cj*X0**j for j, cj in enumerate(cc)))/sum(abs(cj)*abs(X0)**j for j, cj in enumerate(cc))
        if bestv is None or val < bestv[0]:
            bestv = (val, d)
    if bestv[0] < mp.mpf('1e-60'):
        deg_through = bestv[1]
    pred = phi_gauss(n)//2
    print('   n=%d: factor degrees over Q(i) %s ; degree through wp(2varpi/n) = %s ; |(Z[i]/n)^*|/2 = %d' % (n, sorted(degs), deg_through, pred))
    allok = allok and (deg_through == pred)
report('5b. degree of the lemniscate division value over Q(i) = |(Z[i]/n)^*|/2 (n=3..13 odd)', allok)
print('ALL CHECKS PASSED' if ok_all else 'SOME CHECK FAILED')
