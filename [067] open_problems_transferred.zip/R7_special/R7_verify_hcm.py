r"""R7 verification script for the HCM / GGC classification results.

(A) Jedidi-Simon (Bernoulli 19 (2013), Remark 4.1(b)): is HM cap GGC = HCM ?
    Counterexample X = E1 + E2/2: density 2(e^{-x}-e^{-2x}).
(B) Bosch (Probab. Math. Statist. 35 (2015), Remark 1(a) Conjecture, and 1(b) belief):
    sqrt(G_t G_s) HCM for all s,t>0;  (G_t1...G_tn)^(1/n) HCM for all t_i>0.
    Claim: sqrt(G_t G_s) is HCM iff |t-s| <= 1/2 (sufficiency: Bosch).
(C) Bosch-Simon (Ark. Mat. 54 (2016)): "We believe that [a+b>=c] is necessary" for
    G_c x B_{a,b} to have an HCM density.  Claim: HCM iff c <= a+b.
Key lemma (proved in section.tex): if f>0 is HCM and analytic on C\(-inf,0], then
f has no zeros there and psi(z) = -z f'(z)/f(z) satisfies Im psi >= 0 for Im z > 0.

Each check prints PASS/FAIL.  Run: python3 -I R7_verify_hcm.py
"""
import mpmath as mp
import sympy as sp
ok_all = True
def report(name, cond):
    global ok_all
    print(('PASS ' if cond else 'FAIL ') + name); ok_all = ok_all and bool(cond)
mp.mp.dps = 40

# ---------------- generic tools ----------------
def H(f, u, w):
    s = mp.sqrt(w*w - 4); v = (w + s)/2
    return f(u*v)*f(u/v)
def taylor_coeffs(F, w0, r, N=512, M=40):
    pts = [w0 + r*mp.e**(2j*mp.pi*k/N) for k in range(N)]
    vals = [F(p) for p in pts]
    return [sum(vals[k]*mp.e**(-2j*mp.pi*k*m/N) for k in range(N))/N/r**m for m in range(M)]
def first_cm_violation(F, w0, r, M=40):
    cs = taylor_coeffs(F, w0, r, M=M)
    for m, cm in enumerate(cs):
        if mp.re(cm)*(-1)**m < -abs(cs[0])*mp.mpf(10)**(-20):
            return m, mp.re(cm)
    return None

# ================= (A) Jedidi-Simon =================
x = sp.symbols('x', positive=True)
fA = sp.exp(-x) - sp.exp(-2*x)
s_ = sp.symbols('s', positive=True)
LT = sp.simplify(sp.integrate(2*fA*sp.exp(-s_*x), (x, 0, sp.oo)))
report('A1. density 2(e^-x - e^-2x) has LT 1/((1+s)(1+s/2)) [GGC: Thorin measure delta_1+delta_2]',
       sp.simplify(LT - 1/((1+s_)*(1+s_/2))) == 0)
g = sp.simplify(x*sp.diff(fA, x)/fA)
report('A2. x f\'/f = x/(e^x-1) - x', sp.simplify(g - (x/(sp.exp(x)-1) - x)) == 0)
gp = sp.diff(x/(sp.exp(x)-1), x)
# numerator of derivative of x/(e^x-1): (e^x-1-x e^x) <0 for x>0
num = sp.simplify(sp.numer(sp.together(gp)))
vals = [num.subs(x, sp.Rational(k, 7)).evalf() for k in range(1, 200)]
report('A3. d/dx[x/(e^x-1)] < 0 on grid (HM: log f(e^y) concave)', all(v < 0 for v in vals))
fAn = lambda z: mp.e**(-z) - mp.e**(-2*z)
report('A4. f(2 pi i) = 0, so H_{2pi}(0) = |f(2 pi i)|^2 = 0', abs(H(fAn, 2*mp.pi, mp.mpf(0))) < mp.mpf('1e-35'))
viol = first_cm_violation(lambda w: H(fAn, 2*mp.pi, w), mp.mpf('2.2'), mp.mpf('1.5'))
print('   H_{2pi}: first Taylor coefficient at w0=2.2 with wrong CM sign:', viol)
report('A5. H_{2pi} is not CM (explicit wrong-sign Taylor coefficient)', viol is not None)

# ================= (B) Bosch: sqrt(G_t G_s) =================
def fB(t, s):
    nu = t - s
    return lambda z: z**(t+s-1)*mp.besselk(nu, 2*z)
# B1 density check by Mellin moments
okm = True
for (t, s) in [(3, mp.mpf('0.5')), (1, 2), (mp.mpf('0.7'), mp.mpf('2.9'))]:
    C = 4/(mp.gamma(t)*mp.gamma(s))
    for q in [mp.mpf('0.4'), mp.mpf('1.3'), 3]:
        lhs = mp.quad(lambda z: z**q*C*fB(t, s)(z), [0, 1, mp.inf])
        rhs = mp.gamma(t+q/2)*mp.gamma(s+q/2)/(mp.gamma(t)*mp.gamma(s))
        okm = okm and abs(lhs/rhs - 1) < mp.mpf('1e-25')
report('B1. density of sqrt(G_t G_s) is 4/(Gamma(t)Gamma(s)) x^(t+s-1) K_(t-s)(2x) (Mellin moments)', okm)
# B2 elementary example (t,s)=(3,1/2)
fE = lambda z: mp.e**(-2*z)*(4*z**2+6*z+3)/4
okE = all(abs(fE(z)*mp.sqrt(mp.pi)/2 - (mp.mpf(2)/mp.sqrt(mp.pi))*z**mp.mpf('2.5')*mp.besselk(mp.mpf('2.5'), 2*z)*mp.sqrt(mp.pi)/2) < mp.mpf('1e-30') for z in [mp.mpf('0.3'), 1, mp.mpf('2.7')])
report('B2a. sqrt(G_3 G_1/2) has density (4x^2+6x+3)e^(-2x)/4', okE)
z0 = (-3 + 1j*mp.sqrt(3))/4
u0 = abs(z0); w0 = 2*mp.cos(mp.arg(z0))
report('B2b. zero z0=(-3+i sqrt3)/4 = u e^{i 5pi/6}, u=sqrt3/2, H_u(-sqrt3)=0', abs(fE(z0)) < mp.mpf('1e-35') and abs(H(fE, u0, w0)) < mp.mpf('1e-35') and abs(w0 + mp.sqrt(3)) < mp.mpf('1e-35'))
viol = first_cm_violation(lambda w: H(fE, u0, w), mp.mpf('2.2'), mp.mpf('1.5'))
print('   H_u for (3,1/2): first wrong-sign Taylor coefficient at w0=2.2:', viol)
report('B2c. H_{sqrt3/2} not CM for (t,s)=(3,1/2)', viol is not None)
# B3 Pick test: Im R_nu(zeta) with R = zeta K_{nu-1}/K_nu
def R(nu, zeta):
    return zeta*mp.besselk(nu-1, zeta)/mp.besselk(nu, zeta)
pts_ok = True; pts_bad = True
for nu in [mp.mpf('0.1'), mp.mpf('0.3'), mp.mpf('0.5')]:
    for r in [mp.mpf('1e-4'), mp.mpf('0.01'), mp.mpf('0.3'), 1, 3, 10]:
        for k in range(1, 60):
            th = mp.pi*k/60
            if mp.im(R(nu, r*mp.e**(1j*th))) < -mp.mpf('1e-30'):
                pts_ok = False
report('B3a. nu<=1/2: Im R_nu >= 0 on grid (consistent with Bosch\'s sufficiency)', pts_ok)
bad_list = []
for nu in [mp.mpf('0.51'), mp.mpf('0.6'), mp.mpf('0.75'), 1, mp.mpf('1.25'), mp.mpf('1.5'), 2, mp.mpf('3.3')]:
    # asymptotic point: zeta = r e^{i theta} with theta chosen as in the proof
    if nu < 1:
        th = (mp.pi/(2*nu) + mp.pi)/2
        r = mp.mpf('1e-6')
    else:
        th = 7*mp.pi/8
        r = mp.mpf('1e-3')
    val = mp.im(R(nu, r*mp.e**(1j*th)))
    bad_list.append((mp.nstr(nu, 3), mp.nstr(val, 4)))
    pts_bad = pts_bad and val < 0
print('   Im R_nu at proof points:', bad_list)
report('B3b. nu>1/2: Im R_nu(zeta) < 0 at the points predicted by the asymptotics', pts_bad)
# B3c asymptotic constants
ac = True
for nu in [mp.mpf('0.6'), mp.mpf('0.8')]:
    zt = mp.mpf('1e-8')*mp.e**(2j)
    pred = 2*mp.gamma(1-nu)/mp.gamma(nu)*(zt/2)**(2*nu)
    ac = ac and abs(R(nu, zt)/pred - 1) < mp.mpf('1e-3')
for nu in [mp.mpf('1.3'), 2, 3]:
    zt = mp.mpf('1e-8')*mp.e**(2j)
    pred = zt**2/(2*(nu-1))
    ac = ac and abs(R(nu, zt)/pred - 1) < mp.mpf('1e-3')
zt = mp.mpf('1e-8')*mp.e**(2.5j)
ac = ac and abs(R(1, zt)/(zt**2*(-mp.log(zt/2) - mp.euler)) - 1) < mp.mpf('1e-3')
report('B3c. small-zeta asymptotics of R_nu used in the proof', ac)
# B4 direct non-CM evidence for nu=1 (t,s)=(1,2)
f12 = fB(1, 2)
d2 = mp.diff(lambda w: H(f12, mp.mpf('0.02'), w), mp.mpf('2.6'), 2)
print('   (t,s)=(1,2), u=0.02: H_u\'\'(2.6) =', mp.nstr(d2, 6))
report('B4. sqrt(G_1 G_2): H_u fails convexity (so fails CM) at u=0.02, w=2.6', d2 < 0)
# B5 n-fold examples n=2,3,4: density x^{nt} e^{-nx} (x^2+3(n-1)x/n+(n-1)(2n-1)/n^2)
okn = True
for n in [2, 3, 4]:
    t = mp.mpf('0.5')
    ts = [t + 3] + [t + mp.mpf(j)/n for j in range(1, n)]
    qc = [mp.mpf((n-1)*(2*n-1))/n**2, mp.mpf(3*(n-1))/n, 1]      # Q_n coefficients (x^0,x^1,x^2)
    # exact Mellin moments of x^{nt} e^{-nx} Q_n(x):  int x^{q+nt+k} e^{-nx} dx = Gamma(q+nt+k+1)/n^{q+nt+k+1}
    mom = lambda q: sum(qc[k]*mp.gamma(q+n*t+k+1)/mp.mpf(n)**(q+n*t+k+1) for k in range(3))
    Z = mom(0)
    for q in [mp.mpf('0.5'), mp.mpf(2), mp.mpf('3.3')]:   # mpf (not int) to avoid float division q/n
        lhs = mom(q)/Z
        rhs = 1
        for tj in ts:
            rhs *= mp.gamma(tj + q/n)/mp.gamma(tj)
        okn = okn and abs(lhs/rhs - 1) < mp.mpf('1e-25')
    disc = mp.mpf((n-1)*(n-5))/n**2
    okn = okn and disc < 0
report('B5. n=2,3,4: (G_{t+3} G_{t+1/n}...G_{t+(n-1)/n})^(1/n) has density x^{nt}e^{-nx}Q_n(x), Q_n with nonreal zeros', okn)
# B6 general n asymptotic Pick violation: t1=1, tj = 1+(j+1)/(2n) (j=2..n); density via the
# residue (Meijer-G) series f_Y(x) = n/prod Gamma(ti) * sum_j sum_k (-1)^k/k! prod_{i!=j} Gamma(ti-tj-k) x^{n(tj+k)-1}
def series_coeffs(ts, n, K=40):
    pref = n/mp.fprod([mp.gamma(ti) for ti in ts])
    out = []
    for j, tj in enumerate(ts):
        for k in range(K):
            cf = pref*(-1)**k/mp.factorial(k)*mp.fprod([mp.gamma(ti - tj - k) for i, ti in enumerate(ts) if i != j])
            out.append((n*(tj+k)-1, cf))
    return out
def dens_from(coeffs, z):
    return sum(cf*z**ex for ex, cf in coeffs)
mp.mp.dps = 80
okB6 = True; rep = []
for n in [2, 3, 5, 6, 9, 12]:
    ts = [mp.mpf(1)] + [1 + mp.mpf(j+1)/(2*n) for j in range(2, n+1)]
    co = series_coeffs(ts, n)
    # cross-check the series against mpmath's Meijer G at a few real points
    agree = True
    for z in [mp.mpf('0.4'), mp.mpf('0.9')]:
        try:
            g = n*z**(n-1)*mp.meijerg([[], []], [[tj-1 for tj in ts], []], z**n)/mp.fprod([mp.gamma(tj) for tj in ts])
            agree = agree and abs(dens_from(co, z)/g - 1) < mp.mpf('1e-20')
        except Exception:
            pass
    th = mp.mpf('0.9')*mp.pi; rr = mp.mpf('1e-6')        # asymptotic regime (proof: 'for small rho')
    zz = rr*mp.e**(1j*th)
    f0 = dens_from(co, zz)
    fp = sum(cf*ex*zz**(ex-1) for ex, cf in co)
    psi = -zz*fp/f0
    c1 = mp.fprod([mp.gamma(ti - ts[0]) for ti in ts[1:]])
    c2 = mp.fprod([mp.gamma(ti - ts[1]) for i, ti in enumerate(ts) if i != 1])
    lead = mp.mpf(3)/2*abs(c2/c1)*rr**mp.mpf('1.5')*mp.sin(3*th/2)
    rep.append((n, agree, mp.nstr(mp.im(psi), 5), mp.nstr(mp.im(psi)/lead, 5), mp.nstr(c2/c1, 5)))
    okB6 = okB6 and agree and mp.im(psi) < 0 and c2/c1 < 0 and abs(mp.im(psi)/lead - 1) < mp.mpf('0.05')
print('   (n, series agrees with Meijer G, Im psi at 1e-6 e^{0.9 i pi}, ratio to leading term, c2/c1):', rep)
report('B6. general n: (prod G_tj)^(1/n) with t1=1, tj=1+(j+1)/(2n) violates the Pick condition', okB6)
mp.mp.dps = 40

# ================= (C) Bosch-Simon: G_c x B_{a,b} =================
def fC(a, b, c):
    al = c - a - b; de = c - a
    C = mp.gamma(a+b)/(mp.gamma(a)*mp.gamma(c))
    return lambda z: C*z**(a-1)*mp.e**(-z)*mp.hyperu(-al, 1-de, z)
okC = True
for (a, b, c) in [(mp.mpf('0.7'), mp.mpf('0.4'), mp.mpf('1.6')), (2, mp.mpf('0.5'), mp.mpf('4.3')), (mp.mpf('1.5'), 1, 2)]:
    f = fC(a, b, c)
    for q in [mp.mpf('0.5'), 2]:
        lhs = mp.quad(lambda z: z**q*f(z), [0, 1, mp.inf])
        rhs = mp.gamma(c+q)*mp.gamma(a+q)*mp.gamma(a+b)/(mp.gamma(c)*mp.gamma(a)*mp.gamma(a+b+q))
        okC = okC and abs(lhs/rhs - 1) < mp.mpf('1e-15')
report('C1. density of G_c x B_{a,b} is Gamma(a+b)/(Gamma(a)Gamma(c)) x^{a-1}e^{-x}U(a+b-c,1+a-c,x)', okC)
# C2 argument-principle bookkeeping on the cut for c>a+b.  If f were HCM, U would have no
# zero in the upper half-plane (Lemma, part 1) and arg U(-x+i0) would be nonincreasing (part 2);
# the argument principle gives  Delta := arg W(R)-arg W(eps) = alpha*pi - 2*pi*N_+, N_+ = #zeros
# of U in the upper half-plane.  So either N_+ >= 1 (a zero of f in Omega) or arg W increases.
def argW_change(a, b, c, X=mp.mpf(60), eps=mp.mpf('1e-6'), N=6000):
    al = c - a - b; de = c - a
    U = lambda z: mp.hyperu(-al, 1-de, z)
    xs = [eps*(X/eps)**(mp.mpf(k)/N) for k in range(N+1)]
    tot = 0; prev = mp.arg(U(-xs[0] + 1j*mp.mpf('1e-30')))
    incr = False
    for xx in xs[1:]:
        cur = mp.arg(U(-xx + 1j*mp.mpf('1e-30')))
        dlt = cur - prev
        while dlt > mp.pi: dlt -= 2*mp.pi
        while dlt < -mp.pi: dlt += 2*mp.pi
        if dlt > mp.mpf('1e-12'): incr = True
        tot += dlt; prev = cur
    return tot, incr
def find_upper_zero(a, b, c):
    al = c - a - b; de = c - a
    U = lambda z: mp.hyperu(-al, 1-de, z)
    for r0 in [0.5, 1, 2, 3, 5]:
        for th in [1.8, 2.2, 2.6, 2.9]:
            try:
                z = mp.findroot(U, mp.mpc(r0*mp.cos(th), r0*mp.sin(th)))
                if mp.im(z) > mp.mpf('1e-6') and abs(U(z)) < mp.mpf('1e-15'):
                    return z
            except Exception:
                pass
    return None
mp.mp.dps = 25
res = []
okC2 = True
for (a, b, c) in [(mp.mpf('0.7'), mp.mpf('0.4'), mp.mpf('1.6')), (2, mp.mpf('0.5'), mp.mpf('4.3')), (1, mp.mpf('0.3'), mp.mpf('1.8')), (mp.mpf('0.5'), mp.mpf('0.5'), mp.mpf('3.7'))]:
    tot, incr = argW_change(a, b, c)
    al = c - a - b
    Nplus = (al - tot/mp.pi)/2
    Nint = int(mp.nint(Nplus))
    z0 = find_upper_zero(a, b, c) if Nint >= 1 else None
    ok = abs(Nplus - Nint) < mp.mpf('1e-3') and Nint >= 0 and ((Nint == 0 and incr) or (Nint >= 1 and z0 is not None))
    res.append((mp.nstr(al, 3), mp.nstr(tot/mp.pi, 6), 'N+=%d' % Nint, 'arg increases' if incr else 'no increase', None if z0 is None else mp.nstr(z0, 8)))
    okC2 = okC2 and ok
print('   (alpha, Delta/pi, zeros of U in upper half-plane, monotonicity, a located zero):', res)
report('C2. c>a+b: either U has a zero in the upper half-plane or arg U(-x+i0) increases (both exclude HCM)', okC2)
# C3 consistency: c<=a+b gives Im psi >= 0 on grid
okC3 = True
for (a, b, c) in [(mp.mpf('0.7'), mp.mpf('0.9'), mp.mpf('1.2')), (2, 1, 3), (mp.mpf('1.5'), 2, mp.mpf('3.4'))]:
    f = fC(a, b, c)
    for r in [mp.mpf('0.01'), mp.mpf('0.3'), 1, 4]:
        for k in range(1, 30):
            zz = r*mp.e**(1j*mp.pi*k/30)
            psi = -zz*mp.diff(f, zz)/f(zz)
            if mp.im(psi) < -mp.mpf('1e-12'):
                okC3 = False
report('C3. c<=a+b: Im psi >= 0 on grid (consistent with Bosch-Simon sufficiency)', okC3)
# C4 explicit alpha=1 example: f ~ x^{a-1}(x+b)e^{-x}, Im psi(-b+i eps)<0
a, b = mp.mpf('0.8'), mp.mpf('0.6')
f = lambda z: z**(a-1)*(z+b)*mp.e**(-z)
zz = -b + 1j*mp.mpf('0.1')
psi = -zz*mp.diff(f, zz)/f(zz)
report('C4. c=a+b+1: density x^{a-1}(x+b)e^{-x}; Im psi(-b+0.1i) = %s < 0' % mp.nstr(mp.im(psi), 5), mp.im(psi) < 0)

print('ALL CHECKS PASSED' if ok_all else 'SOME CHECK FAILED')
