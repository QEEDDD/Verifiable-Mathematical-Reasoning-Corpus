r"""R7: computational evidence (NOT a proof) for Lorch-Muldoon (1995), Section 2.3 (b),(c).

For f = x^{-nu} J_nu, c = 2 nu + 1, the n-th derivative is f^(n) = x^{-n}(A_n f + x B_n f')
(recurrence of manuscript K-047 of the series with d = 0).  r_n = Res_x(A_n, B_n) is monic of degree n(n-1)
in c (manuscript K-047 of the series), so its rational roots are integers c, i.e. nu in (1/2)Z.
Conjecture (c) of Lorch-Muldoon: the rational roots in nu are -m/2 (m=1..n-1), plus 0 for n=4
and 1 for n=5.  This script computes Res_x(A_n,B_n) exactly with PARI for n <= NMAX and lists
its rational roots.  It checks the conjecture for these n only.
Run: python3 -I R7_verify_lorch_muldoon.py
"""
import cypari2, sys
pari = cypari2.Pari(); pari.allocatemem(4*10**9)
NMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 24
pari('A=vector(80); B=vector(80); A[1]=0; B[1]=1;')
pari('for(n=1,79, A[n+1]=x*deriv(A[n],x)-n*A[n]-x^2*B[n]; B[n+1]=A[n]+x*deriv(B[n],x)+(1-c-n)*B[n]);')
allok = True
for n in range(2, NMAX+1):
    R = pari(f'polresultant(A[{n}], B[{n}], x)')
    deg = int(pari.poldegree(R, 'c')); lc = pari.pollead(R, 'c')
    roots = sorted(set(int(r) for r in pari.nfroots(pari('y'), pari.subst(R, 'c', 'y'))) if False else [int(r) for r in pari(f'my(F=factor(polresultant(A[{n}],B[{n}],x))); v=[]; for(i=1,#F~, if(poldegree(F[i,1],c)==1, v=concat(v, -polcoef(F[i,1],0,c)/polcoef(F[i,1],1,c)))); v')])
    nus = sorted(set((r - 1)/2 for r in roots))
    expected = sorted(set([-m/2 for m in range(1, n)] + ([0.0] if n == 4 else []) + ([1.0] if n == 5 else [])))
    ok = (deg == n*(n-1)) and (lc == 1) and (nus == expected)
    allok = allok and ok
    print(('PASS' if ok else 'FAIL'), 'n=%d: deg_c r_n = %d, monic=%s, rational roots nu = %s' % (n, deg, lc == 1, nus)); sys.stdout.flush()
print('ALL CHECKS PASSED (n <= %d only; no claim for larger n)' % NMAX if allok else 'SOME CHECK FAILED')
