"""R7 verification script for the tricuspoid (deltoid) division-point classification.

Target: Mani & Rubinstein-Salzedo, "N-division points of hypocycloids",
Arnold Math. J. 1 (2015), Remark 5.7 (= arXiv:1503.00566, Remark 4.3):
  "It appears that no n-division points other than those contained among the
   6-division points are constructible ... except in the cases already
   discussed, f_r(x) is indeed irreducible, and further, that the field Q(alpha)
   obtained by adjoining a root of f_r(x) is totally ramified at 3."

Checks performed (each prints PASS/FAIL):
 1. speed^2 = 16 sin^2(3 phi/2) for x=2cos(phi)+cos(2phi), y=2sin(phi)-sin(2phi).
 2. Our x-coordinate cubic reproduces the printed cubic f_n(x) of the paper (rho=1/n).
 3. Counterexample: the point at arc fraction 9/32 has coordinates
    ((39-45 sqrt5)/64, y) with y^2 in Q(sqrt5); f_{32/9} is reducible;
    high-precision numerical integration of the arc length confirms the fraction.
 4. Independent constructibility test: for every n<=N and 0<=k<n the point
    P(k/n) is classified by (a) our rational-root criterion and (b) the order of
    the Galois group of the minimal polynomial of z=x+iy over Q (2-power <=> constructible),
    and the two must agree.
 5. Theorem 5.1 of the paper (all n-division points constructible iff n|6) is re-derived
    for n<=N2 from the criterion.
 6. The 3-adic ramification speculation is tested on irreducible cases.
Run with: python3 -I R7_verify_tricuspoid.py
"""
import sympy as sp
import mpmath as mp
from fractions import Fraction as Fr
import cypari2
pari = cypari2.Pari()
pari.allocatemem(4*10**8)

ok_all = True
def report(name, cond):
    global ok_all
    print(('PASS ' if cond else 'FAIL ') + name)
    ok_all = ok_all and bool(cond)

# ---------- 1. arc length ----------
phi = sp.symbols('phi', real=True)
xs = 2*sp.cos(phi) + sp.cos(2*phi); ys = 2*sp.sin(phi) - sp.sin(2*phi)
sp2 = sp.diff(xs, phi)**2 + sp.diff(ys, phi)**2
report('1. speed^2 == 16 sin^2(3phi/2)', sp.simplify(sp.trigsimp(sp2 - 16*sp.sin(3*phi/2)**2)) == 0)

# ---------- 2. printed cubic ----------
c, x, n, t0 = sp.symbols('c x n t0')
x_of_c = sp.expand(2*(2*c**2 - 1) + (8*c**4 - 8*c**2 + 1))      # x = 2cos(2th)+cos(4th), c=cos(th)
F = sp.expand(sp.resultant(4*c**3 - 3*c - t0, x - x_of_c, c) / 64)
print('   general x-cubic F(x;t0) =', sp.factor(F))
f_ours = sp.expand(F.subs(t0, 1 - sp.Integer(6)/n) * n**4)
f_printed = 4*n**4*x**3 - (27*n**4 - 288*n**3 + 864*n**2)*x - (27*n**4 - 432*n**3 + 2448*n**2 - 6912*n + 10368)
report('2. our cubic (rho=1/n) equals the printed f_n(x) of the paper', sp.expand(f_ours - f_printed) == 0)

# ---------- 3. the counterexample rho = 9/32 ----------
rho = sp.Rational(9, 32)
tt = 1 - 6*rho                      # = -11/16
report('3a. t0 = T_3(1/4) = -11/16', tt == 4*sp.Rational(1, 4)**3 - 3*sp.Rational(1, 4) and tt == sp.Rational(-11, 16))
cubic_c = sp.Poly(4*c**3 - 3*c - tt, c)
print('   trisection cubic factors as', sp.factor(cubic_c.as_expr()))
cth = (3*sp.sqrt(5) - 1)/8          # the root in [1/2,1] = cos(theta), theta in [0,pi/3]
report('3b. cos(theta)=(3sqrt5-1)/8 is a root lying in [1/2,1]', sp.simplify(cubic_c.as_expr().subs(c, cth)) == 0 and sp.Rational(1, 2) <= cth.evalf() <= 1)
xP = sp.nsimplify(sp.expand(x_of_c.subs(c, cth)))
sth = sp.sqrt(1 - cth**2)
yP = sp.simplify(8*sth**3*cth)      # y = 2 sin2th - sin4th = 8 s^3 c
print('   P = (', xP, ',', sp.nsimplify(yP), ')   y^2 =', sp.nsimplify(sp.expand(yP**2)))
report('3c. x(P) = (39-45 sqrt5)/64', sp.simplify(xP - (39 - 45*sp.sqrt(5))/64) == 0)
Fr_ = sp.factor(F.subs(t0, tt))
print('   f_{32/9}(x) ~', Fr_)
report('3d. f_{32/9} is reducible over Q (has rational root -39/32)', sp.simplify(F.subs({t0: tt, x: sp.Rational(-39, 32)})) == 0)
# numerical arc-length check
mp.mp.dps = 50
theta0 = mp.acos((3*mp.sqrt(5) - 1)/8)
phi0 = 2*theta0
L = mp.quad(lambda u: mp.sqrt((-2*mp.sin(u) - 2*mp.sin(2*u))**2 + (2*mp.cos(u) - 2*mp.cos(2*u))**2), [0, phi0])
print('   numerical arc length from cusp (3,0):', mp.nstr(L, 40), ' expected 16*9/32 = 4.5')
report('3e. numerical arc length equals 4.5 to 1e-40', abs(L - mp.mpf('4.5')) < mp.mpf('1e-40'))
Xn = 2*mp.cos(phi0) + mp.cos(2*phi0); Yn = 2*mp.sin(phi0) - mp.sin(2*phi0)
report('3f. numerical coordinates match closed forms', abs(Xn - (39 - 45*mp.sqrt(5))/64) < mp.mpf('1e-40') and abs(Yn - mp.mpf(sp.N(yP, 60))) < mp.mpf('1e-40'))

# ---------- 4. classification cross-check ----------
def T3_has_rational_root(tq):
    """Does 4X^3-3X-tq have a rational root? (rational-root test on cleared polynomial)"""
    P = sp.Poly(4*sp.Symbol('X')**3 - 3*sp.Symbol('X') - tq, sp.Symbol('X'))
    return any(r.is_rational for r in sp.roots(P, filter=None, multiple=True) if r.is_real) if False else bool([f for f, m in sp.factor_list(P.as_expr())[1] if sp.Poly(f, sp.Symbol('X')).degree() == 1])

def criterion(r):
    """our theorem: P(r) constructible iff 4X^3-3X-(1-6 rho) has a rational root, rho = r mod 1/3"""
    rho = r - sp.floor(3*r)/3
    return T3_has_rational_root(1 - 6*rho)

def galois_test(r):
    """independent test: z = x+iy = 2e^{i phi}+e^{-2 i phi}, P(r) constructible iff the Galois
    group of the minimal polynomial of z over Q has 2-power order."""
    rho = r - sp.floor(3*r)/3
    tq = 1 - 6*rho
    # w = e^{i theta}, w^6 - 2 tq w^3 + 1 = 0, phi = 2 theta, z = 2 w^2 + w^-4; then rotate by j*2pi/3
    j = int(sp.floor(3*r))
    W, Z = sp.symbols('W Z')
    # rotation by e^{2 pi i j/3}: z_j = zeta^j z, zeta^3=1 -> use resultant with zeta polynomial
    zeta = sp.Symbol('zeta')
    rel = sp.resultant(sp.Poly(W**6 - 2*tq*W**3 + 1, W).as_expr(), sp.expand(Z*W**4 - (2*W**6 + 1)*(zeta**j)), W)
    if j > 0:
        rel = sp.resultant(rel, zeta**2 + zeta + 1, zeta)
    else:
        rel = rel.subs(zeta, 1)
    # pick the irreducible factor vanishing at the actual point
    th = mp.acos(mp.mpf(sp.N(tq, 50)))/3
    zt = (2*mp.e**(2j*th) + mp.e**(-4j*th))*mp.e**(2j*mp.pi*j/3)
    best = None
    for f, m in sp.factor_list(sp.expand(rel))[1]:
        val = complex(sp.Poly(f, Z).eval(sp.Float(zt.real, 50) + sp.I*sp.Float(zt.imag, 50)))
        if best is None or abs(val) < best[0]:
            best = (abs(val), f)
    f = sp.Poly(best[1], Z)
    deg = f.degree()
    if deg == 1:
        return True, 1
    # PARI polgalois needs degree <= 7 (built-in up to 7)
    g = pari.polgalois(pari(str(f.as_expr()).replace('**', '^')))
    order = int(g[0])
    return (order & (order - 1)) == 0, order

N = 60
mism = 0; found = []
for nn in range(1, N + 1):
    for k in range(nn):
        r = sp.Rational(k, nn)
        a = criterion(r)
        b, order = galois_test(r)
        if a != b:
            mism += 1
            print('   MISMATCH at', r, a, b, order)
        if a and (6*r).q != 1 and sp.gcd(k, nn) == 1:
            found.append(r)
report('4. criterion agrees with Galois-group test for all k/n, n<=%d' % N, mism == 0)
print('   constructible non-6-division fractions (reduced) with denominator <=', N, ':', sorted(set(found)))

# ---------- 5. Theorem 5.1 re-derived ----------
# all n-division points constructible  <=>  n | 6.  "If": every k/n with n|6 has rho in {0,1/6}.
# "Only if": for n not dividing 6 the first point P(1/n) is not constructible.
import flint
def has_rational_root(tq):
    tq = sp.Rational(tq)
    P = flint.fmpq_poly([-flint.fmpq(int(tq.p), int(tq.q)), -3, 0, 4])
    c, facs = P.factor()
    return any(f.degree() == 1 for f, m in facs)
N2 = 2000
bad = [nn for nn in range(1, N2 + 1) if (6 % nn != 0) and has_rational_root(1 - 6*(sp.Rational(1, nn) - sp.floor(sp.Rational(3, nn))/3))]
good = all(criterion(sp.Rational(k, nn)) for nn in (1, 2, 3, 6) for k in range(nn))
report('5. all n-division points constructible iff n | 6 (first point fails for every n<=%d with n not dividing 6)' % N2, bad == [] and good)

# ---------- 6. ramification at 3 for irreducible f_r ----------
Xs = sp.Symbol('X')
counter = []
for nn in range(4, 40):
    for k in range(1, nn):
        r = sp.Rational(k, nn)
        if r > sp.Rational(1, 3) or (6*r).q == 1:
            continue
        tq = 1 - 6*r
        f = sp.Poly(sp.expand(F.subs({t0: tq})*sp.Integer(1)), x)
        fl = sp.factor_list(f.as_expr())[1]
        if len(fl) == 1 and sp.Poly(fl[0][0], x).degree() == 3:
            fp = pari(str(sp.Poly(fl[0][0], x).as_expr()).replace('**', '^'))
            fp = pari.polredabs(fp)
            K = pari.nfinit(fp)
            dec = pari.idealprimedec(K, 3)
            es = [int(pr[2]) for pr in dec]
            if es != [3]:
                counter.append((str(r), es))
print('   irreducible f_r (r = 1/rho, rho<=1/3, denominators<40) where 3 is NOT totally ramified:', counter[:8], '... total', len(counter))
# explicit case r = 28/9 (rho = 9/28, tau = -13/14)
tq = sp.Rational(-13, 14)
f2814 = sp.Poly(sp.expand(F.subs({t0: tq})*sp.Integer(1)), x)
irr = len(sp.factor_list(f2814.as_expr())[1]) == 1 and sp.Poly(sp.factor_list(f2814.as_expr())[1][0][0], x).degree() == 3
Kc = pari.nfinit(pari.polredabs(pari(str(sp.Poly(sp.factor_list(f2814.as_expr())[1][0][0], x).as_expr()).replace('**', '^'))))
dec = pari.idealprimedec(Kc, 3)
print('   r=28/9: f_r irreducible:', irr, '; primes above 3 (e,f):', [(int(pr[2]), int(pr[3])) for pr in dec])
report('6. irreducible f_r with 3 not totally ramified exist (e.g. r=28/9); refutes the ramification speculation', len(counter) > 0 and irr and [int(pr[2]) for pr in dec] != [3])

print('ALL CHECKS PASSED' if ok_all else 'SOME CHECK FAILED')
