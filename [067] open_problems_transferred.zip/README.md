# Supplementary material

Verification scripts, certificates and logs for the paper
"Problems from the literature settled by transferred methods" (Keio, 23 October 2026).

Run each script from inside its own folder with `python3 -I <script>` (several R1 scripts import
helper modules from the current directory). Each script prints the checks it performs and ends with
a PASS line or a summary. The `.log` and `.out` files are the outputs of the runs used for the paper.

Dependencies: Python 3.10+, mpmath, sympy, numpy, scipy, networkx, python-flint (0.9),
cypari2 (for some R7 scripts); Singular and msolve for the Floquet computations.

| Folder | Paper section | Main verification scripts | Further checks and exploration |
|---|---|---|---|
| `R1_orders` | 2 Rook walks | `rook_verify.py` (Lemmas on the Laguerre representation, integration by parts, reduction; asymptotics check), `rook_degrees_modp.py [dmax]` (constructive recurrence mod p), `rook_softproof.py` (soft proof of the guessed recurrences, d <= 7) | `rook_charpoly.py`, `explore_t1.py`, `explore_jordan.py`, `explore_sharp4b.py` |
| `R7_special` | 3 Division points, drawn curves, HCM | `R7_verify_tricuspoid.py`, `R7_verify_drawn_lemniscate.py`, `R7_verify_hcm.py`, `R7_verify_lorch_muldoon.py [nmax]` | logs `*.log` |
| `R5_mixtures` | 4 Mixtures | `R5_gompertz_check.py`, `R5_modes_check.py`, `R5_jackson_check.py` | `R5_wp_npmle_sim.py` (Monte Carlo), `R5_wp_kernel_check.py`, `R5_favard_proof_check.py` |
| `R2_cm` | 5 Polygamma Wronskians | `R2_verify_qa2019_degrees.py` (the exact Taylor certificates of the Taylor lemma); the proofs are otherwise by hand | `R2_verify_kernels.py`, `R2_verify_remark17.py`, `R2_verify_remark18.py`, `R2_verify_yhq_remark4.py`, `R2_verify_yhq_remark2.py`, `R2_verify_mia_partial.py` (consistency checks) |
| `R6_primes` | 6 Composite sequences | `verify_biquadratic.py`, `verify_siurys_certs.py [certdir]` (certificates in `siurys/certs`), `verify_siurys_fixed.py` (data `siurys/fixed_D120_0_119.json`), `verify_siurys_families.py [kmin kmax]`, `verify_siurys_closed_forms.py [kmax]` | search code in `siurys/` (not needed to check the certificates) |
| `R3_floquet` | 7 Floquet isospectrality | `R3_conj2_exact.py` (q = 5, 9), `R3_conj2_krawczyk.py q1,q2,...` (interval certificates, logs `R3_conj2_krawczyk*.log`), `R3_problem1_exact_branches.py Nmin Nmax` (Singular; logs `R3_problem1_exact_branches*.log`), `R3_structure_checks.py` | `R3_problem1_modp_branches.py` (mod-p evidence only), `independent_check_explicit.py`, `explore/` (search and cross-check code, e.g. `explore/branch2d_fast.py`, `explore/q5.ms` with msolve output `explore/q5.out`) |
| `R4_spectral` | 8 Spectral volumes | `q3_verify.py <certs.json> <n>` (independent verifier for the certificates `q3_certs_n*.json`), `R4_q4_small.py [depth]`, `R4_domino.py` | `q3_certify*.py` (certificate generators), `R4_checks.py`, `R4_regions_check.py`, `R4_q4_numerics.py` |

Notes.
- The Krawczyk certificates for Conjecture 2 of Faust et al. take minutes per period for q >= 29;
  `python3 -I R3_conj2_krawczyk.py 5,7,9` is a quick test.
- The exact planar branch computations call Singular through temporary input files; index 11 and 12
  take the longest.
- Results labelled "numerical" or "evidence" in the paper are not used in any proof.
