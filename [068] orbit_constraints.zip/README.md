# External applications: research record, 24 October 2026

이 묶음은 Erdős 급수/Okada 문제와 별개인 두 조합론 문제의 증명 및 검증 기록입니다.
두 증명 모두 유한 탐색에 의존하지 않습니다. 내부 독립 검토는 통과했으나 외부 심사 및 우선권 확정은 아직 이루어지지 않았습니다.

## Results

1. Karunanayaka's Catalan-bound tightness conjecture (2026): for every k >= 3, the minimum number of rows in a fully coordinate-permutation-invariant binary strength-two orthogonal array is 4*binom(k-2,floor((k-2)/2)). All equality cases are classified.
2. There is no circulant weighing matrix CW(195,81). The proof uses a hand-checkable contraction lemma, the established cyclotomic multiplier theorem, a nonprincipal kernel character, and an augmentation norm contradiction.

The two theorems are stated with their original hypotheses. Neither implies a general Hadamard or circulant Hadamard conjecture, or an unrestricted orthogonal-array existence theorem. The mathematical proofs are separate from literature-priority claims.

## Paper and verification

The `paper/` directory contains the complete PDF and standalone LaTeX source. Compile the latter with pdflatex twice. The source has no external image or input-file dependencies.

From the extracted archive's top directory, run:

```bash
python3 transfer_external/coding/independent_catalan_audit.py
python3 transfer_external/designs_code/cw195_audit_checks.py
python3 transfer_external/designs_code/contractions65.py
python3 transfer_external/designs_code/eisenstein65.py
```

These checks use Python's standard library. The two circulant enumeration scripts use paths relative to the archive's top directory; run the contraction script first.

Additional checks:

```bash
python3 transfer_external/coding/check_catalan.py --cp
python3 transfer_external/audit_catalan_independent.py
```

The `--cp` option requires OR-Tools; the second script requires SymPy. Without `--cp`, the first script runs its exact binomial and marginal checks with the standard library. Existing JSON files preserve the recorded results. Running a checker may replace its result JSON.

## Independent internal reviews

- `transfer_external/audit_catalan_independent.md`
- `transfer_external/catalan_independent_audit_general_shadow.md`
- `transfer_external/designs_code/cw195_independent_audit.md`

The circulant audit also supplies a direct proof of the specialized multiplier statement by character inversion. An optional LaTeX version is in `transfer_external/designs_multiplier_lemma.tex`.

## Other attempted transfers

The graph-flow, marginal-table, tiling, and Littlewood reports are exploration records, not further claimed conjecture resolutions. The Littlewood searches returned UNKNOWN at their time limits; this proves neither existence nor nonexistence. The graph and marginal reports give precise obstacles to overly broad transfer claims. Any preprint claims mentioned in exploration records retain the qualifications given there.

## Sources and reproducibility scope

Primary source URLs and exact theorem/table locations appear in the paper and reports. Downloaded third-party paper copies and the full external repository dataset are omitted. The audit records the repository snapshot URL and hash; its status is supporting evidence, not an exhaustive priority guarantee. The supplied proofs can be checked without those downloaded copies except for the cited standard multiplier theorem, for which a specialized proof is also supplied.

The original Erdős manuscript and its existing follow-up were not edited. `MANIFEST_SHA256.txt` records the included files. This package was generated through AI-assisted research and multiple internal checks; no author, affiliation, external endorsement, or publication acceptance is implied.
