# Transfer audit checkpoint

The external target selected is normality of hierarchical marginal semigroups, in particular Bernstein--Sullivant, *Normal Binary Hierarchical Models*, Question 1.1 and Problem 8.3 (classification for two-dimensional manifolds): https://arxiv.org/html/1508.05461v2 . The original source poses these questions in 2016; no later resolution was located in the current search, but this is not proof of current open status. The three-way boundary-of-simplex normality classification is already completed, as the same paper's Theorem 2.8 records. It must not be announced as a newly solved problem.

## Exact obstruction to a universal positivity transfer

For the binary K4 marginal map A, demand that each of the six 2×2 pairwise margins is the all-ones matrix. Let b denote these margins. There is a nonnegative rational lift: assign 1/4 to every binary word of length four. There is also a signed integer lift: assign 2 to 0000, −1 to each weight-one word, 1 to each weight-two word, and 0 to all other words.

There is no nonnegative integer lift. Such a lift would be a four-row array of four binary columns whose pairwise margins are balanced. Recode each column as a vector in {−1,1}^4. All four are nonzero, balanced, and pairwise orthogonal. They would be four orthogonal nonzero vectors in the three-dimensional subspace perpendicular to the all-ones vector, impossible.

This is a known K4 normality hole, not a new counterexample to an open conjecture. It directly disproves any generic claim that lattice congruence compatibility and nonnegative real feasibility suffice for nonnegative integer lifting.

A stronger observation is now verified: 2b and 3b are integer feasible, so b has a nonnegative Z_(p)-valued lift for every prime p despite having no nonnegative integer lift. For 2b take every even-weight word once. For 3b take the zero word twice, every weight-two word once, and every weight-three word once. Use the latter divided by 3 at p=2 and the former divided by 2 at every other prime. The checker independently excludes all 3876 four-row multisets and checks every one of the 24 margins exactly. This identifies the missing semigroup condition, not merely a missing congruence.

## The precise all-primes barrier

Let S=A N^n be a finitely generated additive semigroup in an integer lattice, and fix an integral vector b. Existence of a nonnegative Z_(p)-valued lift of b for every prime p is equivalent to b belonging to the **seminormalization** of S. This is a reformulation of a standard semigroup notion, not a newly claimed theorem.

Proof: put H_b={m∈N:mb∈S}. A local lift at p is equivalent, by clearing its positive common denominator, to some m∈H_b with p∤m. Such an m for every prime exists exactly when gcd(H_b)=1. A submonoid of N with gcd one contains every sufficiently large integer: choose finitely many elements whose gcd is one and use the elementary numerical-semigroup fact. Thus mb∈S for all sufficiently large m. Conversely, eventual membership gives a multiplier coprime to each p. The same gcd condition supplies a Bezout expression for b as an integer combination of elements of S, so b lies in its difference lattice. This is exactly the standard seminormalization characterization.

Hence checking every prime-adic relaxation cannot decide membership in a non-seminormal marginal semigroup. The explicit K4 hole is a concrete failure, since 2b and 3b are in S but b is not.

## Novelty audit of the abstract mechanism

Anchored inclusion--exclusion is a Möbius/ANOVA decomposition; prime-to-p averaging is the usual Reynolds operator over a ring where the group order is a unit; deciding lattice membership via Smith normal form is standard. The arithmetic transfer coefficient and the conserved support sums in the Erdős application are additional hypotheses. They are not supplied merely by a problem having a group action or marginal maps. In particular, their transfers use subtraction and need not preserve the nonnegative cone.

A primary reference for the decomposition itself is Kuo, Sloan, Wasilkowski and Woźniakowski, *On decompositions of multivariate functions*, Math. Comp. 79 (2010), 953–966, DOI https://doi.org/10.1090/S0025-5718-09-02319-9 ; the author's expanded preprint is https://web.maths.unsw.edu.au/~fkuo/pubs/preprint/ksww09-decomp.pdf . Its commuting-projection framework includes both anchored and ANOVA decompositions. We should not name that decomposition as a newly invented mathematical operation.

### An exact abstract form of the proved support deletion

Fix a prime ℓ and R=Z_(ℓ). Let I be a finite index set. For i∈I let G_i be a nontrivial finite abelian ℓ-group of size N_i, and let a_i be an integer with a_i≡1 mod ℓ and N_i/(a_i−1)∈R×. For i≠j choose compatible translation elements t_{ij}∈G_j; these induce a translation τ_i on any product missing i.

Suppose R-valued functions F_S on G_S=∏_{i∈S}G_i are given for every nonempty S⊆I, each having constant residue modulo ℓ. For every character χ nonprincipal in each coordinate of a nonempty M, suppose

\[
\sum_{S\supseteq M}\prod_{i\in S\setminus M}
\frac{a_i-\chi(t_i)}{a_i-1}\,\widehat F_S(\chi)=0.
\]

Also suppose T_i=Σ_{S∋i}Σ F_S lies in ℓN_iR. Then the constant residue of every original singleton F_{i} is zero.

Proof: process maximal supports. Fourier vanishing eliminates the fully mixed component, and anchored differences decompose the current F_S into functions h_i missing coordinate i and having constant residues. Remove each inflated h_i and add N_i/(a_i−1)(a_i−τ_i)h_i to S\{i}. This lower change is zero modulo ℓ. The Fourier equations cancel by their specified coefficient ratio. Its total equals N_iΣh_i, so all T_j for j≠i are unchanged; T_i changes by −N_iΣh_i∈ℓN_iR because the remaining product is nonempty and h_i has constant residue. At the end a singleton is constant c_i, and N_i c_i∈ℓN_iR forces c_i≡0. ∎

This is an abstract restatement of the already proved argument, not a claim of independent novelty. Its hypotheses expose the transfer test: an external problem must supply the displayed **specific coefficient ratios**, compatible translations, uniform residues, and the strong T_i congruences. A generic marginal map supplies none of the coefficient ratios or conservation congruences automatically. Even when the algebraic hypotheses hold, the theorem concerns R-valued functions; preservation of positivity, prescribed finite alphabets, or small support is an additional requirement.

Primary sources found:

- Bernstein--Sullivant, *Normal Binary Hierarchical Models*: https://arxiv.org/html/1508.05461v2 . Defines cone/lattice/semigroup distinction and the still-open-at-publication classification problems.
- Sullivant, *Normal binary graph models* (2010): https://www.ism.ac.jp/editsec/aism/pdf/062_4_0717.pdf . Proves binary graph normality iff K4-minor-free; this is an already solved subcase.
- Bruns--Hemmecke--Ichim--Köppe--Söger, *Challenging Computations of Hilbert Bases of Cones Associated with Algebraic Statistics* (2011): author institution record https://portal.fis.tum.de/en/publications/challenging-computations-of-hilbert-bases-of-cones-associated-wit/ . Completes the three-way marginal normality classification; older papers calling a remaining 3×5×5 case open are obsolete.
- *Unimodular rows over monoid rings* (2018), https://doi.org/10.1016/j.aim.2018.08.011 . Gives the standard seminormalization criterion nx∈M for all sufficiently large n.

No marginal-normality open problem has been closed in this audit. This branch produced an exact limitation result and existing-theory comparison. The separate orthogonal-array claim was independently audited successfully; see `audit_catalan_independent.md`.
