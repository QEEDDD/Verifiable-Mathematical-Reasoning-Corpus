# Independent audit of Catalan-bound tightness

Audited 24 October 2026. **Conclusion: the proof in `coding.md` is valid for every k≥3, including its equality classification.** This is an internal mathematical audit, not external peer review. No new statement about arbitrary orthogonal arrays is implied.

## Original problem verified at the primary source

I independently opened and searched the publisher's full article:

R. C. Karunanayaka, *Catalan Bounds for Symmetric Strength-Two Orthogonal Arrays*, Journal of Combinatorial Designs, first published 18 September 2026, DOI https://doi.org/10.1002/jcd.70039 . Primary full text: https://onlinelibrary.wiley.com/doi/10.1002/jcd.70039 .

The article defines a multiset by a nonnegative integer multiplicity for each Hamming shell, with every word in that shell repeated the same number of times. Its Conjecture 1 states exactly `n_min(k)=4 binom(k−2,floor((k−2)/2))` for k≥3. Theorem 6 supplies the upper bound. The text reports checks through k=14 and explicitly identifies the general analytical lower bound as open. A targeted current search found no separate resolution; the verifiable fact is that the publisher's retrieved article still states it as a conjecture.

The relevant scope is full coordinate-permutation symmetry. Repeated rows are allowed, the array is nonempty, and the multiplicities are integers. The proof uses all three features. It does not address the Hadamard conjecture or a general OA existence classification.

## Independent derivation of the crucial steps

Recode each row by k signs and let D be their sum. Strength two gives `ED=0`, `ED²=k`. Full coordinate symmetry makes a populated weight shell contain at least `C=binom(k,w)` rows.

There must be a populated shell with `d²≤k`. The non-strict inequality is essential: at k=4 the complete odd-weight shells attain equality everywhere; another example has k=9 and shells of weights 3 and 6.

For a selected shell of mass M and sign sum d, the other rows have sum −Md and square-sum kN−Md². Cauchy–Schwarz gives

\[
(N-M)(kN-Md^2)-M^2d^2
=N\bigl(k(N-M)-Md^2\bigr)\geq0.
\]

Thus `N≥M(1+d²/k)`. No positivity, integrality, or direction of inequality was lost in this cancellation.

For `G_k(d)=binom(k,(k−d)/2)(k+d²)`, the exact cross-multiplication difference in the consecutive ratio is

\[
(k-d)(k+(d+2)^2)-(k+d+2)(k+d^2)
=2(d+1)\bigl(k+1-(d+1)^2\bigr).
\]

Every step whose upper endpoint satisfies `(d+2)²≤k` has a strictly positive right side. Consequently G increases through all relevant nonnegative d of the proper parity.

- Odd k: the minimum relevant d is 1, and `G_k(1)/k` is exactly the conjectured lower bound.
- Even k, d≠0: the minimum is d=2. Its bound is `Ccentral(k+4)/(k+2)`, while the target is `Ccentral k/(k−1)`. The difference has positive denominator and numerator `k−4`. Thus it is valid for every even k≥4 and strict for k>4.
- Even k, d=0: `kN≤k²(N−M)` because every remaining row has squared sign sum at most k². This gives exactly `N≥Ccentral k/(k−1)`.

These cases exhaust the possibilities. The binomial identities giving the target in both parities are exact, not asymptotic.

## Equality classification checked

For odd k, strict binomial monotonicity forces |d|=1; the shell multiplicity is one. Cauchy equality forces all remaining rows to have a common sign sum, which the first two moments determine as −k/d. Thus only one adjacent central shell and the opposite endpoint occur. The endpoint multiplicity is the appropriate Catalan number. Global level flip gives the second minimum vector.

For even k≥6, the d≠0 bound is strict, so a minimum array contains the central shell once. Equality in the maximum-square bound forces all other rows to be the two endpoints, in equal numbers. For k=4, equality at d=2 additionally permits the two odd-weight shells once each. There are no other equality cases.

The displayed constructions satisfy the original single-column and two-column marginal equations. Thus the lower bound is attained and the exact minimum follows independently of the source's upper-bound proof.

## Relation to established mathematics and to the transfer claim

The shell-mass inequality is the standard one-atom consequence of a mean and variance constraint (a Cauchy–Schwarz/Cantelli-type bound). The Fourier/moment reduction is also standard. The useful application is to combine that inequality with the indivisible mass of a populated orbit and the exact binomial monotonicity. This establishes the precise conjecture stated in the 2026 article; it does not establish novelty of the underlying inequality itself.

The result is a transfer of the orbit-compression-plus-forcing strategy. It does not use the prime-adic support-deletion theorem. A manuscript should make this distinction explicit instead of presenting one universal algebraic mechanism as having solved both problems.

## Exact corroboration

`audit_catalan_independent.py` imports no proposing-agent code. It checks the two polynomial factorizations symbolically, verifies the binomial comparisons for every admissible d at 3≤k≤1000, and tests the equality constructions directly against the original marginal equations. It also checks explicit counterexamples to the incorrect strict `d²<k` assertion. Its finite checks corroborate the algebraic proof, whose scope is all k.
