"""Independent exact audit of the all-k Catalan-bound argument.

No imports from the proposing agent's code. The proof is algebraic; these
checks corroborate the identities, boundary cases, and constructions.
"""
from math import comb,isqrt
from pathlib import Path
import json
import sympy as s

k,d,M,N=s.symbols('k d M N')
ratio_numerator=s.expand((k-d)*(k+(d+2)**2)-(k+d+2)*(k+d*d))
assert s.expand(ratio_numerator-2*(d+1)*(k-d*d-2*d))==0
assert s.expand((N-M)*(k*N-M*d*d)-M*M*d*d)==s.expand(N*(k*(N-M)-M*d*d))
assert s.expand((k+4)*(k-1)-k*(k+2))==k-4

def choose(n,r):return comb(n,r) if 0<=r<=n else 0
def catalan(r):return comb(2*r,r)//(r+1)
def check_marginals(k,m):
    n=sum(m[w]*comb(k,w) for w in range(k+1))
    one=sum(m[w]*choose(k-1,w-1) for w in range(k+1))
    two=sum(m[w]*choose(k-2,w-2) for w in range(k+1))
    assert 2*one==n and 4*two==n
    assert sum(m[w]*comb(k,w)*(k-2*w) for w in range(k+1))==0
    assert sum(m[w]*comb(k,w)*(k-2*w)**2 for w in range(k+1))==k*n
    return n

comparisons=0;constructions=0
for k in range(3,1001):
    target=4*comb(k-2,(k-2)//2)
    ds=list(range(k%2,isqrt(k)+1,2))
    assert ds
    prev=None
    for d in ds:
        mass=comb(k,(k-d)//2)
        g=mass*(k+d*d)
        if prev is not None:assert g>prev
        prev=g
        if d:
            assert g>=k*target
            if k%2==0 and k>4:assert g>k*target
        else:
            assert k*mass==(k-1)*target
        comparisons+=1
    if k%2:
        r=(k-1)//2
        m=[0]*(k+1);m[r]=1;m[k]=catalan(r)
        assert check_marginals(k,m)==target
        assert check_marginals(k,list(reversed(m)))==target
        constructions+=2
    else:
        r=k//2
        m=[0]*(k+1);m[r]=1;m[0]=m[k]=catalan(r-1)
        assert check_marginals(k,m)==target
        constructions+=1

# The proof must use d² <= k, not the false strict inequality.
assert check_marginals(4,[0,1,0,1,0])==8
m9=[0]*10;m9[3]=m9[6]=1
assert check_marginals(9,m9)==168
assert all((9-2*w)**2==9 for w in (3,6))

out={'result':'PASS','k_min':3,'k_max':1000,'exact_comparisons':comparisons,
     'original_marginal_constructions':constructions,
     'ratio_numerator_factor':str(s.factor(ratio_numerator)),
     'cauchy_expansion_verified':True,'even_comparison_numerator':'k-4',
     'strict_shell_inequality_counterexamples':{'k4':[0,1,0,1,0],'k9':m9},
     'scope':'Corroboration only. The displayed algebraic proof establishes all k.'}
(Path(__file__).parent/'audit_catalan_independent.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
