from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'deliverables'
OUT.mkdir(exist_ok=True)
front = r'''\documentclass[11pt]{article}
\usepackage[T1]{fontenc}
\usepackage{lmodern,amsmath,amssymb,amsthm,mathtools,booktabs}
\usepackage[margin=1in]{geometry}
\usepackage{microtype}
\usepackage[colorlinks=true,linkcolor=blue,citecolor=blue,urlcolor=blue]{hyperref}
\usepackage{enumitem}
\setlist{itemsep=2pt,topsep=4pt}
\newtheorem{theorem}{Theorem}[section]
\newtheorem{lemma}[theorem]{Lemma}
\theoremstyle{remark}
\newtheorem{remark}[theorem]{Remark}
\numberwithin{equation}{section}
\title{Orbit Constraints in Symmetric Arrays\\and Circulant Weighing Matrices}
\author{}
\date{Research draft -- 24 October 2026}
\hypersetup{pdftitle={Orbit Constraints in Symmetric Arrays and Circulant Weighing Matrices},pdfsubject={Catalan-bound tightness and nonexistence of CW(195,81)}}
\begin{document}
\maketitle
\begin{abstract}
We establish two results in combinatorial design theory. For every $k\ge3$,
the minimum number of rows in a binary strength-two orthogonal array invariant
under all coordinate permutations is
$4\binom{k-2}{\lfloor(k-2)/2\rfloor}$, proving Karunanayaka's
Catalan-bound tightness conjecture. We also classify all minimizing shell
multiplicity vectors. Separately, we prove that a circulant weighing matrix
$CW(195,81)$ does not exist, resolving a parameter pair listed as open in
Arasu--Gordon--Zhang's table. Both proofs are analytic. The first combines
indivisible shell masses with two moment constraints. The second combines
contraction, established cyclotomic multiplier theory, a kernel character,
and a short augmentation obstruction. Exact finite checks are supplied as
independent corroboration, not as premises of either proof.
\end{abstract}

\section{Scope and relation to the proposed method}

The purpose of this note is to test a proof strategy outside periodic
Dirichlet-series questions: compress constraints by symmetry, retain the
integrality and coefficient restrictions that survive compression, and use
them to force a sharp bound or a contradiction. The results below concern
different mathematical objects and do not assume any claim about an
Erd\H{o}s function or an Okada lattice.

The first target is Conjecture~1 of Karunanayaka~\cite{Karunanayaka2026},
whose published statement covers every $k\ge3$ and whose reported finite
verification covers $k\le14$. We prove the original statement with its full
coordinate-permutation symmetry assumption. The second target is the
existence of $CW(195,81)$, listed in Table~10 of
Arasu--Gordon--Zhang~\cite{ArasuGordonZhang2021}.

The tools used here have established precedents. Cauchy--Schwarz and orbit
compression are standard. The cyclotomic multiplier theorem is due to
Tan~\cite{Tan2018}; kernel-character reductions also appear in
Tan~\cite{Tan2026}. The contributions asserted in this draft are the
specific lower-bound proof and equality classification, and the elimination
of the parameter pair $(195,81)$. No new general multiplier theorem or
universal $2$-adic decision procedure is asserted.

\paragraph{Review status.}
The proofs have undergone separate internal mathematical audits and exact
arithmetic checks. This is an AI-assisted research draft, not an externally
refereed publication. The source check on 24 October 2026 found the targets
stated as open in the cited records and found no later resolution of these
specific statements. That search is not a guarantee of publication priority.

'''
coding = (ROOT / 'coding_section.tex').read_text()
designs = (ROOT / 'designs_section.tex').read_text()
tail = r'''
\section{Verification and limits}

\subsection{Checks supplied with this note}
The general proofs above do not rely on finite search. The supplementary
programs use exact arithmetic to check the arithmetic reductions independently.
For the array result, two implementations verify 10,813 shell inequalities
through $k=1000$, including the boundary $d^2=k$, and check the constructions
against the original one- and two-coordinate marginal equations. A separate
small-parameter enumeration reproduces all minimum multiplicity vectors;
an optional CP-SAT run checks $3\le k\le16$.

For the circulant result, an exhaustive orbit calculation recovers eight
normalized contractions in two equivalence classes. An independent
Eisenstein calculation excludes the normalized unit-orbit assignments.
These numerical checks are unnecessary for the final proof: the contraction
lemma and the augmentation inequality already exclude every possible matrix.

\subsection{What transfers, and what does not}
For the array problem, positivity makes a populated orbit contribute at
least its full cardinality. The moment equations then force enough mass
outside it. There is no need for a $2$-adic obstruction. For the circulant
problem, a quotient alone discards information: evaluating a nonprincipal
character of its kernel retains enough information to force a unit-valued
group-ring equation. The resulting orbit sizes conflict with the permitted
augmentation norm.

This does not justify a general implication from local integral feasibility
to a solution with a prescribed finite alphabet or with nonnegative
coefficients. Graph-flow, marginal-table, tiling, and Littlewood-polynomial
targets were considered separately; no resolution of their broad open
conjectures is asserted here. In particular, neither result proves the
Hadamard conjecture, the circulant Hadamard conjecture, or Tutte's flow
conjectures. The evidence for transfer consists of the two precise theorems
proved above, with the hypotheses stated there.

\begin{thebibliography}{9}
\bibitem{Karunanayaka2026}
R. C. Karunanayaka,
\emph{Catalan Bounds for Symmetric Strength-Two Orthogonal Arrays},
Journal of Combinatorial Designs, first published 18 September 2026.
\href{https://doi.org/10.1002/jcd.70039}{doi:10.1002/jcd.70039}.
Conjecture 1 and Theorem 6.

\bibitem{ArasuGordonZhang2021}
K. T. Arasu, D. M. Gordon, and Y. Zhang,
\emph{New nonexistence results on circulant weighing matrices},
Cryptography and Communications \textbf{13} (2021), 775--789.
\href{https://arxiv.org/abs/1908.08447v3}{arXiv:1908.08447v3}.
Tables 9 and 10.

\bibitem{Tan2018}
M. M. Tan, \emph{Group Invariant Weighing Matrices},
Designs, Codes and Cryptography \textbf{86} (2018), 2677--2702.
\href{https://arxiv.org/abs/1610.01914v4}{arXiv:1610.01914v4}.
Theorem 3.4 and Corollary 3.5(b).

\bibitem{Tan2026}
M. M. Tan,
\emph{Character and Multiplier Obstructions for Circulant Weighing Matrices},
preprint, 1 September 2026.
\href{https://arxiv.org/abs/2608.18468v2}{arXiv:2608.18468v2}.

\end{thebibliography}
\end{document}
'''
out = OUT / 'Orbit_Constraints_External_Results_20261024.tex'
out.write_text(front + coding + '\n' + designs + tail)
print(out)
