# Independent audit of the Catalan-bound proof

24 October 2026. Reviewer: the general-shadow/graph-flow research agent,
independent of the agent that supplied the proof and its original tests.

**Conclusion: the proposed all-k lower bound and complete equality
classification are mathematically valid. No gap was found.** This is
an internal proof review, not external peer review or journal acceptance.

## Identification of the exact external problem

I independently opened the publisher's complete HTML for Ruwan C.
Karunanayaka, *Catalan Bounds for Symmetric Strength-Two Orthogonal
Arrays*, first published 18 September 2026,
https://onlinelibrary.wiley.com/doi/10.1002/jcd.70039 .
Section 1.1 and Lemma 2 use nonnegative integer multiplicities for
entire binary Hamming shells, with repetitions permitted. Theorem 6
constructs arrays of size

    B_k = 4 binom(k−2, floor((k−2)/2)),  k≥3.

Conjecture 1 asserts that this is the minimum for every k; the article
reports exhaustive verification through k=14. Thus the proof addresses
the source's actual problem, not a different meaning of “symmetric.”
A separate current search found no later announced proof, but this is
not a comprehensive historical priority certification.

## Proof audit

**Moment equivalence.** Put `D=k−2w` for a row of weight w. Full
coordinate symmetry makes all one-coordinate sign means equal and
all distinct two-coordinate correlations equal. Consequently
`E D=0` and `E D²=k` are equivalent to strength two. No independence
assumption beyond strength two is being used.

**Selection of a populated shell.** A weighted average of the values
`d²` equals k, so at least one populated shell has `d²≤k`.
The weak inequality is essential when k is a perfect square, and
the draft uses it correctly. Its mass M is at least the size of the
shell because its multiplicity is a positive integer.

**Cauchy–Schwarz.** After deleting that shell, the remaining sign sum
is `−Md` and remaining square-sum is `kN−Md²`. Hence

    M²d² ≤ (N−M)(kN−Md²).

Expansion cancels M²d² and yields exactly

    N ≥ M(1+d²/k).

There is no illegal division by a possibly vanishing remaining mass.
In fact one populated shell alone cannot satisfy the two moments, but
the displayed algebra does not need that separate observation.

**The binomial comparison.** For
`G_k(d)=binom(k,(k−d)/2)(k+d²)`, direct cross multiplication gives

    (k−d)(k+(d+2)²) − (k+d+2)(k+d²)
      = 2(d+1)(k+1−(d+1)²).

If d and d+2 both lie in the required range, `(d+2)²≤k`, the right
side is strictly positive. This proves monotonicity on the admissible
parity grid, including a final grid point with `d²=k`.

For odd k the smallest admissible absolute value is 1, and
`G_k(1)/k=B_k` exactly. For even k and nonzero d, the smallest value
is 2. Writing `C=binom(k,k/2)`, its bound is
`C(k+4)/(k+2)`, whereas `B_k=Ck/(k−1)`. Their comparison has exact
cross-product difference

    (k+4)(k−1) − k(k+2) = k−4,

The comparison therefore holds for k≥4 and is strict for k>4,
exactly as asserted in the draft.

**The central shell.** The one-atom Cauchy bound by itself is too weak
at d=0. The draft correctly uses the bounded range `D²≤k²` on all
remaining rows, giving `kN≤k²(N−M)` and
`N≥kM/(k−1)≥B_k`. No case has been omitted.

**Equality cases.** For odd k, strict monotonicity forces `|d|=1`
and shell multiplicity one. Equality in Cauchy–Schwarz forces a
single remaining sign value `−k/d`, hence the appropriate endpoint
and its Catalan multiplicity. For even k>4, the nonzero-d alternative
is strict; equality in the central estimate forces only the two
endpoints outside the central shell, with equal endpoint masses.
At k=4, the alternative d=±2 yields precisely the additional vector
`(0,1,0,1,0)`. The k=3 endpoint cases are also valid.

I independently checked the endpoint identities giving the Catalan
numbers and the original column/pair marginal equations. The
constructions in the source provide the matching upper bound at
all k; the proof does not rely on the source's finite enumeration.

## Separate exact verification

`coding/independent_catalan_audit.py` imports none of the author's
checker. It verifies the integer binomial inequalities and all
constructed marginal equations through k=1000, including every
admissible perfect-square boundary in that range.

It also enumerates every interior shell multiplicity vector with
mass at most B_k for 3≤k≤10. Endpoint multiplicities are solved from
the two moments rather than sent to CP-SAT. Every candidate at or
below B_k is recovered, and exactly the stated equality vectors occur.
Results are in `coding/independent_catalan_audit.json`.

The finite checks are corroboration. The elementary argument above
proves the asserted lower bound for every k.
