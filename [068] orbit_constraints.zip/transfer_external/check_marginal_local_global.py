"""Exact K4 marginal-hole certificates; no optimization software required."""
from itertools import product, combinations, combinations_with_replacement
from fractions import Fraction
from pathlib import Path
import json

words=list(product((0,1),repeat=4))
rows=[(i,j,a,b) for i,j in combinations(range(4),2) for a,b in product((0,1),repeat=2)]
A=[[int(x[i]==a and x[j]==b) for x in words] for i,j,a,b in rows]
def margins(x):return [sum(c*v for c,v in zip(row,x)) for row in A]
signed=[2 if sum(x)==0 else -1 if sum(x)==1 else 1 if sum(x)==2 else 0 for x in words]
twice=[int(sum(x)%2==0) for x in words]
thrice=[2 if sum(x)==0 else 1 if sum(x) in (2,3) else 0 for x in words]
assert margins(signed)==[1]*24
assert margins([Fraction(1,4)]*16)==[1]*24
assert margins(twice)==[2]*24
assert margins(thrice)==[3]*24
assert margins([Fraction(x,3) for x in thrice])==[1]*24
assert margins([Fraction(x,2) for x in twice])==[1]*24
# Four observations, including repeated observations: enumerate every multiset.
count=0
for chosen in combinations_with_replacement(range(16),4):
    count+=1
    v=[0]*16
    for i in chosen:v[i]+=1
    assert margins(v)!=[1]*24
out={'status':'PASS','matrix_shape':[24,16],'words':[list(w) for w in words],
     'signed_integer_lift':signed,'integer_lift_of_2b':twice,'integer_lift_of_3b':thrice,
     'all_four_row_multisets_excluded':count,
     'local_lifts':'For p=2 use integer_lift_of_3b/3; for all other primes use integer_lift_of_2b/2.',
     'novelty':'Known binary K4 nonnormality hole, used to audit an invalid universal transfer.'}
(Path(__file__).parent/'marginal_local_global.json').write_text(json.dumps(out,indent=2))
print(json.dumps({k:v for k,v in out.items() if k not in ('words','signed_integer_lift','integer_lift_of_2b','integer_lift_of_3b')},indent=2))
