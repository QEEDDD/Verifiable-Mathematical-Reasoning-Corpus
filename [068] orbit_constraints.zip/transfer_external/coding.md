# External transfer: symmetric strength-two orthogonal arrays

## Primary target and status

Ruwan C. Karunanayaka, **Catalan Bounds for Symmetric Strength-Two Orthogonal Arrays**, *Journal of Combinatorial Designs*, first published 18 September 2026, DOI [10.1002/jcd.70039](https://onlinelibrary.wiley.com/doi/10.1002/jcd.70039). The primary full HTML is accessible. Its §1.1 defines integer Hamming-shell multiplicities; Theorem 6 gives a construction; **Conjecture 1 (Catalan-bound tightness)** asserts

\[
n_{\min}(k)=4\binom{k-2}{\lfloor(k-2)/2\rfloor},\qquad k\ge3.
\]

The article reports verification through k=14 and states the general lower bound as open. The proof below establishes that lower bound for every k and classifies all minimum multiplicity vectors. These are claims about arrays invariant under *all coordinate permutations*, with repeated rows allowed. They do not settle the Hadamard conjecture or the general orthogonal-array existence problem.

Retrieval date: 2026-10-24. Source sections to inspect: §1.1, Lemma 2, §6.2 Theorem 6 and Conjecture 1. The publisher PDF request returned HTTP 403; no local PDF copy was obtained. The exact mathematics below is self-contained.

## Definitions

Let k≥3. For each w∈{0,…,k}, choose an integer m_w≥0. Include every binary word of weight w exactly m_w times. Let

\[
M_w=m_w\binom{k}{w},\qquad N=\sum_wM_w>0.
\]

The resulting multiset is a binary strength-two orthogonal array exactly when each one-coordinate marginal is uniform and each two-coordinate marginal is uniform. Equivalently,

\[
\sum_w m_w\binom{k-1}{w-1}=N/2,\qquad
\sum_w m_w\binom{k-2}{w-2}=N/4.
\]

Its coordinate permutation symmetry ensures that the first equation applies to every coordinate and the second to every distinct pair.

## Theorem and proof

**Theorem.** For every nonempty integer Hamming-shell strength-two orthogonal array on k≥3 coordinates,

\[
N\ge B_k:=4\binom{k-2}{\lfloor(k-2)/2\rfloor}.
\]

Together with the constructions below, this proves Catalan-bound tightness for every k.

**Moment reduction.** Write d_w=k−2w. If a random row is sampled uniformly from the multiset, the sum D of its k signs has

\[
\mathbb E D=0,\qquad \mathbb E D^2=k.
\]

Equivalently,

\[
\sum_w M_wd_w=0,\qquad \sum_wM_wd_w^2=kN. \tag{1}
\]

There is therefore a populated shell with d²≤k, including equality when k is a square. Choose such a shell. Its mass M satisfies

\[
M\ge C_k(d):=\binom{k}{(k-|d|)/2}, \tag{2}
\]

because its multiplicity is a positive integer.

**A forced-shell moment bound.** Remove this shell, leaving mass N−M. Since the original mean is zero, the remaining sum is −Md, and its square-sum is kN−Md². Cauchy–Schwarz gives

\[
M^2d^2\le(N-M)(kN-Md^2).
\]

After cancellation,

\[
N\ge M\left(1+\frac{d^2}{k}\right). \tag{3}
\]

This is the elementary one-atom variance bound; the new use here is the integer lower bound (2) on the mass of an entire coordinate orbit.

**Binomial monotonicity.** For nonnegative d of the same parity as k, define

\[
G_k(d)=\binom{k}{(k-d)/2}(k+d^2).
\]

For consecutive admissible values,

\[
\frac{G_k(d+2)}{G_k(d)}
=\frac{k-d}{k+d+2}\frac{k+(d+2)^2}{k+d^2}.
\]

The difference between numerator and denominator after cross multiplication is

\[
(k-d)(k+(d+2)^2)-(k+d+2)(k+d^2)
=2(d+1)\bigl(k+1-(d+1)^2\bigr).
\]

Thus G_k is strictly increasing as d ranges through the admissible values with d²≤k: if (d+2)²≤k, then (d+1)²<k+1.

For odd k, the smallest admissible |d| is 1, so (2)–(3) imply

\[
N\ge\frac{G_k(1)}k
=\frac{k+1}{k}\binom{k}{(k-1)/2}
=B_k. \tag{4}
\]

For even k and nonzero d, one has |d|≥2. Writing C=binom(k,k/2),

\[
N\ge\frac{G_k(2)}k
=C\frac{k+4}{k+2}
\ge C\frac{k}{k-1}=B_k, \tag{5}
\]

because the middle inequality is equivalent to k≥4; it is strict when k>4.

It remains to treat d=0 for even k. Every other row has D²≤k², and the selected central shell contributes zero, so (1) gives

\[
kN\le k^2(N-M),\qquad
N\ge\frac{k}{k-1}M\ge\frac{k}{k-1}\binom{k}{k/2}=B_k. \tag{6}
\]

This proves the theorem. No numerical search, congruence assumption, or asymptotic estimate is used.

## All equality cases

Let Cat_r=binom(2r,r)/(r+1).

1. **Odd k=2r+1.** Equality in (4) requires |d|=1 and multiplicity one for that shell. Equality in Cauchy–Schwarz forces all other rows to have the same sign sum −k/d. Consequently the only two minimum multiplicity vectors are
   \[
   m_r=1,\ m_k=\operatorname{Cat}_r;
   \qquad\text{or}\qquad
   m_{r+1}=1,\ m_0=\operatorname{Cat}_r,
   \]
   with all other entries zero. They are global level flips of one another.
2. **Even k=2r≥6.** The nonzero-d bound (5) is strict, so a minimum array has a central shell of multiplicity one. Equality in (6) forces all remaining rows to have D=±k. Zero mean gives equal endpoint multiplicities. Hence the unique minimum vector is
   \[
   m_r=1,\qquad m_0=m_k=\operatorname{Cat}_{r-1},
   \]
   with all other entries zero.
3. **k=4.** There are two minimum vectors: (1,0,1,0,1) and (0,1,0,1,0). The first is the central-shell construction. The second arises from equality in (5) at |d|=2 and consists of all odd-weight rows.

Each displayed vector satisfies the moments (1). By coordinate symmetry, these moments imply the one- and two-coordinate orthogonality constraints. Thus they attain B_k. Their endpoint multiplicities are positive integers because they are Catalan numbers.

This proves both the minimum and the complete classification of all multiplicity vectors attaining it. No claim is made about general arrays lacking full coordinate symmetry.

## Relation to the transferred method and existing bounds

The transfer is the combination of a compressed Fourier/moment system with a discrete lower bound on a populated orbit and a real inequality that forces the remaining mass. Here first- and second-order Fourier vanishing give (1), integer shell multiplicity gives (2), and Cauchy–Schwarz supplies an exact dual inequality. The decisive input is positivity and integrality after symmetry reduction. No 2-adic obstruction is needed.

The standard Rao bound for binary strength two is only N≥k+1. The Bierbrauer–Friedman bound is also a general bound without the full permutation-symmetry restriction; it is not the bound established here. Carlet, Kiss and Nagy, *Simplicity conditions for binary orthogonal arrays*, DOI [10.1007/s10623-022-01105-4](https://link.springer.com/article/10.1007/s10623-022-01105-4), discuss Rao bounds, simplicity, and the Carlet–Guilley monotonicity problem. We do not claim to solve that problem. Krotov's 2024 paper [arXiv:2311.05428](https://arxiv.org/abs/2311.05428) already classified OA(2048,14,2,7); that older apparent open case was discarded after checking current primary literature.

## Validation

`coding/check_catalan.py` uses exact integer arithmetic to check the binomial comparison for all admissible d at 3≤k≤1000, verifies every claimed equality construction against the original marginal equations, and checks the classification against an independent CP-SAT enumeration for 3≤k≤16 when requested. The exact arithmetic run passed 10,813 inequalities. The independent CP-SAT optimization and complete equality enumeration both passed for every 3≤k≤16, yielding the stated one or two minimizers in each case. These finite checks are corroboration; the proof above handles all k.

Two internal independent mathematical audits passed: both checked the original publisher definitions and Conjecture 1, Cauchy–Schwarz algebra, the binomial ratio, square-k boundary cases, and the full equality classification. Their reports are separate artifacts; this is not a claim of external peer review or publication acceptance. A freshness search on 2026-10-24 found the publisher conjecture statement and no later resolution; this does not establish publication priority.
