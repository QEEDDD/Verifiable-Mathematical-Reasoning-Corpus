#!/usr/bin/env python3
"""Exact checks for the symmetric strength-two OA theorem.
Default: standard library only, all binomial cases and constructions to k=1000.
--cp: also independently optimize and enumerate shell multiplicities to k=16
      using OR-Tools CP-SAT. These checks corroborate, not replace, the proof.
"""
from fractions import Fraction
from math import comb, isqrt
from pathlib import Path
import argparse
import json


def choose(n, r):
    return comb(n, r) if 0 <= r <= n else 0


def catalan(r):
    return comb(2 * r, r) // (r + 1)


def bound(k):
    return 4 * comb(k - 2, (k - 2) // 2)


def extremizers(k):
    m = [0] * (k + 1)
    if k % 2:
        r = k // 2
        m[r + 1] = 1
        m[0] = catalan(r)
        return [m, m[::-1]]
    r = k // 2
    m[r] = 1
    m[0] = m[k] = catalan(r - 1)
    return [m, [0, 1, 0, 1, 0]] if k == 4 else [m]


def verify_vector(k, m):
    assert len(m) == k + 1 and all(type(x) is int and x >= 0 for x in m)
    N = sum(v * comb(k, w) for w, v in enumerate(m) if v)
    a = sum(v * choose(k - 1, w - 1) for w, v in enumerate(m) if v)
    b = sum(v * choose(k - 2, w - 2) for w, v in enumerate(m) if v)
    assert 2 * a == N and 4 * b == N and N == bound(k)
    assert sum(v * comb(k, w) * (k - 2 * w) for w, v in enumerate(m) if v) == 0
    assert sum(v * comb(k, w) * (k - 2 * w) ** 2 for w, v in enumerate(m) if v) == k * N


def exact_checks(max_k):
    checked = 0
    for k in range(3, max_k + 1):
        B = bound(k)
        for d in range(k % 2, isqrt(k) + 1, 2):
            C = comb(k, (k - d) // 2)
            shell_bound = Fraction(C * k, k - 1) if d == 0 else Fraction(C * (k + d * d), k)
            assert shell_bound >= B, (k, d)
            if d + 2 <= isqrt(k):
                diff = ((k - d) * (k + (d + 2) ** 2)
                        - (k + d + 2) * (k + d * d))
                assert diff == 2 * (d + 1) * (k + 1 - (d + 1) ** 2) > 0
            checked += 1
        for m in extremizers(k):
            verify_vector(k, m)
    return checked


def cp_checks(max_k=16):
    from ortools.sat.python import cp_model
    records = []
    for k in range(3, max_k + 1):
        B = bound(k)
        weights = [comb(k, w) for w in range(k + 1)]
        model = cp_model.CpModel()
        m = [model.new_int_var(0, B // c, f'm{w}') for w, c in enumerate(weights)]
        N = sum(c * z for c, z in zip(weights, m))
        model.add(N >= 1)
        model.add(N <= B)
        model.add(sum(z * c * (k - 2 * w) for w, (z, c) in enumerate(zip(m, weights))) == 0)
        model.add(sum(z * c * ((k - 2 * w) ** 2 - k) for w, (z, c) in enumerate(zip(m, weights))) == 0)
        model.minimize(N)
        solver = cp_model.CpSolver()
        solver.parameters.max_time_in_seconds = 10
        solver.parameters.num_search_workers = 4
        status = solver.solve(model)
        assert status == cp_model.OPTIMAL, (k, solver.status_name(status))
        assert round(solver.objective_value) == B
        opt_seconds = solver.wall_time
        model.clear_objective()
        model.add(N == B)

        class Collector(cp_model.CpSolverSolutionCallback):
            def __init__(self):
                super().__init__()
                self.vectors = []
            def on_solution_callback(self):
                self.vectors.append([self.value(z) for z in m])
        callback = Collector()
        enum = cp_model.CpSolver()
        enum.parameters.enumerate_all_solutions = True
        enum.parameters.max_time_in_seconds = 10
        enum.parameters.num_search_workers = 1
        estatus = enum.solve(model, callback)
        assert estatus == cp_model.OPTIMAL, (k, enum.status_name(estatus))
        assert sorted(callback.vectors) == sorted(extremizers(k))
        rec = {'k': k, 'minimum': B, 'optimization_status': solver.status_name(status),
               'extremizers': callback.vectors, 'enumeration_status': enum.status_name(estatus),
               'optimization_seconds': opt_seconds, 'enumeration_seconds': enum.wall_time}
        records.append(rec)
        print(f'k={k}: minimum {B}; all {len(callback.vectors)} extremizers verified', flush=True)
    return records


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--cp', action='store_true')
    args = parser.parse_args()
    checked = exact_checks(1000)
    print(f'PASS: {checked} exact shell inequalities and all constructions for 3 <= k <= 1000.')
    data = {'exact_inequalities': checked, 'max_k': 1000, 'status': 'PASS'}
    if args.cp:
        data['cp_sat'] = cp_checks()
    Path(__file__).with_name('checks.json').write_text(json.dumps(data, indent=2))


if __name__ == '__main__':
    main()
