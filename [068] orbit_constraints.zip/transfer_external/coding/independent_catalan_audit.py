"""Independent exact audit; no imports from the proof author's verifier.

Checks the finite inequalities/constructions, then exhausts every
interior shell vector that could have run size at most the claimed
minimum. Endpoint multiplicities are derived from the two moments.
"""
from math import comb, isqrt
import json

def binom(n,r): return comb(n,r) if 0<=r<=n else 0
def catalan(r): return comb(2*r,r)//(r+1)

def expected(k):
    answer=[]
    if k%2:
        r=k//2
        a=[0]*(k+1); a[r]=1; a[k]=catalan(r); answer.append(tuple(a))
        a=[0]*(k+1); a[r+1]=1; a[0]=catalan(r); answer.append(tuple(a))
    else:
        a=[0]*(k+1); a[k//2]=1
        a[0]=a[k]=catalan(k//2-1); answer.append(tuple(a))
        if k==4: answer.append((0,1,0,1,0))
    return set(answer)

inequality_cases=0
square_boundary_cases=0
for k in range(3,1001):
    bound=4*comb(k-2,(k-2)//2)
    for d in range(k%2,isqrt(k)+1,2):
        shell=comb(k,(k-d)//2)
        if d==0:
            assert k*shell==(k-1)*bound
        else:
            assert shell*(k+d*d)>=k*bound
            if k%2 and d==1: assert shell*(k+1)==k*bound
            if k%2==0 and k>4: assert shell*(k+d*d)>k*bound
        inequality_cases+=1
        if d*d==k: square_boundary_cases+=1
    for a in expected(k):
        n=sum(a[w]*comb(k,w) for w in range(k+1))
        assert n==bound
        assert 2*sum(a[w]*binom(k-1,w-1) for w in range(k+1))==n
        assert 4*sum(a[w]*binom(k-2,w-2) for w in range(k+1))==n

records=[]
for k in range(3,11):
    bound=4*comb(k-2,(k-2)//2)
    interior=[0]*(k-1)
    found=[]
    visited=0
    def recurse(w,mass,first,second):
        global visited
        if w==k:
            visited+=1
            numerator=k*mass-second
            denominator=k*(k-1)
            if numerator<0 or numerator%denominator or first%k: return
            endpoint_sum=numerator//denominator
            endpoint_difference=-first//k
            if (endpoint_sum+endpoint_difference)%2: return
            m0=(endpoint_sum+endpoint_difference)//2
            mk=(endpoint_sum-endpoint_difference)//2
            n=mass+endpoint_sum
            if m0<0 or mk<0 or not 0<n<=bound: return
            a=(m0,*interior,mk)
            assert 2*sum(a[j]*binom(k-1,j-1) for j in range(k+1))==n
            assert 4*sum(a[j]*binom(k-2,j-2) for j in range(k+1))==n
            found.append((n,a)); return
        weight=comb(k,w); d=k-2*w
        for m in range((bound-mass)//weight+1):
            interior[w-1]=m
            recurse(w+1,mass+m*weight,first+m*weight*d,second+m*weight*d*d)
    recurse(1,0,0,0)
    assert found
    assert {n for n,a in found}=={bound}
    assert {a for n,a in found}==expected(k)
    records.append({'k':k,'bound':bound,'interior_vectors_exhausted':visited,
                    'all_arrays_at_or_below_bound':len(found)})

print(json.dumps({'all_checks_passed':True,
    'inequality_cases_k_through_1000':inequality_cases,
    'included_square_boundary_cases':square_boundary_cases,
    'exhaustive_small_cases':records},indent=2))
