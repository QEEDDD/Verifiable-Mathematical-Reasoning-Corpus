# A hand-checkable nonexistence proof for CW(195,81)

Status: research result derived in this session; root and a separate character-theory
agent have independently checked the proof. External priority review remains. The argument has no dependence on a
computer enumeration. The accompanying exact computations independently check
its finite arithmetic and reproduce the previously known contraction classes.

## References and scope

1. Ming Ming Tan, *Group Invariant Weighing Matrices*, arXiv:1610.01914v4,
   Theorem 3.4 and Corollary 3.5(b): generalized multiplier theorem in
   cyclotomic group rings. https://arxiv.org/pdf/1610.01914
2. K. T. Arasu, Daniel M. Gordon, Yiran Zhang, *New nonexistence results on
   circulant weighing matrices*, arXiv:1908.08447v3 / 2021 publication,
   Tables 9–10: CW(195,81) is listed as open, and ICW_3(65,81) has two
   equivalence classes. https://arxiv.org/html/1908.08447v3
3. Ming Ming Tan, *Character and Multiplier Obstructions for Circulant
   Weighing Matrices*, arXiv:2608.18468v2, 1 September 2026. Its eight
   nonexistence parameters do not include (195,81). Its Theorem 3.1 presents
   the same general C3-kernel reduction used below. Thus that reduction and
   the multiplier machinery are existing mathematics, not a new theorem
   claimed here. https://arxiv.org/html/2608.18468v2
4. Daniel Gordon's current repository snapshot, retrieved 24 October 2026,
   still marks key `CW(195,9)` as `Open`; its second parameter is the square
   root of the weight. Human-readable source:
   https://github.com/dmgordo/circulant-weighing-matrices/blob/main/cwm.json
   Raw source:
   https://raw.githubusercontent.com/dmgordo/circulant-weighing-matrices/main/cwm.json
   The preserved snapshot is `designs_code/cwm_snapshot.json`, SHA256
   `569a51b9c899cfe0363e8811f9afc467a1bdfe1472e69a8dc950f989fd0b4af5`.
   The repository is behind the September preprint on other entries, so its
   listing alone is not proof of absolute novelty.

The potentially new contribution is the parameter-specific elimination at
(195,81), especially the short contraction and augmentation arguments. It
does not settle the circulant Hadamard conjecture.

## Theorem

There is no circulant weighing matrix CW(195,81).

Write x* for group inversion together with complex conjugation of coefficients.
A hypothetical CW(195,81) is an element A of Z[C195], with coefficients
0,±1, satisfying AA*=81. We may replace A by −A so its augmentation is 9.
Since C195=C65×C3, contract its C3 coordinate to obtain B∈Z[C65] with

    BB*=81, augmentation(B)=9, and all coefficients in [−3,3].

### Step 1. The contraction has coefficients only 0,±3

Apply Tan 2018 Theorem 3.4 with coefficient conductor u=1, group C65,
norm n=81, and t=3. The coprimality (81,65)=1 holds, and σ3 is the
Frobenius at 3 in Q(ζ65), so it fixes every prime ideal above 3. We obtain
B^(3)=η X^j B, with η=±1. Augmentation 9 forces η=1; since (3−1,65)=1,
a group translation makes B fixed by multiplication by 3. This application
allows bounded integer coefficients and does not assume B is a genuine CW.
Identify C65=C5×C13. Multiplication by 3 has order 4
on C5's nonzero elements and order 3 on C13's nonzero elements. The four
nonzero C13 orbits each have size 3. In compatible order, write the orbit
coefficients of B as:

- a: at (0,0), orbit size 1;
- b: C5 nonzero × {0}, orbit size 4;
- c_i, i=1,...,4: {0} × the i-th C13 orbit, size 3;
- d_i, i=1,...,4: C5 nonzero × the i-th C13 orbit, size 12.

All these integers lie in [−3,3]. The energy equation is

    a²+4b²+3Σc_i²+12Σd_i²=81.                       (1)

Project further to C5. Its coefficients are x=a+3Σc_i at zero and
y=b+3Σd_i at each of the four nonzero positions. Augmentation and energy give

    x+4y=9,      x²+4y²=81.

Elimination gives 4y(5y−18)=0. Since y is an integer, y=0 and x=9.
Therefore a=3α, b=3β with α,β∈{−1,0,1}, and

    Σc_i=3−α,       Σd_i=−β.                       (2)

The C13 projection has coefficient a+4b at zero and coefficient c_i+4d_i
on its i-th nonzero orbit. Its energy is

    (a+4b)²+3Σ(c_i+4d_i)²=81.                     (3)

If β≠0, the bound |3α+12β|≤9 forces α=−β. Then the coefficient at zero
is ±9, using the entire energy in (3). Thus c_i+4d_i=0 for every i.
The bound |c_i|≤3 forces d_i=0, contradicting Σd_i=−β. Hence β=0.

Put t=Σd_i². Equations (1)–(3) become

    Σd_i=0,     Σc_i=3−α,
    Σc_i²+4t=27−3α²,      2Σc_i d_i+3t=0.          (4)

If t>0, Cauchy–Schwarz gives

    9t²/4 ≤ t(27−3α²−4t),

so t≤108/25<5. Since d_i²≡d_i modulo 2 and Σd_i=0, t is even.
Only t=0,2,4 remain.

If t=4, the d-vector must be a permutation of (1,1,−1,−1). Let P be
the sum of the two c's at the +1 positions and N the sum at the −1 positions.
Then P−N=−6 and P+N=3−α. When α=0 their parity is inconsistent. When
α=1, (P,N)=(−2,4), forcing Σc_i²≥2+8=10, whereas (4) requires 8.
When α=−1, (P,N)=(−1,5), forcing Σc_i²≥1+13=14, again exceeding 8.
Thus t≠4.

If t=2, arrange d=(1,−1,0,0). Then c1−c2=−3, so

    (c1,c2)=(-3,0),(-2,1),(-1,2),(0,3).

Their squared norms are respectively 9,5,5,9. If α=±1, equation (4)
requires c3²+c4² to equal 7 or 11, neither a sum of two integer squares.
If α=0, it requires 10 or 14. The value 14 is impossible. For value 10,
the two possible first pairs require c3+c4=6 or 0. But the integer
solutions to c3²+c4²=10 are permutations of (±3,±1), whose sums are
±4 or ±2. Hence t≠2.

Therefore t=0, so all d_i=0. Now Σc_i²=27−3α². If α=±1, four integers
of absolute value at most 3 would have squared sum 24. Reducing modulo 4
shows either zero or four odd entries; four odds give squared sum 4 modulo 8,
and zero odds give squared sum at most 16. Both alternatives are impossible.
Thus α=0 and Σc_i²=27. There must be three odd entries: one odd and three
even entries have squared sum at most 21. Modulo 8 the remaining even entry
must be zero, and equality 27 then forces all three odd entries to be ±3.
Their sum is 3, so two are +3 and one is −3.

Consequently B=3C for a 0,±1-valued C, with exactly nine nonzero coefficients.
No computation, full classification, or symmetry assumption on A was used.
The multiplier was applied only to its contraction B, as justified by the theorem.

### Step 2. Retain the nonprincipal C3 character

Let ω be a primitive cube root of unity and λ=1−ω, so λ conjugate(λ)=3.
Apply Y↦ω to A∈Z[C65×C3], obtaining E∈Z[ω][C65] with EE*=81.

Each three-entry fiber has sum either 0 or ±3. A fiber of sum ±3 is the
constant triple (±1,±1,±1), and maps to zero under the nonprincipal character.
A nonzero fiber of sum zero is a permutation of (1,−1,0), whose character
value is λ times an Eisenstein unit. Thus E=λD, where every coefficient of D
is zero or one of {±1,±ω,±ω²}, and

    DD*=27.                                        (5)

The identity coefficient in (5) implies exactly 27 nonzero coefficients.
This reduction is the established C3-kernel construction, reproved here.

### Step 3. A legitimate multiplier of D

Apply Tan's generalized multiplier theorem with coefficient conductor u=3,
group C65, norm n=27, and integer t0=133. Its hypotheses hold:

    gcd(27,65)=1,     gcd(133,195)=1,
    133≡1 (mod3),    133≡3 (mod65).

The automorphism σ133 fixes every prime ideal over 3 in Q(ζ195). Indeed,
on Q(ζ65) it is the Frobenius automorphism ζ65↦ζ65³, which lies in the
decomposition group of each prime over 3. The extension obtained by adjoining
ω is totally ramified at those primes, so each has a unique extension and is
still fixed. Equivalently, this is the usual cyclotomic decomposition-group
criterion t0 mod 65∈<3> for the 3-free conductor 65.

The theorem gives D^(133)=η X^j D for an Eisenstein root of unity η.
Since σ133 acts identically on the coefficients Z[ω], augmentation gives

    augmentation(D)=η augmentation(D).

Equation (5) gives |augmentation(D)|²=27, so this number is nonzero and η=1.
Finally gcd(133−1,65)=1 permits a group translation removing X^j.
After that translation D is constant on the multiplication-by-3 orbits of C65.

### Step 4. The augmentation gap

The orbit sizes are 1,4, four copies of 3, and four copies of 12. Since the
support is a union of orbits and has size 27, the size-1 and size-4 orbits
must both be absent: reducing support size modulo 3, their two indicators
have sum 0 modulo 3 and belong to {0,1}. The remaining equation is

    12k+3l=27,      0≤k,l≤4,

whose only solution is k=2,l=1. Therefore

    augmentation(D)=12u+12v+3w=3(4u+4v+w)

for Eisenstein units u,v,w. Its squared absolute value must equal 27, so
|4u+4v+w|=√3. If v=−u, that absolute value is 1. Otherwise u+v is a
nonzero Eisenstein integer, hence |u+v|≥1, and the reverse triangle inequality
gives |4(u+v)+w|≥4−1=3. Neither alternative equals √3. Contradiction. ∎

## Independent computational checks

`contractions65.py` exhausts all normalized multiplier-fixed integer contractions
using augmentation, energy, and exact correlations. It checks 3,388 augmentation/
energy candidates, finds 8 solutions in 2 equivalence classes, and every solution
has coefficients 0,±3. This agrees with the 2021 table.

`eisenstein65.py` checks all 864 orbit-unit possibilities after global phase
normalization. Four survive correlation at shift 1 and none survive shift 2;
the four shift-2 residuals are all −3. This is redundant verification because
Step 4 now eliminates the entire set using augmentation alone.

`audit_handproof.py` separately checks all reduced t=0,2,4 branches: there
are 12 survivors at t=0, all with α=0 and c_i divisible by 3, and none at
t=2 or t=4. It also enumerates possible scaled augmentation norms, obtaining
{1,9,13,21,25,37,49,57,61,73,81}; the required value 3 is absent.

## What transfers, and what does not

The mechanism transferred from the earlier work is to retain character
information inside fibers, force the remaining bounded coefficients to the
boundary of their feasible intervals, then exploit a discrete gap in the
augmentation norm. In the present setting the group-ring relation is quadratic,
so a mere congruence shadow cannot replace the norm constraints. Existing
multiplier theorems legitimately force symmetry; assuming that symmetry at the
outset without the theorem would prove only a restricted nonexistence result.

There is a clean obstruction to naively using only the maximal 2-power quotient
for the circulant Hadamard conjecture. For every odd u, let n=4u². Contract a
binary sequence to C4 by summing the u² coefficients in each residue class.
The candidate quotient vector

    B=(u,u,u,−u)

has the correct odd parity, lies in the coefficient bounds [−u²,u²], and
satisfies BB*=4u². Each B_j also lifts to a sum of u² signs, since
(u²+B_j)/2 is an integer between 0 and u². Thus this quotient, its complete
Fourier norm constraints, and all fiber parity conditions are feasible at
EVERY odd u. This disproves the proposed stronger transfer principle that such
a shadow alone decides these Hadamard orders.

For u=3, the exact audit stores a length-36 binary lift with quotient
autocorrelation (36,0,0,0), but full autocorrelation at shift 1 equal to 24.
The missing information is precisely in nonprincipal characters of the odd
kernel. No new result about Ryser's general conjecture, perfect binary sequences,
or cyclic Menon difference sets is claimed here.

## Priority and publication caution

Primary evidence for open status is the explicit 2021 Table 10 entry. The
latest relevant preprint located, dated September 2026, settles eight different
parameters. Targeted searches found no later (195,81) resolution, but this is
not an exhaustive bibliographic proof of priority. The theorem's mathematical
validity and its novelty are separate questions. The original generalized
multiplier source, rather than solely the recent preprint, was read and checked.
