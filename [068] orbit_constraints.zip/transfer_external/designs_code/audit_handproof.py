"""Independent finite arithmetic checks for the hand proof and transfer limit."""
from itertools import product
import json
from pathlib import Path

vectors=list(product(range(-3,4),repeat=4))
branches={0:[],2:[],4:[]}
for alpha in (-1,0,1):
    for d in vectors:
        t=sum(x*x for x in d)
        if t not in branches or sum(d):continue
        for c in vectors:
            if sum(c)!=3-alpha:continue
            if sum(x*x for x in c)+4*t!=27-3*alpha*alpha:continue
            if 2*sum(x*y for x,y in zip(c,d))+3*t:continue
            branches[t].append({'alpha':alpha,'c':c,'d':d})
assert not branches[2] and not branches[4]
assert all(z['alpha']==0 and all(x%3==0 for x in z['c'])for z in branches[0])

units=[(1,0),(-1,0),(0,1),(0,-1),(-1,-1),(1,1)]
norms=set()
for v,w in product(units,repeat=2):
    a=4+4*v[0]+w[0];b=4*v[1]+w[1]
    norms.add(a*a-a*b+b*b)
assert 3 not in norms

# A fully binary length-36 lift of the perfectly flat C4 contraction.
u=3;n=4*u*u;target=[u,u,u,-u];binary=[0]*n
for r,b in enumerate(target):
    positives=(u*u+b)//2
    for j in range(u*u):binary[r+4*j]=1 if j<positives else -1
actual=[sum(binary[j]*binary[(j+t)%n]for j in range(n))for t in range(n)]
shadow=[sum(binary[r+4*j]for j in range(u*u))for r in range(4)]
shadow_corr=[sum(shadow[j]*shadow[(j+t)%4]for j in range(4))for t in range(4)]
assert shadow==target and shadow_corr==[36,0,0,0] and any(actual[1:])
out={'handproof_branches':{t:len(v)for t,v in branches.items()},
     'handproof_survivors':branches[0],
     'unit_augmentation_scaled_norms':sorted(norms),
     'fake_hadamard_shadow':{'order':n,'binary_lift':binary,
       'quotient_sums':shadow,'quotient_autocorrelation':shadow_corr,
       'full_autocorrelation':actual}}
Path('transfer_external/designs_code/handproof_audit.json').write_text(json.dumps(out,indent=2))
print('branch counts',out['handproof_branches'])
print('possible scaled augmentation norms',sorted(norms))
print('shadow autocorrelation',shadow_corr,'first full off-peak',actual[1])
