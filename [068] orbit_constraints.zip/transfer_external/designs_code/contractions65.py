"""Exhaust all 3-invariant ICW_3(65,81), normalized augmentation 9."""
import json
from math import gcd, isqrt
from pathlib import Path
from time import perf_counter

n=65
unused=set(range(n)); orbits=[]
while unused:
    x=min(unused); orb=[]
    while x not in orb:
        orb.append(x); x=3*x%n
    unused.difference_update(orb);orbits.append(orb)
order=sorted(range(len(orbits)),key=lambda i:-len(orbits[i]))
weights=[len(orbits[i])for i in order]
values=[0]*len(orbits)
solutions=[]; candidates=0; nodes=0
begun=perf_counter()

def recurse(j,total,energy):
    global candidates,nodes
    nodes+=1
    if j==len(order):
        if total!=9 or energy!=81:return
        candidates+=1
        b=[0]*n
        for orb,v in zip(orbits,values):
            for x in orb:b[x]=v
        if any(sum(b[x]*b[(x+t)%n]for x in range(n))for t in range(1,33)):
            return
        solutions.append(b)
        return
    remaining=sum(weights[j:])
    if (9-total)**2>remaining*(81-energy):return
    w=weights[j];i=order[j]
    maxv=min(3,isqrt((81-energy)//w))
    for v in range(-maxv,maxv+1):
        values[i]=v
        recurse(j+1,total+w*v,energy+w*v*v)

recurse(0,0,0)
def canonical(b):
    return min(tuple(b[(u*x+s)%n]for x in range(n))
               for u in range(1,n)if gcd(u,n)==1 for s in range(n))
classes=sorted(set(canonical(b)for b in solutions))
result={'n':n,'weight':81,'bound':3,'multiplier':3,'orbits':orbits,
        'nodes':nodes,'sum_energy_candidates':candidates,
        'normalized_solutions':solutions,'equivalence_classes':classes,
        'seconds':perf_counter()-begun}
Path('transfer_external/designs_code/contractions65.json').write_text(json.dumps(result,indent=2))
print({k:v for k,v in result.items()if k not in ['orbits','normalized_solutions','equivalence_classes']})
print('solutions',len(solutions),'classes',len(classes))
for b in classes:print([(i,v)for i,v in enumerate(b)if v])
