#!/usr/bin/env python3
"""Independent exact checks for the hand proof, not needed as a proof oracle."""
from itertools import product
from math import gcd
import json
from pathlib import Path

# Independently derive orbits in CRT coordinates, not from discovery JSON.
unused = set(product(range(5), range(13)))
orbits = []
while unused:
    start = min(unused)
    orbit = []
    u = start
    while u not in orbit:
        orbit.append(u)
        u = (3*u[0] % 5, 3*u[1] % 13)
    unused.difference_update(orbit)
    orbits.append(orbit)
sizes = sorted(map(len, orbits))
assert sizes == [1,3,3,3,3,4,12,12,12,12]
assert gcd(27,65) == gcd(133,195) == gcd(132,65) == 1
assert 133 % 3 == 1 and 133 % 65 == 3

# C5 projection forces x=9,y=0. Bounds below exceed all projected bounds.
projection_solutions = [(x,y) for x in range(-39,40)
                        for y in range(-39,40)
                        if x+4*y == 9 and x*x+4*y*y == 81]
assert projection_solutions == [(9,0)]

# Verify the complete residual small system after the proved Cauchy bound.
quadruples = list(product(range(-3,4), repeat=4))
ds = [d for d in quadruples if sum(d) == 0 and sum(v*v for v in d) <= 4]
moment_solutions = []
for alpha in (-1,0,1):
    for d in ds:
        t = sum(v*v for v in d)
        for c in quadruples:
            if sum(c) != 3-alpha:
                continue
            if sum(v*v for v in c)+4*t != 27-3*alpha*alpha:
                continue
            if 2*sum(v*w for v,w in zip(c,d))+3*t != 0:
                continue
            moment_solutions.append((alpha,c,d))
assert len(moment_solutions) == 12
assert all(alpha == 0 and d == (0,0,0,0)
           and sorted(c) == [-3,0,3,3] for alpha,c,d in moment_solutions)

support_patterns = [(a,b,c,d) for a,b in product((0,1),repeat=2)
                    for c,d in product(range(5),repeat=2)
                    if a+4*b+3*c+12*d == 27]
assert support_patterns == [(0,0,1,2)]

units = [(1,0),(-1,0),(0,1),(0,-1),(-1,-1),(1,1)]
def norm(z):
    a,b=z
    return a*a-a*b+b*b
assert all(norm(u)==1 for u in units)
norms = sorted({norm((4*u[0]+4*v[0]+w[0],4*u[1]+4*v[1]+w[1]))
                for u,v,w in product(units,repeat=3)})
assert 3 not in norms

report = {
    "status": "PASS",
    "crt_orbit_sizes": sizes,
    "C5_projection_solutions": projection_solutions,
    "residual_moment_solutions": len(moment_solutions),
    "all_moment_solutions": "alpha=0, d=0, c a permutation of (-3,0,3,3)",
    "support_orbit_pattern_counts_1_4_3_12": support_patterns,
    "possible_norms_4u_plus_4v_plus_w": norms,
    "scope": "Exact redundant checks; mathematical multiplier proof audited separately",
}
Path(__file__).with_suffix(".json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps(report,indent=2))
