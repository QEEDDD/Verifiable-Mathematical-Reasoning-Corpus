# Independent adversarial audit: nonexistence of CW(195,81)

Reviewed proof: `cw195_proof.md`, 24 October 2026.

**Verdict:** the four-step hand proof is mathematically sound. I independently
reconstructed the contraction identities and checked every bounded-integer
case, the ramified-prime multiplier hypothesis, translation/phase removal,
and the final augmentation contradiction. Neither finite enumeration is
needed for the conclusion. This is internal mathematical review, not external
peer review or a claim of exhaustive priority verification.

## 1. Contraction and complete integer case analysis

For a putative group-ring weighing matrix A, the C3-principal contraction B
has coefficients in [-3,3], augmentation 9 after a global sign change, and
BB*=81. The standard prime-power multiplier applies to B because (3,65)=1.
A translate may therefore be taken invariant under multiplication by 3.
This property is not being incorrectly asserted for the original A of
order 195, where 3 is not a unit.

In CRT coordinates C5 x C13, the ten multiplier orbits are precisely the
blocks of sizes 1,4, four times 3, and four times 12 used in the proof.
The product blocks are single orbits because the local lengths 4 and 3
are coprime. Write their coefficients as a,b,c_i,d_i.

The C5 projection has coefficients x=a+3 sum(c_i), y=b+3 sum(d_i), with
x+4y=9 and x²+4y²=81. The only integral solution is x=9,y=0. Thus
a=3 alpha, b=3 beta, sum(c_i)=3-alpha, sum(d_i)=-beta.

If beta is nonzero, the C13 energy bound forces alpha=-beta and its
identity coefficient is ±9, exhausting all projected energy. Every
c_i+4d_i vanishes; since |c_i|<=3 this forces d_i=0, contradicting their
sum. Hence beta=0.

The remaining identities are exactly

    sum(d)=0, sum(c)=3-alpha,
    ||c||²+4t=27-3alpha², c·d=-3t/2, t=||d||².

Cauchy-Schwarz and parity give t in {0,2,4}. The proof's exclusions of
t=4 and t=2 are exhaustive. For t=4, d has two entries +1 and two -1;
the two pair sums are inconsistent for alpha=0 and have minimum squared
norm 10 or 14 when alpha=±1, exceeding 8. For t=2, d=(1,-1,0,0) after
permutation. The first c-pair has difference -3 and squared norm 5 or 9.
The residual norms 7,11,14 are impossible sums of two squares. The
remaining norm 10 would require residual sum 0 or 6, neither possible.

At t=0, alpha=±1 would give four squares totaling 24 with each variable
bounded by 3; the modulo-4/modulo-8 argument in the proof is correct.
Thus alpha=0 and the c-squares total 27. Exactly three coefficients are
±3 and the fourth is zero. Their sum 3 means two positive and one negative.
In particular all coefficients of B are divisible by 3.

Translation of B does not cause a lifting gap: coefficientwise divisibility
by 3 is unchanged by translation, or the translation may be lifted to A.

## 2. The nonprincipal contraction

A three-entry fibre of sum ±3 is constant and has zero nonprincipal
C3-character value. A fibre of sum zero is either zero or a permutation
of (1,-1,0). Its nonzero value is (1-omega) times a sixth root of unity.
Therefore D=E/(1-omega) belongs to Z[omega][C65], all coefficients are
zero or Eisenstein units, and DD*=27. The identity coefficient gives
support size exactly 27. This argument agrees with Tan 2026, Theorem 3.1;
it is established machinery, not a new general reduction theorem.

## 3. Why the multiplier t=133 is legitimate

Let K=Q(zeta_195), K0=Q(zeta_65), and E=Q(omega). The prime 3 is
unramified in K0, and adjoining omega gives a totally ramified quadratic
extension at each prime above 3. One elementary local justification is
that lambda=1-omega satisfies the Eisenstein polynomial
lambda²-3lambda+3 over each unramified completion of K0 at 3.

The automorphism sigma_133 restricts to Frobenius sigma_3 on K0 and fixes
omega, since 133=3 mod65 and 133=1 mod3. Frobenius lies in the
decomposition group of every prime above 3 in the abelian field K0.
The unique extension of each such prime to K is therefore also fixed.
Thus sigma_133 fixes every prime above 3 in K, exactly as required by
Tan 2018, Theorem 3.4 / Tan 2026, Result 2.4.

The other hypotheses are explicit: gcd(27,65)=1,
gcd(133,195)=1, and gcd(132,65)=1. The multiplier theorem gives
D^(133)=eta g D. Augmentation is unchanged by the coefficient
automorphism and by group translations. Its norm is 27 and it is nonzero,
so eta=1. The equation h^132=g^(-1) has a solution in C65, removing
the group translate. Thus a translate of D is constant on x -> 3x.

### A self-contained proof of the needed multiplier step

The cited theorem can be replaced by the following argument in this
specific situation. Put

    F = D^(133) D* / 27 in (1/27) Z[omega][C65].

For every character chi of C65, z=chi(D) is a nonzero cyclotomic integer
with z conjugate(z)=27. Its ideal factors only over 3. Since sigma_133
fixes each prime over 3, sigma_133(z)/z is an algebraic unit. Hence

    chi(F) = sigma_133(z)/z

is integral. Character inversion gives 65 F_g integral in K for every
coefficient F_g. Since F_g belongs to E, integrality in K implies
65 F_g belongs to the ring of integers of E, namely Z[omega]. Also
27 F_g belongs to Z[omega] by construction. Bezout's identity for
65 and 27 therefore shows F_g belongs to Z[omega].

Now FF*=1. Its identity coefficient says sum_g Norm(F_g)=1.
Eisenstein norms are nonnegative integers, so precisely one coefficient
is an Eisenstein unit and the rest are zero: F=eta g. Multiplication by
D yields the required multiplier identity. This avoids an assumption
about orders in a group algebra or the use of an unproved field-descent
normalization. The same argument, with 81 in place of 27 and integral
coefficients, justifies the initial multiplier normalization of B.

## 4. Final orbit and augmentation obstruction

The support size 27 and orbit sizes imply the size-1 and size-4 orbits
are absent modulo 3. The remaining equation 12k+3l=27 with 0<=k,l<=4
has only k=2,l=1. Thus augmentation(D)=3(4u+4v+w) for Eisenstein units.
If u+v=0 its absolute value divided by 3 is 1. Otherwise u+v is a
nonzero Eisenstein integer, hence has absolute value at least 1, and
the reverse triangle inequality gives |4(u+v)+w|>=3. Neither is sqrt(3),
contradicting the norm-27 augmentation. No correlation enumeration is
used in this final contradiction.

## Primary sources and present-table check

- Arasu–Gordon–Zhang, *New Nonexistence Results on Circulant Weighing
  Matrices*, 2021, Table 10 explicitly lists (195,81) as open. Table 9
  lists two contraction equivalence classes for ICW_3(65,81):
  https://arxiv.org/html/1908.08447v3 .
- Tan, *Group Invariant Weighing Matrices*, 2018, Theorem 3.4 and
  Corollary 3.5(b), checked in the actual paper:
  https://arxiv.org/pdf/1610.01914 .
- Tan, *Character and Multiplier Obstructions for Circulant Weighing
  Matrices*, v2, 1 September 2026, states the exact multiplier theorem
  as Result 2.4 and the C3 reduction as Theorem 3.1. Its eight exclusions
  do not include (195,81): https://arxiv.org/html/2608.18468v2 .
- The current La Jolla repository was fetched on 24 October 2026 from
  https://raw.githubusercontent.com/dmgordo/circulant-weighing-matrices/main/cwm.json .
  It records `"CW(195,9)": {"status":"Open","comment":""}`; this
  database uses the square root of the weight in its second argument.
  The raw snapshot is `cwm_snapshot.json`, SHA256
  `569a51b9c899cfe0363e8811f9afc467a1bdfe1472e69a8dc950f989fd0b4af5`.
  The upstream file contains a trailing comma before its closing brace;
  the status was extracted after removing only that syntactic comma.

The repository is not fully synchronized with Tan's September exclusions
(some of those are still marked open), so it is not by itself an exhaustive
current-literature guarantee. However the primary 2021 table, the current
repository, and the latest located 2026 paper consistently support treating
(195,81) as a previously unresolved listed case. No prior nonexistence
proof for this parameter was found in the targeted search. Appropriate
claim: a proved exclusion of this parameter, with priority provisional
pending external expert review—not a newly invented multiplier theorem.
