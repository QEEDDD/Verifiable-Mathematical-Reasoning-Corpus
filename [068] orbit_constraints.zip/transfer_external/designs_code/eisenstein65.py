"""Exact 3-invariant Eisenstein unit sequences on C65, weight 27."""
import itertools,json
from pathlib import Path

base=json.loads(Path('transfer_external/designs_code/contractions65.json').read_text())
orbits=base['orbits'];n=65
units=[(1,0),(-1,0),(0,1),(0,-1),(-1,-1),(1,1)]
def product(x,y):
    a,b=x;c,d=y;return a*c-b*d,a*d+b*c-b*d
def conjugate(x):return x[0]-x[1],-x[1]
def corr(a,t):
    s=u=0
    for i in range(n):
        c,d=product(a[(i+t)%n],conjugate(a[i]));s+=c;u+=d
    return s,u

big=[i for i,o in enumerate(orbits)if len(o)==12]
small=[i for i,o in enumerate(orbits)if len(o)==3]
counts=[0]*33;solutions=[];last=[]
for pair in itertools.combinations(big,2):
    for s in small:
        chosen=list(pair)+[s]
        for vv in itertools.product(units,repeat=2):
            a=[(0,0)]*n
            for j,v in zip(chosen,[(1,0)]+list(vv)):
                for x in orbits[j]:a[x]=v
            counts[0]+=1
            for t in range(1,33):
                if corr(a,t)!=(0,0):break
                counts[t]+=1
            else:solutions.append(a)
            if t>1:last.append({'orbits':chosen,'values':[(1,0)]+list(vv),'last_shift':t,'residual':corr(a,t)})
result={'orbit_sizes':[len(o)for o in orbits], 'candidate_count':counts[0],
        'successive_correlation_survivors':counts[1:],
        'solutions':solutions,'survivors_through_shift2':last}
Path('transfer_external/designs_code/eisenstein65.json').write_text(json.dumps(result,indent=2))
print(result if not solutions else {'counts':counts,'solutions':len(solutions)})
