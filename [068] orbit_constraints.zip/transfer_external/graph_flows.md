# Graph-flow transfer: exact obstruction, no claimed conjecture closure

Research checkpoint, 24 October 2026. This investigation targets Tutte's
3-flow conjecture and related modulo orientations. It establishes a
concrete impossibility for the proposed quotient-averaging transfer.
It does not prove Tutte's conjecture or claim a new general graph theorem.

## Current primary-source status

- Jiaao Li and Xinyuan Li, *Nowhere-zero 3-flows in graphs with forbidden
  edge-cuts*, arXiv:2609.08377, 8 September 2026, states Tutte's conjecture
  and proves the case of 4-edge-connected, essentially
  41-edge-connected graphs. Primary abstract:
  https://arxiv.org/abs/2609.08377 . Search retrieval exposed the complete
  abstract; direct page retrieval was unavailable.
- Amir Jafari, *Graphic additive bases and graph flows*,
  arXiv:2610.07034v3, 16 October 2026, uses a lattice-coset method and
  integral rounding. Its stated results include prescribed orientations
  from q edge-disjoint spanning trees and a 3-flow theorem for
  4-edge-connected graphs with no bond of size 6, 7, or 8. Primary text:
  https://arxiv.org/html/2610.07034v3 . This very recent preprint must be
  checked before claiming novelty for a generic lattice-coset approach.
- Davide Mattiolo, *On removable edge subsets in graphs with a
  nowhere-zero 4-flow*, arXiv:2511.01556v1, 3 November 2025, still states
  two separate conjectures: every bridgeless graph has a 3-flow covering
  at least 5/6 of its edges; every cubic graph with a nowhere-zero
  4-flow has a 4-removable edge. It proves the first for graphs having
  a nowhere-zero 4-flow. Primary text:
  https://arxiv.org/html/2511.01556v1 .
- Lovasz, Thomassen, Wu, and Zhang, *Nowhere-zero 3-flows and modulo
  k-orientations* (2013), proves the 6-edge-connected case of Tutte's
  3-flow conjecture. Institutional primary record:
  https://orbit.dtu.dk/en/publications/nowhere-zero-3-flows-and-modulo-emkem-orientations/ .

These sources support treating the full Tutte 3-flow problem as an
unresolved target, rather than overlooking the recent substantial
partial results.

## The modular-to-bounded-integer step is already exact

Fix an orientation and its vertex-edge incidence matrix B. Suppose
`a∈{1,...,k−1}^E` represents a nowhere-zero Z/kZ-flow, so `Ba=k b`
for an integer vector b. The polytope

    Bz=b,  0≤z≤1

is nonempty: `z=a/k` belongs to it. Total unimodularity of B gives an
integral vertex z, hence `z∈{0,1}^E`. Then

    f=a−kz

is an integer circulation, has the prescribed residues, and satisfies
`0<|f(e)|<k` on every edge. This is the standard graph-flow lifting
mechanism, not a new theorem.

In particular, for a fixed orientation, a circulation congruent to 1
on every edge modulo p exists exactly when `B1=0 mod p`, and when it
exists the bounded representatives can be chosen from `{1,1−p}`.
The unsolved difficulty in Tutte's problem is choosing the nonzero
residues, or equivalently an appropriate orientation at p=3. It is
not a hidden saturation obstruction after the residues have been chosen.

## A concrete failure of prime-to-p quotient averaging

Take `G=K5`, with vertices `0,1,2,3,4`. Orient the edges as a regular
tournament on Z/5Z: `i→j` when `j−i` is 1 or 2 modulo 5. Value 1
on every directed edge is an integer circulation. Thus K5 has a
nowhere-zero 2-flow, and therefore a nowhere-zero 3-flow. Its edge
connectivity is 4, so it lies inside Tutte's conjectured class.

Let the cyclic group C4 fix vertex 0 and rotate vertices 1,2,3,4.
It acts on signed edge cochains and preserves the flow equations.
Its order is invertible modulo 3, so averaging is legitimate as a
linear operation over Z_(3) or F3.

However, in any invariant flow the four outward spoke values at
vertex 0 must be one common value a. Conservation gives `4a=0`.
Over F3 this forces `a=0`. Consequently:

> K5 has a nowhere-zero Z3-flow, but has no C4-invariant nowhere-zero
> Z3-flow, even though the averaging group has order prime to 3.

For the displayed integer 2-flow the exact C4 average is the unit
circulation on the outer 4-cycle. All four spokes and both diagonals
become zero. This is verified with rational arithmetic in
`graph_flows_code/averaging_counterexample.py`; the complete result is
in the adjacent JSON file. The code also checks the original flow
and all cuts establishing edge connectivity 4.

This counterexample rules out the direct analogue of the Okada
existence-preserving averaging theorem for nowhere-zero graph flows.
The reason is precise: the allowed alphabet `F3\{0}` is not an affine
coset preserved by averaging. If one normalizes values to 1 by reversing
edges, the automorphism action no longer preserves that all-ones coset.
No amount of exact verification of the smaller quotient repairs this
loss of the feasible set.

## Attempted support elimination

A circulation can be altered along a cycle while preserving all
vertex equations. Over F3, changing by `t c` along a cycle forbids
one value of t for every edge whose nonzero status is to be protected.
Different edges can forbid all three residues. Thus the linear
elimination step that worked for a congruence coset has no automatic
support-preserving analogue. The K5 example proves that an attempted
elimination all the way to the C4-invariant subspace cannot always
be made support preserving.

One elementary positive check was reconstructed: every bridgeless graph
with at most two odd-degree vertices has a nowhere-zero 3-flow. If
there are two such vertices, every cut separating them is odd and
has size at least 3. Three edge-disjoint paths join them. Their union
carries a 3-flow with path values 1,1,−2, and its edge
complement is Eulerian and carries a 2-flow. The union is a 3-flow.
This is a basic known-type special case and is not presented as a
new closure. The substantially stronger four-odd-vertex case was
already studied by Peres and Dahab; their primary conference poster
states a characterization:
https://www.lawcg.mat.br/lawcg20/posters/LAWCG2020_poster_40.pdf .

## A concrete remaining route, not a proved result

For the 5/6-support conjecture, averaging a probability distribution
of flows is legitimate: it preserves expected support probabilities,
unlike averaging the flows themselves. In an edge-transitive
3-edge-connected graph, the established 5/6 support theorem can be
symmetrized to make every edge nonzero with probability at least 5/6.
A prospective extension through 2-edge-cut decompositions would need
compatible marginal distributions on virtual edges. Exact support
probabilities can be equalized by mixing with the zero flow, and the
two nonzero F3 values can be symmetrized by scalar multiplication.
The remaining work is a rigorous decomposition-and-coupling theorem
and a novelty check. No general 5/6 claim is made here.

The honest result of this transfer attempt is therefore a proved
failure mode and a narrowed probabilistic alternative, not a solution
of a named graph conjecture.
