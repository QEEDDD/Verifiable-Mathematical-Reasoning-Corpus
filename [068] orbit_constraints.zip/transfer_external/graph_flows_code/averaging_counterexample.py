"""Exact arithmetic certificates for failure of flow-support averaging."""
from fractions import Fraction
from itertools import combinations
import json

vertices = range(5)
edges = list(combinations(vertices,2))
# Regular tournament orientation on Z/5: the signed value on i->j is
# +1 if j-i is 1 or 2 modulo 5, and -1 otherwise.
f = {(i,j): 1 if (j-i)%5 in (1,2) else -1 for i,j in edges}

def value(flow,i,j):
    return flow[(i,j)] if i<j else -flow[(j,i)]

def boundary(flow):
    return {i:sum(value(flow,i,j) for j in vertices if j!=i) for i in vertices}

def perm(i,k):
    return 0 if i==0 else 1+(i-1+k)%4

images = []
for k in range(4):
    images.append({(i,j):value(f,perm(i,k),perm(j,k)) for i,j in edges})
averaged = {e:sum(F[e] for F in images)/Fraction(4) for e in edges}
assert all(x==0 for x in boundary(f).values())
assert all(x==0 for x in boundary(averaged).values())
assert all(averaged[(0,i)]==0 for i in range(1,5))
assert all(abs(x)==1 for x in f.values())

# Every invariant Z3-flow has one common outward value a on the four
# spokes. Conservation at the fixed vertex requires 4a=0, so a=0.
allowed_spoke_residues = [a for a in range(3) if 4*a%3==0]
assert allowed_spoke_residues == [0]
cuts = [sum((i in subset)!=(j in subset) for i,j in edges)
        for mask in range(1,31)
        for subset in [{i for i in vertices if mask>>i&1}]]
assert min(cuts)==4
print(json.dumps({
    'graph':'K5', 'edge_connectivity':min(cuts),
    'integer_2_flow':[[*e,f[e]] for e in edges],
    'C4_average':[[*e,str(averaged[e])] for e in edges],
    'spoke_values_in_any_invariant_Z3_flow':allowed_spoke_residues,
    'all_checks_passed':True},indent=2))
