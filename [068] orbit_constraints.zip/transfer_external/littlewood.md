# Littlewood and equipowerful-partition transfer attempt

Date: 2026-10-24. This is a different problem from Erdős/Okada. **No Littlewood conjecture is claimed solved by this investigation.**

## The existing questions, checked against the published version

Write P(N,m) for the Littlewood polynomials of length N divisible by (x−1)^m, and m*(N) for their maximum possible order at 1.

The primary target was the published unresolved alternative **m*(240)=10 or 11**, equivalently whether P(240,11) is empty. Buhler–Golan–Pratt–Wagon's final 2021 article gives this alternative in Table 2 and Theorem 3.3. It also reports exclusion of the appropriately antisymmetric order-11 case. Thus an unrestricted positive witness would refute their Symmetry Conjecture; an unrestricted negative proof would settle this particular published question.

The final article also asks whether **every exact-order-m polynomial at the minimum length min L_m has the expected reversal symmetry**. The paper verifies this stronger statement only for m≤6. We therefore tested nonsymmetric minimal witnesses at (N,m)=(96,7), (144,8), and (240,10). These minimum lengths were already proved in that paper. A genuine witness with exact indicated order would answer their existing question negatively.

The old 2019 arXiv version is materially outdated: the final article already proves min L_10=240. No attempt here counts that known construction as a new result. A separate primary paper dated October 1, 2026 still states that the minimum lengths are known through order 10 and unknown at larger orders. Targeted literature searches found no later resolution of the selected questions; that search non-result alone is not a proof of their status.

## Exact translation and computational attempt

Use Boolean variables b_i with signs a_i=2b_i−1. The order-m condition is precisely

Σ_(i=0)^(N−1) a_i binom(i−N/2,j)=0,  0≤j<m.

Generalized binomial coefficients are integers, including at negative arguments. The translated equations are equivalent to the original power-moment equations because these polynomials form a basis in each degree. Fixing a_0=1 loses no solutions, by global negation.

The unrestricted 240-variable model imposed all 11 exact moment equations. A strengthened run added **341 cyclotomic integrality conditions** at orders

2,3,4,5,7,8,9,11,13,16,17,19,23,25,27,29,31,32,37,41,43.

They were derived independently as follows: in the integral basis of Z[x]/Φ_d(x), let X be multiplication by x and M=(X−I)^m. Divisibility by (x−1)^m implies M^(-1)P(X)e_0 has integral coordinates. Clearing denominators gives exact linear congruences; replacing coefficients by their centered residues changes none of those congruences. Every cut is necessary, so they cannot remove a true Littlewood solution.

Additional explicit residue-count domains were imposed. For a prime p, the mean equation and cyclotomic ramification imply every signed mod-p residue sum is divisible by

p^floor((m−1)/(p−1)).

At N=240,m=11 this forces every mod-2, mod-3, and mod-5 class sum to vanish. Mod-11 class sums lie in {−22,0,22} for the nine size-22 classes and {−11,11} for the two size-21 classes. These conditions improve propagation but are instances of the established cyclotomic constraints, not claimed new theorems.

For the minimal-witness question, the model additionally requires at least one reversed pair to disagree with the expected relation a_(N−1−i)=(−1)^m a_i. A returned witness is independently checked using exact integer binomial moments, including the next moment to determine exact order.

## Results

- The published length-240, order-10 symmetric witness was reproduced as a positive control and checked by exact arithmetic.
- The unrestricted (240,11) search with 55 cyclotomic rows returned **UNKNOWN** after 300 seconds: 389,353 branches, no witness and no infeasibility proof.
- The strengthened unrestricted search with 341 cyclotomic rows returned **UNKNOWN** after 300 seconds: 49,699 branches, no witness and no infeasibility proof.
- Residue-only models, with and without antisymmetry, also returned **UNKNOWN** at their 90- or 120-second limits.
- The three minimum-length asymmetry searches all returned **UNKNOWN** after 180 seconds each: (96,7), 817,213 branches; (144,8), 907,544 branches; (240,10), 274,408 branches. None supplied a counterexample or a proof of symmetry.

The scripts and all solver outputs are in `transfer_external/littlewood/`. No result is inferred from a time limit or from imposing the conjectured symmetry restriction.

## A precise limitation of the transferred 2-adic method

The target has an explicit all-odd integer solution even with antisymmetry:

P_odd(x)=(x−1)^15(1+x^16+x^32+⋯+x^224).

It has length 240 and exact order 15 at x=1. Each of the 15 nonoverlapping blocks is the coefficient list of (x−1)^15. Those coefficients are all odd, because (x−1)^15 reduces modulo 2 to 1+x+⋯+x^15. The first factor is antisymmetric and the second reciprocal, so the product is antisymmetric. Its maximum coefficient magnitude is 6435.

Consequently the full odd-coefficient relaxation is feasible for P(240,11), including its antisymmetric subspace. **An exact 2-adic odd-vector obstruction cannot resolve this target negatively.** The ±1 magnitude condition carries essential information; the current computational model retains it. This is a direct mathematical barrier to applying the support-elimination theorem unchanged, not a claim that other p-adic or bounded-integer methods cannot help.

`checks.py` checks the displayed polynomial, the published order-10 control, and the cyclotomic cuts using exact arithmetic. The checks are mathematical regression tests, not evidence of a new conjecture resolution.

## Primary references

1. J. Buhler, S. Golan, R. Pratt, S. Wagon, *Littlewood polynomials, spectral-null codes, and equipowerful partitions*, Mathematics of Computation 90 (2021), 1435–1453, DOI 10.1090/mcom/3612. The unresolved alternatives occur on p.1439; the Symmetry Conjecture on p.1446; the stronger minimum-witness question on p.1452. Publisher URL: https://www.ams.org/mcom/2021-90-329/S0025-5718-2021-03612-1/S0025-5718-2021-03612-1.pdf . The publisher returned HTTP403 in this session, so the published research article itself was read at this mirror: https://artefacts-discovery.researcher.life/full_text/DA-2/6b/6bc24966e25135149d15c78e65565331/full_text/6add81acc32f313d12f4141a2178cb28.pdf .
2. T. Khovanova and T. Madhavarapu, *Fair Duels after a False Start*, arXiv:2610.00880v1, October 1, 2026, Section 3. https://arxiv.org/html/2610.00880v1 . Used to check the contemporary status of the minimum-length problem; its fair-duel results were not claimed or reproved here.
