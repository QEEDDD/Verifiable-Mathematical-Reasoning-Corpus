"""Independent exact checks of the positive control and relaxation witness."""
from math import comb
from pathlib import Path
import json
from search import known_240_order10, cuts

known=[2*b-1 for b in known_240_order10()]
moments=[sum(a*comb(i,k) for i,a in enumerate(known)) for k in range(12)]
assert moments[:10]==[0]*10 and moments[10]!=0
orders=[2,3,4,5,7,8,9,11,13,16,17,19,23,25,27,29,31,32,37,41,43]
count=0
for d in orders:
    for row, denominator in cuts(d,10,240):
        assert sum(a*c for a,c in zip(known,row))%denominator==0
        count+=1
for p in (2,3,5,7):
    modulus=p**(9//(p-1))
    for r in range(p):
        assert sum(known[i] for i in range(r,240,p))%modulus==0

# (x-1)^15 * S_15(x^16), in ascending coefficient order.
block=[(-1)**(15-j)*comb(15,j) for j in range(16)]
odd=block*15
assert len(odd)==240 and all(a%2 for a in odd)
assert odd==[-a for a in odd[::-1]]
odd_moments=[sum(a*comb(i,k) for i,a in enumerate(odd)) for k in range(16)]
assert odd_moments[:15]==[0]*15 and odd_moments[15]!=0
result={
    'known_240_order10_moments':moments,
    'known_240_order10_symmetry':'symmetric',
    'cyclotomic_integrality_rows_checked':count,
    'odd_relaxation_length':240,
    'odd_relaxation_exact_order':15,
    'odd_relaxation_max_absolute_coefficient':max(map(abs,odd)),
    'odd_relaxation_symmetry':'antisymmetric',
    'odd_relaxation_formula':'(x-1)^15 * sum_{j=0}^{14} x^(16j)',
    'odd_relaxation_binomial_moments':odd_moments,
    'status':'all exact arithmetic checks passed'
}
Path(__file__).with_name('checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
