"""Unrestricted exact Littlewood moment search with cyclotomic integrality cuts.

Necessary cuts are derived independently from multiplication by (x-1)^m in
Z[x]/Phi_d(x). Unknown/time limit is never treated as infeasibility.
"""
import argparse
from fractions import Fraction
from functools import reduce
from math import comb, gcd, lcm
from pathlib import Path
import json
import time
import sympy as sp
from ortools.sat.python import cp_model


def binomial(z, k):
    return comb(z, k) if z >= 0 else (-1)**k * comb(k-z-1, k)


def cuts(d, m, n):
    x = sp.Symbol('x')
    phi = sp.Poly(sp.cyclotomic_poly(d, x), x)
    degree = phi.degree()
    constant_first = [int(phi.nth(i)) for i in range(degree)]
    X = sp.zeros(degree)
    for j in range(degree-1):
        X[j+1,j] = 1
    for i, c in enumerate(constant_first):
        X[i,degree-1] = -c
    inverse = ((X-sp.eye(degree))**m).inv()
    powers = []
    column = sp.eye(degree)[:,0]
    for j in range(d):
        powers.append(column)
        column = X*column
    answer = []
    for row in range(degree):
        rational = [(inverse[row,:]*powers[j])[0] for j in range(d)]
        denominator = lcm(*(int(v.q) for v in rational))
        numerators = [int(v*denominator) for v in rational]
        g = gcd(denominator, reduce(gcd, map(abs,numerators), 0))
        denominator //= g
        numerators = [v//g for v in numerators]
        # Only divisibility matters; centered residues preserve the condition
        # and greatly reduce coefficients for large prime cyclotomic orders.
        numerators = [(v+denominator//2)%denominator-denominator//2 for v in numerators]
        if denominator > 1:
            answer.append(([numerators[j%d] for j in range(n)], denominator))
    return answer


def known_240_order10():
    half = [int(c) for c in bin(int('C394E65AB989457A86B7D0D921636E',16))[2:].zfill(120)]
    return half + half[::-1]


def verify(bits, m):
    signs = [2*b-1 for b in bits]
    sums = [sum(a*comb(i,k) for i,a in enumerate(signs)) for k in range(m+1)]
    assert sums[:m] == [0]*m
    return sums


def main(args):
    start=time.time()
    model=cp_model.CpModel()
    bits=[model.new_bool_var(f'b{i}') for i in range(args.n)]
    model.add(bits[0]==1)
    moment_count=args.m if not args.residue_only else 1
    for k in range(moment_count):
        row=[binomial(i-args.n//2,k) for i in range(args.n)]
        total=sum(row)
        if total%2:
            raise ValueError('Parity already makes a moment impossible')
        model.add(sum(c*b for c,b in zip(row,bits))==total//2)
    if args.symmetry!='none':
        for i in range(args.n//2):
            model.add(bits[i] + bits[-1-i] == 1) if args.symmetry=='anti' else model.add(bits[i]==bits[-1-i])
    if args.require_asymmetric:
        wrong=[]
        for i in range(args.n//2):
            flag=model.new_bool_var(f'wrong_parity_pair_{i}')
            if args.m%2:
                model.add(bits[i]==bits[-1-i]).only_enforce_if(flag)
                model.add(bits[i]!=bits[-1-i]).only_enforce_if(flag.Not())
            else:
                model.add(bits[i]!=bits[-1-i]).only_enforce_if(flag)
                model.add(bits[i]==bits[-1-i]).only_enforce_if(flag.Not())
            wrong.append(flag)
        model.add_bool_or(wrong)
    count=0
    for d in args.orders:
        for row, denominator in cuts(d,args.m,args.n):
            bound=sum(map(abs,row))//denominator
            quotient=model.new_int_var(-bound,bound,f'q{d}_{count}')
            model.add(2*sum(c*b for c,b in zip(row,bits))-sum(row)==denominator*quotient)
            count+=1
    # Cyclotomic ramification plus the mean equation implies each signed
    # residue-class sum is divisible by p^floor((m-1)/(p-1)).  Make these
    # bounded domains explicit rather than asking propagation to derive them.
    for p in list(sp.primerange(2,args.m+1)):
        power=int(p**((args.m-1)//(p-1)))
        for r in range(p):
            fibre=[bits[i] for i in range(r,args.n,p)]
            size=len(fibre)
            allowed=[a for a in range(size+1) if (2*a-size)%power==0]
            residue_count=model.new_int_var_from_domain(cp_model.Domain.from_values(allowed),f'count_{p}_{r}')
            model.add(residue_count==sum(fibre))
    if args.n==240 and args.hint:
        hint=known_240_order10()
        verify(hint,10)
        for variable,value in zip(bits,hint):model.add_hint(variable,value)
    invalid=model.validate()
    if invalid:raise ValueError(invalid)
    solver=cp_model.CpSolver()
    solver.parameters.max_time_in_seconds=args.seconds
    solver.parameters.num_search_workers=args.workers
    solver.parameters.random_seed=args.seed
    solver.parameters.log_search_progress=args.log
    status=solver.solve(model)
    result={'n':args.n,'m':args.m,'symmetry':args.symmetry,
            'require_asymmetric':args.require_asymmetric,
            'residue_only':args.residue_only,'cyclotomic_orders':args.orders,
            'cyclotomic_integrality_rows':count,'status':solver.status_name(status),
            'wall_seconds':solver.wall_time,'total_seconds':time.time()-start,
            'branches':solver.num_branches,'conflicts':solver.num_conflicts,
            'response_stats':solver.response_stats()}
    if status in (cp_model.OPTIMAL,cp_model.FEASIBLE):
        result['bits']=[solver.value(b) for b in bits]
        if not args.residue_only:result['exact_binomial_moments']=verify(result['bits'],args.m)
        else:
            result['exact_binomial_moments']=[sum((2*b-1)*comb(i,k) for i,b in enumerate(result['bits'])) for k in range(args.m+1)]
    target=Path(args.output)
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('bits','response_stats')},indent=2),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--n',type=int,default=240)
    parser.add_argument('--m',type=int,default=11)
    parser.add_argument('--symmetry',choices=['none','sym','anti'],default='none')
    parser.add_argument('--seconds',type=int,default=300)
    parser.add_argument('--workers',type=int,default=4)
    parser.add_argument('--seed',type=int,default=1)
    parser.add_argument('--orders',type=int,nargs='*',default=[2,3,4,5,7,8,9,11,13,16])
    parser.add_argument('--hint',action='store_true')
    parser.add_argument('--log',action='store_true')
    parser.add_argument('--residue-only',action='store_true')
    parser.add_argument('--require-asymmetric',action='store_true')
    parser.add_argument('--output',default='transfer_external/littlewood/result_240_11.json')
    main(parser.parse_args())
