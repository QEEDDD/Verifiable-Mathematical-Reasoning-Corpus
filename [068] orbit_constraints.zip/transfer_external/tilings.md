# External transfer checkpoint: cyclic tilings and spectral sets

Status (24 October 2026): **no new open case closed**. Work paused to
audit a potentially stronger result on circulant weighing matrices.

## Primary-source status checks

- Łaba–Londner already prove CM (T2) for periods `(pqr)^2`; this is not
  available as a new target. See the original paper:
  https://arxiv.org/abs/2106.14044 and its even-case extension
  https://personal.math.ubc.ca/~ilaba/preprints/T2-even.pdf .
- Prajapati's September 2026 preprint claims unrestricted T2 necessity:
  https://arxiv.org/html/2609.22280v1 . Its proof/formalization was not
  independently audited here. The existence of this claim prevents
  calling the full conjecture unqualifiedly untouched/open.
- Tan–Zhang's recent preprint claims Fuglede for every square-free cyclic
  group: https://arxiv.org/html/2610.02218v1 . Again this is a retrieved
  claim, not an independently verified result in this report.
- Fallon–Kiss–Mayeli–Somlai's latest version proves spectral-to-tiling for
  `Z_(p²q²r)` under `r>p²q²`:
  https://arxiv.org/abs/2308.16277 and
  https://arxiv.org/html/2308.16277v4 . The current abstract explicitly
  retains the size hypothesis. Cases such as `Z_252` lie outside it.
  The source alone does not prove that every such numerical case remains
  open under all other literature; no primary resolution of 252 was found.
- Kiss–Londner–Matolcsi–Somlai show that natural nonnegative functional
  relaxations of tilings can fail CM conditions:
  https://arxiv.org/abs/2411.03854 . This is a concrete warning against
  treating linear/positive relaxation feasibility as an actual tiling.

## Exact attempted transfer

The full primitive Fourier vanishing condition admits the same anchored
integral decomposition into functions missing a prime coordinate.
However, that decomposition does not preserve nonnegativity or Boolean
values. The obstacle is already present in the classical asymmetric
Lam–Leung vanishing sum; it is not a new theorem.

For example, in `Z_30`, let `A={5,6,12,18,24,25}`. Its mask polynomial
vanishes exactly at primitive 30th roots among nontrivial divisor orders.
In CRT coordinates this is

`{(1,j,0): j=1,2} union {(0,0,k): k=1,2,3,4}`.

At a fully primitive character its sum is `(-1)(-1)+(-1)=0`.
But A contains no full fibre in any prime coordinate, so its indicator
cannot be a nonnegative sum of coordinate-independent indicators.
The anchored decomposition must use cancellation. Moreover A is not
spectral: its only zero order is 30, so distinct spectral frequencies
would have to differ by units modulo 30. All such differences are odd,
which permits at most two frequencies, not six.

The underlying classical source is Lam–Leung, *On Vanishing Sums of Roots
of Unity*, J. Algebra 224 (2000), 91–109:
https://doi.org/10.1006/jabr.1999.8089 . This example is recorded solely
to locate precisely where the transferred proof strategy fails.

## Finite constrained search

`tilings/spectral_252_probe.py` encodes exact cyclotomic divisibility and
spectral orthogonality with Boolean variables. It attempted a restricted
42-point spectral pair in `Z_252`, with a unit spectrum difference,
`Phi_2,Phi_3,Phi_7 | A`, and `Phi_42` not dividing A. After 60 seconds the
solver returned UNKNOWN (715191 branches, 87362 conflicts). No witness
and no exclusion certificate resulted. This is not evidence of a theorem.

Some restricted branches may already follow by inspecting the later
steps of the Fallon–Kiss–Mayeli–Somlai proof under weaker hypotheses than
their global theorem. That comparison remains unfinished, so even a
future solver exclusion of this particular branch must not be advertised
as a newly resolved open case without further literature/proof checking.

The usable methodological conclusion is limited: retain exact Boolean
constraints and certify any elimination by an independently checked
integer inequality. The present integral support-elimination lemma alone
does not preserve the properties that a tiling/spectral argument needs.
