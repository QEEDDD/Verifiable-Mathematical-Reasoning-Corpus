#!/usr/bin/env python3
"""Exploratory exact constraints for a restricted unresolved cyclic case.

Seek a spectral pair of cardinality 42 in Z_252 with a unit spectrum
difference, A divisible by Phi_2,Phi_3,Phi_7, but not Phi_42.
An UNKNOWN run is not a mathematical conclusion. A positive result is
independently checked by exact polynomial division before being reported.
"""
import json
from pathlib import Path
import sympy as s
from ortools.sat.python import cp_model

N, size = 252, 42
x = s.Symbol("x")
divs = [int(d) for d in s.divisors(N) if d > 1]
model = cp_model.CpModel()
A = [model.new_bool_var(f"a{j}") for j in range(N)]
L = [model.new_bool_var(f"l{j}") for j in range(N)]
zero = {d: model.new_bool_var(f"zero{d}") for d in divs}
model.add(sum(A) == size)
model.add(sum(L) == size)
model.add(A[0] == 1)
model.add(L[0] == 1)
model.add(L[1] == 1)  # Restricted to spectra with a unit difference.
rows = {}
for d in divs:
    phi = s.Poly(s.cyclotomic_poly(d, x), x)
    deg = phi.degree()
    remainders = [s.Poly(s.rem(x**j, phi.as_expr(), x), x)
                  for j in range(d)]
    rows[d] = [[int(remainders[j % d].nth(k)) for j in range(N)]
               for k in range(deg)]
    for row in rows[d]:
        model.add(sum(v*A[j] for j, v in enumerate(row) if v) == 0).only_enforce_if(zero[d])
for i in range(N):
    for j in range(i):
        order = N // int(s.gcd(i-j, N))
        model.add_bool_or([L[i].Not(), L[j].Not(), zero[order]])
for d in (2, 3, 7):
    model.add(zero[d] == 1)
abs42 = []
for k, row in enumerate(rows[42]):
    v = model.new_int_var(-size, size, f"rem42_{k}")
    u = model.new_int_var(0, size, f"abs42_{k}")
    model.add(v == sum(c*A[j] for j, c in enumerate(row) if c))
    model.add_abs_equality(u, v)
    abs42.append(u)
model.add(sum(abs42) >= 1)
model.add(zero[42] == 0)
solver = cp_model.CpSolver()
solver.parameters.max_time_in_seconds = 60
solver.parameters.num_search_workers = 4
solver.parameters.random_seed = 0
status = solver.solve(model)
report = {
    "N": N, "cardinality": size,
    "restriction": "unit spectrum difference; Phi_2,Phi_3,Phi_7 divide A, Phi_42 does not",
    "solver_status": solver.status_name(status),
    "wall_time_seconds": solver.wall_time,
    "branches": solver.num_branches,
    "conflicts": solver.num_conflicts,
}
if status in (cp_model.OPTIMAL, cp_model.FEASIBLE):
    aa = [j for j in range(N) if solver.value(A[j])]
    ll = [j for j in range(N) if solver.value(L[j])]
    poly = sum(x**j for j in aa)
    zeros = {d for d in divs if s.rem(poly, s.cyclotomic_poly(d,x), x) == 0}
    assert len(aa) == len(ll) == size
    assert all(N//int(s.gcd(u-v,N)) in zeros for u in ll for v in ll if u != v)
    assert {2,3,7} <= zeros and 42 not in zeros
    report.update(A=aa, L=ll, exact_zero_orders=sorted(zeros))
else:
    report["scope"] = ("No witness found; no theorem proved" if status == cp_model.UNKNOWN
                       else "Solver-only restricted exclusion; no independently checked UNSAT certificate")
Path(__file__).with_suffix(".json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps(report,indent=2))
