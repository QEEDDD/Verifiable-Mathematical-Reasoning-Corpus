T71-T75: exact verification bundle

Manuscript: Antisymmetric Floquet-Isospectral Potentials:
Existence, Local Multiplicity, and Singular Period Inflations
Author: KEIO
Date: 24 October 2026

Run in an environment with Python 3 and SymPy:
    python3 verify_T71_T75.py

Tested with SymPy 1.14.0. The program writes verify_T71_T75.json
beside the script and prints its results. All arithmetic is exact;
there are no floating-point tolerances.

Included checks:
* Period-four and period-five discriminant formulas and seed Jacobians.
* Full discriminants for the period-15 and both period-20 examples.
* Full specialized Jacobian ranks 2, 2, 2.
* Quadratic transfer/continuant identities for periods 3 through 10.
* Exact quotient lengths 2^floor(q/2) of the quadratic initial ideals.

These finite checks supplement, and do not replace, the all-period
proofs in the PDF/TEX. The manuscript resolves two numbered conjectures,
not five separate named problems. No universal historical-priority or
historically unprecedented foundational-principle certification is claimed.
Both small-period seeds have prior literature, as attributed in the paper.
