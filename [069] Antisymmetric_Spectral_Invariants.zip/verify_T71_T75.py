"""Exact checks supporting the spectral theorem manuscript (SymPy, no tolerances).

These finite checks supplement the all-period proofs; they do not replace them.
Run: python research/verify_T71_T75.py
"""
from pathlib import Path
from itertools import product
import json
import sympy as s

x,a,b=s.symbols('x a b'); ii=s.I

def reduce_poly(p, relation):
    return s.rem(s.Poly(s.expand(p),a),s.Poly(a*a-relation,a)).as_expr().expand()

def multiply(A,B,relation):
    return (A*B).applyfunc(lambda p:reduce_poly(p,relation))

def monodromy(v,relation):
    M=s.eye(2)
    for w in v:
        M=multiply(s.Matrix([[x-w,-1],[1,0]]),M,relation)
    return M

def disc(v,relation):
    return s.expand(s.trace(monodromy(v,relation)))

def disc_unrestricted(v):
    """Direct symbolic transfer trace without any seed relation."""
    M=s.eye(2)
    for w in v:
        M=(s.Matrix([[x-w,-1],[1,0]])*M).applyfunc(s.expand)
    return s.expand(s.trace(M))

def free(q):
    p0,p1=2,x
    for k in range(2,q+1):p0,p1=p1,s.expand(x*p1-p0)
    return p1

def antisymmetric(v):
    return all(s.expand(v[j]+v[-1-j])==0 for j in range(len(v)))

def full_specialized_jacobian_rank(v,relation):
    q=len(v); m=q//2
    T=[s.Matrix([[x-w,-1],[1,0]]) for w in v]
    pref=[s.eye(2)]
    for k in range(q):pref.append(multiply(T[k],pref[-1],relation))
    suff=[None]*(q+1);suff[q]=s.eye(2)
    for k in range(q-1,-1,-1):suff[k]=multiply(suff[k+1],T[k],relation)
    E=s.Matrix([[-1,0],[0,0]])
    columns=[]
    for j in range(m):
        d1=multiply(multiply(suff[j+1],E,relation),pref[j],relation)
        k=q-1-j
        d2=multiply(multiply(suff[k+1],E,relation),pref[k],relation)
        p=s.Poly(reduce_poly(s.trace(d1-d2),relation),a)
        # Every entry is a times a Gaussian rational polynomial. Since a !=0,
        # dividing every entry by a preserves the matrix rank exactly.
        assert p.nth(0)==0 and p.degree()<=1
        pp=s.Poly(p.nth(1),x)
        columns.append([pp.nth(q-2*k) for k in range(1,m+1)])
    J=s.Matrix(m,m,lambda i,j:columns[j][i])
    return int(J.rank())

def second_degree_discriminant(v):
    """Multiply transfer matrices, retaining degrees0,1,2 in potentials."""
    A=s.Matrix([[x,-1],[1,0]])
    M0=s.eye(2); M1=s.zeros(2); M2=s.zeros(2)
    for w in v:
        B=s.Matrix([[-w,0],[0,0]])
        M0,M1,M2=A*M0,A*M1+B*M0,A*M2+B*M1
        M0=M0.applyfunc(s.expand);M1=M1.applyfunc(s.expand);M2=M2.applyfunc(s.expand)
    return s.expand(s.trace(M2))

def homogeneous_quotient_length(polys,variables):
    G=s.groebner(polys,*variables,order='grevlex')
    assert G.is_zero_dimensional
    leading=[g.LM(order=G.order).exponents for g in G.polys]
    bounds=[]
    for j in range(len(variables)):
        pure=[e[j] for e in leading if e[j]>0 and all(e[k]==0 for k in range(len(e)) if k!=j)]
        assert pure
        bounds.append(min(pure))
    count=0
    for e in product(*(range(b) for b in bounds)):
        if not any(all(e[j]>=f[j] for j in range(len(e))) for f in leading):count+=1
    return count

result={'arithmetic':'exact rational/Gaussian rational polynomial arithmetic',
        'sympy_version':s.__version__,'seed_identities':[],
        'seed_jacobian_determinants':[],'discriminants':[],'jacobians':[],
        'quadratic_initial_ideals':[],'all_checks_passed':False}
w4=[a,-ii*a,ii*a,-a]
w5=[a,ii*a,0,-ii*a,-a]
# The period-four convention is exactly Z in the manuscript: a=1+i,
# b=-i*a=1-i. The other square root gives -Z, with the same determinants.
for q,word,expected,bvalue,relation,det_expected in [
    (4,[a,b,-b,-a],-(a*a+b*b)*x*x+a*a*b*b+a*a-2*a*b+b*b,
     -ii*a,2*ii,-16*ii),
    (5,[a,b,0,-b,-a],-(a*a+b*b)*x**3+(a*a*b*b+2*a*a-2*a*b+b*b)*x,
     ii*a,1-2*ii,-16+12*ii)]:
    direct=s.expand(disc_unrestricted(word)-free(q))
    assert s.expand(direct-expected)==0
    coeffs=s.Matrix([s.Poly(direct,x).nth(q-2*k) for k in (1,2)])
    determinant=reduce_poly(coeffs.jacobian([a,b]).det().subs(b,bvalue),relation)
    assert s.expand(determinant-det_expected)==0
    result['seed_identities'].append({'period':q,'general_identity_verified':True,
        'discriminant_difference':str(expected)})
    result['seed_jacobian_determinants'].append({'period':q,
        'b':str(bvalue),'a_squared':str(relation),'determinant':str(determinant),
        'expected':str(det_expected),'nonzero':True})
for w,relation,copies in [(w4,2*ii,1),(w5,1-2*ii,1),
                          (w5,1-2*ii,3),(w4,2*ii,5),(w5,1-2*ii,4)]:
    v=w*copies
    assert antisymmetric(v)
    assert s.expand(disc(v,relation)-free(len(v)))==0
    result['discriminants'].append({'period':len(v),'seed_period':len(w),
        'seed_relation':str(relation),'difference_is_zero':True,'antisymmetric':True})
for w,relation,copies in [(w5,1-2*ii,3),(w4,2*ii,5),(w5,1-2*ii,4)]:
    v=w*copies; rank=full_specialized_jacobian_rank(v,relation)
    assert rank==2
    result['jacobians'].append({'period':len(v),'seed_period':len(w),
        'variables':len(v)//2,'rank':rank,'tangent_dimension':len(v)//2-rank})
for q in range(3,11):
    m=q//2;u=s.symbols('u0:'+str(m))
    v=list(u)+([0] if q%2 else [])+[-t for t in reversed(u)]
    direct=second_degree_discriminant(v)
    U=[s.Integer(1),x]
    for k in range(2,q):U.append(s.expand(x*U[-1]-U[-2]))
    continuant=s.Integer(0)
    for d in range(1,m+1):
        Cd=sum(v[j]*v[(j+d)%q] for j in range(q))
        Kd=U[d-1]*U[q-d-1]
        continuant+=(s.Rational(1,2) if 2*d==q else 1)*Cd*Kd
    assert s.expand(direct-continuant)==0
    p=s.Poly(direct,x)
    forms=[p.nth(q-2*k) for k in range(1,m+1)]
    length=homogeneous_quotient_length(forms,u)
    assert length==2**m
    result['quadratic_initial_ideals'].append({'period':q,'variables':m,
        'continuant_formula_matches':True,'zero_dimensional':True,
        'quotient_length':length,'expected':2**m})
result['all_checks_passed']=True
out=Path(__file__).with_suffix('.json')
out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,separators=(',',':')))
