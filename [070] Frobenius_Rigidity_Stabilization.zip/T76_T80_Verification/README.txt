T76--T80: Exact verification bundle
Author of accompanying research manuscript: KEIO
Date: 24 October 2026

This bundle accompanies the standalone PDF and TEX manuscript
Frobenius Lifting, Floquet Rigidity, and Equivariant Stabilization.

STATUS
The manuscript presents full mathematical arguments. These scripts are
finite consistency checks, not proofs of the infinite statements and not
formal machine verification. Internal checking is not external peer review.
Historical novelty of a foundational principle and universal absence of
prior solutions have not been certified.

RUN
Use Python 3.12 and install the dependency listed in requirements.txt.
From the extracted directory run:
  python T76_T78_frobenius_verify.py
  python T79_pole_verify.py
  python T80_cube_verify.py
Each program writes its JSON results beside its own source file.
The JSON files in this archive record the executed checks.

CONTENTS AND FINITE SCOPE
T76_T78_frobenius_verify.py:
  Exact integer/rational arithmetic, first 256 coefficients.
  Additive towers: p=2, levels 1--4; p=3, levels 1--3;
  p=5, levels 1--2. Cantor towers: levels 0--2 (degrees 2, 6, 18;
  divisibility exponents 1, 4, 13). Includes the displayed degree-six
  relation modulo 81 in the original coefficient ring.

T79_pole_verify.py:
  Exact rational evaluation matrices in dimensions 1--5, with a fixed
  random seed. Ranks 1, 2, 4, 8, 16. Exhaustively checks the admissible
  three-step cycles in each of these dimensions. The all-dimensional
  independence and rigidity statements are proved in the manuscript.

T80_cube_verify.py:
  Exact integer computations for reflected cubes of dimensions 2--7.
  Checks nonnegative integral character multiplicities after the proposed
  stabilization and the exact pole order at -1. Uses Python standard
  library only.

MANUSCRIPT BUILD
The separately supplied TEX file is standalone, with an embedded
bibliography. Compile it twice using pdflatex. No external figures or
bibliography database are required. The supplied PDF has 17 pages.

ATTRIBUTION
T76 is an auxiliary structural theorem. T77, T78 and T80 apply to three
numbered conjectures; T79 addresses an explicitly posed unnumbered open
classification problem. These are not five independent named open problems.
The manuscript explains the classical methods used and narrows an earlier
T71 novelty attribution in light of Korotyaev--Kutsenko (2005).

Tested environment: Python 3.12.14, SymPy 1.14.0.
