"""Exact finite checks of the Frobenius-compatible annihilator constructions.

The all-level proofs are in the accompanying T76--T80 manuscript. These
tests only check the finite levels printed in the JSON output and never
replace those proofs. Requires SymPy; execute this file with Python 3.
"""
from pathlib import Path
import json
import sympy as s

z,t=s.symbols('z t')
N=256

def mul(a,b,mod):
    c=[0]*N
    for i,x in enumerate(a):
        if x:
            for j in range(N-i):
                if b[j]: c[i+j]=(c[i+j]+x*b[j])%mod
    return c

def rational_coefficients(expr,mod):
    if expr==0: return [0]*N
    num,den=s.fraction(s.cancel(expr))
    np=s.Poly(num,z);dp=s.Poly(den,z)
    na=[int(np.nth(k))%mod for k in range(min(N,np.degree()+1))]
    da=[int(dp.nth(k))%mod for k in range(min(N,dp.degree()+1))]
    inv=pow(da[0],-1,mod)
    out=[]
    for k in range(N):
        v=na[k] if k<len(na) else 0
        v-=sum(da[j]*out[k-j] for j in range(1,min(k+1,len(da))))
        out.append((v*inv)%mod)
    return out

def evaluate(poly,series,mod):
    out=[0]*N
    for c in s.Poly(poly,t).all_coeffs():
        out=mul(out,series,mod)
        coeff=rational_coefficients(c,mod)
        out=[(a+b)%mod for a,b in zip(out,coeff)]
    return out

out={'coefficient_count':N,'phi':[],'cantor':[],'all_checks_passed':False}
for p,levels in [(2,4),(3,3),(5,2)]:
    A=t;e=0
    phi=[0]*N
    k=1
    while k<N:phi[k]=1;k*=p
    for r in range(1,levels+1):
        A=s.expand(A**p-p**((p-1)*e)*A.subs({z:z**p,t:t-z},simultaneous=True))
        e=p*e+1
        assert s.Poly(A,t).LC()==1
        assert s.degree(A,t)==p**r
        assert s.degree(A,z)<=p**(r-1)
        values=evaluate(A,phi,p**e)
        assert not any(values)
        out['phi'].append({'p':p,'level':r,'degree':p**r,'valuation':e,'passes':True})

psi=[]
for n in range(N):
    m=n;valid=True
    while m:
        if m%3==2:valid=False;break
        m//=3
    psi.append(int(valid))
C=t*t-1/(1+z);e=1
for r in range(3):
    if r:
        C=s.Poly(s.expand(C**3-3**(2*e)*C.subs({z:z**3,t:t/(1+z)},simultaneous=True)),t)
        C=s.Add(*(s.cancel(coeff)*t**power[0] for power,coeff in C.terms()))
        e=3*e+1
    assert s.Poly(C,t).LC()==1
    assert s.degree(C,t)==2*3**r
    assert not any(evaluate(C,psi,3**e))
    out['cantor'].append({'level':r,'degree':2*3**r,'valuation':e,'passes':True})

# Explicit original-ring representative at modulus 81.
u=1/(1+z)
C1_descended=t**6-3*u*t**4-6*u*u*t*t+8*u**3+27*z*u**5
assert not any(evaluate(C1_descended,psi,81))
out['cantor_explicit_degree_six_mod81']=str(C1_descended)
out['all_checks_passed']=True
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,separators=(',',':')))
