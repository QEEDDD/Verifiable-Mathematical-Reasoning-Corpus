"""Finite exact checks of the pole-separation algebra, not the all-d proof."""
from itertools import product
from fractions import Fraction
from pathlib import Path
import json, random
import sympy as s
rng=random.Random(77127)
out=[]
for d in range(1,6):
    signs=list(product((1,-1),repeat=d))
    reps=[a for a in signs if a[0]==1]
    n=len(reps)
    rows=[]
    for j in range(n+5):
        x=[rng.randrange(1,32) for k in range(d)]
        row=[]
        for a in reps:
            p=sum(x[k] for k in range(d) if a[k]==1)
            m=sum(x[k] for k in range(d) if a[k]==-1)
            row.append(s.Rational(1,3*(p*p+p*m+m*m)))
        rows.append(row)
    rank=s.Matrix(rows).rank()
    assert rank==n
    cycles=[]
    for a in signs:
        for b in signs:
            c=tuple((-a[j]-b[j])%3 for j in range(d))
            if all(k in (1,2) for k in c):
                c=tuple(1 if k==1 else -1 for k in c)
                assert a==b==c
                cycles.append((a,b,c))
    assert len(cycles)==2**d
    out.append({'dimension':d,'antipodal_pairs':n,'pole_basis_evaluation_rank':rank,'allowed_cubic_cycles':len(cycles),'all_cycles_single_direction':True})
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
