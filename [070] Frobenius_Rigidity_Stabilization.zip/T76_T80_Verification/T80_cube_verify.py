"""Exact finite checks for the reflection-cube sharpness construction.

Run with Python 3. No third-party packages or floating point arithmetic.
These examples supplement the general mixed-parameter and pole proofs.
"""
from math import comb
from pathlib import Path
import json

def trim(a):
    while len(a)>1 and a[-1]==0:
        a.pop()
    return a

def multiply(a,b):
    out=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):
            out[i+j]+=x*y
    return trim(out)

checks=[]
for n in range(2,8):
    # Cube [0,1]^n, reflected in its first coordinate.
    p,q=n,1
    r=p-q
    counts=lambda k:(k+1)**n if k>=0 else 0
    fixed=lambda k:(k+1)**(n-1) if k>=0 and k%2==0 else 0
    h=trim([sum((-1)**j*comb(n+1,j)*counts(i-j)
                for j in range(min(i,n+1)+1)) for i in range(n+4)])
    H=trim([sum((-1)**j*comb(n,j)*fixed(i-2*j)
                for j in range(min(i//2,n)+1)) for i in range(2*n+5)])
    assert all(x>=0 for x in h+H)
    assert sum((-1)**i*x for i,x in enumerate(H))!=0
    dimension=multiply(h,[comb(r,j) for j in range(r+1)])
    size=max(len(dimension),len(H))
    dimension+= [0]*(size-len(dimension))
    character=H+[0]*(size-len(H))
    trivial=[];sign=[]
    for a,b in zip(dimension,character):
        assert (a+b)%2==0 and (a-b)%2==0 and a>=abs(b)
        trivial.append((a+b)//2);sign.append((a-b)//2)
    checks.append({'cube_dimension':n,'ambient_type':[p,q],
        'stabilization_exponent':r,'exact_pole_order_at_minus_one':r,
        'h_star':h,'fixed_numerator':H,
        'trivial_multiplicities':trivial,'sign_multiplicities':sign,
        'all_multiplicities_nonnegative_integers':True})

result={'arithmetic':'exact integers','checks':checks,'all_checks_passed':True}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'dimensions':[c['cube_dimension'] for c in checks],
                  'all_checks_passed':True}))
