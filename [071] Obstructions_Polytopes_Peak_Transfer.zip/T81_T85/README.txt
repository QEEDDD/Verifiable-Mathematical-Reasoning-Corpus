T81--T85: Derivative Obstructions, Minimal Ehrhart Counterexamples,
and Peak-Transfer Bounds
Author: KEIO
Research manuscript: 24 October 2026

CONTENTS AND STATUS

The standalone TEX and 16-page PDF contain five fully written proofs.
These are internally checked research results, not externally refereed or
proof-assistant-certified theorems. Finite calculations below do not replace
the infinite-parameter proofs in the manuscript.

T81: Ulas Conjecture 4.2(1). A derivative obstruction refutes the original
eventual-monotonicity clause for k=20 and every n>=13. The separate
one-real-root clause is not settled.

T82: An explicit fixed-dimension-ten unbounded family of minimal
ineffective polynomial equivariant Ehrhart numerators. The bare negative
answer to Clarke Question 6.6 is also implicit in a previously known
example after its minimality is established; this is not claimed as an
unqualified historical first.

T83: A negative answer to Clarke Question 6.7, using the half-lattice
boundary coefficient to rule out obstructing faces in dimension three.
The global least counterexample dimension remains undetermined.

T84: Exact weighted energy optimum for arbitrary time-independent,
loopless, real-weighted graphs with nonzero peak transfer at a prescribed
distance and time. The attaining Krawtchouk path and its energy constant
are prior; the proposed extension is the universal peak-transfer bound.
The statement does not hold as written for time-dependent controls.

T85: Adjacency and Laplacian lower bounds answering the explicit request
in Coutinho--Guo--Schmeits Open Problem 7.2. The adjacency cubic leading
constant 1/24 is sharp along even distances, and the growth order is cubic
for all distances. No exact finite-distance extremal formula, sharp
Laplacian asymptotic, or uniform positive transfer amplitude is asserted.

No historically unprecedented foundational principle or exhaustive absence
of prior identical solutions has been established. The five theorem labels
do not represent five independent previously open problems. Read the
manuscript's attribution and scope sections before quoting these results.

REPRODUCING THE CHECKS

Tested with Python 3.12.14 and SymPy 1.14.0. The first three programs use
only the Python standard library. Install the last program's dependency:

    python3 -m pip install -r requirements.txt

Run the following from this directory (do not use Python's -O option,
which disables the exact assertions):

    python3 T81_stern_verify.py
    python3 T82_minimal_family_verify.py
    python3 T83_parity_verify.py
    python3 T84_T85_peak_verify.py

Each program checks exact identities, prints a short JSON summary and
writes its complete JSON record beside the program. Existing recorded
outputs are overwritten with regenerated results.

T81_stern_verify.py:
  Exact rational derivative certificate at -3/4, including the uniform
  n=13 error threshold; recursive Stern derivatives for n=13,...,100.
  Ancillary quadratic identities for n=0,...,100 and the B_845 factor
  calculation are included as checks, not counted as new theorems.

T82_minimal_family_verify.py:
  Fundamental parallelepiped enumeration, independent lattice counts in
  Q_m and 2Q_m, and all character/invariant formulas for m=1,...,12.

T83_parity_verify.py:
  Exact Ehrhart constituent and boundary coefficients of 52 half-lattice
  polygons, including a nonintegral-vertex period-collapse example.

T84_T85_peak_verify.py:
  Full unweighted adjacency matrices for Y_n, n=2,...,6; characteristic
  polynomials, distance moments, individual-vertex spectral projectors,
  and phase alignment. Sharp weighted paths for distances 1,...,10.

COMPILING THE MANUSCRIPT

The TEX embeds all references and needs no external figure or bibliography.
A standard LaTeX installation with the packages named in its preamble is
required. Compile twice:

    pdflatex T81_T85_Obstructions_Polytopes_Peak_Transfer.tex
    pdflatex T81_T85_Obstructions_Polytopes_Peak_Transfer.tex

INTEGRITY

SHA256SUMS records all distributed files except itself. On systems with
sha256sum, run: sha256sum -c SHA256SUMS

The cited primary sources and exact inspected versions are in the
manuscript bibliography. Source papers are not redistributed in this ZIP.
