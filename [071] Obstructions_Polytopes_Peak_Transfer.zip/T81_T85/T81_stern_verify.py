"""Exact finite verification for T81: Ulas Conjecture 4.2(1).

Checks the uniform derivative certificate and independent recursive values.
Also records ancillary classical quadratic identities, not new-theorem claims.
Finite checks supplement the all-n proof. Standard library only.
"""
from functools import cache
from pathlib import Path
import json
from fractions import Fraction as Q

def add(a,b):
    c=[0]*max(len(a),len(b))
    for i,v in enumerate(a):c[i]+=v
    for i,v in enumerate(b):c[i]+=v
    while len(c)>1 and c[-1]==0:c.pop()
    return tuple(c)
def mul(a,b):
    c=[0]*(len(a)+len(b)-1)
    for i,v in enumerate(a):
        for j,w in enumerate(b):c[i+j]+=v*w
    while len(c)>1 and c[-1]==0:c.pop()
    return tuple(c)
@cache
def stern(n):
    if n<2:return (n,)
    if n%2==0:return (0,)+stern(n//2)
    return add(stern(n//2),stern(n//2+1))
checks=[]
for n in range(101):
    a=(4**n-1)//3
    h=2*(4**n-1)*(2*4**n+1)//3+1
    X,Z=stern(a),stern(a+1)
    norm=add(add(mul((1,1,1),mul(X,X)),mul((2,1),mul(X,Z))),mul(Z,Z))
    assert norm==stern(h)
    Y=stern((4**(n+1)-1)//3)
    alternate=add(add(mul((0,0,1),mul(X,X)),mul((0,-1),mul(X,Y))),mul(Y,Y))
    assert alternate==norm
    checks.append({'n':n,'degree':len(norm)-1,'identity_passes':True})
assert stern(845)==mul((1,2),mul((1,2,2),(1,2,2)))
# Independent exact rational certificate for the eventual derivative obstruction.
def at(poly,x):
    v=Q(0)
    for c in reversed(poly):v=v*x+c
    return v
def derivative(poly):
    return tuple(i*poly[i] for i in range(1,len(poly))) or (0,)
k=20;a=Q(-3,4);r=abs(a)
C0=mul(add((0,)*(k-1)+(2,),(-1,-1)),(1,2,-1))
C1=add((0,4,6,0,-2),mul((0,)*(k-1)+(1,),(-2,-6,-2,2)))
C2=add((0,0,-4,-2,2),(0,)*k+(4,))
H=[at(c,a)/(a-1)**3 for c in (C0,C1,C2)]
Hp=[at(derivative(c),a)/(a-1)**3-3*at(c,a)/(a-1)**4 for c in (C0,C1,C2)]
assert Hp[0]==-Q(110236939137,1473173782528)
assert Hp[0]<-Q(7,100)
assert abs(Hp[1])<Q(1,2) and abs(Hp[2])<Q(1,2)
assert abs(H[1])/r<Q(1,10) and 2*abs(H[2])/r<Q(1,2)
E13=Q(17,10)*r**12+Q(13,2)*r**24
assert E13<Q(7,100)
derivative_checks=[]
for n in range(13,101):
    index=2**(2*n+k)-3*2**(n+k-1)+2**k-3
    value=at(derivative(stern(index)),a)
    assert value<0
    predicted=Hp[0]+Hp[1]*a**(n-1)+(n-1)*H[1]*a**(n-2)+Hp[2]*a**(2*n-2)+2*(n-1)*H[2]*a**(2*n-3)
    assert value==predicted
    derivative_checks.append({'n':n,'derivative_sign':-1,'formula_matches':True})
result={'arithmetic':'exact integers and rational numbers','quadratic_checks':checks,
        'monotonicity_certificate':{'k':20,'evaluation_point':str(a),'limit_derivative':str(Hp[0]),'uniform_threshold':13,'E13':str(E13),'error_threshold':'7/100','passes':True},
        'finite_derivative_checks':derivative_checks,
        'ancillary_factor_clause_counterexample_index':845,
        'ancillary_factor_clause_counterexample_factors':[[1,2],[1,2,2],[1,2,2]],
        'all_checks_passed':True}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'quadratic_n_range':[0,100],'derivative_n_range':[13,100],'uniform_certificate_passes':True,'all_checks_passed':True}))
