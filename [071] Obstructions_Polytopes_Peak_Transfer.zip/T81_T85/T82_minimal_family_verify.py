"""Exact verification of an explicit family answering Clarke Question 6.6.

Fundamental parallelepiped enumeration and independent simplex membership
counts. Python standard library only; finite checks do not replace proofs.
"""
from itertools import product
from math import comb
from pathlib import Path
import json

def mul(a,b):
    c=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b): c[i+j]+=x*y
    return c

def lattice_count(m,k):
    a=(1,-1,1,-m)
    ranges=[range(0,k+1),range(-k,k+1),range(0,k+1),range(-m*k,k+1),range(0,2*m*k+1)]
    out=0
    for x in product(*ranges):
        numer=[2*m*x[j]-a[j]*x[4] for j in range(4)]+[x[4]]
        if min(numer)>=0 and sum(numer)<=2*m*k: out+=1
    return out

checks=[]
for m in range(1,13):
    weights=(m,-1,1,-1,m,1)
    ages=[0]*6
    for k in range(2*m):
        residue_sum=sum((k*w)%(2*m) for w in weights)
        assert residue_sum%(2*m)==0
        ages[residue_sum//(2*m)]+=1
    assert ages==[1,0,m-1,m,0,0]
    counts=[lattice_count(m,k) for k in (1,2)]
    assert counts==[6,m+20]
    q=[1,m,-1,m*(m+1)]
    trivial=mul([1,1,1],q)
    sign=[0]+q
    h=mul([1,2,1],q)
    assert sign[3]==-1
    assert h[1]==m+2 and h[2]==2*m
    assert sum(h)==4*m*(m+2)
    checks.append({'m':m,'simplex_h_star':ages,'simplex_counts_k1_k2':counts,
                   'dimension':10,'lattice_point_count':m+13,'normalized_volume':sum(h),
                   'h_star':h,'trivial_multiplicities':trivial,'sign_multiplicities':sign})
out={'all_checks_passed':True,'arithmetic':'exact integers','parameter_range':[1,12],'checks':checks}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'parameter_range':[1,12],'all_checks_passed':True}))
