"""Exact finite checks for the half-lattice boundary formula (T83).

These tests supplement the all-polygons proof; they do not prove it.
Python standard library only. The polygon vertices below are doubled.
"""
from fractions import Fraction
from math import gcd
from pathlib import Path
import json,random

def cross(a,b,c):
    return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])

def hull(points):
    points=sorted(set(points))
    lower=[]
    for p in points:
        while len(lower)>1 and cross(lower[-2],lower[-1],p)<=0: lower.pop()
        lower.append(p)
    upper=[]
    for p in reversed(points):
        while len(upper)>1 and cross(upper[-2],upper[-1],p)<=0: upper.pop()
        upper.append(p)
    return lower[:-1]+upper[:-1]

def count(poly,k):
    out=0
    # Generous exact integer bounding box, with no floating point.
    xmin=min(p[0] for p in poly)*k//2-1
    xmax=max(p[0] for p in poly)*k//2+1
    ymin=min(p[1] for p in poly)*k//2-1
    ymax=max(p[1] for p in poly)*k//2+1
    for x in range(xmin,xmax+1):
        for y in range(ymin,ymax+1):
            if all(cross((k*a[0],k*a[1]),(k*b[0],k*b[1]),(2*x,2*y))>=0
                   for a,b in zip(poly,poly[1:]+poly[:1])): out+=1
    return out

def linear_coefficient(poly,parity):
    k=2 if parity==0 else 1
    vals=[count(poly,k+2*i) for i in range(3)]
    A=Fraction(vals[2]-2*vals[1]+vals[0],8)
    B=Fraction(vals[1]-vals[0],2)-A*(2*k+2)
    return A,B,vals

def expected_gap(poly):
    out=Fraction(0)
    missing=0
    for a,b in zip(poly,poly[1:]+poly[:1]):
        dx,dy=b[0]-a[0],b[1]-a[1]
        g=gcd(abs(dx),abs(dy))
        nx,ny=-dy//g,dx//g
        if (nx*a[0]+ny*a[1])%2:
            out+=Fraction(g,4);missing+=1
    return out,missing

rng=random.Random(8367)
polys=[[(0,0),(1,0),(1,2)],[(0,0),(4,0),(2,1)]]
for _ in range(50):
    p=hull([(rng.randrange(-4,5),rng.randrange(-4,5)) for _ in range(10)])
    if len(p)>=3: polys.append(p)
checks=[]
for p in polys:
    p=hull(p)
    ae,be,even=linear_coefficient(p,0)
    ao,bo,odd=linear_coefficient(p,1)
    expected,missing=expected_gap(p)
    assert ae==ao and be-bo==expected
    assert (expected>0)==(missing>0)
    checks.append({'doubled_vertices':p,'even_counts_k_2_4_6':even,
                   'odd_counts_k_1_3_5':odd,'linear_coefficient_difference':str(be-bo),
                   'predicted_edge_sum':str(expected),'nonlattice_support_edges':missing})
out={'arithmetic':'exact integers and rational numbers','polygon_count':len(checks),
     'all_checks_passed':True,'checks':checks}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'polygon_count':len(checks),'all_checks_passed':True}))
