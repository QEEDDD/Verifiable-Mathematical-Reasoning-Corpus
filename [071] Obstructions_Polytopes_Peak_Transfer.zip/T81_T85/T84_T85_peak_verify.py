"""Exact finite checks for the peak-transfer energy and edge bounds.

These checks do not replace the all-parameter proofs in the accompanying
T81--T85 research record. Requires SymPy; execute with Python 3.
"""
from pathlib import Path
from math import factorial
import json
import sympy as s

x=s.symbols('x')
checks=[]
for n in range(2,7):
    sizes=[v for j in range(1,n+1) for v in (n-j+1,j)]
    starts=[0]
    for k in sizes: starts.append(starts[-1]+k)
    N=starts[-1]
    A=s.zeros(N)
    for i in range(2*n-1):
        for u in range(starts[i],starts[i+1]):
            for v in range(starts[i+1],starts[i+2]):
                A[u,v]=A[v,u]=1
    expected=x**(N-2*n)*s.prod(x*x-k*k for k in range(1,n+1))
    assert s.Poly(A.charpoly(x).as_expr()-expected,x).is_zero
    edges=int(sum(A)/2)
    assert edges==n*(n+1)*(2*n+1)//6
    u,v=starts[1],starts[-2]
    d=2*n-2
    walk=s.zeros(N,1);walk[u]=1
    for j in range(d):
        assert walk[v]==0
        walk=A*walk
    assert walk[v]>0
    entries={}
    spectrum=list(range(-n,n+1))
    for theta in spectrum:
        vec=s.zeros(N,1);vec[u]=1;den=1
        for other in spectrum:
            if other!=theta:
                vec=A*vec-other*vec
                den*=theta-other
        val=s.Rational(vec[v],den)
        if theta==0: assert val==0
        else:
            k=abs(theta)
            expected=s.Rational(factorial(n-1)**2,2*s.prod(k*k-j*j for j in range(1,n+1) if j!=k))
            assert val==expected
            assert s.sign(val)*(-1)**k==(-1)**n
        entries[str(theta)]=str(val)
    B=sum(abs(s.Rational(value)) for value in entries.values())
    assert 0<B<=1
    assert 24*edges>=d*(d+1)*(d+2)
    checks.append({'n':n,'vertices':N,'edges':edges,'distance':d,
       'peak_time':'pi','mutual_projector_entries':entries,
       'peak_amplitude':str(B),'all_checks_passed':True})

weighted=[]
# Set spectral step to 2, so the weighted path has PST at time pi/2.
for d in range(1,11):
    weights_squared=[j*(d+1-j) for j in range(1,d+1)]
    p0,p1=s.Integer(1),x
    for b2 in weights_squared:
        p0,p1=p1,s.expand(x*p1-b2*p0)
    expected=s.prod(x-(2*j-d) for j in range(d+1))
    assert s.expand(p1-expected)==0
    energy=sum(weights_squared)
    assert 6*energy==d*(d+1)*(d+2)
    weighted.append({'distance':d,'energy':energy,
       'peak_time':'pi/2','energy_times_time_squared_over_pi_squared':str(s.Rational(energy,4)),
       'sharp_bound_over_pi_squared':str(s.Rational(d*(d+1)*(d+2),24)),
       'all_checks_passed':True})
out={'arithmetic':'exact integer and rational arithmetic',
     'unweighted_chain_blowups':checks,'sharp_weighted_paths':weighted,
     'all_checks_passed':True}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'Y_n_range':[2,6],'weighted_distance_range':[1,10],'all_checks_passed':True}))
