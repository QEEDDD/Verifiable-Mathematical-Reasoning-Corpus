VERIFICATION SUPPLEMENT TO COLLECTED RESEARCH 01--08
KEIO, 28 October 2026

This ZIP is self-contained. It contains the eight exact original TEX sources,
unchanged mathematical certificate sources extracted from them, a convenience
runner, and the records of a successful fresh full replay.
The consolidated PDF displays the code; its single TEX also contains an exact
recoverable original-source archive. The ZIP is optional, not needed to typeset it.

REQUIREMENTS
Python 3 standard library, g++ with C++17 and unsigned 128-bit integers, and GMP
C++ development libraries on a supported 64-bit LP64 platform. No network needed.
Do not use Python -O for the collection runner.

FULL REPLAY FROM THIS ZIP (run inside the extracted directory)
  python3 reproduce_collection.py originals fresh_replay --full
The output directory must not exist. All checks must return exit code zero.

FULL REPLAY DIRECTLY FROM THE CONSOLIDATED TEX
  python3 reproduce_collection.py KEIO_Collected_Research_01_08_2026.tex fresh_replay --full

EXTRACT ONLY
Omit --full. This verifies all eight source hashes and writes the original TEX
and four replay drivers, but makes NO claim that the finite certificates ran.

CONTENTS
originals/: exact historical source files, needed by their unchanged local drivers.
verification_sources/: the same executable mathematical certificate code for reading.
records/: exact finite certificate logs and replay results.
original_manifest.json and MANIFEST.sha256: byte-identity records.
reproduce_collection.py: an additional convenience wrapper around the unchanged drivers.

SCOPE
Chapters 1--4 are analytic/algebraic papers without these finite certificate suites.
Chapter 5: BBFM denominator and balanced-block finite checks.
Chapter 6: shifted Nekrasov--Okounkov prefix checks through n=50000.
Chapter 7: regular-partition finite checks and exact analytic-constant checks.
Chapter 8: Dukes width-100 edge certificates; NOT a full Dukes proof.
The infinite conclusions require the mathematical arguments in the manuscript.
This is not Lean/Coq-style formal verification or evidence of publication priority.

The recorded full replay passed all four suites. Runtime depends on hardware;
the recorded individual times were approximately 87, 289, 30 and 1 seconds.
Timing differences may change diagnostic log hashes in some suites.
