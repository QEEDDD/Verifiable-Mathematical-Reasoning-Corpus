#!/usr/bin/env python3
"""Extract exact originals from the standalone collection and replay certificates.
Usage: python3 reproduce_collection.py COLLECTION.tex NEW_DIRECTORY [--full]
Alternatively pass the originals directory shipped with the verification ZIP.
Python 3 standard library; --full additionally requires g++ and GMP development libraries.
No network access is used. This is finite-certificate replay, not formal proof checking.
"""
import argparse,base64,hashlib,json,pathlib,re,subprocess,sys,time
EXPECTED = {'uniform_nonlinear_exchange.tex': '3bfe3f99f3637857fd8f93d2e72fd3cd1044e4ccc9e7158c4dcee3f9b21fb334', 'hard_core_uniform_convergence.tex': 'd66f416c230af27bb17ba3c8a3d874aedf8f1eeab46aace2f385907dfdcb4fda', 'hard_core_fast_entropy.tex': 'c0d2b7f51629fac2431b054f4013978cc7a80990c85a3d566c3587637245f09e', 'exchange_tail_counterexample.tex': '87c359a03b6be2406557c201c7a63b4f4b16e23be74bc4d58c490b97562ca9d3', 'KEIO_BBFM_Denominator_Log_Concavity_2026.tex': '429a43c5fb3830e7ef85f1eddd90e233934b3ec405b59d1b0b71d0dd05c158aa', 'KEIO_Shifted_Nekrasov_Okounkov_Unimodality_2026.tex': '9d56524e20bc44f42f48fa170fa0f041227ba68ca66e73a36696c60199b27e87', 'KEIO_Regular_Partition_Log_Concavity_2026.tex': '155421c460f285432f7d208ca00aaeb557e854f4efa5ecc0096c7eed934d5938', 'KEIO_Dukes_Partial_Results_2026.tex': '1560709b0d12ba6991fa9cd62e51187e66521906600da167837ae399a2400ddb'}
NAMES = list(EXPECTED)
def require(ok,msg):
    if not ok: raise RuntimeError(msg)
def digest(b): return hashlib.sha256(b).hexdigest()
def sources(source):
    if source.is_dir(): return {n:(source/n).read_bytes() for n in NAMES}
    s=source.read_text(encoding='utf-8')
    p=r'^% BEGIN ORIGINAL SOURCE (\d{2}) (\S+) ([0-9a-f]{64})\n(.*?)^% END ORIGINAL SOURCE \1\s*$'
    out={}
    for number,name,sha,body in re.findall(p,s,re.M|re.S):
        require(name in EXPECTED and name not in out,'Unexpected or duplicate original '+name)
        chunks=[]
        for line in body.splitlines():
            if not line.strip(): continue
            require(line.startswith('% '),'Malformed source archive line')
            chunks.append(line[2:])
        data=base64.b64decode(''.join(chunks),validate=True)
        require(digest(data)==sha==EXPECTED[name],'Original hash mismatch '+name)
        out[name]=data
    return out

def driver(n,s):
    if n==5:
        p=r'^%<source:reproduce.py>\n\\begin\{lstlisting\}\n(.*?)\\end\{lstlisting\}\n%</source>'
    elif n==6:
        p=r'^% BEGIN_FILE reproduce.py\n\\begin\{lstlisting\}(?:\[[^\n]*\])?\n(.*?)^\\end\{lstlisting\}\n% END_FILE reproduce.py'
    elif n==7:
        p=r'\\begin\{lstlisting\}\[label=src:replay,[^\n]*\]\n(.*?)\n\\end\{lstlisting\}'
    else:
        p=r'^% BEGIN EXACT REPLAY\n\\begin\{lstlisting\}\n(.*?)^\\end\{lstlisting\}'
    m=re.search(p,s,re.M|re.S); require(m is not None,'Missing driver for paper '+str(n))
    return m.group(1)

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('source',type=pathlib.Path);ap.add_argument('directory',type=pathlib.Path)
    ap.add_argument('--full',action='store_true')
    args=ap.parse_args(); require(sys.flags.optimize==0,'Do not use Python -O for collection replay')
    data=sources(args.source.resolve());require(set(data)==set(EXPECTED),'Eight originals required')
    root=args.directory.resolve();root.mkdir(parents=True,exist_ok=False)
    orig=root/'originals';orig.mkdir()
    for name in NAMES:
        require(digest(data[name])==EXPECTED[name],'Original mismatch '+name)
        (orig/name).write_bytes(data[name])
    (root/'original_manifest.json').write_text(json.dumps(EXPECTED,indent=2)+'\n')
    results={'original_count':8,'original_hashes_verified':True,'full_requested':args.full,'papers':[]}
    for n in [5,6,7,8]:
        work=root/('paper_%02d'%n);work.mkdir();tex=orig/NAMES[n-1]
        d=work/'reproduce.py';d.write_text(driver(n,tex.read_text())+'\n')
        if not args.full:continue
        cmd=[sys.executable,str(d)]
        if n==5:cmd+=[str(tex)]
        elif n==6:cmd+=[str(tex),str(work/'replay'),'--full']
        elif n==7:cmd+=[str(tex),str(work/'replay')]
        start=time.monotonic();print('Running full certificate for paper',n,flush=True)
        with (work/'execution.log').open('w') as log:
            p=subprocess.run(cmd,cwd=work,stdout=log,stderr=subprocess.STDOUT)
        item={'paper':n,'exit_code':p.returncode,'seconds':time.monotonic()-start}
        results['papers'].append(item)
        (root/'collection_replay.json').write_text(json.dumps(results,indent=2)+'\n')
        require(p.returncode==0,'Certificate failed for paper %d; inspect execution.log'%n)
        print('PASS paper',n,flush=True)
    results['status']='PASS: all four finite certificate suites' if args.full else 'EXTRACTED ONLY: no finite replay claim'
    (root/'collection_replay.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(results,indent=2))
if __name__=='__main__':main()
