import json, time
from fractions import Fraction
from pathlib import Path
N=256
p=[1]
rows=[]
t0=time.time()
for n in range(1,N+1):
    m=n
    while True:
        p += [0]*m
        for k in range(len(p)-1,m-1,-1): p[k]+=p[k-m]
        if m%2:break
        m//=2
    bad=[]
    # palindromicity halves work, exact integer certificate.
    assert p==p[::-1]
    for k in range(1,(len(p)+1)//2):
        d=p[k]*p[k]-p[k-1]*p[k+1]
        if d<0:bad.append((k,p[k-1],p[k],p[k+1],d))
    rows.append({'n':n,'degree':len(p)-1,'bad_half_indices':bad})
    if bad:print('failure',n,bad[:8],flush=True)
    if n%32==0:print('checked',n,'degree',len(p)-1,'sec',time.time()-t0,flush=True)
Path('research/bbfm_logconcavity/exact_check.json').write_text(json.dumps(rows))
print('DONE',time.time()-t0)
