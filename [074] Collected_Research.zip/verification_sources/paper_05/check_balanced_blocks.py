import json
p=[1];bad=[]
for n in range(1,257):
 for s in range(4):
  if n%(1<<s):break
  k=n//(1<<s);q=p+[0]*k
  for j,a in enumerate(p):q[j+k]+=a
  p=q
 if n>=8:
  hits=[j for j in range(1,(len(p)+1)//2) if p[j]*p[j]<p[j-1]*p[j+1]]
  if hits:bad.append([n,hits])
print(json.dumps({'range':[8,256],'failures':bad,'last_degree':len(p)-1,'status':'finite exact verification only'}))
