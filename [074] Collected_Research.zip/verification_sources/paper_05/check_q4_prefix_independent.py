"""Exact q4 prefix via log derivative; not an infinite-tail proof."""
import json,hashlib
from pathlib import Path
N=10001
b=[0]*(N+1)
for d in range(1,N+1,2):
 for j in range(d,N+1,d):b[j]+=4*d
a=[0]*(N+1);a[0]=1
for n in range(1,N+1):
 s=sum(b[j]*a[n-j] for j in range(1,n+1))
 assert s%n==0
 a[n]=s//n
bad=[n for n in range(1,N) if a[n]*a[n]<a[n-1]*a[n+1]]
result={'checked_internal_indices':[1,N-1],'failures':bad,'coefficient_sha256':hashlib.sha256(('\n'.join(map(str,a))+'\n').encode()).hexdigest(),'method':'n*a_n=4 sum_(j=1)^n sigma_odd(j)*a_(n-j), exact integer arithmetic','scope':'finite verification only'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
