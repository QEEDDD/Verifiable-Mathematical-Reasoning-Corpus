// Finite certificate engine for B_n = Q_n Q_floor(n/2) Q_floor(n/4) Q_floor(n/8).
// All arithmetic is integer-only. Build via test_dyadic_certificate.py so that
// SOURCE_SHA256 records this exact source. No assertion is made beyond the
// explicitly reported finite (n,k) ranges. See dyadic_certificate.md.
#include <algorithm>
#include <cstdint>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>
#ifndef SOURCE_SHA256
#error "Define SOURCE_SHA256 as the SHA256 of this source file."
#endif
using U128 = unsigned __int128;
using I128 = __int128;
constexpr uint64_t HIGH = uint64_t(1) << 63;
struct Dyadic { uint64_t m = 0; int64_t e = 0; };
struct Interval { Dyadic lo, hi; };

static int bits(U128 x) {
    uint64_t hi = uint64_t(x >> 64);
    return hi ? 128 - __builtin_clzll(hi) :
        (uint64_t(x) ? 64 - __builtin_clzll(uint64_t(x)) : 0);
}
static int64_t exponent(I128 e) {
    if (e < std::numeric_limits<int64_t>::min() ||
        e > std::numeric_limits<int64_t>::max())
        throw std::overflow_error("dyadic exponent overflow");
    return int64_t(e);
}
static bool valid(Dyadic a) { return a.m ? a.m >= HIGH : a.e == 0; }
// Exact numerator n, then directed normalization to a 64-bit mantissa.
static Dyadic normalize(U128 n, int64_t e, bool upward) {
    if (!n) return {};
    int shift = bits(n) - 64;
    if (shift <= 0)
        return {uint64_t(n << -shift), exponent(I128(e) + shift)};
    U128 q = n >> shift;
    if (upward && (n - (q << shift))) ++q;
    I128 out_e = I128(e) + shift;
    if (q == (U128(1) << 64)) { q >>= 1; ++out_e; }
    return {uint64_t(q), exponent(out_e)};
}
static Dyadic add(Dyadic a, Dyadic b, bool upward) {
    if (!a.m) return b;
    if (!b.m) return a;
    if (a.e < b.e) std::swap(a,b);
    I128 d = I128(a.e) - b.e;
    if (d <= 64) {
        // Maximum is (2^64-1)*2^64 + (2^64-1) = 2^128-1.
        U128 numerator = (U128(a.m) << unsigned(d)) + b.m;
        return normalize(numerator, b.e, upward);
    }
    // 0 < b < 2^a.e: lower rounds to a, upper adds exactly one ulp.
    if (!upward) return a;
    if (a.m == std::numeric_limits<uint64_t>::max())
        return {HIGH, exponent(I128(a.e) + 1)};
    return {a.m + 1, a.e};
}
static Interval add(Interval a, Interval b) {
    return {add(a.lo,b.lo,false), add(a.hi,b.hi,true)};
}
// Compare a*b with c*d exactly; exponent sums use signed 128-bit integers.
static int compare_products(Dyadic a, Dyadic b, Dyadic c, Dyadic d) {
    U128 p = U128(a.m)*b.m, q = U128(c.m)*d.m;
    if (!p || !q) return (p>q)-(p<q);
    int bp=bits(p), bq=bits(q);
    I128 ep=I128(a.e)+b.e, eq=I128(c.e)+d.e;
    I128 tp=ep+bp, tq=eq+bq;
    if (tp != tq) return tp > tq ? 1 : -1;
    // Equal top-bit positions: align to the larger mantissa bit length.
    // The shifted operand has at most max(bp,bq)<=128 significant bits.
    if (bp < bq) p <<= bq-bp;
    if (bq < bp) q <<= bp-bq;
    return (p>q)-(p<q);
}
static uint64_t natural(const std::string& s) {
    if (s.empty() || s.find_first_not_of("0123456789") != std::string::npos)
        throw std::invalid_argument("expected nonnegative decimal integer");
    size_t end=0;
    uint64_t n=std::stoull(s,&end);
    if (end != s.size()) throw std::invalid_argument("invalid integer");
    return n;
}
static Dyadic read_dyadic() {
    std::string m,e;
    if (!(std::cin>>m>>e)) throw std::invalid_argument("missing dyadic endpoint");
    size_t end=0; int64_t ee=std::stoll(e,&end);
    if (end != e.size()) throw std::invalid_argument("invalid exponent");
    Dyadic x{natural(m),ee};
    if (!valid(x)) throw std::invalid_argument("endpoint is not normalized");
    return x;
}
static void arithmetic() {
    std::string op;
    while (std::cin>>op) {
        if (op == "ADD") {
            Dyadic a=read_dyadic(),b=read_dyadic();
            Dyadic lo=add(a,b,false),hi=add(a,b,true);
            std::cout<<lo.m<<' '<<lo.e<<' '<<hi.m<<' '<<hi.e<<'\n';
        } else if (op == "CMP") {
            Dyadic a=read_dyadic(),b=read_dyadic(),c=read_dyadic(),d=read_dyadic();
            std::cout<<compare_products(a,b,c,d)<<'\n';
        } else throw std::invalid_argument("unknown arithmetic operation");
    }
}
static void emit_endpoint(Dyadic a) { std::cout<<'['<<a.m<<','<<a.e<<']'; }
static void emit_interval(Interval a) {
    std::cout<<'[';emit_endpoint(a.lo);std::cout<<',';emit_endpoint(a.hi);std::cout<<']';
}
static std::string decimal(U128 n) {
    std::string s;
    do { s.push_back(char('0'+n%10)); n/=10; } while(n);
    std::reverse(s.begin(),s.end());return s;
}
int main(int argc,char**argv) {
    try {
        if (argc==2 && std::string(argv[1])=="--arithmetic") {arithmetic();return 0;}
        if (argc<3) throw std::invalid_argument(
            "usage: dyadic_certificate NMAX KMAX [--nmin N] [--dump-intervals]");
        uint64_t nmax=natural(argv[1]),kmax=natural(argv[2]),nmin=8;
        bool dump=false;
        for (int i=3;i<argc;++i) {
            std::string opt=argv[i];
            if (opt=="--nmin" && i+1<argc) nmin=natural(argv[++i]);
            else if(opt=="--dump-intervals") dump=true;
            else throw std::invalid_argument("unknown or incomplete option: "+opt);
        }
        if (!nmin || nmin>nmax || nmax>1000000000ULL)
            throw std::invalid_argument("require 1 <= nmin <= nmax <= 1000000000");
        if (!kmax || kmax>std::numeric_limits<size_t>::max()/sizeof(Interval)-2)
            throw std::invalid_argument("kmax must be positive and safely allocatable");
        const uint64_t cap=kmax+1;
        const Dyadic one{HIGH,-63};
        std::vector<Interval> p(1,Interval{one,one});
        uint64_t degree=0;
        U128 total_checked=0,total_inconclusive=0,total_strict=0;
        std::cout<<"{\"type\":\"metadata\",\"schema\":1,\"source_sha256\":\""<<SOURCE_SHA256
          <<"\",\"family\":\"B_n=Q_n*Q_floor(n/2)*Q_floor(n/4)*Q_floor(n/8)\","
          <<"\"scope\":\"finite only; no analytic skips\",\"nmin\":"<<nmin<<",\"nmax\":"<<nmax
          <<",\"kmax\":"<<kmax<<",\"stored_cap\":"<<cap
          <<",\"built_but_not_checked_n\":[1,"<<nmin-1<<"]}\n";
        for (uint64_t n=1;n<=nmax;++n) {
            for (unsigned s=0;s<4;++s) {
                uint64_t divisor=uint64_t(1)<<s;
                if (n%divisor) break;
                uint64_t w=n/divisor;
                degree+=w; // n<=10^9 bounds degree < 10^18.
                uint64_t end=std::min(cap,degree);
                p.resize(size_t(end)+1);
                if (w<=end)
                    for (uint64_t j=end;j>=w;--j) p[j]=add(p[j],p[j-w]);
            }
            if (n<nmin) continue;
            uint64_t end=std::min(kmax,degree/2),bad=0;
            std::cout<<"{\"type\":\"row\",\"n\":"<<n<<",\"degree\":"<<degree
              <<",\"stored_through\":"<<p.size()-1<<",\"checked_k\":[1,"<<end
              <<"],\"reflected_k\":["<<degree-end<<','<<degree-1
              <<"],\"complete_half_range\":"<<(end==degree/2?"true":"false")
              <<",\"inconclusive_k\":[";
            for(uint64_t k=1;k<=end;++k) {
                if(compare_products(p[k].lo,p[k].lo,p[k-1].hi,p[k+1].hi)<=0) {
                    if(bad++) std::cout<<',';
                    std::cout<<k;
                }
            }
            total_checked+=end;total_inconclusive+=bad;total_strict+=end-bad;
            std::cout<<"],\"strict_certified\":"<<end-bad;
            if(dump) {
                std::cout<<",\"intervals\":[";
                for(size_t k=0;k<p.size();++k) {if(k)std::cout<<',';emit_interval(p[k]);}
                std::cout<<']';
            }
            std::cout<<"}\n";
        }
        std::cout<<"{\"type\":\"summary\",\"checked_inequalities\":"<<decimal(total_checked)
          <<",\"strict_certified\":"<<decimal(total_strict)<<",\"inconclusive\":"<<decimal(total_inconclusive)
          <<",\"all_requested_strict_certified\":"<<(total_inconclusive?"false":"true")
          <<",\"status\":\"finite verification only; inconclusive is not a counterexample\"}\n";
        return total_inconclusive ? 2 : 0;
    } catch(const std::exception& e) {
        std::cerr<<"ERROR: "<<e.what()<<'\n';return 1;
    }
}
