"""Extract and reproduce the manuscript certificates. Python 3, no -O.
Usage: python reproduce.py /absolute/path/to/manuscript.tex
Run in an empty writable directory with g++ available.
"""
from pathlib import Path
import hashlib, json, re, subprocess, sys
assert __debug__, 'Assertions must be enabled'
tex = Path(sys.argv[1]).resolve().read_text()
root = Path.cwd()
out = root / 'research' / 'bbfm_logconcavity'
out.mkdir(parents=True, exist_ok=True)
pattern = (r'^%<source:([^>]+)>\n'
           r'\\begin\{lstlisting\}\n(.*?)'
           r'\\end\{lstlisting\}\n%</source>')
sources = re.findall(pattern, tex, re.M | re.S)
assert len(sources) == 10
for name, code in sources:
    assert Path(name).name == name
    (out / name).write_text(code)

def run_python(name):
    result = subprocess.run([sys.executable, str(out / name)],
                            check=True, text=True, capture_output=True)
    (out / (name + '.stdout')).write_text(result.stdout)
    print('PASS', name, flush=True)
    return result.stdout

for name in ('verify_balanced_moments.py',
             'verify_balanced_tail_h100.py',
             'verify_balanced_h100_constants.py',
             'verify_four_color_prefix.py',
             'verify_small_q4_transfer.py'):
    run_python(name)
run_python('check.py')
rows = json.loads((out / 'exact_check.json').read_text())
assert [r['n'] for r in rows] == list(range(1,257))
assert [r['n'] for r in rows if r['bad_half_indices']] == [3,5,6,7]
b = json.loads(run_python('check_balanced_blocks.py'))
assert b['range'] == [8,256] and b['failures'] == []
source = out / 'dyadic_certificate.cpp'
source_hash = hashlib.sha256(source.read_bytes()).hexdigest()
assert source_hash == ('b3154e0381004bb878a33af90f513d5e20'
                       'b3ab157db6080bf1fc34c2ccb9c7fe')
exe = out / 'dyadic_certificate'
subprocess.run(['g++','-std=c++17','-O3','-Wall','-Wextra',
                '-DSOURCE_SHA256="' + source_hash + '"',
                str(source),'-o',str(exe)],check=True)

def degree(n):
    return sum((n//(1<<a))*(n//(1<<a)+1)//2 for a in range(4))

def certify(first, last, cap, expected_count, expected_hash, filename):
    path = out / filename
    with path.open('w') as stream:
        subprocess.run([str(exe),str(last),str(cap),'--nmin',str(first)],
                       stdout=stream,check=True)
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected_hash
    records = [json.loads(line) for line in path.read_text().splitlines()]
    assert len(records) == last-first+3
    meta, summary = records[0], records[-1]
    assert meta['type'] == 'metadata' and meta['schema'] == 1
    assert meta['source_sha256'] == source_hash
    assert (meta['nmin'],meta['nmax'],meta['kmax']) == (first,last,cap)
    assert meta['stored_cap'] == cap+1
    assert meta['built_but_not_checked_n'] == [1,first-1]
    count = 0
    for n, row in zip(range(first,last+1),records[1:-1]):
        d = degree(n)
        end = min(cap,d//2)
        assert row['type'] == 'row' and row['n'] == n
        assert row['degree'] == d
        assert row['stored_through'] == min(cap+1,d)
        assert row['checked_k'] == [1,end]
        assert row['reflected_k'] == [d-end,d-1]
        assert row['complete_half_range'] == (end == d//2)
        assert row['inconclusive_k'] == []
        assert row['strict_certified'] == end
        count += end
    assert count == expected_count
    assert summary['type'] == 'summary'
    assert summary['checked_inequalities'] == count
    assert summary['strict_certified'] == count
    assert summary['inconclusive'] == 0
    assert summary['all_requested_strict_certified'] is True
    print('PASS',filename,'rows',last-first+1,'strict',count,flush=True)

certify(8,256,40400,1878532,
        'fc6f65c4a2650f67b7cc97656460da2412ba4887d4cb99dfb13c2ede565be57a',
        'dyadic_B8_B256.jsonl')
certify(257,27999,40399,1119898742,
        '93e20573a804fc4e213286519b3ff26b725fa584709253d95de7766c72d4e14f',
        'dyadic_B257_B27999.jsonl')
print('ALL CERTIFICATES PASS')
