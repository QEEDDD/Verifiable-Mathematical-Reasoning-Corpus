"""Exact scalar/core/first-tail checks for balanced_fourier_h100.md.

Moment and remaining-tail rational certificates are separate. No coefficient scan.
"""
from fractions import Fraction as F
from pathlib import Path
import json


def exp_lower(x, terms=100):
    term=total=F(1)
    for j in range(1,terms+1):
        term *= x/j
        total += term
    return total

H=100
a,b=F(11,12),F(64,49)
C=F(15,2)
phase_coefficient=F(7,40)
assert exp_lower(F(5))>144
assert F(145,143)**3/6 < phase_coefficient
assert F(143,145)**2>F(49,64)
assert F(14,25)<1
assert 2*F(22,7)/a**3<9

# Lower Gaussian endpoint is > 16/5. Each retained moment >49/50.
U=F(79,10)
assert b*U>F(16,5)**2
assert exp_lower(F(128,25))>160
assert F(5,2)**2 < 2*F(314,100)
tail_fraction_0=F(4,5)*F(5,16)/160
tail_fraction_2=F(4,5)*(F(16,5)+F(5,16))/160
assert tail_fraction_0<F(1,50) and tail_fraction_2<F(1,50)
assert 1-F(1,3*H**2)>F(999,1000)
positive=F(999,1000)*F(49,50)**2*2*F(314,100)/b**2
assert positive>F(7,2)
phase=120*F(22,7)*phase_coefficient**2*C/(a**5*H)
assert phase<F(27,20)

# delta < |theta| <= 2 delta. Put r=L |theta| and U=(sigma/L)^2.
# f(r)=r^2-r^4/12 increases on [1,2]. For p=1/2,3/2,
# U^p exp[-Uf(r)/2] decreases when U>=79/10.
# Integrate via exact positive rectangles, with sqrt(79/10)<3.
N=256
assert U<9
assert U*F(11,12)>3
x=y=F(0)
for i in range(N):
    l=1+F(i,N)
    u=1+F(i+1,N)
    f=l*l-l**4/12
    eminus=1/exp_lower(U*f/2)
    x+=F(6,N)*eminus
    y+=F(6,N)*U*u*u*eminus
assert x<F(1,40),float(x)
assert y<F(1,4),float(y)
central_phase=120*F(22,7)/(36*a**5*F(79,1000)*H)
assert central_phase<F(41,20)
xt=F(1,40)+F(1,3000)
yt=F(1,4)+F(1,50)
assert 3*xt+3*yt+xt*yt<F(9,10)
assert F(7,2)-F(27,20)-F(9,10)==F(5,4)
assert F(7,2)-F(41,20)-F(9,10)==F(11,20)
result={
  'status':'PASS', 'h_min':H,
  'positive_core_lower_decimal':float(positive),
  'phase_loss_upper_decimal':float(phase),
  'central_phase_loss_upper_decimal':float(central_phase),
  'total_tail_bound':'9/10',
  'first_tail_x_upper_decimal':float(x),
  'first_tail_y_upper_decimal':float(y),
  'first_tail_x_bound':'1/40', 'first_tail_y_bound':'1/4',
  'first_tail_grid':N,
}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
