"""Exact all-parameter moment certificate for four balanced rows, h >= 100.

No coefficient scan. Every inequality is rational; displayed decimals are reports.
See balanced_moments.md for the sum/integral and floor arguments.
"""
from fractions import Fraction as F
from pathlib import Path
import json

H = 100
GRID = 256
LAST = 16 * GRID
DEN = 10**18

def down(x):
    return F(x.numerator * DEN // x.denominator, DEN)

def up(x):
    return F(-((-x.numerator * DEN) // x.denominator), DEN)

def exp_interval(x):
    term = total = F(1)
    for j in range(1, 151):
        term *= x / j
        total += term
    nxt = term * x / 151
    return down(total), up(total + nxt / (1 - x / 152))

vl, vu = [], []
for i in range(LAST + 1):
    el, eu = exp_interval(F(i, GRID))
    vl.append(down(eu / (1 + eu)**2))
    vu.append(up(el / (1 + el)**2))
lo, hi = {2: [F(0)], 3: [F(0)]}, {2: [F(0)], 3: [F(0)]}
for i in range(LAST):
    l, u = F(i, GRID), F(i + 1, GRID)
    for q in (2, 3):
        area = (u**(q + 1) - l**(q + 1)) / (q + 1)
        lo[q].append(lo[q][-1] + vl[i + 1] * area)
        hi[q].append(hi[q][-1] + vu[i] * area)

def max_bound(q, x):
    return min(F(1 if q == 2 else 2), x**q / 4)

def balanced_interval(q, i, upper=False):
    # z >= i/GRID for lower, z <= i/GRID for upper.
    result = F(0)
    for a in range(4):
        d = 2**a
        j = (i + d - 1)//d if upper else i//d
        result += (hi if upper else lo)[q][j]
    return result

def error(q, z):
    return sum((max_bound(q, z / 2**a) for a in range(4)), F(0)) / H

worst = (F(0), None)
variance_worst = (F(100), None)
for i in range(GRID, LAST):
    z_upper = F(i + 1, GRID)
    s_lower = balanced_interval(2, i) - error(2, z_upper)
    t_upper = balanced_interval(3, i + 1, upper=True) + error(3, z_upper)
    assert s_lower > 0
    ratio = t_upper**2 / s_lower**3
    if ratio > worst[0]:
        worst = ratio, i
    assert ratio < F(15,2), (i, float(ratio))
    if i < 5 * GRID:
        vratio = s_lower / z_upper**2
        if vratio < variance_worst[0]:
            variance_worst = vratio, i
        assert vratio > F(79,1000), (i, float(vratio))

zeta_upper = sum((F(1,j**3) for j in range(1,11)), F(0)) + F(1,200)
assert zeta_upper < F(1203,1000)
s_tail = balanced_interval(2, LAST) - F(4,H)
t_tail = 4 * F(9,2) * F(1203,1000) + F(8,H)
tail_ratio = t_tail**2 / s_tail**3
assert tail_ratio < F(15,2)
v_tail = (balanced_interval(2, 5*GRID) - error(2,F(5))) / 25
assert v_tail > F(79,1000)

# Fourth moment covariance reduces to the single infinite row.
fourth_ratio = (F(7,30)*F(22,7)**4 + F(5,H))/(F(314,100)**2/6 - F(1,H))
assert fourth_ratio < 14
# Four rows; each right sum differs by at most max(f_2)/h.
variance_upper = 4 * (F(22,7)**2/6 + F(1,H))
assert variance_upper < 7
# Constants used to bound max f_q, from e > 27/10.
assert F(4)/F(27,10)**2 < 1
assert F(27)/F(27,10)**3 < 2
assert F(256)/F(27,10)**4 < 5

result = {
    'status': 'PASS', 'h_min': H,
    'third_moment_ratio_constant': '15/2',
    'core_variance_constant': '79/1000',
    'fourth_moment_constant': 14,
    'variance_upper_constant': 7,
    'grid_denominator': GRID, 'z_interval': [1,16],
    'exp_taylor_degree': 150, 'rounding_denominator': DEN,
    'third_moment_worst_cell': [f'{worst[1]}/{GRID}',f'{worst[1]+1}/{GRID}'],
    'third_moment_upper_decimal': float(worst[0]),
    'third_moment_upper_exact': [str(worst[0].numerator),str(worst[0].denominator)],
    'third_moment_tail_upper_decimal': float(tail_ratio),
    'core_variance_worst_cell': [f'{variance_worst[1]}/{GRID}',f'{variance_worst[1]+1}/{GRID}'],
    'core_variance_lower_decimal': float(variance_worst[0]),
    'core_variance_lower_exact': [str(variance_worst[0].numerator),str(variance_worst[0].denominator)],
    'core_variance_tail_lower_decimal': float(v_tail),
    'fourth_moment_upper_decimal': float(fourth_ratio),
    'variance_upper_decimal': float(variance_upper),
}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
