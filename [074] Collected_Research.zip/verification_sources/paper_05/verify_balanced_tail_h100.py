"""Exact rational Fourier absolute-moment tail certificate for balanced blocks.

For h>=100,n>=h,B_n=Q_n Q_floor(n/2) Q_floor(n/4) Q_floor(n/8),
x=sigma*integral_{2/min(n,5h)<=|theta|<=pi}|phi(theta)|dtheta < 1/3000,
y=sigma^3*integral_{2/min(n,5h)<=|theta|<=pi}theta^2|phi(theta)|dtheta < 1/50.
See balanced_tail_h100.md for the proof and definitions.
All certificate comparisons use fractions; decimal output is descriptive only.
"""
from fractions import Fraction as F
from math import isqrt
from pathlib import Path
import json

H=100
GRID=256
DEN=10**24
TAIL_DEN=10**32

def down(x,den=DEN):
    return F(x.numerator*den//x.denominator,den)
def up(x,den=DEN):
    return F(-((-x.numerator*den)//x.denominator),den)
def exp_interval(x):
    term=total=F(1)
    for j in range(1,81):
        term*=x/j
        total+=term
    nxt=term*x/81
    return down(total),up(total+nxt/(1-x/82))

elo=[]; vlow=[]; vhigh=[]
for i in range(5*GRID+1):
    lo,hi=exp_interval(F(i,GRID))
    elo.append(lo)
    vlow.append(down(hi/(1+hi)**2))
    vhigh.append(up(lo/(1+lo)**2))
Ilo=[F(0)]; Ihi=[F(0)]
for i in range(5*GRID):
    l,u=F(i,GRID),F(i+1,GRID)
    area=(u**3-l**3)/3
    Ilo.append(Ilo[-1]+vlow[i+1]*area)
    Ihi.append(Ihi[-1]+vhigh[i]*area)

def I2lo(x):
    assert 0<=x<=5
    i=x.numerator*GRID//x.denominator
    if i==5*GRID:return Ilo[i]
    return down(Ilo[i]+vlow[i+1]*(x**3-F(i,GRID)**3)/3)

def I2hi(x):
    assert 0<=x<=5
    i=x.numerator*GRID//x.denominator
    if i==5*GRID:return Ihi[i]
    return up(Ihi[i]+vhigh[i]*(x**3-F(i,GRID)**3)/3)

def Jlo(z):
    ans=F(0)
    for a in range(4):
        x=z/2**a
        assert (x*GRID).denominator==1
        el=elo[int(x*GRID)]
        ans+=F(1,2)-1/(1+el)
    return down(ans)

# e^(k/100) lower bounds by one exact Taylor lower bound and rounded
# multiplication. Induction certifies every table entry independently
# of floating point. Tail reciprocals are rounded upward.
r=down(sum((F(1,100)**j / __import__('math').factorial(j) for j in range(21)),F(0)),TAIL_DEN)
exp_table=[F(1)]
for k in range(1,20001):
    exp_table.append(down(exp_table[-1]*r,TAIL_DEN))
def neg_exp_up(x):
    assert 0<=x<=200
    k=x.numerator*100//x.denominator
    return up(1/exp_table[k],TAIL_DEN)

def sqrt_up(x):
    den=10**6
    t=isqrt(x.numerator*den*den//x.denominator)+1
    ans=F(t,den)
    assert ans*ans>x
    return ans

results=[]
first_tail=None
for zi in range(32,161):
    zlo=F(zi,32)
    zhi=F(zi+1,32) if zi<160 else None
    mass=Jlo(zlo)
    if zhi is None:
        # f2(x)<=x^2 e^-x is unimodal with maximum<1; its integral is2.
        # Four rows give sigma²/h³ <=4(2+1/H)<9.
        assert 4*(2+F(1,H))<9
        B=F(9)
    else:
        # f2 increases on[0,2]: 2/x-tanh(x/2)>0.
        B=sum((I2hi(zhi/2**a)+((zhi/2**a)**2*vhigh[int(zhi/2**a*GRID)] if zhi/2**a<=2 else F(1))/H for a in range(4)),F(0))
    R=sqrt_up(B)
    s0=s2=F(0)
    minimum=F(100)
    start=2/min(zhi or F(5),F(5))
    first=start.numerator*40//start.denominator
    for si in range(first,320):
        l,u=F(si,40),F(si+1,40)
        V=F(0)
        for a in range(4):
            c=min(zlo/2**a,2/u)
            V+=I2lo(c-F(1,H))-(F(1,H) if c>2 else F(0))
        prefix=F(25,72)*l*l*V
        abel=mass-F(1,2*H)-F(24,23)/l
        rate=max(prefix,abel)
        # h^(1/2)e^-rate*h and h^(3/2)e^-rate*h decrease for h>=H.
        assert rate>F(3,2*H)
        minimum=min(minimum,rate)
        E=neg_exp_up(H*rate)
        s0+=(u-l)*E
        s2+=(u**3-l**3)/3*E
    xn=2*R*10*s0
    yn=2*R**3*1000*s2
    ratefar=mass-F(1,2*H)-F(3,23)
    assert ratefar>F(9,2*H)
    E=neg_exp_up(H*ratefar)
    xf=2*F(22,7)*R*1000*E
    yf=F(2,3)*F(22,7)**3*R**3*10**9*E
    x,y=xn+xf,yn+yf
    if zi==32:first_tail=(x/R,y/R**3)
    assert x<F(1,3000),(zi,float(x))
    assert y<F(1,50),(zi,float(y))
    results.append({"z_lower":str(zlo),"z_upper":str(zhi) if zhi is not None else "infinity","sigma_squared_upper":float(B),"minimum_near_rate":float(minimum),"far_rate":float(ratefar),"x_upper":float(x),"y_upper":float(y)})
central_variance=sum((F(1,12*2**(3*a))+F(1,8*H*2**(2*a))+F(1,24*H**2*2**a) for a in range(4)),F(0))
assert central_variance<F(1,10)
Rc=sqrt_up(F(1,10))
xc,yc=first_tail[0]*Rc,first_tail[1]*Rc**3
assert xc<F(1,3000) and yc<F(1,50)
report={"central_tn_le_1":{"variance_bound":"1/10","variance_certificate_upper":float(central_variance),"x_upper":float(xc),"y_upper":float(yc)},"status":"PASS","h_min":H,"frequency_start":"2/min(n,5h)","x_bound":"1/3000","y_bound":"1/50","integral_grid_denominator":GRID,"z_grid_denominator":32,"s_grid_denominator":40,"exp_grid_denominator":100,"rounding_denominator":DEN,"tail_rounding_denominator":TAIL_DEN,"max_x_upper":max(r['x_upper']for r in results),"max_y_upper":max(r['y_upper']for r in results),"parameter_cells":results}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items()if k!='parameter_cells'},indent=2))
