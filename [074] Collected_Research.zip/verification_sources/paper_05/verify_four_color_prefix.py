"""Exact finite part of the all-index q4 proof; see four_color_partition_tail.md.

No finite list alone is claimed to prove an infinite assertion.
The analytic argument covers indices n >= 10000.
"""
import hashlib, json, time
from pathlib import Path

N = 10000
start = time.time()
# F(x) = product_{j odd}(1-x^j)^(-4).  Four independent colors.
a = [1] + [0] * N
for j in range(1, N + 1, 2):
    for color in range(4):
        for k in range(j, N + 1):
            a[k] += a[k-j]
assert a[:10] == [1, 4, 10, 24, 51, 100, 190, 344, 601, 1024]
T = [a[k]*a[k] - a[k-1]*a[k+1] for k in range(1, N)]
assert all(v > 0 for v in T)
# Independently recover each coefficient using n a_n = 4 sum sigma_odd(j) a_(n-j).
sigma_odd = [0] * (N + 1)
for d in range(1, N + 1, 2):
    for k in range(d, N + 1, d):
        sigma_odd[k] += d
for n in range(1, N + 1):
    assert n*a[n] == 4*sum(sigma_odd[j]*a[n-j] for j in range(1,n+1))
coeff_bytes = ("\n".join(map(str,a)) + "\n").encode()
result = {
    "coefficient_range": [0,N],
    "strict_log_concavity_range": [1,N-1],
    "failed_indices": [],
    "minimum_integer_turan": min(T),
    "coefficient_sha256": hashlib.sha256(coeff_bytes).hexdigest(),
    "independent_recurrence_verified": True,
    "elapsed_seconds": time.time()-start,
}
path = Path(__file__).with_name('four_color_prefix.json')
path.write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2))
