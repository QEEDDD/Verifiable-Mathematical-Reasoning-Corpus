"""Exact finite bridge for q4 indices below 10000, not a BBFM proof alone."""
from fractions import Fraction as F
from pathlib import Path
import runpy,contextlib,io,json
with contextlib.redirect_stdout(io.StringIO()):d=runpy.run_path(str(Path(__file__).with_name('check_q4_prefix_independent.py')))
a=d['a']
assert 100*a[9998]<99*a[9999]
worst=F(1)
for k in range(1,10000):
 T=a[k]*a[k]-a[k-1]*a[k+1]
 assert 10**9*T>a[k]*a[k],k
 worst=min(worst,F(T,a[k]*a[k]))
assert 400*10**12*99**3501<100**3501
# Large-index bridge with the already-proved R_k<exp(-1.7/sqrt(k)).
assert 40400<201**2
assert F(17*3501,10*201)>F(59,2)
def lower_exp(x,N):
 t=s=F(1)
 for j in range(1,N+1):
  t*=x/j;s+=t
 return s
assert lower_exp(F(3),8)>20
assert lower_exp(F(5,2),10)>12
assert F(4*120,12*20**9)<F(9,40*40404**2)
result={'status':'PASS','small_indices':[1,9999],'R_9999_upper':'99/100','relative_Turan_lower':'1/1000000000','minimum_relative_Turan_exact':[str(worst.numerator),str(worst.denominator)],'minimum_relative_Turan_decimal':float(worst),'d_min':3500,'deficit_upper':'1/1000000000000','large_indices':[10000,40400],'balanced_parameter_cutoff':28000,'scope':'conditional on the independently audited H=100 Fourier theorem; not a finite residual scan'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
