#!/usr/bin/env python3
"""Exact rational verification of the elementary eta-derivative constants.
No floating-point number enters an assertion. Run from any directory.
"""
from fractions import Fraction as Q
from math import factorial
import json


def atan_bounds(x, terms=60):
    s=sum(((-1)**j*x**(2*j+1)/Q(2*j+1) for j in range(terms)),Q(0))
    nxt=(-1)**terms*x**(2*terms+1)/Q(2*terms+1)
    return min(s,s+nxt),max(s,s+nxt)


def exp_lower(x, terms=100):
    return sum((x**j/Q(factorial(j)) for j in range(terms+1)),Q(0))

lo5,hi5=atan_bounds(Q(1,5))
lo239,hi239=atan_bounds(Q(1,239))
pilo=16*lo5-4*hi239
pihi=16*hi5-4*lo239
Clo=Q(411,250)
Chi=Q(329,200)
assert pilo**2/6>Clo
assert pihi**2/6<Chi
assert 24*pilo**2/Q(17)>13  # modular remainder on the Cauchy disk
assert exp_lower(Q(129,20))>200*pihi
assert exp_lower(Q(121,25))>40*pihi
# e > 2.7 follows by five terms of the exponential series.
assert exp_lower(Q(1),5)>Q(27,10)
# 2*4!*4^4 * 20 * exp(-260) < 10^-100.
assert Q(2*factorial(4)*4**4*20,1)*10**100 < Q(27,10)**260

# All E-remnant contributions are < 10^-100; use larger epsilon below.
eps=Q(1,10**90)
results=[]
for T,logupper,avec,muupper,vlo,vhi,L3,L4 in [
    (Q(1,100),Q(129,20),[Q(1,40),Q(1,40),Q(1,300),Q(1,300),Q(1,150)],Q(51,50),Q(199,200),Q(201,200),Q(401,200),Q(601,100)),
    (Q(1,20),Q(121,25),[Q(1,10),Q(1,10),Q(2,125),Q(2,125),Q(31,1000)],Q(213,200),Q(24,25),Q(26,25),Q(203,100),Q(121,20)),
]:
    raw=[
        Q(9,16)*T/Clo*(logupper+Q(1,2))+Q(81,1536)*T*T/Clo+eps,
        T/(2*Clo)*(logupper+Q(3,2))+Q(9,96)*T*T/Clo+eps,
        T/(2*Clo)+T*T/(12*Clo)+eps,
        T/(2*Clo)+eps,
        T/Clo+eps,
    ]
    assert all(x<y for x,y in zip(raw,avec))
    a0,a1,a2,a3,a4=avec
    m=1-a0
    e2=a2/m+a1*a1/m**2
    e3=a3/m+3*a1*a2/m**2+2*a1**3/m**3
    e4=a4/m+(4*a1*a3+3*a2*a2)/m**2+12*a1*a1*a2/m**3+6*a1**4/m**4
    assert 1-e2>vlo and 1+e2<vhi
    assert 2+e3<L3
    assert 6+e4<L4
    flo=Clo-T*logupper/2-T*T/24
    ftarget=Q(161,100) if T==Q(1,100) else Q(38,25)
    assert flo>ftarget
    delta=T*(logupper-1)/2+T*T/12
    assert 1+delta/flo<muupper
    m2lo=2*Clo-T/2-eps
    m2target=Q(82,25) if T==Q(1,100) else Q(13,4)
    assert m2lo>m2target
    assert pihi*pihi/3+eps<Q(329,100)
    assert 6*Chi+eps<10
    assert 24*Chi+eps<40
    results.append({
        'T':str(T),'F_t_lower':str(ftarget),'mean_t_upper':str(muupper),
        'variance_t2_lower':str(vlo),'variance_t2_upper':str(vhi),
        'log_derivative3_t3_bound':str(L3),'log_derivative4_t4_bound':str(L4),
        'M2_t3_lower':str(m2target),'M2_t3_upper':'329/100',
        'M3_t4_upper':'10','M4_t5_upper':'40',
        'raw_E_bounds':[str(x) for x in raw],
        'round_E_bounds':[str(x) for x in avec],
        'log_correction2':str(e2),'log_correction3':str(e3),'log_correction4':str(e4),
    })

# A wider angular strip, useful for intermediate Fourier tails.
assert 24*pilo*pilo/Q(53)>4
assert Q(2*factorial(4)*4**4*20)*10**28 < Q(27,10)**80
assert Q(11,7)-Q(11,24)<Q(9,8)
T=Q(1,20)
lu=Q(121,25)
epswide=Q(1,10**25)
wide_raw=[
    Q(9,8)*T/Clo*(lu+Q(9,8))+Q(81,384)*T*T/Clo+epswide,
    T/(2*Clo)*(lu+Q(17,8))+Q(3,16)*T*T/Clo+epswide,
    T/(2*Clo)+T*T/(12*Clo)+epswide,
    T/(2*Clo)+epswide,
    T/Clo+epswide,
]
wide=[Q(21,100),Q(11,100),Q(2,125),Q(2,125),Q(31,1000)]
assert all(x<y for x,y in zip(wide_raw,wide))
a0,a1,a2,a3,a4=wide
m=1-a0
wb2=a2/m+a1*a1/m**2
wb3=a3/m+3*a1*a2/m**2+2*a1**3/m**3
wb4=a4/m+(4*a1*a3+3*a2*a2)/m**2+12*a1*a1*a2/m**3+6*a1**4/m**4
assert wb2<Q(1,25)
assert wb3<Q(7,200)
assert wb4<Q(3,50)
print(json.dumps({'status':'all exact rational assertions passed','ranges':results,
    'wide_strip':{'T':'1/20','theta_over_t_max':'2',
    'E_bounds':[str(x) for x in wide],
    'H_second_t2_bound':str(wb2),'H_third_t3_bound':str(wb3),
    'H_fourth_t4_bound':str(wb4),
    'log_derivative3_t3_bound':'407/200','log_derivative4_t4_bound':'303/50',
    'remainder_scaled_bound':'t*10^-28'}},indent=2))
