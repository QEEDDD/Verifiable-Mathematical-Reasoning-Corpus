// Exact fixed-point certificate for shifted Nekrasov--Okounkov rows.
// See README.md for proof of interval invariant. GMP integers only enter proofs.
#include <gmpxx.h>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <climits>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>

#ifndef CERT_SOURCE_SHA256
#define CERT_SOURCE_SHA256 "unrecorded"
#endif

using Poly = std::vector<mpz_class>;
using Clock = std::chrono::steady_clock;
static double seconds(Clock::time_point t) {
  return std::chrono::duration<double>(Clock::now()-t).count();
}
static size_t bits(const mpz_class& x) {
  return x == 0 ? 0 : mpz_sizeinbase(x.get_mpz_t(),2);
}
static unsigned parse_unsigned(const char* s,unsigned lo,unsigned hi) {
  if(!s || !*s || *s=='-' || *s=='+') throw std::runtime_error("invalid unsigned argument");
  size_t used=0; auto v=std::stoull(s,&used,10);
  if(used!=std::string(s).size() || v<lo || v>hi)
    throw std::runtime_error("argument outside supported range");
  return static_cast<unsigned>(v);
}
static unsigned ceillog2(size_t n) {
  unsigned b=0; size_t v=1; while(v<n) {v<<=1; ++b;} return b;
}
static uint64_t coefficient_digest(const Poly& p) {
  constexpr uint64_t prime=(uint64_t(1)<<61)-1, base=1000003;
  uint64_t h=0;
  for(auto& x:p) h=(static_cast<__uint128_t>(h)*base+mpz_fdiv_ui(x.get_mpz_t(),prime))%prime;
  return h;
}
static void dump_values(const Poly& p,unsigned k,const mpz_class& S) {
  std::cout<<"{\"type\":\"fixedpoint_values\",\"k\":"<<k<<",\"S\":\""<<S<<"\",\"values\":[";
  for(size_t n=0;n<p.size();++n) {if(n)std::cout<<',';std::cout<<'"'<<p[n]<<'"';}
  std::cout<<"]}"<<std::endl;
}
static unsigned tail_bound(unsigned n) {
  // ceil((142/125)*sqrt(n)); 142/125 > sqrt(2*(zeta(2)-1)).
  uint64_t target=uint64_t(142)*142*n;
  unsigned k=static_cast<unsigned>(std::sqrt(double(target)/(125*125)));
  while(uint64_t(125)*125*k*k < target) ++k;
  while(k && uint64_t(125)*125*(k-1)*(k-1)>=target) --k;
  return k;
}
static Poly partitions(unsigned N) {
  Poly p(N+1); p[0]=1;
  for(unsigned n=1;n<=N;++n) {
    for(unsigned j=1;;++j) {
      unsigned g1=j*(3*j-1)/2; if(g1>n) break;
      if(j&1) p[n]+=p[n-g1]; else p[n]-=p[n-g1];
      unsigned g2=j*(3*j+1)/2;
      if(g2<=n) { if(j&1) p[n]+=p[n-g2]; else p[n]-=p[n-g2]; }
    }
  }
  return p;
}
static size_t checked_packed_size(size_t coefficients,size_t limbs) {
  if(!coefficients || !limbs || limbs>SIZE_MAX/coefficients)
    throw std::runtime_error("packed-size multiplication overflow");
  size_t total=coefficients*limbs;
  // GMP stores its limb count in a signed int. Both packed operands have at
  // most total limbs, so their product needs at most 2*total limbs.
  if(total>static_cast<size_t>(INT_MAX)/2)
    throw std::runtime_error("packed product exceeds GMP signed-int limb limit");
  return total;
}
static void check_supported_platform() {
  if(CHAR_BIT!=8 || sizeof(int)!=4 || sizeof(long)!=8 ||
     sizeof(unsigned long)!=8 || sizeof(void*)!=8 || sizeof(size_t)!=8 ||
     sizeof(mp_limb_t)!=8 || GMP_NUMB_BITS!=64 || GMP_NAIL_BITS!=0)
    throw std::runtime_error("supported platform is LP64, 8-bit bytes, 64-bit GMP limbs, no nails");
}
static Poly exact_convolution_trunc(const Poly& a,const Poly& b,
                                   unsigned N,unsigned shift,
                                   size_t& slot_bits) {
  size_t ma=0,mb=0;
  for(unsigned i=0;i<=N;++i) {ma=std::max(ma,bits(a[i]));mb=std::max(mb,bits(b[i]));}
  // Every convolution coefficient < (N+1)*2^(ma+mb) <= 2^slot_bits.
  size_t extra=ceillog2(N+1);
  if(ma>SIZE_MAX-mb || ma+mb>SIZE_MAX-extra)
    throw std::runtime_error("convolution slot-size overflow");
  slot_bits=ma+mb+extra;
  size_t limbs=slot_bits/GMP_NUMB_BITS+(slot_bits%GMP_NUMB_BITS!=0);
  if(limbs>SIZE_MAX/GMP_NUMB_BITS)
    throw std::runtime_error("rounded convolution slot-size overflow");
  slot_bits=limbs*GMP_NUMB_BITS;
  if(GMP_NAIL_BITS != 0) throw std::runtime_error("GMP nails unsupported");
  size_t total=checked_packed_size(size_t(N)+1,limbs);
  std::vector<mp_limb_t> packed(total,0);
  mpz_class aa,bb,cc;
  auto pack=[&](const Poly& p,mpz_class& out) {
    std::fill(packed.begin(),packed.end(),0);
    for(unsigned i=0;i<=N;++i) {
      if(p[i]<0) throw std::runtime_error("negative coefficient");
      size_t m=mpz_size(p[i].get_mpz_t());
      if(m>limbs) throw std::runtime_error("coefficient spills slot");
      if(m) std::copy_n(mpz_limbs_read(p[i].get_mpz_t()),m,packed.data()+size_t(i)*limbs);
    }
    mpz_import(out.get_mpz_t(),total,-1,sizeof(mp_limb_t),0,0,packed.data());
  };
  pack(a,aa);pack(b,bb);
  mpz_mul(cc.get_mpz_t(),aa.get_mpz_t(),bb.get_mpz_t());
  // Only coefficients through degree N are needed; higher limbs cannot borrow.
  const mp_limb_t* cp=mpz_limbs_read(cc.get_mpz_t()); size_t cn=mpz_size(cc.get_mpz_t());
  Poly result(N+1);
  for(unsigned i=0;i<=N;++i) {
    size_t offset=size_t(i)*limbs;
    if(offset<cn) {
      size_t take=std::min(limbs,cn-offset);
      mpz_import(result[i].get_mpz_t(),take,-1,sizeof(mp_limb_t),0,0,cp+offset);
      mpz_fdiv_q_2exp(result[i].get_mpz_t(),result[i].get_mpz_t(),shift);
    }
  }
  return result;
}
static void compare_naive(const Poly& f,const Poly& old,const Poly& next,
                          unsigned N,unsigned b) {
  for(unsigned n=0;n<=N;++n) {
    mpz_class c=0;
    for(unsigned j=0;j<=n;++j) c+=f[j]*old[n-j];
    mpz_fdiv_q_2exp(c.get_mpz_t(),c.get_mpz_t(),b);
    if(c!=next[n]) throw std::runtime_error("Kronecker vs naive mismatch");
  }
}
int main(int argc,char**argv) {
 try {
  check_supported_platform();
  unsigned N=argc>1?parse_unsigned(argv[1],1,1000000):1000;
  unsigned K=argc>2?parse_unsigned(argv[2],1,1000000):tail_bound(N)+1;
  unsigned b=argc>3?parse_unsigned(argv[3],16,4096):64;
  unsigned start=argc>4?parse_unsigned(argv[4],1,N):1;
  bool naive=false,dump=false;
  for(int i=5;i<argc;++i) {
    if(std::string(argv[i])=="naive")naive=true;
    else if(std::string(argv[i])=="dump")dump=true;
    else throw std::runtime_error("unknown option");
  }
  if(N<1 || N>1000000 || K>1000000 || b<16 || start<1 || start>N) throw std::runtime_error("bad parameter");
  mpz_class S=mpz_class(1)<<b;
  if(S<=2*K) throw std::runtime_error("interval denominator not positive");
  auto all=Clock::now();
  std::vector<unsigned long> sigma(N+1,0);
  for(unsigned d=1;d<=N;++d) for(unsigned n=d;n<=N;n+=d) sigma[n]+=d;
  Poly f(N+1);
  for(unsigned n=1;n<=N;++n) f[n]=(S*sigma[n])/n;
  Poly current=partitions(N),previous;
  for(auto& c:current) c*=S;
  if(dump)dump_values(current,0,S);
  uint64_t count=0, failures=0;
  std::cout<<"{\"type\":\"start\",\"source_sha256\":\""<<CERT_SOURCE_SHA256<<"\",\"N\":"<<N<<",\"K\":"<<K<<",\"b\":"<<b<<",\"first_n\":"<<start<<",\"setup_seconds\":"<<seconds(all)<<"}"<<std::endl;
  for(unsigned k=0;k<K;++k) {
    auto t=Clock::now();size_t width;
    Poly next=exact_convolution_trunc(f,current,N,b,width);
    double mult_seconds=seconds(t);
    if(dump)dump_values(next,k+1,S);
    if(naive) compare_naive(f,current,next,N,b);
    uint64_t checks=0,bad=0;
    unsigned first_bad=0,min_n=0;double min_slack=1;
    if(k>=1) {
      mpz_class qminus=S-2*(k-1),qplus=S-2*(k+1);
      for(unsigned n=std::max(start,k+1);n<=N;++n) {
        if(k>tail_bound(n)) continue;
        mpz_class lhs=(k+1)*current[n]*current[n]*qminus*qplus;
        mpz_class rhs=k*previous[n]*next[n]*S*S;
        ++checks;
        if(lhs<=rhs) {++bad;if(!first_bad)first_bad=n;}
        // Diagnostics only: proof comparison above is exact integer arithmetic.
        if(lhs>0) {
          mpz_class gap=lhs-rhs;
          long ge=0,le=0;
          double gm=mpz_get_d_2exp(&ge,gap.get_mpz_t());
          double lm=mpz_get_d_2exp(&le,lhs.get_mpz_t());
          double slack=std::ldexp(gm/lm,int(ge-le));
          if(slack<min_slack){min_slack=slack;min_n=n;}
        }
      }
    }
    count+=checks;failures+=bad;
    size_t maxbits=0;for(auto&v:next)maxbits=std::max(maxbits,bits(v));
    std::cout<<std::setprecision(10)<<"{\"type\":\"column\",\"computed_k\":"<<k+1<<",\"checked_k\":"<<k<<",\"slot_bits\":"<<width<<",\"max_coefficient_bits\":"<<maxbits<<",\"coefficient_digest_mod_2p61_minus_1\":"<<coefficient_digest(next)<<",\"multiply_seconds\":"<<mult_seconds<<",\"column_seconds\":"<<seconds(t)<<",\"checks\":"<<checks<<",\"inconclusive\":"<<bad<<",\"first_inconclusive_n\":"<<first_bad<<",\"min_relative_slack_diagnostic\":"<<min_slack<<",\"min_slack_n\":"<<min_n<<"}"<<std::endl;
    previous=std::move(current);current=std::move(next);
  }
  unsigned need=tail_bound(N)+1;
  bool coverage=K>=need;
  std::cout<<"{\"type\":\"complete\",\"checks\":"<<count<<",\"inconclusive\":"<<failures<<",\"full_tail_reduced_coverage\":"<<(coverage?"true":"false")<<",\"needed_K\":"<<need<<",\"seconds\":"<<seconds(all)<<"}"<<std::endl;
  if(failures) return 2;
  return coverage?0:3; // A partial run is never reported as overall success.
 }catch(std::exception&e){std::cerr<<"ERROR: "<<e.what()<<std::endl;return 1;}
}
