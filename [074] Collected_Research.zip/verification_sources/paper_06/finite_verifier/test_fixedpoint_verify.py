#!/usr/bin/env python3
"""Independent Fraction and naive convolution audits of the C++ verifier."""
from fractions import Fraction
from pathlib import Path
import subprocess,json,math,hashlib
ROOT=Path(__file__).resolve().parent
P=(1<<61)-1

def partitions(N):
    # Product expansion, independent from the C++ pentagonal recurrence.
    p=[1]+[0]*N
    for j in range(1,N+1):
        for n in range(j,N+1):p[n]+=p[n-j]
    return p

def conv(a,b,N):
    return [sum(a[j]*b[n-j] for j in range(n+1)) for n in range(N+1)]

def digest(a):
    h=0
    for x in a:h=(1000003*h+x)%P
    return h

def audit(N,K,b):
    S=1<<b;p=partitions(N)
    f=[Fraction(0)]+[sum((Fraction(1,d) for d in range(1,n+1) if n%d==0),Fraction(0)) for n in range(1,N+1)]
    fd=[int(x*S) for x in f]
    exact=list(map(Fraction,p));lower=[x*S for x in p]
    got=[json.loads(x) for x in subprocess.check_output([str(ROOT/'fixedpoint_verify'),str(N),str(K),str(b),'1','naive'],text=True).splitlines()]
    cols={x['computed_k']:x for x in got if x['type']=='column'}
    checks=0
    for k in range(1,K+1):
        exact=conv(f,exact,N)
        lower=[x//S for x in conv(fd,lower,N)]
        assert digest(lower)==cols[k]['coefficient_digest_mod_2p61_minus_1']
        for n,(v,l) in enumerate(zip(exact,lower)):
            assert Fraction(l,S)<=v<=Fraction(l,S-2*k),(n,k,l,v)
            assert (v==0 if n<k else v>=1)
            checks+=1
    return {'N':N,'K':K,'b':b,'exact_interval_checks':checks,'all_passed':True}

tail_gap=Fraction(142,125)**2-(Fraction(355,113)**2/Fraction(3)-2)
assert tail_gap>0
partial=subprocess.run([str(ROOT/'fixedpoint_verify'),'100','2','64','1'],text=True,capture_output=True)
assert partial.returncode==3
assert json.loads(partial.stdout.splitlines()[-1])['full_tail_reduced_coverage'] is False
results=[audit(30,16,16),audit(50,10,64),audit(60,20,128)]
report={'tests':results,'tail_cap_rational_gap':str(tail_gap),'incomplete_coverage_returns_3':True,'source_sha256':hashlib.sha256((ROOT/'fixedpoint_verify.cpp').read_bytes()).hexdigest(),'all_passed':True}
print(json.dumps(report,indent=2))
