#!/usr/bin/env python3
"""Extract and reproduce the single-TeX shifted-unimodality certificate.

Copy this listing to reproduce.py, then run (without python -O):
  python3 reproduce.py manuscript.tex replay --full
The default runs extraction, analytic checkers and small independent audits.
Use --audit-log PATH instead of --full to audit an existing completed log.
"""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
from fractions import Fraction

EXPECTED = {
    "verify_h100_constants.py":
    "a98bd0725c8fd1d1d1df35d8187f46b49ff84660bc05efd706455d7e70b195d7",
    "eta_derivatives/verify_constants.py":
    "9c35412a4f5a08938dfd38f4848b5bc3d053743986d91cb779f8e4710bd3cebb",
    "finite_verifier/fixedpoint_verify.cpp":
    "8145fcafa5dba3d8d15aa60263779d05ce6a1dff49fa361ffd91195afe3cb64c",
    "finite_verifier/test_fixedpoint_verify.py":
    "1e6342a38e54dfa069158bf57a27f27214c7678555b1462d1d3fbd281974c103",
}


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def extract(tex, root):
    data = tex.read_bytes()
    # Newline normalization is intentionally forbidden: hashes are byte-exact.
    require(b"\r" not in data, "Use the original LF-newline TeX source")
    pattern = re.compile(
        rb"^% BEGIN_FILE ([A-Za-z0-9_./-]+)\n"
        rb"\\begin\{lstlisting\}(?:\[[^\n]*\])?\n"
        rb"(.*?)^\\end\{lstlisting\}\n% END_FILE(?: [^\n]*)?\n",
        re.M | re.S)
    blocks = {}
    for match in pattern.finditer(data):
        name = match.group(1).decode("ascii")
        require(name not in blocks, "Duplicate listing: " + name)
        require(name in EXPECTED or name == "reproduce.py",
                "Unexpected extracted path: " + name)
        blocks[name] = match.group(2)
    require(set(EXPECTED) <= set(blocks), "Missing required source listing")
    for name, expected in EXPECTED.items():
        require(sha(blocks[name]) == expected, "Source hash mismatch: " + name)
    root.mkdir(parents=True, exist_ok=True)
    for name, content in blocks.items():
        target = root / name
        require(root in target.resolve().parents,
                "Extracted path escapes output directory")
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            require(target.read_bytes() == content,
                    "Refusing to overwrite different file: " + str(target))
        else:
            target.write_bytes(content)
    manifest = {name: sha(content) for name, content in sorted(blocks.items())}
    (root / "extracted_sources_sha256.json").write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    return manifest


def run_json(script, output, env):
    text = subprocess.check_output([sys.executable, str(script)],
                                   text=True, env=env)
    value = json.loads(text)
    output.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
    return value


def cap(n):
    target = 142 * 142 * n
    k = math.isqrt(target // (125 * 125))
    if 125 * 125 * k * k < target:
        k += 1
    require(125 * 125 * k * k >= target, "Cap upper bound failed")
    require(k == 0 or 125 * 125 * (k - 1) ** 2 < target,
            "Cap minimality failed")
    return k


def audit_log(path, root):
    records = [json.loads(line) for line in path.read_text().splitlines()
               if line.strip()]
    require(len(records) == 258, "Expected start, 256 columns, complete")
    start, end = records[0], records[-1]
    require(start.get("type") == "start" and end.get("type") == "complete",
            "Missing terminal completion or initial provenance record")
    require((start["N"], start["K"], start["b"], start["first_n"])
            == (50000, 256, 64, 1), "Unexpected finite-run parameters")
    source = "finite_verifier/fixedpoint_verify.cpp"
    require(start["source_sha256"] == EXPECTED[source]
            == sha((root / source).read_bytes()), "Wrong engine provenance")
    N, K, b = start["N"], start["K"], start["b"]
    require(K == cap(N) + 1 and 2 ** b > 2 * K,
            "Insufficient coefficient columns or nonpositive enclosure")
    total = 0
    column_counts = []
    for k, row in enumerate(records[1:-1]):
        require(row.get("type") == "column", "Non-column interior record")
        require((row["computed_k"], row["checked_k"]) == (k + 1, k),
                "Skipped, duplicated or reordered coefficient column")
        # cap(n)>=k iff 142^2*n > 125^2*(k-1)^2, for k>=1.
        first = max(k + 1, (125 * 125 * (k - 1) ** 2) // (142 * 142) + 1)
        expected = 0 if k == 0 else max(0, N - first + 1)
        require(row["checks"] == expected, "Column coverage count mismatch")
        require(row["inconclusive"] == 0 and row["first_inconclusive_n"] == 0,
                "A strict integer comparison was not certified")
        total += expected
        column_counts.append(expected)
    # Independent row-wise sum, with integer-only ceiling calculation.
    require(total == sum(min(n - 1, cap(n)) for n in range(1, N + 1))
            == 8492344, "Total required-index count mismatch")
    require(end["checks"] == total and end["inconclusive"] == 0,
            "Completion aggregate mismatch")
    require(end["full_tail_reduced_coverage"] is True
            and end["needed_K"] == K, "Incomplete tail-reduced coverage")
    require(Fraction(142, 125) ** 2 > Fraction(355, 113) ** 2 / 3 - 2,
            "Finite tail cap too small")
    require(Fraction(142, 125) ** 2 < Fraction(13, 10),
            "Finite and analytic caps incompatible")
    analytic = json.loads((root / "verified_h100_constants.json").read_text())
    eta = json.loads((root / "eta_derivatives/verified_constants.json").read_text())
    for report in (analytic, eta):
        require(report["status"] == "all exact rational assertions passed",
                "Analytic rational checks failed")
    require(analytic["n_cutoff"] == 50000 and N + 1 >= analytic["n_cutoff"],
            "Gap between finite and infinite ranges")
    report = {
        "status": "all required finite inequalities and coverage checks passed",
        "finite_n_range": [1, N], "analytic_n_range": [50000, "infinity"],
        "computed_columns": K, "fractional_bits": b,
        "strict_integer_comparisons": total, "column_checks": column_counts,
        "source_sha256": EXPECTED[source],
        "finite_log_path": str(path), "finite_log_sha256": sha(path.read_bytes()),
        "note": "Log hash records this replay only; timings differ across runs."
    }
    (root / "reproduction_coverage.json").write_text(
        json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


def main():
    require(sys.flags.optimize == 0, "Do not run with Python optimization (-O)")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("tex", type=Path)
    parser.add_argument("directory", type=Path)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--full", action="store_true")
    mode.add_argument("--audit-log", type=Path)
    mode.add_argument("--extract-only", action="store_true")
    parser.add_argument("--cxx", default="g++")
    args = parser.parse_args()
    root = args.directory.resolve()
    manifest = extract(args.tex.resolve(), root)
    print("Extracted and hash-verified", len(manifest), "source listings.")
    if args.extract_only:
        return
    env = dict(os.environ)
    env.pop("PYTHONOPTIMIZE", None)
    eta = run_json(root / "eta_derivatives/verify_constants.py",
                   root / "eta_derivatives/verified_constants.json", env)
    analytic = run_json(root / "verify_h100_constants.py",
                        root / "verified_h100_constants.json", env)
    for value in (eta, analytic):
        require(value["status"] == "all exact rational assertions passed",
                "Analytic scalar checker did not pass")
    source = root / "finite_verifier/fixedpoint_verify.cpp"
    binary = root / "finite_verifier/fixedpoint_verify"
    definition = '-DCERT_SOURCE_SHA256="' + sha(source.read_bytes()) + '"'
    subprocess.run([args.cxx, "-O3", "-std=c++17", definition, str(source),
                    "-lgmpxx", "-lgmp", "-o", str(binary)], check=True, env=env)
    test = run_json(root / "finite_verifier/test_fixedpoint_verify.py",
                    root / "finite_verifier/test_fixedpoint_verify.json", env)
    require(test["all_passed"] is True, "Independent small-range audit failed")
    print("Analytic checks, compilation and independent small audits passed.")
    if args.full:
        log = root / "full_N50000.jsonl"
        require(not log.exists(), "Refusing to overwrite existing full-run log")
        print("Running the complete finite scan; wait for its completion.", flush=True)
        with log.open("w", encoding="utf-8") as out:
            subprocess.run([str(binary), "50000", "256", "64", "1"],
                           stdout=out, check=True, env=env)
        audit_log(log, root)
    elif args.audit_log:
        audit_log(args.audit_log.resolve(), root)
    else:
        print("No full finite claim: add --full or --audit-log COMPLETED_LOG.")


if __name__ == "__main__":
    main()
