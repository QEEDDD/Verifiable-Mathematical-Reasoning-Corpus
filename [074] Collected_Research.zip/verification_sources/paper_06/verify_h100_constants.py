#!/usr/bin/env python3
"""Exact rational scalar checks for direct_determinant_h100.md."""
from fractions import Fraction as F
import json
from pathlib import Path

def exp_lower(x, terms):
    x=F(x); s=z=F(1)
    for j in range(1,terms+1):
        z=z*x/j; s+=z
    return s

a=F(7,8); b=F(9,8); a2=F(37,50)
# Rounded real-axis inputs are weaker than eta_derivatives' certified values.
assert F(51,50)<F(103,100)
assert F(199,200)>F(19,20)
assert F(201,200)<F(11,10)
assert F(329,100)<F(33,10)
assert F(401,200)<F(5,2) and F(601,100)<8
# Core quartic comparisons and monotonicity in v=lt>=0.
assert 8*F(82,25)-40*F(19,20)<0
assert F(40)/F(82,25)==F(500,41)
assert F(125,1107)<F(1,8)
assert F(125,492)<F(13,50)
# c^2/sigma^6 decreases with u: derivative numerator has negative coefficients.
assert 5*F(82,25)-3*F(19,20)*10<0
assert 5*F(19,20)-3*F(19,20)*F(5,2)<0
assert F(100)/(36*F(82,25)**3)<F(2,25)
assert F(2,25)*F(1,100)==F(1,1250)
# sigma_l delta>6.
assert F(82,25)/(9*F(1,100))>36
# Exact positive exponential lower bounds.
assert exp_lower(13,100)>400000
assert exp_lower(19,150)>150000000
assert exp_lower(49,250)>10**21
assert exp_lower(F(81,4),150)>10**8 # lower-Gaussian tail e^{-20.25}
# Elementary sin and sinh envelopes on [0,1/200].
x=F(1,200)
assert 1-x*x/6>F(99,100)
# sinh(x)/x <= sum (x^2)^j = 1/(1-x^2).
assert 1/(1-x*x)<F(101,100)
assert F(9801,40804+9801)>F(19,100)
assert F(9801,10201+9801)>F(49,100)
# Variance upper powers.
assert F(33,5)<F(13,5)**2
assert F(33,5)**3<18**2
# All t^{-p} exp(-c/t) used are increasing on (0,1/100].
for p,c in [(F(1,2),F(19,100)),(F(3,2),F(19,100)),
            (F(3,2),F(49,100)),(F(9,2),F(49,100))]:
    assert F(1,100)<c/p
# Near tail after x>=6, using exponent >=13 and standard Gaussian bounds.
near0=2/(a2*6)/400000
near2=2*(6/a2+1/(a2*a2*6))/400000
assert near0<F(1,500000)
assert near2<F(1,20000)
mid0=F(26,150000000); mid2=F(18000,150000000)
far0=F(44,7)*F(13,5)*1000/F(10**21)
far2=F(2,3)*F(22,7)**3*18*10**9/F(10**21)
tail0=near0+mid0+far0; tail2=near2+mid2+far2
assert tail0<F(1,100000)
assert tail2<F(1,5000)
# Gaussian full moments with pi<22/7.
assert (F(27,10)-F(1,100000))**2>F(44,7)/a
assert (F(31,10)-F(1,5000))**2>F(44,7)/a**3
# Lower Gaussian tail at sigma*delta>=6 is below 1e-8.
assert 2/(b*6)/10**8<F(1,10**8)
# Elementary square root enclosures used for I.
assert F(5,2)**2<F(628,100) # 2pi>6.28, follows eta checker Machin enclosure.
assert F(51,20)**2>F(44,7)
assert F(47,50)**2<1/b
assert (1/a)**7<F(8,5)**2
phase=F(15,2)*F(51,20)*F(1,1250)*F(8,5)
I_lower=F(5,2)*F(47,50)-phase-F(1,10**8)-F(1,100000)
assert I_lower>F(23,10)
# Final ratio R(u) increases: derivative of u(A+Bu)/(C+Du)^2.
A=F(33,10); B=F(11,10); C=F(6541,2000); D=F(19,20)
assert A*C>0 and 2*B*C-A*D>0
ratio3=3*F(103,100)**2*(A+3*B)/(C+3*D)**2
assert ratio3<F(9,16)
assert F(837,100)*F(9,16)<F(529,100)
# Coverage: sqrt(1.3n)+1<=sqrt(1.4n) at n>=N.
N=50000
# It is enough to show n/10-1 >= 2sqrt(13n/10), increasing relatively thereafter.
assert F(N,10)>1
assert (F(N,10)-1)**2>4*F(13*N,10)
# (n/10-1)/sqrt n increases for positive n.
assert (N-16500)**2>103**2*F(7*N,5)
assert N>16500
# u>=3 contradicts u^2 <= (7/5)(33/20+(103/100)u).
assert 9>F(7,5)*(F(33,20)+3*F(103,100))
assert 6>F(7,5)*F(103,100)
result={"status":"all exact rational assertions passed","n_cutoff":N,
        "t_max":"1/100","kt_max":"3","I_sigma_lower":"23/10",
        "J0_sigma_upper":"27/10","J2_sigma3_upper":"31/10",
        "tail0_sigma_upper":str(tail0),"tail2_sigma3_upper":str(tail2),
        "computed_I_sigma_lower":str(I_lower),"final_ratio_at_u3":str(ratio3),
        "final_ratio_upper":"9/16","finite_certificate_status":"pending independent audit and full scan"}
path=Path(__file__).with_name('verified_h100_constants.json')
path.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
