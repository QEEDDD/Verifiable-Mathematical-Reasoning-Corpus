"""Independent exact audit of certify.cpp; coin-change is the oracle."""
import json, math, subprocess, pathlib, hashlib, time
from fractions import Fraction
DIR=pathlib.Path(__file__).parent
N=350
start=time.time()

def coin_partitions(M,k=None):
 a=[0]*(M+1);a[0]=1
 for part in range(1,M+1):
  if k is not None and part%k==0:continue
  for n in range(part,M+1):a[n]+=a[n-part]
 return a
p=coin_partitions(N+1)
assert [n for n in range(1,26) if p[n]**2 < p[n-1]*p[n+1]] == list(range(1,26,2))
assert all(p[n]**2 != p[n-1]*p[n+1] for n in range(1,26))
# Generate generalized pentagonal numbers by signed r, then sort independently.
pent=sorted((r*(3*r-1)//2,(-1)**(abs(r)-1)) for r in range(-N,N+1) if r and r*(3*r-1)//2<=N+1)
p_euler=[1]+[0]*(N+1)
for n in range(1,N+2):p_euler[n]=sum(sign*p_euler[n-g] for g,sign in pent if g<=n)
assert p==p_euler
assert all(p[n]*p[n]>p[n-1]*p[n+1] for n in range(26,N+1))
base_margins=[]
for m in range(27):
 lhs=p[m]*p[27]**(27-m);rhs=p[27]*p[26]**(27-m)
 assert lhs<=rhs;base_margins.append(rhs-lhs)
# Verify geometric envelope directly, not through the inductive argument.
envelope_checks=0
for n in range(27,N+1):
 for m in range(n):
  assert p[m]*p[n]**(n-m)<=p[n]*p[n-1]**(n-m)
  envelope_checks+=1
cutoff={26:30};details={};maxk=30
for n in range(27,N+1):
 square=p[n]**2;D=square-p[n-1]*p[n+1]
 L=math.isqrt(n)
 if L*L<n:L+=1
 while L*p[n-1]>(L-1)*p[n]:L+=1
 assert 8*(L-1)**L<3*L**L
 j=1;a=3;b=8
 while 2*a*square>=D*(b-a):j+=1;a*=3;b*=8
 cutoff[n]=min(n+2,j*L);maxk=max(maxk,cutoff[n]);details[n]=(L,j,D)
 # Independent direct rational cutoff inequality when transfer is used.
 k=j*L
 u=p[n-1]**k;v=p[n]**k
 assert 2*u*square<D*(v-u)

numerator_checks=0;lc_checks=0;engine_queries=0
for k in range(1,N+3):
 b=coin_partitions(N+1,k)
 # Euler numerator formula, independent of original's lo optimization.
 e=[p[n]-sum(sign*p[n-k*g] for g,sign in pent if k*g<=n) for n in range(N+2)]
 assert b==e,(k,'Euler numerator mismatch')
 numerator_checks+=N+2
 if k<30:continue
 lo=next((n for n in range(27,N+1) if k<cutoff[n]),N+1)
 optimized=p.copy()
 for g,sign in pent:
  shift=k*g
  if shift>N+1:break
  for n in range(max(lo-1,shift),N+2):optimized[n]-=sign*p[n-shift]
 for n in range(26,N+1):
  assert b[n]**2>b[n-1]*b[n+1],(k,n,'LC failure')
  lc_checks+=1
  if n>=27 and k<cutoff[n]:
   assert optimized[n-1:n+2]==b[n-1:n+2],(k,n,'optimized neighbor mismatch')
   engine_queries+=1
  elif k>=n+2 or n==26:
   assert b[n-1:n+2]==p[n-1:n+2]
  else:
   L,j,D=details[n]
   assert k>=j*L
   a=3**j;c=8**j
   # Direct actual deficit check against the claimed upper bound.
   assert (p[n]-b[n])*(c-a)<=a*p[n]

binary=DIR/'audit_certify'
subprocess.run(['g++','-O2','-std=c++17',str(DIR/'certify.cpp'),'-lgmpxx','-lgmp','-o',str(binary)],check=True)
r=subprocess.run([str(binary),str(N)],capture_output=True,text=True,check=True)
engine=json.loads(r.stdout)
assert engine['exact_checks']==engine_queries,(engine,engine_queries)
assert engine['max_k_exclusive']==maxk
report={
 'N':N,'ordinary_partition_values_compared':N+2,'regular_partition_values_compared':numerator_checks,
 'geometric_envelope_pairs_compared':envelope_checks,'direct_LC_pairs_compared':lc_checks,
 'engine_exact_queries_compared':engine_queries,'engine_max_k_exclusive':maxk,
 'n25_difference':p[25]**2-p[24]*p[26], 'n26_difference':p[26]**2-p[25]*p[27],
 'base27_all_pass':True, 'cutoff_inequalities_exact_pass':True,
 'source_sha256':hashlib.sha256((DIR/'certify.cpp').read_bytes()).hexdigest(),
 'status':'PASS','seconds':time.time()-start,
}
assert report['n25_difference']<0<report['n26_difference']
(DIR/'audit_independent_results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
