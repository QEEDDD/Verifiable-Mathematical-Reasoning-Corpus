"""Independent coin-change oracle and fresh full-source replay for k=2,...,29."""
import hashlib,json,pathlib,subprocess,time
D=pathlib.Path(__file__).parent
src=D/'check_small_moduli.cpp';data=D/'small_moduli_65798.jsonl'
start=time.time();N=500
records=[json.loads(line) for line in data.read_text().splitlines() if line.strip()]
assert [r['k'] for r in records]==list(range(2,30))
assert all(r['N']==65798 for r in records)
for r in records:
 for field in ['negative','zero']:
  assert r[field]==sorted(set(r[field]))
  assert all(1<=n<=65798 for n in r[field])
 assert not set(r['negative'])&set(r['zero'])

def coin(k=None):
 b=[1]+[0]*(N+1)
 for part in range(1,N+2):
  if k is not None and part%k==0:continue
  for n in range(part,N+2):b[n]+=b[n-part]
 return b
p=coin()
# Independent signed-index pentagonal generation.
gpent=sorted((j*(3*j-1)//2,(-1)**abs(j)) for j in range(-N,N+1) if j and j*(3*j-1)//2<=N+1)
table=[];values=0;neg=0;zero=0
for r in records:
 k=r['k'];b=coin(k)
 e=[p[n]+sum(s*p[n-k*g] for g,s in gpent if k*g<=n) for n in range(N+2)]
 assert b==e,(k,'b coefficient mismatch')
 negative=[n for n in range(1,N+1) if b[n]**2<b[n-1]*b[n+1]]
 zeros=[n for n in range(1,N+1) if b[n]**2==b[n-1]*b[n+1]]
 assert negative==[n for n in r['negative'] if n<=N],(k,'negative list mismatch')
 assert zeros==[n for n in r['zero'] if n<=N],(k,'zero list mismatch')
 assert not [n for n in r['negative']+r['zero'] if n>N],(k,'unexpected late exception')
 cutoff=max(negative+zeros)+1
 assert b[cutoff-1]**2<=b[cutoff-2]*b[cutoff]
 assert b[cutoff]**2>b[cutoff-1]*b[cutoff+1]
 table.append({'k':k,'finite_last_nonpositive_plus_one':cutoff,'negative':negative,'zero':zeros})
 values+=N+2;neg+=len(negative);zero+=len(zeros)
# Recompile the untouched source; its hard-coded N remains 65798.
binary=D/'audit_small_moduli'
subprocess.run(['g++','-O2','-std=c++17','-Wall','-Wextra',str(src),'-lgmpxx','-lgmp','-o',str(binary)],check=True)
r=subprocess.run([str(binary)],capture_output=True,text=True,check=True)
replay=[json.loads(line) for line in r.stdout.splitlines() if line.strip()]
assert replay==records,'fresh full-source output differs from recorded artifact'
(D/'audit_small_moduli_replay_65798.jsonl').write_text(r.stdout)
report={'status':'PASS','oracle_N':N,'full_replay_N':65798,'moduli':28,
'coefficient_values_compared':values,'oracle_determinants_compared':28*N,
'full_replay_determinants':28*65798,'negative_count':neg,'zero_count':zero,
'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),
'data_sha256':hashlib.sha256(data.read_bytes()).hexdigest(),
'full_replay_exit_code':r.returncode,'seconds':time.time()-start,'finite_threshold_table':table,
'all_n_status':'NOT ESTABLISHED BY THIS FINITE AUDIT; requires separately verified analytic tail'}
(D/'audit_small_moduli_results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='finite_threshold_table'},indent=2))
print('threshold table:',[(x['k'],x['finite_last_nonpositive_plus_one']) for x in table])
