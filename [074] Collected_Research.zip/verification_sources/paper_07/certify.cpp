#include <gmpxx.h>
#include <vector>
#include <iostream>
#include <cmath>
#include <chrono>
#include <algorithm>
int main(int argc,char**argv){
 int N=argc>1?std::stoi(argv[1]):10000;if(N<30||N>300000)return 1;
 auto start=std::chrono::steady_clock::now();
 std::vector<mpz_class> p(N+2);p[0]=1;
 std::vector<std::pair<int,int>> pent;
 for(int r=1;;r++){int a=r*(3*r-1)/2,b=r*(3*r+1)/2;if(a>N+1)break;pent.push_back({a,r%2?1:-1});if(b<=N+1)pent.push_back({b,r%2?1:-1});}
 for(int n=1;n<=N+1;n++)for(auto [g,s]:pent){if(g>n)break;if(s==1)p[n]+=p[n-g];else p[n]-=p[n-g];}
 // Geometric dominance base at 27, exact integer powers.
 for(int m=0;m<27;m++){mpz_class a,b;mpz_pow_ui(a.get_mpz_t(),p[27].get_mpz_t(),27-m);a*=p[m];mpz_pow_ui(b.get_mpz_t(),p[26].get_mpz_t(),27-m);b*=p[27];if(a>b){std::cerr<<"base fail";return 2;}}
 std::vector<int> cutoff(N+1);int maxk=30;
 for(int n=26;n<=N;n++){
  mpz_class square=p[n]*p[n],D=square-p[n-1]*p[n+1];if(D<=0){std::cerr<<"p LC fail "<<n;return 2;}
  if(n==26){cutoff[n]=30;continue;}
  int L=(int)std::ceil(std::sqrt(n));while(L*p[n-1]>(L-1)*p[n])L++;
  // (1-1/L)^L < 3/8, via e>8/3. If k>=jL, deficit <=3^j/(8^j-3^j).
  int j=1;mpz_class a=3,b=8;
  while(2*a*square>=D*(b-a)){a*=3;b*=8;j++;}
  cutoff[n]=std::min(n+2,j*L);maxk=std::max(maxk,cutoff[n]);
 }
 unsigned long long checks=0;
 for(int k=30;k<maxk;k++){
  int lo=N+1;for(int n=27;n<=N;n++)if(k<cutoff[n]){lo=n;break;}if(lo>N)continue;
  std::vector<mpz_class>b=p;
  for(auto [g,s]:pent){long long shift=1LL*g*k;if(shift>N+1)break;for(int n=std::max(lo-1,(int)shift);n<=N+1;n++){if(s==1)b[n]-=p[n-shift];else b[n]+=p[n-shift];}}
  for(int n=lo;n<=N;n++)if(k<cutoff[n]){checks++;if(b[n]*b[n]<=b[n-1]*b[n+1]){std::cout<<"FAIL k="<<k<<" n="<<n<<std::endl;return 3;}}
  if(k%250==0)std::cerr<<"k="<<k<<"/"<<maxk<<" checks="<<checks<<std::endl;
 }
 double secs=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
 std::cout<<"{\"N\":"<<N<<",\"all_k_ge\":30,\"exact_checks\":"<<checks<<",\"max_k_exclusive\":"<<maxk<<",\"seconds\":"<<secs<<",\"status\":\"PASS\"}"<<std::endl;
}
