#!/usr/bin/env python3
"""Exact rational numeric checks for the all-modulus theorem in this manuscript."""
from fractions import Fraction as Q
from math import factorial
from pathlib import Path
import json

def atan_enclosure(x, terms=40):
    s=sum(((-1)**j*x**(2*j+1)/(2*j+1) for j in range(terms)),Q(0))
    z=s+(-1)**terms*x**(2*terms+1)/(2*terms+1)
    return min(s,z),max(s,z)
def exp_lower(x,terms=250):
    return sum((x**j/factorial(j) for j in range(terms)),Q(0))
a,b=atan_enclosure(Q(1,5));c,d=atan_enclosure(Q(1,239))
plo,phi=16*a-4*d,16*b-4*c
Alo,Ahi=plo**2/6,phi**2/6
t=Q(1,200);alpha=Q(747,1000);r=Q(28,1000)
checks={}
def check(name,statement):
    checks[name]=bool(statement)
    assert statement,name
check('saddle threshold <65798',Ahi/t**2<65798)
check('variance upper <3.3/t^3',2*Ahi+t<Q(33,10))
check('quartic loss <.253',(12*Ahi+24*t)/(48*(Alo-t))<Q(253,1000))
check('skew ratio <.028',(3*Ahi+2*t)**2/(Alo-t)**3*t<r)
check('1/(4V)<1e-6',t**3/(4*(Alo-t))<Q(1,10**6))
check('standardized core endpoint >9',(Alo-t)/(4*t)>81)
# Normal second moment bound sqrt(2/pi)*(9+1/9)*exp(-81/2)<1e-15.
check('both Gaussian tail losses <1e-15',Q(82,9)/exp_lower(Q(81,2))<Q(1,10**15))
check('sin x >=.999x for x<=.04',1-Q(4,100)**2/6>Q(999,1000))
# sinh(x)/x <=1+(x^2/6)/(1-x^2/20), by ratios in the tail series.
check('sinh x <=1.001x for x<=.04',1+(Q(4,100)**2/6)/(1-Q(4,100)**2/20)<Q(1001,1000))
check('near tail S ratio >.199',Q(999,1000)**2/(4*Q(1001,1000)**2+Q(999,1000)**2)>Q(199,1000))
check('far tail S ratio >.499',Q(999,1000)**2/(Q(1001,1000)**2+Q(999,1000)**2)>Q(499,1000))
H2=sum((Q(1,j*j) for j in range(1,11)),Q(0));H1=sum((Q(1,j) for j in range(1,11)),Q(0))
check('H10 second >1.549',H2>Q(1549,1000))
check('H10 first <2.93',H1<Q(293,100))
check('near tail exponent >.15',Q(199,1000)*(H2/2-t*H1/2)>Q(15,100))
check('far tail exponent >.15',(Q(1,2)-t/2)*Q(499,1000)>Q(15,100))
check('A phase loss <.152',(r*Q(105,72))**2*alpha**(-9)<Q(152,1000)**2)
check('B phase loss <.017',(r*Q(15,72))**2*alpha**(-7)<Q(17,1000)**2)
check('A core >.847',1-Q(1,10**6)-Q(152,1000)-Q(1,10**15)>Q(847,1000))
check('B core >.982',1-Q(1,10**6)-Q(17,1000)-Q(1,10**15)>Q(982,1000))
expsq=1/exp_lower(2*Q(15,100)/t)
check('A tail loss <.128',32*phi*Q(33,10)**3*t**(-9)*expsq<Q(128,1000)**2)
check('B tail loss <2e-9',2*phi*Q(33,10)*t**(-3)*expsq<Q(2,10**9)**2)
check('both tail bounds increase with t',Q(15,100)>Q(9,2)*t)
check('A final >.719',Q(847,1000)-Q(128,1000)>=Q(719,1000))
check('B final >.981',Q(982,1000)-Q(2,10**9)>Q(981,1000))
result={'method':'exact Fraction arithmetic, Machin pi enclosure, positive exponential Taylor partial sums','passed':sum(checks.values()),'total':len(checks),'checks':checks,'analytic_cutoff':65798,'moduli':'all integers k>=2'}
p=Path(__file__).with_name('constants_certificate.json');p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
