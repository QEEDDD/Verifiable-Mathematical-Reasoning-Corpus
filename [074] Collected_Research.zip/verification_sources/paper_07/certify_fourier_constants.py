#!/usr/bin/env python3
"""Exact rational certificate for the 25703 Fourier proof constants.

No floating-point assertion is used. Pi is enclosed using Machin's identity
and alternating arctangent series; exponential upper bounds use reciprocals
of positive Taylor partial sums. See the analytic proof in this manuscript.
"""
from fractions import Fraction as Q
from math import factorial
from pathlib import Path
import json


def atan_enclosure(x, terms=40):
    s = sum(((-1) ** j * x ** (2*j+1) / (2*j+1)
             for j in range(terms)), Q(0))
    snext = s + (-1) ** terms * x ** (2*terms+1) / (2*terms+1)
    return min(s, snext), max(s, snext)


def exp_lower(x, terms=250):
    return sum((x**j / factorial(j) for j in range(terms)), Q(0))


a, b = atan_enclosure(Q(1, 5))
c, d = atan_enclosure(Q(1, 239))
pi_lo, pi_hi = 16*a-4*d, 16*b-4*c
zeta_lo, zeta_hi = pi_lo*pi_lo/6, pi_hi*pi_hi/6
t = Q(1, 125)
alpha = Q(63, 100)
r = Q(44, 1000)
checks = {}


def check(name, statement):
    checks[name] = bool(statement)
    assert statement, name


check('pi enclosure nonempty', pi_lo < pi_hi)
check('M3 constant < 13.1', zeta_hi*159/exp_lower(Q(3)) < Q(131, 10))
check('M4 constant < 56', zeta_hi*1848/exp_lower(Q(4)) < 56)
check('variance lower > 3.17/t^3', 2*zeta_lo*Q(29, 30)-t > Q(317, 100))
check('variance upper < 3.29/t^3', 2*zeta_hi < Q(329, 100))
check('saddle threshold < 25703', zeta_hi/t**2 < 25703)
check('squared sine ratio > .199', Q(999,1000)**2 /
      (4*Q(1001,1000)**2+Q(999,1000)**2) > Q(199,1000))
check('squared sine ratio > .499 in outer region', Q(999,1000)**2 /
      (Q(1001,1000)**2+Q(999,1000)**2) > Q(499,1000))
check('H10 > 1.549', sum((Q(1,j*j) for j in range(1,11)), Q(0)) > Q(1549,1000))
check('removed factor exponent < .08225/t', pi_hi*pi_hi/120 < Q(8225,100000))
check('transition exponent > .225/t', Q(199,1000)*Q(1549,1000)-Q(8225,100000) > Q(225,1000))
check('outer exponent > .225/t', Q(499,1000)-Q(8225,100000) > Q(225,1000))
check('quartic loss < .37', Q(56)/(48*Q(317,100)) < Q(37,100))
check('skew ratio r < .044', Q(131,10)**2/Q(317,100)**3*t < r)
check('1/(4V) < 1e-6', t**3/(4*Q(317,100)) < Q(1,10**6))
check('Gaussian cutoff > 9.95', Q(317,100)/(4*t) > Q(995,100)**2)
check('Gaussian tail epsilon < 1e-19', 11/exp_lower(Q(49)) < Q(1,10**19))
check('A moment loss < .514', (r*Q(105,72))**2 * alpha**(-9) < Q(514,1000)**2)
check('B moment loss < .047', (r*Q(15,72))**2 * alpha**(-7) < Q(47,1000)**2)
check('A core > .485', 1-Q(1,10**6)-Q(514,1000)-Q(1,10**19) > Q(485,1000))
check('B core > .952', 1-Q(1,10**6)-Q(47,1000)-Q(1,10**19) > Q(952,1000))
exp_sq_upper = 1/exp_lower(Q(225,4))
tail_a_sq_upper = 32*pi_hi*Q(329,100)**3*t**(-9)*exp_sq_upper
tail_b_sq_upper = 2*pi_hi*Q(329,100)*t**(-3)*exp_sq_upper
check('A tail relative loss < .101', tail_a_sq_upper < Q(101,1000)**2)
check('B tail relative loss < 1e-8', tail_b_sq_upper < Q(1,10**8)**2)
check('A tail bound increases with t', Q(225,1000) > Q(9,2)*t)
check('B tail bound increases with t', Q(225,1000) > Q(3,2)*t)
check('B total > .951', Q(952,1000)-Q(1,10**8) > Q(951,1000))

result = {
    'method': 'exact Fraction arithmetic; Machin pi enclosure; positive exp Taylor partial sums',
    'passed': sum(checks.values()),
    'total': len(checks),
    'checks': checks,
    'pi_enclosure_width_denominator': (pi_hi-pi_lo).denominator,
    'analytic_threshold_n': 25703,
    'analytic_range_k': 'all integer k >= 30',
}
out = Path(__file__).with_name('fourier_constants_certificate.json')
out.write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({'passed': result['passed'], 'total': result['total'], 'output': str(out)}))
