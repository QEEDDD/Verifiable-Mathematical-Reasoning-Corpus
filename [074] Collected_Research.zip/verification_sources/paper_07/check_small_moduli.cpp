#include <gmpxx.h>
#include <vector>
#include <iostream>
int main(){const int N=65798;std::vector<mpz_class>p(N+2);p[0]=1;std::vector<std::pair<int,int>> pent;
for(int r=1;;r++){int a=r*(3*r-1)/2,b=r*(3*r+1)/2;if(a>N+1)break;pent.push_back({a,r%2?1:-1});if(b<=N+1)pent.push_back({b,r%2?1:-1});}
for(int n=1;n<=N+1;n++)for(auto[g,s]:pent){if(g>n)break;if(s==1)p[n]+=p[n-g];else p[n]-=p[n-g];}
for(int k=2;k<30;k++){std::vector<mpz_class>b=p;for(auto[g,s]:pent){int shift=g*k;if(shift>N+1)break;for(int n=shift;n<=N+1;n++){if(s==1)b[n]-=p[n-shift];else b[n]+=p[n-shift];}}
std::cout<<"{\"k\":"<<k<<",\"N\":"<<N<<",\"negative\":[";bool first=true;for(int n=1;n<=N;n++)if(b[n]*b[n]<b[n-1]*b[n+1]){if(!first)std::cout<<",";first=false;std::cout<<n;}std::cout<<"],\"zero\":[";first=true;for(int n=1;n<=N;n++)if(b[n]*b[n]==b[n-1]*b[n+1]){if(!first)std::cout<<",";first=false;std::cout<<n;}std::cout<<"]}"<<std::endl;
}}
