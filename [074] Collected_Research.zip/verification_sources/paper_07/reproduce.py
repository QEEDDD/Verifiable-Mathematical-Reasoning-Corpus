#!/usr/bin/env python3
import pathlib, re, subprocess, sys

if len(sys.argv) != 3:
    raise SystemExit("usage: replay.py MANUSCRIPT.tex NEW_DIRECTORY")
source = pathlib.Path(sys.argv[1]).read_text()
dest = pathlib.Path(sys.argv[2]).resolve()
dest.mkdir(parents=True, exist_ok=False)
pattern = (r"\\begin\{lstlisting\}\[label=src:(\w+),[^\n]*\]\n"
           r"(.*?)\n\\end\{lstlisting\}")
blocks = dict(re.findall(pattern, source, flags=re.S))
files = {"cpp": "certify.cpp", "oracle": "audit_independent.py",
         "constants": "certify_fourier_constants.py",
         "smallcpp": "check_small_moduli.cpp",
         "allkconstants": "certify_all_k_constants.py",
         "smallaudit": "audit_small_moduli.py"}
for tag, name in files.items():
    if tag not in blocks:
        raise SystemExit("missing source listing: " + tag)
    (dest / name).write_text(blocks[tag] + "\n")

def run(args):
    subprocess.run(args, cwd=dest, check=True)

run(["g++", "-O3", "-std=c++17", "certify.cpp",
     "-lgmpxx", "-lgmp", "-o", "certify"])
with (dest / "cert25703.json").open("w") as out:
    subprocess.run([str(dest / "certify"), "25703"],
                   cwd=dest, stdout=out, check=True)
import json
record = json.loads((dest / "cert25703.json").read_text())
assert record["N"] == 25703 and record["status"] == "PASS"
assert record["exact_checks"] == 43931660
assert record["max_k_exclusive"] == 2737
run([sys.executable, "certify_fourier_constants.py"])
run([sys.executable, "audit_independent.py"])
run(["g++", "-O3", "-std=c++17", "check_small_moduli.cpp",
     "-lgmpxx", "-lgmp", "-o", "check_small_moduli"])
with (dest / "small_moduli_65798.jsonl").open("w") as out:
    subprocess.run([str(dest / "check_small_moduli")],
                   cwd=dest, stdout=out, check=True)
records = [json.loads(line) for line in
           (dest / "small_moduli_65798.jsonl").read_text().splitlines()]
O = lambda m: list(range(1, m+1, 2))
expected = {2: [2,4,8,11,13,14,16,17,19,20,23,26,29,32],
            3: O(57), 4: [1,4,8,11,13,16], 5: O(41), 6: O(11),
            7: O(35), 8: [1,3,5,7,11,13,17,19], 9: O(33),
            10: O(19), 11: O(31), 12: O(21), 13: O(31),
            14: O(19)+[23], 23: O(25)+[29], 27: O(27),
            29: O(25)+[29]}
for k in (15,17,19,21): expected[k] = O(29)
for k in (16,18,20,22,24,25,26,28): expected[k] = O(25)
assert [z["k"] for z in records] == list(range(2,30))
for z in records:
    k = z["k"]
    assert z["N"] == 65798 and z["negative"] == expected[k]
    assert z["zero"] == ({2: [1], 4: [5,7]}.get(k, []))
run([sys.executable, "certify_all_k_constants.py"])
run([sys.executable, "audit_small_moduli.py"])
print("PASS: both finite certificates, all constants, both audits")
print("Reproduction records:", dest)
