import hashlib
import json
import math
from pathlib import Path

LIMIT = 100
DIGEST = ('ad3217b1c51edfdceb79419b85d2a21a412d'
          'ba1e559f8f7cc2e2280e2a30c947')
ZEROS = {(4, 2), (4, 4), (6, 3), (6, 5)}


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def forward(N, K, direct=False):
    rows = [[1] + [0]*K, [1] + [0]*K]
    for n in range(2, N+1):
        a, b = rows[-1], rows[-2]
        if direct:
            row = [a[k] + sum(b[k-1-2*j] for j in
                   range(min(n-2, (k-1)//2)+1))
                   for k in range(K+1)]
        else:
            row, sums = a.copy(), [0, 0]
            for k in range(K+1):
                if k >= 1:
                    sums[k % 2] += b[k-1]
                if k >= 2*n-1:
                    sums[k % 2] -= b[k-(2*n-1)]
                row[k] += sums[k % 2]
        rows.append(row)
    return rows


def newton(values):
    out = []
    while values:
        out.append(values[0])
        values = [b-a for a, b in zip(values, values[1:])]
    return out


def low_certificate():
    K = LIMIT
    Nmax = 3*K+3
    rows = forward(Nmax+3, K+2)
    require(rows == forward(Nmax+3, K+2, True),
            'Independent forward recurrences disagree')
    certificates = []
    small_checks = finite_all = newton_total = 0
    zeros = set()
    for k in range(2, K+1):
        N = k+3
        def D(n):
            return rows[n][k]**2-rows[n][k-2]*rows[n][k+2]
        values = [D(n) for n in range(N, N+2*k+1)]
        c = newton(values)
        require(len(c) == 2*k+1 and min(c) >= 0,
                f'Newton positivity failure at k={k}')
        require(c[-1] == math.comb(2*k, k)
                - math.comb(2*k, k-2), 'Leading coefficient')
        require((c[0] == 0) == (k == 3), 'Tail equality')
        if k == 3:
            require(c[1] > 0, 'Tail strictness')
            zeros.add((N, k))
        for x in range(2*k+1, 2*k+4):
            require(sum(v*math.comb(x, j)
                    for j, v in enumerate(c)) == D(N+x),
                    'Polynomial replay beyond interpolation')
        for n in range(4, N):
            require(D(n) >= 0, f'Finite lower base: {n},{k}')
            finite_all += 1
            if 2 <= k <= n*(n-1)//2-2:
                small_checks += 1
                if D(n) == 0:
                    zeros.add((n, k))
        newton_total += len(c)
        certificates.append({
            'k': k, 'base_n': N, 'degree_bound': 2*k,
            'newton_coefficients': c})
    require((newton_total, finite_all, small_checks)
            == (10197, 4950, 4279), 'Lower counts')
    require(zeros == ZEROS, 'Lower equality classification')
    artifact = {
        'method': 'exact nonnegative Newton-basis polynomial certificates',
        'claim': f'For every n>=4 and 2<=k<={K}, a[n,k]^2 >= a[n,k-2]*a[n,k+2].',
        'status': 'infinite n, bounded k; NOT the full Dukes conjecture',
        'maximum_k': K,
        'newton_coefficients': newton_total,
        'finite_remaining_in_domain_checks': small_checks,
        'two_recurrence_implementations_agree_through_n': Nmax+3,
        'certificates': certificates}
    data = (json.dumps(artifact, indent=2)+'\n').encode()
    digest = hashlib.sha256(data).hexdigest()
    require(digest == DIGEST, 'Archived SHA-256 mismatch')
    Path('low_inversion_certificate_100.json').write_bytes(data)
    return {'newton_coefficients': newton_total,
            'finite_checks_all': finite_all,
            'finite_checks_admissible': small_checks,
            'equality_pairs': sorted(zeros), 'sha256': digest}


def upper_certificate():
    D = LIMIT
    K = D+2
    rows = [[1]+[0]*K, [1]+[0]*K]
    checks = 0
    zeros = set()
    # Independently use the reversed recurrence, not reversed
    # coefficients from the lower-strip implementation.
    for n in range(2, D+4):
        a, b = rows[-1], rows[-2]
        row = []
        for d in range(K+1):
            shifted = a[d-n+1] if d >= n-1 else 0
            row.append(shifted + sum(b[d-2*j] for j in
                       range(min(n-2, d//2)+1)))
        rows.append(row)
        if n < 4:
            continue
        for p in (0, 1):
            support = [j for j, x in enumerate(row[p::2])
                       if x > 0]
            require(not support or support ==
                    list(range(support[0], support[-1]+1)),
                    f'Upper prefix support: {n},{p}')
        for d in range(2, D+1):
            defect = row[d]**2-row[d-2]*row[d+2]
            require(defect >= 0, f'Upper base: {n},{d}')
            checks += 1
            if n in (D+2, D+3):
                require(defect > 0, 'Terminal strictness')
            Nn = n*(n-1)//2
            if d <= Nn-2 and defect == 0:
                zeros.add((n, Nn-d))
    require(checks == 9900, 'Upper count')
    require(zeros == ZEROS, 'Upper equality classification')
    # Cross-check full forward rows through n=35.
    full = [[1], [1]]
    for n in range(2, 36):
        a = [0]*(n*(n-1)//2+1)
        a[:len(full[-1])] = full[-1]
        for shift in range(1, 2*n-2, 2):
            for k, x in enumerate(full[-2]):
                a[k+shift] += x
        full.append(a)
        reverse = a[::-1]
        for d in range(K+1):
            expected = reverse[d] if d < len(reverse) else 0
            require(rows[n][d] == expected,
                    f'Forward/reverse cross-check: {n},{d}')
    return {'base_n_through': D+3, 'inequalities': checks,
            'terminal_rows_strict': [D+2, D+3],
            'equality_pairs': sorted(zeros)}


def main():
    report = {'lower_strip': low_certificate(),
              'upper_strip': upper_certificate(),
              'status': 'PASS: both infinite width-100 edge strips',
              'scope': 'NOT the full Dukes conjecture; no linear-window threshold'}
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()

