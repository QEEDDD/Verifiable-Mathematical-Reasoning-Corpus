KEIO — T91–T95, new attempt
27 October 2026

Manuscript
  Lucky-Car Reciprocity via Prescribed Forests,
  and Four Further Investigations

The PDF and standalone LaTeX source contain the mathematical proofs,
original target statements, primary references, and exact scope limits.
No track is certified as satisfying every requested condition concerning
historically unprecedented principles and worldwide priority.

RESULTS AND LIMITS

T91: Full lucky-set identity of Avila–Ferroni–Morales, Conjecture 5.1,
     for every positive integer parameter vector and every subset.
     The argument constructs an explicit weighted bijection and its
     first-hit inverse, then uses the source's established Proposition
     4.13. The all-parameter proof is in the manuscript. Internal reviews
     found no gap; external peer review and worldwide priority are not
     established.

T92: The zero-residue branch of Ulas Question 2.10 is proved with a
     superpolylogarithmic lower bound. The residue-one branch remains
     unresolved here, so the original two-branch question is not closed.

T93: Exact Somos–8 identities for Barry Conjectures 11 and 12 and the
     original continued fraction in Conjecture 13. A conflicting printed
     generating function in 13 is explicitly identified. The infinite
     rank argument comes from Hone's established theorem. This is not
     claimed to be a historically new foundational mechanism.

T94: Exact minimum cubelike-GRR valencies on two infinite subsequences
     and in four smaller dimensions. The full function requested in
     Arnadottir–Guo Problem 8.3 remains undetermined.

T95: Sun Conjecture 4.8, p = 3 mod 4 branch, is proved for all four
     parameters. The complementary branch is credited to prior work.
     The signed inverse data used here are already implicit in earlier
     explicit formulas; the manuscript gives an alternative modulo-four
     derivation, not a certified historically unprecedented principle.

REPRODUCING THE EXACT CHECKS

Tested with Python 3.12 and SymPy 1.14.0. All programs except T92 use
only the standard library. Run without Python's -O optimization flag:
the programs use assertions for their exact checks.

From this directory:

  python3 -m pip install -r requirements.txt
  python3 t91_cartesian_verify.py
  python3 t91_independent_random_audit.py
  python3 t92_stern_growth_verify.py
  python3 t93_somos8_verify.py
  python3 t94_cubelike_verify.py
  python3 t95_sun48_verify.py

Each program writes its accompanying JSON output in this directory.
The independent T91 audit imports t91_cartesian_verify.py from the same
directory; keep those two files together.

T91: exhaustive auxiliary bijections in both directions through n = 5;
     400 seeded larger forest cases; original parking protocols for
     23 parameter vectors; negative controls; and a separate 720-case
     monotone-stack audit using nonconsecutive labels through n = 80.
T92: symbolic characteristic-two matrix identity; 367 binary-word
     instances; five independent integer-polynomial instances.
T93: 1,320 exact evaluations certify degree-bounded polynomial identities;
     three nonzero rank witnesses; independent determinant checks.
T94: 55 construction parameters; small full codeweight enumerations;
     finite rigidity certificates for the four smaller exact minima.
T95: 13 independently enumerated class numbers and 117 evaluations of
     the original determinant.

The T93 degree-bounded interpolation is part of an exact finite proof.
The other enumerations check implementations and examples; their
infinite conclusions rely on the written proofs, not extrapolation.

REBUILDING THE PDF

Use a LaTeX installation with the packages listed in the standalone TEX
preamble (a standard TeX Live installation suffices):

  pdflatex -interaction=nonstopmode -halt-on-error KEIO_T91_T95_Retry_2026-10-27.tex
  pdflatex -interaction=nonstopmode -halt-on-error KEIO_T91_T95_Retry_2026-10-27.tex
  pdflatex -interaction=nonstopmode -halt-on-error KEIO_T91_T95_Retry_2026-10-27.tex

The delivered PDF has 20 pages. It was checked for unresolved references,
TeX warnings, formula overflow, and page layout. No copyrighted primary
source PDFs are bundled; the manuscript bibliography links to them.

INTEGRITY

SHA256SUMS records each delivered file other than itself. Before rerunning
programs or rebuilding the PDF, verify the supplied files with:

  sha256sum -c SHA256SUMS

The source and verification programs are supplied for independent review.
They are not proof-assistant formalizations or external peer-review
certificates.
