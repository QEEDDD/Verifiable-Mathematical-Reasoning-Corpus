"""Exact finite tests for the Cartesian-gap bijection and AFM Conjecture 5.1.

Only Python standard library is used. Finite tests supplement, not replace,
the all-n proof in t91_cartesian_proof.tex.
"""
from collections import Counter
from itertools import permutations, product
from pathlib import Path
import json
import random


def is_pf(c):
    return all(a <= i + 1 for i, a in enumerate(sorted(c)))


def forward(order, forced, root_colors):
    """Outcome/gap choices -> parking colors and increasing parents."""
    pos = {v: i + 1 for i, v in enumerate(order)}
    parent = {}
    color = dict(root_colors)
    for v in order:
        p = max((i for i in range(pos[v] - 1) if order[i] > v), default=-1)
        if v in forced:
            parent[v] = order[p] if p >= 0 else None
        else:
            assert p + 1 < color[v] <= pos[v]
    for v in sorted(order, reverse=True):
        if v in forced:
            color[v] = color[parent[v]] if parent[v] is not None else 1
    assert is_pf(color.values())
    return color, parent


def inverse(labels, color, parent):
    """First-return split at the largest remaining car label."""
    n = len(labels)
    if not n:
        return ()
    assert is_pf(color.values())
    m = max(labels)
    desc = {m}
    changed = True
    while changed:
        changed = False
        for v, p in parent.items():
            if p in desc and v not in desc:
                desc.add(v)
                changed = True
    d = len(desc)
    a = color[m]
    k = next(s for s in range(a, n + 1)
             if sum(t <= s for t in color.values()) - s == d - 1)
    left = tuple(v for v in labels if v not in desc and color[v] <= k)
    right = tuple(v for v in labels if v != m and v not in left)
    assert len(left) == k - 1 and len(right) == n - k
    lc = {v: color[v] for v in left}
    rc = {v: 1 if v in desc else color[v] - k for v in right}
    lp = {v: parent[v] for v in left if v in parent}
    rp = {v: None if parent[v] == m else parent[v]
          for v in right if v in parent}
    assert all(p is None or p in left for p in lp.values())
    assert all(p is None or p in right for p in rp.values())
    return inverse(left, lc, lp) + (m,) + inverse(right, rc, rp)


def check_bijection(max_n=5):
    records = []
    for n in range(1, max_n + 1):
        labels = tuple(range(1, n + 1))
        forward_checks = reverse_checks = 0
        for bits in range(1 << n):
            forced = {j for j in labels if bits >> (j - 1) & 1}
            free = tuple(j for j in labels if j not in forced)
            for order in permutations(labels):
                pos = {v: i + 1 for i, v in enumerate(order)}
                bounds = {j: max((i + 1 for i in range(pos[j] - 1)
                                  if order[i] > j), default=0) for j in free}
                for roots in product(*(range(bounds[j] + 1, pos[j] + 1)
                                       for j in free)):
                    color, parent = forward(order, forced, dict(zip(free, roots)))
                    assert inverse(labels, color, parent) == order
                    forward_checks += 1
            for c in product(labels, repeat=n):
                if not is_pf(c):
                    continue
                color = dict(zip(labels, c))
                forced_sorted = tuple(sorted(forced))
                choices = [tuple(k for k in labels if k > j and color[k] == color[j])
                           + ((None,) if color[j] == 1 else ()) for j in forced_sorted]
                for ps in product(*choices):
                    parent = dict(zip(forced_sorted, ps))
                    order = inverse(labels, color, parent)
                    c2, p2 = forward(order, forced, {j: color[j] for j in free})
                    assert c2 == color and p2 == parent
                    reverse_checks += 1
        assert forward_checks == reverse_checks
        records.append({'n': n, 'all_forced_subsets': 1 << n,
                        'forward_inverse_checks': forward_checks,
                        'inverse_forward_checks': reverse_checks})
        print('bijection', records[-1], flush=True)
    return records


def direct_lucky_counts(y):
    u = []
    for v in y:
        u.append(v + (u[-1] if u else 0))
    n, m = len(y), u[-1]
    sparse, dense_dual = Counter(), Counter()
    for w in product(range(1, m + 1), repeat=n):
        if any(a > b for a, b in zip(sorted(w), u)):
            continue
        avail = set(u)
        mask = 0
        for j, a in enumerate(w):
            b = min(s for s in avail if s >= a)
            avail.remove(b)
            if b == a:
                mask |= 1 << j
        sparse[mask] += 1
        avail = set(range(2, m + 1))
        mask = 0
        for j, a in enumerate(w):
            options = [s for s in avail if s >= a]
            if options:
                b = min(options)
                avail.remove(b)
                if b == a:
                    mask |= 1 << j
        dual = sum((1 - ((mask >> j) & 1)) << (n - 1 - j) for j in range(n))
        dense_dual[dual] += 1
    assert sparse == dense_dual
    return {'y': list(y), 'parking_words': sum(sparse.values()),
            'all_exact_lucky_sets_match': True,
            'FHMS_counts_by_bitmask': {str(k): sparse[k] for k in range(1 << n)}}


def main():
    bijection = check_bijection()
    rng = random.Random(20261027)
    larger = []
    for n in (6, 10, 25, 50):
        labels = tuple(range(1, n + 1))
        for _ in range(100):
            c = [rng.randrange(1, i + 1) for i in labels]
            rng.shuffle(c)
            color = dict(zip(labels, c))
            parent = {}
            for j in labels:
                choices = [k for k in labels if k > j and color[k] == color[j]]
                if color[j] == 1:
                    choices.append(None)
                if choices and rng.randrange(2):
                    parent[j] = rng.choice(choices)
            order = inverse(labels, color, parent)
            c2, p2 = forward(order, set(parent),
                             {j: color[j] for j in labels if j not in parent})
            assert c2 == color and p2 == parent
        larger.append({'n': n, 'reproducible_random_forest_roundtrips': 100})
    # The first hit is essential: a later solution k=2 has an invalid left
    # parking vector in this example, whereas k=1 gives (3,1,2).
    color, parent = {1: 1, 2: 2, 3: 1}, {1: 3}
    assert inverse((1, 2, 3), color, parent) == (3, 1, 2)
    assert not is_pf([2])
    # Replacing nearest-greater-LEFT by RIGHT already fails the parking
    # condition for outcome (1,2), J={1}, root color c_2=2.
    assert not is_pf([2, 2])
    params = [y for n in range(1, 4) for y in product(range(1, 3), repeat=n)]
    params += [(1, 1, 1, 1), (1, 1, 1, 2), (1, 2, 1, 1),
               (2, 1, 2, 1), (2, 2, 2, 2), (1, 1, 1, 1, 1),
               (1, 2, 1, 1, 1), (2, 1, 1, 2, 1), (4, 3, 5)]
    direct = [direct_lucky_counts(y) for y in params]
    out = {'target': 'Avila--Ferroni--Morales, arXiv:2603.19194v2, Conjecture 5.1',
           'status': 'all finite exact checks passed',
           'bijection': bijection, 'larger_inverse_checks': larger,
           'negative_controls': {'later_cut_can_fail': True,
                                 'right_instead_of_left_can_fail': True},
           'direct_protocol_comparisons': direct,
           'scope': 'Finite checks supplement the separate all-n bijective proof; no priority certification.'}
    Path(__file__).with_suffix('.json').write_text(json.dumps(out, indent=2) + '\n')
    print('All checks passed:', len(direct), 'parameter vectors', flush=True)


if __name__ == '__main__':
    main()
