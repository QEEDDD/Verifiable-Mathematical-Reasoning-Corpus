from random import Random
from pathlib import Path
import importlib.util,json
spec=importlib.util.spec_from_file_location('candidate',Path(__file__).with_name('t91_cartesian_verify.py'))
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
rng=Random(914013)
records=[]
for n in (1,2,3,5,8,13,21,40,80):
    for trial in range(80):
        labels=tuple(sorted(rng.sample(range(1,10000),n)))
        while True:
            values=[rng.randrange(1,n+1) for _ in labels]
            if all(x<=i for i,x in enumerate(sorted(values),1)):break
        c=dict(zip(labels,values));parents={}
        for i in labels:
            choices=[j for j in labels if j>i and c[j]==c[i]]
            if c[i]==1:choices.append(None)
            if choices and rng.randrange(3)!=0:parents[i]=rng.choice(choices)
        out=module.inverse(labels,c,parents)
        assert tuple(sorted(out))==labels
        stack=[];nearest={};positions={}
        for pos,i in enumerate(out,1):
            while stack and stack[-1][0]<i:stack.pop()
            nearest[i]=stack[-1] if stack else (None,0)
            positions[i]=pos
            stack.append((i,pos))
        for i in labels:
            p,left=nearest[i]
            if i in parents:
                assert p==parents[i]
                assert c[i]==(1 if p is None else c[p])
            else:
                assert left<c[i]<=positions[i]
        records.append({'n':n,'trial':trial,'passed':True})
result={'status':'PASS','checks':len(records),'sizes':[1,2,3,5,8,13,21,40,80],
        'method':'Independent monotone-stack recovery of nearest-greater-left parents and all color-gap bounds on randomly generated parking-colored forests with nonconsecutive labels.',
        'seed':914013}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(result)
