"""Exact checks for the symmetric binary-word family for Ulas Question 2.10, r=0.
The asymptotic theorem is proved in t92_stern_growth.tex; finite tests alone are not proof.
"""
from functools import cache
from itertools import product
from pathlib import Path
import json
import sympy as s

t,q,h,u=s.symbols('t q h u');d=t+1

def red(e):return s.Poly(s.expand(e),t,q,h,u,modulus=2).as_expr()
def N(q,h):return s.Matrix([[d*q+h,q],[q+d*(1+h),d*q+1]])
def F(u):return s.Matrix([[d*u,u],[u+d,d*u+1]])
D=t*t*q*q+h
res=(N(q,h)*F(u)*N(q,h)-N(q+u*D,t*t*q*q)).applyfunc(red)
assert res==s.zeros(2)
assert red(N(q,h).det()-D)==0
assert red((s.Matrix([[d,1]])*N(q,h)*s.Matrix([0,1]))[0]-1)==0
L=s.Matrix([[t,0],[1,1]]);R=s.Matrix([[1,1],[0,t]])
for a in range(1,15):assert (L**a*R*L*R**a-F(t**a)).applyfunc(red)==s.zeros(2)
for c in range(1,15):assert (s.Matrix([[1,0]])*R*L*R**c-s.Matrix([[d,1]])).applyfunc(red)==s.zeros(1,2)

def word(aa,c):
 w=''
 for a in aa:w=w+'1'*a+'01'+'0'*a+w
 return w+'1'*c+'01'

def direct(w):
 # Independent bit-by-bit recursion, polynomial arithmetic encoded by integers.
 a,b=0,1
 for bit in w:
  if bit=='0':a,b=a<<1,a^b
  else:a,b=a^b,b<<1
 return a
checks=[];words=set()
for j in range(5):
 for aa in product(range(1,4),repeat=j):
  for c in range(1,4):
   w=word(aa,c)
   assert direct(w)==1
   assert len(w)==2*sum(2**(j-i-1)*(a+1) for i,a in enumerate(aa))+c+2
   assert w not in words;words.add(w)
   checks.append({'j':j,'a':aa,'c':c,'digits':len(w),'passes':True})
for j in (5,6,7,8):
 aa=tuple(1+(i%5) for i in range(j));w=word(aa,7)
 assert direct(w)==1
 checks.append({'j':j,'a':aa,'c':7,'digits':len(w),'passes':True})
# Exact integer recurrence checks confirm that only reduction mod 2 is used.
@cache
def integer_stern(n):
 if n<2:return (n,)
 if n%2==0:return (0,)+integer_stern(n//2)
 a,b=integer_stern(n//2),integer_stern(n//2+1)
 return tuple((a[k] if k<len(a) else 0)+(b[k] if k<len(b) else 0) for k in range(max(len(a),len(b))))
integer_checks=[]
for aa,c in [((),2),((1,),2),((2,3),4),((1,2,3),2),((3,1,2,1),3)]:
 w=word(aa,c);n=int(w,2);co=integer_stern(n)
 assert co[0]==1 and all(v%2==0 for v in co[1:])
 integer_checks.append({'a':aa,'c':c,'index':str(n),'degree':len(co)-1,'passes':True})
out={'target':'Ulas 2019 Question 2.10, residue r=0 only','status':'all checks passed','r1_status':'unresolved','matrix_residuals':[[str(res[i,j]) for j in range(2)] for i in range(2)],'block_checks':14,'tail_checks':14,'direct_binary_checks':checks,'integer_checks':integer_checks,'scope':'Exact symbolic matrix identities plus finite independent checks; the asymptotic counting proof is in the manuscript. No universal r=1 or historical-first claim.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
print('PASS:',len(checks),'binary checks,',len(integer_checks),'integer checks, symbolic normal-form identity')
