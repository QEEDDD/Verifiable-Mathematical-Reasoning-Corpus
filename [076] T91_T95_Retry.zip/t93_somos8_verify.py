#!/usr/bin/env python3
"""Exact finite certificate for coefficient identification in Barry 11--13.

The all-index rank theorem is Hone (2021), Theorem 5.5; it is NOT inferred
from these tests. Degree-bounded interpolation here proves four polynomial
identities exactly, which identify the recurrence coefficients uniquely.
Only Python's standard library is used. Do not run with -O.
"""
from fractions import Fraction
from pathlib import Path
import json


def determinant(matrix):
    """Fraction-free Bareiss elimination, with exact divisions checked."""
    a = [row[:] for row in matrix]
    if not a:
        return 1
    sign, previous, size = 1, 1, len(a)
    for k in range(size - 1):
        if a[k][k] == 0:
            pivot_row = next((i for i in range(k + 1, size) if a[i][k]), None)
            if pivot_row is None:
                return 0
            a[k], a[pivot_row] = a[pivot_row], a[k]
            sign = -sign
        pivot = a[k][k]
        for i in range(k + 1, size):
            for j in range(k + 1, size):
                numerator = a[i][j] * pivot - a[i][k] * a[k][j]
                assert numerator % previous == 0
                a[i][j] = numerator // previous
        for i in range(k + 1, size):
            a[i][k] = 0
        previous = pivot
    return sign * a[-1][-1]


def rational_determinant(matrix):
    """Independent ordinary Gaussian elimination over rational numbers."""
    a = [[Fraction(x) for x in row] for row in matrix]
    result = Fraction(1)
    for j in range(len(a)):
        p = next((i for i in range(j, len(a)) if a[i][j]), None)
        if p is None:
            return 0
        if p != j:
            a[j], a[p] = a[p], a[j]
            result = -result
        result *= a[j][j]
        for i in range(j + 1, len(a)):
            factor = a[i][j] / a[j][j]
            for k in range(j + 1, len(a)):
                a[i][k] -= factor * a[j][k]
    assert result.denominator == 1
    return int(result)


def moments(target, r, length):
    """Original continued fraction: A(x)g=1-r*x+x^3*(1-r*x)*g^2."""
    aa = {
        11: [1, -(r + 1), -1, r],
        12: [1, -(r + 1), r - 1],
        13: [1, -(r + 1), r - 2, r],
    }[target]
    g = []
    for n in range(length):
        value = (1 if n == 0 else -r if n == 1 else 0)
        value -= sum(aa[i] * g[n - i] for i in range(1, min(n + 1, len(aa))))
        for k, multiplier in ((3, 1), (4, -r)):
            if n >= k:
                value += multiplier * sum(g[j] * g[n - k - j] for j in range(n - k + 1))
        g.append(value)
    return g


def direct_moments(target, r, length):
    """Independent expansion of the original continued fraction, no A polynomial."""
    g=[]
    for n in range(length):
        value = int(n == 0)
        if target == 11:
            value += sum(r**(k-1)*g[n-k] for k in range(1,n+1))
            if n >= 2: value += g[n-2]
        else:
            if n >= 1: value += g[n-1]
            value += sum(r**(k-2)*g[n-k] for k in range(2,n+1))
            if target == 13 and n >= 2: value += g[n-2]
        if n >= 3: value += sum(g[k]*g[n-3-k] for k in range(n-2))
        g.append(value)
    return g


def hankel_values(target, r, max_index):
    g = moments(target, r, 2 * max_index + 1)
    return [determinant([[g[i + j] for j in range(n + 1)] for i in range(n + 1)])
            for n in range(max_index + 1)]


def coefficients(target, r):
    """Common denominator and numerators of the four printed coefficients."""
    if target == 11:
        den = r**4 - 2*r**3 + 8*r*r + 2*r - 9
        a = -(-r**8+8*r**7-21*r**6+40*r**5-35*r**4+24*r**3-71*r*r-8*r)
        b = 8*(r**9-6*r**8+17*r**7-30*r**6+15*r**5-14*r**4-r**3-14*r*r)
        c = 8*(r-1)*(r**10-2*r**8+29*r**7-32*r**6+39*r**5+18*r**4+11*r**3-r*r+r)
        d = -(-2*r**13+13*r**12-48*r**11+85*r**10-83*r**9+11*r**8-124*r**7+454*r**6-364*r**5+263*r**4+84*r**3+189*r*r+25*r+9)
    elif target == 12:
        den = r*r - 4*r + 3
        a = -(-r**4+11*r**3-26*r*r+16*r+5)
        b = -(-2*r**5+19*r**4-40*r**3+13*r*r+5*r)
        c = -(r-1)*(-3*r**6+12*r**5-15*r**4-25*r**3+62*r*r+36*r+5)
        d = -(-r**9+8*r**8-26*r**7+43*r**6-40*r**5+17*r**4+23*r**3-27*r*r-19*r-3)
    elif target == 13:
        den = 2*(r**3 - 3*r*r - 5*r + 7)
        a = -(r**7-8*r**6+25*r**5-20*r**4-37*r**3+75*r+28)
        b = (r+1)*(r**8-11*r**7+47*r**6-83*r**5+17*r**4+71*r**3+45*r*r-169*r+210)
        c = (r*r-1)*(3*r**8-29*r**7+115*r**6-225*r**5+181*r**4+105*r**3-255*r*r-235*r+84)
        d = -(r**10-17*r**9+96*r**8-212*r**7+54*r**6+594*r**5-796*r**4-36*r**3+721*r*r-329*r-588)
    else:
        raise ValueError(target)
    return den, (a, b, c, d)


def degree_bound(target, n):
    dd, degrees = {
        11: (4, (8, 9, 11, 13)),
        12: (2, (4, 5, 7, 9)),
        13: (3, (7, 9, 10, 10)),
    }[target]
    hh = lambda m: m * (m + 1)
    return max([dd + hh(n) + hh(n-8)] +
               [degrees[k-1] + hh(n-k) + hh(n-8+k) for k in range(1,5)])


def residual(target, r, n, h):
    den, cc = coefficients(target, r)
    return den*h[n]*h[n-8] - sum(cc[k-1]*h[n-k]*h[n-8+k] for k in range(1,5))


def main():
    result = {
        'targets': 'Barry arXiv:2211.12637v1, Conjectures 11--13 (original continued fractions)',
        'scope': 'Complete coefficient-identification certificate; all-index propagation requires Hone Theorem 5.5 and the written rank-specialization argument.',
        'new_principle_claim': False,
        'source_typo': 'Conjecture 13 printed Catalan denominator has +(r+1)x; its original continued fraction gives -(r+1)x. The latter is used here.',
        'interpolation': [], 'independent_checks': [], 'degenerate_integer_parameters': [],
    }
    for target in (11,12,13):
        bounds = [degree_bound(target,n) for n in range(8,12)]
        largest = max(bounds)
        per_index = [0]*4
        for r in range(largest+1):
            h = hankel_values(target,r,11)
            for j,n in enumerate(range(8,12)):
                if r <= bounds[j]:
                    value = residual(target,r,n,h)
                    assert value == 0, (target,r,n,value)
                    per_index[j] += 1
        h = hankel_values(target,2,11)
        matrix = [[h[n-k]*h[n-8+k] for k in range(1,5)] for n in range(8,12)]
        witness = determinant(matrix)
        assert witness != 0 and rational_determinant(matrix) == witness
        result['interpolation'].append({
            'conjecture':target, 'indices':[8,9,10,11], 'degree_bounds':bounds,
            'distinct_integer_evaluations':per_index, 'all_residuals_zero':True,
            'rank_witness_parameter':2, 'four_by_four_determinant':witness,
        })
        for r in (-3,-2,0,1,2,3,5):
            g=moments(target,r,29)
            assert g == direct_moments(target,r,29)
            h=hankel_values(target,r,14)
            for n in (2,5,8):
                matrix=[[g[i+j] for j in range(n+1)] for i in range(n+1)]
                assert rational_determinant(matrix)==h[n]
            vals=[residual(target,r,n,h) for n in range(8,15)]
            assert not any(vals)
            result['independent_checks'].append({'conjecture':target,'r':r,'indices':list(range(8,15)), 'all_residuals_zero':True})
        for r in range(-4,5):
            den,cc=coefficients(target,r)
            if den==0:
                result['degenerate_integer_parameters'].append({'conjecture':target,'r':r,'numerators':cc})
    result['all_checks_passed']=True
    out=Path(__file__).with_suffix('.json')
    out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':'PASS','output':str(out),'interpolation':result['interpolation'],'degeneracies':result['degenerate_integer_parameters']},indent=2))

if __name__=='__main__':
    main()
