"""Exact finite checks supplementing, not replacing, the T94 all-r proof."""
from itertools import permutations
from pathlib import Path
import json


def base_graph(r):
    lengths = {(0, 1): 2, (0, 2): 3, (0, 3): 1,
               (1, 2): r - 6, (1, 3): 1, (2, 3): 1}
    edges = []
    nxt = 4
    for (u, v), length in lengths.items():
        path = [u] + list(range(nxt, nxt + length - 1)) + [v]
        nxt += length - 1
        edges.extend(tuple(sorted(pair)) for pair in zip(path, path[1:]))
    assert nxt == r and len(edges) == r + 2
    neighbors = [set() for _ in range(r)]
    for u, v in edges:
        neighbors[u].add(v)
        neighbors[v].add(u)
    assert min(map(len, neighbors)) == 2
    assert all(not (neighbors[u] & neighbors[v]) for u, v in edges)
    preserving = []
    for p in permutations(range(4)):
        if all(lengths[tuple(sorted((p[u], p[v])))] == length
               for (u, v), length in lengths.items()):
            preserving.append(p)
    assert preserving == [(0, 1, 2, 3)]
    return edges, neighbors


def verify(r, full_code=False):
    edges, neighbors = base_graph(r)
    rigid = sorted([1 << i for i in range(r)] +
                   [(1 << u) ^ (1 << v) for u, v in edges])
    rigid_set = set(rigid)
    assert len(rigid) == 2 * r + 2
    local_degrees = {x: sum(x != y and (x ^ y) in rigid_set for y in rigid)
                     for x in rigid}
    assert all(local_degrees[1 << i] == 2 * len(neighbors[i])
               for i in range(r))
    assert all(local_degrees[(1 << u) ^ (1 << v)] == 2 for u, v in edges)
    m = (1 << r) - 2 * r - 3
    d = m - r
    assert m > (1 << (r - 1)) and d > (1 << (r - 1))
    lower = (1 << (r - 1)) - len(rigid)
    assert lower >= 5
    record = {"r": r, "dimension_d": d, "valency_m": m,
              "deleted_nonzero_columns": len(rigid),
              "minimum_distance_lower_bound": lower,
              "max_weight_bound": 1 << (r - 1),
              "core_permutations_tested": 24,
              "core_setwise_stabilizer_order": 1,
              "local_rigidity_checked": True,
              "optimality_inequality_checked": True,
              "zero_column_extension": {"dimension_d": d + 1,
                                        "valency_m": m + 1}}
    if full_code:
        columns = [x for x in range(1, 1 << r) if x not in rigid_set]
        rows = [sum(1 << j for j, x in enumerate(columns) if (x >> i) & 1)
                for i in range(r)]
        assert len(columns) == m
        word = prev = 0
        min_weight, max_weight = m, 0
        weights = {}
        for step in range(1, 1 << r):
            u = step ^ (step >> 1)
            changed = u ^ prev
            assert changed.bit_count() == 1
            word ^= rows[changed.bit_length() - 1]
            prev = u
            actual = word.bit_count()
            predicted = (1 << (r - 1)) - sum((u & x).bit_count() % 2
                                            for x in rigid)
            assert actual == predicted
            assert lower <= actual <= (1 << (r - 1)) < m
            weights[actual] = weights.get(actual, 0) + 1
            min_weight = min(min_weight, actual)
            max_weight = max(max_weight, actual)
        record.update({"all_nonzero_codewords_checked": (1 << r) - 1,
                       "actual_minimum_distance": min_weight,
                       "actual_maximum_weight": max_weight,
                       "weight_distribution": weights,
                       "all_ones_excluded": True})
    return record


def small_cases():
    rigid5 = [3, 7, 8, 9, 10, 12, 13, 14, 15, 17, 23, 31]
    colors = [int(v == 0) for v in range(32)]
    classes = []
    for _ in range(4):
        sig = [(colors[v], tuple(sorted(colors[v ^ s] for s in rigid5)))
               for v in range(32)]
        table = {s: i for i, s in enumerate(sorted(set(sig)))}
        colors = [table[s] for s in sig]
        classes.append(len(set(colors)))
    assert classes == [3, 8, 30, 32]
    expected_colors = [31, 16, 14, 28, 17, 15, 18, 29, 26, 27, 24, 12,
                       20, 23, 30, 25, 9, 21, 10, 2, 1, 3, 11, 19,
                       13, 5, 0, 7, 6, 4, 8, 22]
    assert colors == expected_colors
    hyperplane_max = max(sum((u & x).bit_count() % 2 == 0 for x in rigid5)
                         for u in range(1, 32))
    assert hyperplane_max == 9
    checks = []
    for r, rigid in [(5, rigid5), (6, rigid5 + [32])]:
        for epsilon in (0, 1):
            columns = [x for x in range(1 - epsilon, 1 << r) if x not in rigid]
            weights = {}
            for u in range(1, 1 << r):
                w = sum((u & x).bit_count() % 2 for x in columns)
                weights[w] = weights.get(w, 0) + 1
            m, d = len(columns), len(columns) - r
            assert min(weights) >= 5 and max(weights) < m
            for candidate in range(d, m):
                assert candidate > (1 << (candidate - d))
            checks.append({"dimension_d": d, "valency_m": m,
                           "code_dimension": r, "weight_distribution": weights,
                           "minimum_distance": min(weights),
                           "all_ones_excluded": True,
                           "all_smaller_valencies_excluded": True})
    return {"rigid5": rigid5, "color_class_counts": classes,
            "fourth_colors": colors, "max_hyperplane_intersection": hyperplane_max,
            "exact_minima": checks}


def main():
    output = {
        "target": "Arnadottir--Guo arXiv:2608.20476v1 Problem 8.3",
        "status": "PARTIAL: exact minimum on d=2^r-3r-3+epsilon, r>=10, epsilon=0,1, plus d=14,15,44,45; full function unresolved",
        "proof": "t94_cubelike.tex",
        "not_a_new_foundational_principle_claim": True,
        "checks": [verify(r, full_code=(r <= 14)) for r in range(10, 65)],
        "small_cases": small_cases(),
        "checks_are_not_the_infinite_proof": True,
        "all_checks_passed": True,
    }
    path = Path(__file__).with_suffix('.json')
    path.write_text(json.dumps(output, indent=2) + '\n')
    print(json.dumps({"all_checks_passed": True, "parameter_instances": 55,
                      "full_codeword_runs": 5, "output": str(path)}))


if __name__ == '__main__':
    main()
