#!/usr/bin/env python3
"""Exact arithmetic checks for the p == 3 (mod 4) branch of Sun 4.8.

Finite checks supplement the all-prime proof in t95_sun48_section.tex.
No dependency beyond Python's standard library is required.
"""
from pathlib import Path
from math import gcd, isqrt
import json


def primes_below(n):
    return [p for p in range(2, n) if all(p % q for q in range(2, isqrt(p) + 1))]


def chi(a, p):
    t = pow(a % p, (p - 1) // 2, p)
    return -1 if t == p - 1 else t


def det(a):
    a = [r[:] for r in a]
    n = len(a)
    if not n:
        return 1
    previous, sign = 1, 1
    for k in range(n - 1):
        if a[k][k] == 0:
            pivot = next((j for j in range(k + 1, n) if a[j][k]), None)
            if pivot is None:
                return 0
            a[k], a[pivot] = a[pivot], a[k]
            sign *= -1
        q = a[k][k]
        for i in range(k + 1, n):
            for j in range(k + 1, n):
                numerator = q * a[i][j] - a[i][k] * a[k][j]
                assert numerator % previous == 0
                a[i][j] = numerator // previous
            a[i][k] = 0
        previous = q
    return sign * a[-1][-1]


def class_number(discriminant):
    """Count primitive reduced positive-definite binary quadratic forms."""
    result = 0
    for a in range(1, isqrt((-discriminant) // 3) + 1):
        for b in range(-a, a + 1):
            numerator = b * b - discriminant
            if numerator % (4 * a):
                continue
            c = numerator // (4 * a)
            if a > c or gcd(gcd(a, b), c) != 1:
                continue
            if (abs(b) == a or a == c) and b < 0:
                continue
            result += 1
    return result


def target(p, x, y, z, w):
    l = chi(2, p)
    h = class_number(-p)
    s = (-1) ** ((h - 1) // 2)
    return x - l * (w + y - z + 1) - s * z + (1 + s - l) * (w * x - y * z)


def main():
    parameter_cases = [(0, 0, 0, 0), (1, 0, 0, 0), (0, 1, 0, 0),
                       (0, 0, 1, 0), (0, 0, 0, 1), (1, 0, 0, 1),
                       (0, 1, 1, 0), (2, -3, 5, -7), (-2, 4, -1, 3)]
    cases = []
    for p in primes_below(104):
        if p <= 3 or p % 4 != 3:
            continue
        n = (p - 1) // 2
        l = chi(2, p)
        h = class_number(-p)
        s = (-1) ** ((h - 1) // 2)
        c = [[chi(i - j, p) for j in range(n + 1)] for i in range(n + 1)]
        hmat = [[chi(i - j + 1, p) for j in range(n)] for i in range(n)]
        c0 = [[1 if j == 0 else c[i][j] for j in range(n + 1)] for i in range(n + 1)]
        dh, dc, dc0 = det(hmat), det(c), det(c0)
        excess = sum(chi(j, p) for j in range(1, n + 1))
        assert dc == 1 and dh == -l and dc0 == -s
        assert dh % 4 == chi(n, p) % 4
        assert dc0 % 4 == (n - 1 + excess) % 4
        assert excess == (2 - l) * h
        records = []
        for x, y, z, w in parameter_cases:
            a = [[x + chi(i-j+1, p) + chi(i,p)*y + chi(j,p)*z + chi(i*j,p)*w
                  for j in range(n)] for i in range(n)]
            actual, expected = det(a), target(p, x, y, z, w)
            assert actual == expected
            records.append({'parameters': [x,y,z,w], 'determinant': actual})
        cases.append({'p': p, 'n': n, 'h_minus_p': h, 'chi2': l,
                      'det_C': dc, 'det_H': dh, 'Cramer_u0': dc0,
                      'quadratic_excess': excess, 'parameter_checks': records})
    output = {'target': 'Sun 2024 Conjecture 4.8, equation (4.20), unchanged',
              'status': 'PASS', 'primes_checked': len(cases),
              'exact_determinant_parameter_checks': len(cases)*len(parameter_cases),
              'cases': cases,
              'scope': 'Finite checks only. The all-prime proof uses published inverse-square identities, modulo-4 sign recovery, and the rank-two determinant lemma. No historical new-principle claim.'}
    path = Path(__file__).with_suffix('.json')
    path.write_text(json.dumps(output, indent=2) + '\n')
    print(json.dumps({k:v for k,v in output.items() if k != 'cases'}, indent=2))


if __name__ == '__main__':
    main()
