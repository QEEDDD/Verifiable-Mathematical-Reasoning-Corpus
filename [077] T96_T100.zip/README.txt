KEIO — T96–T100
27 October 2026

Exact Hankel Periods, Parking-Outcome Formulas, and Three Further Investigations

Read KEIO_T96_T100_2026-10-27.pdf, or compile the matching standalone TEX
file twice with pdflatex. No external TeX inputs, bibliography database,
figures, or network access are required.

MAIN RESULTS AND LIMITS

T96: A degree-preserving ternary fold proves the residue-one Stern count
      Pi_(1,2)(x) >> (log x)^(log_2 3). This is a partial lower bound;
      it does not settle Ulas Question 2.10.
T97: Complete coefficient-extraction formulas for the first two FHMS
      Section 6 questions: arbitrary-capacity outcomes admitting k lucky
      cars, and a fixed lucky set with an arbitrary single unavailable spot.
      The source questions are explicit but not individually numbered.
T98: Written all-shift proof of Han 2016 Conjecture 4.2: the binary
      Rudin–Shapiro Hankel sequence over F_2 has least period 9*2^m
      for every k>=3 with 2^m<k<=2^(m+1). The proof includes minimality.
T99: Exact simple connected graphs on 128 and 256 vertices whose ordinary
      Cesaro average mixing matrix has rank two. These finite examples
      do not answer Coutinho–Guo Open Problem 4.1 about infinitude.
T100: An all-prime obstruction to an auxiliary half-system extension.
      Sun Conjecture 4.10(ii) for the original consecutive set is not solved.

Historical priority and a historically unprecedented foundational
principle are NOT certified for any track. The literature search is
bounded. Internal proof reviews are not external peer review or formal
proof-assistant certification. No transcendence theorem is claimed.

REPRODUCING THE FINITE CERTIFICATES

Requirement: Python 3.10 or newer, standard library only.
Do not run with -O or -OO, since assertions are part of the verifiers.

  python3 run_all.py

The runner checks every file in SHA256.json before and after execution,
runs all five verifiers, and checks their exit codes and result status.
Each individual tNN_verify.py is also independently runnable. It writes
its deterministic tNN_verify.json alongside itself.

The JSON files contain exact finite certificates and computation results.
The T99 decimals are display-only; all graph certification uses integers
and rational numbers. None of these programs proves a universal theorem
merely by checking a finite range. The manuscript provides the all-
parameter arguments for every theorem it claims.

SOURCE AND REVIEW RECORD

SOURCE_AND_PROOF_AUDIT.md records the primary target sources, established
antecedents, exclusions from preceding rounds, and independent internal
proof reviews. It does not assert exhaustive worldwide priority clearance.
The bibliography contains links to original papers; their copyrighted
full-text PDFs are not included in this archive.

FILES

  KEIO_T96_T100_2026-10-27.pdf / .tex  Complete manuscript
  t96_verify.py through t100_verify.py  Exact verification programs
  t96_verify.json through t100_verify.json  Reproducible outputs
  run_all.py  One-command verification runner
  SOURCE_AND_PROOF_AUDIT.md  Source and proof-scope review
  README.txt  This file
  SHA256.json  File integrity manifest (excluding the manifest itself)
