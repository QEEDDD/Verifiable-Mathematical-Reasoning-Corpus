# T96–T100: independent source, priority, and proof audit

Audit date: 27 October 2026. This is a bounded literature search and an
internal mathematical review. A complete original-target proof, a method
not supplied by an existing theorem, and worldwide historical priority
are separate tests. No search failure certifies worldwide priority.

## Exclusions carried forward

The corpus README explicitly identifies its contents as research drafts,
not peer-reviewed publications or proof-assistant artifacts. Previously
proved items must not be recounted as new closures. In particular:

* AFM2603.19194v2 Conjecture5.1: previous retry T91.
* Ulas1909.10844 Question2.10 residue0: previous retry T92; residue1 was
  still unresolved. Ulas4.2(1),4.3,4.4 and a negative answer to the
  universal Question4.1 were treated in earlier rounds.
* Barry2211.12637 Conjecture7 and Conjectures11–13: earlier rounds.
* Wang–Zhang2502.21050 Conjecture8: earlier round's actual continued-
  fraction cycle proof, not just a determinant-period calculation.
* Cigler2309.02127 Conjectures1.2/1.3: explicit prior public PR12729
  (3 October2026); Cigler2308.07642 Conjecture11: PR13035 (4 October).
* Arnadottir–Guo2608.20476 Problem8.2: previous nonabelian-GRR construction;
  Problem8.3 infinitude alone also follows from older almost-all abelian
  GRR theory plus nonzero XOR. Only selected minimum valencies were proved.
* CGS OpenProblem7.1: prior public PR14855 (10 October2026).
  OpenProblem7.2 adjacency cubic order and leading constant: earlier round.
* Sun2405.03626 Conjecture4.8: previous retry T95 together with the cited
  prior complementary congruence branch. Signed inverse data already occur
  implicitly in Yang–Yang–Zhang's explicit cyclotomic formulas.

These exclusions were communicated to the five research agents before
their new target selection.

## T96: Ulas Question2.10

Primary: https://arxiv.org/abs/1909.10844
and https://arxiv.org/pdf/1909.10844 . The original source is dated
24 September2019. Its Question2.10 asks for superquadratic-logarithmic
counts in both residue classes modulo2. The previous residue0 proof is
not a full closure of the two-residue question. Exact title/source-ID/
question searches found the original and surrounding Stern literature,
but no matching later full solution. This is bounded negative evidence.

Do not substitute Gawron's reciprocal-index zero-density conjecture:
Schinzel's 2017 paper already proves it. The stronger polynomial-in-log
upper bound is a different question.

Independently read the completed t96_section.tex. The three folding
operations preserve the original integer-degree congruence, not just
the degree after mod-two reduction. In particular, the matrix K_Z has
leading coefficient -I, so comparing K_Z M_rev=M^T K_Z proves equal
maximum degrees and transposed leading coefficient matrices. Prefix11
and nonnegative integer coefficients imply the first column of M has
degree at most E-1. Hence the first row of M_rev has that bound, giving
deg A_0<=2E-1 and deg B_0<=2E. The three allowed suffixes then keep
the integer degree at most 2E+1, while the parity identity forces
equality. The final zero-run distinguishes the three maps and the
remaining palindrome recovers the parent word. No logical gap found
in this argument or its 3^j distinct-word and 5*2^j-2 length bounds.

The resulting exponent log_2(3) is about1.585, below the exponent2
required in Question2.10. Thus this is a proved partial quantitative
advance for the unchanged counting function, not a resolution of the
original two-residue question. The source's earlier lower bound is
linear in log x. No matching ternary construction was located in the
bounded search; reversal/matrix methods are established antecedents.
Independently executed t96_verify.py: PASS for 1,093 ternary-family
words, 201 independent-seed folds, 40 full integer-coefficient checks,
and 24 larger seeded cases, including the program's negative controls.

## T97: two FHMS Section 6 enumeration questions

Primary full text: https://arxiv.org/html/2508.13917v2 , dated
10 September 2025. Section 6 first asks for the number of outcomes
admitting k lucky cars for a general vector u with repetitions, then
for a closed formula for c_s(n,I) for an arbitrary unavailable spot s.
These are pre-existing explicitly stated questions, but they are not
separately numbered or named conjectures. Theorem 3.7 already gives
the forced-lucky criterion; Theorems 2.2 and 3.11 already use increasing
runs rooted at lucky labels. The new section attributes these facts.

Independently read t97_section.tex in full. The first formula encodes
an ordered partition by its block-index word and orders the last
occurrences of the block letters. The intervals between these terminal
events have exactly the claimed allowed alphabets. Their geometric
series count words, not merely multisets, and each terminal weight
correctly tests whether the predecessor block is still unfilled.
The coefficient fixes every block size. Finally, an outcome has a lucky
set of size k if and only if its mandatory set has size at most k;
division by 1-q therefore counts the union of attainable outcomes once.
No logical gap found in the all-parameter bijection.

The second formula splits the outcome at its single unavailable spot.
The left increasing runs are rooted at J, the right ones at I minus J,
with a fixed first sentinel-root-0 run on the right. Every nonlucky
label chooses one smaller root; increasing order then uniquely fixes
its position. The run order contributes the two factorials, and the
power of z is precisely the left length. This is a bijection, including
empty lucky sets, empty runs at the hole, and holes at either endpoint.
No logical gap found in the all-parameter proof.

Independently executed t97_verify.py: PASS in all 728 ordered-partition
cases through n=6, 125 original parking-process enumerations through
n=4, and 1,792 single-hole/fixed-set cases through n=7. These are finite
checks of implementations and supplement the written proofs.

Primary-source exact-ID, distinctive phrase, and related lucky-outcome
searches did not locate the same two full formulas. Related primary
paper https://arxiv.org/html/2510.27574v1 concerns Fubini rankings and
unit Fubini rankings, with different constrained objects. The author
abstract of Fang--Li--Lin2610.05665 concerns run/return symmetries and
prime decomposition of vector parking functions, not these outcome
counts. A potentially related Texas thesis search hit could not yet be
retrieved and is not counted as cleared. Negative search evidence does
not certify worldwide priority.

Strict-method finding: terminal-order word decomposition and formal
geometric series are classical constructions; the one-hole proof is an
explicit extension of the original authors' increasing-run proof.
These are complete formulas for the two unchanged source questions,
but neither a historically unprecedented principle nor the absence of
an identical solution worldwide has been established. Do not label
T97 as satisfying every condition in the user's request.

## T98: Han's newly selected Hankel candidates

Primary author manuscript, dated22August2016:
https://irma.math.unistra.fr/~guoniu/papers/p94hfrac.pdf
Published as *Hankel continued fraction and its applications*, Advances
in Mathematics303(2016),295–321, DOI10.1016/j.aim.2016.08.013;
preprint arXiv:1406.1593.

Conjecture4.2 (printedp23) concerns the binary 0/1 Rudin–Shapiro sequence,
shifted by k, and the least period of its Hankel determinant sequence
modulo2. For k>=3 it predicts9*2^m, where2^m<k<=2^(m+1). The source says
it checked k<=129. This is not the signed(+/-1) Rudin–Shapiro nonsingularity
problem. Exact-source/conjecture and distinctive-period searches in two
engines did not locate a complete later resolution.

Conjectures5.9 and5.10 (printedp25) concern nonzero Hankel determinants
of the eta-cube coefficient sequence and of the alternating triangular-
number indicator series, respectively. The printed product for C9 starts
at n=0, an evident typo contradicted by its accompanying sum; this must
not be sold as a mathematical counterexample. No exact closure was
located in the bounded search. No corpus overlap was found by literal
Hankel/Rudin–Shapiro/Han source searches.

Related but different: Cigler2407.05768v2, fullPDF inspected at
https://arxiv.org/pdf/2407.05768 , studies a(n,q)=q^(n choose2) as the
coefficient sequence in the x-variable. That is not the sparse coefficient
sequence of sum(-1)^n*x^(n(n+1)/2) in Han5.10. Its title's use of
partial theta does not establish overlap.

Also inspected the primary full text of Liu--Wang--Zhang2608.08703v2
(October 2026): https://arxiv.org/html/2608.08703v2 . Its Section 9
periodic Hankel formulas address Barry's 2021 Conjectures 26, 30, 39
and OEIS A136576/A136577, rather than Han's binary Rudin--Shapiro
least-period conjecture. Its table resolves many other Barry Somos-4
targets, which should therefore be excluded from any target switch.

### Independent audit of the completed T98 draft

Read t98_section.tex in full and separately rederived the following
steps. The shifted quadratic equation gives g^2+g=(z+1)^(-3),
Tr F_k=z^k/(z+1), and N F_0=(z+1)^(-5). The smooth cubic has one
point above z+1=0, with valuations v(z+1)=2 and v(F_0)=-5. Hence a
polynomial combination A+B F_0 can have only odd pole orders 5,3,1
there; polynomial A cannot cancel such a term.

The displayed epsilon has divisor 3P_+-3P_- and norm one. The genus-one
argument excludes a principal simple difference P_+-P_-, proving that
every pole-free norm-one function is an epsilon power. Trace-polynomial
valuations correctly imply that epsilon^j belongs to the shifted module
only when J=3*2^m divides j. For that J the explicitly displayed matrix
is polynomial and determinant one, so multiplication and its inverse
preserve coprime pairs and give the claimed translation of every normal
index and its following gap. This proves an actual period from n=0.

The formerly missing minimality step is now supplied. For a gap
d>=k-1, the error norm N=V/(z+1)^5 has deg V<=5 and is congruent
to a square modulo z^k. Thus N' has numerator (z+1)V'+V, of degree
at most 4, but that numerator is divisible by z^(k-1). For k>=6 it
vanishes. The rational norm is a square. Its possible finite-pole
valuation would be odd by the preceding ramified-place calculation,
so there is no such pole. Its degree is nonpositive and it is nonzero,
forcing N=1. The error is consequently epsilon^(ell J), and the
endpoints of all gaps at least k-1 are exactly the positive multiples
of R=3J. Any period of the binary Hankel sequence preserves those
endpoints, and hence is divisible by R. This proves minimality, rather
than mistaking a continued-fraction period for a determinant least
period.

The initial quadratic triples for k=3,4,5 were independently recovered
from f_0=x^k f_k+its initial polynomial, giving the listed (A,C)
pairs (1,408),(196,816),(98,1632). Their exact transformation formula
is obtained by clearing the displayed substitution. Independently
executed t98_verify.py: PASS for 1,024 quadratic-series coefficients,
512 trace-order checks, 254 shift cycles, 1,078 direct Hankel checks,
and 128 polynomial unimodular unit matrices. No logical gap found in
this completed all-k draft. This remains an internal proof review,
not a proof-assistant or peer-review certification.

Primary antecedents inspected for method comparison:

* A. J. van der Poorten, *Non-periodic continued fractions in
  hyperelliptic function fields*, Bull. Austral. Math. Soc.64(2001),
  331--343, DOI10.1017/S000497270003999X. Proposition1 proves the exact
  coprime approximation criterion used here; the preceding equation
  identifies error order with the next denominator degree. Section3
  relates norm-constant units, maximal partial-quotient degrees, and
  ends of quasi-periods. Thus these infrastructure principles are old.
* A. N. W. Hone, *Continued fractions and Hankel determinants from
  hyperelliptic curves*, arXiv1907.05204v3 / CPAM74(2021),2310--2347,
  https://arxiv.org/pdf/1907.05204 . This already connects genus-one
  continued fractions with Hankel determinants and Somos recurrences.
* Chang--Liu2603.11670v1,
  https://arxiv.org/html/2603.11670v1 , treats quadratic orthogonal
  pairs over C and bilateral Somos-4/5; no binary Rudin--Shapiro
  all-shift least-period resolution was located there.

The characteristic-two square-congruence/odd-pole argument is the
specific proposed additional step in T98. A matching prior resolution
or identical argument was not located in this bounded audit. That
does not establish a historically unprecedented foundational principle
or worldwide absence of an identical proof. The complete original
named-conjecture proof and the strict historical-novelty condition
must be reported separately.

## T99: rank-two average mixing

Primary final published source:
https://pure.uva.nl/ws/files/234177391/Selected_open_problems_in_continuous-time_quantum_walks.pdf
Coutinho–Guo, *Selected open problems in continuous-time quantum walks*,
Special Matrices12(1)(2024),20240025, DOI10.1515/spma-2024-0025.

OpenProblem4.1 asks whether there are only finitely many graphs whose
ordinary Cesaro average mixing matrix has rank2. It explicitly states
that no infinite family is known. Exact-phrase, author/problem-number,
rank-two and rank2 searches in two engines located no full resolution.
Rank of an adjacency or Hermitian adjacency matrix is a different problem.

The newer arXiv2610.27498 (MusungKang,20October2026) proves local-
multiplicity/average-return upper bounds and the complete-graph trace
conjecture, according to its author abstract; it is not a located answer
to the rank-two finiteness problem. Likewise non-Cesaro time-law averages
from Baptista–Coutinho–Marques2308.16378 change the object and cannot be
substituted for the original target.

The agent's later bi-Cayley construction uses two fibers over an
elementary abelian 2-group and a 2-by-2 Fourier symbol for each character.
The symbol spectrum itself is classical: Gao--Luo, *The spectrum of
semi-Cayley graphs over abelian groups*, LAA432(11)(2010),2974--2983,
DOI10.1016/j.laa.2009.12.040; also explicit in the inspected primary
Chiapparoli--Podesta2608.27231 Section5,
https://arxiv.org/pdf/2608.27231 . For a simple-spectrum graph, squared
eigenvector coordinates are constant on every automorphism orbit,
so two orbits imply average-mixing rank at most two. This is an
elementary consequence of the established spectral formula, not a new
foundational principle by itself. An unbounded family with all those
quadratic eigenvalues distinct would be needed for the original target.
Finite exact examples do not establish that family.

The primary CGGZ2018 paper was also inspected at
https://arxiv.org/pdf/1709.03591 . Theorem3.1 and Corollary3.2 already
give the Gram/average-state interpretation used in the structural
attempt. Its Section5 recalls rank one if and only if the graph is K1
or K2. No full rank-two bi-Cayley family or solution to finiteness was
located in these sources or the bounded exact-phrase searches.

### Final finite-certificate audit

Independently read the final `t99_section.tex` and executed
`python round96_100/t99_verify.py`; all assertions pass for orders 128
and 256. The hexadecimal mask convention and table agree with the
verifier: the populations are (34,33,39) and (70,63,65), in the order
(S,B,T), giving fiber degrees (67,72) and (133,128). Neither S nor T
contains zero. S spans the full binary vector space in each case, and
an independent edge construction and breadth-first search confirm
simplicity and connectivity.

The general certificate is logically sufficient. The parity assumptions
give odd u=a-c and b, hence D=u^2+4b^2 is positive and 5 modulo 8.
Thus each monic quadratic is irreducible over the rationals, and
distinct (trace,D) pairs give distinct minimal polynomials. Different
irreducible monic quadratics cannot share a root, so the adjacency
spectrum is simple. This step does not assume that the discriminants
have distinct square-free parts. The normalized Fourier projectors
are P_(x,+/-) tensor (chi_x chi_x^T/N). Squaring entries and summing
gives diagonal fiber blocks (1+kappa)J_N/(2N), off-diagonal blocks
(1-kappa)J_N/(2N), and exactly the two nonzero eigenvalues 1 and kappa.
Odd u and b imply 0<kappa<1. The normalization 1/(2N) in the manuscript
is correct. No logical gap was found in the finite graph claims.

The two six-letter recursion products were also checked exactly by
the verifier. Their equality refutes that particular collision-free
recursion and says nothing about all possible constructions. The final
manuscript correctly states that there is no proved unbounded family.
These two finite examples therefore do not decide Open Problem 4.1.
No identical 128/256-vertex construction was located in the bounded
literature search, but neither first-example nor largest-example
priority is certified.

## T100: Sun4.10(ii) nonvanishing gap

Primary Jiang–Sun2606.03970v1,2June2026, fullHTML inspected:
https://arxiv.org/html/2606.03970v1 . Theorem1.1 proves the square-or-zero
version for p=3 mod4. Remark1.1 explicitly says the authors cannot show
p does not divide the determinant; thus that assertion cannot be treated
as already proved by their theorem.

Their proof writes the evaluation matrix as V B V^T modulo p and
reorders coefficient parity to obtain B=[C1 C2; C2^T 0]. Thus its
determinant is (-1)^((p+1)/4)*det(C2)^2 times a nonzero Vandermonde square.
The missing condition is precisely det(C2)!=0 modulo p. This source
reduction was provided to the research agent; repeating it alone would
not constitute a new method or a completion.

Independently read t100_section.tex. Its formula for the even--odd
coefficient block C has the right binomial coefficient and remainder
indices. The proof of the auxiliary half-system norm identity is valid:
P_H(X)P_H(-X)=X^(p+1)-X^2 because deg P_H=(p+1)/2 is even. Choosing
zero and all nonresidues gives a half-system when p=3 mod4 and makes
the original-form matrix's row zero vanish, over the integers as well.
The two displayed consecutive-interval identities also follow from
reflection and a shift of the exact product. No gap found in these
limited propositions. They do not establish det C nonzero for the
specified interval half-system. The section states this failure clearly
and must not be described as a solution of Sun's conjecture.

## Proof audit status

T97 and T98 have complete original-target proofs that passed this
independent logical review and finite recomputation. T96 has a valid
partial bound but does not reach its unchanged target. T100 has correct
limited auxiliary results but leaves the original nonvanishing gap.
T99 has valid exact finite certificates at orders 128 and 256 but no
unbounded family or finiteness theorem, so its unchanged target remains
unanswered. No new track is certified as meeting every strict historical
success condition at this stage.
