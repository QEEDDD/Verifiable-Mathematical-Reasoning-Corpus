#!/usr/bin/env python3
"""Run the exact finite checks supplied with the T96--T100 manuscript."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent


def check_hashes():
    manifest = json.loads((HERE / 'SHA256.json').read_text())
    for relative, expected in manifest.items():
        path = HERE / relative
        if not path.is_file() or sha256(path.read_bytes()).hexdigest() != expected:
            raise SystemExit('File hash mismatch: ' + relative)
    print(f'PASS: {len(manifest)} file hashes', flush=True)


def main():
    if not __debug__:
        raise SystemExit('Run without -O: the certificates use exact assertions.')
    check_hashes()
    statuses = []
    for number in range(96, 101):
        name = f't{number}_verify.py'
        print(f'Running {name}', flush=True)
        result = subprocess.run([sys.executable, str(HERE / name)], cwd=HERE,
                                text=True, capture_output=True)
        if result.returncode:
            print(result.stdout)
            print(result.stderr, file=sys.stderr)
            raise SystemExit(result.returncode)
        data = json.loads((HERE / f't{number}_verify.json').read_text())
        passed = data.get('status') == 'PASS' or data.get('all_assertions_passed') is True
        if not passed:
            raise SystemExit(f'{name} did not report a successful certificate check')
        statuses.append({'track': f'T{number}', 'exit_code': 0,
                         'certificate_checks_passed': True})
        print(f'PASS: T{number} finite certificate checks', flush=True)
    check_hashes()
    print(json.dumps({'all_five_verifiers_passed': True, 'checks': statuses,
                      'scope': 'Finite checks supplement the manuscript proofs. '
                               'T96, T99, and T100 original targets remain unresolved.'}, indent=2))


if __name__ == '__main__':
    main()
