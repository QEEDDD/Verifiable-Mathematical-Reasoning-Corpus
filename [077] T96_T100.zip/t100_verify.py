"""Exact checks for an unresolved target, Sun Conjecture 4.10(ii).

The all-prime square-or-zero reduction belongs to Jiang--Sun (2026).
The original nonvanishing assertion is NOT proved by this verifier.
Run without Python -O so that assertions remain active.
"""
from math import comb, isqrt
from pathlib import Path
import json


def primes3(limit):
    for p in range(3, limit, 4):
        if all(p % d for d in range(2, isqrt(p) + 1)):
            yield p


def trim(a):
    while len(a) > 1 and not a[-1]:
        a.pop()
    return a


def mul(a, b, p):
    c = [0] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            c[i + j] = (c[i + j] + x * y) % p
    return trim(c)


def poly(roots, p):
    a = [1]
    for k in roots:
        a = mul(a, [(-k) % p, 1], p)
    return a


def affine(a, c, d, p):
    """a(c X + d), independently by binomial expansion."""
    out = [0] * len(a)
    for i, v in enumerate(a):
        for j in range(i + 1):
            out[j] = (out[j] + v * comb(i, j)
                      * pow(c, j, p) * pow(d, i - j, p)) % p
    return trim(out)


def detmod(matrix, p):
    a = [[v % p for v in row] for row in matrix]
    ans = 1
    for k in range(len(a)):
        pivot = next((i for i in range(k, len(a)) if a[i][k]), None)
        if pivot is None:
            return 0
        if pivot != k:
            a[k], a[pivot] = a[pivot], a[k]
            ans = -ans
        ans = ans * a[k][k] % p
        inv = pow(a[k][k], -1, p)
        for i in range(k + 1, len(a)):
            factor = a[i][k] * inv % p
            for j in range(k + 1, len(a)):
                a[i][j] = (a[i][j] - factor * a[k][j]) % p
    return ans % p


def compressed(p, P):
    n = (p - 1) // 2
    q = (n + 1) // 2
    C = [[int(a + b == q - 1) * comb(n, 2 * b + 1) % p
          for b in range(q)] for a in range(q)]
    r = [0] * (n + 1)
    r[0] = 1
    for m in range(2 * n + 1):
        if m % 2 == 0 and m > n:
            a = n - m // 2
            for b in range(q):
                C[a][b] = (C[a][b] + comb(n, a) * r[2*b+1]) % p
        top = r[n]
        r = [((0 if i == 0 else r[i-1]) - top * P[i]) % p
             for i in range(n+1)]
    return C


def norm_identity(P, p):
    E, O = P[::2], P[1::2]
    ee, oo = mul(E, E, p), mul(O, O, p)
    out = ee + [0] * max(0, len(oo)+1-len(ee))
    for i, c in enumerate(oo):
        out[i+1] = (out[i+1]-c) % p
    target = [0] * ((p-1)//2+2)
    target[1] = p-1
    target[-1] = 1
    assert trim(out) == target


def main():
    records = []
    for p in primes3(200):
        n = (p-1)//2
        q = (n+1)//2
        chi = [0] + [1 if pow(k,n,p)==1 else -1 for k in range(1,p)]
        H = list(range(n+1))
        A = [[chi[(j+k)%p] + chi[(j*j+k*k)%p] for k in H] for j in H]
        P = poly(H, p)
        C = compressed(p, P)
        dA, dC = detmod(A,p), detmod(C,p)
        dV = 1
        for j in range(n+1):
            for k in range(j):
                dV = dV * (j-k) % p
        assert dA == pow(-1,q,p)*dV*dV*dC*dC % p
        assert dA != 0 and pow(2*dA % p,n,p) == 1
        half = pow(2,-1,p)
        assert affine(P,-1,-half,p) == P
        assert mul([half,1],affine(P,1,1,p),p) == mul([1,1],P,p)
        norm_identity(P,p)
        N = [0] + [k for k in range(1,p) if chi[k] == -1]
        assert len(N) == n+1
        assert all(((-a)%p not in N) for a in N[1:])
        AN = [[chi[(j+k)%p] + chi[(j*j+k*k)%p] for k in N] for j in N]
        assert all(x == 0 for x in AN[0])
        PN = poly(N,p)
        expected = [0]*(n+2)
        expected[1] = expected[n+1] = 1
        assert PN == expected
        norm_identity(PN,p)
        records.append({'p':p,'original_det_mod_p':dA,'compressed_det_mod_p':dC,
                        'original_legendre_symbol':1,'nonresidue_first_row_zero':True})
    result = {'status':'PASS','prime_cases':len(records),'prime_limit_exclusive':200,
              'original_conjecture_status':'UNRESOLVED: finite checks only',
              'established_prior_input':'Jiang--Sun 2606.03970v1 parity-block reduction',
              'all_prime_auxiliary_result':'The nonresidue half-system has a zero row; the manuscript proves this directly.',
              'records':records}
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k != 'records'},indent=2))


if __name__ == '__main__':
    main()
