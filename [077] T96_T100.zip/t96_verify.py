"""Exact checks for T96's degree-preserving ternary Stern fold.

The asymptotic lower bound is proved in t96_section.tex. These checks do
not settle Ulas Question 2.10, whose square-logarithm target is stronger.
Run without -O: exact assertions are part of this verifier.
"""
from itertools import product
from pathlib import Path
from random import Random
import json


def trim(p):
    p = list(p)
    while len(p) > 1 and p[-1] == 0:
        p.pop()
    return tuple(p)


def add(p, q):
    return trim([(p[i] if i < len(p) else 0) +
                 (q[i] if i < len(q) else 0)
                 for i in range(max(len(p), len(q)))])


def mul(p, q):
    out = [0] * (len(p) + len(q) - 1)
    for i, a in enumerate(p):
        for j, b in enumerate(q):
            out[i+j] += a*b
    return trim(out)


def mm(A, B):
    return tuple(tuple(add(mul(A[i][0], B[0][j]),
                           mul(A[i][1], B[1][j]))
                       for j in range(2)) for i in range(2))


def transpose(A):
    return tuple(tuple(A[j][i] for j in range(2)) for i in range(2))


ZERO, ONE, T = (0,), (1,), (0, 1)
LM = ((T, ZERO), (ONE, ONE))
RM = ((ONE, ONE), (ZERO, T))
KZ = (((1, -1), ONE), (ONE, (1, -1)))
assert mm(KZ, LM) == mm(transpose(LM), KZ)
assert mm(KZ, RM) == mm(transpose(RM), KZ)


def parity_degree_state(word):
    """Independent polynomial parity plus true integer-degree recurrences."""
    a, b = 0, 1
    da, db = -10**9, 0
    for bit in word:
        if bit == '0':
            a, b = a << 1, a ^ b
            da, db = da + 1, max(da, db)
        else:
            a, b = a ^ b, b << 1
            da, db = max(da, db), db + 1
    return a, b, da, db


def flat(word):
    a, _, degree, _ = parity_degree_state(word)
    return a == (1 << (degree + 1)) - 1


def fold(word, k):
    g = word[:-1]
    return g + g[::-1] + '0'*k + '11'


def invert_fold(word):
    assert word.endswith('11')
    body = word[:-2]
    k = len(body) - len(body.rstrip('0'))
    assert 0 <= k <= 2
    body = body[:-k] if k else body
    assert len(body) % 2 == 0
    g = body[:len(body)//2]
    assert body == g + g[::-1]
    return g + '1', k


def integer_polynomial(word):
    a, b = ZERO, ONE
    for bit in word:
        if bit == '0':
            a, b = trim((0,) + a), add(a, b)
        else:
            a, b = add(a, b), trim((0,) + b)
    return a


levels = []
current = {'111': ()}
checked_words = 0
integer_checks = []
for depth in range(7):
    expected_degree = 3 * 2**depth - 1
    assert len(current) == 3**depth
    assert max(map(len, current)) == 5 * 2**depth - 2
    for word, path in current.items():
        assert word.startswith('11') and word.endswith('11')
        assert parity_degree_state(word)[2] == expected_degree
        assert flat(word)
        assert len(word) == 3*2**depth + sum(
            2**(depth-i-1)*k for i, k in enumerate(path))
        if depth:
            parent, k = invert_fold(word)
            assert k == path[-1]
            assert fold(parent, k) == word
        if depth <= 3:
            coeff = integer_polynomial(word)
            assert len(coeff) - 1 == expected_degree
            assert all(c % 2 == 1 for c in coeff)
            integer_checks.append({'depth': depth, 'path': path,
                                   'degree': len(coeff)-1,
                                   'largest_coefficient': max(coeff)})
        checked_words += 1
    levels.append({'depth': depth, 'words': len(current),
                   'degree': expected_degree,
                   'max_digits': max(map(len, current))})
    if depth < 6:
        nxt = {}
        for word, path in current.items():
            for k in range(3):
                child = fold(word, k)
                assert child not in nxt
                nxt[child] = path + (k,)
        current = nxt

# Independent original seeds, rather than only words produced by the fold.
seed_checks = 0
for n in range(3, 2**16, 4):
    word = bin(n)[2:]
    if len(word) < 3 or not word.startswith('11') or not flat(word):
        continue
    E = parity_degree_state(word)[2]
    for k in range(3):
        child = fold(word, k)
        assert flat(child)
        assert parity_degree_state(child)[2] == 2*E+1
        assert invert_fold(child) == (word, k)
        seed_checks += 1

rng = Random(961003)
large_checks = []
for trial in range(24):
    depth = rng.randint(7, 10)
    word = '111'
    path = []
    for _ in range(depth):
        k = rng.randrange(3)
        word = fold(word, k)
        path.append(k)
    assert flat(word)
    assert parity_degree_state(word)[2] == 3*2**depth-1
    large_checks.append({'depth': depth, 'digits': len(word),
                         'degree': parity_degree_state(word)[2],
                         'path': path})

# A flat reduced polynomial need not extend to the integer degree.
negative_controls = []
for word, k, reason in [('111', 3, 'k=3 is outside the proved range'),
                        ('10011', 2, 'the initial-11 condition is absent')]:
    child = fold(word, k)
    p, _, E, _ = parity_degree_state(child)
    assert p & (p+1) == 0  # The reduction itself is still a flat string.
    assert not flat(child)
    negative_controls.append({'input_word': word, 'k': k,
                              'output_word': child,
                              'integer_degree': E,
                              'reduced_degree': p.bit_length()-1,
                              'reason': reason})

result = {
    'status': 'PASS',
    'target': 'Ulas Question 2.10, residue-one branch only',
    'proved_bound': 'Pi_(1,2)(x) >> (log x)^(log_2 3)',
    'full_question_status': 'NOT RESOLVED: log_2 3 < 2',
    'integer_self_adjointness_identities': 2,
    'exhaustive_construction_words': checked_words,
    'levels': levels,
    'independent_seed_fold_checks': seed_checks,
    'integer_polynomial_checks': integer_checks,
    'seeded_larger_checks': large_checks,
    'negative_controls': negative_controls,
    'scope': ('Finite checks supplement the written all-word degree proof. '
              'No complete answer to Question 2.10 or historical-priority '
              'certification is claimed.')
}
Path(__file__).with_suffix('.json').write_text(json.dumps(result, indent=2)+'\n')
print('PASS:', checked_words, 'ternary-family words;', seed_checks,
      'independent-seed folds;', len(integer_checks),
      'integer coefficient checks;', len(large_checks), 'larger seeded cases')
