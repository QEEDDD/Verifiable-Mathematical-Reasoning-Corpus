"""Exact independent checks for the two FHMS Section 6 outcome formulas.

Standard library only. The general formula is evaluated by multivariate
coefficient extraction. Its output is compared with direct ordered set
partitions and, on smaller cases, with the original parking algorithm.
"""
from itertools import combinations, combinations_with_replacement, permutations, product
from collections import Counter, defaultdict
from math import factorial
from pathlib import Path
import json


def compositions(n, r):
    if r == 1:
        if n >= 1:
            yield (n,)
        return
    for a in range(1, n-r+2):
        for tail in compositions(n-a, r-1):
            yield (a,)+tail


def forced_polynomial(sites, sizes):
    """Coefficient formula, indexed by the r! orders of block maxima."""
    r = len(sites)
    caps = tuple(m-1 for m in sizes)
    zero = (0,)*r
    result = Counter()
    for order in permutations(range(r)):
        rank = {j: h+1 for h,j in enumerate(order)}
        def exp(j,h):
            return int(sites[j] == 1 or
                       (j > 0 and sites[j] == sites[j-1]+1 and rank[j-1] > h))
        initial = sum(exp(j,rank[j]) for j in range(r))
        dp = {(zero,initial): 1}
        for h in range(r):
            eligible = [j for j in range(r) if rank[j] > h]
            terms = []
            ranges = [range(caps[j]+1) if j in eligible else range(1) for j in range(r)]
            for v in product(*ranges):
                degree = sum(v)
                mult = factorial(degree)
                for a in v:
                    mult //= factorial(a)
                power = sum(v[j]*exp(j,h) for j in range(r))
                terms.append((v,power,mult))
            new = defaultdict(int)
            for (e,a),c in dp.items():
                for v,b,d in terms:
                    ev = tuple(e[j]+v[j] for j in range(r))
                    if all(ev[j] <= caps[j] for j in range(r)):
                        new[ev,a+b] += c*d
            dp = new
        for (e,a),c in dp.items():
            if e == caps:
                result[a] += c
    return +result


def partitions(labels, sizes):
    if len(sizes) == 1:
        yield (tuple(labels),)
        return
    for block in combinations(labels,sizes[0]):
        rest = tuple(x for x in labels if x not in block)
        for tail in partitions(rest,sizes[1:]):
            yield (block,)+tail


def mandatory(sites, blocks):
    f = set()
    for j,block in enumerate(blocks):
        if sites[j] == 1:
            f.update(block)
        elif j > 0 and sites[j] == sites[j-1]+1:
            f.update(i for i in block if i < max(blocks[j-1]))
    return frozenset(f)


def brute_partition_polynomial(sites,sizes):
    n = sum(sizes)
    return Counter(len(mandatory(sites,B)) for B in partitions(tuple(range(1,n+1)),sizes))


def park_outcomes(sites,sizes):
    n = sum(sizes)
    out = defaultdict(set)
    for preferences in product(range(1,max(sites)+1),repeat=n):
        blocks = [[] for _ in sites]
        lucky = 0
        for label,pref in enumerate(preferences,1):
            target = next((j for j,s in enumerate(sites) if s >= pref and len(blocks[j]) < sizes[j]),None)
            if target is None:
                break
            blocks[target].append(label)
            if sites[target] == pref:
                lucky |= 1 << (label-1)
        else:
            out[tuple(tuple(B) for B in blocks)].add(lucky)
    return out


def cut_formula(n,I):
    """Returns c_s(n,I) for all s=1,...,n+1 simultaneously."""
    I=tuple(sorted(I)); k=len(I)
    ans=[0]*(n+1)
    for mask in range(1<<k):
        J={I[a] for a in range(k) if mask>>a&1}
        poly=[1]
        for label in range(1,n+1):
            if label in I:
                continue
            left=sum(i<label for i in J)
            right=1+sum(i<label for i in I if i not in J)
            q=[0]*(len(poly)+1)
            for d,c in enumerate(poly):
                q[d] += right*c
                q[d+1] += left*c
            poly=q
        mult=factorial(len(J))*factorial(k-len(J))
        for d,c in enumerate(poly):
            ans[d+len(J)] += mult*c
    return ans


def main():
    general=[]
    for n in range(1,7):
        for r in range(1,n+1):
            for sizes in compositions(n,r):
                # Every adjacency pattern, including the available first spot.
                for flags in product((0,1),repeat=r):
                    sites=[1 if flags[0] else 2]
                    for adjacent in flags[1:]:
                        sites.append(sites[-1]+(1 if adjacent else 2))
                    got=forced_polynomial(sites,sizes)
                    expected=brute_partition_polynomial(sites,sizes)
                    assert got == expected,(sites,sizes,got,expected)
                    assert sum(got.values()) == factorial(n)//__import__('math').prod(factorial(m) for m in sizes)
                    general.append((n,r))
    direct=[]
    cut_cases=0
    for n in range(1,5):
        for u in combinations_with_replacement(range(1,6),n):
            sites=tuple(sorted(set(u)));sizes=tuple(u.count(s) for s in sites)
            actual=park_outcomes(sites,sizes)
            actual_poly=Counter(min(mask.bit_count() for mask in possible) for possible in actual.values())
            assert actual_poly == forced_polynomial(sites,sizes)
            for B,possible in actual.items():
                F=mandatory(sites,B);fmask=sum(1<<(i-1) for i in F)
                allsup={mask for mask in range(1<<n) if mask&fmask == fmask}
                assert possible == allsup
            direct.append({'u':u,'outcomes':len(actual)})
        for s in range(1,n+2):
            sites=tuple(i for i in range(1,n+2) if i != s)
            actual=park_outcomes(sites,(1,)*n)
            for mask in range(1<<n):
                I={i+1 for i in range(n) if mask>>i&1}
                expected=sum(mask in values for values in actual.values())
                assert cut_formula(n,I)[s-1] == expected,(n,s,I)
                cut_cases += 1
    for n in (5,6,7):
        allperm=list(permutations(range(1,n+1)))
        for mask in range(1<<n):
            I={i+1 for i in range(n) if mask>>i&1}
            got=cut_formula(n,I)
            for s in range(1,n+2):
                cut=s-1
                expected=0
                for p in allperm:
                    left,right=p[:cut],p[cut:]
                    if left and left[0] not in I:
                        continue
                    if all(b in I or a<b for segment in (left,right) for a,b in zip(segment,segment[1:])):
                        expected += 1
                assert got[cut] == expected,(n,s,I,got,expected)
                cut_cases += 1
    examples=[]
    for sites,sizes in [((1,2),(2,2)),((2,3),(2,2)),((1,2,4),(2,1,2)),((1,2,3),(3,2,2))]:
        poly=forced_polynomial(sites,sizes)
        examples.append({'sites':sites,'sizes':sizes,'mandatory_polynomial':dict(sorted(poly.items())),
                         'k_lucky_outcomes':[sum(c for a,c in poly.items() if a<=k) for k in range(sum(sizes)+1)]})
    result={'status':'PASS','general_capacity_cases':len(general),'maximum_n_general':6,
            'original_parking_simulations':len(direct),'maximum_n_parking':4,
            'one_gap_fixed_lucky_cases':cut_cases,'maximum_n_cut':7,
            'examples':examples,'cut_example':{'n':6,'I':[1,3,5],'c_s':cut_formula(6,{1,3,5})},
            'scope':'Exact finite checks supplement the written all-parameter proofs. Classical order decompositions are used; no historically unprecedented-principle claim.'}
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
