"""Exact certificates for T98: Han 2016 Conjecture 4.2.

All arithmetic is over F_2. Polynomials are binary integers, with bit i
the coefficient of x^i (or z^i). The all-shift proof is in the manuscript;
the explicit three small cycles are finite exact proof certificates.
Run without Python's -O flag. Standard library only.
"""

from pathlib import Path
import json


def multiply(a, b):
    out = 0
    while b:
        if b & 1:
            out ^= a
        a <<= 1
        b >>= 1
    return out


def square(a):
    out, i = 0, 0
    while a:
        if a & 1:
            out |= 1 << (2 * i)
        a >>= 1
        i += 1
    return out


def divide(a, b):
    assert b
    quotient = 0
    while a and a.bit_length() >= b.bit_length():
        d = a.bit_length() - b.bit_length()
        quotient ^= 1 << d
        a ^= b << d
    return quotient, a


def exact_divide(a, b):
    q, r = divide(a, b)
    assert r == 0
    return q


def order_zero(a):
    assert a
    return (a & -a).bit_length() - 1


def order_one(a):
    assert a
    e = 0
    while True:
        q, r = divide(a, 3)
        if r:
            return e
        a = q
        e += 1


def u(n):
    return (n & (n >> 1)).bit_count() % 2


def hfrac_step(A, B, C):
    assert A and B & 1 and not C & 1
    d = order_zero(A)
    coefficients = []
    for n in range(2 * d + 2):
        v = (A >> n) & 1
        for j in range(1, min(n + 1, B.bit_length())):
            v ^= ((B >> j) & 1) & coefficients[n - j]
        for j in range(1, min(n + 1, C.bit_length())):
            if (n - j) % 2 == 0:
                v ^= ((C >> j) & 1) & coefficients[(n - j) // 2]
        coefficients.append(v)
    assert coefficients[d] == 1
    reciprocal = [1]
    for n in range(1, d + 2):
        reciprocal.append(sum(reciprocal[j] * coefficients[d + n - j]
                              for j in range(n)) % 2)
    D = sum(v << i for i, v in enumerate(reciprocal))
    numerator = (multiply(A, square(D)) ^ (multiply(B, D) << d)
                 ^ (C << (2 * d)))
    assert numerator % (1 << (2 * d + 2)) == 0
    return numerator >> (2 * d + 2), B, A << 2, d + 1, D


def start(k):
    T = sum(u(i) << i for i in range(k))
    numerator = 8 ^ multiply(17, T) ^ multiply(51, square(T))
    assert numerator % (1 << k) == 0
    return numerator >> k, 17, 51 << k


def cycle(k):
    A, B, C = start(k)
    seen, gaps, quotients = {}, [], []
    while (A, C) not in seen:
        seen[A, C] = len(gaps)
        A, B, C, gap, D = hfrac_step(A, B, C)
        gaps.append(gap)
        quotients.append(D)
        assert len(gaps) < 100000
    assert seen[A, C] == 0  # The computed cycle starts at the original series.
    word = [0] * sum(gaps)
    n = 0
    for gap in gaps:
        word[n] = 1
        n += gap
    period = next(p for p in range(1, len(word) + 1)
                  if len(word) % p == 0
                  and all(word[i] == word[i % p] for i in range(len(word))))
    return gaps, quotients, word, period


def direct_hankel(k, n):
    rows = [sum(u(k + i + j) << j for j in range(n)) for i in range(n)]
    for col in range(n):
        pivot = next((i for i in range(col, n) if (rows[i] >> col) & 1), None)
        if pivot is None:
            return 0
        rows[pivot], rows[col] = rows[col], rows[pivot]
        for i in range(col + 1, n):
            if (rows[i] >> col) & 1:
                rows[i] ^= rows[col]
    return 1


def unit_coefficients(j):
    # epsilon^j = a + b*epsilon, epsilon^2 = (z+1)^3*epsilon + 1.
    a, b, T = 1, 0, 15
    for _ in range(j):
        a, b = b, a ^ multiply(T, b)
    # epsilon = 1+(z+1)^4*F_0.
    return a ^ b, multiply(17, b), multiply(T, b)


def unit_matrix(k):
    m = (k - 1).bit_length() - 1
    assert (1 << m) < k <= (1 << (m + 1))
    J, R = 3 << m, 9 << m
    a0, B, trace = unit_coefficients(J)
    assert order_zero(trace) == 1 << (m + 1)
    assert B % (1 << k) == 0
    q = B >> k
    P = sum(u(i) << (k - 1 - i) for i in range(k))
    a = a0 ^ multiply(q, P)
    q_trace_F = exact_divide(q << k, 3)
    norm_numerator = (1 << (2 * k)) ^ (multiply(P, 17) << k) ^ multiply(square(P), 51)
    q_norm_F = exact_divide(multiply(q, norm_numerator), 51)
    determinant = multiply(a, a ^ q_trace_F) ^ multiply(q, q_norm_F)
    assert determinant == 1
    assert q.bit_length() - 1 == R - k + 1
    return {"k": k, "J": J, "R": R, "matrix_determinant": 1,
            "unit_denominator_degree": q.bit_length() - 1}


def main():
    f = sum(u(i) << i for i in range(1024))
    residual = 8 ^ multiply(17, f) ^ multiply(51, square(f))
    assert residual % (1 << 1024) == 0

    trace_checks = 0
    for j in range(1, 513):
        _, _, tr = unit_coefficients(j)
        v2 = order_zero(j)
        expected = 0 if j % 3 else 1 << (v2 + 1)
        assert order_zero(tr) == expected
        assert order_one(tr) == 3 << v2
        trace_checks += 1

    records, small = [], []
    direct_checks = 0
    for k in range(3, 257):
        gaps, quotients, word, period = cycle(k)
        m = (k - 1).bit_length() - 1
        assert period == 9 << m
        assert len(word) == period
        if k >= 6:
            assert max(gaps) == k - 1 and gaps.count(k - 1) == 1
        if k <= 24:
            for n in range(49):
                assert direct_hankel(k, n) == word[n % period]
                direct_checks += 1
        records.append({"k": k, "period": period, "cycle_steps": len(gaps),
                        "largest_gap": max(gaps)})
        if k <= 5:
            small.append({"k": k, "initial_polynomial_codes": start(k),
                          "gap_quotient_pairs": list(zip(gaps, quotients)),
                          "period_word": ''.join(map(str, word)),
                          "least_period": period, "exact_cycle_closed": True})
    unit_records = [unit_matrix(k) for k in range(3, 131)]
    result = {
        "target": "Han 2016 Conjecture 4.2, binary Rudin-Shapiro, determinants over F_2",
        "status": "PASS",
        "quadratic_series_coefficients_checked": 1024,
        "trace_order_identities_checked": trace_checks,
        "shift_cycles_checked": len(records),
        "direct_hankel_comparisons": direct_checks,
        "polynomial_unimodular_unit_matrices_checked": len(unit_records),
        "small_shift_exact_proof_certificates": small,
        "cycle_summary": records,
        "unit_matrix_summary": unit_records,
        "scope": "The all-k proof uses norm-one unit classification and the long-gap norm lemma. Finite sweeps supplement that proof. No worldwide-priority or historically unprecedented-principle certification."
    }
    Path(__file__).with_suffix('.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if not isinstance(v, list)}, indent=2))


if __name__ == '__main__':
    main()
