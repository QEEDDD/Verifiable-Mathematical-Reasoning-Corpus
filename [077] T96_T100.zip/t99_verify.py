#!/usr/bin/env python3
"""Exact, dependency-free certificates for two finite rank-two mixing graphs.

No infinitude assertion is checked or made. Integer mask bit g is membership
of g in F_2^d, with XOR as the group operation. Run from any directory.
"""
from collections import deque
from fractions import Fraction
from math import isqrt
import json
from pathlib import Path

EXAMPLES = [
    (6, "1d39f52fe7384174", "37ec8fd2075e6984", "29e5fdffe09a47da"),
    (7, "623a7e9d385f8df96b33f5d522a56aa8",
     "db196b1a5d26bcf475c59b8a07829823", "c8975afdc8d54101d50561d3475eab7e"),
]


def walsh(values):
    out = list(values)
    h = 1
    while h < len(out):
        for i in range(0, len(out), 2 * h):
            for j in range(i, i + h):
                a, b = out[j], out[j+h]
                out[j], out[j+h] = a+b, a-b
        h *= 2
    return out


def gf2_rank(vectors):
    basis = {}
    for a in vectors:
        while a:
            k = a.bit_length() - 1
            if k in basis:
                a ^= basis[k]
            else:
                basis[k] = a
                break
    return len(basis)


def fraction_data(x):
    return {"numerator": str(x.numerator), "denominator": str(x.denominator),
            "decimal_for_display_only": float(x)}


def matmul(a, b):
    return [[sum(x*y for x, y in zip(row, col)) for col in zip(*b)] for row in a]


def word_product(word):
    matrices = {
        "+": [[0, 1, 0], [1, 0, 1], [1, 1, 0]],
        "-": [[0, 1, 0], [-1, 0, 1], [1, -1, 0]],
    }
    out = [[int(i == j) for j in range(3)] for i in range(3)]
    for letter in word:
        out = matmul(matrices[letter], out)
    return out


def certificate(d, s_hex, b_hex, t_hex):
    n = 1 << d
    masks = [int(h, 16) for h in (s_hex, b_hex, t_hex)]
    assert all(0 <= m < (1 << n) for m in masks)
    sets = [[g for g in range(n) if (m >> g) & 1] for m in masks]
    S, B, T = sets
    assert 0 not in S and 0 not in T
    assert len(S) % 2 == 0 and len(T) % 2 == 1 and len(B) % 2 == 1
    assert gf2_rank(S) == d and B

    transforms = []
    for support, mask in zip(sets, masks):
        fast = walsh([(mask >> g) & 1 for g in range(n)])
        direct = [sum(-1 if (x & g).bit_count() % 2 else 1
                      for g in support) for x in range(n)]
        assert fast == direct
        transforms.append(fast)
    records, labels, kappa_sum = [], set(), Fraction(0)
    for x, (a, b, c) in enumerate(zip(*transforms)):
        t, u = a+c, a-c
        det, D = a*c-b*b, u*u+4*b*b
        assert D == t*t-4*det
        assert D > 0 and D % 8 == 5 and isqrt(D)**2 != D
        assert (t, D) not in labels
        labels.add((t, D))
        K = [[u, 2*b], [2*b, -u]]
        assert matmul(K, K) == [[D, 0], [0, D]]
        kappa_sum += Fraction(u*u, D)
        records.append({"x": x, "a": a, "b": b, "c": c,
                        "trace": t, "determinant": det, "discriminant": D})
    assert len(labels) == n
    kappa = kappa_sum/n
    assert 0 < kappa < 1
    same, cross = (1+kappa)/(2*n), (1-kappa)/(2*n)
    assert n*(same+cross) == 1 and n*(same-cross) == kappa

    # Independently construct every edge, then check simple, symmetric, connected.
    adj = [set() for _ in range(2*n)]
    for g in range(n):
        adj[g].update(g ^ s for s in S)
        adj[n+g].update(n+(g ^ t) for t in T)
        for b in B:
            adj[g].add(n+(g ^ b))
            adj[n+g].add(g ^ b)
    for v, neighbors in enumerate(adj):
        assert v not in neighbors
        assert all(v in adj[w] for w in neighbors)
        assert len(neighbors) == (len(S)+len(B) if v < n else len(T)+len(B))
    seen, queue = {0}, deque([0])
    while queue:
        for w in adj[queue.popleft()]:
            if w not in seen:
                seen.add(w)
                queue.append(w)
    assert len(seen) == 2*n
    return {
        "dimension": d, "group_order": n, "graph_order": 2*n,
        "encoding": "integer mask bit g means g is a member; g uses binary coordinates",
        "masks_S_B_T": ["0x"+h for h in (s_hex, b_hex, t_hex)],
        "S": S, "B": B, "T": T,
        "sizes_S_B_T": [len(S), len(B), len(T)],
        "fiber_degrees": [len(S)+len(B), len(T)+len(B)],
        "simple": True, "connected": True, "rank_of_S_over_GF2": gf2_rank(S),
        "distinct_irreducible_quadratics": len(labels),
        "simple_adjacency_spectrum": True,
        "mixing_nontrivial_eigenvalue": fraction_data(kappa),
        "mixing_same_fiber_entry": fraction_data(same),
        "mixing_cross_fiber_entry": fraction_data(cross),
        "mixing_rank": 2,
        "exact_spectral_block_certificates": records,
    }


def main():
    examples = [certificate(*row) for row in EXAMPLES]
    word1, word2 = "-+++--", "+---++"
    relation = word_product(word1)
    assert relation == word_product(word2)
    assert relation == [[1, 0, 0], [-4, 1, 0], [0, 0, 1]]
    result = {
        "status": "finite examples only; the original finiteness/infinitude problem is unresolved here",
        "method_scope": "classical Fourier blocks with an exact parity certificate",
        "examples": examples,
        "rejected_fixed_recursion": {"words_in_application_order": [word1, word2],
                                     "equal_products": relation},
        "all_assertions_passed": True,
    }
    target = Path(__file__).with_suffix(".json")
    target.write_text(json.dumps(result, indent=2)+"\n", encoding="utf-8")
    print(json.dumps({"all_assertions_passed": True,
                      "graph_orders": [x["graph_order"] for x in examples],
                      "mixing_ranks": [x["mixing_rank"] for x in examples],
                      "certificate": str(target)}, indent=2))


if __name__ == "__main__":
    main()
