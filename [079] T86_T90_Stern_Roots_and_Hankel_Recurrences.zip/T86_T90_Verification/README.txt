FINITE CERTIFICATES FOR STERN ROOTS AND A BILINEAR HANKEL IDENTITY
Research round T86--T90
Author: KEIO
Date: 26 October 2026

READ THE SCOPE BEFORE QUOTING RESULTS

The PDF and standalone TEX contain complete unconditional arguments for
Ulas Conjecture 4.3(1) and Cigler Conjecture 4.1. Independent internal
mathematical reviews found no gap. These are research drafts, not externally
refereed results or proof-assistant certificates. No exhaustive absence of
prior identical proofs or historically unprecedented foundational principle
has been established.

T86--T90 are research-track labels, not five independent open-problem
solutions. The outcomes are:

T86: Clarke Question 6.8 remains unresolved. A 4D candidate is effective;
     every member of a specified 5D projection family is nonpolynomial.
T87: The all-odd-period PT existence conjecture remains unresolved.
     A five-site reflected ansatz is impossible for all odd periods >=7.
T88: The entire original three-family Ulas 4.3(1) assertion is proved.
     The fourth family is also fully classified. Its source's ambiguity
     about multiplicity is retained, not silently changed.
T89: An exact all-pairs classification inside uniform depth-two trees is
     proved. The original infinitude question already has a prior public
     solution and is excluded from new-resolution counting.
T90: Cigler's original all-k boundary Hankel recurrence is proved with
     the original moments. All complex x,c, k>=0, n>=2k+2 are included.
     Classical Christoffel/Cauchy/Hirota ingredients are explicitly credited.
     The initially investigated Wang--Zhang shifted-period target was not
     proved and is not included as a successful result.

CONTENTS

The PDF and TEX have identical mathematical content. Seven Python programs
and their recorded JSON outputs provide exact finite checks. The proofs of
infinite assertions are in the manuscript, not inferred from the checks.

REPRODUCING THE CHECKS

Tested with Python 3.12.14 and SymPy 1.14.0. Install the dependency:

    python3 -m pip install -r requirements.txt

Run these commands from this directory. Do NOT use Python -O, which would
disable the assertions. Each script regenerates its adjacent JSON record.

    python3 T86_ehrhart_verify.py
    python3 T87_sparse_pt_verify.py
    python3 T88_stern_verify.py
    python3 T88_fourth_stern_verify.py
    python3 T89_tree_verify.py
    python3 T90_cigler_verify.py
    python3 T90_hirota_verify.py

T86_ehrhart_verify.py:
  Exact supporting-facet and lattice-point checks for the 4D candidate,
  its fixed triangle, and all four parity cases of the 5D projection route.
  The all-parameter projection obstruction uses the proved lattice shear
  and the Ehrhart degree/period bound, not unproved pattern extrapolation.

T87_sparse_pt_verify.py:
  Exact transfer-discriminant identities for periods 7,9,11,13,15,17.
  The general sparse-ansatz obstruction follows from Chebyshev coprimality.
  The original existence conjecture is NOT solved.

T88_stern_verify.py:
  Eight Bernstein certificates, positive-shift certificates, and 177
  independent Stern-recursion comparisons for all three families n=2..60.

T88_fourth_stern_verify.py:
  Sixty recurrence-derived factorizations and twelve exact Sturm/root
  multiplicity checks. n=3 has a triple root at -1, not three distinct roots.

T89_tree_verify.py:
  870 parameter cases and full Laplacians of seven trees of at most 50
  vertices, checking individual-vertex projectors and phase patterns.

T90_cigler_verify.py:
  108 direct-Hankel parameter runs, including x=0,+/-1 and several c.
  24 long-range recurrence checks, k=1..12, x=2,3, reaching n=512.
  These include indices well beyond the initial vanishing determinant block.

T90_hirota_verify.py:
  Exact rational Cauchy minor expansions and nontrivial Hirota identities
  with one through six spectral pairs.

COMPILING THE MANUSCRIPT

The TEX embeds all references and needs no external figures or bib file.
A standard LaTeX installation with the packages in its preamble is needed.
Compile twice; if labels change, repeat once more:

    pdflatex T86_T90_Stern_Roots_and_Hankel_Recurrences.tex
    pdflatex T86_T90_Stern_Roots_and_Hankel_Recurrences.tex

INTEGRITY AND SOURCES

SHA256SUMS lists every distributed file except itself. On systems with
sha256sum, run: sha256sum -c SHA256SUMS

The exact original targets and all principal antecedents are linked in the
manuscript bibliography. External source papers are not redistributed.
The primary Cigler preprint is version 5 (2010), Conjecture 4.1, equation 4.5:
https://homepage.univie.ac.at/johann.cigler/preprints/conjectures-hankel.pdf
Its author re-posed the same recurrence on 18 October 2023:
https://mathoverflow.net/questions/456683
The source for Ulas 4.3(1) is arXiv:1909.10844v1 (2019), published 2020:
https://arxiv.org/abs/1909.10844v1

These source links support provenance of the questions, not external
validation of the new proof drafts.
