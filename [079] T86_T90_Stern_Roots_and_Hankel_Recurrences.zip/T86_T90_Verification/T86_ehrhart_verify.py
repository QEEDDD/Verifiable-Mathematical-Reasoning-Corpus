"""Exact checks for the T86 least-dimension research attempt.

No claim of resolving Clarke Question 6.8 is made. The integer facet
certificates reject one four-dimensional candidate and all members of a
specified two-parameter family of projections of a known example.
"""
from itertools import combinations, product
from functools import reduce
from math import gcd, comb
from pathlib import Path
import json
import sympy as s


def facets(V):
    """Enumerate all supporting facets by exact rational linear algebra."""
    d=len(V[0]); out=set()
    assert s.Matrix([[x-y for x,y in zip(v,V[0])] for v in V[1:]]).rank()==d
    for ids in combinations(range(len(V)),d):
        ns=s.Matrix([list(V[i])+[1] for i in ids]).nullspace()
        if len(ns)!=1:continue
        w=ns[0];den=s.ilcm(*[x.q for x in w]);w=[int(x*den) for x in w]
        g=reduce(gcd,[abs(x) for x in w]);w=[x//g for x in w]
        val=[sum(a*b for a,b in zip(w[:-1],v))+w[-1] for v in V]
        if max(val)<=0:out.add(tuple(w))
        elif min(val)>=0:out.add(tuple(-a for a in w))
    return sorted(out)


def count(V,F,k,den=1):
    # V contains denominator-scaled vertices. Test den*x in k*conv(V).
    if k==0:return 1
    d=len(V[0]);ranges=[]
    for j in range(d):
        lo=min(v[j] for v in V)*k;hi=max(v[j] for v in V)*k
        ranges.append(range(-((-lo)//den),hi//den+1))
    return sum(all(den*sum(a*b for a,b in zip(f[:-1],x))+k*f[-1]<=0 for f in F)
               for x in product(*ranges))

V=[(1,0,0,0),(0,0,1,0),(1,1,0,1),(0,1,1,1),(2,1,1,0),(1,0,2,1)]
F=facets(V)
L=[count(V,F,k) for k in range(5)]
h=[sum((-1)**j*comb(5,j)*L[k-j] for j in range(k+1)) for k in range(5)]
assert L==[1,6,23,68,165] and h==[1,1,3,3,0]
R2=[(1,0),(1,2),(3,1)]; RF=facets(R2)
N=[count(R2,RF,k,2) for k in range(6)]
assert N==[1,0,5,4,13,12]
x=s.symbols('x');ne=s.interpolate([(k,N[k]) for k in (0,2,4)],x);no=s.interpolate([(k,N[k]) for k in (1,3,5)],x)
assert s.expand(ne-no)==x+s.Rational(3,2)
# D_sigma=(1-t)^3(1+t)^2, giving fixed numerator 1-t+3t^2+t^3.
fixed=[1,-1,3,1,0]
trivial=[(a+b)//2 for a,b in zip(h,fixed)];sign=[(a-b)//2 for a,b in zip(h,fixed)]
assert trivial==[1,0,3,2,0] and sign==[0,1,0,1,0]

V0=[(1,0,0,0,0,0),(0,0,1,0,0,0),(0,1,0,1,1,0),(0,0,1,1,1,0),(0,0,0,1,0,0),(0,0,0,0,0,1),(1,1,0,0,1,0),(1,1,0,0,0,1)]
projections=[]
for a,b in product(range(2),repeat=2):
    # Doubled fixed coordinates (r1,r2,z) for the quotient lattice.
    W=sorted(set((v[0]+v[3]-a*(v[2]+v[5]),v[1]+v[4]-b*(v[2]+v[5]),2*(v[2]+v[5])) for v in V0))
    G=facets(W);N=[count(W,G,k,2) for k in range(8)]
    ne=s.interpolate([(k,N[k]) for k in (0,2,4,6)],x)
    no=s.interpolate([(k,N[k]) for k in (1,3,5,7)],x)
    diff=s.Poly(ne-no,x)
    assert diff.degree()==2 and diff.LC()>0
    projections.append({'a_parity':a,'b_parity':b,'doubled_fixed_vertices':W,'facets':G,
        'fixed_counts_k0_to_k7':N,'even_constituent':str(s.factor(ne)),
        'odd_constituent':str(s.factor(no)),'difference':str(s.factor(ne-no)),
        'polynomial_equivariant_numerator':False})
out={'status':'failed to solve original least-dimension question',
    'four_dimensional_candidate':{'vertices':V,'facets':F,'counts_k0_to_k4':L,'h_star':h,
       'fixed_counts_k0_to_k5':N if False else [1,0,5,4,13,12],
       'fixed_numerator':fixed,'trivial_multiplicities':trivial,'sign_multiplicities':sign,
       'effective':True},'projection_obstruction':projections,'all_checks_passed':True}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'four_dimensional_candidate':'effective, rejected','projection_parities':4,'all_checks_passed':True}))
for z in projections:print(z['a_parity'],z['b_parity'],z['even_constituent'],z['odd_constituent'],z['difference'])
