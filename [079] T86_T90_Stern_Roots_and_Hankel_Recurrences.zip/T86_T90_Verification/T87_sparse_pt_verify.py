"""Exact checks for the sparse-PT obstruction; not a proof of Conjecture 2.

Requires SymPy. All-parameter proof is in t87_spectral_attempt.md.
"""
import json
from pathlib import Path
import sympy as s
x,u,v=s.symbols('x u v')
a,b,c,d=s.symbols('a b c d',real=True)
def M(z):
    return s.Matrix([[x-z,-1],[1,0]])
A=M(0); h=-2*(a+c)
C=M(a+s.I*b); B=M(c+s.I*d)
D=B*C*s.conjugate(C).subs(s.conjugate(x),x)*s.conjugate(B).subs(s.conjugate(x),x)
Q=s.Matrix([[u,-v],[v,u-x*v]])
form=s.Poly(s.expand(s.trace(Q*M(h)*Q*D-Q*Q*A**5)),u,v)
F=form.coeff_monomial(u*u); G=form.coeff_monomial(u*v); H=form.coeff_monomial(v*v)
assert s.expand(H-((-3*a*a+b*b)*x+2*a*(a*a+b*b)))==0
expected_top=-3*a*a-4*a*c+b*b-3*c*c+d*d
expected_next=2*(a**3+4*a*a*c+a*b*b+4*a*c*c+c**3+c*d*d)
records=[]
for r in range(1,7):
    q=2*r+5
    ur=s.chebyshevu(r,x/2);vr=s.chebyshevu(r-1,x/2)
    assert (A**r-Q.subs({u:ur,v:vr})).applyfunc(s.simplify)==s.zeros(2)
    assert s.gcd(ur,vr)==1
    values=[a+s.I*b,c+s.I*d]+[0]*r+[h]+[0]*r+[c-s.I*d,a-s.I*b]
    P=s.eye(2)
    for value in values:
        P=(M(value)*P).applyfunc(s.expand)
    difference=s.Poly(s.expand(s.trace(P)-2*s.chebyshevt(q,x/2)),x)
    assert s.expand(difference.as_expr()-(F*ur*ur+G*ur*vr+H*vr*vr))==0
    assert s.expand(difference.coeff_monomial(x**(q-2))-expected_top)==0
    assert s.expand(difference.coeff_monomial(x**(q-3))-expected_next)==0
    records.append({'q':q,'transfer_identity':True,'coprimality':True,'top_coefficients':True})
result={'arithmetic':'exact symbolic polynomial arithmetic','H':str(s.factor(H)),
        'range_checked':[7,9,11,13,15,17],'checks':records,'all_checks_passed':True,
        'original_conjecture_solved':False}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'all_checks_passed':True,'range_checked':[7,9,11,13,15,17]}))
