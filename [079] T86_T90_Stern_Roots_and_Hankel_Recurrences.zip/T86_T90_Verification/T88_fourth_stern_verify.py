"""Exact checks for the fourth Stern family's full real-root classification.

Finite checks supplement the all-n monotonicity, concavity and reciprocity
proof. Requires SymPy. Run without -O; outputs JSON beside this script.
"""
from functools import cache
from pathlib import Path
import json
import sympy as s
t,x=s.symbols('t x')
@cache
def stern(n):
    if n<2:return (n,)
    if n%2==0:return (0,)+stern(n//2)
    a,b=stern(n//2),stern(n//2+1)
    return tuple((a[j] if j<len(a) else 0)+(b[j] if j<len(b) else 0) for j in range(max(len(a),len(b))))
def poly(n):return sum(v*t**j for j,v in enumerate(stern(n)))
initial={1:(t+1)*(3*t*t+2*t+1),2:(t+1)*(t*t+3*t+1)**2,
         3:(t+1)**3*(t**4+2*t**3+6*t*t+4*t+1)}
G4=x**4-x**3+3*x*x-3*x+1
sos=(x*x-x/2)**2+s.Rational(11,4)*(x-s.Rational(6,11))**2+s.Rational(2,11)
assert s.expand(G4-sos)==0
quartic3=x**4-2*x**3+6*x*x-4*x+1
assert s.expand(quartic3-((x*x-x)**2+(2*x-1)**2+x*x))==0
checks=[]
for n in range(1,61):
    index=2**(2*n+5)-9*2**(n+2)-5
    p=poly(index)
    M=(t+2)*t**n-2*t-1
    N=(t*t+t+2)*t**n+2*t**3-2*t*t-3*t-1
    assert s.expand((t-1)**2*p-M*N)==0
    assert s.expand(t**(n+1)*M.subs(t,1/t)+M)==0
    if n in initial:assert s.expand(p-initial[n])==0
    if n%2==0:
        base,rem=s.div(M,t-1,t);assert rem==0
        assert s.expand(t**n*base.subs(t,1/t)-base)==0
        G,rem=s.div(N,t*t-1,t);assert rem==0
        assert G.subs(t,-1)==n-3
    else:
        K,rem=s.div(M,t*t-1,t);assert rem==0
        assert s.expand(t**(n-1)*K.subs(t,1/t)-K)==0
        assert K.subs(t,-1)==s.Rational(3-n,2)
    item={'n':n,'index':str(index),'uniform_factorization_matches':True,
          'reciprocity_matches':True}
    if n<=12:
        sqf=s.sqf_list(p,t)[1]
        counts=[(int(s.Poly(q,t).count_roots(-s.oo,s.oo)),int(mult)) for q,mult in sqf]
        distinct=sum(c for c,m in counts);with_mult=sum(c*m for c,m in counts)
        assert distinct==({1:1,2:3,3:1}.get(n,3))
        assert with_mult==({1:1,2:5,3:3}.get(n,3))
        item.update({'distinct_real_roots':distinct,'real_roots_with_multiplicity':with_mult,
                     'sturm_squarefree_counts':counts})
    checks.append(item)
result={'all_checks_passed':True,'arithmetic':'exact rational polynomial identities and Sturm counts',
        'recurrence_n_range':[1,60],'sturm_n_range':[1,12],'checks':checks,
        'scope':'Original Conjecture4.3(3) must distinguish multiplicity at n3.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'all_checks_passed':True,'factorizations':60,'sturm_checks':12}))
