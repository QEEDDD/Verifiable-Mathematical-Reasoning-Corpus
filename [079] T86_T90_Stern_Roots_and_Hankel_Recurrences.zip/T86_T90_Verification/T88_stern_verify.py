"""Exact certificates for Ulas Conjecture 4.3(1), all three families.

Checks finite polynomial certificates and independently evaluates the Stern
recursion for n=2,...,60. The all-n conclusion is proved in the accompanying
manuscript by quadratic envelopes, not by extrapolating these tests.
Requires SymPy. Run without Python -O; writes JSON beside this script.
"""
from functools import cache
from pathlib import Path
import json
import sympy as s
x,t,u,y=s.symbols('x t u y')
A=2*x**3+2*x**2-3*x+1
abc={
0:(A,-2*(1-x)**2,-x*(x*x-x+2)),
2:((2*x*x-2*x+1)*A,2*x*(1-x)**2*(x**3+x*x-3*x+2),x*x*(2-3*x)*(x*x-x+2)),
3:(2*x**5-4*x**3+6*x*x-3*x+1,2*x*(1-x)*(3*x*x-2*x+1),-x**3*(5*x*x-5*x+2))}
q={
(0,2):x**4-2*x**3+5*x**2-4*x+1,
(0,3):x**6-2*x**5+5*x**4-6*x**3+7*x**2-4*x+1,
(2,2):3*x**6-10*x**5+23*x**4-26*x**3+17*x**2-6*x+1,
(2,3):3*x**8-8*x**7+21*x**6-32*x**5+37*x**4-30*x**3+17*x**2-6*x+1,
(3,2):5*x**6-10*x**5+17*x**4-16*x**3+11*x**2-4*x+1,
(3,3):5*x**8-10*x**7+17*x**6-22*x**5+23*x**4-18*x**3+11*x**2-4*x+1}
bern={
'A':(A,1,5,5,[5,2,0,0,3,10]),
'a3':(abc[3][0],1,5,5,[5,2,2,3,3,10]),
'q03':(q[0,3],1,6,30,[30,10,4,3,8,20,60]),
'q22':(q[2,2],1,6,30,[30,0,4,3,4,10,60]),
'q23':(q[2,3],1,8,140,[140,35,15,5,4,5,20,70,420]),
'q32':(q[3,2],1,6,15,[15,5,6,6,10,15,60]),
'q33':(q[3,3],1,8,140,[140,70,55,50,56,65,90,105,420]),
'J':(abc[2][0]-abc[2][1]*x**3,s.Rational(2,3),9,413343,
[413343,260253,158193,95499,57915,36369,26973,28623,47159,97125])}
certificates=[]
for name,(p,r,N,D,vec) in bern.items():
    expected=sum(v*s.binomial(N,j)*u**j*(1-u)**(N-j) for j,v in enumerate(vec))/D
    assert s.expand(p.subs(x,r*u)-expected)==0
    assert len(vec)==N+1 and min(vec)>=0 and vec[0]>0 and vec[-1]>0
    certificates.append({'name':name,'interval':[0,str(r)],'degree':N,'denominator':D,'numerators':vec,'passes':True})
assert s.expand(q[0,2]-((x*x-x)**2+(2*x-1)**2))==0
shifts=[]
for (i,e),p in q.items():
    a,b,c=abc[i]
    assert s.expand(a+b*(-x)**e+c*x**(2*e)-(1-x)*(1+x)**2*p)==0
    coeff=s.Poly(p.subs(x,1+y),y)
    assert min(coeff.all_coeffs())>0
    shifts.append({'family':i,'n':e,'ascending_coefficients':[int(coeff.nth(j)) for j in range(coeff.degree()+1)]})
H2=x**3*(3*x-2)*(x*x-x+2)-(x-1)**2*(x**3+x*x-3*x+2)
H3=x**5*(5*x*x-5*x+2)-(x-1)*(3*x*x-2*x+1)
assert s.expand(abc[2][1]+2*abc[2][2]*x*x+2*x*H2)==0
assert s.expand(-abc[3][1]+2*abc[3][2]*x**3+2*x*H3)==0
for H in (H2,H3):assert min(s.Poly(H.subs(x,1+y),y).all_coeffs())>0
@cache
def stern(n):
    if n<2:return (n,)
    if n%2==0:return (0,)+stern(n//2)
    a,b=stern(n//2),stern(n//2+1)
    return tuple((a[j] if j<len(a) else 0)+(b[j] if j<len(b) else 0) for j in range(max(len(a),len(b))))
def index(i,n):
    return {0:2**(2*n+4)-9*2**(n+1)-1,
            2:2**(2*n+8)-9*2**(n+4)-13,
            3:2**(2*n+8)-51*2**(n+2)-1}[i]
checks=[]
for i,(a,b,c) in abc.items():
    for n in range(2,61):
        coeff=stern(index(i,n))
        p=sum(v*(-x)**j for j,v in enumerate(coeff))
        expected=a+b*(-x)**n+c*x**(2*n)
        assert s.expand((1+x)**2*p-expected)==0
        quotient,rem=s.div(p,1-x,x)
        assert rem==0
        at_one={0:n-1,2:n,3:n+1+(-1)**n}[i]
        assert quotient.subs(x,1)==at_one>0
        checks.append({'family':i,'n':n,'index':str(index(i,n)),
                       'degree':len(coeff)-1,'identity_matches':True,
                       'quotient_at_minus_one':at_one})
result={'all_checks_passed':True,'arithmetic':'exact integers and rationals',
        'bernstein_certificates':certificates,'positive_shift_certificates':shifts,
        'recurrence_check_n_range':[2,60],'recurrence_checks':checks,
        'note':'Finite tests supplement; quadratic-envelope proof supplies all n.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'all_checks_passed':True,'bernstein_certificates':len(certificates),
                  'recurrence_checks':len(checks),'n_range':[2,60]}))
