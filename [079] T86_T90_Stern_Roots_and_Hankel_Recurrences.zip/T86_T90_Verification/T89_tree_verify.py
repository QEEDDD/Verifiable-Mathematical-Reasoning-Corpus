"""Exact checks for the two-level tree classification (auxiliary result).

No claim that the historical open existence problem is newly solved.
Requires SymPy. The all-parameter proof is in classification.tex.
"""
from pathlib import Path
from math import isqrt, gcd
import json
import sympy as S
z = S.symbols('z')

parameter_checks=[]
for a in range(1,31):
    for b in range(2,31):
        disc=(a-b)**2+4*a
        h=isqrt(disc)
        if h*h!=disc:
            parameter_checks.append({'a':a,'b':b,'integral_radial_support':False})
            continue
        u=(h+a-b)//2;v=(h-a+b)//2
        assert u>=1 and v>=2 and u*v==a and u*v-u+v==b
        r=u*(v-1)+1;s=v*(u+1)+1
        assert r+s==a+b+2 and r*s==1+b+a*b and s-r==u+v
        g=gcd(r,s)
        child_peak=(r//g)%2==0 and (s//g)%2==1
        leaf_peak=(r//g)%2==1 and (s//g)%2==0
        assert child_peak==(u%2==1 and v%2==0)
        assert leaf_peak==(u%2==0 and v%2==1)
        assert 1<r<b<s
        parameter_checks.append({'a':a,'b':b,'u':u,'v':v,'radial_eigenvalues':[0,r,s],
          'first_peak_time':f'pi/{g}' if child_peak or leaf_peak else None,
          'root_to_child_peak':child_peak,'root_to_leaf_peak':leaf_peak})

full_checks=[]
for a,b in [(1,2),(2,3),(3,5),(4,4),(4,7),(6,5),(6,7)]:
    N=1+b+a*b
    L=S.zeros(N)
    edges=[]
    for i in range(b):
        c=1+i;edges.append((0,c))
        for j in range(a):edges.append((c,1+b+i*a+j))
    for x,y in edges:
        L[x,x]+=1;L[y,y]+=1;L[x,y]-=1;L[y,x]-=1
    f=z*z-(a+b+2)*z+N
    q=z*z-(a+2)*z+1
    D=S.Poly(z*(z-1)*f*q,z)
    expected=z*f*q**(b-1)*(z-1)**(b*(a-1))
    assert S.Poly(L.charpoly(z).as_expr()-expected,z).is_zero
    powers=[S.eye(N)]
    for k in range(1,D.degree()+1):powers.append(powers[-1]*L)
    annihilator=S.zeros(N)
    for k in range(D.degree()+1):annihilator+=D.nth(k)*powers[k]
    assert annihilator==S.zeros(N)
    def numerator(x,y):
        return S.Poly(sum(D.nth(k)*sum(z**(k-1-j)*powers[j][x,y]
                    for j in range(k)) for k in range(1,D.degree()+1)),z)
    for y in range(1,1+b):
        assert S.expand(numerator(0,y).as_expr()+(z-1)**2*q)==0
    for y in range(1+b,N):
        assert S.expand(numerator(0,y).as_expr()-(z-1)*q)==0
    pairs=0
    for x in range(1,N):
        for y in range(x+1,N):
            assert not numerator(x,y).rem(S.Poly(q,z)).is_zero
            pairs+=1
    h=isqrt((a-b)**2+4*a)
    integral=h*h==(a-b)**2+4*a
    item={'a':a,'b':b,'vertices':N,'edges':len(edges),
          'full_characteristic_polynomial':True,'annihilator':True,
          'individual_root_resolvents':True,'nonroot_pairs_with_irrational_support':pairs}
    if integral:
        r=(a+b+2-h)//2;s=(a+b+2+h)//2
        child=[S.Rational(1,N),S.Rational(r-1,r*(s-r)),-S.Rational(s-1,s*(s-r))]
        leaf=[S.Rational(1,N),-S.Rational(1,r*(s-r)),S.Rational(1,s*(s-r))]
        assert sum(child)==sum(leaf)==0
        g=gcd(r,s)
        phases=[1,(-1)**(r//g),(-1)**(s//g)]
        item.update({'root_spectrum':[0,r,s],
            'child_coefficients':list(map(str,child)),
            'leaf_coefficients':list(map(str,leaf)),
            'root_child_alignment':all(ph*S.sign(c)==1 for ph,c in zip(phases,child)),
            'root_leaf_alignment':all(ph*S.sign(c)==1 for ph,c in zip(phases,leaf))})
    full_checks.append(item)

result={'all_checks_passed':True,'arithmetic':'exact integer and rational',
        'parameter_count':len(parameter_checks),'parameter_checks':parameter_checks,
        'full_matrix_checks':full_checks,
        'scope':'Auxiliary classification; Open Problem 7.1 has an earlier public solution.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'all_checks_passed':True,'parameter_count':len(parameter_checks),
                  'full_matrix_cases':len(full_checks),'max_vertices':max(x['vertices'] for x in full_checks)}))
