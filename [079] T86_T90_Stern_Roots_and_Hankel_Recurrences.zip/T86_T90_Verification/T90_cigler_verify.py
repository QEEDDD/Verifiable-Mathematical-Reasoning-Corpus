"""Exact checks accompanying the proof of Cigler's Conjecture 4.1.

These finite checks are not the all-k, all-n proof. SymPy is used only for
exact polynomial or integer determinants. No floating-point arithmetic.
"""
from pathlib import Path
from math import comb
import json
import sympy as sp

z=sp.Symbol('z')

def reduced_values(k,x,N):
    poly=sp.Poly(sp.chebyshevu(k,z/2)-x*sp.chebyshevu(k-1,z/2),z)
    q=[int(poly.nth(i)) for i in range(k)]
    prev=[x]+[0]*(k-1)
    now=[1]+[0]*(k-1)
    rows=[now]
    for _ in range(N+k):
        top=now[-1]
        nxt=[(now[j-1] if j else 0)-prev[j]-top*q[j] for j in range(k)]
        rows.append(nxt)
        prev,now=now,nxt
    out=[]
    for n in range(N+1):
        mat=sp.Matrix(k,k,lambda i,j:rows[n+j][i])
        val=int(sp.polys.matrices.DomainMatrix.from_Matrix(mat).det())
        out.append((-1)**(k*n)*val)
    return out

def direct_values(k,x,c,N):
    row=[1]+[0]*(2*N+k+3)
    moments=[]
    for _ in range(2*N+1):
        moments.append(row[k])
        row=[(c+x if j==0 else c)*row[j]+(row[j-1] if j else 0)+row[j+1]
             for j in range(len(row)-1)]+[0]
    return [int(sp.polys.matrices.DomainMatrix.from_Matrix(
                sp.Matrix(n,n,lambda i,j:moments[i+j])).det())
            if n else 1 for n in range(N+1)]

out={'all_checks_passed':False,'arithmetic':'exact integers',
     'direct_hankel_checks':[], 'bilinear_checks':[],
     'proof_scope':'Finite checks supplement, not replace, the all-parameter proof.'}
for k in range(1,7):
    for x in [-2,-1,0,1,2,3]:
        N=2*k+4
        reduced=reduced_values(k,x,N)
        for c in [-2,0,3]:
            direct=direct_values(k,x,c,N)
            assert direct==reduced
            out['direct_hankel_checks'].append({'k':k,'x':x,'c':c,'n_max':N,'passes':True})
        print('direct',k,x,flush=True)

for k in range(1,13):
    N=3*(k+1)**2+5
    for x in [2,3]:
        vals=reduced_values(k,x,N)
        nontrivial=0
        for n in range(2*k+2,N+1):
            terms=[vals[n]*vals[n-2*k-2],
                   -x*x*vals[n-1]*vals[n-2*k-1],
                   (x*x-1)*vals[n-k-1]**2]
            assert sum(terms)==0
            nontrivial+=bool(any(terms))
        out['bilinear_checks'].append({'k':k,'x':x,'n_min':2*k+2,
                                      'n_max':N,'nontrivial_checks':nontrivial,'passes':True})
        print('bilinear',k,x,N,flush=True)
out['all_checks_passed']=True
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'direct_cases':len(out['direct_hankel_checks']),
                  'bilinear_ranges':len(out['bilinear_checks']),
                  'all_checks_passed':True}))
