"""Exact independent checks of the Cauchy soliton Hirota--Miwa identity."""
from pathlib import Path
from itertools import combinations
import json
import sympy as s

def tau(p,q,w):
    total=s.Rational(0)
    k=len(p)
    for mask in range(1<<k):
        S=[i for i in range(k) if mask>>i&1]
        term=s.prod(w[i] for i in S)
        for i,j in combinations(S,2):
            term*=(p[i]-p[j])*(q[i]-q[j])/((p[i]-q[j])*(q[i]-p[j]))
        total+=term
    return s.factor(total)
records=[]
for k in range(1,7):
    p=[s.Rational(j+2) for j in range(k)]
    q=[1/z for z in p]
    w=[s.Rational((-1)**j*(j+1),2*j+3) for j in range(k)]
    a,b,c=s.Rational(-3),s.Rational(-2),s.Rational(-1)
    def shifted(*directions):
        ws=[w[i]*s.prod((z-p[i])/(z-q[i]) for z in directions) for i in range(k)]
        return tau(p,q,ws)
    C=s.Matrix(k,k,lambda i,j:(p[i]-q[i])*w[i]/(p[i]-q[j]))
    assert s.factor((s.eye(k)+C).det()-tau(p,q,w))==0
    terms=[(a-b)*shifted(a,b)*shifted(c),(b-c)*shifted(b,c)*shifted(a),(c-a)*shifted(c,a)*shifted(b)]
    assert s.factor(sum(terms))==0
    assert any(z!=0 for z in terms)
    records.append({'soliton_count':k,'cauchy_expansion':True,'hirota_identity':True,
                    'nontrivial':True})
out={'arithmetic':'exact rational numbers','all_checks_passed':True,'checks':records}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'all_checks_passed':True,'soliton_counts':[1,2,3,4,5,6]}))
