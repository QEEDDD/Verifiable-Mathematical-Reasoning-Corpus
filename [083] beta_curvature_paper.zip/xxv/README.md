# XXV · The curvature of the Fisher–Rao beta manifold decreases in both parameters

Paper: `paper/beta_curvature_paper.tex` (single file) and `paper/beta_curvature_paper.pdf`.

## Problem
K(x,y) is the sectional curvature of the Fisher–Rao metric on the beta manifold. The metric is the Hessian of
log B(x,y) = lnΓ(x) + lnΓ(y) − lnΓ(x+y).

- Le Brigant–Preston–Puechmorel (arXiv 1904.08247; Differential Geom. Appl. 2021) proved K < 0 and conjectured a lower bound.
- In the form recalled by Qi–Agarwal (Mathematics 2024) and Qi (arXiv 2609.10628, Sept. 2026) the conjecture reads:
  K(x,y) > −1/2 and K is decreasing in x and in y.
- Before this work only the diagonal x = y was settled: −1/2 < K(x,x) < 0 (Qi 2021, Qi–Agarwal 2024), and K(x,x) is decreasing (Qi 2026).
- The two-variable statement is listed as not attempted in corpus item [067] (October 2026).

## Results (proved; the proof is computer-assisted)
- **Theorem A.** ∂K/∂x < 0 and ∂K/∂y < 0 on (0,∞)². Hence −1/2 < K < 0, with inf = −1/2 and sup = 0, so the conjecture holds.
- **Theorem B (edge laws and squeeze).**
  - The edge laws are K(x,0+) = −(G'(x) − 1/2)/2 and K(x,∞) = −h'(x) g(x)/(4 e(x)²), with h = 1/ψ', G = −ψ'/ψ'', g = x − G and e = x − h.
  - These maps are strictly decreasing bijections onto (−1/4, 0) and (−1/2, −1/4) respectively.
  - The squeeze is max{K(x,∞), K(y,∞)} < K(x,y) < min{K(x,0+), K(y,0+)}.
- **Theorem C (defect calculus, any F with F'' > 0 > F''').** For the Hessian metric of F(x) + F(y) − F(x+y):
  K = −h'(x)h'(y)h'(x+y) A / (4B²), with defects A = G(x+y) − G(x) − G(y) and B = h(x+y) − h(x) − h(y).
  The logarithmic derivative q = ∂ₓ log(−K) has three exact forms: raw, defect-balance and averaged.
- **Corollary D.**
  - K(x,x) is strictly decreasing from 0 to −1/2, which recovers Qi 2026 and Qi–Agarwal 2024.
  - λ ↦ K(λx, λy) is strictly decreasing.
  - The level sets {K = c} are graphs of decreasing functions.

## Method
The proof combines a defect representation with shape-constrained certification.
1. Seven one-variable shape lemmas S1–S7 make every building block of q monotone or unimodal:
   h'' > 0, h''' < 0, G'' > 0, G'' unimodal, 2h'' − G'' > 0 and decreasing, sign pattern of G' − h'.
2. (0,∞)² is split into six regions:
   - the corner x+y ≤ 7/25;
   - the strips x ≤ 1/10 and y ≤ 1/50;
   - the far regions x ≥ 4 and y ≥ 10;
   - the main region [1/10, 4] × [1/50, 10].
3. Everything outside the main region reduces to one-variable inequalities, via the averaged formula near the axes and the defect-balance formula at infinity.
4. In the main region, monotone corner bounds turn positivity on a box into point evaluations at its corners.
5. All inequalities are verified in Arb ball arithmetic via python-flint, with exact SymPy preprocessing:
   - a regular form ψ_k(x) = (−1)^{k+1}k!/x^{k+1} + ψ_k(1+x) near 0;
   - Hurwitz zeta enclosures on [1,3];
   - Alzer's enveloping polygamma series, with an included proof, on [3,∞).

## Files
Verification: `VERIFY.md` gives four steps. Check `MANIFEST.sha256`, re-run, then compare logs with `scripts/compare_logs.py`. The same folder is distributed as `xxv_certification_bundle.zip`.

Scripts (`scripts/`, Python 3 with sympy, mpmath, python-flint 0.9):
- `run_all.sh` reproduces everything in about 2–3 minutes and writes `logs/`.
- `compare_logs.py` compares two log folders line by line and ignores only elapsed times. A clean run on 29 Oct 2026 agreed on all eight logs.
- `symforms.py` holds the exact symbolic forms (direct, small-x regular, large-x enveloping).
- `rig1d.py` and `cert1d.py` do ball evaluation and sign certification by interval splitting.
- `lemmas1d.py` certifies the shape lemmas S1–S7 (`logs/03_shape_lemmas.log`).
- `regions1d.py` certifies the corner, left strip, bottom strip and the large-x and large-y regions (`logs/04_one_variable_regions.log`).
- `mainregion.py` certifies the main region with corner-monotone box bounds:
  - 13,573 boxes in `logs/05_main_region.log`;
  - a 53,747-box recheck in `logs/06_main_region_fine_grid.log`.
- `curvsym.py` checks the curvature formula, the compact formula and the defect representation symbolically (`logs/01`).
- `sanity.py` cross-checks all forms against mpmath (`logs/02`).
- `numerics.py` produces values, edge laws, asymptotics and the figure data (`logs/07`, `data/plot_K.dat`; illustration only).

## Caveats
- The proof is computer-assisted. Its correctness rests on Arb/python-flint ball arithmetic, SymPy exact algebra and the scripts in this folder, all of which are included and reproducible.
- An independent adversarial review checked the work:
  - it re-derived every identity and bound direction and checked the coverage and the arb semantics;
  - it re-ran the certificates from a separate copy and got identical logs, apart from elapsed times;
  - it stress-tested every region bound at random points and on random boxes, with 0 violations.
- The review found no error affecting the proof. Its minor suggestions are incorporated: cache keyed by a hash of `symforms.py`, clearer diagnostics, cosmetic cleanup.
