# Verifying the computer-assisted proof (XXV, beta-curvature paper)

This folder holds everything needed to re-run, from scratch, every certificate behind *The curvature of the Fisher–Rao beta manifold decreases in both parameters* (`paper/beta_curvature_paper.pdf`). It is distributed as `xxv_certification_bundle.zip`.

**Provenance.** The folder is `xxv/` of the private working repository QEEDDD/Claude, branch `claude/intelligent-mccarthy-in9x9v`.
- The certificate scripts and the logs are those of commit `5a2ca21612fc6976907a3f995cebc5e01f492472`.
- Added in the later commit:
  - this file;
  - `MANIFEST.sha256`;
  - `scripts/compare_logs.py`;
  - the file-location sentence of the paper's Appendix A.
- No mathematics changed.

## Requirements
- Python ≥ 3.11 (tested with 3.13.17).
- `pip install sympy mpmath python-flint==0.9.0` (tested with sympy 1.14.0, mpmath 1.3.0, python-flint 0.9.0).
- One core and about 3 minutes, including the one-time build of the symbolic forms.

## Four steps (run inside this folder)
```sh
sha256sum -c MANIFEST.sha256                    # 1. every file is intact
cp -r logs logs_ref                             # 2. keep the distributed logs
sh scripts/run_all.sh                           # 3. rebuild data/forms.pkl, re-run every certificate
python3 scripts/compare_logs.py logs_ref logs   # 4. expect "all logs agree"
```
- `compare_logs.py` compares the logs line by line and ignores only elapsed times such as `(30.9s)` and `0.2s`.
- A clean run on 29 Oct 2026 reproduced all eight logs in this way (2 min 38 s, exit code 0).
- `data/forms.pkl` is deliberately not shipped. It is a Python pickle, and loading pickles from others is unsafe. Step 3 rebuilds it from `scripts/symforms.py`; the cache is keyed by a hash of that file.

## What each log certifies
| Paper | Script | Log | Final line to look for |
|---|---|---|---|
| Lemma 2.1, formula (2), Theorem 2.2 (curvature formula, defect representation) | `curvsym.py` | `01` | four checks, each ending in `: 0` |
| Cross-check of all exact forms against mpmath | `sanity.py` | `02` | `all large-x forms have theta-free leading terms` |
| Theorem 3.3 (shape lemmas S1–S7), using Lemmas 3.1–3.2 | `lemmas1d.py` | `03` | `all one-variable shape lemmas certified` |
| Lemmas 4.2–4.6 (corner, left strip, bottom strip, regions I and II) | `regions1d.py` | `04` | `ALL ONE-VARIABLE REGIONS CERTIFIED` |
| Proposition 4.8 (main region, Lemma 4.7 box bound) | `mainregion.py 0.04` | `05` | `certified: 13573 boxes` |
| Proposition 4.8, independent finer grid | `mainregion.py 0.02` | `06` | `certified: 53747 boxes` |
| Proposition 4.8, defect-balance bound only | `mainregion.py 0.04 balance` | `08` | `certified: 27489 boxes` |
| Values, edge laws, figure data (illustration only, not used in any proof) | `numerics.py` | `07` | — |

Theorem 4.9 (q > 0 on (0,∞)², hence ∂K/∂x < 0 and ∂K/∂y < 0) follows from Lemma 4.1 (coverage), Lemmas 4.2–4.6 and Proposition 4.8, as Table 2 of the paper summarises.

All sign decisions use Arb ball arithmetic (python-flint) at 256 bits. A comparison is accepted only when it is certain.
