"""Certified sign / bound checks for one-variable quantities on intervals of (0, inf]."""
import sys, time
from flint import arb, fmpq, ctx
from rig1d import Quantity, build, psi
ctx.prec=256
INF=float('inf')
XS=fmpq(1)      # use the regularised small-x form on (0, XS]
XL=fmpq(3)      # use the enveloping large-x form on [XL, inf)

def iv(a,b):
    return arb(a).union(arb(b))

def sgn(b):
    if b>0: return 1
    if b<0: return -1
    return 0

def sign_piece(Qo,a,b):
    """certified sign of Qo on [a,b] (0<=a<b<=inf) or 0 if undecided"""
    if b!=INF and b<=XS:
        X=iv(a,b); e,n,d=Qo.small(X)
        return sgn(n)*sgn(d)
    if a>=XL:
        Tb=iv(0 if b==INF else fmpq(1)/b, fmpq(1)/a)
        m,n,d=Qo.large(Tb)
        return sgn(n)*sgn(d)
    v=Qo.direct(iv(a,b))
    return sgn(v)

def certify_sign(Qo,a,b,want,maxdepth=40,log=None):
    """split [a,b] adaptively (at XS, XL, and by bisection/geometric splitting) until every piece
    has certified sign `want`. returns number of pieces; raises on failure."""
    stack=[(fmpq(a) if a!=INF else a, fmpq(b) if b!=INF else INF,0)]
    # pre-split at XS, XL
    pieces=0
    work=[]
    for (lo,hi,dep) in stack:
        cuts=[lo]+[c for c in (XS,XL) if lo<c and (hi==INF or c<hi)]+[hi]
        for i in range(len(cuts)-1): work.append((cuts[i],cuts[i+1],0))
    while work:
        lo,hi,dep=work.pop()
        s=sign_piece(Qo,lo,hi)
        if s==want:
            pieces+=1; continue
        if dep>=maxdepth:
            raise RuntimeError('cannot certify %s sign %d on [%s,%s]'%(Qo.name,want,lo,hi))
        if hi==INF:
            mid=lo*4
        elif lo==0:
            mid=hi/2
        elif hi/lo>2:
            # geometric midpoint (rational approx)
            mid=fmpq(int((float(lo)*float(hi))**0.5*2**20),2**20)
            if not (lo<mid<hi): mid=(lo+hi)/2
        else:
            mid=(lo+hi)/2
        work.append((lo,mid,dep+1)); work.append((mid,hi,dep+1))
    return pieces

if __name__=='__main__':
    print('library module; the certificate of the shape lemmas is lemmas1d.py')
