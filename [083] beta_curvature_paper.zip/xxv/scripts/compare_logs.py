# Compare two log folders (e.g. the distributed logs and a fresh run) line by line.
# Elapsed times such as "(30.9s)", "(1s)", "0.2s" or "total 51.0s" are the only parts allowed to differ.
# usage: python3 compare_logs.py REF_DIR NEW_DIR
import re, sys, pathlib

STAMP = re.compile(r'(?<![\w.])\d+(?:\.\d+)?s\b')

def norm(path):
    return [STAMP.sub('<t>', line.rstrip('\n')) for line in path.read_text().splitlines()]

def main(ref, new):
    ref, new = pathlib.Path(ref), pathlib.Path(new)
    bad = 0
    for r in sorted(ref.glob('0[1-8]_*.log')):
        n = new / r.name
        if not n.exists():
            print('MISSING  ', r.name); bad += 1; continue
        a, b = norm(r), norm(n)
        if a == b:
            print('IDENTICAL', r.name, '(%d lines, time stamps ignored)' % len(a))
        else:
            bad += 1
            i = next((k for k, (x, y) in enumerate(zip(a, b)) if x != y), min(len(a), len(b)))
            print('DIFFERS  ', r.name, 'first difference at line %d' % (i + 1))
            print('   ref:', a[i] if i < len(a) else '<end>')
            print('   new:', b[i] if i < len(b) else '<end>')
    print('all logs agree' if bad == 0 else '%d log(s) differ' % bad)
    return bad

if __name__ == '__main__':
    sys.exit(1 if main(*sys.argv[1:3]) else 0)
