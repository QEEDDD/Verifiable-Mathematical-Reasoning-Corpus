"""Symbolic check: Gaussian curvature of the Hessian metric g = Hess(phi) on R^2 equals
   K = -det M / (4 det(g)^2),  M = [[p11,p12,p22],[p111,p112,p122],[p112,p122,p222]],
using Brioschi's formula for E=p11, F=p12, G=p22 (generic phi)."""
import sympy as sp
u,v=sp.symbols('u v')
phi=sp.Function('phi')(u,v)
E=sp.diff(phi,u,2); F=sp.diff(phi,u,v); G=sp.diff(phi,v,2)
Eu,Ev=sp.diff(E,u),sp.diff(E,v); Fu,Fv=sp.diff(F,u),sp.diff(F,v); Gu,Gv=sp.diff(G,u),sp.diff(G,v)
Evv=sp.diff(E,v,2); Fuv=sp.diff(F,u,v); Guu=sp.diff(G,u,2)
M1=sp.Matrix([[-Evv/2+Fuv-Guu/2, Eu/2, Fu-Ev/2],[Fv-Gu/2,E,F],[Gv/2,F,G]])
M2=sp.Matrix([[0,Ev/2,Gu/2],[Ev/2,E,F],[Gu/2,F,G]])
Kb=(M1.det()-M2.det())/(E*G-F**2)**2
d=lambda *a: sp.diff(phi,*a)
M=sp.Matrix([[d(u,u),d(u,v),d(v,v)],[d(u,u,u),d(u,u,v),d(u,v,v)],[d(u,u,v),d(u,v,v),d(v,v,v)]])
Kh=-M.det()/(4*(E*G-F**2)**2)
print('Brioschi - Hessian formula simplifies to:',sp.simplify(sp.expand(Kb-Kh)))
# beta case: phi = F(u)+F(v)-F(u+v), with F''=psi1 etc. -> compact formula and defect representation
p1,p2,p3,q1,q2,q3,r1,r2,r3=sp.symbols('p1 p2 p3 q1 q2 q3 r1 r2 r3')
# derivatives of phi: phi_uu=p1-r1, phi_uv=-r1, phi_vv=q1-r1, third: p2-r2, -r2, -r2, q2-r2
Mb=sp.Matrix([[p1-r1,-r1,q1-r1],[p2-r2,-r2,-r2],[-r2,-r2,q2-r2]])
Db=(p1-r1)*(q1-r1)-r1**2
Kc=-Mb.det()/(4*Db**2)
compact=(r2*(p1*q2+q1*p2)-r1*p2*q2)/(4*(p1*q1-r1*(p1+q1))**2)
print('compact formula check:',sp.simplify(Kc-compact))
# defect representation: h=1/psi1, h'=-psi2/psi1^2, G=-psi1/psi2
hu,hv,hs=1/p1,1/q1,1/r1; Gu_,Gv_,Gs_=-p1/p2,-q1/q2,-r1/r2
h1u,h1v,h1s=-p2/p1**2,-q2/q1**2,-r2/r1**2
A=Gs_-Gu_-Gv_; B=hs-hu-hv
defect=-h1u*h1v*h1s*A/(4*B**2)
print('defect representation check:',sp.simplify(Kc-defect))
# Riemann tensor of a Hessian metric: R_1212 = 1/4 sum g^{pq}(phi_12p phi_12q - phi_11p phi_22q), K = R_1212/det g
f=sp.symbols('f11 f12 f22 f111 f112 f122 f222')
f11,f12,f22,f111,f112,f122,f222=f
gm=sp.Matrix([[f11,f12],[f12,f22]]); gi=gm.inv(); Dg=gm.det()
T3={(1,1,1):f111,(1,1,2):f112,(1,2,1):f112,(2,1,1):f112,(1,2,2):f122,(2,1,2):f122,(2,2,1):f122,(2,2,2):f222}
R1212=sp.Rational(1,4)*sum(gi[p-1,q-1]*(T3[(1,2,p)]*T3[(1,2,q)]-T3[(1,1,p)]*T3[(2,2,q)]) for p in (1,2) for q in (1,2))
Mf=sp.Matrix([[f11,f12,f22],[f111,f112,f122],[f112,f122,f222]])
print('Riemann-tensor form vs -det M/(4 D^2):',sp.simplify(R1212/Dg+Mf.det()/(4*Dg**2)))
