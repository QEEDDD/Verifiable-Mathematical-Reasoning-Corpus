"""Certify the one-variable shape lemmas S1-S7 (paper, Theorem 3.3)."""
import time
from flint import fmpq, ctx
from rig1d import Quantity, build
from cert1d import certify_sign, INF
ctx.prec=256
names=['h2','h3','G2','G3','G4','eps','eps1','kap','kap1']
forms=build(names)
QQ={nm:Quantity(nm,forms) for nm in names}
jobs=[('S1',"h''>0 on (0,inf)",'h2',0,INF,1),
      ('S2',"h'''<0 on (0,inf)",'h3',0,INF,-1),
      ('S3',"G''>0 on (0,inf)",'G2',0,INF,1),
      ('S4a',"G''''<0 on (0,2/5]",'G4',0,fmpq(2,5),-1),
      ('S4b',"G'''<0 on [3/10,inf)",'G3',fmpq(3,10),INF,-1),
      ('S4c',"G'''>0 on (0,29/100]",'G3',0,fmpq(29,100),1),
      ('S5',"eps=2h''-G''>0 on (0,inf)",'eps',0,INF,1),
      ('S6',"eps'=2h'''-G'''<0 on (0,inf)",'eps1',0,INF,-1),
      ('S7a',"kappa'=G'-h'<0 on [1,inf)",'kap1',fmpq(1),INF,-1),
      ('S7b',"kappa=G-h>0 on (0,1]",'kap',0,fmpq(1),1)]
T0=time.time()
for tag,desc,nm,a,b,want in jobs:
    t0=time.time()
    n=certify_sign(QQ[nm],a,b,want)
    print('%-4s %-36s certified with %6d pieces (%.1fs)'%(tag,desc,n,time.time()-t0),flush=True)
print('all one-variable shape lemmas certified, total %.1fs'%(time.time()-T0))
