"""Certify q(u,v) = d/du log(-K(u,v)) > 0 on the main region
      M = [U0, L] x [V0, V]  intersected with {u+v >= SIGMA_C}
by corner-monotone box bounds (paper, Lemma 4.7 and Proposition 4.8).  Uses only the shape lemmas S1-S6.
Node values are exact-point ball evaluations; every box bound is a rigorous arb lower bound."""
import sys, time, math
from flint import arb, fmpq, ctx
ctx.prec=128
FACT=[1,1,2,6]
def psi(k,X):
    z=arb(k+1).zeta(X)
    return z*FACT[k] if k%2==1 else -z*FACT[k]
_cache={}
def pt(x):
    """values at an exact rational point x: G, G', h, h', T, delta'"""
    if x in _cache: return _cache[x]
    X=arb(x)
    p1,p2,p3=psi(1,X),psi(2,X),psi(3,X)
    h=1/p1; h1=-p2/(p1*p1); h2=(2*p2*p2-p1*p3)/(p1*p1*p1)
    G=-p1/p2; G1=p1*p3/(p2*p2)-1
    r=(G,G1,h,h1,h2/h1,G1-2*h1+1)
    _cache[x]=r
    return r
def node(u,v):
    Gu,G1u,hu,h1u,Tu,du=pt(u); Gv,G1v,hv,h1v,Tv,dv=pt(v); Gs,G1s,hs,h1s,Ts,ds=pt(u+v)
    A=Gs-Gu-Gv; B=hs-hu-hv
    return dict(A=A,B=B,DG=G1s-G1u,Dh=h1s-h1u,Dd=du-ds,Tu=Tu,Ts=Ts)
def box_lb(u0,u1,v0,v1):
    """rigorous lower bound for q on [u0,u1]x[v0,v1] (two variants, take the max)"""
    n00=node(u0,v0); n11=node(u1,v1); n01=node(u0,v1); n10=node(u1,v0)
    Tu=n11['Tu']; Ts=n11['Ts']                      # T decreasing (S1,S2): min at u1, s1
    Amax=n11['A']; Amin=n00['A']; Bmax=n11['B']; Bmin=n00['B']   # A,B increasing in u,v (S3,S1)
    DGmin=n00['DG'] if n00['DG']<n10['DG'] else (n10['DG'] if n10['DG']<n00['DG'] else n00['DG'].union(n10['DG']).lower())
    Dhmax=n01['Dh']; Dhmin=n10['Dh']                 # Dh incr in v (S1), decr in u (S2)
    Ddmax=n01['Dd']                                  # |Delta delta'| incr in v (S5), decr in u (S6)
    if not (Amin>0 and Bmin>0 and DGmin>0 and Dhmin>0):
        return None
    raw=Tu+Ts+DGmin/Amax-2*Dhmax/Bmin
    BAlo=(Bmin-Amax).lower()               # certified lower bound of B-A on the box
    if BAlo>=0:
        P=2*Dhmin*BAlo/(Amax*Bmax)
    else:
        P=2*Dhmax*BAlo/(Amin*Bmin)
    dsp=Tu+Ts-Ddmax/Amin+P
    return raw,dsp
def geom_nodes(a,b,rho):
    """rational nodes a=x0<x1<...<xn=b, roughly geometric with ratio exp(rho)"""
    n=max(1,math.ceil(math.log(float(b/a))/rho))
    r=(float(b)/float(a))**(1.0/n)
    xs=[a]
    for i in range(1,n):
        xs.append(fmpq(round(float(a)*r**i*2**24),2**24))
    xs.append(b)
    return xs
MODE='best'      # 'best': raw bound, balance bound as fallback; 'balance': balance (delta-split) bound only
def certify(U0,L,V0,V,SIG,rho,maxdepth=10,log=print):
    us=geom_nodes(U0,L,rho); vs=geom_nodes(V0,V,rho)
    stats=dict(boxes=0,raw=0,dsp=0,refined=0,minmargin=None)
    def check(u0,u1,v0,v1,depth):
        if u1+v1<SIG: return            # box entirely inside the corner region {u+v<SIG}
        r=box_lb(u0,u1,v0,v1)
        ok=False
        if r is not None:
            raw,dsp=r
            if MODE!='balance' and raw>0: ok=True; stats['raw']+=1; best=raw
            elif dsp>0: ok=True; stats['dsp']+=1; best=dsp
        if ok:
            rel=best/node(u1,v1)['Tu']
            if stats['minmargin'] is None or rel<stats['minmargin'][0]:
                stats['minmargin']=(rel,(float(u0),float(u1)),(float(v0),float(v1)))
        if ok:
            stats['boxes']+=1
            return
        if depth>=maxdepth:
            raise RuntimeError('box failed: u in [%s,%s], v in [%s,%s]'%(u0,u1,v0,v1))
        stats['refined']+=1
        um=(u0+u1)/2; vm=(v0+v1)/2
        for (a,b) in ((u0,um),(um,u1)):
            for (c,d) in ((v0,vm),(vm,v1)):
                check(a,b,c,d,depth+1)
    t0=time.time()
    for i in range(len(us)-1):
        for j in range(len(vs)-1):
            check(us[i],us[i+1],vs[j],vs[j+1],0)
        if i%20==0: log('  u-column %d/%d done (%.0fs), boxes so far %d'%(i,len(us)-1,time.time()-t0,stats['boxes']))
    return stats
if __name__=='__main__':
    U0=fmpq(1,10); L=fmpq(4); V0=fmpq(1,50); V=fmpq(10); SIG=fmpq(7,25)
    rho=float(sys.argv[1]) if len(sys.argv)>1 else 0.04
    if len(sys.argv)>2: MODE=sys.argv[2]
    print('mode:',MODE)
    st=certify(U0,L,V0,V,SIG,rho)
    rel,ub,vb=st['minmargin']
    print('MAIN REGION M=[1/10,4]x[1/50,10] cap {u+v>=7/25} certified: %d boxes (raw bound %d, balance bound %d, refinements %d), initial grid ratio exp(%.3f)'%(st['boxes'],st['raw'],st['dsp'],st['refined'],rho))
    print('smallest certified lower bound relative to T(u1): %s on u in [%.5f,%.5f], v in [%.5f,%.5f]'%(rel.str(5),ub[0],ub[1],vb[0],vb[1]))
