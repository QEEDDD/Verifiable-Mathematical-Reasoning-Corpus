"""Numerical illustrations (not used in the proofs): values of K, the edge laws, the diagonal,
the decomposition of q, and plot data for the figure in the paper.  mpmath, 40 digits."""
import mpmath as mp, os
mp.mp.dps=40
DATA=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','data')
def base(x):
    p1,p2,p3=[mp.polygamma(k,x) for k in (1,2,3)]
    return p1,p2,p3
def K(u,v):
    s=u+v
    p1,p2,_=base(u); q1,q2,_=base(v); r1,r2,_=base(s)
    return (r2*(p1*q2+q1*p2)-r1*p2*q2)/(4*(p1*q1-r1*(p1+q1))**2)
def hG(x):
    p1,p2,p3=base(x)
    h=1/p1; h1=-p2/p1**2; G=-p1/p2; G1=p1*p3/p2**2-1
    return h,h1,G,G1
def K0(u):      # lim_{v->0} K(u,v)
    h,h1,G,G1=hG(u); return -(G1-mp.mpf(1)/2)/2
def Kinf(u):    # lim_{v->oo} K(u,v)
    h,h1,G,G1=hG(u); return -h1*(u-G)/(4*(u-h)**2)
def defect(u,v):
    s=u+v
    hu,h1u,Gu,_=hG(u); hv,h1v,Gv,_=hG(v); hs,h1s,Gs,_=hG(s)
    A=Gs-Gu-Gv; B=hs-hu-hv
    return -h1u*h1v*h1s*A/(4*B**2)
print('Sample values of K (compact formula vs defect representation):')
for (u,v) in [(1,1),(mp.mpf('0.5'),2),(10,10),(100,100),(mp.mpf('0.01'),mp.mpf('0.01')),(50,mp.mpf('0.3')),(1,1000),(1000,1000)]:
    print('  K(%s,%s) = %s   [defect form: %s]'%(mp.nstr(u,4),mp.nstr(v,4),mp.nstr(K(u,v),15),mp.nstr(defect(u,v),15)))
print('Edge laws: K(u,0+) = -(G\'(u)-1/2)/2,  K(u,oo) = -h\'(u)g(u)/(4e(u)^2)')
for u in [mp.mpf(10)**k for k in (-3,-2,-1,0,1,2,3)]:
    print('  u=%-8s K(u,0+)=%-22s K(u,1e-8)=%-22s K(u,oo)=%-22s K(u,1e8)=%s'%(mp.nstr(u,3),mp.nstr(K0(u),12),mp.nstr(K(u,mp.mpf('1e-8')),12),mp.nstr(Kinf(u),12),mp.nstr(K(u,mp.mpf('1e8')),12)))
print('Diagonal K(x,x):')
for x in [mp.mpf(10)**(k/2) for k in range(-6,7)]:
    print('  x=%-10s K(x,x)=%s'%(mp.nstr(x,4),mp.nstr(K(x,x),15)))
# plot data: K(u,v) for v in {0.1,1,10} and the edge curves, u log-spaced in [1e-2,1e2]
us=[mp.mpf(10)**(k/10.0) for k in range(-20,21)]
with open(os.path.join(DATA,'plot_K.dat'),'w') as f:
    f.write('log10u K0 Kv01 Kv1 Kv10 Kinf\n')
    for u in us:
        f.write('%.2f %.6f %.6f %.6f %.6f %.6f\n'%(float(mp.log10(u)),float(K0(u)),float(K(u,mp.mpf('0.1'))),float(K(u,1)),float(K(u,10)),float(Kinf(u))))
# numerical illustration of the squeeze K(u,oo) < K(u,v) < K(u,0+) on a grid
grid=[mp.mpf(10)**(k/4.0) for k in range(-12,13)]
viol=0; cnt=0
for u in grid:
    lo=Kinf(u); hi=K0(u)
    for v in grid:
        k=K(u,v); cnt+=1
        if not (lo<k<hi): viol+=1
print('Squeeze K(u,oo)<K(u,v)<K(u,0+) on a 25x25 log grid in [1e-3,1e3]^2: %d violations out of %d'%(viol,cnt))
print('plot data written to data/plot_K.dat')
# asymptotics (remarks in the paper, not used in proofs)
def q(u,v):
    return mp.diff(lambda w: mp.log(-K(w,v)), u)
print('Large-argument expansion of q: q ~ (a^3+c^3)/6 + (a^2-c^2)(a+b-c)/18, a=1/x, b=1/y, c=1/(x+y):')
for (u,v) in [(50,50),(100,30),(200,1000),(1000,1000)]:
    u=mp.mpf(u); v=mp.mpf(v); a,b,c=1/u,1/v,1/(u+v)
    lead=(a**3+c**3)/6+(a**2-c**2)*(a+b-c)/18
    print('  x=%s y=%s  q=%s  leading=%s  ratio=%s'%(mp.nstr(u,4),mp.nstr(v,4),mp.nstr(q(u,v),10),mp.nstr(lead,10),mp.nstr(q(u,v)/lead,8)))
print('Near the origin: K/(-(3 zeta(2)/4)(x+y)^2) and q*(x+y)/2:')
for (u,v) in [('1e-2','1e-2'),('1e-3','3e-3'),('1e-4','1e-4'),('1e-5','2e-5')]:
    u=mp.mpf(u); v=mp.mpf(v); s=u+v
    print('  x=%s y=%s  ratio_K=%s  q*s/2=%s'%(mp.nstr(u,3),mp.nstr(v,3),mp.nstr(K(u,v)/(-3*mp.zeta(2)/4*s**2),8),mp.nstr(q(u,v)*s/2,8)))
