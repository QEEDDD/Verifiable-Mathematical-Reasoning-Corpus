"""Certify q>0 on the regions that reduce to one-variable inequalities (paper, Lemmas 4.2-4.6):
  C  (corner)   : u+v <= SIG
  Lf (left)     : u <= EPSL, v >= SIG-EPSL
  Bt (bottom)   : v <= EPSB, SIG-EPSB <= u <= LU
  I  (large u)  : u >= LU, v>0 arbitrary
  II (large v)  : EPSL <= u <= LU, v >= VV
Every inequality is checked in ball arithmetic on a finite partition; monotone quantities are
bounded by their endpoint values (shape lemmas S1-S7)."""
import time
from flint import arb, fmpq, ctx
from rig1d import Quantity, build
ctx.prec=256
INF=float('inf')
XS=fmpq(1); XL=fmpq(3)
SIG=fmpq(7,25); EPSL=fmpq(1,10); EPSB=fmpq(1,50); LU=fmpq(4); VV=fmpq(10)
names=['h','h1','h2','G','G1','G2','T','R','eps','dp','gp','ghat','kap','e','ep','g']
forms=build(names)
Qs={nm:Quantity(nm,forms) for nm in names}
def iv(a,b): return arb(a).union(arb(b))
def enc(nm,a,b):
    """ball containing {Q(x): a<=x<=b} (b may be INF); uses small/direct/large form"""
    Qo=Qs[nm]
    if b!=INF and b<=XS: return Qo.small_val(iv(a,b)) if a>0 or Qo.sa>=0 else None
    if a>=XL: return Qo.large_val(iv(0 if b==INF else fmpq(1)/b, fmpq(1)/a))
    return Qo.direct(iv(a,b))
def val(nm,x):
    return enc(nm,x,x) if x<=XS or x>=XL else Qs[nm].direct(arb(x))
def minG2(a,b):
    """min of G'' on [a,b]: G'' is unimodal (S4), so the minimum is attained at an endpoint"""
    A=val('G2',a); B=val('G2',b)
    return A.lower() if A.lower()<B.lower() else B.lower()
def encl_split(nm,a,b,n):
    """range enclosure on [a,b] as the union of n sub-enclosures (lower bound min, upper max)"""
    lo=None; hi=None
    for i in range(n):
        x0=a+(b-a)*i/n; x1=a+(b-a)*(i+1)/n
        E=enc(nm,x0,x1)
        l=E.lower(); u=E.upper()
        lo=l if lo is None else (l if l<lo else lo)
        hi=u if hi is None else (u if u>hi else hi)
    return lo,hi
def lb_pos(nm,a,b,depth=0):
    """a certified positive lower bound for Q on [a,b] (adaptive bisection), or error"""
    E=enc(nm,a,b).lower()
    if E>0: return E
    if depth>30: raise RuntimeError('lb_pos failed for %s on [%s,%s]'%(nm,a,b))
    m=(a+b)/2
    l1=lb_pos(nm,a,m,depth+1); l2=lb_pos(nm,m,b,depth+1)
    return l1 if l1<l2 else l2
def geom(a,b,ratio):
    xs=[a]
    while True:
        nx=fmpq(int(float(xs[-1])*ratio*2**30)+1,2**30)
        if nx>=b: xs.append(b); return xs
        xs.append(nx)
LOG=[]
def out(s):
    print(s,flush=True); LOG.append(s)

# ---------------- Corner: q >= 1/s + R(u) + R(s) >= 1/s1 + 2 min_{(0,s1]} R ----------------
def corner():
    N=400; m=None; worst=None
    for k in range(1,N+1):
        s0=SIG*(k-1)/N; s1=SIG*k/N
        lo=enc('R',s0,s1).lower()          # R = x * n/d on (0,1]: regular small form
        m=lo if m is None else (lo if lo<m else m)
        b=1/arb(s1)+2*m
        if not b>0: raise RuntimeError('corner fails at s1=%s'%s1)
        worst=b if worst is None else (b if b<worst else worst)
    out('C  corner  u+v<=%s : min lower bound of 1/s+2min R = %s  (N=%d)'%(SIG,worst.str(5),N))

# ---------------- Left: u<=EPSL, v>=SIG-EPSL ----------------
def left():
    Rmin=None
    for k in range(200):
        lo=enc('R',EPSL*k/200,EPSL*(k+1)/200).lower()
        Rmin=lo if Rmin is None else (lo if lo<Rmin else Rmin)
    G2e=val('G2',EPSL); G1e=val('G1',EPSL); h2e=val('h2',EPSL)
    v0=SIG-EPSL; VL=fmpq(10**6)
    vs=geom(v0,VL,1.02)
    worst=None
    for i in range(len(vs)-1):
        a,b=vs[i],vs[i+1]
        mG2=minG2(a,b+EPSL)
        xl=(mG2-G2e).lower()            # certified lower bound of min G''(v..v+u) - G''(EPSL)
        gt=arb(0) if xl>=0 else xl/(2*(val('G1',a)-G1e))   # bound for min(0, .)/<G''>
        lb=Rmin+val('T',b+EPSL)+gt+(h2e-val('h2',a))/val('h1',b)
        if not lb>0: raise RuntimeError('left fails on v in [%s,%s]: %s'%(a,b,lb))
        worst=lb if worst is None else (lb if lb<worst else worst)
    # tail v >= VL: T>=0, G''>=0, h'<1
    lbt=Rmin-G2e/(2*(val('G1',VL)-G1e))+h2e-val('h2',VL)
    if not lbt>0: raise RuntimeError('left tail fails')
    out('Lf left    u<=%s, v>=%s : min lower bound %s over %d v-intervals; tail v>=%s bound %s'%(EPSL,v0,worst.str(5),len(vs)-1,VL,lbt.str(5)))

# ---------------- Bottom: v<=EPSB, SIG-EPSB<=u<=LU ----------------
def bottom():
    us=geom(SIG-EPSB,LU,1.01)
    worst=None
    for i in range(len(us)-1):
        a,b=us[i],us[i+1]
        mG2=minG2(a,b+EPSB)
        den=val('h1',a)-EPSB
        if not den>0: raise RuntimeError('bottom: h1(u0)<=EPSB')
        lb=val('T',b)+val('T',b+EPSB)+mG2/(val('G1',b+EPSB)-fmpq(1,2))-2*val('h2',a)/den
        rel=lb/val('T',b)
        if not lb>0: raise RuntimeError('bottom fails on u in [%s,%s]: %s'%(a,b,lb))
        worst=rel if worst is None else (rel if rel<worst else worst)
    out('Bt bottom  v<=%s, %s<=u<=%s : min (lower bound)/T(u1) = %s over %d u-intervals'%(EPSB,SIG-EPSB,LU,worst.str(5),len(us)-1))

# ---------------- Region I: u>=LU, all v ----------------
def regionI():
    vs=fmpq(1); c=val('g',vs)       # c1=g(v*)/v*, c2=g(v*) with v*=1
    c1=c/vs; c2=c
    # finite part [LU, XB] with monotone endpoint bounds; tail [XB,inf) with large forms on t-intervals
    XB=fmpq(64)
    us=geom(LU,XB,1.02); worst=None
    for i in range(len(us)-1):
        a,b=us[i],us[i+1]
        T=val('T',b); ep=val('eps',a); gp=val('gp',a); dp=val('dp',a); gh=val('ghat',a)
        d1=c1-gp; d2=c2-gh
        if not (d1>0 and d2>0): raise RuntimeError('regionI denominators')
        m1=ep/d1; m2=dp/d2
        lb=T-(m1 if m1>m2 else (m2 if m2>m1 else m1.union(m2).upper()))
        if not lb>0: raise RuntimeError('region I fails on [%s,%s]: %s'%(a,b,lb))
        rel=lb/T; worst=rel if worst is None else (rel if rel<worst else worst)
    # tail: t in [0,1/XB], split into pieces; Q = t^m n/d with exact exponents
    K=64; worst_t=None
    for k in range(K):
        t0=fmpq(k,K)/XB; t1=fmpq(k+1,K)/XB
        Tb=iv(t0,t1)
        mT,nT,dT=Qs['T'].large(Tb); me,ne,de=Qs['eps'].large(Tb); mg,ng,dg=Qs['gp'].large(Tb)
        md,nd,dd=Qs['dp'].large(Tb); mh,nh,dh=Qs['ghat'].large(Tb)
        assert (mT,me,mg,md,mh)==(3,5,2,4,1)
        # divide everything by t^3:  T/t^3 - max( t^2 (e/t^5)/(c1 - t^2 g'/t^2) , t (d/t^4)/(c2 - t ghat/t) )
        Tt=nT/dT; et=ne/de; gt=ng/dg; dt=nd/dd; ht=nh/dh
        m1=Tb**2*et/(c1-Tb**2*gt); m2=Tb*dt/(c2-Tb*ht)
        lb=Tt-m1.union(m2).upper()
        if not (lb>0 and (c1-Tb**2*gt)>0 and (c2-Tb*ht)>0): raise RuntimeError('region I tail fails k=%d'%k)
        rel=lb/Tt.upper(); worst_t=rel if worst_t is None else (rel if rel<worst_t else worst_t)
    out('I  large u u>=%s (v*=1): min relative margin %s on [%s,%s] (%d intervals); tail u>=%s: min rel. margin %s'%(LU,worst.str(5),LU,XB,len(us)-1,XB,worst_t.str(5)))

# ---------------- Region II: EPSL<=u<=LU, v>=VV ----------------
def regionII():
    gV=val('gp',VV); eV=val('ep',VV)
    us=geom(EPSL,LU,1.01); worst=None
    for i in range(len(us)-1):
        a,b=us[i],us[i+1]
        kmin=lb_pos('kap',a,b)
        if not kmin>0: raise RuntimeError('kappa')
        den1=val('g',a)-b*gV
        fac=val('ep',b)-eV
        if not (den1>0 and fac>0): raise RuntimeError('regionII denominators on [%s,%s]'%(a,b))
        lb=val('T',b)-val('dp',a)/den1+2*fac*kmin/(val('g',b)*val('e',b))
        if not lb>0: raise RuntimeError('region II fails on [%s,%s]: %s'%(a,b,lb))
        rel=lb/val('T',b); worst=rel if worst is None else (rel if rel<worst else worst)
    out('II large v v>=%s, %s<=u<=%s : min (lower bound)/T(u1) = %s over %d u-intervals'%(VV,EPSL,LU,worst.str(5),len(us)-1))

if __name__=='__main__':
    T0=time.time()
    for f in (corner,left,bottom,regionI,regionII):
        t0=time.time(); f(); out('   (%.1fs)'%(time.time()-t0))
    out('ALL ONE-VARIABLE REGIONS CERTIFIED (%.1fs)'%(time.time()-T0))
