"""Rigorous one-variable layer (python-flint arb ball arithmetic).
Every function returns an arb ball that contains the exact range of the quantity over the input ball."""
import sympy as sp, pickle, os, time
from flint import arb, fmpq, fmpz, ctx
from symforms import Q, small_form, large_form, x, t, P, TH, PS, num_den
ctx.prec=256
FACT=[1,1,2,6,24,120,720,5040,40320]

def psi(k,X):
    """psi^{(k)} over the ball X (X>0): (-1)^(k+1) k! zeta(k+1,X)."""
    z=arb(k+1).zeta(X)
    return z*FACT[k] if k%2==1 else -z*FACT[k]

class Poly:
    """exact polynomial with fmpq coefficients, evaluated in ball arithmetic"""
    def __init__(self,expr,vars_):
        p=sp.Poly(sp.expand(expr),*vars_)
        self.vars=vars_
        self.terms=[(tuple(m),fmpq(int(c.p),int(c.q))) for m,c in p.terms()]
        self.maxdeg=[max([m[i] for m,_ in self.terms]+[0]) for i in range(len(vars_))]
    def __call__(self,vals):
        pw=[]
        for i,v in enumerate(vals):
            L=[arb(1)]
            for _ in range(self.maxdeg[i]): L.append(L[-1]*v)
            pw.append(L)
        s=arb(0)
        for m,c in self.terms:
            term=arb(c)
            for i,e in enumerate(m):
                if e: term*=pw[i][e]
            s+=term
        return s

CACHE=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','data','forms.pkl')
NTERMS=4
def _key():
    import hashlib
    src=open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'symforms.py'),'rb').read()
    return hashlib.sha256(src+('NTERMS=%d'%NTERMS).encode()).hexdigest()
def build(names):
    forms={}
    if os.path.exists(CACHE):
        cached=pickle.load(open(CACHE,'rb'))
        if cached.get('__key__')==_key(): forms=cached     # reuse only forms built from this exact symforms.py
    forms['__key__']=_key()
    changed=False
    for nm in names:
        if nm in forms: continue
        t0=time.time()
        n,d=num_den(Q[nm])
        a,ns,ds=small_form(nm)
        L=large_form(nm,NTERMS)
        forms[nm]=dict(direct=(n,d),small=(a,ns,ds),large=L)
        changed=True
        print('built',nm,'%.1fs'%(time.time()-t0),flush=True)
    if changed: pickle.dump(forms,open(CACHE,'wb'))
    return forms

class Quantity:
    def __init__(self,nm,forms):
        f=forms[nm]; self.name=nm
        n,d=f['direct']
        self.dn=Poly(n,[x]+list(PS)); self.dd=Poly(d,[x]+list(PS))
        a,ns,ds=f['small']; self.sa=a
        self.sn=Poly(ns,[x]+list(P)); self.sd=Poly(ds,[x]+list(P))
        L=f['large']; self.lm=L['m']
        self.ln=Poly(L['num'],[t]+list(TH)); self.ld=Poly(L['den'],[t]+list(TH))
    def direct(self,X):
        ps=[psi(k,X) for k in range(1,8)]
        return self.dn([X]+ps)/self.dd([X]+ps)
    def small(self,X):
        """returns (x^a factor exponent, n, d) over ball X (X may contain 0)"""
        Ps=[psi(k,1+X) for k in range(1,8)]
        return self.sa,self.sn([X]+Ps),self.sd([X]+Ps)
    def small_val(self,X):
        a,n,d=self.small(X)
        return (X**a if a>=0 else 1/X**(-a))*n/d
    def large(self,Tb):
        """Tb: ball of t=1/x values; returns (m, n, d) with Q = t^m n/d"""
        th=arb('0.5',0.5)   # [0,1]
        vals=[Tb]+[th]*7
        return self.lm,self.ln(vals),self.ld(vals)
    def large_val(self,Tb):
        m,n,d=self.large(Tb)
        return (Tb**m if m>=0 else 1/Tb**(-m))*n/d
