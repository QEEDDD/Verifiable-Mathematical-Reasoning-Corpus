#!/bin/sh
# Reproduces every certificate used in the paper (python3 + sympy + mpmath + python-flint 0.9).
# The first run builds ../data/forms.pkl (exact symbolic forms, about two minutes).
set -e
cd "$(dirname "$0")"
L=../logs
python3 curvsym.py   > $L/01_symbolic_identities.log 2>&1
python3 sanity.py    > $L/02_forms_crosscheck.log 2>&1
python3 lemmas1d.py  > $L/03_shape_lemmas.log 2>&1
python3 regions1d.py > $L/04_one_variable_regions.log 2>&1
python3 mainregion.py 0.04 > $L/05_main_region.log 2>&1
python3 mainregion.py 0.02 > $L/06_main_region_fine_grid.log 2>&1
python3 mainregion.py 0.04 balance > $L/08_main_region_balance_only.log 2>&1
python3 numerics.py  > $L/07_numerics.log 2>&1
echo "all certificates reproduced; see ../logs"
