"""Sanity checks: (1) small/direct/large forms agree with mpmath values;
(2) the Hessian-metric curvature formula agrees with the Brioschi formula symbolically;
(3) the defect, averaged and delta-split identities hold symbolically/numerically."""
import mpmath as mp, sympy as sp
from flint import arb, fmpq, ctx
from rig1d import Quantity, build
ctx.prec=256; mp.mp.dps=50
names=['h','h1','h2','h3','G','G1','G2','G3','G4','T','R','eps','eps1','dp','gp','ghat','kap','kap1','e','ep','g']
forms=build(names); Qs={n:Quantity(n,forms) for n in names}
def ref(nm,x):
    x=mp.mpf(x)
    def base(y):
        p1,p2,p3=[mp.polygamma(k,y) for k in (1,2,3)]
        return dict(h=1/p1,G=-p1/p2)
    f=lambda nm2,y: base(y)[nm2]
    d={'h':lambda y:f('h',y),'G':lambda y:f('G',y)}
    hd=lambda k: mp.diff(lambda y:f('h',y),x,k)
    Gd=lambda k: mp.diff(lambda y:f('G',y),x,k)
    v=dict(h=hd(0),h1=hd(1),h2=hd(2),h3=hd(3),G=Gd(0),G1=Gd(1),G2=Gd(2),G3=Gd(3),G4=Gd(4))
    v['T']=v['h2']/v['h1']; v['R']=v['T']-1/x; v['eps']=2*v['h2']-v['G2']; v['eps1']=2*v['h3']-v['G3']
    v['dp']=v['G1']-2*v['h1']+1; v['gp']=1-v['G1']; v['ghat']=v['G']-x+mp.mpf(1)/2
    v['kap']=v['G']-v['h']; v['kap1']=v['G1']-v['h1']; v['e']=x-v['h']; v['ep']=1-v['h1']; v['g']=x-v['G']
    return v[nm]
worst=0
for nm in names:
    for xs in ['0.3','0.9','2','5','40']:
        r=ref(nm,xs)
        X=arb(fmpq(*[int(z) for z in sp.Rational(xs).as_numer_denom()]))
        vals=[Qs[nm].direct(X)]                                   # direct form: all points
        if sp.Rational(xs)<=1: vals.append(Qs[nm].small_val(X))   # small-x form: used on (0,1]
        if sp.Rational(xs)>=3: vals.append(Qs[nm].large_val(1/X)) # enveloping form: used on [3,inf)
        for V in vals:
            c=mp.mpf(V.mid().str(40,radius=False)); rad=mp.mpf(V.rad().str(10,radius=False))
            err=abs(c-r)
            ok = err<=rad+mp.mpf(10)**-25*max(1,abs(r))
            if not ok: print('MISMATCH',nm,xs,c,r,rad)
            worst=max(worst,err/max(1,abs(r)))
print('all forms contain the mpmath reference values (no MISMATCH); worst relative distance of ball centres %.2e'%worst)
# the enveloping parameters theta_k enter the large-x forms only at strictly higher order than the leading term
from symforms import t, TH
import pickle, os
forms_all=pickle.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','data','forms.pkl'),'rb'))
for nm in sorted(k for k in forms_all if k!='__key__'):
    L=forms_all[nm]['large']; lows=[]
    for key in ('num','den'):
        Pp=sp.Poly(L[key],t,*TH)
        free=min(m[0] for m,c in Pp.terms() if sum(m[1:])==0)
        th=[m[0] for m,c in Pp.terms() if sum(m[1:])>0]
        assert free==0 and (not th or min(th)>0), nm
        lows.append(min(th) if th else None)
    print('large form %-5s: Q = t^%d n/d; theta enters n at order t^%s, d at order t^%s'%(nm,L['m'],lows[0],lows[1]))
print('all large-x forms have theta-free leading terms')
