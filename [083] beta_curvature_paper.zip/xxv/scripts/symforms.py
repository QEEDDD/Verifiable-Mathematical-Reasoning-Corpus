"""Symbolic layer: quantities attached to F = log Gamma, as rational functions of
psi_k = psi^{(k)}(x), k=1..6.  Produces three exact representations of each quantity Q:
  direct : rational in (x, psi1..psi6)
  small  : Q = x^a * n(x,P)/d(x,P),  P_k = psi_k(1+x),  n(0,.), d(0,.) not identically 0
  large  : Q = t^m * n(t,th)/d(t,th), t = 1/x, psi_k = (-1)^(k+1) (S_k(t) + th_k E_k(t)), th_k in [0,1]
All manipulations are exact (sympy rationals)."""
import sympy as sp
x,t=sp.symbols('x t',positive=True)
PS=sp.symbols('psi1:8')            # psi1..psi7
P=sp.symbols('P1:8')               # psi_k(1+x)
TH=sp.symbols('th1:8')             # enveloping parameters
psi=dict(zip(range(1,8),PS))
def D(expr):
    """d/dx of an expression in x, psi_k (psi_k' = psi_{k+1})."""
    r=sp.diff(expr,x)
    for k in range(1,7):
        r+=sp.diff(expr,psi[k])*psi[k+1]
    return r
p1,p2,p3=psi[1],psi[2],psi[3]
Q={}
Q['h']=1/p1
Q['h1']=D(Q['h']); Q['h2']=D(Q['h1']); Q['h3']=D(Q['h2']); Q['h4']=D(Q['h3'])
Q['G']=-p1/p2
Q['G1']=D(Q['G']); Q['G2']=D(Q['G1']); Q['G3']=D(Q['G2']); Q['G4']=D(Q['G3'])
Q['T']=Q['h2']/Q['h1']
Q['R']=Q['T']-1/x
Q['eps']=2*Q['h2']-Q['G2']
Q['eps1']=2*Q['h3']-Q['G3']
Q['kap']=Q['G']-Q['h']
Q['kap1']=Q['G1']-Q['h1']
Q['dp']=Q['G1']-2*Q['h1']+1          # delta'
Q['g']=x-Q['G']; Q['gp']=1-Q['G1']    # g = x - G
Q['e']=x-Q['h']; Q['ep']=1-Q['h1']    # e = x - h
Q['ghat']=Q['G']-x+sp.Rational(1,2)   # 1/2 - g
Q['ehat']=Q['h']-x+sp.Rational(1,2)   # 1/2 - e
Q['gam']=Q['G']/x                     # gamma = G/x
Q['eta_x']=Q['h']/x                   # h/x
Q['kG']=(Q['G1']-Q['G']/x)/x          # int_0^1 t G''(tx) dt
Q['kh']=(Q['h1']-Q['h']/x)/x          # int_0^1 t h''(tx) dt
for k in list(Q): Q[k]=sp.together(sp.simplify(Q[k]))

def num_den(expr):
    n,d=sp.fraction(sp.together(expr))
    return sp.expand(n),sp.expand(d)

def small_form(name):
    """psi_k(x) = (-1)^(k+1) k!/x^(k+1) + P_k ; return (a, n, d) with Q = x^a n/d."""
    n,d=num_den(Q[name])
    sub={psi[k]:(-1)**(k+1)*sp.factorial(k)/x**(k+1)+P[k-1] for k in range(1,8)}
    res=[]
    for poly in (n,d):
        e=sp.together(poly.subs(sub))
        nn,dd=sp.fraction(e)               # dd is a pure power of x
        nn=sp.Poly(sp.expand(nn),x)
        # lowest power of x in nn
        low=min(m[0] for m in nn.monoms())
        nn=sp.expand(sp.cancel(nn.as_expr()/x**low))
        ddeg=sp.Poly(dd,x).degree() if dd.has(x) else 0
        assert sp.simplify(dd-x**ddeg*sp.Poly(dd,x).LC())==0
        res.append((low-ddeg, nn/sp.Poly(dd,x).LC()))
    (an,nn),(ad,dd)=res
    return an-ad, sp.expand(nn), sp.expand(dd)

def bern_parts(k,nterms):
    """(-1)^(k+1) psi_k(x) = S + th*E (Alzer 1997, Thm 8), t=1/x."""
    S=sp.factorial(k-1)*t**k+sp.factorial(k)*t**(k+1)/2
    for j in range(1,nterms+1):
        S+=sp.bernoulli(2*j)*sp.factorial(2*j+k-1)/sp.factorial(2*j)*t**(2*j+k)
    j=nterms+1
    E=sp.bernoulli(2*j)*sp.factorial(2*j+k-1)/sp.factorial(2*j)*t**(2*j+k)
    return S,E

def large_form(name,nterms):
    n,d=num_den(Q[name])
    sub={x:1/t}
    for k in range(1,8):
        S,E=bern_parts(k,nterms)
        sub[psi[k]]=(-1)**(k+1)*(S+TH[k-1]*E)
    res=[]
    for poly in (n,d):
        e=sp.together(sp.expand(poly.subs(sub)))
        nn,dd=sp.fraction(e)
        nn=sp.Poly(sp.expand(nn),t); dd=sp.Poly(sp.expand(dd),t)
        lowd=min(m[0] for m in dd.monoms()); assert len(dd.monoms())==1
        # theta-free part lowest power
        nn0=sp.Poly(sp.expand(nn.as_expr().subs({th:0 for th in TH})),t)
        low0=min(m[0] for m in nn0.monoms())
        lowall=min(m[0] for m in nn.monoms())
        res.append((low0,lowall,sp.expand(sp.cancel(nn.as_expr()/t**min(low0,lowall))),min(low0,lowall)-lowd, dd.LC()))
    (n0,na,nn,en,lcn),(d0,da,dd,ed,lcd)=res
    return dict(m=en-ed, num=sp.expand(nn/lcn), den=sp.expand(dd/lcd), num_low0=n0, num_lowall=na, den_low0=d0, den_lowall=da)

if __name__=='__main__':
    for nm in ['h2','h3','G2','G3','eps','eps1','kap1','R','kap','G4']:
        a,n,d=small_form(nm)
        print(nm,'small: x^',a,' n(0)=',sp.simplify(n.subs(x,0)),' d(0)=',sp.simplify(d.subs(x,0)))
