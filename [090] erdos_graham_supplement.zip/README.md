# Supplement to "Tent rigidity for the Erdős–Graham equation and the Tengely–Ulas–Zygadło conjecture" (Keio, 2026)

All programs use exact integer arithmetic. The folder `independent_check/` contains a second, independently written set of programs (see its `NOTE.md`), which do not use the tent theory and reproduce the main computations. C programs: `gcc -O2 -o prog prog.c -lm`.
Python programs need Python 3 only. Run them from inside `code/` (the Python files import `eg.py`).

## Data (`data/`)

| file | content |
|---|---|
| `certs.json` | explicit solutions with a_k = 392: `n3_K392` (the set A* of the paper, 185 terms), `n14_K392` (181 terms, the Borwein–Loring example), `n18_K392` (177 terms, fewest terms of any counterexample), `n1_K392` (185 terms) |
| `Astar_states.txt` | hand-checkable certificate for A*: the integer states rho_j from rho_3 = 3 to rho_392 = 0 (all live states lie in [1, j+1]) |
| `violations_ak392.txt` | all 37 solutions with a_k <= 392 violating a_k <= 2(n+k) (all have a_k = 392), with their elements |
| `solutions_k_le_28.txt` | every solution with 2 <= k <= 28 terms; columns `k n a_k multiplicity` (Table 3 of the paper) |
| `table_n3_upto_2e9.txt` | Table 2: all K <= 2*10^9 with a representation of 3/8 of largest term K; h, k_min, k_max, excess |
| `events_n3.txt` | centres (`C`) and odd windows (`W+`/`W-`, side of the reference path) of the tent sequence of n = 3 up to 4*10^9 |

## Programs (`code/`)

| program | purpose | expected output |
|---|---|---|
| `verify392.bc` | `BC_LINE_LENGTH=0 bc -q verify392.bc` computes 3*2^389 - sum a*2^(392-a) over A* | `0` |
| `verify.gp` | `gp -q verify.gp` checks the four sets of `certs.json` as exact rationals | four lines with `sum==n/2^n: 1` |
| `eg.py` | raw dynamic programming over integer states (no tent theory); `python3 eg.py 3 400` | K = 8, 32, 46, 392 with k ranges |
| `certs.py` | reconstructs the sets of `certs.json` and checks them | k = 185, 181, 177, 185 |
| `minimality.py` | Theorem 4.1(b): all 403 solutions with a_k <= 392; 37 violating solutions (25 distinct (n,k)), all at a_k = 392 | `403`, `37`, `25` |
| `all392.py` | writes `violations_ak392.txt` (explicit sets, each verified) | `37 violating solutions` |
| `minviolk.c` | Theorem 4.1(c): `./minviolk 2500 5000` exhaustive DP for n <= 2500, a_k <= 5000, k < 2600 | least violating a_k = 392, least k = 177 (n = 18) |
| `nextviol.c` | `./nextviol 392 12230`: no counterexample with 392 < a_k < 12230; counterexamples at 12230 for 61 values of n | `61; least a_k = 12230` |
| `check_theory.py` | checks Theorems 3.3/3.4 (rigidity, 2^{c(j)} paths, mirror symmetry, 2^{c(j)-1} successes) against the raw DP for n <= 300, j < 3000 | `all verified` |
| `nk.c` | Theorem 6.1: `./nk 28 0 out.txt` (raw, ~16 min) or `./nk 22 1 out.txt` (hybrid); raw and hybrid lists coincide for k <= 22 | N(k) table, max a_k = 2^(k+1)-2 |
| `excess.c` | Corollary 3.6 for one n: `./excess 3 2000000000` | Table 2 |
| `events.c` | `./events 3 4000000000` centres and odd windows | 12 centres below 4*10^9 |
| `blockcount.c` | lower bounds for N(k): `./blockcount 12230` | max multiplicity 122 at k = 6109 |
| `cert_N.py` | explicit construction + exact verification: `python3 cert_N.py 392 185`, `python3 cert_N.py 12230 6109` | 14, resp. 122 verified solutions |
| `everyn.c` | Theorem 4.1(e): `./everyn 1 1000 12000000`, `./everyn 1001 3000 12000000` | no failures |
| `everyn_merge.c` | Theorem 4.1(e) for all n <= 16513: `./everyn_merge 1 16513 2000000 760000000` (two-state DP for n until its tent sequence meets that of n = 3, then block data of n = 3) | no failures; n = 16514 has none up to 2.2*10^9 |
| `ii.c` | Proposition 7.2: `./ii 1 1000000 4000000000` | no failures |
| `brute_k4.py` | brute force over subsets for k <= 4 (Theorem 5.1, small k) | 9 solutions, max a_k = 6, 14, 30 |
| `merge.c` | coalescence of tent sequences: `./merge 100000 100000000` | all merge by j = 249178 |
