"""All solutions (n; A) of n/2^n = sum_{a in A} a/2^a with max A = 392 that violate max A <= 2(n+|A|):
enumerate all paths by plain DP with explicit parent pointers (no tent theory), print the sets."""
K = 392
out = []
for n in range(1, K):
    # layers of dict state -> list of (prefix_set_as_tuple)   (number of paths is tiny)
    layer = {n: [()]}
    for j in range(n, K-1):
        new = {}
        for r, prefs in layer.items():
            for inc in (0, 1):
                v = 2*r - (j+1) if inc else 2*r
                if not (0 < v <= j+2): continue
                new.setdefault(v, []).extend([p + ((j+1,) if inc else ()) for p in prefs])
        layer = new
    for r, prefs in layer.items():
        if 2*r - K == 0:
            for p in prefs:
                A = p + (K,)
                assert n << (K-n) == sum(a << (K-a) for a in A)
                if len(A) >= 2 and K > 2*(n+len(A)): out.append((n, A))
out.sort(key=lambda t: (t[0], len(t[1]), t[1]))
with open("violations_ak392.txt", "w") as f:
    f.write("# All 37 solutions of n/2^n = sum a/2^a with a_k = 392 > 2(n+k). Format: n k excess : elements\n")
    for n, A in out:
        f.write("%d %d %d : %s\n" % (n, len(A), K - 2*(n+len(A)), " ".join(map(str, A))))
print(len(out), "violating solutions written; distinct (n,k):", len(set((n,len(A)) for n,A in out)))
