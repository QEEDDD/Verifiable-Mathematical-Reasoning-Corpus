/* For target largest term Kt, for every n < Kt compute (via Theorem 3.5 block decomposition) the multiset of
   term counts k of all solutions of n/2^n with a_k = Kt; aggregate H[k] = #{(n,A): |A|=k, max A = Kt}. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef long long ll;
#define MAXB 64
int main(int argc,char**argv){
  ll Kt=atoll(argv[1]); ll nlo = argc>2? atoll(argv[2]) : 1, nhi = argc>3? atoll(argv[3]) : Kt-1;
  ll *H = calloc(Kt+2,sizeof(ll)); ll total=0, nwith=0;
  for (ll n=nlo;n<=nhi && n<Kt;n++){
    ll u = n>=2? n-2:1; int s = n>=3?1:(n==1?-1:0);
    ll h=0, A0=0, bstart=-1, bx=0; ll L[MAXB], X[MAXB]; int nb=0;
    ll j;
    for (j=n;j<Kt-1;j++){
      ll w=2*u-(j+1);
      if (u==0){ if (h>0){ L[nb]=j-bstart; X[nb]=bx; nb++; } h++; bstart=j; bx=0; s=+1; }
      else { int inc=(s>0); if(h==0) A0+=inc; else bx+=inc; if(w<0) s=-s; }
      u=w<0?-w:w;
    }
    /* now j = Kt-1 */
    if (!(u==1 && ((Kt-1)&1))) continue;
    if (n==1 && Kt==2) continue;
    if (h==0){ if (s<0){ H[A0+1]++; total++; nwith++; } continue; }
    ll Lp = (Kt-1)-bstart; ll y = (s<0)? bx : Lp-bx;
    ll base = A0 + y + 1;
    /* subset sums over nb free blocks */
    ll ncomb = 1LL<<nb;
    for (ll m=0;m<ncomb;m++){ ll k=base; for(int b=0;b<nb;b++) k += ((m>>b)&1)? (L[b]-X[b]) : X[b]; H[k]++; total++; }
    nwith++;
  }
  ll best=0,bestk=-1, kmin=-1,kmax=-1;
  for (ll k=0;k<=Kt;k++) if(H[k]){ if(kmin<0)kmin=k; kmax=k; if(H[k]>best){best=H[k];bestk=k;} }
  printf("Kt=%lld n in[%lld,%lld]: n with solutions=%lld, solutions=%lld, k in [%lld,%lld], max multiplicity H[k]=%lld at k=%lld\n",Kt,nlo,nhi,nwith,total,kmin,kmax,best,bestk);
  if (argc>4){ for (ll k=kmin;k<=kmax;k++) if(H[k]) printf("%lld %lld\n",k,H[k]); }
  return 0;
}
