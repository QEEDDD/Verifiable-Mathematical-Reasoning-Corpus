# Independent brute force (itertools over subsets) for k<=4: n<=26, a_k<=50  (Theorem 5.1, small k)
from itertools import combinations
sols=[]
for k in range(2,5):
    for n in range(1,27):
        for K in range(n+k, 51):
            for rest in combinations(range(n+1,K), k-1):
                A=rest+(K,)
                if n<<(K-n) == sum(a<<(K-a) for a in A): sols.append((k,n,A))
for s in sols: print(s)
print(len(sols), "solutions; max a_k per k:", {k:max(A[-1] for kk,n,A in sols if kk==k) for k in (2,3,4)})
