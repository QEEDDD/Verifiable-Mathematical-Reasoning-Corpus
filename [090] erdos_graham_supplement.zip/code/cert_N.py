"""Certificate for lower bounds N(k) >= m: construct explicitly all solutions (n; A) with max A = K and |A| = k
(using the block structure only to *find* them) and verify each one by exact integer arithmetic."""
import sys
from itertools import product
K, kt = int(sys.argv[1]), int(sys.argv[2])

def tent_data(n, K):
    u = abs(n-2); j = n; cents = []
    while j < K-1:
        if u == 0: cents.append(j)
        u = abs(2*u - (j+1)); j += 1
    return cents, u

def build(n, K, choice):
    """simulate states; choice[i] in {0,1}: 0 = exclude at centre i, 1 = include. Returns A or None."""
    r = n; A = []; ci = 0
    for j in range(n, K-1):
        v = 2*r - (j+2)
        if v == 0:
            inc = choice[ci]; ci += 1
        elif v >= 2 or v == 1: inc = 1          # forced include (v=1: the live continuation)
        else: inc = 0                            # v <= -1: forced exclude (v=-1: live continuation)
        if inc: A.append(j+1); r = 2*r - (j+1)
        else: r = 2*r
        assert 1 <= r <= j+2 - 1 + 1 and r <= j+2, (n, j, r)
    # last step: must include K from state K/2
    if 2*r - K != 0: return None
    A.append(K)
    return A

found = []
for n in range(1, K):
    cents, u = tent_data(n, K)
    if u != 1: continue
    h = len(cents)
    if n == 1 and K == 2: continue
    for choice in product((0, 1), repeat=h):
        A = build(n, K, choice)
        if A is None or len(A) != kt: continue
        # exact verification, independent of the construction
        assert all(a > n for a in A) and len(set(A)) == len(A)
        assert n << (K - n) == sum(a << (K - a) for a in A)
        found.append((n, tuple(A)))
assert len(set(found)) == len(found)
print("K=%d k=%d: %d distinct verified solutions; n values: %s" % (K, kt, len(found), sorted(set(n for n,_ in found))[:40]))
