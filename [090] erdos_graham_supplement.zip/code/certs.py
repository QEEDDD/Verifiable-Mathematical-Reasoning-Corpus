from eg import min_path, check, enumerate_solutions
from fractions import Fraction as F
import json
out = {}
for (n, K) in [(3, 392), (14, 392), (18, 392), (1, 392)]:
    A = min_path(n, K)
    assert check(n, A) and sum(F(a, 2**a) for a in A) == F(n, 2**n)
    assert all(a > n for a in A) and len(A) == len(set(A))
    out["n%d_K%d" % (n, K)] = A
    print("n=%d K=%d k=%d  2(n+k)=%d  excess=%d" % (n, K, len(A), 2*(n+len(A)), K-2*(n+len(A))))
json.dump(out, open("certs.json", "w"))
A = out["n3_K392"]
print("A* =", A)
# complement in (3,392]
comp = [a for a in range(4, 393) if a not in set(A)]
print("missing integers in (3,392]: %d" % len(comp))
# maximal runs of consecutive elements of A
runs = []; s = A[0]; p = A[0]
for a in A[1:]:
    if a == p+1: p = a; continue
    runs.append((s, p)); s = p = a
runs.append((s, p))
print("as %d maximal runs:" % len(runs), " ".join("%d" % r[0] if r[0]==r[1] else "%d-%d" % r for r in runs))
