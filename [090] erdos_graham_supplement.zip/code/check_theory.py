# Validate the tent-rigidity theorem against the raw DP (no theory) for many n.
from collections import defaultdict, Counter
import sys
def check(n, J):
    u = abs(n-2); h = 0            # tent orbit, number of centres seen
    layer = {n: Counter({0: 1})}   # rho -> Counter(k -> #paths)   (live finite-continuable paths)
    # predicted term-count structure: blocks between centres
    j = n
    nsucc_checked = 0
    while j < J:
        # (1) every live state has |2 rho - j - 2| == u_j
        for r in layer: assert abs(2*r - j - 2) == u, (n, j, r, u)
        paths = sum(sum(c.values()) for c in layer.values())
        assert paths == 2**h, (n, j, paths, h)
        # (2) mirror symmetry after the first centre
        if h >= 1:
            ms = Counter({r: sum(c.values()) for r, c in layer.items()})
            for r, m in ms.items(): assert ms.get(j+2-r, 0) == m, (n, j, 'mirror')
        new = defaultdict(Counter); succ = Counter()
        for r, cnts in layer.items():
            v = 2*r                                  # exclude a=j+1
            if v <= j+2:
                for k, c in cnts.items(): new[v][k] += c
            v = 2*r - (j+1)                          # include a=j+1
            if v == 0:
                for k, c in cnts.items(): succ[k+1] += c
            elif 0 < v <= j+2:
                for k, c in cnts.items(): new[v][k+1] += c
        nsucc = sum(succ.values())
        # (3) successes exactly at odd windows u_j = 1, number 2^(h-1) if h>=1
        if nsucc: assert u == 1 and j % 2 == 1, (n, j, u)
        if u == 1 and j % 2 == 1 and h >= 1:
            assert nsucc == 2**(h-1), (n, j, nsucc, h); nsucc_checked += 1
        if u == 0: h += 1
        layer = {r: c for r, c in new.items()}
        w = 2*u - (j+1); u = abs(w); j += 1
    return nsucc_checked
tot = 0
for n in range(1, 301):
    tot += check(n, 3000)
print("tent rigidity, path count 2^h, mirror symmetry, success count 2^(h-1): all verified for n<=300, j<3000; odd-window success counts checked:", tot)
