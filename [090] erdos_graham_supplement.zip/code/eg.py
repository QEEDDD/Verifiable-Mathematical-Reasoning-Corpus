"""Erdos-Graham equation  n/2^n = sum_{a in A} a/2^a  (A finite, |A|=k>=2).
Raw dynamic programming over the integer state rho_j = 2^j (n/2^n - sum_{a in A, a<=j} a/2^a), j>=n.
No use of the tent-rigidity theory: states are kept as an explicit dict  rho -> {k: number_of_paths}.
"""
from collections import defaultdict

def enumerate_solutions(n, Kmax):
    """Return dict K -> {k: count} of all representations of n/2^n (all terms > n, distinct)
    with largest term K <= Kmax, including the trivial one-term ones if any (k=1)."""
    layer = {n: {0: 1}}            # at j = n, rho = n, zero terms used
    out = {}
    j = n
    while j < Kmax and layer:
        new = defaultdict(lambda: defaultdict(int))
        for r, cnts in layer.items():
            # exclude a=j+1
            v = 2*r
            if v <= j+2:            # finite reps need rho_{j+1} <= (j+1)+1
                for k, c in cnts.items(): new[v][k] += c
            # include a=j+1
            v = 2*r - (j+1)
            if v == 0:
                d = out.setdefault(j+1, defaultdict(int))
                for k, c in cnts.items(): d[k+1] += c
            elif 0 < v <= j+2:
                for k, c in cnts.items(): new[v][k+1] += c
        layer = {r: dict(c) for r, c in new.items()}
        j += 1
    return {K: dict(d) for K, d in out.items()}

def min_path(n, K):
    """Reconstruct one representation of n/2^n with largest term K and the minimum number of terms."""
    layers = [{n: (0, None, None)}]   # rho -> (mincount, parent_rho, included?)
    j = n
    while j < K - 1:
        new = {}
        for r, (c, _, _) in layers[-1].items():
            for inc in (0, 1):
                v = 2*r - (j+1) if inc else 2*r
                if not (0 < v <= j+2): continue
                cc = c + inc
                if v not in new or cc < new[v][0]: new[v] = (cc, r, inc)
        layers.append(new); j += 1
    # last step j = K-1 must include K and land on 0
    best = None
    for r, (c, _, _) in layers[-1].items():
        if 2*r - K == 0 and (best is None or c < best[0]): best = (c, r)
    if best is None: return None
    A = [K]; r = best[1]
    for idx in range(len(layers)-1, 0, -1):
        c, pr, inc = layers[idx][r]
        if inc: A.append(n + idx)       # layer idx corresponds to j = n+idx; inclusion of a = j
        r = pr
    return sorted(A)

def check(n, A):
    """Exact check of n/2^n == sum a/2^a using integers scaled by 2^max(A)."""
    K = max(A)
    return n << (K - n) == sum(a << (K - a) for a in A) and len(set(A)) == len(A)

if __name__ == "__main__":
    import sys
    n, K = int(sys.argv[1]), int(sys.argv[2])
    sols = enumerate_solutions(n, K)
    for KK in sorted(sols):
        ks = sols[KK]
        print("K=%d  #sols=%d  k-range=[%d,%d]  2(n+kmin)=%d  excess=%d" % (KK, sum(ks.values()), min(ks), max(ks), 2*(n+min(ks)), KK-2*(n+min(ks))))
