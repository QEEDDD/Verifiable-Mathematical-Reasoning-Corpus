#include <stdio.h>
#include <stdlib.h>
typedef long long ll;
int main(int argc,char**argv){ ll n=atoll(argv[1]), J=atoll(argv[2]);
  ll u = n>=2? n-2:1; int s = n>=3? 1 : (n==1?-1:0);
  for (ll j=n;j<=J;j++){
    if (u==0) printf("C %lld\n",j);
    else if (u==1 && (j&1)) printf("W%c %lld\n", s>0?'+':'-', j);
    ll w=2*u-(j+1);
    if (u==0) s=+1; else if (w<0) s=-s;
    u=w<0?-w:w;
  }
  return 0; }
