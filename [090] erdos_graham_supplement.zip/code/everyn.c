/* for each n in [n0,n1]: least a_k <= J of a counterexample to a_k <= 2(n+k) (fast block method) */
#include <stdio.h>
#include <stdlib.h>
typedef long long ll;
int main(int argc,char**argv){ ll n0=atoll(argv[1]), n1=atoll(argv[2]), J=atoll(argv[3]);
  ll worstK=0, worstn=-1, nfail=0;
  for (ll n=n0; n<=n1; n++){
    ll u = n>=2? n-2:1; int s = n>=3?1:(n==1?-1:0);
    ll h=0,A0=0,smin=0,bstart=-1,bx=0, found=-1, fk=-1;
    for (ll j=n;j<J;j++){
      if ((j&1) && u==1 && !(n==1&&j==1)){
        ll K=j+1, kmin=-1;
        if (h==0){ if (s<0) kmin=A0+1; }
        else { ll L=j-bstart; ll y=(s<0)?bx:L-bx; kmin=A0+smin+y+1; }
        if (kmin>0 && K>2*(n+kmin)){ found=K; fk=kmin; break; }
      }
      ll w=2*u-(j+1);
      if (u==0){ if(h>0){ ll L=j-bstart; smin += (bx<L-bx?bx:L-bx);} h++; bstart=j; bx=0; s=+1; }
      else { int inc=(s>0); if(h==0)A0+=inc; else bx+=inc; if(w<0)s=-s; }
      u=w<0?-w:w;
    }
    if (found<0){ nfail++; if (nfail<=20) printf("n=%lld: no counterexample with a_k<=%lld\n",n,J); continue; }
    if (found>worstK){worstK=found;worstn=n;}
  }
  printf("n in [%lld,%lld]: without counterexample below %lld: %lld; largest least counterexample a_k=%lld (n=%lld)\n",n0,n1,J,nfail,worstK,worstn);
  return 0; }
