/* For each n in [n0,n1]: least a_k <= JU+1 of a counterexample to a_k <= 2(n+k).
   Method: min-count DP on the two tent states of n until its tent sequence meets that of n=3 (U),
   then U's precomputed block data (Theorem 3.5) for all later odd windows of U. */
#include <stdio.h>
#include <stdlib.h>
typedef long long ll;
#define INF (1LL<<60)
typedef struct { ll t; int type; ll P; int sig; } Ev;  /* type 0 centre, 1 odd window; P = ref prefix count up to t (steps < t); sig = ref side at t */
int main(int argc,char**argv){
  ll n0=atoll(argv[1]), n1=atoll(argv[2]); ll JM=atoll(argv[3]); ll JU=atoll(argv[4]);
  int *Uu=malloc(sizeof(int)*(JM+2)); ll *UP=malloc(sizeof(ll)*(JM+2)); signed char *Us=malloc(JM+2);
  Ev *ev=malloc(sizeof(Ev)*100000); int nev=0;
  { ll u=1; int s=+1; ll P=0;            /* n=3: u_3=1, ref side + */
    for (ll j=3;j<=JU;j++){
      if (j<=JM){ Uu[j]=(int)u; UP[j]=P; Us[j]=(signed char)s; }
      if (u==0){ ev[nev].t=j; ev[nev].type=0; ev[nev].P=P; ev[nev].sig=0; nev++; }
      else if (u==1 && (j&1)){ ev[nev].t=j; ev[nev].type=1; ev[nev].P=P; ev[nev].sig=s; nev++; }
      ll w=2*u-(j+1);
      if (u==0){ s=+1; /* ref excludes at centre: no inclusion */ }
      else { if (s>0) P++; if (w<0) s=-s; }
      u = w<0?-w:w;
    } }
  for (ll j=0;j<3 && j<=JM;j++){ Uu[j]=-1; }
  ll worstK=0,worstn=-1,nfail=0,nomerge=0; ll maxmerge=0;
  for (ll n=n0;n<=n1;n++){
    ll u = n>=2? n-2:1; ll ct = n>=3?0:INF, cb = n==1?0:INF; ll cc = (n==2)?0:INF; /* top, bottom, centre counts */
    ll found=-1; ll t=-1;
    for (ll j=n;j<=JM;j++){
      if (j>=3 && Uu[j]==(int)u){ t=j; break; }          /* merged with U at time j (state before move at j) */
      if (u==1 && (j&1) && cb<INF && !(n==1&&j==1)){ ll K=j+1, k=cb+1; if (K>2*(n+k)){found=K;break;} }
      ll w=2*u-(j+1); ll nt=INF, nb=INF;
      if (u==0){ ll c=cc; nt=c; nb=c+1; }
      else if (w>0){ if(ct<INF) nt=ct+1; if(cb<INF) nb=cb; }
      else { if(ct<INF) nb=ct+1; if(cb<INF) nt=cb; }
      ll nu = w<0?-w:w;
      if (nu==0){ cc = (nt<nb?nt:nb); ct=cb=INF; } else { ct=nt; cb=nb; cc=INF; }
      u=nu;
    }
    if (found<0 && t<0){ nomerge++; continue; }
    if (found<0){
      if (t-n>maxmerge) maxmerge=t-n;
      /* n's state at merge time t: if u==0 single centre state with count cc; else top count ct, bottom cb */
      int sref = Us[t];  /* ref side of U at t (0 meaningless if centre) */
      /* events of U strictly after the steps already processed: odd windows w>=t, centres >= t */
      int e0=0; while (e0<nev && ev[e0].t<t) e0++;
      ll Pt = UP[t];
      ll m_same=INF, m_opp=INF;   /* n's min counts on the side equal/opposite to U's reference side at t */
      if (u==0){ m_same=cc; m_opp=cc; }
      else { if (sref>0){ m_same=ct; m_opp=cb; } else { m_same=cb; m_opp=ct; } }
      ll firstC=-1, firstCP=0; ll blocksum=0; ll lastC=-1, lastCP=0; ll D=INF;
      for (int e=e0;e<nev && found<0;e++){
        if (ev[e].type==0){
          if (firstC<0){
            firstC=ev[e].t; firstCP=ev[e].P;
            ll Iref = firstCP-Pt, L=firstC-t;           /* inclusions on [t,firstC) for ref-side path */
            ll a = m_same<INF? m_same+Iref : INF, b = m_opp<INF? m_opp+(L-Iref) : INF;
            if (u==0 && firstC==t){ a=cc; b=cc; }
            D = a<b?a:b;
          } else { ll x=ev[e].P-lastCP, L=ev[e].t-lastC; blocksum += (x<L-x?x:L-x); }
          lastC=ev[e].t; lastCP=ev[e].P;
        } else {
          ll w=ev[e].t, K=w+1; ll k=-1;
          if (w==1) continue;
          if (firstC<0){
            /* no centre in [t,w): side invariant relative to ref; need offset -1 at w */
            ll Iref = ev[e].P-Pt, L=w-t;
            int need_same = (ev[e].sig<0);              /* ref side at w is bottom -> 'same' paths succeed */
            if (need_same && m_same<INF) k = m_same+Iref+1;
            if (!need_same && m_opp<INF) k = m_opp+(L-Iref)+1;
          } else {
            ll x=ev[e].P-lastCP, L=w-lastC; ll y = (ev[e].sig<0)? x : L-x;
            if (D<INF) k = D + blocksum + y + 1;
          }
          if (k>0 && K>2*(n+k)) found=K;
        }
      }
    }
    if (found<0){ nfail++; if (nfail<=10) printf("n=%lld: none with a_k<=%lld\n",n,JU+1); continue; }
    if (getenv("PERN")) printf("%lld %lld\n",n,found);
    if (found>worstK){worstK=found;worstn=n;}
  }
  printf("n in [%lld,%lld]: no counterexample up to %lld: %lld; not merged by %lld: %lld; max merge delay %lld; largest least counterexample a_k=%lld (n=%lld)\n",
     n0,n1,JU+1,nfail,JM,nomerge,maxmerge,worstK,worstn);
  return 0; }
