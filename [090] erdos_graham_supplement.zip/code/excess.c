/* Theory-based (tent rigidity + block decomposition) computation of all solutions' term-count range
   for n/2^n at every possible largest term K <= J.  O(J) time, O(#centres) memory. */
#include <stdio.h>
#include <stdlib.h>
typedef long long ll;
int main(int argc,char**argv){
  ll n=atoll(argv[1]), J=atoll(argv[2]); int verbose = argc>3 ? atoi(argv[3]) : 1;
  ll u = n>=2? n-2 : 1;  /* u_n = |n-2| */
  int v_sign = (n>=3)? +1 : (n==1? -1 : 0);   /* sign of v on the reference path (0 at a centre) */
  ll h=0;                 /* centres so far */
  ll A0=0;                /* inclusions before first centre (single path) */
  ll sum_min=0, sum_max=0;/* sum over completed blocks of min/max(x_i, L_i-x_i) */
  ll blk_start=-1, blk_x=0; /* current block: start (centre time) and reference inclusions in it */
  ll best_excess = -(1LL<<60), bestK=-1;
  for (ll j=n; j<=J; j++){
    /* success at odd window? (reference path state v = v_sign*u) */
    if ((j&1) && u==1 && !(n==1 && j==1)){
      ll K=j+1, kmin=-1, kmax=-1, nsol=0;
      if (h==0){ if (v_sign<0){ kmin=kmax=A0+1; nsol=1; } }
      else {
        ll L = j - blk_start;            /* partial block [blk_start, j) */
        ll y = (v_sign<0) ? blk_x : L - blk_x;
        kmin = A0 + sum_min + y + 1; kmax = A0 + sum_max + y + 1; nsol = 1; /* nsol = 2^(h-1) */
      }
      if (kmin>0){
        ll ex = K - 2*(n+kmin);
        if (verbose) printf("K=%lld h=%lld #sol=2^%lld k_min=%lld k_max=%lld excess(k_min)=%lld\n",K,h,h>0?h-1:0,kmin,kmax,ex);
        if (ex>best_excess){best_excess=ex;bestK=K;}
      }
    }
    /* inclusion on the reference path at step j, and transition */
    ll w = 2*u-(j+1);
    if (u==0){                           /* centre: close previous block, open new; reference = exclude */
      if (h==0){ /* nothing */ } else { ll L=j-blk_start; ll x=blk_x; sum_min += (x<L-x?x:L-x); sum_max += (x>L-x?x:L-x); }
      h++; blk_start=j; blk_x=0; v_sign=+1;   /* exclude: v' = +(j+1) */
    } else {
      int inc = (v_sign>0);
      if (h==0) A0 += inc; else blk_x += inc;
      if (w<0) v_sign = -v_sign;
    }
    u = w<0?-w:w;
  }
  printf("n=%lld J=%lld: centres=%lld, max excess K-2(n+k_min) = %lld at K=%lld\n",n,J,h,best_excess,bestK);
  return 0;
}
