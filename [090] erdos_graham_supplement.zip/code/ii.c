/* Erdos #261(ii) check via tent rigidity: for each n in [N0,N1], find the least K such that n/2^n has a
   representation with largest term K and k>=2 terms.  u_{j+1}=|2u_j-(j+1)|, side sigma flips iff 2u_j<j+1;
   success at odd j with u_j=1 if (a centre occurred before j) or (sigma_j=-1). */
#include <stdio.h>
#include <stdlib.h>
typedef long long ll;
int main(int argc,char**argv){
  ll N0=atoll(argv[1]), N1=atoll(argv[2]), CAP=atoll(argv[3]);
  ll worstK=0, worstn=0, nfail=0; double sumT=0;
  for (ll n=N0;n<=N1;n++){
    ll u = n>=2 ? n-2 : 1; int sig = (n>=3)? +1 : -1; int centre = (n==2); ll j=n; ll K=-1;
    if (n==2) sig=0;
    for (; j-n < CAP; j++){
      if ((j&1) && u==1){
        if (centre || sig==-1){ if (!(n==1 && j==1)) { K=j+1; break; } }
      }
      ll w = 2*u-(j+1);
      if (u==0){ centre=1; sig=+1; } /* after a centre both sides exist; track one representative */
      else if (w<0) sig=-sig;
      u = w<0?-w:w;
    }
    if (K<0){ nfail++; printf("n=%lld: no solution with a_k <= n+%lld\n",n,CAP); continue; }
    sumT += (double)(K-n);
    if (K>worstK){worstK=K;worstn=n;}
  }
  printf("n in [%lld,%lld]: failures=%lld, max least a_k = %lld (n=%lld), mean (a_k-n)=%.1f\n",N0,N1,nfail,worstK,worstn,sumT/(double)(N1-N0+1-nfail));
  return 0;
}
