/* merge times of orbits u_{j+1}=|2u_j-(j+1)|, u_n=|n-2|, with the universal orbit U (n=3). */
#include <stdio.h>
#include <stdlib.h>
typedef long long ll;
int main(int argc,char**argv){
  ll N1=atoll(argv[1]); ll J=atoll(argv[2]);
  int *U = malloc(sizeof(int)*(J+2)); ll u=1; /* n=3: u_3=1 */
  for (ll j=0;j<3;j++) U[j]=-1;
  for (ll j=3;j<=J;j++){ U[j]=(int)u; ll w=2*u-(j+1); u=w<0?-w:w; }
  ll worst=0, worstn=0, nomerge=0; ll hist[64]={0};
  for (ll n=1;n<=N1;n++){
    ll v = n>=2? n-2 : 1; ll j=n; ll t=-1;
    for (; j<=J; j++){ if (v==U[j]){ t=j; break;} ll w=2*v-(j+1); v=w<0?-w:w; }
    if (t<0){ nomerge++; continue; }
    ll d=t-n; int b=0; while((1LL<<b)<=d) b++; hist[b]++;
    if (t>worst){worst=t;worstn=n;}
  }
  printf("n<=%lld: not merged by %lld: %lld; latest merge time %lld (n=%lld)\n",N1,J,nomerge,worst,worstn);
  for (int b=0;b<40;b++) if(hist[b]) printf("  merge delay in [2^%d,2^%d): %lld\n",b-1,b,hist[b]);
  return 0;
}
