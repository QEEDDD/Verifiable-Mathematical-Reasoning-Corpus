# Exhaustive check: every solution of n/2^n = sum a/2^a (k>=2) with a_k <= 392 ; list violations of a_k <= 2(n+k)
from eg import enumerate_solutions
import time
t=time.time()
KMAX = 392
viol = []; nsol = 0; maxstates = 0
for n in range(1, KMAX):
    sols = enumerate_solutions(n, KMAX)
    for K, ks in sols.items():
        for k, c in ks.items():
            if k < 2: continue
            nsol += c
            if K > 2*(n+k): viol.append((K, n, k, c))
viol.sort()
print("solutions with a_k <= %d (k>=2): %d" % (KMAX, nsol))
print("violating solutions (with multiplicity):", sum(v[3] for v in viol), "; distinct (n,k):", len(viol))
for v in viol: print("  a_k=%d n=%d k=%d (#such=%d) 2(n+k)=%d excess=%d" % (v[0], v[1], v[2], v[3], 2*(v[1]+v[2]), v[0]-2*(v[1]+v[2])))
print("time %.1fs" % (time.time()-t))
