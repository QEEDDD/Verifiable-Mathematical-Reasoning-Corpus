/* For n in [1,NMAX], enumerate ALL solutions with a_k <= KMAX (raw DP, explicit count vectors up to KC terms),
   report violations a_k > 2(n+k) with the smallest k, and the smallest a_k. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef long long ll; typedef unsigned long long ull;
#define KC 2600
#define SMAX 64
static ll rho[SMAX], rho2[SMAX]; static ull cnt[SMAX][KC+1], cnt2[SMAX][KC+1];
int main(int argc,char**argv){
  ll NMAX=atoll(argv[1]), KMAX=atoll(argv[2]);
  ll bestk=1<<30, bestk_n=-1, bestk_K=-1, nviol=0, maxS=0; ll bestK=1LL<<60;
  for (ll n=1;n<=NMAX;n++){
    int S=1; rho[0]=n; memset(cnt[0],0,sizeof(cnt[0])); cnt[0][0]=1;
    for (ll j=n; j<KMAX; j++){
      ll K=j+1; int S2=0;
      for (int s=0;s<S;s++) for (int inc=0;inc<2;inc++){
        ll v = inc ? 2*rho[s]-K : 2*rho[s];
        if (inc && v==0){
          for (int c=0;c<KC;c++) if (cnt[s][c]){ ll k=c+1; if (k>=2 && K>2*(n+k)){ nviol++;
              if (k<bestk || (k==bestk && K<bestk_K)){bestk=k;bestk_n=n;bestk_K=K;}
              if (K<bestK) bestK=K; } }
          continue;
        }
        if (v<=0 || v>j+2) continue;
        int q; for(q=0;q<S2;q++) if(rho2[q]==v) break;
        if(q==S2){ if(S2>=SMAX){fprintf(stderr,"states!\n");return 1;} rho2[S2]=v; memset(cnt2[S2],0,sizeof(cnt2[S2])); S2++; }
        if (inc){ for(int c=0;c+1<KC;c++) cnt2[q][c+1]+=cnt[s][c]; } else { for(int c=0;c<KC;c++) cnt2[q][c]+=cnt[s][c]; }
      }
      S=0; for(int q=0;q<S2;q++){ int nz=0; for(int c=0;c<KC;c++) if(cnt2[q][c]){nz=1;break;} if(!nz) continue; rho[S]=rho2[q]; memcpy(cnt[S],cnt2[q],sizeof(cnt[S])); S++; }
      if (S>maxS) maxS=S; if (S==0) break;
    }
  }
  printf("n<=%lld, a_k<=%lld, k<%d: violating (n,k) classes = %lld; least violating a_k = %lld; least k in a violation = %lld (n=%lld, a_k=%lld); max live states=%lld\n",
         NMAX,KMAX,KC,nviol,bestK,bestk,bestk_n,bestk_K,maxS);
  return 0;
}
