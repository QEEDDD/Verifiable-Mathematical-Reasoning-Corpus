/* least counterexample a_k in (lo, hi] over all n (fast block method) */
#include <stdio.h>
#include <stdlib.h>
typedef long long ll;
int main(int argc,char**argv){ ll lo=atoll(argv[1]), hi=atoll(argv[2]);
  ll best=1LL<<62, bn=-1, bk=-1, cnt=0;
  for (ll n=1; 2*n < hi; n++){
    ll u = n>=2? n-2:1; int s = n>=3?1:(n==1?-1:0);
    ll h=0,A0=0,smin=0,bstart=-1,bx=0;
    for (ll j=n;j<hi;j++){
      if ((j&1) && u==1 && !(n==1&&j==1)){
        ll K=j+1, kmin=-1;
        if (h==0){ if (s<0) kmin=A0+1; }
        else { ll L=j-bstart; ll y=(s<0)?bx:L-bx; kmin=A0+smin+y+1; }
        if (kmin>0 && K>lo && K>2*(n+kmin)){ cnt++; if (K<best || (K==best && n<bn)){best=K;bn=n;bk=kmin;} }
      }
      ll w=2*u-(j+1);
      if (u==0){ if(h>0){ ll L=j-bstart; smin += (bx<L-bx?bx:L-bx);} h++; bstart=j; bx=0; s=+1; }
      else { int inc=(s>0); if(h==0)A0+=inc; else bx+=inc; if(w<0)s=-s; }
      u=w<0?-w:w;
    }
  }
  printf("counterexamples (n, least-k solution) with %lld < a_k <= %lld: %lld; least a_k = %lld (n=%lld, k=%lld)\n",lo,hi,cnt,best,bn,bk);
  return 0; }
