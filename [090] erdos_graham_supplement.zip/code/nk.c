/* Exact enumeration of all solutions of  n/2^n = sum_{i=1}^k a_i/2^{a_i}  (n>=1, 2<=k<=KM, n<a_1<...<a_k)
   mode 0 (raw): plain DP over integer states rho_j, no structural theory used.
   mode 1 (hybrid): skip n unless the tent orbit u_{j+1}=|2u_j-(j+1)|, u_n=|n-2|, has u_{K-1}=1 for some K in range;
                    then run the same raw DP for that n.
   Cutoffs: n <= 2^{k+1}-k-2 (elementary), and gap lemma  K <= n + k(1+log2 K).
   Output: N(k), max a_k, and every solution (n, a_k, k, multiplicity). */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
typedef long long ll; typedef unsigned long long ull;
#define KMX 40
#define SMAX 64
int KM; int mode;
ull Ncount[KMX+2]; ll maxK[KMX+2]; ll minK[KMX+2];
ll maxstates = 0;
FILE *fo;
static ll rho[SMAX], rho2[SMAX]; static ull cnt[SMAX][KMX+2], cnt2[SMAX][KMX+2];
int beyond(ll n, ll K){ /* true if no solution with <=KM terms can have largest term >= K */
  if (K < 2*KM+4) return 0;
  return (double)K > (double)n + KM*(1.0+log2((double)K)) + 1e-9;
}
int orbit_has_window(ll n){
  ll u = n>2 ? n-2 : 2-n;
  for (ll j=n; ; j++){
    ll K=j+1; if (beyond(n,K)) return 0;
    if (u==1 && (j&1)) return 1;
    ll w = 2*u-(j+1); u = w<0?-w:w;
  }
}
void run_n(ll n){
  int S=1; rho[0]=n; memset(cnt[0],0,sizeof(cnt[0])); cnt[0][0]=1;
  for (ll j=n; ; j++){
    ll K=j+1; if (beyond(n,K)) break;
    int S2=0;
    for (int s=0;s<S;s++){
      for (int inc=0; inc<2; inc++){
        ll v = inc ? 2*rho[s]-K : 2*rho[s];
        if (inc && v==0){
          for (int c=0;c<KM;c++) if (cnt[s][c]){ int k=c+1; if (k>=2){ Ncount[k]+=cnt[s][c]; if (K>maxK[k]) maxK[k]=K; if (minK[k]==0||K<minK[k]) minK[k]=K;
                fprintf(fo,"%d %lld %lld %llu\n",k,n,K,cnt[s][c]); } }
          continue;
        }
        if (v<=0 || v> j+2) continue;
        int q; for (q=0;q<S2;q++) if (rho2[q]==v) break;
        if (q==S2){ if (S2>=SMAX){fprintf(stderr,"too many states\n"); exit(1);} rho2[S2]=v; memset(cnt2[S2],0,sizeof(cnt2[S2])); S2++; }
        if (inc){ for (int c=0;c+1<KM;c++) cnt2[q][c+1]+=cnt[s][c]; }
        else    { for (int c=0;c<KM;c++) cnt2[q][c]+=cnt[s][c]; }
      }
    }
    /* drop empty states */
    S=0;
    for (int q=0;q<S2;q++){ int nz=0; for(int c=0;c<KM;c++) if(cnt2[q][c]){nz=1;break;} if(!nz) continue;
      rho[S]=rho2[q]; memcpy(cnt[S],cnt2[q],sizeof(cnt[S])); S++; }
    if (S>maxstates) maxstates=S;
    if (S==0) break;
  }
}
int main(int argc,char**argv){
  KM=atoi(argv[1]); mode=atoi(argv[2]); fo=fopen(argv[3],"w");
  ll nmax = (1LL<<(KM+1)) - 2 - 2; /* n <= 2^{k+1}-k-2 <= 2^{KM+1}-4 (k>=2) */
  ll nrun=0;
  for (ll n=1;n<=nmax;n++){
    if (mode==1 && !orbit_has_window(n)) continue;
    nrun++; run_n(n);
  }
  fclose(fo);
  printf("KM=%d mode=%d  n<=%lld  n_runs=%lld  max live states=%lld\n",KM,mode,nmax,nrun,maxstates);
  for (int k=2;k<=KM;k++) printf("k=%2d N=%llu  min a_k=%lld  max a_k=%lld  2^(k+1)-2=%lld\n",k,Ncount[k],minK[k],maxK[k],(1LL<<(k+1))-2);
  return 0;
}
