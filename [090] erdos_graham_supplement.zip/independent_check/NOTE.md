# Independent checks (separate referee implementation)

These programs were written independently of the authors' code (see `../code`) and do **not** use the tent-rigidity theory of Section 3. They reproduce:

- `check_Astar.py`: the identity sum_{a in A*} a/2^a = 3/8 and the violation 392 > 376.
- `statedp.c`: generic state DP (any number of states; prunes only states that cannot reach 0); Theorem 4.1(b),(c) and Table 2.
- `nk3.c`: exhaustive DP for N(k), k <= 28 (Table 3). The run was split into n <= 2^28 (`nk3_k28_output_part_a.txt`) and 2^28 < n <= 2^29 - 30 (`nk3_k28_output_part_b.txt`); the per-k counts add up to Table 3.
- `fvbig.c`: Theorem 4.1(e) without the tent theory: a least-count DP for each n up to a common time T, then one DP from the union of all states at time T. Summary: every n <= 16513 has a counterexample; n = 16514 has none with a_k <= 2*10^9 (`fvbig_summary_n20000.txt`).
- `brute_k4.py`: brute force over subsets for k <= 4 (Theorem 5.1, small k).
