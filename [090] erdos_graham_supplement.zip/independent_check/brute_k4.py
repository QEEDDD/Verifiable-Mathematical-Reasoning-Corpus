#!/usr/bin/env python3
"""Brute force: all solutions with 2<=k<=4 terms, n<=26, all a_i in (n,50] (exact integers)."""
from itertools import combinations
sols = []
for n in range(1, 27):
    target = n * 2 ** (50 - n)          # n/2^n scaled by 2^50
    for k in range(2, 5):
        for A in combinations(range(n + 1, 51), k):
            if sum(a * 2 ** (50 - a) for a in A) == target:
                sols.append((n,) + A)
print(len(sols), sols)
print("done")
