#!/usr/bin/env python3
"""Referee check A: verify the explicit counterexample A* from the paper.

Reads the .tex file only as text (data), extracts the explicit list and the
run notation, and checks everything with exact integer / Fraction arithmetic.
"""
import re, sys
from fractions import Fraction

tex_path = sys.argv[1]
lines = open(tex_path, encoding="utf-8").read().split("\n")

# locate the explicit list: the line after "\small\raggedright" in Section 4
idx = next(i for i, l in enumerate(lines) if "Let $A^*$ be the set consisting" in l)
list_line = None
for l in lines[idx:idx + 6]:
    if re.match(r"^\s*4, 6, 9", l):
        list_line = l
        break
assert list_line is not None
A = [int(t) for t in re.findall(r"\d+", list_line)]
print("explicit list: count =", len(A), " distinct =", len(set(A)),
      " strictly increasing =", all(A[i] < A[i + 1] for i in range(len(A) - 1)))
print("min =", min(A), " max =", max(A))

# run notation
run_line = next(l for l in lines if l.startswith("$4$, $6$, $9$--$10$"))
runs = re.findall(r"\$(\d+)\$(?:--\$(\d+)\$)?", run_line)
R = []
for a, b in runs:
    a = int(a); b = int(b) if b else a
    R.extend(range(a, b + 1))
print("run notation: #runs =", len(runs), " #elements =", len(R),
      " equals explicit list:", R == A)
# check maximality of runs (consecutive runs separated by a gap >= 2)
ends = []
for a, b in runs:
    a = int(a); b = int(b) if b else a
    ends.append((a, b))
maximal = all(ends[i + 1][0] >= ends[i][1] + 2 for i in range(len(ends) - 1))
print("runs maximal:", maximal)
# independent count of maximal runs from the explicit list
nr = 1 + sum(1 for i in range(len(A) - 1) if A[i + 1] != A[i] + 1)
print("maximal runs counted from explicit list:", nr)

# exact sum with Fractions
S = sum(Fraction(a, 2 ** a) for a in A)
print("sum a/2^a =", S, " == 3/8:", S == Fraction(3, 8))
# integer identity 3*2^389 = sum a*2^(392-a)
lhs = 3 * 2 ** 389
rhs = sum(a * 2 ** (392 - a) for a in A)
print("integer identity 3*2^389 == sum a*2^(392-a):", lhs == rhs)
k, n, K = len(A), 3, max(A)
print("all elements > n=3:", all(a > 3 for a in A))
print("k =", k, " 2(k+n) =", 2 * (k + n), " a_k =", K, " violation a_k>2(k+n):", K > 2 * (k + n),
      " excess =", K - 2 * (k + n))

# state recurrence check rho_{j+1} = 2 rho_j - (j+1)[j+1 in A], from rho_3 = 3
Aset = set(A)
rho = 3
ok = True
offs = []
for j in range(3, 392):
    if not (1 <= rho <= j + 1):
        ok = False
        print("state not live at j =", j, rho)
    offs.append(2 * rho - (j + 2))
    rho = 2 * rho - (j + 1) * (1 if (j + 1) in Aset else 0)
print("all states live for 3<=j<392:", ok, " final rho_392 =", rho)
