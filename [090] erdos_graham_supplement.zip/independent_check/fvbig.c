/* Referee code: first counterexample (K > 2(n+kmin)) for every n <= NMAX, up to KMAX,
 * WITHOUT using the tent theory:
 *  phase 1: for each n, generic min-count state DP from time n to time T
 *           (records violations with K <= T, and the live states at time T with
 *            their min number of inclusions so far);
 *  phase 2: one multi-label DP from time T to KMAX started from the union U of all
 *           states seen at time T: for each state carries, per label (start state at
 *           T), the min number of further inclusions; at each termination time K
 *           this gives G(label,K) = min #inclusions on (T,K] of a path from label.
 *  phase 3: for each n, kmin(K) = min_label m_n(label) + G(label,K).
 * usage: fvbig NMAX T KMAX
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#define MAXS 64
#define MAXL 64
#define INF  (INT64_MAX / 4)
typedef struct { int64_t rho, cmin; } St;

typedef struct { int ns; int64_t rho[8]; int64_t m[8]; int64_t fv; int64_t fvk; } NInfo;

int main(int argc, char **argv) {
    int64_t NMAX = atoll(argv[1]), T = atoll(argv[2]), KMAX = atoll(argv[3]);
    NInfo *info = calloc(NMAX + 1, sizeof(NInfo));
    int64_t U[MAXL]; int nU = 0;
    int maxst = 0;
    St A[MAXS], B[MAXS];
    /* phase 1 */
    for (int64_t n = 1; n <= NMAX; n++) {
        St *cur = A, *nxt = B; int ns = 1; cur[0].rho = n; cur[0].cmin = 0;
        info[n].fv = 0;
        for (int64_t j = n; j < T && ns; j++) {
            int64_t K = j + 1; int nn = 0;
            for (int i = 0; i < ns; i++) {
                int64_t rho = cur[i].rho, r1 = 2 * rho - K, r0 = 2 * rho;
                if (r1 == 0) {
                    int64_t k = cur[i].cmin + 1;
                    if (!(n == 1 && K == 2) && !info[n].fv && K > 2 * (n + k)) { info[n].fv = K; info[n].fvk = k; }
                }
                int64_t s[2]; int64_t c[2]; int m = 0;
                if (r1 > 0 && r1 < K + 2) { s[m] = r1; c[m] = cur[i].cmin + 1; m++; }
                if (r0 > 0 && r0 < K + 2) { s[m] = r0; c[m] = cur[i].cmin; m++; }
                for (int q = 0; q < m; q++) {
                    int f = -1; for (int z = 0; z < nn; z++) if (nxt[z].rho == s[q]) { f = z; break; }
                    if (f < 0) { if (nn >= MAXS) { fprintf(stderr, "states\n"); return 1; } nxt[nn].rho = s[q]; nxt[nn].cmin = c[q]; nn++; }
                    else if (c[q] < nxt[f].cmin) nxt[f].cmin = c[q];
                }
            }
            if (nn > maxst) maxst = nn;
            St *t = cur; cur = nxt; nxt = t; ns = nn;
        }
        if (ns > 8) { fprintf(stderr, "more than 8 states at T for n=%lld\n", (long long)n); return 1; }
        info[n].ns = ns;
        for (int i = 0; i < ns; i++) {
            info[n].rho[i] = cur[i].rho; info[n].m[i] = cur[i].cmin;
            int f = -1; for (int z = 0; z < nU; z++) if (U[z] == cur[i].rho) { f = z; break; }
            if (f < 0) { if (nU >= MAXL) { fprintf(stderr, "labels\n"); return 1; } U[nU++] = cur[i].rho; }
        }
    }
    printf("phase1 done: max #states %d; union of states at T=%lld has %d elements:", maxst, (long long)T, nU);
    for (int z = 0; z < nU; z++) printf(" %lld", (long long)U[z]);
    printf("\n"); fflush(stdout);
    /* phase 2: multi-label DP */
    typedef struct { int64_t rho; int64_t g[MAXL]; } LSt;
    LSt *L1 = malloc(sizeof(LSt) * MAXS), *L2 = malloc(sizeof(LSt) * MAXS);
    int ns = nU;
    for (int z = 0; z < nU; z++) { L1[z].rho = U[z]; for (int l = 0; l < nU; l++) L1[z].g[l] = (l == z) ? 0 : INF; }
    int64_t *termK = malloc(sizeof(int64_t) * 1000); int64_t (*termG)[MAXL] = malloc(sizeof(int64_t) * MAXL * 1000); int nterm = 0;
    LSt *cur = L1, *nxt = L2;
    int maxst2 = 0;
    for (int64_t j = T; j < KMAX && ns; j++) {
        int64_t K = j + 1; int nn = 0;
        for (int i = 0; i < ns; i++) {
            int64_t rho = cur[i].rho, r1 = 2 * rho - K, r0 = 2 * rho;
            if (r1 == 0) {
                if (nterm >= 1000) { fprintf(stderr, "term\n"); return 1; }
                termK[nterm] = K;
                for (int l = 0; l < nU; l++) termG[nterm][l] = cur[i].g[l] >= INF ? INF : cur[i].g[l] + 1;
                nterm++;
            }
            int64_t s[2]; int inc[2]; int m = 0;
            if (r1 > 0 && r1 < K + 2) { s[m] = r1; inc[m] = 1; m++; }
            if (r0 > 0 && r0 < K + 2) { s[m] = r0; inc[m] = 0; m++; }
            for (int q = 0; q < m; q++) {
                int f = -1; for (int z = 0; z < nn; z++) if (nxt[z].rho == s[q]) { f = z; break; }
                if (f < 0) { if (nn >= MAXS) { fprintf(stderr, "states2\n"); return 1; }
                    f = nn++; nxt[f].rho = s[q]; for (int l = 0; l < nU; l++) nxt[f].g[l] = INF; }
                for (int l = 0; l < nU; l++) if (cur[i].g[l] < INF) {
                    int64_t v = cur[i].g[l] + inc[q]; if (v < nxt[f].g[l]) nxt[f].g[l] = v; }
            }
        }
        if (nn > maxst2) maxst2 = nn;
        LSt *t = cur; cur = nxt; nxt = t; ns = nn;
    }
    printf("phase2 done: %d termination times in (T,KMAX], max #states %d\n", nterm, maxst2);
    for (int e = 0; e < nterm; e++) {
        printf("  K=%lld G=", (long long)termK[e]);
        for (int l = 0; l < nU; l++) { if (termG[e][l] >= INF) printf(" inf"); else printf(" %lld", (long long)termG[e][l]); }
        printf("\n");
    }
    /* phase 3 */
    int64_t worst = 0, worstn = 0; long none = 0; int64_t firstnone = 0;
    long histo[1000]; memset(histo, 0, sizeof histo);
    FILE *fo = fopen("fvbig_out.txt", "w");
    for (int64_t n = 1; n <= NMAX; n++) {
        int64_t fv = info[n].fv, fk = info[n].fvk;
        if (!fv) {
            for (int e = 0; e < nterm && !fv; e++) {
                int64_t best = INF;
                for (int i = 0; i < info[n].ns; i++) {
                    int l = -1; for (int z = 0; z < nU; z++) if (U[z] == info[n].rho[i]) { l = z; break; }
                    if (termG[e][l] < INF) { int64_t v = info[n].m[i] + termG[e][l]; if (v < best) best = v; }
                }
                if (best < INF && termK[e] > 2 * (n + best)) { fv = termK[e]; fk = best; }
            }
        }
        fprintf(fo, "%lld %lld %lld\n", (long long)n, (long long)fv, (long long)fk);
        if (!fv) { none++; if (!firstnone) firstnone = n; }
        else if (fv > worst) { worst = fv; worstn = n; }
    }
    fclose(fo);
    printf("SUMMARY n<=%lld: n without counterexample with K<=%lld: %ld (first such n: %lld); largest first-violation K = %lld at n=%lld\n",
           (long long)NMAX, (long long)KMAX, none, (long long)firstnone, (long long)worst, (long long)worstn);
    return 0;
}
