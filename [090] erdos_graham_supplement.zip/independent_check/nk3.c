/* Referee code, faster variant of nk.c (same exhaustive DP), with:
 *  - count vectors tracked only on their nonzero window [lo,hi]
 *  - pruning: a live state rho at time j needs at least r further terms where
 *    r = min{ r : sum_{i=1}^r (j+i) 2^{-i} >= rho }  (f decreasing; elementary);
 *    a count c is dropped if c + r > KT.
 *  - K bound from the gap lemma, as in nk.c.
 * usage: nk2 KT n1 n2     (n2 = 0 -> 2^{KT+1}-KT-2)
 * prints per-k counts and min/max K for solutions with n in [n1,n2]; also prints
 * every solution with k >= 2 as "SOL k n K mult" if env LIST is set.
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#define MAXK 40
#define MAXS 64
typedef struct { int64_t rho; int lo, hi; uint64_t cnt[MAXK + 2]; } St;
static St SA[MAXS], SB[MAXS];
static int maxst = 0;
static int flog2(int64_t x) { int r = -1; while (x) { x >>= 1; r++; } return r; }

/* least r>=1 such that (j+r+2) <= 2^r (j+2-rho), i.e. S_r(j) >= rho ; capped at cap */
static inline int rmin(int64_t rho, int64_t j, int cap) {
    int64_t d = j + 2 - rho;          /* >= 1 for live states */
    for (int r = 1; r <= cap; r++) {
        if (r < 62 && (j + r + 2) <= (d << r)) return r;
    }
    return cap + 1;
}

int main(int argc, char **argv) {
    int KT = atoi(argv[1]);
    int64_t n1 = atoll(argv[2]), n2 = atoll(argv[3]);
    if (n2 == 0) n2 = (1LL << (KT + 1)) - KT - 2;
    int list = getenv("LIST") != NULL;
    uint64_t N[MAXK + 2]; int64_t minK[MAXK + 2], maxK[MAXK + 2];
    memset(N, 0, sizeof N);
    for (int k = 0; k <= MAXK + 1; k++) { minK[k] = INT64_MAX; maxK[k] = 0; }
    for (int64_t n = n1; n <= n2; n++) {
        /* KM = max K with K <= n + KT*(1+floor(log2 K)): for each L, K in [2^L, 2^{L+1}-1] */
        int64_t KM = n + 1;
        for (int L = 1; L < 62; L++) {
            int64_t lo = 1LL << L, hi = (1LL << (L + 1)) - 1;
            int64_t b = n + (int64_t)KT * (1 + L);
            int64_t cand = b < hi ? b : hi;
            if (cand >= lo && cand > KM) KM = cand;
        }
        (void)flog2;
        St *cur = SA, *nxt = SB; int ns = 1;
        cur[0].rho = n; cur[0].lo = 0; cur[0].hi = 0; cur[0].cnt[0] = 1;
        for (int64_t j = n; j < KM && ns; j++) {
            int64_t K = j + 1; int nn = 0;
            for (int i = 0; i < ns; i++) {
                St *s0 = &cur[i];
                int64_t rho = s0->rho;
                int64_t r1 = 2 * rho - K;
                if (r1 == 0) {
                    for (int c = s0->lo; c <= s0->hi; c++) if (s0->cnt[c]) {
                        int k = c + 1;
                        if (k < 2 || k > KT) continue;
                        N[k] += s0->cnt[c];
                        if (K < minK[k]) minK[k] = K;
                        if (K > maxK[k]) maxK[k] = K;
                        if (list) printf("SOL %d %lld %lld %llu\n", k, (long long)n, (long long)K,
                                         (unsigned long long)s0->cnt[c]);
                    }
                }
                int64_t succ[2]; int inc[2]; int m = 0;
                if (r1 > 0 && r1 < K + 2) { succ[m] = r1; inc[m] = 1; m++; }
                int64_t r0 = 2 * rho;
                if (r0 > 0 && r0 < K + 2) { succ[m] = r0; inc[m] = 0; m++; }
                for (int s = 0; s < m; s++) {
                    /* counts after the move: c+inc ; need c+inc + rmin(succ, K) <= KT */
                    int need = rmin(succ[s], K, KT + 1);
                    int maxc = KT - need;           /* allowed count after move */
                    int lo = s0->lo + inc[s], hi = s0->hi + inc[s];
                    if (hi > maxc) hi = maxc;
                    if (lo > hi) continue;
                    int idx = -1;
                    for (int q = 0; q < nn; q++) if (nxt[q].rho == succ[s]) { idx = q; break; }
                    if (idx < 0) {
                        if (nn >= MAXS) { fprintf(stderr, "too many states\n"); return 1; }
                        idx = nn++; nxt[idx].rho = succ[s]; nxt[idx].lo = lo; nxt[idx].hi = hi;
                        for (int c = lo; c <= hi; c++) nxt[idx].cnt[c] = 0;
                    } else {
                        St *t = &nxt[idx];
                        if (lo < t->lo) { for (int c = lo; c < t->lo; c++) t->cnt[c] = 0; t->lo = lo; }
                        if (hi > t->hi) { for (int c = t->hi + 1; c <= hi; c++) t->cnt[c] = 0; t->hi = hi; }
                    }
                    for (int c = lo; c <= hi; c++) nxt[idx].cnt[c] += s0->cnt[c - inc[s]];
                }
            }
            /* drop empty states */
            int w = 0;
            for (int q = 0; q < nn; q++) {
                int any = 0; for (int c = nxt[q].lo; c <= nxt[q].hi; c++) if (nxt[q].cnt[c]) { any = 1; break; }
                if (any) { if (w != q) nxt[w] = nxt[q]; w++; }
            }
            nn = w;
            if (nn > maxst) maxst = nn;
            St *t = cur; cur = nxt; nxt = t; ns = nn;
        }
    }
    for (int k = 2; k <= KT; k++)
        printf("k=%d N=%llu minK=%lld maxK=%lld\n", k, (unsigned long long)N[k],
               (long long)(minK[k] == INT64_MAX ? -1 : minK[k]), (long long)maxK[k]);
    printf("max #states = %d (n in [%lld,%lld])\n", maxst, (long long)n1, (long long)n2);
    return 0;
}
