/* Referee code: generic state DP for n/2^n = sum a/2^a, a > n.
 * No use of the tent theory: keeps an arbitrary set of integer states rho at
 * time j (0 < rho < j+2), with for each state: min and max number of
 * inclusions so far, and number of paths (uint64, overflow-checked).
 * Prunes only states that can never reach 0 by a finite set (rho > j+2,
 * rho == j+2, rho < 0).
 *
 * Modes:
 *   scan  n1 n2 KMAX        : for every n in [n1,n2], all K<=KMAX: report
 *                             violations K > 2(n+kmin), totals, max #states
 *   single n KMAX           : list all K<=KMAX with solutions (K, #sol, kmin, kmax)
 *   firstviol n1 n2 KMAX    : for each n, first K<=KMAX with a violation
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

typedef struct { int64_t rho, cmin, cmax; uint64_t np; } St;
#define MAXS 4096
static St SA[MAXS], SB[MAXS];
static int maxstates_global = 0;

static inline int addst(St *S, int ns, int64_t rho, int64_t cmin, int64_t cmax, uint64_t np) {
    for (int i = 0; i < ns; i++) if (S[i].rho == rho) {
        if (cmin < S[i].cmin) S[i].cmin = cmin;
        if (cmax > S[i].cmax) S[i].cmax = cmax;
        if (S[i].np + np < S[i].np) { fprintf(stderr, "path count overflow\n"); exit(2); }
        S[i].np += np; return ns;
    }
    if (ns >= MAXS) { fprintf(stderr, "too many states\n"); exit(1); }
    S[ns].rho = rho; S[ns].cmin = cmin; S[ns].cmax = cmax; S[ns].np = np;
    return ns + 1;
}

/* callback type: return nonzero to stop */
typedef int (*solcb)(int64_t n, int64_t K, int64_t kmin, int64_t kmax, uint64_t np, void *ctx);

static void run(int64_t n, int64_t KMAX, solcb cb, void *ctx) {
    St *cur = SA, *nxt = SB;
    int ns = 0;
    ns = addst(cur, ns, n, 0, 0, 1);
    for (int64_t j = n; j < KMAX; j++) {
        int nn = 0;
        int64_t K = j + 1;
        /* termination candidates at K (merge, in case several states terminate) */
        int term = 0; int64_t tmin = 0, tmax = 0; uint64_t tnp = 0;
        for (int i = 0; i < ns; i++) {
            int64_t rho = cur[i].rho;
            int64_t r1 = 2 * rho - K;   /* include K */
            if (r1 == 0) {
                if (!term) { term = 1; tmin = cur[i].cmin + 1; tmax = cur[i].cmax + 1; tnp = cur[i].np; }
                else { if (cur[i].cmin + 1 < tmin) tmin = cur[i].cmin + 1;
                       if (cur[i].cmax + 1 > tmax) tmax = cur[i].cmax + 1; tnp += cur[i].np; }
            } else if (r1 > 0 && r1 < K + 2) {
                nn = addst(nxt, nn, r1, cur[i].cmin + 1, cur[i].cmax + 1, cur[i].np);
            }
            int64_t r0 = 2 * rho;      /* exclude K */
            if (r0 > 0 && r0 < K + 2) nn = addst(nxt, nn, r0, cur[i].cmin, cur[i].cmax, cur[i].np);
        }
        if (term) {
            if (cb(n, K, tmin, tmax, tnp, ctx)) return;
        }
        if (nn > maxstates_global) maxstates_global = nn;
        St *t = cur; cur = nxt; nxt = t; ns = nn;
        if (ns == 0) return;
    }
}

/* ---------- mode scan ---------- */
typedef struct { uint64_t total392; long nviolNK; int64_t KMAXr; long viol12230; int64_t minviolK_gt392;
                 int64_t mink_viol; } ScanCtx;
static int cb_scan(int64_t n, int64_t K, int64_t kmin, int64_t kmax, uint64_t np, void *vctx) {
    ScanCtx *c = (ScanCtx *)vctx;
    if (n == 1 && K == 2) return 0;               /* k=1, excluded */
    if (K <= 392) c->total392 += np;
    if (K > 2 * (n + kmin)) {
        c->nviolNK++;
        printf("VIOL n=%lld K=%lld kmin=%lld kmax=%lld nsol=%llu excess=%lld\n",
               (long long)n, (long long)K, (long long)kmin, (long long)kmax,
               (unsigned long long)np, (long long)(K - 2 * (n + kmin)));
        if (K == 12230) c->viol12230++;
        if (K > 392 && (c->minviolK_gt392 == 0 || K < c->minviolK_gt392)) c->minviolK_gt392 = K;
        if (c->mink_viol == 0 || kmin < c->mink_viol) c->mink_viol = kmin;
    }
    return 0;
}

/* ---------- mode single ---------- */
static int cb_single(int64_t n, int64_t K, int64_t kmin, int64_t kmax, uint64_t np, void *vctx) {
    (void)vctx;
    printf("K=%lld nsol=%llu kmin=%lld kmax=%lld excess(kmin)=%lld\n", (long long)K,
           (unsigned long long)np, (long long)kmin, (long long)kmax, (long long)(K - 2 * (n + kmin)));
    fflush(stdout);
    return 0;
}

/* ---------- mode firstviol ---------- */
typedef struct { int64_t found; } FVCtx;
static int cb_fv(int64_t n, int64_t K, int64_t kmin, int64_t kmax, uint64_t np, void *vctx) {
    FVCtx *c = (FVCtx *)vctx; (void)kmax; (void)np;
    if (n == 1 && K == 2) return 0;
    if (K > 2 * (n + kmin)) { c->found = K; return 1; }
    return 0;
}

int main(int argc, char **argv) {
    if (argc < 2) { fprintf(stderr, "usage\n"); return 1; }
    if (!strcmp(argv[1], "scan")) {
        int64_t n1 = atoll(argv[2]), n2 = atoll(argv[3]), KMAX = atoll(argv[4]);
        ScanCtx c; memset(&c, 0, sizeof c);
        for (int64_t n = n1; n <= n2; n++) run(n, KMAX, cb_scan, &c);
        printf("SUMMARY n in [%lld,%lld], K<=%lld: total solutions with K<=392: %llu; violating (n,K) pairs: %ld;"
               " n with violation at K=12230: %ld; least violating K>392: %lld; least kmin among violations: %lld;"
               " max #states: %d\n",
               (long long)n1, (long long)n2, (long long)KMAX, (unsigned long long)c.total392, c.nviolNK,
               c.viol12230, (long long)c.minviolK_gt392, (long long)c.mink_viol, maxstates_global);
    } else if (!strcmp(argv[1], "single")) {
        int64_t n = atoll(argv[2]), KMAX = atoll(argv[3]);
        run(n, KMAX, cb_single, NULL);
        printf("max #states: %d\n", maxstates_global);
    } else if (!strcmp(argv[1], "firstviol")) {
        int64_t n1 = atoll(argv[2]), n2 = atoll(argv[3]), KMAX = atoll(argv[4]);
        int64_t worst = 0, worstn = 0; long notfound = 0;
        for (int64_t n = n1; n <= n2; n++) {
            FVCtx c = {0};
            run(n, KMAX, cb_fv, &c);
            if (!c.found) { notfound++; printf("no violation with K<=%lld for n=%lld\n", (long long)KMAX, (long long)n); }
            else if (c.found > worst) { worst = c.found; worstn = n; }
        }
        printf("SUMMARY firstviol n in [%lld,%lld]: not found: %ld; largest first-violation K = %lld (n=%lld); max #states %d\n",
               (long long)n1, (long long)n2, notfound, (long long)worst, (long long)worstn, maxstates_global);
    }
    return 0;
}
