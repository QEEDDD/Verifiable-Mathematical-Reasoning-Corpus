# Supplement to "Symmetric insertion and 2-adic completions for permutations of Z" (Keio, 2026)

These programs corroborate Remarks 3.5 and 4.3 and the computations of Section 6. The proofs in the paper do not depend on them.
Python programs need Python 3; the SAT programs also need `python-sat` (`pip install python-sat`). C programs: `gcc -O2 -o prog prog.c`.
Run everything from inside `code/` (or `code/independent/`).

## Theorem 3.4 and Remarks 3.5, 4.3

| file | purpose | how to run | expected output |
|---|---|---|---|
| `build.py` | builds the permutation of Theorem 3.4 (even targets 0,2,-2,4,...; odd targets 1,-1,3,-3,...) | `python3 build.py 200` | `40002 max|v|= 40001`, writes `seq_200.txt` |
| `check.c` | brute force over all pairs of positions: in-order (odd,even,odd) 3-APs, monotone 4-APs of odd difference, counts of even-difference monotone APs | `./check seq_200.txt` | `(odd,even,odd) 3-APs=0 ; monotone odd-diff 4-APs=0 ; (even-diff monotone 3-APs=261436991, 4-APs=154981918)`, `covers [-199,199] fully` |
| `count3.c` | in-order 3-APs by type | `./count3 seq_200.txt` | `even diff=261436991 ; odd diff (even,odd,even)=650 ; odd diff (odd,even,odd)=0` (total 261,437,641) |
| `length_check.py` | Remark 3.5: after step n the odd integers present form all odd integers of an interval symmetric about y_n, and the word has n^2+2 terms | `python3 length_check.py` | `checked n<= 300 ok True` |
| `sigma1.py` | Remark 4.3: rerun the construction with even targets y_j = 2*tau_j (tau = the sequence of Theorem 3.4); checks root protection of all even terms and protection of all multiples of 4 for the node 2Z, then counts monotone 4-APs by (v2(d), parity class) | `python3 sigma1.py 40 40` | `len 522 bad_root 0 bad_level1_in_evens 0`; no 4-APs with v2(d)=0, none with v2(d)=1 inside the even integers |

## Section 6: safe words

| file | purpose |
|---|---|
| `safesat.py` | SAT encoding: is there a word over a window [lo,hi], containing a target set and starting with a given prefix, that is safe for SOME tree order (the preferences are unknowns; integers outside the window are in the tail)? `--nat` counts only progressions inside N0 |
| `ho.py`, `ho_print.py` | our implementation of Ho's recursion for N0 (Ho, arXiv:2609.12780, Algorithm 1) |
| `independent/` | a second, independently written SAT encoding (`sat_ext.py`, `safety.py`, `run_sec6_sat.py`) and `sec6.py`, which checks the 17-term word |

Runs:

- `python3 safesat.py -40 40 -8:8` gives SAT (safe words exist for every n; in our run the solver returned `7,-1,3,-5,5,-3,1,-7,6,-2,2,-6,4,-4,0,8,-8`).
- `python3 independent/sec6.py` (from `code/independent/`: `python3 sec6.py`) confirms that this word is the decreasing listing of [-8,8] for the tree order preferring digit 0 at levels 0-2 and digit 1 at levels 3-4, that it is safe for that order, and that it is not the reverse listing for Ho's order.
- `python3 safesat.py -64 64 -9:9 --prefix 7,-1,3,-5,5,-3,1,-7,6,-2,2,-6,4,-4,0,8,-8` gives UNSAT: no safe extension covers [-9,9] inside [-64,64].
- `python3 safesat.py 0 40 0:7,9,11,15 --nat --prefix 0,1,3,2,11,7,15,9,5,6,4 --maxlen 11` gives SAT (sanity check: Ho's word is recognised as safe).
- `python3 safesat.py 0 96 0:8 --nat --prefix 0,1,3,2,11,7,15,9,5,6,4` gives UNSAT.
- `python3 ho_print.py 9` shows that the next step of Ho's recursion (adding 8) gives a word of 354 terms with largest entry 2623 (`t=8 len=354 max=2623`), so a bounded window cannot decide extendability.
- In `code/independent/`: `python3 run_sec6_sat.py N 96 0,1,2,3,4,5,6,7,8` and `python3 run_sec6_sat.py Z -64 64 -9,-8,...,9` give UNSAT (the two UNSAT results above, with the second encoding).
