"""Symmetric-insertion permutation of Z (odd differences).
Even targets 0,2,-2,4,-4,...; odd targets 1,-1,3,-3,...
Step j: append next odd target (if new); then, before the next even target y, append (2y - O) minus O
(O = odds already placed, in increasing order of value), then append y."""
import sys
def build(nsteps):
    seq=[]; placed=set(); odds=[]
    def app(v):
        seq.append(v); placed.add(v)
        if v%2: odds.append(v)
    evens=[0]; odds_t=[]
    k=1
    while len(evens)<nsteps:
        evens+= [2*k,-2*k]; k+=1
    j=0; kk=0
    oddt=[]
    for i in range(nsteps):
        t = (2*(i//2)+1)*(1 if i%2==0 else -1)   # 1,-1,3,-3,...
        if t not in placed: app(t)
        y=evens[i]
        if y in placed: continue
        refl=sorted(set(2*y-o for o in odds)-placed)
        for r in refl: app(r)
        app(y)
    return seq
if __name__=='__main__':
    n=int(sys.argv[1]); s=build(n)
    print(len(s), "max|v|=",max(abs(v) for v in s))
    with open(f"seq_{n}.txt","w") as f: f.write(" ".join(map(str,s))+"\n")
