// read sequence; check (i) no monotone 3-AP of type (odd,even,odd) [positions increasing along AP],
// (ii) no monotone 4-AP with odd difference; (iii) report counts of monotone 3/4-APs with even difference (expected to exist)
#include <stdio.h>
#include <stdlib.h>
int main(int argc,char**argv){
  FILE*f=fopen(argv[1],"r"); static long a[2000000]; int n=0; while(fscanf(f,"%ld",&a[n])==1) n++;
  long mn=a[0],mx=a[0]; for(int i=0;i<n;i++){ if(a[i]<mn)mn=a[i]; if(a[i]>mx)mx=a[i]; }
  long off=-mn; long W=mx-mn+1; int *pos=malloc(sizeof(int)*W); for(long i=0;i<W;i++) pos[i]=-1;
  for(int i=0;i<n;i++) pos[a[i]+off]=i;
  long bad3=0,bad4=0,ev3=0,ev4=0;
  for(int i=0;i<n;i++) for(int j=i+1;j<n;j++){ long x=a[i], y=a[j], d=y-x; long z=y+d; if(z<mn||z>mx) continue; int pz=pos[z+off]; if(pz<0||pz<j) continue;
      // (x,y,z) in-order 3-AP
      if(d%2!=0){ if(x%2!=0) bad3++; }
      else ev3++;
      long w=z+d; if(w<mn||w>mx) continue; int pw=pos[w+off]; if(pw<0||pw<pz) continue;
      if(d%2!=0) bad4++; else ev4++; }
  printf("n=%d values in [%ld,%ld]: in-order (odd,even,odd) 3-APs=%ld ; monotone odd-diff 4-APs=%ld ; (even-diff monotone 3-APs=%ld, 4-APs=%ld)\n",n,mn,mx,bad3,bad4,ev3,ev4);
  // also check: is the prefix covering [-k,k]?
  long k=0; while(-k-1>=mn && k+1<=mx && pos[-k-1+off]>=0 && pos[k+1+off]>=0) k++;
  printf("covers [-%ld,%ld] fully\n",k,k);
}
