#include <stdio.h>
#include <stdlib.h>
int main(int argc,char**argv){
  FILE*f=fopen(argv[1],"r"); static long a[2000000]; int n=0; while(fscanf(f,"%ld",&a[n])==1) n++;
  long mn=a[0],mx=a[0]; for(int i=0;i<n;i++){ if(a[i]<mn)mn=a[i]; if(a[i]>mx)mx=a[i]; }
  long off=-mn, W=mx-mn+1; int *pos=malloc(sizeof(int)*W); for(long i=0;i<W;i++) pos[i]=-1;
  for(int i=0;i<n;i++) pos[a[i]+off]=i;
  long odd3_eom=0, odd3_oeo=0, ev3=0;
  for(int i=0;i<n;i++) for(int j=i+1;j<n;j++){ long x=a[i],y=a[j],d=y-x,z=y+d; if(z<mn||z>mx) continue; int pz=pos[z+off]; if(pz<0||pz<j) continue;
     if(d%2!=0){ if(x%2==0) odd3_eom++; else odd3_oeo++; } else ev3++; }
  printf("in-order 3-APs: even diff=%ld ; odd diff (even,odd,even)=%ld ; odd diff (odd,even,odd)=%ld\n",ev3,odd3_eom,odd3_oeo);
}
