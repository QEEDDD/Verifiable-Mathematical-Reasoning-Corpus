# Ho's construction on N_0 and a safety checker for words under the completion order (P then rest in "lhd" order)
import sys
sys.setrecursionlimit(100000)
def lhd(m,n):
    # m ◁ n : lowest differing bit k, m has 1 there (works for negative ints via Python's infinite 2's complement)
    x=m^n
    k=(x & -x)
    return (m & k)!=0
def key(m):
    # sort key consistent with ◁ for nonnegative ints: compare bit-reversed with 1<0 ... use cmp_to_key instead
    return m
from functools import cmp_to_key
def cmp(m,n):
    if m==n: return 0
    return -1 if lhd(m,n) else 1
def rev_lhd_sorted(S):
    return sorted(S, key=cmp_to_key(cmp), reverse=True)
def extend(P,T):
    P=list(P); T=set(T)-set(P)
    m=max([abs(x) for x in P],default=0)
    if m==0:
        return P+[x for x in rev_lhd_sorted(T)]  # P subset {0}; 0 is greatest so reverse order puts 0 first anyway
    P0=[x//2 for x in P if x%2==0]; P1=[(x-1)//2 for x in P if x%2==1]
    T0={t//2 for t in T if t%2==0}; T1={(t-1)//2 for t in T if t%2==1}
    Q0=extend(P0,T0); E=[2*y for y in Q0[len(P0):]]
    h=max(E,default=0)
    Q1=extend(P1,T1|set(range(0,h))); O=[2*y+1 for y in Q1[len(P1):]]
    return P+O+E
def safe(P):
    # check C(P) = P then rest in ◁ order has no monotone 4AP; conditions S1,S2,S3
    pos={x:i for i,x in enumerate(P)}
    S=set(P); n=len(P)
    # S1: no 4AP in P ; S2: every 3AP in order (x,y,z) has w=2z-y in P before z
    for i in range(n):
        for j in range(i+1,n):
            x,y=P[i],P[j]; r=y-x
            z=y+r; w=z+r
            # S3 for pair (x,y)
            zin=z in S; win=w in S
            if lhd(x,y):
                if not zin and not win: return False,('S3',x,y,z,w)
                if zin and not win and pos[z]>j: return False,('S3b',x,y,z,w)
            if zin and pos[z]>j:
                # 3AP x,y,z in order
                if not win: return False,('S2',x,y,z,w)
                if pos[w]>pos[z]: return False,('S1',x,y,z,w)
    return True,None
if __name__=="__main__":
    P=[]
    for t in range(0,int(sys.argv[1])):
        if t in P: continue
        P=extend(P,{t})
        ok,why=safe(P[:400]) if len(P)>400 else safe(P)
    print(len(P), P[:30])
    ok,why=safe(P); print("safe:",ok,why)
