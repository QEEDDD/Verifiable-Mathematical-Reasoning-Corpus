import sys
sys.setrecursionlimit(100000)
from ho import extend
P=[]
for t in range(0,int(sys.argv[1])):
    if t in P: continue
    P=extend(P,{t})
    print("t=%d len=%d max=%d"%(t,len(P),max(P)))
print(P)
