#!/usr/bin/env python3
import sys, time
from sat_ext import Enc
from safety import analyze, feasible_roots
W17 = [7, -1, 3, -5, 5, -3, 1, -7, 6, -2, 2, -6, 4, -4, 0, 8, -8]
H = [0, 1, 3, 2, 11, 7, 15, 9, 5, 6, 4]
which = sys.argv[1]
t0 = time.time()
if which == 'Z':
    lo, hi = int(sys.argv[2]), int(sys.argv[3])
    REQ = set(int(v) for v in sys.argv[4].split(','))
    enc = Enc(W17, range(lo, hi + 1), REQ)
elif which == 'N':
    hi = int(sys.argv[2]); REQ = set(int(v) for v in sys.argv[3].split(','))
    fixed = (lambda node: 1) if (len(sys.argv) > 4 and sys.argv[4] == 'lhd') else None
    enc = Enc(H, range(0, hi + 1), REQ, nat=True, fixed_pref=fixed)
print("vars", enc.nv, "clauses", len(enc.clauses), "build %.1fs" % (time.time() - t0), flush=True)
s, Wx = enc.solve()
print("SAT" if s else "UNSAT", "solve+build %.1fs" % (time.time() - t0))
if s:
    print("extension:", Wx)
    if which == 'Z':
        print("check: feasible roots", feasible_roots(Wx), "contains REQ", REQ <= set(Wx))
