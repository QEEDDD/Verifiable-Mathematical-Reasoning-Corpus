#!/usr/bin/env python3
"""Exact safety test for finite words w.r.t. tree orders on Z, plus a brute-force validator.

Tree order: node (k, r) = r + 2^k Z, r in [0, 2^k).  pref[(k, r)] = bit b in {0,1}: the child
r + b*2^k + 2^{k+1}Z is preferred.  x < y (x 'prec' y) iff bit_k(x) == pref[node(x,y)], k = v2(x-y).

Characterisation used by `analyze` (derived independently, validated below by brute force):
a 4-AP monotone in C(W) has its first two in-order terms u1,u2 in W.  Then with c=2u2-u1, d=3u2-2u1:
  * c in W after u2 and (d not in W or d after c)  -> unsafe for every tree order ("dead");
  * c not in W and d not in W                      -> need u2 prec u1 (a constraint on one node);
  * otherwise no monotone 4-AP starting (u1,u2).
"""
import random
from functools import cmp_to_key


def v2(n):
    n = abs(n)
    k = 0
    while n & 1 == 0:
        n >>= 1
        k += 1
    return k


def node_of(x, y):
    k = v2(x - y)
    return (k, x & ((1 << k) - 1))


class TreeOrder:
    def __init__(self, pref=None, seed=None):
        self.pref = dict(pref or {})
        self.rng = random.Random(seed)

    def get(self, node):
        if node not in self.pref:
            self.pref[node] = self.rng.randrange(2)
        return self.pref[node]

    def less(self, x, y):
        k, r = node_of(x, y)
        return ((x >> k) & 1) == self.get((k, r))

    def cmp(self, x, y):
        if x == y:
            return 0
        return -1 if self.less(x, y) else 1


def analyze(W):
    """Return (dead_witness or None, constraints dict node->bit, conflict_witness or None)."""
    pos = {x: i for i, x in enumerate(W)}
    dead = None
    cons = {}
    why = {}
    conflict = None
    n = len(W)
    for i in range(n):
        u1 = W[i]
        for j in range(i + 1, n):
            u2 = W[j]
            c = 2 * u2 - u1
            d = 3 * u2 - 2 * u1
            pc = pos.get(c)
            pd = pos.get(d)
            if pc is not None:
                if pc > j and (pd is None or pd > pc):
                    if dead is None:
                        dead = (u1, u2, c, d)
                continue
            if pd is not None:
                continue
            node = node_of(u1, u2)
            bit = (u2 >> node[0]) & 1
            if node in cons and cons[node] != bit:
                if conflict is None:
                    conflict = (node, why[node], (u1, u2))
            else:
                cons[node] = bit
                why[node] = (u1, u2)
    return dead, cons, conflict


def feasible_roots(W, info=None):
    """Set of root parities p such that W is safe for some tree order preferring parity p."""
    dead, cons, conflict = info if info is not None else analyze(W)
    if dead is not None or conflict is not None:
        return set()
    if (0, 0) in cons:
        return {cons[(0, 0)]}
    return {0, 1}


def safe_for(W, order, info=None):
    dead, cons, conflict = info if info is not None else analyze(W)
    if dead is not None:
        return False
    # every constraint must be satisfied by the order (conflicting constraints cannot both be)
    if conflict is not None:
        return False
    return all(order.get(node) == b for node, b in cons.items())


def brute_safe(W, order, K=None):
    """Brute force: build C(W) restricted to the window [-K,K] and test every 4-AP inside it."""
    S = set(W)
    B = max(abs(x) for x in W) if W else 1
    if K is None:
        K = 6 * B + 6
    tail = sorted([x for x in range(-K, K + 1) if x not in S], key=cmp_to_key(order.cmp))
    key = {}
    for i, x in enumerate(W):
        key[x] = i
    off = len(W)
    for i, x in enumerate(tail):
        key[x] = off + i
    for a in range(-K, K + 1):
        dl = 1
        while a + 3 * dl <= K:
            k0, k1, k2, k3 = key[a], key[a + dl], key[a + 2 * dl], key[a + 3 * dl]
            if (k0 < k1 < k2 < k3) or (k0 > k1 > k2 > k3):
                return False, (a, a + dl, a + 2 * dl, a + 3 * dl)
            dl += 1
    return True, None


def reverse_listing(S, order):
    """List the finite set S in reverse order (largest first)."""
    return sorted(S, key=cmp_to_key(order.cmp), reverse=True)
