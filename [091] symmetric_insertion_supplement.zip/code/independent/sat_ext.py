#!/usr/bin/env python3
"""SAT test: does the word W have an extension W' = W X (X a word of new integers from the
universe V) containing all of REQ that is safe for some tree order (or for a fixed tree order)?

Encoding (my own):  in[v] (v in V\\W), ord[u,v] (u<v numerically, u before v), pref[node].
For every ordered pair (u1,u2) of V with c=2u2-u1, d=3u2-2u1, G := in u1 & in u2 & u1 before u2:
   G & !in c & !in d            ->  u2 prec u1           (tree-order literal)
   G & in c & u2 before c & !in d                     -> false
   G & in c & u2 before c & in d & c before d         -> false
(in the N-setting, pairs whose 4-AP leaves N are skipped).  Before-relation on V\\W: a tournament
with all 3-cycles forbidden (hence a linear order).
"""
import itertools
import sys
from pysat.solvers import Solver
from safety import node_of


class Enc:
    def __init__(self, W, V, REQ, nat=False, fixed_pref=None, solver='cadical153'):
        self.W = list(W)
        self.Wpos = {x: i for i, x in enumerate(W)}
        self.V = list(V)
        self.Vset = set(V)
        self.X0 = [v for v in V if v not in self.Wpos]
        self.nat = nat
        self.fixed_pref = fixed_pref  # None, or function node -> bit
        self.nv = 0
        self.inv = {}
        for v in self.X0:
            self.inv[v] = self.new()
        self.ordv = {}
        for a, b in itertools.combinations(sorted(self.X0), 2):
            self.ordv[(a, b)] = self.new()
        self.prefv = {}
        self.clauses = []
        self.build(REQ)
        self.solver_name = solver

    def new(self):
        self.nv += 1
        return self.nv

    # literal helpers: return True/False constants or an int literal
    def lit_in(self, x):
        if x in self.Wpos:
            return True
        if x in self.inv:
            return self.inv[x]
        return False

    def lit_prec(self, a, b):
        ia, ib = a in self.Wpos, b in self.Wpos
        if ia and ib:
            return self.Wpos[a] < self.Wpos[b]
        if ia and not ib:
            return True
        if ib and not ia:
            return False
        if a < b:
            return self.ordv[(a, b)]
        return -self.ordv[(b, a)]

    def lit_less(self, x, y):
        """tree-order literal for x prec y"""
        node = node_of(x, y)
        bit = (x >> node[0]) & 1
        if self.fixed_pref is not None:
            return self.fixed_pref(node) == bit
        if node not in self.prefv:
            self.prefv[node] = self.new()
        v = self.prefv[node]
        return v if bit == 1 else -v

    def add(self, conj_true, then_lits):
        """Add clause: (AND of conj_true) -> (OR of then_lits).  Literals may be constants."""
        cl = []
        for l in conj_true:
            if l is True:
                continue
            if l is False:
                return
            cl.append(-l)
        for l in then_lits:
            if l is True:
                return
            if l is False:
                continue
            cl.append(l)
        if not cl:
            raise ValueError("empty clause: instance trivially UNSAT")
        self.clauses.append(cl)

    def build(self, REQ):
        for r in REQ:
            l = self.lit_in(r)
            if l is False:
                raise ValueError("required element outside universe")
            if l is not True:
                self.clauses.append([l])
        # transitivity / acyclicity on X0
        X = sorted(self.X0)
        for a, b, c in itertools.combinations(X, 3):
            # forbid a->b->c->a and a->c->b->a
            self.add([self.lit_prec(a, b), self.lit_prec(b, c), self.lit_prec(c, a)], [])
            self.add([self.lit_prec(a, c), self.lit_prec(c, b), self.lit_prec(b, a)], [])
        # pair conditions
        for u1 in self.V:
            for u2 in self.V:
                if u1 == u2:
                    continue
                c = 2 * u2 - u1
                d = 3 * u2 - 2 * u1
                if self.nat and (c < 0 or d < 0):
                    continue
                G = [self.lit_in(u1), self.lit_in(u2), self.lit_prec(u1, u2)]
                inc, ind = self.lit_in(c), self.lit_in(d)
                # 1. no c, no d -> u2 prec u1
                self.add(G, [inc, ind, self.lit_less(u2, u1)])
                if inc is False:
                    continue
                pc = self.lit_prec(u2, c) if c in self.Vset else False
                # 2. c after u2, d absent -> false
                self.add(G + [inc, pc], [ind])
                if ind is False:
                    continue
                pd = self.lit_prec(c, d)
                # 3. c after u2, d after c -> false
                self.add(G + [inc, pc, ind, pd], [])

    def solve(self):
        with Solver(name=self.solver_name, bootstrap_with=self.clauses) as s:
            r = s.solve()
            model = s.get_model() if r else None
        if not r:
            return False, None
        ms = set(l for l in model if l > 0)
        X = [v for v in self.X0 if self.inv[v] in ms]
        # order X by the tournament
        from functools import cmp_to_key

        def cmpf(a, b):
            l = self.lit_prec(a, b)
            val = (l in ms) if l > 0 else ((-l) not in ms)
            return -1 if val else 1
        X.sort(key=cmp_to_key(cmpf))
        return True, self.W + X


if __name__ == "__main__":
    pass
