#!/usr/bin/env python3
"""Checks of the explicit words quoted in Section 6."""
from functools import cmp_to_key
from safety import analyze, feasible_roots, TreeOrder, brute_safe, node_of, v2

W17 = [7, -1, 3, -5, 5, -3, 1, -7, 6, -2, 2, -6, 4, -4, 0, 8, -8]
print("W17 =", W17, " set == [-8,8]:", sorted(W17) == list(range(-8, 9)))
dead, cons, conflict = analyze(W17)
print("dead:", dead, " conflict:", conflict)
print("feasible root parities:", feasible_roots(W17))
print("constraints (node -> preferred bit):", dict(sorted(cons.items())))


class ConstOrder(TreeOrder):
    def __init__(self, bit):
        super().__init__()
        self.bit = bit

    def get(self, node):
        return self.bit


lhd = ConstOrder(1)      # Ho's order as defined in the paper: prefer digit 1 everywhere
rev_lhd = ConstOrder(0)  # its reverse: prefer digit 0 everywhere
S = list(range(-8, 9))
lhd_sorted = sorted(S, key=cmp_to_key(lhd.cmp))
print("<|-increasing order of [-8,8]          :", lhd_sorted)
print("reverse-<| listing of [-8,8]            :", lhd_sorted[::-1])
print("W17 equals reverse-<| listing?          :", W17 == lhd_sorted[::-1])
print("W17 equals <|-increasing listing?       :", W17 == lhd_sorted)
print("W17 safe for <| (brute force)?          :", brute_safe(W17, lhd)[0])
print("W17 safe for reverse of <| (brute)?     :", brute_safe(W17, rev_lhd)[0])

# Which tree order is W17 the reverse listing of?  For i<j we need W17[j] < W17[i].
need = {}
okc = True
for i in range(len(W17)):
    for j in range(i + 1, len(W17)):
        x, y = W17[i], W17[j]
        node = node_of(y, x)
        bit = (y >> node[0]) & 1
        if need.get(node, bit) != bit:
            okc = False
        need[node] = bit
print("W17 is a reverse listing of some tree order:", okc)
bylevel = {}
for (k, r), b in need.items():
    bylevel.setdefault(k, set()).add(b)
print("preferred digit by level for that order:", dict(sorted(bylevel.items())))
order = TreeOrder(pref=need, seed=5)
print("W17 safe for that order (brute force):", brute_safe(W17, order)[0])
# Is W17 safe for some order preferring parity 1 at the root?  (feasible_roots says)

# ---------------- Ho's word in N with <| ----------------
H = [0, 1, 3, 2, 11, 7, 15, 9, 5, 6, 4]


def n_safe_with(W, order, K=None):
    """Brute-force N-safety: completion = W then N\\W in order; only 4-APs inside [0,K]."""
    Sset = set(W)
    if K is None:
        K = 6 * max(W) + 6
    tail = sorted([x for x in range(0, K + 1) if x not in Sset], key=cmp_to_key(order.cmp))
    key = {x: i for i, x in enumerate(W)}
    for i, x in enumerate(tail):
        key[x] = len(W) + i
    for a in range(0, K + 1):
        dl = 1
        while a + 3 * dl <= K:
            ks = [key[a + t * dl] for t in range(4)]
            if ks == sorted(ks) or ks == sorted(ks, reverse=True):
                return False, (a, a + dl, a + 2 * dl, a + 3 * dl)
            dl += 1
    return True, None


print()
print("Ho's word", H, "N-safe for <| (brute force, window [0,6max+6]):", n_safe_with(H, lhd))
print("Ho's word N-safe for reverse of <| :", n_safe_with(H, rev_lhd)[0])
