def enum_even(n):
    out=[0]; k=1
    while len(out)<n: out+= [2*k,-2*k]; k+=1
    return out[:n]
def enum_odd(n):
    out=[]; k=0
    while len(out)<n: out+=[2*k+1,-(2*k+1)]; k+=1
    return out[:n]
N=300
ys=enum_even(N); ts=enum_odd(N)
seq=[]; present=set(); odd=set(); ok=True
for j in range(N):
    t=ts[j]
    if t not in present: seq.append(t); present.add(t); odd.add(t)
    y=ys[j]
    for r in sorted(set(2*y-o for o in odd)-odd): seq.append(r); present.add(r); odd.add(r)
    seq.append(y); present.add(y)
    lo,hi=min(odd),max(odd)
    if odd!=set(range(lo,hi+1,2)) or lo+hi!=2*y or len(seq)!=(j+1)**2+2: ok=False; print("fail at",j+1); break
print("checked n<=",N,"ok",ok, "last interval",lo,hi)
