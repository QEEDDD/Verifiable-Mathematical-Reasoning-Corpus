"""SAT search for a 'safe word' P over [lo,hi] (subset, ordered) containing a target set, w.r.t. SOME 2-adic tree order:
  P followed by (Z minus P) in tree order has no monotone 4-AP.
Conditions (P finite, tail = all other integers incl. outside [lo,hi] in tree order):
  S1/S2: every in-order 3-AP (x,y,z) of P has w=2z-y in P and before z.
  S3: every pair x before y in P with neither (z=2y-x in P before y) nor (w=3y-2x in P) must have y < x in the tree order,
      i.e. pref(meet(x,y)) = bit_k(y), k=v2(y-x).
  Domain: if --nat, only APs inside N0 count (for sanity check vs Ho).
Usage: python3 safesat.py lo hi targets [--nat] [--prefix a,b,c] [--maxlen L]"""
import sys, time
from pysat.solvers import Cadical153
from pysat.card import CardEnc, EncType
args=sys.argv[1:]
nat='--nat' in args
if nat: args.remove('--nat')
prefix=[]
if '--prefix' in args:
    i=args.index('--prefix'); prefix=[int(t) for t in args[i+1].split(',') if t]; del args[i:i+2]
maxlen=None
if '--maxlen' in args:
    i=args.index('--maxlen'); maxlen=int(args[i+1]); del args[i:i+2]
lo,hi=int(args[0]),int(args[1])
def parse(s):
    out=set()
    for part in s.split(','):
        if not part: continue
        if ':' in part: a,b=map(int,part.split(':')); out|=set(range(a,b+1))
        else: out.add(int(part))
    return out
T=parse(args[2])
V=list(range(lo,hi+1)); idx={v:i for i,v in enumerate(V)}; n=len(V)
top=0
def new():
    global top; top+=1; return top
m=[new() for _ in V]
o={}
for i in range(n):
    for j in range(i+1,n): o[(i,j)]=new()
def bf(a,b): return o[(a,b)] if a<b else -o[(b,a)]
def inD(v): return (v>=0) if nat else True
cl=[]
for i in range(n):
    for j in range(i+1,n):
        for k in range(j+1,n):
            cl.append([-bf(i,j),-bf(j,k),bf(i,k)]); cl.append([bf(i,j),bf(j,k),-bf(i,k)])
# preference vars per node (k, r mod 2^k), k up to Kmax
pref={}
def prefvar(k,r):
    key=(k,r)
    if key not in pref: pref[key]=new()
    return pref[key]
def v2(x):
    x=abs(x); c=0
    while x%2==0: x//=2; c+=1
    return c
for t in T: cl.append([m[idx[t]]])
# S1/S2: in-order 3-AP (x,y,z): positions x<y<z ; need w=2z-y in P and w before z
for x in V:
    for y in V:
        if y==x: continue
        z=2*y-x
        if z not in idx: continue
        if nat and not (inD(x) and inD(y) and inD(z)): continue
        w=2*z-y
        base=[-m[idx[x]],-m[idx[y]],-m[idx[z]],-bf(idx[x],idx[y]),-bf(idx[y],idx[z])]
        if (w in idx) and (not nat or w>=0):
            cl.append(base+[m[idx[w]]]); cl.append(base+[bf(idx[w],idx[z])])
        elif nat and w<0:
            pass  # AP leaves N0: no constraint
        else:
            cl.append(base)  # w outside window: in tail -> monotone
# S3
for x in V:
    for y in V:
        if y==x: continue
        z=2*y-x; w=3*y-2*x
        if nat and (z<0 or w<0 or x<0 or y<0):
            # if the 4-AP leaves N0 (z or w negative), no constraint from tail
            if x<0 or y<0: continue
            if z<0 or w<0: continue
        k=v2(y-x); r=x%(2**k); by=(y>>k)&1 if y>=0 else ((y%(2**(k+1)))>>k)&1
        lit_pref = prefvar(k,r) if by==1 else -prefvar(k,r)   # pref=1 means child with bit 1 is smaller
        clause=[-m[idx[x]],-m[idx[y]],-bf(idx[x],idx[y]),lit_pref]
        if w in idx: clause.append(m[idx[w]])
        if z in idx:
            e=new()  # e -> m_z & z before y
            cl.append([-e,m[idx[z]]]); cl.append([-e,bf(idx[z],idx[y])])
            clause.append(e)
        cl.append(clause)
# prefix: given elements in order at the start
for a,b in zip(prefix,prefix[1:]):
    cl.append([bf(idx[a],idx[b])])
for a in prefix:
    cl.append([m[idx[a]]])
    for v in V:
        if v not in prefix:
            cl.append([-m[idx[v]],bf(idx[a],idx[v])])
if maxlen:
    enc=CardEnc.atmost(lits=m,bound=maxlen,top_id=top,encoding=EncType.seqcounter); cl+=enc.clauses
s=Cadical153(bootstrap_with=cl)
t0=time.time(); r=s.solve(); dt=time.time()-t0
print(f"[{lo},{hi}] targets={sorted(T)} nat={nat} vars={top} clauses={len(cl)} -> {'SAT' if r else 'UNSAT'} ({dt:.1f}s)")
if r:
    M=set(l for l in s.get_model() if l>0)
    mem=[i for i in range(n) if m[i] in M]
    score={i:0 for i in mem}
    for a in mem:
        for b in mem:
            if a<b:
                if o[(a,b)] in M: score[a]+=1
                else: score[b]+=1
    word=[V[i] for i in sorted(mem,key=lambda i:-score[i])]
    print("word:",word)
