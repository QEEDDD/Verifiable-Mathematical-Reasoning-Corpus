# sigma1: Theorem 3.4 construction with y_j = 2*tau_j, tau = Theorem 3.4 sequence itself.
import sys
sys.setrecursionlimit(10000)
def build_with(ys, ts):
    seq=[]; present=set(); odd=set()
    for j in range(len(ys)):
        t=ts[j]
        if t not in present:
            seq.append(t); present.add(t); odd.add(t)
        y=ys[j]
        assert y not in present
        refl=sorted(set(2*y-o for o in odd)-odd)
        for r in refl: seq.append(r); present.add(r); odd.add(r)
        seq.append(y); present.add(y)
    return seq
def enum_even(n):
    out=[0]; k=1
    while len(out)<n: out+= [2*k,-2*k]; k+=1
    return out[:n]
def enum_odd(n):
    out=[]; k=0
    while len(out)<n: out+=[2*k+1,-(2*k+1)]; k+=1
    return out[:n]
N=int(sys.argv[1]) if len(sys.argv)>1 else 40
tau=build_with(enum_even(N), enum_odd(N))      # Theorem 3.4 sequence (prefix)
M=int(sys.argv[2]) if len(sys.argv)>2 else 60
ys=[2*v for v in tau[:M]]
s1=build_with(ys, enum_odd(M))
pos={v:i for i,v in enumerate(s1)}
# check root protection of evens and node-of-evens protection of 0 mod 4
bad_root=bad_l1=0
for i,v in enumerate(s1):
    if v%2==0:
        S=set(x for x in s1[:i] if x%2!=0)
        if set(2*v-x for x in S)!=S: bad_root+=1
        if v%4==0:
            S2=set(x for x in s1[:i] if x%4==2)
            if set(2*v-x for x in S2)!=S2: bad_l1+=1
print("len",len(s1),"bad_root",bad_root,"bad_level1_in_evens",bad_l1)
# count monotone 4-APs by v2 of difference and class
from collections import Counter
cnt=Counter()
n=len(s1)
vals=s1
for i in range(n):
    for j in range(i+1,n):
        x,y=vals[i],vals[j]; d=y-x
        z=y+d; w=z+d
        if z in pos and w in pos and pos[z]>j and pos[w]>pos[z]:
            k=0; dd=abs(d)
            while dd%2==0: dd//=2; k+=1
            cnt[(k, x%2 if k>=1 else 'any')]+=1
print(sorted(cnt.items()))
