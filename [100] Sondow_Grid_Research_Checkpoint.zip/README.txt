SONDOW LOG CANCELLATION: EXACT FINITE CERTIFICATES
Research checkpoint, 2026-10-30

STATUS
This package proves finite small linear forms in Euler's constant. It does NOT
prove that Euler's constant is irrational, and makes no claim of priority.
The construction does not use numerical digits of Euler's constant.

DEFINITIONS
I_n = integral over [0,1]^2 of
 [x(1-x)y(1-y)]^n / [(1-xy)(-log(xy))].
d_n = lcm(1,...,n), E_n = d_(2n) I_n.
Sondow's exact identity is E_n = C_n gamma + log(S_n) - M_n,
where C_n=d_(2n) binom(2n,n), and C_n, M_n, and S_n are integers.
The verifier computes M_n and all prime-log coefficients directly from
the harmonic-sum formulas, independently of the generator's prefix sums.
For n>=1, 0<I_n<16^(-n).
Primary source: https://arxiv.org/pdf/math/0209070

NORMALIZATION THAT MATTERS
Each certificate gives rational q_n, but integer final coefficients A and B:
 sum q_n E_n = A gamma - B, with every prime-log coefficient zero.
The rigorous upper bound is h=sum |q_n| d_(2n) 16^(-n).
Let D be the least common denominator of the q_n and u_n=D q_n.
Then u_n are integers and the unnormalized projected pair is (DA,DB).
In these examples gcd(A,B)=1, so gcd(DA,DB)=D. Dividing the entire integer
combination by that common factor preserves integrality of the final
coefficients A,B. Raw u_n need not be small; this is NOT a short integer
E_n-vector result. The 50..100 examples have common denominators of
21759 and 21779 bits, respectively.

VERIFIED RESULTS
Window 1..20:
 A1=-15700603, B1=-9062634; h1<2^(-23).
 A2=-8660380, B2=-4998907; h2<2^(-22).
 A1 B2 - A2 B1 = 1.
 In fact 0<4998907-8660380 gamma<1.919e-7. An exact root-count certificate
 proves the corresponding degree-19 polynomial after removing t is positive
 on [0,1/16]. This does not depend on numerical evaluation of gamma.

Window 20..50: two independent integer pairs, both h<2^(-67).
Window 50..100: two independent integer pairs, both h<2^(-155).
All coefficients and exact rational bounds are in the JSON files.
The 50..100 coefficient pairs have determinant 1. Consequently at least one
linear form is nonzero. If gamma=p/q in lowest terms, then a nonzero integer
linear form has magnitude at least 1/q. These finite certificates imply
 q > 70095921708758763489189184089217745284896512241.
This is a finite denominator exclusion, not irrationality or a record claim.

CONSTRUCTION
Form the rational kernel of the prime-log matrix. Give a coefficient vector
the squared norm sum (q_n d_(2n)16^(-n))^2. Mod out by the subspace that also
kills C and M. For each prescribed integer pair (A,B), its least-norm lift is
rational and obtained by exact linear algebra. This induces a positive
definite rational binary quadratic form on Z^2. Exact Gauss reduction gives
two integer pairs with determinant +/-1. The full rational coefficient lifts
then give the displayed h bounds. This is closely related to continued
fraction approximation, inferred here from exact integral identities.

WHAT IS STILL UNPROVED
For an increasing sequence of windows, we would need two independent
integer pairs whose certified errors BOTH tend to zero. The second
successive minimum of the induced binary quadratic form must be controlled.
A small first minimum or determinant does not suffice: if gamma were
rational, the shortest direction could give an identically zero form.
The observed finite decreases do not establish any asymptotic bound.

HOW TO VERIFY
Python 3.11 or later; exact standard-library arithmetic only:
 python verify_log_cancellation.py
This checks all prime logs cancel, final A,B are the claimed integers,
exact rational upper bounds, denominator normalization, and determinants.
For the additional strict positivity certificate, install SymPy and run:
 python verify_positive_form.py

HOW TO REGENERATE
The generator additionally requires python-flint and sympy.
 python quotient_agent_quotient.py 1 20 20 50 50 100
Run from the extracted directory; it writes certificate JSONs there.
The generator also emits results for the more restrictive integer E_n
lattice. Those bounds do not apply after the common-factor normalization.

CONTENTS
verify_log_cancellation.py: independent exact verifier, standard library.
verify_positive_form.py: exact positivity check using SymPy.
quotient_agent_rational_*.json: exact rational lifts and upper bounds.
quotient_agent_sign_1_20.json: primitive integer polynomial and root data.
gamma_elimination_probe.py, quotient_agent_weighted.py,
quotient_agent_quotient.py: reproducible construction scripts.
