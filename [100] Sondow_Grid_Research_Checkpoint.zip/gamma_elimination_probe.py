from math import comb, lcm, gcd, log2
from functools import reduce
from flint import fmpz_mat, arb, ctx
from sympy import primerange, factorint
import sys, time

def columns(lo,hi):
    primes=list(primerange(1,2*hi+1))
    ix={p:i for i,p in enumerate(primes)}
    data=[]
    for n in range(lo,hi+1):
        d=lcm(*range(1,2*n+1))
        h=[0]
        for j in range(1,2*n+1): h.append(h[-1]+d//j)
        pref=[]; w=0
        for i in range((n-1)//2+1):
            w+=comb(n,i)**2*(h[n-i]-h[i]); pref.append(w)
        exps=[0]*len(primes)
        for k in range(1,n+1):
            e=2*pref[min(k-1,n-k)]
            for p,v in factorint(n+k).items(): exps[ix[p]]+=e*v
        C=d*comb(2*n,n)
        M=sum(comb(n,i)**2*h[n+i] for i in range(n+1))
        data.append((exps,C,M))
    return primes,data

def probe(lo,hi):
    started=time.time()
    primes,data=columns(lo,hi)
    mat=fmpz_mat([x[0] for x in data])
    H,T=mat.hnf(transform=True)
    kernel=[]
    for i in range(H.nrows()):
        if all(H[i,j]==0 for j in range(H.ncols())):
            kernel.append([int(T[i,j]) for j in range(T.ncols())])
    if not kernel:
        print('window',lo,hi,'no kernel',flush=True);return
    K=fmpz_mat(kernel).lll()
    assert K*mat==fmpz_mat(K.nrows(),mat.ncols())
    rows=[]
    ctx.prec=40*hi+500
    for i in range(K.nrows()):
        u=[int(K[i,j]) for j in range(K.ncols())]
        A=sum(v*x[1] for v,x in zip(u,data))
        B=sum(v*x[2] for v,x in zip(u,data))
        if not(A or B): continue
        val=A*arb.const_euler()-B
        rows.append((float(abs(val).mid()),max(abs(v).bit_length() for v in u),A,B,u,val))
    rows.sort(key=lambda x:x[0])
    print('window',lo,hi,'kernel_dim',len(kernel),'nonzero_projected_LLL_rows',len(rows),'seconds',round(time.time()-started,2),flush=True)
    for _,bits,A,B,u,val in rows[:2]:
        g=gcd(A,B)
        print('coeff_bits',bits,'A_bits',abs(A).bit_length(),'B_bits',abs(B).bit_length(),'value',val.str(10),'primitive_value',(val/g).str(10),'gcd_bits',g.bit_length(),flush=True)
        if hi<=10: print('u',u,'A',A,'B',B,flush=True)

if __name__=='__main__':
    args=[int(x) for x in sys.argv[1:]]
    for lo,hi in zip(args[::2],args[1::2]): probe(lo,hi)
