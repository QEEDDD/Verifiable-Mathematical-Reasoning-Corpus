from gamma_elimination_probe import columns
from quotient_agent_weighted import kernel,log2q
from flint import fmpz_mat,fmpq_mat,fmpq
from math import lcm,log2
from fractions import Fraction
import sys,time,json

def dots(a,b):return sum(x*y for x,y in zip(a,b))
def near(a):return int((a+fmpq(1,2)).floor())
def row(A,i):return [A[i,j] for j in range(A.ncols())]
def matrows(A):return [row(A,i) for i in range(A.nrows())]
def bitsq(q):return log2(int(q.numerator))-log2(int(q.denominator))

def run(lo,hi):
 st=time.time();ps,data=columns(lo,hi);X=fmpz_mat([x[0] for x in data]);K=kernel(X)
 P=K*fmpz_mat([[x[1],x[2]] for x in data]);H,T=P.hnf(transform=True)
 lifts=T*K;nr=sum(any(H[i,j] for j in range(2)) for i in range(H.nrows()))
 if nr!=2:return print('ranknot2',lo,hi,nr)
 w=[lcm(*range(1,2*n+1))*16**(hi-n) for n in range(lo,hi+1)]
 W=fmpz_mat([[int(lifts[i,j])*w[j] for j in range(lifts.ncols())] for i in range(lifts.nrows())])
 bs=matrows(W);v=bs[:2];Z=bs[2:]
 Q=fmpq_mat([[dots(a,b) for b in v] for a in v]);Vmin=fmpq_mat(v)
 if Z:
  ZM=fmpz_mat(Z).lll();Z=matrows(ZM)
  Zq=fmpq_mat(Z);Vq=fmpq_mat(v);R=Vq*Zq.transpose()
  Zinv=(Zq*Zq.transpose()).inv();Q=Q-R*Zinv*R.transpose()
  Vmin=Vq-R*Zinv*Zq
 # Allow rational integral coefficients, but keep projected coefficients integral.
 P0=fmpq_mat([[H[i,j] for j in range(2)] for i in range(2)])
 Pinv=P0.inv();Qfull=Pinv*Q*Pinv.transpose();Vfull=Pinv*Vmin
 G=Q;change=[[1,0],[0,1]];iters=0
 while True:
  iters+=1
  if G[0,0]>G[1,1]:
   change=[change[1],change[0]];G=fmpq_mat([[G[1,1],G[1,0]],[G[0,1],G[0,0]]])
  mu=near(G[0,1]/G[0,0])
  if mu==0:break
  change[1]=[b-mu*a for a,b in zip(change[0],change[1])]
  G=fmpq_mat([[G[0,0],G[0,1]-mu*G[0,0]],[G[1,0]-mu*G[0,0],G[1,1]-2*mu*G[0,1]+mu*mu*G[0,0]]])
  if iters>10000:raise RuntimeError('too many')
 # Rational Gram-Schmidt for exact Babai lift reduction.
 orth=[]
 for z in Z:
  cur=[fmpq(x) for x in z]
  for zz in orth:
   c=dots(z,zz)/dots(zz,zz);cur=[a-c*b for a,b in zip(cur,zz)]
  orth.append(cur)
 def lift(a,b):
  vv=[a*x+b*y for x,y in zip(v[0],v[1])]
  for z,zz in reversed(list(zip(Z,orth))):
   c=near(dots(vv,zz)/dots(zz,zz));vv=[x-c*y for x,y in zip(vv,z)]
  assert all(x%ww==0 for x,ww in zip(vv,w))
  u=[int(x//ww) for x,ww in zip(vv,w)]
  A=sum(a*x[1] for a,x in zip(u,data));B=sum(a*x[2] for a,x in zip(u,data))
  bd=Fraction(sum(abs(int(x)) for x in vv),16**hi)
  return dict(u=u,A=A,B=B,bound_num=bd.numerator,bound_den=bd.denominator,boundlog2=log2q(bd))
 out=[]
 for a in range(-3,4):
  for b in range(-3,4):
   if a==b==0:continue
   aa=a*change[0][0]+b*change[1][0];bb=a*change[0][1]+b*change[1][1]
   out.append(lift(aa,bb))
 out.sort(key=lambda x:x['boundlog2'])
 enc=lambda x:[str(x.numerator),str(x.denominator)]
 result=dict(lo=lo,hi=hi,dim=K.nrows(),quotient_l2_min_log2=bitsq(G[0,0])/2-4*hi,quotient_l2_second_log2=bitsq(G[1,1])/2-4*hi,gauss_iters=iters,best=out[:5],image_basis=[[int(H[i,j]) for j in range(2)] for i in range(2)],change=change,reduced_gram=[[enc(G[i,j]/16**(2*hi)) for j in range(2)] for i in range(2)],reduced=bool(G[0,0]<=G[1,1] and 2*abs(G[0,1])<=G[0,0]),babai_radius_log2=bitsq(sum(dots(z,z) for z in orth)/4)/2-4*hi if orth else None)
 print({k:v for k,v in result.items() if k in ['lo','hi','dim','quotient_l2_min_log2','quotient_l2_second_log2','gauss_iters','reduced','babai_radius_log2']},'bestboundlog2',out[0]['boundlog2'],'secs',round(time.time()-st,2),flush=True)
 with open(f'quotient_agent_quotient_{lo}_{hi}.json','w') as f:json.dump(result,f)
 G=Qfull;change=[[1,0],[0,1]];iters=0
 while True:
  iters+=1
  if G[0,0]>G[1,1]:
   change=[change[1],change[0]];G=fmpq_mat([[G[1,1],G[1,0]],[G[0,1],G[0,0]]])
  mu=near(G[0,1]/G[0,0])
  if mu==0:break
  change[1]=[b-mu*a for a,b in zip(change[0],change[1])]
  G=fmpq_mat([[G[0,0],G[0,1]-mu*G[0,0]],[G[1,0]-mu*G[0,0],G[1,1]-2*mu*G[0,1]+mu*mu*G[0,0]]])
 RV=fmpq_mat(change)*Vfull
 forms=[]
 for i in range(2):
  q=[RV[i,j]/w[j] for j in range(len(w))]
  qM=fmpq_mat([q]);assert qM*fmpq_mat(X)==fmpq_mat(1,X.ncols())
  proj=qM*fmpq_mat([[x[1],x[2]] for x in data]);assert list(proj[0,j] for j in range(2))==change[i]
  bd=sum(abs(x) for x in row(RV,i))/16**hi
  forms.append(dict(A=change[i][0],B=change[i][1],bound=enc(bd),boundlog2=bitsq(bd),rational_E_coefficients=[enc(x) for x in q]))
 ratres=dict(lo=lo,hi=hi,forms=forms,change=change,reduced_gram=[[enc(G[i,j]/16**(2*hi)) for j in range(2)] for i in range(2)])
 print('RATIONAL',lo,hi,[(z['A'],z['B'],z['boundlog2']) for z in forms],flush=True)
 with open(f'quotient_agent_rational_{lo}_{hi}.json','w') as f:json.dump(ratres,f)

if __name__=='__main__':
 a=list(map(int,sys.argv[1:]))
 for lo,hi in zip(a[::2],a[1::2]):run(lo,hi)
