from gamma_elimination_probe import columns
from flint import fmpz_mat,arb,ctx
from math import lcm,gcd,log2
from fractions import Fraction
import sys,time,json

def kernel(A):
 H,T=A.hnf(transform=True)
 rows=[]
 for i in range(H.nrows()):
  if all(H[i,j]==0 for j in range(H.ncols())):
   rows.append([int(T[i,j]) for j in range(T.ncols())])
 return fmpz_mat(rows) if rows else None

def log2q(x):
 return log2(x.numerator)-log2(x.denominator)

def run(lo,hi):
 st=time.time();primes,data=columns(lo,hi)
 mat=fmpz_mat([x[0] for x in data]);K=kernel(mat)
 if K is None:return print('NO KERNEL',lo,hi,flush=True)
 d=[lcm(*range(1,2*n+1)) for n in range(lo,hi+1)]
 w=[dd*16**(hi-n) for n,dd in zip(range(lo,hi+1),d)]
 W=fmpz_mat([[int(K[i,j])*w[j] for j in range(K.ncols())] for i in range(K.nrows())])
 print('START',lo,hi,'dim',K.nrows(),'HNFsecs',round(time.time()-st,3),flush=True)
 L,U=W.lll(transform=True)
 V=U*K
 assert V*mat==fmpz_mat(V.nrows(),mat.ncols())
 ctx.prec=60*hi+2000
 out=[]
 for i in range(V.nrows()):
  u=[int(V[i,j]) for j in range(V.ncols())]
  A=sum(v*x[1] for v,x in zip(u,data));B=sum(v*x[2] for v,x in zip(u,data))
  bound=Fraction(sum(abs(v)*ww for v,ww in zip(u,w)),16**hi)
  if not(A or B):continue
  val=A*arb.const_euler()-B
  out.append(dict(A=A,B=B,u=u,bound_num=bound.numerator,bound_den=bound.denominator,boundlog2=log2q(bound),value=val.str(12),coeffbits=max(abs(v).bit_length() for v in u)))
 out.sort(key=lambda z:z['boundlog2'])
 projection=fmpz_mat([[r['A'],r['B']] for r in out]);PH=projection.hnf()
 nonzero=[[int(PH[i,j]) for j in range(2)] for i in range(PH.nrows()) if any(PH[i,j] for j in range(2))]
 print('END',lo,hi,'secs',round(time.time()-st,3),'nonzero',len(out),'projection_basis',nonzero,flush=True)
 for z in out[:3]:print({k:v for k,v in z.items() if k not in ['A','B','u','bound_num','bound_den']},flush=True)
 det=None
 if len(out)>1:
  z=out[0]
  for q in out[1:]:
   if z['A']*q['B']-q['A']*z['B']:
    det=(z['A']*q['B']-q['A']*z['B']);print('independent pair boundlogs',z['boundlog2'],q['boundlog2'],'detbits',abs(det).bit_length(),flush=True);break
 path=f'quotient_agent_result_{lo}_{hi}.json'
 with open(path,'w') as f:json.dump({'lo':lo,'hi':hi,'kernel_dim':K.nrows(),'projection_basis':nonzero,'rows':out},f)

if __name__=='__main__':
 a=list(map(int,sys.argv[1:]))
 for lo,hi in zip(a[::2],a[1::2]):run(lo,hi)
