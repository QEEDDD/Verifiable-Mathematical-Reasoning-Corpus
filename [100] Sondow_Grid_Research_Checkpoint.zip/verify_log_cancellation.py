"""Verify Sondow cancellation certificates using only exact standard-library arithmetic.

Run: python verify_log_cancellation.py [certificate.json ...]
No numerical value of Euler's constant is evaluated or used.
"""
from fractions import Fraction as F
from math import comb, gcd, lcm
from pathlib import Path
import json
import sys

sys.set_int_max_str_digits(0)


def factor(n):
    out = {}
    p = 2
    while p * p <= n:
        while n % p == 0:
            out[p] = out.get(p, 0) + 1
            n //= p
        p += 1
    if n > 1:
        out[n] = out.get(n, 0) + 1
    return out


def sondow_row(n):
    """Direct harmonic-sum formula, independent of the generator's prefix sums."""
    d = lcm(*range(1, 2 * n + 1))
    h = [F(0)]
    for j in range(1, 2 * n + 1):
        h.append(h[-1] + F(1, j))
    logs = {}
    for k in range(1, n + 1):
        a = 2 * sum(
            (comb(n, i) ** 2 * (h[n - i] - h[i])
             for i in range(min(k - 1, n - k) + 1)), F(0)
        )
        for p, power in factor(n + k).items():
            logs[p] = logs.get(p, F(0)) + d * a * power
    C = d * comb(2 * n, n)
    M = d * sum((comb(n, i) ** 2 * h[n + i] for i in range(n + 1)), F(0))
    assert M.denominator == 1
    assert all(x.denominator == 1 for x in logs.values())
    return d, logs, C, M


def verify(path):
    doc = json.loads(Path(path).read_text())
    lo, hi = doc['lo'], doc['hi']
    rows = [sondow_row(n) for n in range(lo, hi + 1)]
    forms = doc['forms']
    bounds = []
    for j, form in enumerate(forms):
        q = [F(int(a), int(b)) for a, b in form['rational_E_coefficients']]
        assert len(q) == len(rows)
        logs = {}
        for x, (_, row_logs, _, _) in zip(q, rows):
            for p, a in row_logs.items():
                logs[p] = logs.get(p, F(0)) + x * a
        assert all(x == 0 for x in logs.values()), 'Uncancelled logarithm'
        A = sum((x * row[2] for x, row in zip(q, rows)), F(0))
        B = sum((x * row[3] for x, row in zip(q, rows)), F(0))
        assert A == form['A'] and B == form['B']
        assert A.denominator == B.denominator == 1
        bound = sum((abs(x) * F(row[0], 16 ** n)
                     for n, x, row in zip(range(lo, hi + 1), q, rows)), F(0))
        assert bound == F(*map(int, form['bound']))
        D = lcm(*(x.denominator for x in q))
        u = [int(D * x) for x in q]
        assert all(F(x, D) == y for x, y in zip(u, q))
        assert gcd(abs(D * int(A)), abs(D * int(B))) == D
        bounds.append(bound)
        print(f'  form {j+1}: A={A}, B={B}')
        print(f'    all prime logs cancel; exact bound verified; common denominator bits={D.bit_length()}')
    det = forms[0]['A'] * forms[1]['B'] - forms[1]['A'] * forms[0]['B']
    assert abs(det) == 1
    upper = max(bounds)
    denominator_lower = upper.denominator // upper.numerator
    if (lo, hi) == (1, 20):
        assert bounds[0] < F(1, 2 ** 23)
        assert bounds[1] < F(1, 2 ** 22)
    if (lo, hi) == (50, 100):
        assert all(x < F(1, 2 ** 155) for x in bounds)
    print(f'PASS window {lo}..{hi}: determinant={det}; at least one form is nonzero.')
    print(f'If gamma=p/q is reduced, then q>{denominator_lower}.')


if __name__ == '__main__':
    paths = sys.argv[1:] or sorted(Path(__file__).parent.glob('quotient_agent_rational_*.json'))
    for path in paths:
        verify(path)
