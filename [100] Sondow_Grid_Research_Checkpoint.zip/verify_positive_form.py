"""Optional exact positivity verification; requires SymPy."""
from fractions import Fraction as F
from math import lcm
from pathlib import Path
import json
import sys
import sympy as s

sys.set_int_max_str_digits(0)
root = Path(__file__).resolve().parent
c = json.loads((root / 'quotient_agent_sign_1_20.json').read_text())
f = json.loads((root / 'quotient_agent_rational_1_20.json').read_text())['forms'][1]
q = [F(int(a), int(b)) for a, b in f['rational_E_coefficients']]
scale = F(int(c['identity_integral_scale_numerator']), int(c['identity_integral_scale_denominator']))
a = [int(v) for v in c['polynomial_t_removed_coefficients']]
assert scale > 0
assert [scale * q[n-1] * lcm(*range(1, 2*n+1)) for n in range(1, 21)] == a
x = s.symbols('x')
p = s.Poly.from_list(list(reversed(a)), gens=x)
assert a[0] > 0
assert p.eval(0) != 0 and p.eval(s.Rational(1, 16)) != 0
assert p.count_roots(0, s.Rational(1, 16)) == 0
assert F(*map(int, f['bound'])) < F(1919, 10**10)
print('PASS: 0 < 4998907 - 8660380*gamma < 1.919e-7.')
