Certified prime outputs on the two shifted Mills schedules
=========================================================

Open prime_outputs.txt to see the exact bases and all the reported integers. Run the following commands in this directory with standard Python 3.9 or later, with assertions enabled. No extra packages are needed. Elliptic-curve primality and multiprecision powers can take several minutes.

python3 verify_sparse_pairs.py
    Verify the simple three-term seed and fourteen prime values, up to 400 and 401 digits.
python3 verify_primes.py joint_prime_witness_7.json
    Verify fourteen prime values from a second common rational base, up to 802 and 803 digits.
python3 verify_next.py
    Check proper divisors at level eight for the second common rational base.
python3 verify_prefixes.py finite_prefix_certificates_8_8.json
    Verify each separate minimum for prefixes of lengths one through eight. Check every skipped composite, all prime certificates, exact floor comparisons, and full containment of the two final cells.
python3 verify_leading_integers.py 8
    Check exact logarithmic inequalities for a base in either final cell. The consequence for infinite minima uses the continuation argument in the paper.
python3 verify_ratio.py
    Check a lower bound on denominators using rational enclosures for both logarithms and two adjacent Farey fractions. The same continuation hypothesis applies.

The last two checks use integer enclosures for 2*atanh(z). Finite prime proofs use elliptic curves with certified orders and recursive Lucas certificates at the leaves. Entries outside the tested prefixes are not promised prime. The window criterion in the paper deals with the ordinary prime set.
