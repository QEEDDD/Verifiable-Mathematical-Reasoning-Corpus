"""Independent standard-library rational log certificate for the 20th primes.
Reads known finite prime P_k in prefix_{minus,plus}.json, and checks
stated 60 leading digits by monotone comparisons (no floating point).
"""
import json,sys
from pathlib import Path
F=1<<420
J=140
assert 3*F < 3**(2*J+1)
def ceil(a,b):return -((-a)//b)
def step(lo,hi,al,ah):return lo*al//F,ceil(hi*ah,F)
def basic(n,d):
    assert d<=n<=2*d
    zl=(n-d)*F//(n+d);zh=ceil((n-d)*F,n+d)
    ll,uu=step(zl,zh,zl,zh)
    lo,hi=zl,zh; sl=su=0
    for j in range(J):
        sl+=lo//(2*j+1);su+=ceil(hi,2*j+1)
        lo,hi=step(lo,hi,ll,uu)
    return 2*sl,2*su+1
l2,u2=basic(2,1)
def log(n):
    e=n.bit_length()-1;l,u=basic(n,1<<e)
    return e*l2+l,e*u2+u
l10,u10=log(10)
folder=Path(__file__).resolve().parent;k=int(sys.argv[1]) if len(sys.argv)>1 else 7
for name,sgn,nd,g in [
 ('minus',-1,536469125,222487814404547507395301073243996095613005076468264118478769),
 ('plus',1,263660230,580631151197619473246743688848015321913247203824634113594065)]:
    a=json.loads((folder/'finite_prefix_certificates_8_8.json').read_text())['rows'][name][k-1]
    P,D=a['P'],a['D'];E=3**20+sgn
    m=nd-len(str(g));assert m>0
    left=(m*u10+log(g)[1])*D
    right=(m*l10+log(g+1)[0])*D
    assert left < E*log(P)[0] <= E*log(P+1)[1] < right
    print(name,'base level',k,'digit count',nd,'first 60',g,'verified')
