"""Verify that the 802/803-digit pair's exact rational base fails at level 8."""
from pathlib import Path
import json
row = json.loads((Path(__file__).resolve().parent/'joint_prime_witness_7.json').read_text())
num, denominator = row['a'], 10**row['e']
for exponent, factor in [(6560, 163), (6562, 31)]:
    # The top factor can be checked without constructing the full denominator times a larger quotient.
    D = denominator**exponent
    residue = pow(num, exponent, factor * D) // D
    assert residue == 0 and num > denominator
    # The prior level already gave primes of hundreds of digits at smaller exponents.
    print(exponent, 'has proper factor', factor)
