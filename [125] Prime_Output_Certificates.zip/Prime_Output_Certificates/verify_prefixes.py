"""Exact proof of two separately minimal finite prime-floor prefixes, with no dependencies."""
from pathlib import Path
import json,sys
from math import gcd
from verify_primes import ecpp

def compare(x,i,y,j):
    g=gcd(i,j);a=x**(j//g);b=y**(i//g);return (a>b)-(a<b)

def composite(n,a):
    if n<2:return n==1
    if n%2==0:return n>2
    for v in (3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97):
        if v<n and n%v==0:return True
    assert 1<a<n
    v=n-1;d=(v&-v).bit_length()-1;r=pow(a,v>>d,n)
    if r in (1,n-1):return False
    for j in range(d-1):
        r=r*r%n
        if r==n-1:return False
    return True

def check(input_path):
    data=json.loads(Path(input_path).read_text())
    for name,sgn in [('minus',-1),('plus',1)]:
        rows=data['rows'][name]; P,D=1,1
        known=[]
        for k,row in enumerate(rows,1):
            E=3**k+sgn;p=row['prime'];g=row['gap'];starter=p-g;
            assert row['k']==k and row['E']==E and g>=0
            assert compare(starter,E,P,D)<=0<compare(starter+1,E,P,D)
            wit=row['skipped_mr_bases'];assert len(wit)==g
            for off,w in enumerate(wit):assert composite(starter+off,w)
            ecpp(p,row['certificate'],data['leaves'])
            if g:P,D=p,E
            assert (P,D)==(row['P'],row['D'])
            known.append((p,E))
            for p1,e1 in known:
                assert compare(p1,e1,P,D)<=0<compare(p1+1,e1,P,D)
        for prior_p, prior_e in known:
            assert compare(P + 1, D, prior_p + 1, prior_e) <= 0
        print(name,'certified the minimum of each finite prefix through',len(rows),'levels;',len(str(rows[-1]['prime'])),'digits at last level',flush=True)
if __name__=='__main__':check(sys.argv[1])
