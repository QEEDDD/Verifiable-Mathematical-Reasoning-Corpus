"""Standard-library verification using elliptic curves and recursive Lucas certificates."""
from math import gcd, isqrt
from pathlib import Path
import json,sys

def curve_multiple(n,a,k,P):
    # Mixed Jacobian/affine arithmetic. Guard all nonzero branch divisors
    # with one gcd so every prime divisor of n follows identical branches.
    if P is None:return None
    x,y=P
    V=None; guard=1
    for bit in bin(k)[2:]:
        if V is not None:
            X,Y,Z=V
            if Y==0:
                V=None
            else:
                guard=guard*Y%n
                yy=Y*Y%n; z2=Z*Z%n
                S=4*X*yy%n; M=(3*X*X+a*z2*z2)%n
                XX=(M*M-2*S)%n
                V=(XX,(M*(S-XX)-8*yy*yy)%n,2*Y*Z%n)
        if bit=='0':continue
        if V is None:
            V=(x,y,1)
            continue
        X,Y,Z=V; z2=Z*Z%n
        H=(x*z2-X)%n; R=(y*z2*Z-Y)%n
        if H:
            guard=guard*H%n
            h2=H*H%n; h3=h2*H%n; u=X*h2%n
            XX=(R*R-h3-2*u)%n
            V=(XX,(R*(u-XX)-Y*h3)%n,Z*H%n)
        elif R:
            guard=guard*R%n
            assert (y*z2*Z+Y)%n==0
            V=None
        else:
            if Y==0:V=None;continue
            guard=guard*Y%n
            yy=Y*Y%n; S=4*X*yy%n; M=(3*X*X+a*z2*z2)%n
            XX=(M*M-2*S)%n
            V=(XX,(M*(S-XX)-8*yy*yy)%n,2*Y*Z%n)
    assert gcd(n,guard)==1
    if V is None:return None
    X,Y,Z=V; inv=pow(Z,-1,n); w=inv*inv%n
    return X*w%n,Y*w*inv%n

def lucas(n, data):
    if n==2:return
    base, fac=data[str(n)];assert n>=3 and n%2
    prod=1
    for q,v in fac:
        lucas(q,data);assert v>=1;prod*=q**v
        assert gcd(pow(base,(n-1)//q,n)-1,n)==1
    assert prod==n-1 and pow(base,n-1,n)==1

def ecpp(p, cert, leaves):
    if isinstance(cert,int):
        assert cert==p;lucas(p,leaves);return
    for n,t,s,a,P in cert:
        assert p==n and n>3 and gcd(6,n)==1 and s>0
        q,r=divmod(n+1-t,s); assert r==0 and 1<q<n
        assert q>(isqrt(isqrt(n))+2)**2
        x,y=P; P=(x%n,y%n);a%=n;b=(y*y-x**3-a*x)%n
        assert gcd(n,4*a**3+27*b*b)==1
        Q=curve_multiple(n,a,s,P)
        assert Q is not None and curve_multiple(n,a,q,Q) is None
        p=q
    lucas(p,leaves)

def verify(bundle):
    b=json.loads(Path(bundle).read_text()); D=10**b['e']; A=b['a']; K=len(b['pairs']);assert type(A)==int and A> D
    for j,row in enumerate(b['pairs'],1):
        for i,(p,cert) in enumerate(row):
            n=3**j+2*i-1
            assert A**n//D**n==p
            ecpp(p,cert,b['leaves'])
    print('Verified',2*K,'prime floors at one rational base; last digit counts',*[len(str(r[0])) for r in b['pairs'][-1]])

if __name__=='__main__':verify(sys.argv[1])
