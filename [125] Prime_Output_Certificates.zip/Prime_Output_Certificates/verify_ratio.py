"""Integer-only bounds on the log ratio from the two terminal prime cells."""
from fractions import Fraction
import json
from pathlib import Path

bits = 2100
unit = 1 << bits
terms = 720
assert 3 * unit < 3 ** (2 * terms + 1)

def ceil_div(n, d):
    return -((-n) // d)

def log_normalized(n, d):
    # log(n/d) = 2*atanh(z), where 0 <= z <= 1/3.
    assert d <= n <= 2*d
    low = (n-d)*unit//(n+d)
    high = ceil_div((n-d)*unit, n+d)
    square_low = low*low//unit
    square_high = ceil_div(high*high, unit)
    total_low = total_high = 0
    for j in range(terms):
        total_low += low//(2*j+1)
        total_high += ceil_div(high, 2*j+1)
        low = low*square_low//unit
        high = ceil_div(high*square_high, unit)
    return 2*total_low, 2*total_high+1

log_two = log_normalized(2,1)
def log_interval(n):
    e = n.bit_length()-1
    lo, hi = log_normalized(n, 1 << e)
    return e*log_two[0]+lo, e*log_two[1]+hi

def simplest(a,b):
    integer = a.numerator//a.denominator
    if a == integer:
        return a
    if b >= integer+1:
        return Fraction(integer+1)
    return integer + 1/simplest(1/(b-integer),1/(a-integer))

root = Path(__file__).resolve().parent
rows = json.loads((root/'finite_prefix_certificates_8_8.json').read_text())['rows']
m, p = rows['minus'][-1], rows['plus'][-1]
lo = Fraction(log_interval(m['P'])[0]*p['D'], m['D']*log_interval(p['P']+1)[1])
hi = Fraction(log_interval(m['P']+1)[1]*p['D'], m['D']*log_interval(p['P'])[0])
assert lo < hi
v = simplest(lo,hi)
P,Q = v.numerator,v.denominator
b = pow(P,-1,Q)
a = (P*b-1)//Q
c,d = P-a,Q-b
assert c*b-a*d == 1 and Fraction(a,b) < lo <= v <= hi < Fraction(c,d)
assert Q > 10**240
print('Conditional on both terminal cells extending, the rational denominator is at least',Q)
