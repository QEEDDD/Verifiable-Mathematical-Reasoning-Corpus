Computational checks for the collected edition

Run the commands below from the directory containing this README. All scripts
use exact arithmetic and run offline. Use Python 3.9 or later. SymPy is used
by earlier/aesz4_dossier.py, verify_finite.py and eta_rows.py. The long-range
check also requires a C++17 compiler with __uint128_t support (GCC or Clang).

Earlier manuscripts (the code is also printed in the TeX)
  python3 earlier/reflection_blocks_and_levels.py
  python3 earlier/apery_supersingular.py
  python3 earlier/all_level_reflection.py
  python3 earlier/aesz4_dossier.py

The first script joins two consecutive listings so that the second can reuse
the first one's coefficient and term functions. Expected counts are 2,583
block checks, 178 level checks and 256 level-dependent checks. The second
script checks 94 supersingular Apéry cases. The third checks 656 cases.
The fourth checks the AESZ4 recurrence, nine truncations, residual-monodromy
determinants and the modular-polynomial calculation. It also writes
earlier/verification_output.json.

Tetrahedral projector and digit formulas
  python3 verify_four_primes.py
  python3 verify_traces.py 199
  python3 verify_digits.py 199

The first program recovers the four Euler factors used for the Galois
comparison. The next two test the torus and reciprocal-j trace formulas, then
the Jacobi-sum digits and the elliptic trace criteria.

Good-prime level-54 congruence
  python3 check_frobenius.py
  python3 verify_finite.py 5000
  c++ -O3 -std=c++17 range_check.cpp -o range_check
  python3 eta_rows.py 100000 > rows.txt
  ./range_check < rows.txt

The first check covers 1,009 smooth parameters at the 23 primes from 5 to 97.
The second computes modular-form coefficients independently of the truncation
and checks the exact valuations for all 667 good primes up to 5,000.
The last three commands check all 9,590 good primes up to 100,000 modulo p^3.
The final prime, 99,991, has coefficient 49,718,099.

The 45-page volume originally embedded its code as five TeX listings. Its
verbatim code is in earlier/. The two follow-up archives shared identical
copies of verify_four_primes.py and verify_finite.py. Each appears once here.
