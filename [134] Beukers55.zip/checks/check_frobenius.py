"""Exact tests of the transported matrix modulo p^3, using independent elliptic point counts."""
from math import isqrt


def mul(a,b,M):
    return tuple(sum(a[h]*b[j-h] for h in range(j+1)) % M for j in range(3))


def block_polynomials(p):
    M=p**3
    term=(1,0,0)
    blocks=[]
    for k in range(p):
        if k:
            num=(1,0,0)
            for j in (3*k-2,3*k-1,3*k):
                num=mul(num,(j,3*p,0),M)
            u=pow(k,-1,M)
            den=(u**6,-6*p*u**7,21*p*p*u**8)
            term=mul(mul(term,mul(num,num,M),M),den,M)
        blocks.append(term)
    return blocks


def columns(p,z,blocks):
    M=p**3
    g=(pow(z,p-1,M)-1)%M
    L=(g-g*g*pow(2,-1,M))%M
    shift=(1,L,L*L*pow(2,-1,M))
    matrix=[[0]*3 for i in range(4)]
    zk=1
    for k,b in enumerate(blocks):
        col=mul(shift,b,M)
        for i in range(4):
            for h in range(3):
                matrix[i][h]=(matrix[i][h]+zk*col[h])%M
            col=mul(col,(k,p,0),M)
        zk=zk*z%M
    return matrix


def fibre_traces(p):
    N=[0]*p
    for x in range(1,p):
        for y in range(1,p):
            z=(1-x-y)%p
            if z:
                N[x*y*z%p]+=1
    return [p-2-v for v in N]


def check(bound=97):
    count=0
    primes=[p for p in range(5,bound+1) if all(p%d for d in range(2,isqrt(p)+1))]
    for p in primes:
        M=p**3
        blocks=block_polynomials(p)
        h=fibre_traces(p)
        for z in range(1,p):
            if 729*z%p==1:
                continue
            mat=columns(p,z,blocks)
            trace=sum(mat[i][i] for i in range(3))%M
            geom=-sum(h[u]*h[z*pow(u,-1,p)%p] for u in range(1,p))
            assert (trace-geom)%M==0,(p,z,trace,geom)
            count+=1
        c=pow(-5832,-1,M)
        mat=columns(p,c,blocks)
        assert mat[0][1:]==[0,0], (p,mat[0])
    print('all smooth rational parameters:',count,'primes:',len(primes),'bound:',bound)

if __name__=='__main__':
    check()
