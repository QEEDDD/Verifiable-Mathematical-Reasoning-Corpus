#!/usr/bin/env python3
"""Exact checks for the AESZ4 level-54 attractor dossier.

Standard-library checks are used where possible; SymPy is used only for exact
symbolic polynomial factorization and matrix determinants.
"""
from __future__ import annotations

import json
from fractions import Fraction
from math import factorial
from pathlib import Path

import sympy as sp

OUT = Path(__file__).with_name("verification_output.json")


def generalized_binomial(a: Fraction, k: int) -> Fraction:
    result = Fraction(1)
    for j in range(k):
        result *= a - j
    return result / factorial(k)


def truncated_sum_mod(p: int) -> int:
    modulus = p**3
    total = Fraction(0)
    for k in range(p):
        total += (
            generalized_binomial(Fraction(-1, 3), k) ** 2
            * generalized_binomial(Fraction(-2, 3), k) ** 2
            * Fraction(-1, 8) ** k
        )
    return (total.numerator * pow(total.denominator, -1, modulus)) % modulus


def picard_fuchs_check(max_n: int = 12) -> bool:
    # c_n=(1/3)_n^2(2/3)_n^2/(n!)^4 and
    # n^4 c_n=(n-2/3)^2(n-1/3)^2 c_{n-1}.
    c = [Fraction(1)]
    for n in range(1, max_n + 1):
        c.append(
            c[-1]
            * Fraction(3 * n - 2, 3) ** 2
            * Fraction(3 * n - 1, 3) ** 2
            / n**4
        )
    return all(
        n**4 * c[n]
        == Fraction(3 * n - 2, 3) ** 2
        * Fraction(3 * n - 1, 3) ** 2
        * c[n - 1]
        for n in range(1, max_n + 1)
    )


def residual_monodromy_data() -> dict[str, object]:
    A = sp.Matrix(
        [
            [0, 0, 0, -1],
            [1, 0, 0, -2],
            [0, 1, 0, -3],
            [0, 0, 1, -2],
        ]
    )
    B = sp.Matrix(
        [
            [0, 0, 0, -1],
            [1, 0, 0, 4],
            [0, 1, 0, -6],
            [0, 0, 1, 4],
        ]
    )
    e4 = sp.Matrix([[0, 0, 0, 1]])
    v = sp.Matrix([0, -2, 1, -2])
    observability = sp.Matrix.vstack(*[e4 * (A**i) for i in range(4)])
    cyclic = sp.Matrix.hstack(*[(A**i) * v for i in range(4)])
    assert A - B == 3 * v * e4
    assert observability.det() == 1
    assert cyclic.det() == 81
    x = sp.symbols("x")
    assert sp.factor(A.charpoly(x).as_expr()) == (x**2 + x + 1) ** 2
    assert sp.factor(B.charpoly(x).as_expr()) == (x - 1) ** 4
    return {
        "A_minus_B": [[int(z) for z in row] for row in (A - B).tolist()],
        "observability_det": int(observability.det()),
        "cyclic_det": int(cyclic.det()),
        "charpoly_A": str(sp.factor(A.charpoly(x).as_expr())),
        "charpoly_B": str(sp.factor(B.charpoly(x).as_expr())),
        "mod3_flag_dimensions": [1, 2, 3, 4],
    }


def phi2_factorization() -> dict[str, str]:
    a, X, Y = sp.symbols("a X Y")
    phi2 = (
        X**3
        + Y**3
        - X**2 * Y**2
        + 1488 * X * Y * (X + Y)
        - 162000 * (X**2 + Y**2)
        + 40773375 * X * Y
        + 8748000000 * (X + Y)
        - 157464000000000
    )
    j = lambda z: 27 * (1 + 8 * z) ** 3 / (z * (1 - z) ** 3)
    expression = sp.factor(
        sp.together(phi2.subs({X: j(a), Y: j(-sp.Rational(1, 8) / a)}))
    )
    numerator, denominator = sp.fraction(expression)
    assert numerator != 0
    return {
        "numerator": str(sp.factor(numerator)),
        "denominator": str(sp.factor(denominator)),
    }


def main() -> None:
    residues = {str(p): truncated_sum_mod(p) for p in [5, 7, 11, 13, 17, 19, 23, 29, 31]}
    expected_signed = {
        "5": 3,
        "7": 29,
        "11": -57,
        "13": 20,
        "17": -72,
        "19": -106,
        "23": 174,
        "29": -210,
        "31": 47,
    }
    for p_string, signed in expected_signed.items():
        p = int(p_string)
        assert residues[p_string] == signed % (p**3)

    report = {
        "picard_fuchs_coefficient_recurrence": picard_fuchs_check(),
        "truncated_sum_mod_p3": residues,
        "signed_representatives": expected_signed,
        "residual_monodromy": residual_monodromy_data(),
        "phi2_substitution": phi2_factorization(),
    }
    OUT.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
