from time import perf_counter

def coeffs(p, maxn, prec):
    mod=p**prec
    u,v=1,0
    out=[]
    for n in range(maxn):
        out.append(u*pow(p,v,mod)%mod if v<prec else 0)
        a,b=2*n+1,2*n+2
        while a%p==0:
            a//=p;v+=1
        while b%p==0:
            b//=p;v-=1
        u=u*a*pow(b,-1,mod)%mod
        assert v>=0
    return out

def vp(n,p,prec):
    if n==0:return prec
    ans=0
    while n%p==0:ans+=1;n//=p
    return ans

start=perf_counter()
checks=0
counts=[]
for p,maxs in ((3,8),(5,6),(7,4),(11,3)):
    prec=2*maxs+3
    mod=p**prec
    largest=max(p**(maxs+1),4*p**maxs)
    a=coeffs(p,largest,prec)
    for d in range(2,9):
        for eps in (-1,1):
            prefix=[0]
            for n,x in enumerate(a):
                prefix.append((prefix[-1]+pow(x,d,mod)*(eps if n%2 else 1))%mod)
            if prefix[p]%p==0:continue
            vals=[prefix[p**s] for s in range(maxs+2)]
            min_excess=prec
            for s in range(1,maxs+1):
                defect=(vals[s+1]*vals[s-1]-vals[s]**2)%mod
                assert defect%p**(2*s)==0,(p,d,eps,s,'cross',vp(defect,p,prec))
                checks+=1
                min_excess=min(min_excess,vp(defect,p,prec)-2*s)
                for m in (2,3,4):
                    defect=(prefix[m*p**s]*vals[s-1]-vals[s]*prefix[m*p**(s-1)])%mod
                    assert defect%p**(2*s)==0,(p,d,eps,s,m,vp(defect,p,prec))
                    checks+=1
            counts.append((p,d,eps,maxs,min_excess))
    print('prime',p,'done',flush=True)
print('all exact checks passed:',checks)
print('seconds:',round(perf_counter()-start,2))
print('metadata (p,d,eps,maxs,min consecutive excess):',counts)

assert checks == 656
previously_uncovered = sum(4*max(0, maxs-d+1)
                          for p,d,eps,maxs,excess in counts)
assert previously_uncovered == 236
print("Checks in the former s >= d gap:", previously_uncovered)

