#!/usr/bin/env python3
"""Exact diagnostics for the supersingular Apery-disk theorem.

Supersingularity is tested on the displayed elliptic curve over F_(p^2),
not inferred from the Apery truncation being tested. No floating point.
"""
from math import comb


def add(x, y, p):
    return ((x[0]+y[0]) % p, (x[1]+y[1]) % p)


def scale(x, c, p):
    return (x[0]*c % p, x[1]*c % p)


def mul(x, y, p, d):
    return ((x[0]*y[0]+d*x[1]*y[1]) % p,
            (x[0]*y[1]+x[1]*y[0]) % p)


def power(x, k, p, d):
    ans = (1, 0)
    while k:
        if k & 1:
            ans = mul(ans, x, p, d)
        x = mul(x, x, p, d)
        k >>= 1
    return ans


def ss_residues(p):
    d = next(i for i in range(2, p) if pow(i, (p-1)//2, p) == p-1)
    roots = []
    for t in range(1, p):
        disc = (1-34*t+t*t) % p
        if not disc:
            continue
        if pow(disc, (p-1)//2, p) == 1:
            root = (next(i for i in range(p) if i*i % p == disc), 0)
        else:
            ratio = disc * pow(d, -1, p) % p
            root = (0, next(i for i in range(p) if i*i % p == ratio))
        h = scale(add((1-17*t, 0), root, p), pow(144*t, -1, p), p)
        h2 = mul(h, h, p, d)
        a = scale(add(add((1, 0), scale(h, 12, p), p), scale(h2, 24, p), p),
                  pow(4, -1, p), p)
        b = mul(power(h, 3, p, d), add((1, 0), scale(h, 9, p), p), p, d)
        m = (p-1)//2
        hasse = (0, 0)
        for j in range(m//2+1):
            term = mul(power(a, m-2*j, p, d), power(b, j, p, d), p, d)
            hasse = add(hasse, scale(term, comb(m, j)*comb(m-j, j), p), p)
        if hasse == (0, 0):
            roots.append(t)
    return roots


def apery_coefficients(length, modulus):
    last, a = 0, 1
    result = []
    for n in range(length):
        result.append(a % modulus)
        numerator = (2*n+1)*(17*n*(n+1)+5)*a-n**3*last
        denominator = (n+1)**3
        assert numerator % denominator == 0
        last, a = a, numerator//denominator
    return result


def evaluate(coefficients, t, modulus):
    value = 0
    for c in reversed(coefficients):
        value = (value*t+c) % modulus
    return value


def valuation_residue(value, p, precision):
    value %= p**precision
    if value == 0:
        return f">={precision}"
    v = 0
    while value % p == 0:
        value //= p
        v += 1
    return v


def main():
    rows = []
    precision = 10
    for p in (5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43):
        modulus = p**precision
        coeffs = apery_coefficients(p*p, modulus)
        residues = ss_residues(p)
        for residue in residues:
            for t in (residue, residue+p):
                defect = evaluate(coeffs, t, modulus)-p*p
                val = valuation_residue(defect, p, precision)
                assert isinstance(val, str) or val >= 5
                rows.append(dict(p=p, t=t, s=2, m=1, defect_valuation=val))
        print(p, residues, flush=True)
    for p, t, depth in ((5, 6, 4), (5, 11, 4), (5, 4, 4),
                        (5, 9, 4), (7, 8, 3), (7, 15, 3),
                        (11, 10, 3), (11, 21, 3)):
        assert t % p in ss_residues(p)
        precision = 3*depth+4
        modulus = p**precision
        coeffs = apery_coefficients(p**depth, modulus)
        vals = {s:evaluate(coeffs[:p**s], t, modulus) for s in range(depth+1)}
        for s in range(2, depth+1):
            val = valuation_residue(vals[s]-p*p*vals[s-2], p, precision)
            assert isinstance(val, str) or val >= 3*s-1
            rows.append(dict(p=p, t=t, s=s, m=1, defect_valuation=val))
    assert len(rows) == 94
    print(f'{len(rows)} exact supersingular-disk checks passed')


if __name__ == '__main__':
    main()

