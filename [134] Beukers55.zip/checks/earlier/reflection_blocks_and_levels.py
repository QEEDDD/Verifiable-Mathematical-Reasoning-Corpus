def primes(bound):
    return [p for p in range(3, bound + 1, 2)
            if all(p % j for j in range(3, int(p**0.5) + 1, 2))]

def coefficients(length, modulus):
    b, inv4, q, out = 1, pow(4, -1, modulus), 1, []
    for k in range(length):
        out.append((b % modulus) * q % modulus)
        b = b * 2 * (2*k + 1) // (k + 1)
        q = q * inv4 % modulus
    return out

def terms(a, d, eps, modulus):
    return [pow(x, d, modulus) * (eps if k % 2 else 1) % modulus
            for k, x in enumerate(a)]

block_checks = 0
for p in primes(43):
    modulus, N = p*p, (p-1)//2
    a = coefficients(3*p, modulus)
    for d in range(2, 2*p + 3):
        for eps in (-1, 1):
            if (-1)**(d*N) * eps**N != 1:
                continue
            c = terms(a, d, eps, modulus)
            fp = sum(c[:p]) % modulus
            for m in (1, 2, 3):
                assert (sum(c[:m*p]) - fp*sum(c[:m])) % modulus == 0
                block_checks += 1

level_checks = 0
for p in (3, 5, 7, 11, 13, 17, 19, 29, 37):
    modulus = p*p
    max_level = 3 if p <= 7 else 2
    a = coefficients(p**max_level, modulus)
    for d in range(2, 13):
        for eps in (-1, 1):
            c = terms(a, d, eps, modulus)
            values = [sum(c[:p**s]) % modulus
                      for s in range(1, max_level + 1)]
            if values[0] % p == 0:
                continue
            for s in range(1, len(values)):
                assert (values[s] - values[0]*values[s-1]) % modulus == 0
                level_checks += 1

assert block_checks == 2583
assert level_checks == 178
print("Block checks:", block_checks, "; level checks:", level_checks)

checks = 0
for p, maxs in ((3,5), (5,4), (7,3), (11,2), (13,2), (17,2)):
    modulus = p**(2*maxs + 1)
    a = coefficients(p**(maxs + 1), modulus)
    for d in range(2, 13):
        for eps in (-1, 1):
            c = terms(a, d, eps, modulus)
            f = [1] + [sum(c[:p**j]) % modulus
                       for j in range(1, maxs + 2)]
            if f[1] % p == 0:
                continue
            for s in range(1, maxs + 1):
                exponent = min(2*s, s+d-1)
                assert (f[s+1]*f[s-1] - f[s]**2) % p**exponent == 0
                checks += 1
assert checks == 256
print("Level-dependent cross-difference checks:", checks)
