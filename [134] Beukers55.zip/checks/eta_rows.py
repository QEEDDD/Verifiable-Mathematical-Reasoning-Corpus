"""Emit the weight-four eta-basis coefficients used by range_check.cpp."""
import sys
from sympy import Matrix
from verify_finite import BASIS, STURM, check_cusp_form, eta_series
for row in BASIS:
    check_cusp_form(row)
tab=Matrix([eta_series(row,5*STURM) for row in BASIS]).T
assert tab[1:STURM+1,:].rank()==len(BASIS)==21
eqs=[]
for p,e in [(2,2),(3,0),(5,3)]:
    for j in range(1,STURM+1):
        v=tab[p*j,:]-e*tab[j,:]
        if p==5 and j%p==0:
            v+=p**3*tab[j//p,:]
        eqs.append(v)
ker=Matrix.vstack(*eqs).nullspace()
assert len(ker)==1
coeff=ker[0]/(tab[1,:]*ker[0])[0]
print(int(sys.argv[1]))
for c,row in zip(coeff,BASIS):
    assert (2*c).is_Integer
    print(int(2*c),*row)
