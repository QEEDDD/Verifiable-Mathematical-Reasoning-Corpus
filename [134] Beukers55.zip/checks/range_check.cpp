// Compile with c++ -O3 -std=c++17. Input: bound followed by (2*coefficient, 8 eta exponents) rows.
#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <vector>
using u64 = std::uint64_t;
using u128 = __uint128_t;
constexpr std::array<int,8> divisors{1,2,3,6,9,18,27,54};

// Multiply or divide by Euler's product E(q^d). Unsigned arithmetic is in Z/(2^64).
void euler(std::vector<u64>& a, int d, bool divide) {
    int limit = int(a.size())-1;
    std::vector<std::pair<int,int>> coefficients;
    for (int j=1; d*j*(3LL*j-1)/2<=limit; ++j)
        for (int h : {-1,1}) {
            int shift = int(d*j*(3LL*j+h)/2);
            if (shift<=limit) coefficients.emplace_back(shift,j%2?-1:1);
        }
    if (divide) {
        for (int k=1;k<=limit;++k) {
            u64 val=a[k];
            for (auto [shift,sign] : coefficients) {
                if (shift>k) break;
                if (sign==1) val-=a[k-shift]; else val+=a[k-shift];
            }
            a[k]=val;
        }
    } else {
        auto old=a;
        for (auto [shift,sign] : coefficients)
            for (int k=shift;k<=limit;++k)
                if (sign==1) a[k]+=old[k-shift]; else a[k]-=old[k-shift];
    }
}
int main() {
    int bound, twice;
    if (!(std::cin>>bound) || bound<5 || bound>200000) return 1;
    std::vector<u64> form(bound+1);
    while (std::cin>>twice) {
        std::array<int,8> exponents{};
        int shift=0;
        for (int i=0;i<8;i++) {
            if (!(std::cin>>exponents[i])) return 2;
            shift+=divisors[i]*exponents[i];
        }
        if (shift%24||shift<=0) return 3;
        shift/=24;
        if (shift>bound||twice==0) continue;
        std::vector<u64> a(bound-shift+1);
        a[0]=1;
        for (int i=0;i<8;i++)
            for(int k=0;k<std::abs(exponents[i]);k++)
                euler(a,divisors[i],exponents[i]<0);
        for (int j=0;j<=bound-shift;j++) form[j+shift]+=u64(twice)*a[j];
    }
    if(form[1]!=2 || form[2]!=4 || form[5]!=6) return 4;
    int count=0, nonordinary=0, last=0;
    std::int64_t last_a=0;
    std::vector<bool> composite(bound+1);
    for(int n=2;n<=bound/n;n++) if(!composite[n])
        for(int j=n*n;j<=bound;j+=n) composite[j]=true;
    for(int p=5;p<=bound;p++) if(!composite[p]) {
        if(form[p]&1) return 5;
        // Deligne: |2*a_p| <= 4*p^(3/2), so signed lift is unique within this bound.
        std::int64_t twice_a = form[p] < (u64(1)<<63) ? (std::int64_t)form[p]
                                      : -(std::int64_t)(~form[p])-1;
        auto a=twice_a/2;
        u64 mod=u64(p)*p*p;
        if(u128(twice_a<0?-twice_a:twice_a)*(twice_a<0?-twice_a:twice_a)>16*u128(mod)) return 6;
        u64 product=1, denom=1, sum=1;
        for(u64 k=1;3*k<2*u64(p);k++) {
            u64 base=(3*k-1)*(3*k-2), k2=k*k;
            u64 num=u128(base)*base%mod, d=mod-u128(648)*k2*k2%mod;
            product=u128(product)*num%mod;
            sum=(u128(sum)*d+product)%mod;
            denom=u128(denom)*d%mod;
        }
        u64 amod = (std::int64_t(mod)+a)%std::int64_t(mod);
        if(sum!=u128(amod)*denom%mod) {
            std::cout<<"FAIL "<<p<<" "<<a<<"\n"; return 7;
        }
        if(a%p==0){std::cout<<"nonordinary "<<p<<" "<<a<<"\n";nonordinary++;}
        last=p;last_a=a;count++;
    }
    std::cout<<"bound "<<bound<<", verified "<<count<<", nonordinary "<<nonordinary
             <<", last "<<last<<", a_last "<<last_a<<"\n";
}
