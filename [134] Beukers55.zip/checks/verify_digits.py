"""Check the Jacobi-sum digit formulas against direct torus point counts.

Run this script from the directory also containing verify_traces.py.
No extra packages are needed. The default checks every prime 5 through 199.
"""
from argparse import ArgumentParser
from math import factorial, isqrt, prod

from verify_traces import primes_up_to, toric_trace, truncated_sum


def digit_formulas(p):
    modulus = p**3
    c = pow(-5832, -1, modulus)
    teich = pow(c, p*p, modulus)
    q = ((pow(c, p-1, p*p)-1)//p) % p
    harmonic = [0]
    for j in range(1, p):
        harmonic.append((harmonic[-1]+pow(j, -1, p)) % p)
    m, n = (p-1)//3, 2*(p-1)//3
    v = pow(3, -1, modulus)
    ellipse_low = ellipse_mid = 0
    low = 0
    correction = 0
    single = 0
    for k in range(m+1):
        delta = p*k*pow(p-1, -1, modulus) % modulus
        num = prod(j-3*delta for j in range(1,3*k+1)) % modulus
        den = prod(j-delta for j in range(1,k+1)) % modulus
        w = num*pow(den, -3, modulus) % modulus
        ellipse_low += pow(v, p*k, p*p)*w
        low += pow(teich, k, modulus)*w*w
        Ak = factorial(3*k)//factorial(k)**3
        single = (single + Ak*pow(3,-k,p)) % p
        correction += Ak*Ak*pow(c,k,p)*(1+k*q+6*k*(harmonic[3*k]-harmonic[k]))
    mid = 0
    for k in range(m+1,n+1):
        w = factorial(3*k-p+1)*pow(factorial(k),-3,p) % p
        ellipse_mid = (ellipse_mid+pow(v,k,p)*w) % p
        mid = (mid+pow(c,k,p)*w*w) % p
    trace = (low + p*p*mid)*pow(1-p,-1,modulus) % modulus
    elliptic = (ellipse_low-p*ellipse_mid)*pow(1-p,-1,p*p) % (p*p)
    return trace, correction % p, single, elliptic


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("bound", nargs="?", type=int, default=199)
    args = parser.parse_args()
    checked = 0
    for prime in primes_up_to(args.bound):
        total = toric_trace(prime)[1]
        S = truncated_sum(prime)
        pred, correction, single, elliptic = digit_formulas(prime)
        assert (pred-total) % prime**3 == 0, (prime, total, pred)
        assert (total-S-prime*correction) % prime**2 == 0, (prime, correction)
        # Independently count the short model y^2=x^3+189x+702 of curve 54.a3.
        squares = {x*x % prime for x in range(1, prime)}
        rhs = [(x**3+189*x+702) % prime for x in range(prime)]
        b = sum(-1 if value in squares else 1 for value in rhs if value)
        radius = isqrt(4*prime)
        eligible = [u for u in range(-radius,radius+1)
                    if u % prime == single and (u-prime-1) % 3 == 0]
        assert (elliptic-b) % prime**2 == 0, (prime, elliptic, b)
        assert eligible == [b], (prime, single, b)
        assert correction == single, (prime, correction, single)
        assert (pred-S-prime*b) % prime**3 == 0, (prime, pred, S, b)
        checked += 1
    print(f"Trace formulas and elliptic criteria checked for {checked} primes 5 through {args.bound}.")
