#!/usr/bin/env python3
"""Exact finite certificate for Beukers 1.28, good primes up to 5000 by default.

Run: python3 verify_finite.py [upper_bound]. Dependency: sympy.
Python 3.12+ is faster because it has math.sumprod. Use Python 3.9+.

The target is the unique normalized element of S_4(Gamma_0(54)) with
U_2 f=2f, U_3 f=0, T_5 f=3f. The program proves the uniqueness by rational
linear algebra; the three specified eigenvalues for 54.4.a.c are listed at
https://www.lmfdb.org/ModularForm/GL2/Q/holomorphic/54/ .

The index of Gamma_0(54) in PSL_2(Z) is 108. There are 12 cusps and no
elliptic fixed points of either order (level divisible by 3 and by 9,
respectively, with -1 a nonresidue modulo 3). Thus X_0(54) has genus
1+108/12-12/2=4 and dim S_4=(4-1)(4-1)+(4/2-1)*12=21. The weight-4
Sturm bound is floor(4*108/12)=36. All eta quotients below are tested
using the eta-quotient transformation criterion and Ligozat's cusp-order
formula. Their independence is then checked over Q. The output does
not use residues of the hypergeometric sum to identify a Fourier coefficient.
"""

import argparse
from math import gcd, lcm
from operator import mul

from sympy import Matrix, primerange

try:
    from math import sumprod  # Exact for sequences of Python integers.
except ImportError:
    def sumprod(left, right):
        return sum(map(mul, left, right))


LEVEL = 54
STURM = 36
DIVISORS = (1, 2, 3, 6, 9, 18, 27, 54)

# Each row stands for the eta quotient product over d|54 of eta(d*tau)^r_d.
BASIS = (
    (0, 0, 0, 0, 0, 8, 0, 0), (0, 0, 0, 0, 2, 2, 2, 2),
    (0, 0, 0, 0, 8, 0, 0, 0), (0, 0, 0, 1, 0, 4, 0, 3),
    (0, 0, 0, 2, 0, 0, 0, 6), (0, 0, 0, 4, 0, 4, 0, 0),
    (0, 0, 0, 5, 0, 0, 0, 3), (0, 0, 0, 8, 0, 0, 0, 0),
    (0, 0, 1, 0, 4, 0, 3, 0), (0, 0, 1, 1, 2, 2, 1, 1),
    (0, 0, 2, 0, 0, 0, 6, 0), (0, 0, 4, 0, 4, 0, 0, 0),
    (0, 0, 5, 0, 0, 0, 3, 0), (0, 0, 8, 0, 0, 0, 0, 0),
    (1, 1, 0, 0, 1, 1, 2, 2), (1, 1, 1, 1, 1, 1, 1, 1),
    (1, 1, 2, 2, 1, 1, 0, 0), (-1, -1, 2, 6, 3, -1, 0, 0),
    (-1, -1, 3, 4, 2, 0, 2, -1), (-1, -1, 3, 6, -1, -1, 3, 0),
    (-1, 2, -1, -1, 7, 4, -1, -1),
)


def require(condition, message):
    if not condition:
        raise ArithmeticError(message)


def valuation(n, p):
    e = 0
    while n % p == 0:
        n //= p
        e += 1
    return e


def check_cusp_form(exponents):
    factors = list(zip(DIVISORS, exponents))
    require(len(exponents) == len(DIVISORS) and sum(exponents) == 8,
            "wrong weight for eta quotient")
    require(sum(d*r for d, r in factors) % 24 == 0 and
            sum((LEVEL//d)*r for d, r in factors) % 24 == 0,
            "eta transformation criterion failed")
    # (-1)^4 product(d^r_d) must be a rational square for trivial character.
    for p in (2, 3):
        require(sum(valuation(d, p)*r for d, r in factors) % 2 == 0,
                "nontrivial eta character")
    for c in DIVISORS:
        # This equals 24*c*gcd(c,54/c) times the cusp order at denominator c.
        order_numerator = sum((LEVEL//d)*gcd(c, d)**2*r for d, r in factors)
        require(order_numerator > 0, "zero or negative cusp order")


def eta_series(exponents, bound):
    """Coefficients of one eta quotient via its exact logarithmic derivative."""
    terms = [(d, r) for d, r in zip(DIVISORS, exponents) if r]
    initial_order = sum(d*r for d, r in terms) // 24
    if initial_order > bound:
        return [0] * (bound+1)
    stride = gcd(*(d for d, _ in terms))
    terms = [(d//stride, r) for d, r in terms]
    n = (bound-initial_order)//stride
    b = [0] * (n+1)
    for d, r in terms:
        for j in range(d, n+1, d):
            for k in range(j, n+1, j):
                b[k] += r*j
    # For the series stripped of q^initial_order and written in Q=q^stride,
    # Q A'(Q)/A(Q) = -sum_{j>=1} b[j] Q^j.
    a = [1]
    for k in range(1, n+1):
        q, rem = divmod(-sumprod(a, b[k:0:-1]), k)
        require(rem == 0, "nonintegral eta coefficient")
        a.append(q)
    result = [0] * (bound+1)
    result[initial_order::stride] = a
    return result


def modular_coefficients(bound):
    for row in BASIS:
        check_cusp_form(row)
    small = Matrix([eta_series(row, 5*STURM) for row in BASIS]).T
    dimension = small[1:STURM+1, :].rank()
    require(dimension == len(BASIS) == 21, "basis rank failed")
    equations = []
    dimensions = []
    for p, eigenvalue in ((2, 2), (3, 0), (5, 3)):
        for n in range(1, STURM+1):
            equation = small[p*n, :] - eigenvalue*small[n, :]
            if LEVEL % p and n % p == 0:
                equation += p**3*small[n//p, :]
            equations.append(equation)
        kernel = Matrix.vstack(*equations).nullspace()
        dimensions.append(len(kernel))
    require(dimensions == [4, 3, 1], "unexpected simultaneous eigenspaces")
    coeff = kernel[0] / (small[1, :]*kernel[0])[0]
    denominator = lcm(*(int(c.q) for c in coeff))
    out = [0] * (bound+1)
    for row, c in zip(BASIS, coeff):
        if c:
            multiplier = int(denominator*c)
            terms = eta_series(row, bound)
            out = [v+multiplier*w for v, w in zip(out, terms)]
    require(all(v % denominator == 0 for v in out), "nonintegral newform coefficient")
    return [v//denominator for v in out]


def hypergeometric_residue(p, exponent=4):
    """Retain exactly all terms possibly nonzero modulo p^4, p>=5."""
    modulus = p**exponent
    value = total = 1
    # (3k)!/(k!)^3 has valuation floor(3k/p) for 0<=k<p.
    # Its square contributes zero modulo p^4 when k>floor(2p/3).
    for j in range(1, 2*p//3+1):
        numerator = ((3*j-2)*(3*j-1))**2
        value = value*numerator*pow(-648*j**4, -1, modulus) % modulus
        total += value
    return total % modulus


def main(bound):
    require(bound >= 5, "upper bound must be at least 5")
    coeff = modular_coefficients(bound)
    primes = list(primerange(5, bound+1))
    failures, higher, nonordinary = [], [], []
    for p in primes:
        a = coeff[p]
        residue = hypergeometric_residue(p)
        if (residue-a) % p**3:
            failures.append((p, a, residue))
        if (residue-a) % p**4 == 0:
            higher.append(p)
        if a % p == 0:
            nonordinary.append((p, a))
    print("upper bound:", bound, "number of good primes:", len(primes))
    print("failures modulo p^3:", failures)
    print("congruences also holding modulo p^4:", higher)
    print("nonordinary primes and coefficients:", nonordinary)
    print("last prime, coefficient, residue modulo p^3:", p, a, residue % p**3)
    return int(bool(failures))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("upper_bound", type=int, nargs="?", default=5000)
    raise SystemExit(main(parser.parse_args().upper_bound))
