"""Recover the four requisite Euler polynomials by counting over F_p and F_p^2.

No external packages. Elements a+b*w of F_p[w]/(w^2-d) are coded a+p*b.
"""
from collections import Counter


def trace(p, degree):
    q = p ** degree
    d = next(x for x in range(2, p) if pow(x, (p-1)//2, p) == p-1)
    def mul(x, y):
        a, b = x % p, x // p
        e, f = y % p, y // p
        return (a*e+b*f*d) % p + p*((a*f+b*e) % p)
    def inv(x):
        a, b = x % p, x // p
        norm_inv = pow((a*a-b*b*d) % p, -1, p)
        return (a*norm_inv) % p + p*((-b*norm_inv) % p)
    c = pow(-5832, -1, p)
    count = Counter()
    for x in range(1, q):
        for y in range(1, q):
            z = (1-(x % p)-(y % p)) % p + p*((-(x//p)-(y//p)) % p)
            if z:
                count[mul(mul(x, y), z)] += 1
    moments = sum(count[u]*count[mul(c, inv(u))] for u in range(1,q))
    return q**3 - 5*q*q + 10*q - 8 - moments


if __name__ == "__main__":
    traces = {5: (3, 3), 7: (29, -1), 13: (20, -4), 19: (-106, 2)}
    for p, (a, b) in traces.items():
        t, t2 = trace(p, 1), trace(p, 2)
        assert (t*t-t2) % 2 == 0
        e2 = (t*t-t2)//2
        assert t == a + p*b
        assert e2 == 2*p**3 + a*p*b
        print(f"p={p:2}  tr(F)={t:4}  tr(F^2)={t2:7}  e2={e2:6}  pair=({a},{p*b})")
