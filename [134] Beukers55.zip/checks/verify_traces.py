"""Exact finite checks for the AESZ4 torus and reciprocal-j pencils (Python 3).

Default: verify each prime 5 <= p <= 199. Independent modular-form data are
not input to this script; the finite comparisons concern the displayed formulas.
"""
from argparse import ArgumentParser
from math import comb, isqrt


def primes_up_to(bound):
    for n in range(5, bound + 1):
        if all(n % d for d in range(2, isqrt(n) + 1)):
            yield n


def legendre_table(p):
    signs = [-1] * p
    signs[0] = 0
    for a in range(1, p):
        signs[a * a % p] = 1
    return signs


def truncated_sum(p):
    mod = p**3
    c = pow(-5832, -1, mod)
    return sum(comb(3*k, k)**2 * comb(2*k, k)**2 * pow(c, k, mod)
               for k in range(p)) % mod


def toric_trace(p):
    c = pow(-5832, -1, p)
    counts = [0] * p
    for x in range(1, p):
        for y in range(1, p):
            z = (1 - x - y) % p
            if z:
                counts[x*y*z % p] += 1
    assert sum(counts) == p*p - 3*p + 3
    mates = {a: c * pow(a, -1, p) % p for a in range(1, p)}
    point_count = sum(counts[a] * counts[b] for a, b in mates.items())
    trace = -sum((p - 2 - counts[a]) * (p - 2 - counts[b])
                 for a, b in mates.items())
    assert trace == p**3 - 5*p*p + 10*p - 8 - point_count
    return point_count, trace


def reciprocal_j_trace(p):
    signs = legendre_table(p)
    local = {}
    for w in range(2, p):
        A = -3*w*(w-1)
        B = 2*w*(w-1)**2
        local[w] = -sum(signs[(x**3 + A*x + B) % p] for x in range(p))
    smooth_sum = sum(a * local[pow(w, -1, p)] for w, a in local.items())
    ramified = 0 if p % 4 == 3 else 2*p*(-1)**((p-1)//4)
    return signs[-2] * (-smooth_sum - ramified)


def check(bound, details):
    tested = 0
    nonordinary = []
    for p in primes_up_to(bound):
        S = truncated_sum(p)
        count, total = toric_trace(p)
        projected = reciprocal_j_trace(p)
        assert (S + 8 + count) % p == 0, (p, "toric reduction")
        assert (total - projected) % p == 0, (p, "Tate-twisted trace")
        assert (S - projected) % p**3 == 0, (p, "reciprocal-j comparison")
        if projected % p == 0:
            nonordinary.append(p)
        if details:
            print(p, S, total, projected, (total - projected)//p, sep="\t")
        tested += 1
    print(f"Verified {tested} primes, 5 <= p <= {bound}")
    print(f"Projected trace divisible by p: {nonordinary}")


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("bound", nargs="?", type=int, default=199)
    parser.add_argument("--details", action="store_true",
                        help="list p, S mod p^3, total and projected traces, and their difference / p")
    args = parser.parse_args()
    check(args.bound, args.details)
