CERTIFIED PRIME EXTENSIONS AND UNIFORM COEFFICIENT BOUNDS
Prepared 8 November 2026 for Keio

MAIN RESULTS AND LIMITS

The existing corpus chain ends at r=62988*p5+1, with 18,886 decimal digits.
This work proves P=2347*2^8192*r+1 prime, with 21,356 decimal digits.
The comparison concerns those constructed certificate endpoints, not the
much larger pre-existing Mersenne prime cited as a benchmark in [130].
The separate 39,000-digit Proth search produced no certified prime.

P is defined entirely by the recurrence in the paper and verifier. Its
prime certificate depends on the independently replayed corpus chain.
The archive does not assert a world record or historical first discovery.

The paper proves Philemon's original implication for every coefficient
1<=a<=64 and for an explicit coefficient set with lower asymptotic density
at least 9/10. These statements hold for ALL admissible m, not merely a
finite computational range. The exact finite coefficient-count bound is
X-floor(X/10). The original unrestricted conjecture remains unresolved
in this work. Allocation and product-expansion methods have prior
antecedents; priority for the quantitative bound is not established.

For OEIS A359504, the paper derives every-prime occurrence and eventual
uniqueness from published representation theorems. The finite experiment
checks 3,795,778 terms. The unspecified exceptional range is NOT closed.
No original named conjecture satisfying all six requested gates is claimed.

EXACT PRIME VERIFICATION

Run from the extracted archive root:

    python3 verify_certificates.py

Python 3 exact integers are sufficient. The optional gmpy2 module speeds
up the same arithmetic; our replay used gmpy2 2.3.2 with GMP 6.3.0.
The verifier requires no network, integer input file, or primality oracle.
It proves 2 and 7 by trial division, then replays every Pocklington
dependency and the new certificate(s). A search program's PRP message is
not used as a proof. Success ends with ALL CERTIFICATES PASSED.

Canonical integer fingerprints hash decimal ASCII WITHOUT a trailing
newline. The supplied *_prime.txt files have a convenience final newline;
strip whitespace before comparing their decimal fingerprints.
MANIFEST.json instead hashes the raw bytes of every archived file.

STANDALONE PAPER

The included .tex is a complete source with inline bibliography and code.
There are no external inputs, figures, .bib files, or custom style files.
Compile twice with pdflatex, for example:

    pdflatex Certified_Prime_Extensions_and_Open_Problem_Audit.tex
    pdflatex Certified_Prime_Extensions_and_Open_Problem_Audit.tex

The PDF is supplied separately with the same base filename.

SEARCH PROVENANCE

Corpus snapshot:
c30d40119134a59eda6fa5cc6331f27c8e67d034
https://github.com/QEEDDD/Verifiable-Mathematical-Reasoning-Corpus

The original corpus is CC BY 4.0. Seed definitions and certificate
parameters are attributed to Keio's manuscripts [129] and [130].

OpenPFGW 4.1.8 / GWNUM 31.5 was used only as the search engine.
The downloaded Linux archive had SHA-256:
aadf885e2d6489866bb7eeea2ba3f75a3fa02e679f1d6a86fd2632e042a99c99
https://sourceforge.net/projects/openpfgw/files/pfgw_linux_4.1.8.7z/
Third-party binaries are not redistributed in this archive.

Final search summaries (completed tests, software passes, software rejects):
  Lineage: 69, 1, 68
  Earlier n=131072 large-coefficient run: 285, 0, 285
  Separate n=131113 Proth run: 3429, 0, 3429

The search workers can finish out of coefficient order. Journals preserve
each tested coefficient, expression, program output, and elapsed time.
Software rejections are not required by the successful prime proof.
The n=131113 execution ended without a terminal summary. Its final_audit.json
reconciles every complete durable journal record; the earlier periodic
status.json is retained unchanged. Unlogged candidates are not classified.

OPTIONAL SEARCH REPRODUCTION

For a new search, copy the scripts and candidate files into a new working
tree with the same directory layout, keeping the archived *_search folders
separate. The program appends to journals when output folders already exist.
Place your own OpenPFGW executable at research/prime_strategy/pfgw/pfgw64.
Compile the sieve from the archive root:

    g++ -O3 -std=c++17 research/compute/sieve_proth.cpp -o sieve_proth

Recreate the lineage candidate file and run its three workers:

    ./sieve_proth 8192 1000000 100000000 lineage 1 research/compute/lineage_candidates.txt
    python3 research/compute/search_pfgw.py lineage --n 8192 --workers 3

The other retained search configurations are documented in their sieve
logs and status files. Optional searches are not guaranteed to reproduce
the same completion order or runtime. A STOP file in a *_search directory
requests a stop after the currently running candidates finish.

OTHER EXACT COMPUTATIONS

The giant-candidate audit tests all primes through 10^9 and finds no
factor of the two old candidates. This DOES NOT prove their primality.

    g++ -O3 -std=c++17 research/corpus/audit_giant_small_factors.cpp -o audit
    ./audit 1000000000

The OEIS experiment can be rerun from the archive root:

    g++ -O3 -std=c++17 research/named_problem/frontier.cpp -o frontier
    ./frontier 100000000 1

The experiment uses a substantial prime-factor array (hundreds of MB).
Its plus-sign mode is the one used in the paper. The optional minus-sign
mode supplies no claimed theorem here. The first 5,000 terms were checked
against the full official OEIS b-file. Available subset products popped
from the heap and selected eligible products are different counts.

The JSON file philemon_64_exact_checks.json records exact rational
arithmetic used in the analytical proof. The proof itself, including the
exhaustive coefficient-pattern classification, is in the paper.
