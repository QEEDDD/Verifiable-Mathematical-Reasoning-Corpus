"""Reproducible bounded sieve-survivor search; search output needs exact replay."""
import argparse, concurrent.futures, hashlib, json, os, pathlib, re, subprocess, threading, time

ROOT=pathlib.Path(__file__).resolve().parent
PFGW=ROOT.parent/'prime_strategy/pfgw/pfgw64'
seed='(14^512-14^256+1)'
for c in (438,13696,5494,13258,22330): seed=f'({c}*{seed}^2+1)'
RECORD=f'(62988*{seed}+1)'

def main():
 ap=argparse.ArgumentParser();ap.add_argument('family',choices=['plain','lineage']);ap.add_argument('--n',type=int,required=True);ap.add_argument('--label');ap.add_argument('--workers',type=int,default=4);ap.add_argument('--limit',type=int,default=12000);args=ap.parse_args()
 family=args.family;label=args.label or family;ks=[int(s) for s in (ROOT/f'{label}_candidates.txt').read_text().split()][:args.limit]
 outdir=ROOT/f'{label}_search';outdir.mkdir(exist_ok=True)
 stopped=threading.Event();lock=threading.Lock();stats={'started':0,'completed':0,'rejected':0,'errors':0,'passes':0};start=time.time()
 def write_status():
  (outdir/'status.json').write_text(json.dumps({**stats,'elapsed_seconds':time.time()-start,'family':family,'n':args.n,'workers':args.workers},indent=2))
 def worker(w):
  wd=outdir/f'worker_{w}';wd.mkdir(exist_ok=True)
  with (wd/'journal.jsonl').open('a',buffering=1) as log:
   for idx in range(w,len(ks),args.workers):
    if stopped.is_set() or (outdir/'STOP').exists():break
    k=ks[idx];expr=f'{k}*2^{args.n}+1' if family=='plain' else f'{k}*{RECORD}*2^{args.n}+1'
    cmd=[str(PFGW),'-T1','-f0','-u0','-r']+(['-tm'] if family=='plain' else ['-b2'])+['-q'+expr]
    with lock:stats['started']+=1
    begin=time.time();p=subprocess.run(cmd,cwd=wd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    result=p.stdout.replace('\r','\n');dt=time.time()-begin
    passed=bool(re.search(r'\bis prime!|\bis (?:a )?(?:\d+-)?PRP\b',result,re.I))
    rejected=bool(re.search(r'\bis composite|\bis not prime|\bis not (?:a )?(?:\d+-)?PRP|\bis factored',result,re.I))
    # Never promote an unrecognized status into a success or composite result.
    rec={'index':idx,'k':k,'expression':expr,'seconds':dt,'returncode':p.returncode,'passed':passed,'rejected':rejected,'output':result}
    log.write(json.dumps(rec)+'\n')
    with lock:
     stats['completed']+=1;stats['passes']+=int(passed);stats['rejected']+=int(rejected and not passed);stats['errors']+=int(not passed and not rejected)
     if passed:
      (outdir/f'pass_{k}.json').write_text(json.dumps(rec,indent=2));stopped.set();print('PASS',family,k,flush=True)
     if stats['completed']%25==0 or passed:write_status();print(family,stats,'elapsed',round(time.time()-start,1),flush=True)
  return w
 with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
  list(pool.map(worker,range(args.workers)))
 with lock:write_status()
 print('FINISHED',family,stats,'elapsed',time.time()-start,flush=True)
if __name__=='__main__':main()
