#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <vector>
#include <chrono>
using U = std::uint64_t;
U power(U a,U e,U p){U r=1;while(e){if(e&1)r=r*a%p;e>>=1;if(e)a=a*a%p;}return r;}
U inverse(U a,U p){std::int64_t t=0,nt=1,r=p,nr=a;while(nr){auto q=r/nr;auto v=t-q*nt;t=nt;nt=v;v=r-q*nr;r=nr;nr=v;}if(r!=1)return 0;if(t<0)t+=p;return t;}
U record_mod(U p){U x=power(14,256,p);U z=(x*x%p+p-x+1)%p;for(U k: {438ULL,13696ULL,5494ULL,13258ULL,22330ULL})z=(k*(z*z%p)+1)%p;return(62988*z+1)%p;}
int main(int argc,char**argv){
 if(argc!=7){std::cerr<<"n count bound plain|lineage odd_start outfile\n";return 2;}
 U n=std::strtoull(argv[1],0,10), count=std::strtoull(argv[2],0,10), B=std::strtoull(argv[3],0,10);bool lin=std::string(argv[4])=="lineage";
 U kstart=std::strtoull(argv[5],0,10);if(B>1000000000ULL||count>100000000ULL||!(kstart&1))return 2;
 auto start=std::chrono::steady_clock::now();
 std::vector<bool> composite(B/2+1,false),blocked(count,false);
 for(U p=3;p*p<=B;p+=2)if(!composite[p/2])for(U j=p*p;j<=B;j+=2*p)composite[j/2]=true;
 U primes=1;
 for(U p=3;p<=B;p+=2)if(!composite[p/2]){
  ++primes;U c=power(2,n,p);if(lin)c=c*record_mod(p)%p;
  if(!c)continue;
  U k0=p-inverse(c,p), m0=((k0+p-kstart%p)%p)*((p+1)/2)%p;
  for(U j=m0;j<count;j+=p)blocked[j]=true;
 }
 std::ofstream out(argv[6]);U survivors=0;for(U j=0;j<count;++j)if(!blocked[j]){out<<2*j+kstart<<'\n';++survivors;}
 std::cout<<"n="<<n<<" family="<<(lin?"lineage":"plain")<<" kstart="<<kstart<<" odd_candidates="<<count<<" sieve_bound="<<B<<" primes="<<primes<<" survivors="<<survivors<<" seconds="<<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<std::endl;
}
