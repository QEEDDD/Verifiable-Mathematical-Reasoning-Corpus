#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <vector>
#include <chrono>

static std::uint64_t power_mod(std::uint64_t a, std::uint64_t e, std::uint64_t m) {
    std::uint64_t r=1;
    while(e) { if(e&1) r=r*a%m; e>>=1; if(e) a=a*a%m; }
    return r;
}

int main(int argc,char**argv) {
    const std::uint64_t bound=argc>1 ? std::strtoull(argv[1],nullptr,10) : 100000000;
    if(bound>1000000000ULL) return 2;
    auto begin=std::chrono::steady_clock::now();
    std::vector<bool> composite(bound/2+1,false);
    for(std::uint64_t p=3;p*p<=bound;p+=2) if(!composite[p/2])
        for(std::uint64_t n=p*p;n<=bound;n+=2*p) composite[n/2]=true;
    std::uint64_t count=1,hits2=0,hits3=0;
    for(std::uint64_t p=3;p<=bound;p+=2) if(!composite[p/2]) {
        ++count;
        std::uint64_t a=power_mod(2,136279841,p);
        std::uint64_t q=(a+p-1)%p;
        std::uint64_t sq=q*q%p;
        if((28*sq+1)%p==0) { ++hits2; std::cout << "N2_FACTOR " << p << " q_mod " << q << std::endl; }
        if((66*(sq*q%p)+1)%p==0) { ++hits3; std::cout << "N3_FACTOR " << p << " q_mod " << q << std::endl; }
    }
    double dt=std::chrono::duration<double>(std::chrono::steady_clock::now()-begin).count();
    std::cout << "bound="<<bound<<" primes_checked="<<count<<" N2_hits="<<hits2<<" N3_hits="<<hits3<<" seconds="<<dt<<std::endl;
}
