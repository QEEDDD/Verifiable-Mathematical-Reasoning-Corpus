#include <algorithm>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <functional>
#include <iostream>
#include <queue>
#include <string>
#include <vector>
using namespace std;
int main(int argc,char**argv){
 const int M=argc>1?stoi(argv[1]):1000000;
 const int sign=argc>2?stoi(argv[2]):1;
 auto start=chrono::steady_clock::now();
 vector<int> spf(M+2),ps;
 for(int i=2;i<=M+1;i++){
  if(!spf[i]){spf[i]=i;ps.push_back(i);}
  for(int p:ps){if(p>spf[i]||1LL*p*i>M+1)break;spf[p*i]=p;}
 }
 vector<int8_t> missing(M+1,0);
 for(int i=2;i<=M;i++){
  int p=spf[i],v=i/p;
  missing[i]=(v%p==0||missing[v]<0)?-1:missing[v]+1;
 }
 vector<bool> seen(M+2,false);
 priority_queue<int,vector<int>,greater<int>> heap;
 heap.push(1);
 int n=0,largest=0,maxP=0,examined=0; bool failure=false;
 ofstream prefix(string("research/named_problem/prefix_")+(sign==1?"plus":"minus")+".csv");
 prefix<<"n,P,new_prime\n";
 auto add=[&](int q,int P){
  n++; largest=max(largest,q);seen[q]=true;
  if(n<=10000)prefix<<n<<","<<P<<","<<q<<"\n";
  if(n<=59)cout<<q<<((n==59)?"\n":" ");
  for(int x=q;x<=M;x+=q){if(missing[x]>=0){missing[x]--;if(missing[x]==0)heap.push(x);}}
 };
 if(sign==-1){add(2,0);add(3,0);}
 while(!heap.empty()){
  int P=heap.top();heap.pop();examined++;maxP=max(maxP,P);
  int x=P+sign;
  vector<int> unseen;
  while(x>1){int p=spf[x]; if(!seen[p])unseen.push_back(p); while(x%p==0)x/=p;}
  if(unseen.size()>1){cout<<"COUNTEREXAMPLE step="<<n+1<<" P="<<P<<" factors=";for(int p:unseen)cout<<p<<",";cout<<"\n";failure=true;break;}
  if(unseen.size()==1)add(unseen[0],P);
 }
 double elapsed=chrono::duration<double>(chrono::steady_clock::now()-start).count();
 cout<<"RESULT M="<<M<<" sign="<<sign<<" terms="<<n<<" largest_prime="<<largest<<" max_P="<<maxP<<" products="<<examined<<" failure="<<failure<<" elapsed_seconds="<<elapsed<<"\n";
 return 0;
}
