"""Exact primality proofs. Python 3; optional gmpy2 accelerates the same checks.
No input files, prime tables, PRP oracle, or network are used.
"""
import hashlib
import json
import math
import sys
import time

if hasattr(sys, "set_int_max_str_digits"):
    sys.set_int_max_str_digits(0)
try:
    import gmpy2
    Z, modpow, gcd = gmpy2.mpz, gmpy2.powmod, gmpy2.gcd
    backend = "gmpy2 " + gmpy2.version()
except ImportError:
    Z, modpow, gcd = int, pow, math.gcd
    backend = "Python standard-library exact integers"

def need(condition, explanation):
    if not condition:
        raise ArithmeticError(explanation)

known = set()
for q in (2, 7):
    need(all(q % d for d in range(2, math.isqrt(q) + 1)),
         "base-prime trial division failed")
    known.add(Z(q))

def fingerprint(label, n, expected_digits, expected_bits,
                expected_hash=None):
    decimal = str(n)
    digest = hashlib.sha256(decimal.encode("ascii")).hexdigest()
    need(len(decimal) == expected_digits, label + ": digit count")
    need(n.bit_length() == expected_bits, label + ": bit length")
    if expected_hash is not None:
        need(digest == expected_hash, label + ": decimal identity")
    print(json.dumps({"label": label, "status": "CERTIFIED",
          "digits": len(decimal), "bits": n.bit_length(),
          "sha256_decimal": digest}), flush=True)
    return n

def pocklington(label, n, factors):
    need(n > 2 and n % 2, label + ": odd positive integer")
    F = Z(1)
    distinct = set()
    for q, exponent, a in factors:
        need(q in known, label + ": unknown factor primality")
        need(exponent >= 1 and q not in distinct,
             label + ": invalid factor list")
        distinct.add(q)
        F *= q**exponent
    need((n-1) % F == 0, label + ": F does not divide n-1")
    need(F*F > n, label + ": insufficient factored part")
    for q, exponent, a in factors:
        need(1 < a < n, label + ": witness range")
        need(modpow(Z(a), n-1, n) == 1,
             label + ": Fermat congruence failed")
        t = modpow(Z(a), (n-1)//q, n)
        need(gcd(t-1, n) == 1, label + ": gcd failed")
    known.add(n)
    return n

started = time.perf_counter()
x = Z(14)**256
p = pocklington("p0", x*x-x+1,
                [(Z(2), 256, 11), (Z(7), 256, 2)])
fingerprint("p0", p, 587, 1950)
sizes = [(1177,3908), (2357,7829), (4718,15670),
         (9439,31354), (18882,62722)]
for i, (k, size) in enumerate(zip(
        (438,13696,5494,13258,22330), sizes), 1):
    parent = p
    p = pocklington("p"+str(i), k*parent*parent+1,
                    [(parent,2,2)])
    fingerprint("p"+str(i), p, *size)
r = pocklington("r", 62988*p+1, [(p,1,2)])
fingerprint("r", r, 18886, 62738,
    "ca4c8532ec289a68d0fe9769f87f3797"
    "aa560f9f1a141866da17b917c11c1081")
P = pocklington("P", 2347*(Z(2)**8192)*r+1, [(r,1,2)])
fingerprint("P", P, 21356, 70941,
    "6f4975bbc4efe37c474e15c24dcf3950b"
    "130a0338cbb03220550730ad73d4ad8")



print("ALL CERTIFICATES PASSED;", backend,
      "elapsed seconds", round(time.perf_counter()-started, 3))
