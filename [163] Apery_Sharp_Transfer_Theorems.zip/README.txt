Apéry transfer research volume — 14 November 2026

Contents
- Apery_Sharp_Transfer_Theorems.pdf: 23-page English proof draft.
- Apery_Sharp_Transfer_Theorems.tex: one self-contained LaTeX source.
- Three Python verifiers and their recorded outputs.

The volume contains the foundational rigidity arguments, the optimal
A361713 tower law, an infinite counterexample family for A357567
Conjecture 4, and a proof of A361717 Conjecture 2. It records an exact
remaining boundary for Swisher C.3; it does not claim to prove C.3.
The existing A361713 counterexample is credited in the manuscript.
No claim of historical priority or external peer review is made.

Build with an ordinary LaTeX distribution:
  pdflatex Apery_Sharp_Transfer_Theorems.tex
  pdflatex Apery_Sharp_Transfer_Theorems.tex

Run with Python 3.8 or newer, keeping the Python files together:
  python3 verify_rigidity_completion.py
  python3 verify_transfer_sharp.py
  python3 verify_smooth_counterexamples.py

The verifiers use only the Python standard library. All computations
use exact integer, rational, or modular arithmetic. The finite checks
support auditing; the written arguments supply the all-level proofs.
