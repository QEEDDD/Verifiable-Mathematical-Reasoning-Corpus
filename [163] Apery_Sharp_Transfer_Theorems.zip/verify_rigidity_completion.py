#!/usr/bin/env python3
"""Exact finite checks for the Apéry-rigidity completion.

No floating point arithmetic. Congruence checks use integer modular arithmetic
with every p-factor removed before inversion. These checks are finite evidence,
not substitutes for the manuscript's proofs.
"""

from math import comb


def valuation(a, p, cap=None):
    if not a:
        return f">={cap}" if cap is not None else "infinity"
    v = 0
    while a % p == 0:
        a //= p
        v += 1
    return v


def split_p(a, p):
    v = 0
    while a % p == 0:
        a //= p
        v += 1
    return a, v


def exact_values(n):
    a = b = 0
    for k in range(n + 1):
        t, u = comb(n, k), comb(n + k, k)
        a += t * t * u * u
        b += t * t * u
    nu = sum(comb(n - 1, k) ** 2 * comb(n + k, k) for k in range(n)) if n else 0
    return a, b, nu


def apery_mod(n, p, precision):
    modulus = p**precision
    cu = du = 1
    cv = dv = 0
    a = b = 1
    for k in range(1, n + 1):
        ku, kv = split_p(k, p)
        xu, xv = split_p(n - k + 1, p)
        yu, yv = split_p(n + k, p)
        ki = pow(ku, -1, modulus)
        cu = cu * xu * ki % modulus
        du = du * yu * ki % modulus
        cv += xv - kv
        dv += yv - kv
        assert cv >= 0 and dv >= 0
        av, bv = 2 * cv + 2 * dv, 2 * cv + dv
        if av < precision:
            a = (a + cu * cu * du * du * p**av) % modulus
        if bv < precision:
            b = (b + cu * cu * du * p**bv) % modulus
    return a, b


def product_sums(n, p, precision):
    modulus = p**precision
    o = e = 1
    i2 = i3 = remainder = units = nu = 0
    for k in range(1, n + 1):
        nu = (nu + o * e) % modulus
        if k == n:
            break
        ku, kv = split_p(k, p)
        x = (n // p**kv) * pow(ku, -1, modulus) % modulus
        i2 = (i2 + x * x * o * e) % modulus
        i3 = (i3 + x * x * x * o * e) % modulus
        term = x * x * o * (e - 1)
        remainder = (remainder + term) % modulus
        if k % p:
            units = (units + term) % modulus
        o = o * (1 - x) % modulus
        e = e * (1 - x * x) % modulus
    return i2, i3, remainder, units, nu


def verify_exact_identities():
    count = 0
    for n in range(2, 81):
        _, bn, nu = exact_values(n)
        _, bm, _ = exact_values(n - 1)
        assert 5 * (n - 1) * nu == n * (bn - 3 * bm)
        weights = [comb(n - 1, k) ** 2 * comb(n + k, k) for k in range(n)]
        moments = [sum(k**j * weights[k] for k in range(n)) for j in range(7)]
        assert (2 - n) * moments[1] == (2 * n - 1) * nu - n * n * bm
        for j in range(2, 7):
            # Sum of the finite-difference certificate at degree j.
            certificate = sum(
                ((k + 1) ** (j - 2) * (k + 1 - n) ** 2 * (k + 1 + n)
                 - k ** (j + 1)) * weights[k]
                for k in range(n)
            )
            assert certificate == 0
        count += 7
    for p in (5, 7, 11):
        for n in range(1, 41):
            modulus = p**12
            a, b, _ = exact_values(n)
            assert apery_mod(n, p, 12) == (a % modulus, b % modulus)
            count += 1
    print(f"Exact identity and implementation checks: {count}; all passed.")


def verify_towers():
    primes = [5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43]
    pairs = {(p, 2) for p in primes}
    pairs.update((5, r) for r in range(2, 6))
    pairs.update((7, r) for r in range(2, 5))
    pairs.update(((11, 3), (13, 3)))
    print("p r target | v(2gamma-7Delta) v(2delta+Delta) v(4alpha-5Delta) v(4beta+5Delta) v(D) v(U2) v(V2) v(nu(N))")
    for p, r in sorted(pairs):
        n, m = p**r, p**(r - 1)
        target, precision = 3 * r + 3, 3 * r + 6
        modulus = p**precision
        an, bn = apery_mod(n, p, precision)
        am, bm = apery_mod(m, p, precision)
        anx, bnx = apery_mod(n - 1, p, precision)
        amx, bmx = apery_mod(m - 1, p, precision)
        delta_c = (comb(2 * n, n) - comb(2 * m, m)) % modulus
        sn, sm = product_sums(n, p, precision), product_sums(m, p, precision)
        defect = (sn[0] - sm[0] - delta_c * pow(4, -1, modulus)) % modulus
        carry = (sn[2] - sm[2] - sn[3]) % modulus
        differences = [
            (2 * (an - am) - 7 * delta_c) % modulus,
            (2 * (anx - amx) + delta_c) % modulus,
            (4 * (bn - bm) - 5 * delta_c) % modulus,
            (4 * (bnx - bmx) + 5 * delta_c) % modulus,
            defect, sn[3], carry,
        ]
        assert all(x % (p**target) == 0 for x in differences), (p, r, differences)
        assert (sn[1] - sm[1]) % (p**target) == 0
        assert sn[4] % (p**(r + 3)) == 0
        # Independently check exact representations modulo the working modulus.
        cn = comb(2 * n, n) % modulus
        assert (bn - 1 - cn - sn[0] - sn[1]) % modulus == 0
        assert (bnx - 2 + cn * pow(2, -1, modulus) + 3 * sn[0] - 2 * sn[1]) % modulus == 0
        vals = [valuation(x, p, precision) for x in differences + [sn[4]]]
        print(p, r, target, "|", *vals)
    print(f"Tower pairs: {len(pairs)}; all targets passed. Largest index: {max(p**r for p, r in pairs)}.")
    print("A displayed >= value means the residue vanishes through the working precision.")


def exact_five_boundary():
    _, b25, _ = exact_values(25)
    _, b24, _ = exact_values(24)
    _, b5, _ = exact_values(5)
    _, b4, _ = exact_values(4)
    dc = comb(50, 25) - comb(10, 5)
    xa, xb = 4 * (b25 - b5) - 5 * dc, 4 * (b24 - b4) + 5 * dc
    assert xa == 5**11 * 152633309640740772
    assert xb == 5**12 * 2865957580382044
    print("Exact p=5, r=2 boundary:")
    print(f"Delta_2={dc}; B(25)={b25}; B(24)={b24}")
    print("4alpha_2-5Delta_2 = 5^11 * 152633309640740772")
    print("4beta_2+5Delta_2 = 5^12 * 2865957580382044")


if __name__ == "__main__":
    print("FINITE EXACT VERIFICATION; NOT A PROOF OF THE INFINITE TOWERS")
    verify_exact_identities()
    verify_towers()
    exact_five_boundary()
