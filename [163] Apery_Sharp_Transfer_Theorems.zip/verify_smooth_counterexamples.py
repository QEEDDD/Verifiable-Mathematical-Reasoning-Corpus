#!/usr/bin/env python3
"""Finite independent checks accompanying the infinite-family proof.

The proof uses only A(5m)=A(m) mod25 and B(5m)=B(m) mod25. This
script additionally evaluates the large-index residue directly by modular
binomial sums, without using those transfer equalities.
"""

from math import comb
from verify_rigidity_completion import apery_mod, exact_values, valuation


for a in range(81):
    for b in range(a + 1):
        assert (comb(5 * a, 5 * b) - comb(a, b)) % 25 == 0
for m in range(61):
    a, b, _ = exact_values(m)
    ax, bx, _ = exact_values(5 * m)
    assert (ax - a) % 25 == 0
    assert (bx - b) % 25 == 0
print("Babbage checks: a=0..80, all b=0..a; all passed.")
print("Exact Apéry transfer checks: m=0..60; all passed.")

a3, b3, _ = exact_values(3)
u3 = 3**42 * a3**25 - 5**25 * b3**42
assert (a3, b3) == (1445, 147)
assert valuation(u3, 5) == 25
assert (u3 // 5**25) % 5 == 2
print("Seed: A(3)=1445, B(3)=147, v5(F(3))=25, F(3)/5^25=2 mod5.")

modulus = 5**26
print("r n A(n)mod25 B(n)mod5 F(n)mod5^26 target5r")
for r in range(7):
    n = 3 * 5**r
    a, b = apery_mod(n, 5, 26)
    residue = (pow(3, 42, modulus) * pow(a, 25, modulus)
               - pow(5, 25, modulus) * pow(b, 42, modulus)) % modulus
    assert residue == 2 * 5**25
    print(r, n, a % 25, b % 5, residue, 5 * r)
print("At n=46875, v5(F)=25 < v5(n^5)=30: exact counterexample.")
print("The infinite family follows from the written proof, not this finite check.")
