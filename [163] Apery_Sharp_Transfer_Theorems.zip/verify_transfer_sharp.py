#!/usr/bin/env python3
"""Independent finite checks for the A361713 sharp tower law.

Python standard library only. This is a reproducible arithmetic check, not
an infinite proof. The finite scope is printed at the beginning of the run.
J4 is evaluated modulo p**L using its rational product with p-free
 denominators; coefficient J3(p) is independently computed by binomial sums.
"""
from fractions import Fraction
from functools import lru_cache
from math import comb


def valuation(value, p):
    """Exact valuation of a nonzero integer; None for zero."""
    if value == 0:
        return None
    value = abs(value)
    result = 0
    while value % p == 0:
        result += 1
        value //= p
    return result


def qmod(value, modulus):
    value = Fraction(value)
    return value.numerator * pow(value.denominator, -1, modulus) % modulus


@lru_cache(maxsize=None)
def j4_mod(p, r, precision):
    """J4(p**r) mod p**precision, with no nonunit modular inversions."""
    modulus = p ** precision
    n = p ** r
    even_product = 1
    total = 0
    for k in range(1, n):
        denominator = k
        exponent = 0
        while denominator % p == 0:
            denominator //= p
            exponent += 1
        # n/k = p**(r-exponent) / denominator, denominator coprime to p.
        x = p ** (r - exponent) * pow(denominator, -1, modulus) % modulus
        x2 = x * x % modulus
        total = (total + x2 * x2 * even_product * even_product) % modulus
        even_product = even_product * (1 - x2) % modulus
    return total


def exact_u(n):
    return sum(comb(n, k) ** 2 * comb(n + k - 1, k) ** 2
               for k in range(n))


def exact_apery_a(n):
    return sum(comb(n, k) ** 2 * comb(n + k, k) ** 2
               for k in range(n + 1))


@lru_cache(maxsize=None)
def prime_coefficient(p):
    h2 = sum((Fraction(1, k * k) for k in range(1, p)), Fraction(0))
    # Independent exact identity: A(p)-A(p-1)=C(2p,p)^2+4 J3(p).
    j3 = Fraction(exact_apery_a(p) - exact_apery_a(p - 1)
                  - comb(2 * p, p) ** 2, 4)
    return h2, j3


def main():
    large_primes = (7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43)
    cases = {(p, r) for p in large_primes for r in (1, 2, 3)}
    cases.update((5, r) for r in range(1, 6))
    cases.update((7, r) for r in (4, 5, 6))
    cases.update((11, r) for r in (4, 5))
    cases = sorted(cases)
    print('FINITE SCOPE:')
    print('  Every prime 7 <= p <= 43, levels r=1,2,3.')
    print('  Additional cases p=7, r=4,5,6; p=11, r=4,5.')
    print('  Boundary cases p=5, r=1,2,3,4,5.')
    print('  Total cases:', len(cases))
    print('  Largest n:', max(p ** r for p, r in cases))
    print('  Arithmetic: exact integers/Fractions and modular products; no floats.')
    print()

    # Cross-check the modular product against the defining integer sum.
    direct_checks = 0
    for p, r in cases:
        if p ** r <= 25:
            precision = 3 * r + 7
            assert j4_mod(p, r, precision) == (exact_u(p ** r) - 1) % (p ** precision)
            direct_checks += 1
    print('Defining-binomial-sum cross-checks passed:', direct_checks)
    print()
    print('p,r,n,proved_lower_bound,observed_valuation,first_defect_error_valuation')
    law_checks = 0
    for p, r in cases:
        precision = 3 * r + (6 if p == 5 else 7)
        modulus = p ** precision
        difference = (j4_mod(p, r, precision)
                      - j4_mod(p, r - 1, precision)) % modulus
        observed = valuation(difference, p)
        lower = min(5 * r - 1, 3 * r + 4) if p == 5 else min(5 * r, 3 * r + 5)
        assert observed is None or observed >= lower, (p, r, observed, lower)
        error_text = 'not asserted at this level'
        if r >= 3:
            h2, j3 = prime_coefficient(p)
            predicted = -2 * p ** (3 * r - 1) * h2 * j3
            error = (difference - qmod(predicted, modulus)) % modulus
            error_v = valuation(error, p)
            required = 3 * r + (5 if p == 5 else 6)
            assert error_v is None or error_v >= required, (p, r, error_v, required)
            error_text = '>=' + str(precision) if error_v is None else str(error_v)
            law_checks += 1
        if p == 11 and r >= 3:
            assert observed == 3 * r + 5
        if p == 5 and r >= 3:
            assert observed == 3 * r + 4
        observed_text = '>=' + str(precision) if observed is None else str(observed)
        print(f'{p},{r},{p**r},{lower},{observed_text},{error_text}')
    print()
    print('First-defect congruence checks passed:', law_checks)
    print('All displayed lower bounds passed.')
    print()

    h2, j3 = prime_coefficient(11)
    assert h2 == Fraction(1968329, 1270080)
    assert j3 == 97380253269607
    assert qmod(h2 / 11, 11) == 10
    assert j3 / 11 ** 5 == 604654757
    assert qmod(j3 / 11 ** 5, 11) == 3
    print('EXACT p=11 SHARPNESS CERTIFICATE:')
    print('  H_10^(2) =', h2)
    print('  J3(11) =', j3)
    print('  H_10^(2)/11 =', h2 / 11, '== 10 mod 11')
    print('  J3(11)/11^5 =', j3 / 11 ** 5, '== 3 mod 11')
    print('  Leading normalized coefficient = -2*10*3 == 6 mod 11.')
    print()
    h2, j3 = prime_coefficient(5)
    assert h2 == Fraction(205, 144)
    assert j3 == 180625
    assert qmod(h2 / 5, 5) == 4
    assert qmod(j3 / 5 ** 4, 5) == 4
    print('EXACT p=5 SHARPNESS CERTIFICATE:')
    print('  H_4^(2) =', h2)
    print('  J3(5) =', j3)
    print('  Leading normalized coefficient = -2*4*4 == 3 mod 5.')
    print()
    print('PASS: finite checks only; all-level conclusions require the written proof.')


if __name__ == '__main__':
    main()
