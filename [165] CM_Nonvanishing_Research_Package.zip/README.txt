CM NONVANISHING RESEARCH PACKAGE -- 14 NOVEMBER 2026

Result: conditional on the no-Siegel-zero boundary-CM classification,
Conjecture 5.2 holds for min(k,l)<=500 (even weights >=4, total 8,10,14
excluded). Local nonvanishing at the 35 listed CM points is unconditional.
The PDF and single TEX also prove an effective finite-weight reduction
for every fixed odd CM discriminant <=-7, and an equal-v2 two-adic theorem.
The global numerical cutoff N is NOT evaluated; the full conjecture is
NOT proved. Historical novelty has not been established.

Reproduce from this directory with Python 3 and mpmath, sympy installed:
  python3 cm_triangle.py
  python3 cm_band_norm.py
  python3 cm_band_simple_edge.py
Optional independent small-column calculation:
  python3 verify_small_columns.py

Expected results:
- cm_triangle: 2,169,895 nonzero intervals, no failures.
- cm_band_norm: all even smaller weights 10..496 pass all 35 points.
  This diagnostic script also tests 498,500 with an insufficient cutoff;
  those failures are expected and are superseded by cm_band_simple_edge.
- cm_band_simple_edge: 70 dominance inequalities and 315 finite tests pass.
- verify_small_columns: 2,065 nonzero intervals for columns 10 and 12.

Every nonvanishing decision uses outward mpmath.iv intervals and an
explicit Fourier tail. Rounded decimal fields in JSON are diagnostic,
not independent rational interval certificates. The scripts reconstruct
and check the outward intervals. This is not a proof-assistant artifact.
The mathematical proof of the infinite tails is in the PDF/TEX; finite
computation alone does not prove the infinite weight assertions.

The single TEX compiles with a standard pdfLaTeX installation (two passes).

Environment:
{
  "python": "3.12.14",
  "mpmath": "1.3.0",
  "sympy": "1.14.0"
}
