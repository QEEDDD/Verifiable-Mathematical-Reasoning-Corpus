"""Certified CM nonvanishing band, using mpmath interval arithmetic.

For each even l=10..500 and each of 35 positive discriminant magnitudes D,
test |E_l((-1+i*sqrt(D))/2)-1| > 12*y**(-3)*A**(2-(1000-l)/2),
where A=(D+1)/4 is the minimal squared norm of a nonhorizontal lattice vector.
This suffices for F_{k,l} != 0 at this CM point whenever k>=1000-l,
provided |E_l|<2 and |E_k-1|<4*y**(1-k), as proved separately.

The Fourier series is evaluated as an interval polynomial plus a rigorous
absolute tail. All inputs to the intervals are integers or exact ratios.
"""
import json
import time
from pathlib import Path
from mpmath import iv, mp
from sympy import bernoulli

iv.dps = 400
mp.dps = 60  # for output only; every certification uses iv intervals
N = 300
DS = [7,11,19,27,43,67,163,
      15,35,51,75,91,99,115,123,147,187,235,267,403,427,
      195,315,435,483,555,595,627,715,795,1435,
      1155,1995,3003,3315]
assert len(DS) == len(set(DS)) == 35
DS.sort()
ROOT = Path(__file__).resolve().parent

def out_endpoint(value, lower=True):
    """Print an endpoint, but never use this rounded conversion to certify."""
    endpoint = value._mpi_[0 if lower else 1]
    return mp.nstr(mp.make_mpf(endpoint), 30)

def iv_int(n):
    return iv.mpf(int(n))

points = {}
for D in DS:
    y = iv.sqrt(iv_int(D))/2
    r = iv.exp(-2*iv.pi*y)
    points[D] = (y, r, -r)

records = []
first_failure = None
started = time.time()
for ell in range(10, 501, 2):
    s = ell-1
    coeff = [0]*(N+1)
    for d in range(1,N+1):
        ds = d**s
        for n in range(d,N+1,d):
            coeff[n] += ds
    B = bernoulli(ell)
    bn, bd = map(int, B.as_numer_denom())
    factor = iv_int(-2*ell*bd)/iv_int(bn)
    K = 1000-ell
    row = []
    for D in DS:
        y,r,q = points[D]
        # Horner polynomial sum_{n=1}^N sigma_{ell-1}(n)*q^n.
        val = iv_int(coeff[N])
        for n in range(N-1,0,-1):
            val = val*q + coeff[n]
        val *= q
        # sigma_s(n) <= zeta(s)*n^s < 2*n^s.
        # Ratio of n^s*r^n for n>=N+1 is at most rho.
        rho = r*(iv_int(N+2)/iv_int(N+1))**s
        assert rho < 1, (ell,D,"invalid tail ratio")
        tail = 2*iv_int((N+1)**s)*r**(N+1)/(1-rho)
        # Enclose the signed Fourier tail by [-tail_upper,+tail_upper].
        tail_box = iv.mpf([-tail.b, tail.b])
        R = factor*(val+tail_box)
        abs_R = abs(R)
        A = iv_int(D+1)/4
        threshold = 12*y**(-3)*A**(2-K//2)
        ratio = abs_R/threshold
        passed = (ratio > 1) is True
        row.append({"D": D, "passed": passed,
                    "ratio_lower": out_endpoint(ratio),
                    "ratio_upper": out_endpoint(ratio, False),
                    "R_lower": out_endpoint(R),
                    "R_upper": out_endpoint(R, False)})
    passed_all = all(x["passed"] for x in row)
    if not passed_all and first_failure is None:
        first_failure = ell
    worst = min(row, key=lambda x: mp.mpf(x["ratio_lower"]))
    records.append({"ell": ell, "K":K, "passed_all": passed_all,
                    "worst_D":worst["D"],
                    "worst_ratio_lower":worst["ratio_lower"],
                    "checks":row})
    if ell % 20 == 0 or not passed_all:
        print(json.dumps({"ell":ell,"passed_all":passed_all,
                          "worst_D":worst["D"],
                          "worst_ratio_lower":worst["ratio_lower"],
                          "seconds":round(time.time()-started,1)}), flush=True)

summary = {"interval_backend":"mpmath.iv", "decimal_precision":iv.dps,
           "fourier_cutoff":N, "discriminants":DS,
           "weight_range":[10,500], "first_failed_weight":first_failure,
           "continuous_band_through":500 if first_failure is None else first_failure-2,
           "total_checks":len(records)*len(DS),
           "records":records}
(ROOT/"cm_band_norm_results.json").write_text(json.dumps(summary,indent=2))
print(json.dumps({k:v for k,v in summary.items() if k!="records"}),flush=True)
