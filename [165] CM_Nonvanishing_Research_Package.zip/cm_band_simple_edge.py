"""Certify edge weights 498,500 using the universal lattice upper bound.

The finite triangle covers k+l<=1000. For l=498 use K=508. For l=500
use K=516. Explicitly check nine additional unordered weight pairs:
(498,504),(498,506), and (500,k) for k=502,504,...,514.
Evaluate R_l with outward intervals and prove
|R_l|>12*y**(-3)*A**(2-K/2), where A=(D+1)/4.
"""
import json
from pathlib import Path
from mpmath import iv,mp
from sympy import bernoulli
iv.dps=400
mp.dps=60
N=300
DS=sorted([7,11,19,27,43,67,163,15,35,51,75,91,99,115,123,147,187,235,267,403,427,195,315,435,483,555,595,627,715,795,1435,1155,1995,3003,3315])
def I(n): return iv.mpf(int(n))
def out(x,lower=True): return mp.nstr(mp.make_mpf(x._mpi_[0 if lower else 1]),35)
records=[]
Rcache={D:{} for D in DS}
for ell in (498,500):
    s=ell-1
    coeff=[0]*(N+1)
    for d in range(1,N+1):
        ds=d**s
        for n in range(d,N+1,d): coeff[n]+=ds
    bn,bd=map(int,bernoulli(ell).as_numer_denom())
    factor=I(-2*ell*bd)/I(bn)
    K=508 if ell==498 else 516
    for D in DS:
        y=iv.sqrt(I(D))/2
        A=I(D+1)/4
        r=iv.exp(-2*iv.pi*y)
        q=-r
        val=I(coeff[N])
        for n in range(N-1,0,-1): val=val*q+coeff[n]
        val*=q
        rho=r*(I(N+2)/I(N+1))**s
        assert rho<1
        tail=2*I((N+1)**s)*r**(N+1)/(1-rho)
        R=factor*(val+iv.mpf([-tail.b,tail.b]))
        Rcache[D][ell]=R
        error=12*y**(-3)*A**(2-K//2)
        ratio=abs(R)/error
        rec={"ell":ell,"K":K,"D":D,"bound":"universal12",
             "passed":(ratio>1) is True,"ratio_lower":out(ratio),
             "ratio_upper":out(ratio,False)}
        records.append(rec)
        if not rec["passed"]: print(json.dumps(rec),flush=True)

# Independently evaluate the nine extra pairs required at l=498,500.
for w in (502,504,506,508,510,512,514,1002,1004,1006,1008,1010,1012,1014):
    s=w-1
    coeff=[0]*(N+1)
    for d in range(1,N+1):
        ds=d**s
        for n in range(d,N+1,d): coeff[n]+=ds
    bn,bd=map(int,bernoulli(w).as_numer_denom())
    factor=I(-2*w*bd)/I(bn)
    for D in DS:
        y=iv.sqrt(I(D))/2
        r=iv.exp(-2*iv.pi*y)
        q=-r
        val=I(coeff[N])
        for n in range(N-1,0,-1): val=val*q+coeff[n]
        val*=q
        rho=r*(I(N+2)/I(N+1))**s
        assert rho<1
        tail=2*I((N+1)**s)*r**(N+1)/(1-rho)
        Rcache[D][w]=factor*(val+iv.mpf([-tail.b,tail.b]))

extra_checks=[]
for D in DS:
    R=Rcache[D]
    for ell,k in [(498,504),(498,506)]+[(500,k) for k in range(502,516,2)]:
        F=R[ell]+R[k]+R[ell]*R[k]-R[ell+k]
        passed=(F>0) is True or (F<0) is True
        scale=abs(R[ell])+abs(R[k])+abs(R[ell]*R[k])+abs(R[ell+k])
        rec={"D":D,"k":ell,"l":k,"passed":passed,
             "F_lower":out(F),"F_upper":out(F,False),
             "relative_margin_lower":out(abs(F)/scale)}
        extra_checks.append(rec)
        if not passed: print(json.dumps(rec),flush=True)
summary={"precision":iv.dps,"fourier_cutoff":N,
         "all_passed":all(x["passed"] for x in records),
         "total_checks":len(records),"records":records,
         "extra_pair_checks":len(extra_checks),
         "extra_pairs_all_nonzero":all(x["passed"] for x in extra_checks),
         "extra_pairs":extra_checks}
Path(__file__).with_name("cm_band_simple_edge_results.json").write_text(json.dumps(summary,indent=2))
for ell in (498,500):
    worst=min((x for x in records if x["ell"]==ell),key=lambda x:mp.mpf(x["ratio_lower"]))
    print(json.dumps({"ell":ell,"all_passed":all(x["passed"] for x in records if x["ell"]==ell),"worst":worst}),flush=True)
print(json.dumps({"extra_pair_checks":len(extra_checks),
                  "extra_pairs_all_nonzero":summary["extra_pairs_all_nonzero"]}),flush=True)
