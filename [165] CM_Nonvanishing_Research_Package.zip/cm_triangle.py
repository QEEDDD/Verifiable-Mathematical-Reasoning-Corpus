"""Independent outward-interval verification of the CM finite triangle.

Checks every even pair 4<=k<=l with k+l<=1000, excluding total weights
8,10,14, at the 35 principal CM points from the exponent-two classification.

For each even w, R_w=E_w-1 is evaluated using 300 exact Fourier coefficients
and an explicit geometric upper bound for the absolute tail. 400 decimal
digits of mpmath.iv interval precision are used throughout certification.
F_{k,l}=R_k+R_l+R_k*R_l-R_{k+l} avoids cancellation of the constant term.
"""
import json
import time
from pathlib import Path
from mpmath import iv, mp
from sympy import bernoulli

iv.dps = 400
mp.dps = 60  # printing and ranking only, never certification
N = 300
M = 1000
DS = sorted([7,11,19,27,43,67,163,
      15,35,51,75,91,99,115,123,147,187,235,267,403,427,
      195,315,435,483,555,595,627,715,795,1435,
      1155,1995,3003,3315])
assert len(DS) == len(set(DS)) == 35
ROOT = Path(__file__).resolve().parent

def endpoint_number(interval, lower=True):
    return mp.make_mpf(interval._mpi_[0 if lower else 1])

def out_endpoint(interval, lower=True):
    return mp.nstr(endpoint_number(interval, lower), 35)

def I(n):
    return iv.mpf(int(n))

points = {}
R = {D:{} for D in DS}
for D in DS:
    y = iv.sqrt(I(D))/2
    r = iv.exp(-2*iv.pi*y)
    points[D] = y,r,-r

started = time.time()
for w in range(4,M+1,2):
    s = w-1
    coeff = [0]*(N+1)
    for d in range(1,N+1):
        ds = d**s
        for n in range(d,N+1,d):
            coeff[n] += ds
    B = bernoulli(w)
    bn,bd = map(int,B.as_numer_denom())
    factor = I(-2*w*bd)/I(bn)
    for D in DS:
        y,r,q = points[D]
        val=I(coeff[N])
        for n in range(N-1,0,-1):
            val=val*q+coeff[n]
        val*=q
        rho=r*(I(N+2)/I(N+1))**s
        assert rho<1, (w,D,"tail ratio not below one")
        tail=2*I((N+1)**s)*r**(N+1)/(1-rho)
        val+=iv.mpf([-tail.b,tail.b])
        R[D][w]=factor*val
    if w%100==0:
        print(json.dumps({"phase":"precompute", "through_weight":w,
                          "seconds":round(time.time()-started,1)}),flush=True)

pairs=[(k,l) for k in range(4,M//2+1,2)
               for l in range(k,M-k+1,2)
               if k+l not in (8,10,14)]
assert len(pairs)==61997
records=[]
failures=[]
for D in DS:
    RD=R[D]
    min_separation=None
    worst_pair=None
    worst_value=None
    for k,l in pairs:
        F=RD[k]+RD[l]+RD[k]*RD[l]-RD[k+l]
        if (F>0) is True:
            sep=endpoint_number(F)
        elif (F<0) is True:
            sep=-endpoint_number(F,False)
        else:
            failures.append({"D":D,"k":k,"l":l,
                             "lower":out_endpoint(F),
                             "upper":out_endpoint(F,False)})
            continue
        if min_separation is None or sep<min_separation:
            min_separation=sep
            worst_pair=(k,l)
            worst_value=F
    k,l=worst_pair
    scale=abs(RD[k])+abs(RD[l])+abs(RD[k]*RD[l])+abs(RD[k+l])
    relative_margin=abs(worst_value)/scale
    rec={"D":D,"checked_pairs":len(pairs),
         "all_nonzero":not any(f["D"]==D for f in failures),
         "smallest_absolute_lower_bound":mp.nstr(min_separation,35),
         "smallest_absolute_pair":list(worst_pair),
         "that_pair_relative_margin_lower":out_endpoint(relative_margin)}
    records.append(rec)
    print(json.dumps({"phase":"triangle",**rec,
                      "seconds":round(time.time()-started,1)}),flush=True)

summary={"interval_backend":"mpmath.iv", "decimal_precision":iv.dps,
         "fourier_cutoff":N,"total_weight_max":M,
         "discriminants":DS,"pairs_per_discriminant":len(pairs),
         "total_pairs":len(pairs)*len(DS),
         "zero_containing_intervals":len(failures),
         "all_nonzero":not failures,"failures":failures,
         "records":records,"elapsed_seconds":time.time()-started}
(ROOT/"cm_triangle_results.json").write_text(json.dumps(summary,indent=2))
print(json.dumps({k:v for k,v in summary.items() if k not in ("records","failures")}),flush=True)
