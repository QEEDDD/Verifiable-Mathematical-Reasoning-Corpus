"""Outward interval certificate for two infinite-weight CM nonvanishing columns.

This file certifies only the finite part k=4,6,...,62, ell=10,12.
The accompanying mathematical note handles every even k>=64 analytically.
mpmath interval arithmetic is used, with an explicit infinite q-series tail.
This is not a proof of the full two-variable conjecture.
"""
import json
from pathlib import Path
import mpmath as mp
from sympy import bernoulli

mp.iv.dps = 160
mp.mp.dps = 180
iv = mp.iv
DISCRIMINANTS = [
    -7,-11,-19,-27,-43,-67,-163,
    -15,-35,-51,-75,-91,-99,-115,-123,-147,-187,-235,-267,-403,-427,
    -195,-315,-435,-483,-555,-595,-627,-715,-795,-1435,
    -1155,-1995,-3003,-3315,
]
assert len(DISCRIMINANTS)==35 and len(set(DISCRIMINANTS))==35
N=100
weights=range(4,76,2)
sigmas={}
coeffs={}
tails={}
for w in weights:
    b=bernoulli(w)
    coeffs[w]=-iv.mpf(2*w*int(b.q))/int(b.p)
    s=[0]*(N+1)
    for d in range(1,N+1):
        power=d**(w-1)
        for n in range(d,N+1,d):
            s[n]+=power
    sigmas[w]=s
    # For r<=1/4000 and w<=74, the consecutive majorant ratio is <1/2.
    # zeta(w-1)<2, so this bounds the entire tail after n=N.
    assert iv.mpf(1)/4000*(iv.mpf(N+2)/(N+1))**(w-1)<iv.mpf(1)/2
    tails[w]=iv.mpf(4)*(N+1)**(w-1)/(iv.mpf(4000)**(N+1))

certificate=[]
for D in DISCRIMINANTS:
    y=iv.sqrt(-D)/2
    r=iv.exp(-2*iv.pi*y)
    assert r<iv.mpf(1)/4000
    powers=[iv.mpf(1)]
    for n in range(1,N+1):
        powers.append(-powers[-1]*r)
    E={}
    for w in weights:
        total=sum((sigmas[w][n]*powers[n] for n in range(1,N+1)),iv.mpf(0))
        tail=tails[w].b
        total+=iv.mpf([-tail,tail])
        E[w]=1+coeffs[w]*total
    for ell in (10,12):
        for k in range(4,64,2):
            if k+ell in (8,10,14):
                continue
            value=E[k]*E[ell]-E[k+ell]
            assert value.a>0 or value.b<0, (D,k,ell,str(value))
            certificate.append({'D':D,'k':k,'ell':ell,'enclosure':str(value)})

result={
    'status':'PASS',
    'scope':'Only finite part of ell=10 and ell=12 columns; not full conjecture',
    'number_of_certified_evaluations':len(certificate),
    'discriminants':DISCRIMINANTS,
    'interval_decimal_precision':iv.dps,
    'q_series_terms':N,
    'tail_bound':'4*(N+1)^(w-1)/4000^(N+1), before multiplication by -2w/B_w',
    'evaluations':certificate,
}
path=Path(__file__).with_name('small_columns_certificate.json')
path.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='evaluations'},indent=2))
