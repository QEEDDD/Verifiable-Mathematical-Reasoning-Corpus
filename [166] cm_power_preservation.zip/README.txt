EXACT UNIVERSAL ORDER TWELVE FOR POWERS OF COMPLETELY MONOTONE FUNCTIONS

Main claim
----------
For every completely monotone f on (0,infinity) and every real alpha >= 1,
(-1)^j (f^alpha)^(j) >= 0 for j=0,...,12. The universal integer bound is sharp:
f(t)=1+exp(-t), alpha=6/5, t=log(7/3) fails at derivative order 13.

Status
------
This is a computer-assisted proof with exact rational arithmetic, accompanied
by a written analytic reduction. It is not a proof-assistant formalization;
external mathematical review is pending. The 1997 published abstract of
H. van Haeringen establishes the earlier universal lower bound 7 and failure
at 13. A limited literature search found no subsequent exact classification.
This does not establish exhaustive priority, nor verify the wording of a
named conjecture predicting the number twelve.

Reproduce
---------
Use Python 3.10 or later and NumPy. No network or input datasets are required.
From the cm_threshold12 directory, run:

    python3 verify_cm12.py
    python3 verify13.py
    python3 independent_audit.py

The main verifier regenerates all integer polynomials and uses Fraction for
coefficient conversion, subdivision, and sign decisions. NumPy stores object
arrays; floating-point approximations play no role in accepting a cell.
Timing measurements printed by the program are not part of the proof.

Expected main verification:
    2048 monomials, 64 groups in total
    63 nonzero-tail groups: 69 accepted boxes, maximum depth 4
    1 zero-tail group: 76 accepted simplex/interval cells, maximum depth 12
    Total: 145 accepted cells, no unresolved group

The exact negative normalized derivative at order 13 is
    -6524240334632293437 / 2980232238769531250.

The independent audit is supplementary: its rational-point comparisons test
algebraic implementations, while the main certificate proves nonnegativity
over whole cells and therefore over the entire parameter domain.

The analytic arguments (Laplace representation, Stieltjes parametrization,
lower derivative signs, extension to all real alpha >= 1) are in the paper.
The arithmetic program alone does not formalize those analytic arguments.

Scope
-----
The input f is completely monotone to every order. No assertion is made for
an arbitrary function known only to satisfy the first twelve signs. Nor does
the conclusion assert complete monotonicity of f^alpha at every order.

The PDF and single TeX include the full main verifier and order-13 verifier.
The TeX can be built with an ordinary LaTeX installation using pdflatex twice.

Additional historical problem
-----------------------------
The separate hillar_2005 directory contains a proof refuting the Hermitian
branch of Hillar's Euler-Lagrange commutativity statement from his 2005
preprint. It does not refute the positive-semidefinite branch or the BMV
theorem. Its exact symbolic verifier requires SymPy. This result is separate
from the completely monotone function theorem.
