#!/usr/bin/env python3
"""Independent exact arithmetic audits of verify_cm12.py.

Run with: python independent_audit.py

This is an additional implementation audit, not a replacement for the full
Bernstein certificate or for the manuscript's analytic proof. In particular,
evaluations at rational points are spot checks of change-of-basis operations.
Every arithmetic comparison uses integers or fractions, with no tolerance.

The submitted verifier is loaded from the same directory when packaged, or
from audit/verify_cm12.py in the development workspace. The audit regenerates
moment coefficients independently, and compares changes of basis against
direct evaluation of the original polynomials and affine substitutions.
"""
from fractions import Fraction as F
import hashlib
import importlib.util
import itertools
import json
import math
from pathlib import Path
import random


BASE = Path(__file__).resolve().parent
CORE_PATH = BASE / "verify_cm12.py"
if not CORE_PATH.exists():
    CORE_PATH = BASE / "audit" / "verify_cm12.py"
spec = importlib.util.spec_from_file_location("cm12_target_under_test", CORE_PATH)
core = importlib.util.module_from_spec(spec)
spec.loader.exec_module(core)


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def bernstein(d, i, x):
    return F(math.comb(d, i)) * x**i * (1-x)**(d-i)


def audit_moments():
    """Independent enumeration of level profiles of ordered rooted trees."""
    compositions_checked = 0
    for n in range(1, 13):
        oracle = {}
        for cuts in itertools.product((0, 1), repeat=n-1):
            exponents, current = [], 1
            for cut in cuts:
                if cut:
                    exponents.append(current)
                    current = 1
                else:
                    current += 1
            exponents.append(current)
            weight = math.prod(
                math.comb(exponents[i]+exponents[i+1]-1, exponents[i+1])
                for i in range(len(exponents)-1)
            )
            key = tuple(exponents)+(0,)*(12-len(exponents))
            oracle[key] = weight
            compositions_checked += 1
        require(core.moment(0, n) == oracle, f"Moment polynomial mismatch at n={n}")
    return {"orders": list(range(1, 13)), "composition_coefficients": compositions_checked}


def audit_nonzero_tail_conversions(rng):
    """Direct monomial evaluation versus the submitted tensor-basis weights."""
    groups = {}
    for exponent, coefficients in core.derivative(12).items():
        groups.setdefault(exponent[6:], {})[exponent[:6]] = core.div_alpha(coefficients)
    require(len(groups) == 64, "Expected 64 tail groups")
    checked, terms = 0, 0
    for tail, polynomial in groups.items():
        if not any(tail):
            continue
        common = tuple(min(e[j] for e in polynomial) for j in range(6))
        D = 12-sum(tail)-sum(common)
        K = max(map(len, polynomial.values()))-1
        beta = F(2, 7)
        xs = [F(rng.randrange(1, 10), 11) for _ in range(5)]
        q, remainder = [], F(1)
        for x in xs:
            q.append(remainder*x)
            remainder *= 1-x
        q.append(remainder)
        direct = sum(
            sum(F(cj)*beta**j for j, cj in enumerate(c))
            * math.prod(q[j]**(e[j]-common[j]) for j in range(6))
            for e, c in polynomial.items()
        )
        transformed = F(0)
        for exponent, coefficients in polynomial.items():
            u = [exponent[j]-common[j] for j in range(6)]
            prefix = [sum(u[:j]) for j in range(5)]
            beta_value = sum(
                sum(F(coefficients[j]*math.comb(i, j), math.comb(K, j))
                    for j in range(min(i, len(coefficients)-1)+1))
                * bernstein(K, i, beta)
                for i in range(K+1)
            )
            cube_factors = [
                sum(F(math.comb(prefix[j], a), math.comb(D, u[j]+a))
                    * bernstein(D, u[j]+a, xs[j])
                    for a in range(prefix[j]+1))
                for j in range(5)
            ]
            transformed += beta_value*math.prod(cube_factors)
            terms += 1
        require(direct == transformed, f"Nonzero-tail conversion mismatch: {tail}")
        checked += 1
    require(checked == 63, "Expected to audit all 63 nonzero tails")
    return {"groups": checked, "monomials": terms,
            "rational_evaluations_per_group": 1,
            "meaning": "spot checks of conversion, not positivity sampling"}


def audit_simplex_edge_splits(rng):
    """Check multinomial weighting against actual child-to-parent affine maps."""
    comparisons = 0
    for D in range(1, 7):
        dimension_of_barycentric_vector = 4
        r = dimension_of_barycentric_vector
        exponents = core.weak(D, r)
        location = {p: i for i, p in enumerate(exponents)}
        coefficients = [F(rng.randrange(-10, 11), rng.randrange(1, 8))
                        for _ in exponents]

        def evaluate(values, q):
            return sum(
                values[location[p]]
                * F(math.factorial(D), math.prod(math.factorial(x) for x in p))
                * math.prod(q[j]**p[j] for j in range(r))
                for p in exponents
            )

        for i, j in itertools.combinations(range(r), 2):
            groups = {}
            for p in exponents:
                key = tuple(p[h] for h in range(r) if h not in (i, j))
                groups.setdefault(key, []).append(p)
            left, right = [F(0)]*len(exponents), [F(0)]*len(exponents)
            for group in groups.values():
                indices = [location[p] for p in sorted(group, key=lambda p: p[i])]
                line = [coefficients[z] for z in indices]
                d = len(line)-1
                left[indices[0]], right[indices[d]] = line[0], line[-1]
                for z in range(1, d+1):
                    line = [(line[k]+line[k+1])/2 for k in range(len(line)-1)]
                    left[indices[z]], right[indices[d-z]] = line[0], line[-1]
            numerators = [rng.randrange(1, 9) for _ in range(r)]
            q = [F(x, sum(numerators)) for x in numerators]
            # Left moves vertex i to the midpoint, and right moves vertex j.
            qleft = q.copy()
            qleft[i], qleft[j] = q[i]/2, q[j]+q[i]/2
            qright = q.copy()
            qright[i], qright[j] = q[i]+q[j]/2, q[j]/2
            require(evaluate(left, q) == evaluate(coefficients, qleft),
                    f"Left simplex edge mismatch at degree={D}, edge={(i,j)}")
            require(evaluate(right, q) == evaluate(coefficients, qright),
                    f"Right simplex edge mismatch at degree={D}, edge={(i,j)}")
            comparisons += 2
    return {"degrees": list(range(1, 7)), "barycentric_coordinates": 4,
            "edges_per_degree": 6, "child_map_equalities": comparisons}


def audit_order_13():
    alpha, probability = F(6, 5), F(3, 10)
    stirling = [[0]*14 for _ in range(14)]
    stirling[0][0] = 1
    for n in range(1, 14):
        for k in range(1, n+1):
            stirling[n][k] = k*stirling[n-1][k]+stirling[n-1][k-1]
    falling, result = F(1), F(0)
    for k in range(1, 14):
        falling *= alpha-k+1
        result += stirling[13][k]*falling*probability**k
    expected = F(-6524240334632293437, 2980232238769531250)
    require(result == expected and result < 0, "Order-13 rational counterexample mismatch")
    return {"alpha": str(alpha), "bernoulli_probability": str(probability),
            "normalized_derivative": str(result)}


def main():
    rng = random.Random(9817)
    report = {
        "status": "PASS",
        "arithmetic": "integers and fractions; no floating point tolerance",
        "core_sha256": hashlib.sha256(CORE_PATH.read_bytes()).hexdigest(),
        "core_basename": CORE_PATH.name,
        "deterministic_point_seed": 9817,
        "moment_polynomials": audit_moments(),
        "all_nonzero_tail_conversions": audit_nonzero_tail_conversions(rng),
        "simplex_edge_multinomial_weights": audit_simplex_edge_splits(rng),
        "sharpness_counterexample": audit_order_13(),
        "scope": "Independent implementation audit; run verify_cm12.py for the full positivity certificate. Analytic reductions require the manuscript proof.",
    }
    target = BASE / "independent_audit_report.json"
    target.write_text(json.dumps(report, indent=2)+"\n")
    print(json.dumps(report, indent=2))
    print("Report:", target)


if __name__ == "__main__":
    main()
