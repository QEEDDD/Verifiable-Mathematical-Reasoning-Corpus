#!/usr/bin/env python3
"""Exact thirteenth-derivative obstruction for powers of CM functions.

f(t) = 1 + exp(-t), alpha = 6/5, t0 = log(7/3).
At t0 the normalized derivative moments of f are m_j = 3/10 (j>=1).
The normalized signed derivative of f**alpha is therefore the finite
Stirling polynomial computed below. No numerical transcendental evaluation
is needed to decide its sign.
"""
from fractions import Fraction as Q
import json


def certificate():
    n = 13
    alpha, p = Q(6, 5), Q(3, 10)
    stirling = [[0] * (n + 1) for _ in range(n + 1)]
    stirling[0][0] = 1
    for j in range(1, n + 1):
        for k in range(1, j + 1):
            stirling[j][k] = stirling[j-1][k-1] + k*stirling[j-1][k]
    falling, total = Q(1), Q(0)
    for k in range(1, n + 1):
        falling *= alpha-k+1
        total += stirling[n][k] * falling * p**k
    expected = Q(-6524240334632293437, 2980232238769531250)
    if total != expected or total >= 0:
        raise RuntimeError("Exact derivative obstruction failed")
    return {"f": "1 + exp(-t)", "alpha": str(alpha),
            "time": "log(7/3)", "derivative_order": n,
            "normalized_signed_derivative": str(total),
            "strictly_negative": True}


if __name__ == "__main__":
    print(json.dumps(certificate(), indent=2))
