#!/usr/bin/env python3
"""Exact certificate: positive real powers preserve CM derivatives through 12.

Every coefficient and subdivision operation is a Fraction or integer. NumPy is
used only as an object-array container; no floating-point operations or acceptance
tolerances occur. The accompanying proof gives the analytic moment reduction,
Bernstein geometry, lower-derivative implication, and extension in alpha.
"""
import math
from itertools import combinations
from fractions import Fraction
from fractions import Fraction as F
from itertools import product
from collections import defaultdict
from functools import lru_cache
from math import comb
import numpy as np
import sys,time

NMAX=12
zero=(0,)*NMAX
def mul(a,b):
 c=defaultdict(int)
 for p,v in a.items():
  for q,w in b.items():c[tuple(x+y for x,y in zip(p,q))]+=v*w
 return dict(c)
@lru_cache(None)
def moment(h,n):
 if n==0:return {zero:1}
 ans=defaultdict(int)
 for j in range(n):
  for p,v in mul(moment(h,j),moment(h+1,n-1-j)).items():
   q=list(p);q[h]+=1;ans[tuple(q)]+=v
 return dict(ans)
@lru_cache(None)
def bell(n,k):
 if n==k==0:return {zero:1}
 if n==0 or k==0:return {}
 ans=defaultdict(int)
 for j in range(1,n-k+2):
  for p,v in mul(moment(0,j),bell(n-j,k-1)).items():ans[p]+=comb(n-1,j-1)*v
 return dict(ans)
def pmul(a,b):
 c=[0]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):c[i+j]+=x*y
 return c
fall=[[1]]
for k in range(1,NMAX+1):fall.append(pmul(fall[-1],[2-k,1]))
def derivative(n):
 ans=defaultdict(lambda:[0]*(n+1))
 for k in range(1,n+1):
  for p,v in bell(n,k).items():
   for j,w in enumerate(fall[k]):ans[p][j]+=v*w
 return ans
def div_alpha(c):
 q=[c[0]]
 for k in range(1,len(c)-1):q.append(c[k]-q[-1])
 if c[-1]!=q[-1]:raise ArithmeticError('alpha division')
 while len(q)>1 and q[-1]==0:q.pop()
 return q
def split(a,axis):
 x=np.moveaxis(a,axis,0);n=x.shape[0]-1
 l=np.empty_like(x);r=np.empty_like(x)
 l[0]=x[0];r[n]=x[n]
 for k in range(1,n+1):
  x=(x[:-1]+x[1:])/F(2)
  l[k]=x[0];r[n-k]=x[-1]
 return np.moveaxis(l,0,axis),np.moveaxis(r,0,axis)
def check(a,depth=0,maxdepth=12):
 if min(a.flat)>=0:return True,1,depth
 if max(a.flat)<0:return False,1,depth
 if depth>=maxdepth:return None,1,depth
 varies=[max(abs(v) for v in np.diff(a,axis=j).flat) if a.shape[j]>1 else F(0) for j in range(a.ndim)]
 axis=max(range(a.ndim),key=lambda j:varies[j])
 c,d=split(a,axis)
 ok1,n1,d1=check(c,depth+1,maxdepth)
 if ok1 is not True:return ok1,n1,d1
 ok2,n2,d2=check(d,depth+1,maxdepth)
 return ok2,n1+n2,max(d1,d2)
def certify_nonzero_tails(n=12,r=6):
 groups=defaultdict(dict)
 coeff=derivative(n)
 if len(coeff)!=2**(n-1):raise ArithmeticError('monomial coverage')
 for p,c in coeff.items():groups[p[r:]][p[:r]]=div_alpha(c)
 if len(groups)!=64:raise ArithmeticError('group count')
 leaves=0;depth=0;fail=[];checked=0
 for tail,poly in groups.items():
  if not any(tail):continue
  checked+=1
  mins=tuple(min(e[j] for e in poly) for j in range(r))
  D=n-sum(tail)-sum(mins);K=max(map(len,poly.values()))-1
  arr=np.full((K+1,)+(D+1,)*(r-1),F(0),dtype=object)
  for e,c in poly.items():
   u=[e[j]-mins[j] for j in range(r)]
   prefixes=[sum(u[:j]) for j in range(r-1)]
   for vs in product(*(range(p+1) for p in prefixes)):
    inds=tuple(u[j]+vs[j] for j in range(r-1))
    weight=F(1)
    for j in range(r-1):weight*=F(comb(prefixes[j],vs[j]),comb(D,inds[j]))
    for i in range(K+1):
     b=sum((F(c[j]*comb(i,j),comb(K,j)) for j in range(min(i,len(c)-1)+1)),F(0))
     arr[(i,)+inds]+=b*weight
  ok,nn,dd=check(arr);leaves+=nn;depth=max(depth,dd)
  if ok is not True:fail.append((tail,ok,nn,dd))
 if checked!=63:raise ArithmeticError('nonzero-tail coverage')
 print('EXACT',n,'prefix',r,'nonzero-tail groups',checked,'leaves',leaves,'maxdepth',depth,'failed',len(fail),flush=True)
 if fail:print(fail[:10],flush=True)
 if fail:raise ArithmeticError('nonzero-tail certificate failed')
 return leaves,depth

@lru_cache(None)
def weak(n,r):
 if r==1:return ((n,),)
 return tuple((i,)+p for i in range(n+1) for p in weak(n-i,r-1))

def certify_zero_tail(n=12,r=6,maxdepth=25):
 poly={p[:r]:div_alpha(c) for p,c in derivative(n).items() if not any(p[r:])}
 pure=(n,)+(0,)*(r-1)
 if min(poly[pure])<0:raise ArithmeticError('pure negative')
 del poly[pure]
 mins=tuple(min(p[j] for p in poly) for j in range(r))
 if mins!=(1,1,0,0,0,0):raise ArithmeticError('special common monomial')
 D=n-sum(mins);K=max(map(len,poly.values()))-1
 exps=weak(D,r);loc={p:i for i,p in enumerate(exps)}
 arr=np.full((K+1,len(exps)),Fraction(0),dtype=object)
 for p,c in poly.items():
  u=tuple(p[j]-mins[j] for j in range(r));mult=math.factorial(D)
  mult=math.factorial(D)//math.prod(math.factorial(uj) for uj in u)
  for i in range(K+1):arr[i,loc[u]]=sum((Fraction(c[j]*math.comb(i,j),math.comb(K,j)) for j in range(min(i,len(c)-1)+1)),Fraction(0))/mult
 if not all(isinstance(v,Fraction) for v in arr.flat):raise ArithmeticError('exact coefficient types')
 # Exact arithmetic: no normalization or tolerance.
 lines={};lineof={}
 for i,j in combinations(range(r),2):
  gs=defaultdict(list)
  for p in exps:gs[tuple(p[h] for h in range(r) if h not in(i,j))].append(p)
  lines[(i,j)]=[np.array([loc[p] for p in sorted(g,key=lambda q:q[i])]) for g in gs.values()]
  lineof[(i,j)]={int(v):line for line in lines[(i,j)] for v in line}
 print('shape',arr.shape,'D,K',D,K,'mins',mins,flush=True)
 nodes=0
 def split_beta(a):
  x=a.copy();left=np.zeros_like(a);right=np.zeros_like(a);left[0]=x[0];right[K]=x[-1]
  for kk in range(1,K+1):
   x=(x[:-1]+x[1:])/Fraction(2);left[kk]=x[0];right[K-kk]=x[-1]
  return left,right
 def split_edge(a,edge):
  left=np.zeros_like(a);right=np.zeros_like(a)
  for inds in lines[edge]:
   x=a[:,inds];d=len(inds)-1
   left[:,inds[0]]=x[:,0];right[:,inds[d]]=x[:,-1]
   for kk in range(1,d+1):
    x=(x[:,:-1]+x[:,1:])/Fraction(2)
    left[:,inds[kk]]=x[:,0];right[:,inds[d-kk]]=x[:,-1]
  return left,right
 def check(a,depth=0,path=()):
  nonlocal nodes
  nodes+=1
  if min(a.flat)>=0:return True,1,depth
  if max(a.flat)<0:return False,1,depth
  if depth>=maxdepth:
   print('FAILPATH',path,'range',a.min(),a.max(),flush=True)
   return None,1,depth
  ib,jb=np.unravel_index(a.argmin(),a.shape)
  def score(values):
   values=values.copy();mn=min(values[0],values[-1]);variation=max(abs(np.diff(values)),default=0)
   for kk in range(1,len(values)):
    values=(values[:-1]+values[1:])/Fraction(2);mn=min(mn,values[0],values[-1])
   return mn,variation
  scores={None:score(a[:,jb])}
  for edge in lines:scores[edge]=score(a[ib,lineof[edge][jb]])
  edge=max(scores,key=scores.get)
  le,ri=split_beta(a) if edge is None else split_edge(a,edge)
  o1,n1,d1=check(le,depth+1,path+((edge,0),))
  if o1 is not True:return o1,n1,d1
  o2,n2,d2=check(ri,depth+1,path+((edge,1),))
  return o2,n1+n2,max(d1,d2)
 start=time.time();initial=[arr]
 for lev in range(0):initial=[v for a in initial for v in split_beta(a)]
 results=[]
 for idx,a in enumerate(initial):
  ans=check(a);results.append(ans)
  print('SLICE',idx,'RESULT',ans,'nodes',nodes,'seconds',time.time()-start,flush=True)
  if ans[0] is not True:break
 if any(ans[0] is not True for ans in results):raise ArithmeticError('zero-tail certificate failed')
 print('ALLRESULTS',results,flush=True)
 return sum(ans[1] for ans in results),max(ans[2] for ans in results)

if __name__=='__main__':
 start=time.time()
 ordinary=certify_nonzero_tails()
 special=certify_zero_tail()
 print('PASS: all 64 groups at order 12 have exact nonnegative Bernstein certificates.')
 print('Total leaves:',ordinary[0]+special[0],'; maximum depth:',max(ordinary[1],special[1]))
 print('Elapsed seconds:',time.time()-start)
