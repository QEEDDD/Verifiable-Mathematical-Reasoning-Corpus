"""Exact audit of the Hermitian counterexample to Hillar 2005, Conj. 1.6.

Run: python verify_hillar.py
Requires SymPy. No floating point operations or random tests are used.
The uniform proof is in hillar_hermitian_counterexample.tex; finite
recurrence checks here are additional independent audits.
"""
import json
from pathlib import Path
import sympy as s

I2 = s.eye(2)
Z = s.diag(1, -1)
X = s.Matrix([[0, 1], [1, 0]])
Y = s.Matrix([[0, -s.I], [s.I, 0]])
A, B = Z/s.sqrt(2), X/s.sqrt(2)

def zero_matrix(M):
    return all(s.simplify(x) == 0 for x in M)

def norm_squared(M):
    return s.simplify(s.trace(M.conjugate().T * M))

assert A == A.conjugate().T and B == B.conjugate().T
assert norm_squared(A) == norm_squared(B) == 1
assert zero_matrix(A*A-I2/2) and zero_matrix(B*B-I2/2)
assert zero_matrix(A*B+B*A)
assert not zero_matrix(A*B-B*A)
assert A*B-B*A == s.Matrix([[0, 1], [-1, 0]])

# Integer recurrences avoid radicals until applying the overall scaling.
T = [I2]
checked = 0
for length in range(1, 25):
    prev = T
    T = []
    for k in range(length+1):
        value = s.zeros(2)
        if k < len(prev):
            value += Z*prev[k]
        if k:
            value += X*prev[k-1]
        T.append(value)
    if length % 2 == 1 and length >= 3:
        r = (length+1)//2
        for j in range(1, r):
            # Unnormalized coefficients implied by the general theorem.
            assert T[2*j] == s.binomial(r-1,j)*Z
            assert T[2*j-1] == s.binomial(r-1,j-1)*X
            SA = T[2*j]/s.sqrt(2)**length
            SB = T[2*j-1]/s.sqrt(2)**length
            assert zero_matrix(A*SA-A*A*s.trace(A*SA))
            assert zero_matrix(B*SB-B*B*s.trace(B*SB))
            checked += 1

t = s.symbols("t", real=True)
for n in (2, 4, 6, 8):
    d = n//2
    block_Z = s.diag(s.eye(d), -s.eye(d))
    block_X = s.BlockMatrix([[s.zeros(d),s.eye(d)],
                            [s.eye(d),s.zeros(d)]]).as_explicit()
    An, Bn = block_Z/s.sqrt(n), block_X/s.sqrt(n)
    assert norm_squared(An) == norm_squared(Bn) == 1
    assert zero_matrix((An+t*Bn)**2-(1+t*t)*s.eye(n)/n)
    assert not zero_matrix(An*Bn-Bn*An)

u,v = s.symbols("u v", real=True)
a1,a2,a3,b1,b2,b3 = s.symbols("a1 a2 a3 b1 b2 b3", real=True)
AA = (u*I2+a1*X+a2*Y+a3*Z)/s.sqrt(2)
BB = (v*I2+b1*X+b2*Y+b3*Z)/s.sqrt(2)
w = a1*b1+a2*b2+a3*b3
actual = s.expand(4*s.trace(AA*AA*BB*BB)+2*s.trace(AA*BB*AA*BB))
expected = 1+2*(u*u+v*v+w*w)-2*u*u*v*v+12*u*v*w
normalizations = (u*u+a1*a1+a2*a2+a3*a3-1,
                  v*v+b1*b1+b2*b2+b3*b3-1)
G = s.groebner(normalizations,a3,b3,a2,b2,a1,b1,u,v)
assert G.reduce(s.expand(actual-expected))[1] == 0

# Algebraic certificates behind the quantitative neighborhood bound.
# Each RHS is nonnegative if |u|,|v|,|w| <= 1/10.
assert s.expand((u*u+v*v)/100-2*u*u*v*v
                - (u*u*(s.Rational(1,100)-v*v)
                   + v*v*(s.Rational(1,100)-u*u))) == 0
# 2|uv| <= u^2+v^2 gives 12|uvw| <= (3/5)(u^2+v^2).
assert s.Rational(2)-s.Rational(1,100)-s.Rational(3,5) == s.Rational(139,100)

def objective(A0,B0):
    return s.simplify(4*s.trace(A0*A0*B0*B0)+2*s.trace(A0*B0*A0*B0))

assert objective(A,B) == 1
P,Q = s.diag(1,0),s.diag(0,1)
assert norm_squared(P) == norm_squared(Q) == 1
assert P*Q == s.zeros(2)
assert objective(P,Q) == 0

report = {
    "status": "PASS",
    "arithmetic": "exact symbolic, no floating point",
    "source": "Hillar, arXiv:math/0507166v1, 8 July 2005, Conjecture 1.6",
    "scope": "Hermitian assertion only; matrices are indefinite",
    "recurrence_pairs_checked": checked,
    "even_degrees_checked": list(range(4,25,2)),
    "block_dimensions_checked": [2,4,6,8],
    "Pauli_coordinate_identity": "exact reduction modulo norm constraints",
    "local_lower_bound": "F-1 >= (139/100)(u^2+v^2)+2w^2 for |u|,|v|,|w|<=1/10",
    "local_minimum_value": 1,
    "global_minimum_value": 0,
    "historical_priority": "not asserted",
}
out = Path(__file__).with_name("verification_report.json")
out.write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps(report,indent=2))
