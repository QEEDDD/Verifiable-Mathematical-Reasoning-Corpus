RENYI ENTROPY UNDER HEAT FLOW
Research manuscript prepared for Keio, 15 November 2026

Main files
  renyi_no_universal_order.pdf: complete five-page analytic proof.
  renyi_no_universal_order.tex: standalone LaTeX source.
  verify_renyi.py: exact symbolic coefficient checks and an Arb interval
    certificate for one explicitly specified real-line Renyi-2 witness.

Main theorem
For each fixed finite alpha > 0, the family
  G_s(x)(1 + cos(x)/4 + cos(2x)/16)
after normalization contains a smooth positive density for which an entropy
time derivative violates the alternating-sign hierarchy. The window variance,
derivative order, and time may depend on alpha. This is not one density with
a simultaneous assertion for all alpha. No log-concavity assertion is made.

Verification
  python3 verify_renyi.py
Requires sympy and python-flint; python-flint 0.9.0 was used.
The symbolic checks are exact. The finite witness is certified at 96 and
160 bits, with 337/10000 < h_2''''(1/10) < 338/10000. Its density is
  G_1000(x)(1 + 9*cos(x)/10)/(1 + 9*exp(-500)/10).
This finite computation does not formally verify the general analytic proof.
The general theorem does not depend on the numerical certificate.

Status
The proof was checked in this research session, including a separate
mathematical review. It has not received external peer review or formal
proof-assistant verification. A bounded literature search did not establish
historical priority. The Shannon counterexample and the periodic/Gaussian
method have prior sources, explicitly credited in the manuscript. The claim
here concerns all finite positive Renyi orders; it is not a new Shannon
counterexample, not a Tsallis classification, and not a classification of
entropy orders at each fixed derivative order.

Additional research notes, if present in the archive, are separate projects.
Their own scope and source limitations apply; they are not dependencies of
the Renyi theorem.
