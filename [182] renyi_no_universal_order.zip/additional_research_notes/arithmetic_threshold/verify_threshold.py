"""Exact checks for the general prime threshold construction, 14 Nov 2026.
This is a verification script, not a substitute for the all-prime proof.
"""
from fractions import Fraction
from math import gcd
from sympy import primerange

def v2(x):
    x=abs(x)
    assert x
    return (x&-x).bit_length()-1

def construct(p):
    b=(p-1).bit_length()-1
    tau=v2(p*p-1)-1
    J=tau+b
    L=1<<b
    M=1<<(b+2)
    C=1<<(tau-1)
    a=tau+2*b+3
    Q=1<<J
    high=(p-1-L)//2
    raw={}
    for r in range(1,Q,2):
        if r in raw: continue
        u=r
        for i in range(L):
            assert u not in raw and (-u)%Q not in raw
            e=b+int(i//2<high)
            y=(r*pow(p,i,M)+(0 if i%2==0 else 1<<e))%M
            assert y%2
            raw[u]=y
            raw[(-u)%Q]=-y
            u=u*p%Q
        assert u==r
    assert len(raw)==Q//2
    H={u:C*x for u,x in raw.items()}
    G={u:H[u*p%Q]-p*H[u] for u in H}
    return locals()

def check_hypotheses(data):
    p,b,tau,J,L,M,C,a,Q,raw,H,G=(data[k] for k in ['p','b','tau','J','L','M','C','a','Q','raw','H','G'])
    assert all(raw[u]%2 and (raw[u]-u)%(1<<b)==0 for u in raw)
    assert all(H[(-u)%Q]==-H[u] for u in H)
    for k in range(1,J):
        seen={}
        for u,x in H.items():
            r=u%(1<<k)
            z=x%(1<<k)
            if r in seen: assert seen[r]==z
            seen[r]=z
    assert sum(1<<v2(x) for x in G.values())==(p-1)*sum(1<<v2(x) for x in H.values())
    assert 4*max(max(map(abs,H.values())),max(map(abs,G.values())))+1 < 1<<(a+1)
    assert a<=3*b+4

def digit(x,i,a):
    y=(x+(1<<(a+1))-1)//2
    return 2*((y>>i)&1)-1

def check_full_okada(data):
    p,a,Q,H,G=(data[k] for k in ['p','a','Q','H','G'])
    # eta_i and g_i are well-defined on odd residues modulo 2^i.
    eta=[]
    gam=[]
    for i in range(a+1):
        R=1<<i
        ei={}
        gi={}
        for u in range(1,1<<a,2):
            r=u%R
            e=digit(1+4*H[u%Q],i,a)
            g=digit(-1+4*G[u%Q],i,a)
            if r in ei: assert ei[r]==e and gi[r]==g
            ei[r]=e
            gi[r]=g
        eta.append(ei)
        gam.append(gi)
    N=(1<<a)*p
    f=[]
    for n in range(1,N+1):
        i=a-min(v2(n),a)
        z=n//p if n%p==0 else n
        z>>=v2(z)
        tab=gam if n%p==0 else eta
        f.append(tab[i][z%(1<<i)])
    assert set(f)=={-1,1} and sum(f)==0
    # Primary-source Okada epsilon equations.
    for ell,exp in [(2,a),(p,1)]:
        total=Fraction()
        for n,fn in enumerate(f,1):
            x=n
            val=0
            while x%ell==0:
                x//=ell
                val+=1
            eps=Fraction(exp)+Fraction(1,ell-1) if val>=exp else Fraction(val)
            total+=fn*eps
        assert total==0,(p,ell,total)
    # Primary-source Okada monoid equation at every unit residue.
    # Because f depends on n mod p only via p | n, it suffices to check odd n mod 2^a.
    for n in range(1,1<<a,2):
        total=Fraction(eta[0][0],1)+Fraction(gam[0][0],p-1)
        total*=Fraction(1,1<<(a-1))
        for i in range(a):
            j=a-i
            R=1<<j
            orbit=[]
            u=n%R
            while u not in orbit:
                orbit.append(u)
                u=u*p%R
            assert u==orbit[0]
            length=len(orbit)
            weighted=sum(Fraction(gam[j][u],p**(t+1)) for t,u in enumerate(orbit))
            weighted/=1-Fraction(1,p**length)
            total+=Fraction(eta[j][n%R]+weighted,1<<i)
        assert total==0,(p,n,total)
    return N

if __name__=='__main__':
    primes=list(primerange(3,300))
    for p in primes:
        d=construct(int(p))
        check_hypotheses(d)
    print(f'Exact Theorem E hypotheses passed for all {len(primes)} odd primes below 300.')
    for p in [3,5,7,11,13]:
        d=construct(p)
        N=check_full_okada(d)
        print(f'p={p}, a={d["a"]}, N={N}: all values +/-1, zero sum, epsilon equations and every monoid equation passed exactly.')
