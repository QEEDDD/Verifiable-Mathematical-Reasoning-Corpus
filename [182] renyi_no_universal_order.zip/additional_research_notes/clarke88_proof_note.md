# Effective dilates of Clarke's six-dimensional example

Internal research note, 14 November 2026. This supplies a counterexample to the **suggested dichotomy following Question 8.8**, not a full solution of the set-classification question itself.

Primary source: Oliver Clarke, *The equivariant Ehrhart theory of polytopes with order-two symmetries: Part II*, [arXiv:2610.17988v1](https://arxiv.org/html/2610.17988v1), submitted 13 October 2026. The live arXiv abstract page was checked on 14 November 2026 and lists only v1. The relevant source locations are Example 5.6, Proposition 6.5, and Question 8.8. Source text is locally available at `/tmp/2610.17988.txt`. No claim of literature priority is made: targeted searches did not locate this dilation calculation, but a search is not a proof of novelty.

## Precise result

Let \(P\subset\mathbb R^6\) be the convex hull of
\[
\begin{array}{ll}
(1,0,0,0,0,0),&(0,0,0,1,0,0),\\
(0,0,1,0,0,0),&(0,0,0,0,0,1),\\
(0,1,0,1,1,0),&(1,1,0,0,1,0),\\
(0,0,1,1,1,0),&(1,1,0,0,0,1).
\end{array}
\]
The involution \(\sigma\) exchanges the first and last blocks of three coordinates. This is exactly the polytope already constructed in Clarke's Example 5.6; neither its construction nor its ineffectiveness at dilation 1 is new here.

**Theorem.** Its equivariant \(H^*\)-series is effective at precisely the dilations \(m\ge2\). Consequently its set of effective odd dilations is
\[
E(P)=\{3,5,7,\ldots\}.
\]
In particular, the suggested dichotomy “empty or all odd positive integers” after Question 8.8 is false.

## Short proof of the dichotomy counterexample

Write \(H_m(t)=h^*_{mP}(t)\) and \(F_m(t)=\varphi_{mP}(t)(\sigma)\). For a group of order two, the coefficients of the trivial and sign representations are respectively \((H_m+F_m)/2\) and \((H_m-F_m)/2\).

Clarke's Example 5.6 supplies
\[
H_1=1+t+t^3+t^4,
\qquad F_1=1-t+2t^2-t^3+t^4.
\]
Thus the coefficient of the sign representation in degree 2 is \(-1\), so \(1\notin E(P)\).

The dimension is six and the homogeneous involution has eigenvalue multiplicities \((p,q)=(4,3)\). Its lattice-point counts \(L(k)=|kP\cap\mathbb Z^6|\) and fixed-point counts \(N(k)=|(kP)^\sigma\cap\mathbb Z^6|\) satisfy
\[
\sum_{k\ge0}L(k)t^k=\frac{1+t+t^3+t^4}{(1-t)^7},
\qquad
\sum_{k\ge0}N(k)t^k=\frac{1-t+2t^2-t^3+t^4}{(1-t)^4(1+t)^3}.
\]
In particular
\[
L(k)=\binom{k+6}{6}+\binom{k+5}{6}+\binom{k+3}{6}+\binom{k+2}{6},
\]
and cancellation/expansion of the second rational function gives
\[
N(k)=\begin{cases}
(k+2)(k+3)(k+4)/24,&k\text{ even},\\
k(k^2-1)/24,&k\text{ odd}.
\end{cases}
\]
The binomial terms are zero when their nonnegative upper argument is less than 6. These expressions are exact at all \(k\ge0\).

Dilation takes the subsequences \(L(mk)\) and \(N(mk)\). Therefore
\[
H_m=(1-t)^7\sum_{k\ge0}L(mk)t^k,
\qquad F_m=(1-t)^4(1+t)^3\sum_{k\ge0}N(mk)t^k.
\]
At \(m=3\), exact substitution gives
\[
\begin{aligned}
H_3&=1+106t+728t^2+1246t^3+728t^4+106t^5+t^6,\\
F_3&=1+26t^2+26t^4+t^6.
\end{aligned}
\]
Both representation multiplicity polynomials are nonnegative:
\[
\begin{aligned}
(H_3+F_3)/2&=1+53t+377t^2+623t^3+377t^4+53t^5+t^6,\\
(H_3-F_3)/2&=53t+351t^2+623t^3+351t^4+53t^5.
\end{aligned}
\]
Thus \(3\in E(P)\) while \(1\notin E(P)\). This already proves the promised counterexample. The rational-series derivation, rather than only counting a finite list of lattice points, ensures no nonzero higher-degree tail has been omitted.

## Exact proof for all dilations

Let \(d_j=[t^j](1-t)^4(1+t)^3\), so
\[
(d_0,\ldots,d_7)=(1,-1,-3,3,3,-3,-1,1).
\]
For \(0\le i\le6\), set
\[
h_i(m)=\sum_{j=0}^i(-1)^j\binom7j L(m(i-j)),
\qquad
f_i(m)=\sum_{j=0}^i d_jN(m(i-j)).
\]
These are explicit polynomials in \(m\) separately for even and odd \(m\). The multiplicities are \(a_i=(h_i+f_i)/2\), \(b_i=(h_i-f_i)/2\).

An exact, finite polynomial certificate is provided by `clarke88_certificates.json`, generated and verified by `clarke88_verify.py`. For odd dilations substitute \(m=2r+3\), and for even dilations substitute \(m=2r+2\). Each JSON row lists the coefficients in increasing powers of \(r\) of \(90a_i\) and \(90b_i\). Every listed coefficient is a nonnegative integer. Thus \(a_i,b_i\ge0\) for every integer \(r\ge0\), proving effectiveness for every \(m\ge2\).

This is a proof by polynomial identity and coefficient positivity, not a check up to a numerical cutoff. The script also verifies the two rational-series identities symbolically, including vanishing of all terms of degree above six. Since the coefficients are representation multiplicities in the integral representation ring, nonnegative values are nonnegative integers; this also follows directly from the lattice action.

## General necessary condition on effective-dilate sets

For an arbitrary invariant lattice polytope with a nontrivial involution, the odd-effective set is either empty or cofinite among the odd positive integers. This corrects the suggested dichotomy to a weaker statement, without claiming every cofinite set can occur.

Indeed, if \(\varphi_P\) is not polynomial, Proposition 6.5(a) makes every odd dilate non-polynomial. An effective equivariant \(H^*\)-series must be polynomial because its dimension evaluation is the ordinary polynomial \(h^*\). Hence \(E(P)=\varnothing\).

If \(\varphi_P\) is polynomial, every odd dilate is polynomial. Write \(d=\dim P\), and \(f=\dim P^\sigma<d\). For each \(1\le i\le d\), ordinary Ehrhart theory and the Eulerian generating-function identity give
\[
[t^i]h^*_{mP}(t)
=\operatorname{vol}_{\mathbb Z}(P)\,A(d,i-1)\,m^d+O(m^{d-1}),
\]
where \(\operatorname{vol}_{\mathbb Z}\) here means lattice-normalized *Euclidean* volume (the leading Ehrhart coefficient, not factorial-normalized volume), and \(A(d,i-1)>0\) is an Eulerian number. Meanwhile each coefficient of \(F_m\) is a fixed finite linear combination of \(N(mj)\), and so is \(O(m^f)\). Therefore \([t^i]h^*_{mP}>|[t^i]F_m|\) for all sufficiently large odd \(m\), simultaneously for \(1\le i\le d\). The constant coefficient is the trivial representation. Polynomiality and Ehrhart reciprocity bound both numerator degrees by \(d\), so this proves effectiveness of all sufficiently large odd dilates.

If the involution acts trivially, all dilates are effective and the conclusion still holds.

## Novelty and scope checks

- Corpus files #070 and #071 treat Clarke Conjecture 8.5, Question 6.6, and Question 6.7. Searching their text found no Question 8.8 or the above third-dilate coefficients.
- This reuses Clarke's known polytope and known \(m=1\) numerator. The new calculation is its effective-dilate set and the failure of the suggested odd-dilate dichotomy.
- This does **not** refute Clarke's Conjecture 8.7 (effectiveness is preserved by dilation). A failure at dilation 1 followed by success at dilation 3 is compatible with that conjecture.
- This does **not** classify all realizable odd-effective sets; Question 8.8 in its broad characterization form remains only partially addressed.
- The unrelated Tu unimodular-defect search found no counterexample through dimension 8. Those scans are exploratory floating-point filters, not publication-quality exact certificates and should not be presented as a new theorem.
