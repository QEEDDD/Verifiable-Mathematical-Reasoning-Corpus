"""Exact certificates for the effective-dilate set of Clarke Example 5.6.

Source: https://arxiv.org/html/2610.17988v1, Example 5.6, Question 8.8.
No floating point arithmetic is used. SymPy is needed only for polynomial algebra.
"""
from math import comb
import json
from pathlib import Path
import sympy as sp

m, r, k, t = sp.symbols("m r k t")
def polynomial_binomial(x, n):
    return sp.prod(x-j for j in range(n))/sp.factorial(n)

L = sp.expand(sum(polynomial_binomial(k+6-j, 6) for j in (0, 1, 3, 4)))
N_even = (k+2)*(k+3)*(k+4)/24
N_odd = k*(k*k-1)/24
D = sp.Poly((1-t)**4 * (1+t)**3, t)
def polynomial_series(poly, variable=t):
    """Sum poly(n)*variable**n exactly for a polynomial written in k."""
    answer = 0
    power_series = 1/(1-variable)
    P = sp.Poly(poly,k)
    for j in range(P.degree()+1):
        answer += P.nth(j)*power_series
        power_series = variable*sp.diff(power_series,variable)
    return sp.cancel(answer)

H = [sp.expand(sum((-1)**j*comb(7, j)*L.subs(k,m*(i-j))
                  for j in range(i+1))) for i in range(7)]
assert sp.cancel((1-t)**7*polynomial_series(L.subs(k,m*k))
                 - sum(H[i]*t**i for i in range(7))) == 0

certificates = {}
for parity, shift in (("odd", 3), ("even", 2)):
    F = [sp.expand(sum(D.nth(j) *
                     (N_even if parity == "even" or (i-j)%2 == 0 else N_odd)
                     .subs(k, m*(i-j))
                     for j in range(i+1))) for i in range(7)]
    if parity == "even":
        Nm_series = polynomial_series(N_even.subs(k,m*k))
    else:
        Nm_series = polynomial_series(N_even.subs(k,2*m*k)).subs(t,t**2)
        Nm_series += t*polynomial_series(N_odd.subs(k,m*(2*k+1))).subs(t,t**2)
    assert sp.cancel(D.as_expr()*Nm_series
                     - sum(F[i]*t**i for i in range(7))) == 0
    coefficients = []
    for i in range(7):
        row = {"degree": i}
        for sign, name in ((1,"trivial"), (-1,"sign")):
            # Coefficient j of this polynomial is 90 times the coefficient
            # of r**j in the corresponding representation multiplicity.
            R = sp.Poly(sp.expand(45*(H[i]+sign*F[i]).subs(m, 2*r+shift)), r)
            values = [R.nth(j) for j in range(7)]
            assert all(c.is_Integer and c >= 0 for c in values), (parity,i,name,R)
            row[name] = [int(c) for c in values]
        coefficients.append(row)
    certificates[parity] = coefficients
    if parity == "odd":
        H3 = [int(x.subs(m,3)) for x in H]
        F3 = [int(x.subs(m,3)) for x in F]
        assert H3 == [1,106,728,1246,728,106,1]
        assert F3 == [1,0,26,0,26,0,1]
        assert [int(x.subs(m,1)) for x in H] == [1,1,0,1,1,0,0]
        assert [int(x.subs(m,1)) for x in F] == [1,-1,2,-1,1,0,0]

# The rational-series identities establish the vanishing of ALL further
# coefficients; checking a finite prefix alone would not suffice.
source_h = 1+t+t**3+t**4
source_f = 1-t+2*t**2-t**3+t**4
source_N = source_f/((1-t)**4*(1+t)**3)
constituent_series = polynomial_series(N_even.subs(k,2*k)).subs(t,t**2)
constituent_series += t*polynomial_series(N_odd.subs(k,2*k+1)).subs(t,t**2)
assert sp.cancel(source_N-constituent_series) == 0

out = Path(__file__).with_name("clarke88_certificates.json")
out.write_text(json.dumps(certificates,indent=2)+"\n")
print("PASS: exact formal positivity for every odd m >= 3 and even m >= 2.")
print("m=1 is ineffective; effective odd set is {3,5,7,...}.")
print("h*_3P =", H3)
print("trace_3P =", F3)
print("Integer coefficient certificates:",out)
