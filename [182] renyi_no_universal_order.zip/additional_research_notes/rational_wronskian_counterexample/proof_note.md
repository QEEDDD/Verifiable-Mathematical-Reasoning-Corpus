# Rational functions with constant Wronskian and arbitrarily many poles

Working mathematical note; exact proof, not a priority claim.

## Result

Let K be a field of characteristic zero, let n ≥ 2, and let P ∈ K[x] be a nonzero polynomial. Choose Q ∈ K[x] satisfying Q′ = P². For j = 0,…,n−1 set

\[
F_j(x)=\frac{Q(x)^j}{P(x)^{n-1}}.
\]

With the convention W(F₀,…,Fₙ₋₁) = det(Fⱼ⁽ⁱ⁾)ᵢ,ⱼ₌₀ⁿ⁻¹,

\[
\boxed{W(F_0,\ldots,F_{n-1})=\prod_{j=0}^{n-1}j!\ne0.}
\]

In particular, the functions are linearly independent over K.

The integration constant in Q can be chosen so that gcd(P,Q)=1. For this choice, every Fⱼ has exactly the same finite poles: the roots of P. A root of P of multiplicity m is a pole of order (n−1)m of every Fⱼ. Thus one may prescribe any finite pole set (including any number of distinct real poles), and realize it in every dimension n ≥ 2 with a nonzero constant Wronskian. Over K one prescribes a pole divisor defined over K, equivalently a polynomial P ∈ K[x].

## Proof

We use two elementary determinant identities. If h and uⱼ are differentiable sufficiently many times, then

\[
W(hu_0,\ldots,hu_{n-1})=h^nW(u_0,\ldots,u_{n-1}). \tag{1}
\]

Indeed, by Leibniz's rule the derivative matrix on the left is the product of a lower triangular matrix with diagonal entries h and the derivative matrix of the uⱼ. The determinant of the first matrix is hⁿ. This is an algebraic identity in the differential field K(x).

For a function Q, repeated chain rule similarly gives

\[
W(u_0\circ Q,\ldots,u_{n-1}\circ Q)
 =(Q')^{n(n-1)/2}(W(u_0,\ldots,u_{n-1})\circ Q). \tag{2}
\]

The corresponding lower triangular matrix has diagonal entries 1,Q′,(Q′)²,…,(Q′)ⁿ⁻¹. Possible zeros of Q′ cause no difficulty: this is again a differential identity, not a change of coordinates requiring a global inverse.

For uⱼ(t)=tʲ the derivative matrix is upper triangular, with diagonal entries j!. Consequently, writing N=n(n−1)/2 and h=P⁻⁽ⁿ⁻¹⁾, equations (1) and (2) imply

\[
W(F_0,\ldots,F_{n-1})
 =P^{-n(n-1)}(Q')^N\prod_{j=0}^{n-1}j!
 =P^{-2N}(P^2)^N\prod_{j=0}^{n-1}j!
 =\prod_{j=0}^{n-1}j!.
\]

Characteristic zero guarantees that Q exists by termwise polynomial integration. Start with one primitive Q₀. There are only finitely many roots a of P in an algebraic closure, hence finitely many forbidden constants −Q₀(a). Since K is infinite, choose c ∈ K outside their intersection with K and put Q=Q₀+c. Then Q(a) ≠ 0 at every root a of P. The assertions about pole locations and orders follow directly. ∎

These determinant transformation identities are classical. The note does not claim their discovery or priority for this construction.

## Small explicit real counterexample

Take

\[
P=x^2-1,\qquad Q=\frac{x^5}{5}-\frac{2x^3}{3}+x.
\]

Then Q′=(x²−1)², and Q(1)=8/15, Q(−1)=−8/15. Thus

\[
f=\frac1{x^2-1},\qquad
g=\frac{x^5/5-2x^3/3+x}{x^2-1}
\]

both have simple poles at the two distinct real points −1 and 1. Directly,

\[
W(f,g)
 =\frac1P\left(\frac{Q'}P-\frac{QP'}{P^2}\right)
   -\left(-\frac{P'}{P^2}\right)\frac QP
 =\frac{Q'}{P^2}=1.
\]

For n=3, the concrete triple (P⁻², QP⁻², Q²P⁻²) has Wronskian 2; all three functions have poles of order two at ±1. The theorem handles every n, not merely finitely many checked instances. A translation x↦x−1 moves one pole to 0 if desired.

## Exact claim contradicted in the accessible source

The accessible primary text is Carlos Hermoso and Juan Gerardo Alcázar, *Nonzero Constant Wronskians of Polynomials and Laurent Polynomials, and Geometric Consequences*, arXiv:2410.18867v1, posted 24 October 2024:

https://arxiv.org/html/2410.18867v1

Section 4, Theorem 22 asserts impossibility of a nonzero constant Wronskian for two linearly independent rational functions with at least two different poles. The paragraph immediately following its proof proposes the analogous impossibility for every n ≥ 3 as an open problem. The explicit pair above contradicts Theorem 22 as written, and the universal construction supplies counterexamples to that conjecture in every dimension.

The source permits a characteristic-zero coefficient field, and the example already has rational coefficients and two real poles. No issue about complex poles, poles at infinity, or nonreal coefficients is involved. Both functions individually have both finite poles, so the ambiguity between a shared pole set and the union of pole sets does not affect the example. The source's partial fraction form explicitly permits polynomial parts, which g has.

A published article with shortened title, *Nonzero Constant Wronskians of Polynomials and Laurent Polynomials*, by Juan G. Alcázar and Carlos Hermoso appears in *The American Mathematical Monthly* 133(3) (2026), 250–267, DOI 10.1080/00029890.2025.2601468. The publisher's accessible abstract still describes an n=2 impossibility result and n≥3 open question. Its full text could not be accessed in this investigation (HTTP 403), so **Theorem 22 refers specifically to the arXiv v1, not to an independently checked final journal numbering or wording**.

Publisher: https://www.tandfonline.com/doi/full/10.1080/00029890.2025.2601468

Institutional record: https://portalcientifico.uah.es/documentos/69b610df7b66766ff3dbd33f

Author publication list: https://juange-alcazar.web.uah.es/Publications.htm

Targeted searches for the paper title with “correction,” “erratum,” and “counterexample” found no correction in the returned results. This bounded search does not establish that none exists or that the counterexample is new.

## Where the pole argument breaks

The proof of Theorem 22 isolates a determinant summand having maximal poles at two different points and argues that other summands cannot cancel it because none has the same pair of pole orders. This inference is invalid: one group of summands can cancel the principal part at the first pole, while a different group cancels the principal part at the second pole.

For example,

\[
\frac1{(x^2-1)^2}
 =\frac1{4(x-1)^2}-\frac1{4(x-1)}
 +\frac1{4(x+1)^2}+\frac1{4(x+1)}.
\]

The left side has poles at both points, while every summand on the right has only one. Thus simultaneous pole-order labels do not provide a linearly independent decomposition of rational functions. Laurent principal parts must be tracked locally and summed at each pole.

For the displayed counterexample,

\[
g=R+\frac{8x}{15P},\qquad R=\frac{x^3}{5}-\frac{7x}{15},
\]

and

\[
W\left(\frac1P,\frac{8x}{15P}\right)=\frac8{15P^2},\qquad
W\left(\frac1P,R\right)=1-\frac8{15P^2}.
\]

The polar terms therefore cancel exactly, leaving 1.

## Optional classification for pairs

Let f ∈ C(x) be nonzero and let c ≠ 0. There exists g ∈ C(x) with W(f,g)=c if and only if the rational function f⁻² has zero residue at every finite pole. When this holds, all solutions are

\[
g=f(C+cR),\qquad R'=f^{-2},\quad C\in\mathbb C.
\]

Indeed, W(f,g)=f²(g/f)′. A rational function has a rational primitive if and only if its partial fractions have no simple-pole terms: polynomial terms and poles of order at least two integrate rationally, whereas the derivative of a rational function has no simple-pole residue. This proves both directions and the formula for all solutions. In particular, f=1/P always qualifies, because f⁻²=P² is polynomial.

This criterion concerns a prescribed first function f and is not presented as a classification of all higher-dimensional constant-Wronskian spaces.

## An actual obstruction at infinity

If all rational functions u₁,…,uₙ are strictly proper, then each uⱼ⁽ⁱ⁾(x)=O(x⁻¹⁻ⁱ) as x→∞. Every determinant product defining their Wronskian is therefore O(x⁻ⁿ⁽ⁿ⁺¹⁾/²), so the Wronskian cannot be a nonzero constant. Thus behavior at infinity provides an obstruction; the mere number or location of finite poles does not. The source's stated theorem does not assume strict properness.

## Corpus connection and limits

The construction transfers the reduction-of-order/Wronskian conservation idea underlying the discrete Abel/Casoratian tool: choose one solution and solve the determinant equation for a second. A second transfer is the insistence on local principal-part cancellation rather than a global pole-count heuristic. The remaining lift to all n uses determinant covariance and the monomial Vandermonde structure. These connections motivate the proof, but no assertion is made that all ten corpus tools are logically necessary.

The exact mathematical conclusions of this note are the displayed identities, the arbitrary finite-pole construction, and the contradiction to the accessible arXiv statement. Priority, any independent earlier correction, the precise final journal statement, and downstream impact on other theorems require separate verification.
