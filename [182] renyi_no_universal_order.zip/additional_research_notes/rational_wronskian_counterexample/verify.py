"""Exact symbolic checks accompanying the all-n proof (not a substitute for it)."""
import math
import sympy as sp

x = sp.symbols("x")
P = x**2 - 1
Q = x**5 / sp.Integer(5) - 2*x**3 / sp.Integer(3) + x
assert sp.expand(sp.diff(Q, x) - P**2) == 0
assert Q.subs(x, 1) == sp.Rational(8, 15)
assert Q.subs(x, -1) == sp.Rational(-8, 15)
assert sp.gcd(P, Q) == 1

def wronskian(functions):
    return sp.factor(sp.Matrix([
        [sp.diff(f, x, i) for f in functions]
        for i in range(len(functions))
    ]).det(method="domain-ge"))

for n in range(2, 6):
    functions = [Q**j / P**(n - 1) for j in range(n)]
    actual = wronskian(functions)
    expected = math.prod(math.factorial(j) for j in range(n))
    assert actual == expected, (n, actual, expected)
    print(f"n={n}: W={actual}, all {n} functions have both real poles +/-1")

R = x**3/sp.Integer(5) - 7*x/sp.Integer(15)
assert sp.factor(Q/P - R - 8*x/(15*P)) == 0
assert sp.factor(wronskian([1/P, 8*x/(15*P)]) - 8/(15*P**2)) == 0
assert sp.factor(wronskian([1/P, R]) - 1 + 8/(15*P**2)) == 0
partial = 1/(4*(x-1)**2)-1/(4*(x-1))+1/(4*(x+1)**2)+1/(4*(x+1))
assert sp.factor(1/P**2 - partial) == 0
print("All exact identity, pole noncancellation, and cancellation checks passed.")
