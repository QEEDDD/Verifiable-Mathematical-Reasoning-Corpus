#!/usr/bin/env python3
"""Exact coefficient checks and certified finite Renyi-2 heat witness.

Dependencies: sympy and python-flint (tested with python-flint 0.9.0).
This checks exact algebra and a finite interval computation. It does not
machine-verify the general Fourier/localization proof in the accompanying note.
"""

import json
import math

import sympy as sp
from flint import arb, arb_series, ctx


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def coefficients():
    a, e, d = sp.symbols("alpha epsilon delta")
    a1 = a * (a - 1) * e**2 / 4
    a2 = sp.prod(a - j for j in range(4)) * e**4 / 64
    a3 = a * (a - 1) * (a - 2) * e**2 * d / 8
    a3 += sp.prod(a - j for j in range(6)) * e**6 / 2304
    c2 = sp.cancel((a2 - a1**2 / 2) / (1 - a))
    c3 = sp.cancel((a3 - a1 * a2 + a1**3 / 3) / (1 - a))
    expected_c2 = a * (a**2 + 3 * a - 6) * e**4 / 64
    q = a**4 + 4 * a**3 - 4 * a**2 - 25 * a + 30
    expected_c3 = a * (2 - a) * e**2 * d / 8 - a * q * e**6 / 576
    require(sp.expand(c2 - expected_c2) == 0, "c2 identity failed")
    require(sp.expand(c3 - expected_c3) == 0, "c3 identity failed")
    # On [0,2], |Q(a)| is at most this sum of absolute monomial bounds.
    q_bound = 2**4 + 4 * 2**3 + 4 * 2**2 + 25 * 2 + 30
    require(q_bound == 144, "coarse polynomial bound failed")
    circle_lower_factor = sp.Rational(1, 16) - sp.Rational(q_bound, 16 * 576)
    require(circle_lower_factor == sp.Rational(3, 64), "c3 lower bound failed")
    return {"c2": str(sp.factor(c2)), "c3": str(sp.factor(c3)),
            "fixed_profile_c3_factor_lower_bound": str(circle_lower_factor)}


def finite_witness(bits):
    ctx.prec = bits
    ctx.cap = 5
    # t = 1/10 + x; coefficients through x^4 are interval enclosures.
    t = arb_series([arb(1) / 10, arb(1)], 5)
    s = arb(1000)
    epsilon = arb(9) / 10
    v = s + t
    f = 1 + 2 * epsilon * (-s * t / (2 * v) - s * s / (4 * v)).exp()
    f += epsilon**2 / 2 * (-s * t / v).exp() * (1 + (-s * s / v).exp())
    entropy_up_to_constant = v.log() / 2 - f.log()
    fourth = math.factorial(4) * entropy_up_to_constant[4]
    require(fourth > arb(337) / 10000, "fourth derivative lower certificate failed")
    require(fourth < arb(338) / 10000, "fourth derivative upper certificate failed")
    return {"precision_bits": bits, "h2_fourth_derivative": str(fourth),
            "certified_rational_interval": "(337/10000, 338/10000)",
            "violates_required_h2_fourth_le_zero": True}


if __name__ == "__main__":
    print(json.dumps({"coefficient_checks": coefficients(),
                      "finite_witness_checks": [finite_witness(96), finite_witness(160)]},
                     indent=2))
