Counterexamples to Iterated Turan Positivity for Multiplier Sequences
November 2026 — reproducible working proof note

RESULT
For every integer K >= 6, exp(x)*(x+10*K)^2*(x+K)^2 has a strictly
positive multiplier sequence whose sixth iterated Turan quantity at K
is strictly negative. The parameter K remains fixed during iteration.
This is a negative answer to Csordas–Dimitrov (2000), Problem 3.1,
in its original domain n >= r, and to Branden's shifted Problem 8.1.

SINGLE EXAMPLE
exp(x)*(x+100)^2*(x+10)^2 has EGF coefficients
n^4 + 214*n^3 + 13451*n^2 + 206334*n + 1000000.
At r=6,n=10 the exact normalized ratio lies strictly between
-451/100000 and -450/100000. All 48 prerequisite entries are positive.

FINITE POLYNOMIAL
(1+x/50000)^50000*(x+100)^2*(x+10)^2 also fails at r=6,n=10.
Its degree is 50004 and every root is a negative real number.

REPRODUCE (Python 3.8 or newer; standard library only)
python3 verify_turan_theorem.py
python3 verify_turan_finite.py
python3 independent_turan_audit.py
Run without Python's -O option, which disables assertions.
The family checker reconstructs its polynomial tables; it does not
trust the included JSON certificate as input. The independent audit
constructs the quartic from its roots and compares two exact methods.
The family_independent_report.json records a separate SymPy derivation.

PAPER
The PDF has 8 pages. The single TEX file embeds both main verifiers;
no external code files are required to compile it with pdfLaTeX.
The complete family coefficient table and 49 single-example integers
are in turan_theorem_certificate.json. SHA256SUMS covers all deliverables.

SCOPE
The counterexample sequence depends on K. No claim is made that a
single sequence fails at every K, that six is the earliest possible
failure order, or that the first five iterates are positive everywhere.
The theorem does not disprove the Riemann hypothesis, Branden's ordinary
coefficient theorem, or fixed-sequence eventual-positivity statements.
The mathematical certificate has passed independent exact computations.
Historical priority and external peer review have not been established.
