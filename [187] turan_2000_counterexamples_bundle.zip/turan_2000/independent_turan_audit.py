#!/usr/bin/env python3
"""Independent exact audit of a Csordas--Dimitrov Problem 3.1 counterexample.

Python standard library only. Run from any directory. The witness, rather than
another verifier, is the input: exp(x)*(x+100)^2*(x+10)^2. Two routes are compared:
(1) coefficient extraction and a triangular integer recurrence;
(2) expanded polynomials with exact +/-1 shifts, followed by Horner evaluation.

The script audits the mathematics of the witness, not bibliographic priority.
"""
from functools import lru_cache
from math import comb, factorial
from pathlib import Path
import json


def trim(p):
    while len(p) > 1 and p[-1] == 0:
        p.pop()
    return p


def multiply(p, q):
    out = [0] * (len(p) + len(q) - 1)
    for i, a in enumerate(p):
        for j, b in enumerate(q):
            out[i + j] += a * b
    return trim(out)


def subtract(p, q):
    return trim([(p[i] if i < len(p) else 0) -
                 (q[i] if i < len(q) else 0)
                 for i in range(max(len(p), len(q)))])


def shift(p, delta):
    out = [0] * len(p)
    for j, a in enumerate(p):
        for k in range(j + 1):
            out[k] += a * comb(j, k) * delta ** (j - k)
    return trim(out)


def evaluate(p, x):
    acc = 0
    for a in reversed(p):
        acc = acc * x + a
    return acc


def main():
    # The polynomial factor is constructed from its explicitly negative roots.
    factor = [1]
    for root_magnitude in (100, 100, 10, 10):
        factor = multiply(factor, [root_magnitude, 1])
    assert factor == [1000000, 220000, 14100, 220, 1]

    def gamma_by_egf(n):
        return sum(a * factorial(n) // factorial(n - j)
                   for j, a in enumerate(factor) if j <= n)

    quartic = [1000000, 206334, 13451, 214, 1]
    # A second derivation of the polynomial in n, using the falling factorial.
    falling = [1]
    derived = [0] * 5
    for j, a in enumerate(factor):
        if j:
            falling = multiply(falling, [-(j - 1), 1])
        for k, b in enumerate(falling):
            derived[k] += a * b
    assert derived == quartic
    assert all(gamma_by_egf(n) == evaluate(quartic, n) for n in range(101))

    @lru_cache(None)
    def triangular(r, n):
        assert n >= r >= 0
        if not r:
            return gamma_by_egf(n)
        return (triangular(r - 1, n) ** 2 -
                triangular(r - 1, n - 1) * triangular(r - 1, n + 1))

    polynomials = [quartic]
    for _ in range(6):
        p = polynomials[-1]
        polynomials.append(subtract(multiply(p, p),
                                    multiply(shift(p, -1), shift(p, 1))))
    assert [len(p) - 1 for p in polynomials] == [4, 6, 10, 18, 34, 66, 130]
    comparisons = 0
    for r, p in enumerate(polynomials):
        for n in range(r, 51):
            assert evaluate(p, n) == triangular(r, n)
            comparisons += 1
    value = triangular(6, 10)
    assert value < 0
    predecessors = [triangular(r, n)
                    for r in range(6) for n in range(4 + r, 17 - r)]
    assert len(predecessors) == 48 and all(v > 0 for v in predecessors)

    # Compact, purely integer sign certificate using fifth-row prefixes.
    # Each fifth-row value has 143 digits. Floors at 10^135 have eight digits.
    scale = 10 ** 135
    a, b, c = (triangular(5, n) for n in (9, 10, 11))
    lo_a, lo_b, lo_c = a // scale, b // scale, c // scale
    # b < (lo_b+1)*scale, a >= lo_a*scale, c >= lo_c*scale.
    assert (lo_b + 1) ** 2 < lo_a * lo_c

    report = {
        "status": "PASS",
        "witness": "exp(x)*(x+100)^2*(x+10)^2",
        "class_membership": {
            "LP_type_I_c": 1000000,
            "LP_type_I_sigma": 1,
            "LP_type_I_positive_x_j": [100, 100, 10, 10],
            "gamma_n_strictly_positive": "All five quartic coefficients are positive."
        },
        "quartic_ascending_coefficients": quartic,
        "EGF_coefficient_comparisons": 101,
        "polynomial_vs_triangle_comparisons": comparisons,
        "iteration_polynomial_degrees": [len(p) - 1 for p in polynomials],
        "all_48_dependency_predecessors_positive": True,
        "T6_at_10": str(value),
        "negative_integer_digits": len(str(-value)),
        "fifth_row_at_9_10_11": [str(a), str(b), str(c)],
        "compact_sign_certificate": {
            "scale": "10^135",
            "fifth_row_floor_prefixes": [lo_a, lo_b, lo_c],
            "upper_bound_for_middle_square_after_scaling": (lo_b + 1) ** 2,
            "lower_bound_for_neighbor_product_after_scaling": lo_a * lo_c,
            "strict_comparison": True
        },
        "source_scope": {
            "original": "Csordas--Dimitrov (2000), Problem 3.1, pp. 10--11 of author preprint",
            "url": "https://www.dcce.ibilce.unesp.br/~dimitrov/papers/vargana.pdf",
            "requirements": "gamma_k >= 0; EGF in LP type I; k >= n >= 2",
            "point_satisfies_index_restriction": "10 >= 6 >= 2",
            "additional_normalization": "None in Problem 3.1.",
            "later_restatement": "Branden, arXiv:0909.1927v3, Problem 8.1",
            "priority": "Not established by this audit."
        }
    }
    out = Path(__file__).with_name("independent_turan_audit_report.json")
    out.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
