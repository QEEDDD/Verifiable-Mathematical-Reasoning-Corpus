#!/usr/bin/env python3
"""Finite-polynomial multiplier-sequence counterexample, exact integers only.

Phi(x)=(1+x/50000)^50000*(x+100)^2*(x+10)^2.
All zeros are strictly negative. With gamma_j=j![x^j]Phi, we verify
T_6(10)<0 after the harmless geometric rescaling a_j=50000^j*gamma_j.
"""
from math import prod
from fractions import Fraction

N=50000
P=(1000000,220000,14100,220,1)
def falling(n,r):
    return prod(range(n-r+1,n+1)) if r<=n else 0

def coefficient(j):
    return sum(c*falling(j,r)*falling(N,j-r)*N**r
               for r,c in enumerate(P) if r<=j)

def verify():
    row=[coefficient(j) for j in range(4,17)]
    for r in range(1,6):
        row=[row[i]**2-row[i-1]*row[i+1] for i in range(1,len(row)-1)]
        if not all(c>0 for c in row):
            raise ArithmeticError('A lower dependency-window term is not positive')
    denominator=row[0]*row[2]
    last=row[1]**2-denominator
    if last>=0:raise ArithmeticError('Finite-polynomial counterexample failed')
    ratio=Fraction(last,denominator)
    # Small rational enclosure, independently meaningful without long integers.
    if not Fraction(-2,1000)<ratio<Fraction(-1,1000):
        raise ArithmeticError('Stated rational enclosure failed')
    print('PASS: degree50004 polynomial with only negative zeros has T6(10)<0.')
    print('Exact ratio T6(10)/(T5(9)*T5(11)) lies strictly between -2/1000 and -1/1000.')

if __name__=='__main__':verify()
