#!/usr/bin/env python3
"""Exact certificate: an iterated Turan counterexample at every center K>=6.

Uses only Python's standard library. Coefficient lists are in increasing
powers. The parameter K stays fixed when the sequence index changes.
The coefficient tables are generated, not read as trusted inputs.
"""
from math import comb, prod
from pathlib import Path
import json


def add(a, b):
    out = [0] * max(len(a), len(b))
    for i, c in enumerate(a):
        out[i] += c
    for i, c in enumerate(b):
        out[i] += c
    while len(out) > 1 and out[-1] == 0:
        out.pop()
    return out


def mul(a, b):
    out = [0] * (len(a) + len(b) - 1)
    for i, c in enumerate(a):
        for j, d in enumerate(b):
            out[i+j] += c*d
    while len(out) > 1 and out[-1] == 0:
        out.pop()
    return out


def sub(a, b):
    return add(a, [-c for c in b])


def evaluate(a, x):
    out = 0
    for c in reversed(a):
        out = out*x + c
    return out


def shift(a, h):
    return [sum(a[j]*comb(j, i)*h**(j-i)
                for j in range(i, len(a))) for i in range(len(a))]


def input_polynomial(c):
    # Coefficients of (x+10K)^2(x+K)^2 in powers of x.
    p = ([0,0,0,0,100], [0,0,0,220], [0,0,141], [0,22], [1])
    falling, ans = [1], [0]
    for j in range(5):
        ans = add(ans, mul(p[j], falling))
        falling = mul(falling, [c-j, 1])
    return ans


def gamma(j, K):
    p = (100*K**4, 220*K**3, 141*K**2, 22*K, 1)
    return sum(p[r]*prod(range(j-r+1, j+1))
               for r in range(min(j, 4)+1))


def integer_rows(K):
    row = [gamma(j, K) for j in range(K-6, K+7)]
    rows = [row]
    for r in range(6):
        row = [row[i]**2-row[i-1]*row[i+1]
               for i in range(1, len(row)-1)]
        rows.append(row)
    return rows


def verify():
    row = [input_polynomial(c) for c in range(-6, 7)]
    degrees = []
    lower_count = 0
    for r in range(1, 7):
        row = [sub(mul(row[i], row[i]), mul(row[i-1], row[i+1]))
               for i in range(1, len(row)-1)]
        degree_set = sorted(set(len(p)-1 for p in row))
        assert degree_set == [2+2**(r+1)]
        degrees.append(degree_set[0])
        if r <= 5:
            for p in row:
                assert all(c > 0 for c in shift(p, 6))
                lower_count += 1
    assert len(row) == 1 and len(row[0]) == 131
    coeff = row[0]
    shifted = shift(coeff, 6)
    assert all(c < 0 for c in shifted)
    assert lower_count == 35

    # Direct checks hold K fixed and move only the sequence index.
    for K in (6, 10, 37):
        rows = integer_rows(K)
        assert rows[-1][0] == evaluate(coeff, K)

    # A compact certificate for the single example K=10.
    rows = integer_rows(10)
    for j, value in zip(range(4, 17), rows[0]):
        assert value == j**4+214*j**3+13451*j**2+206334*j+1000000
    assert all(c > 0 for row in rows[:-1] for c in row)
    left, middle, right = rows[5]
    D = left*right
    V = middle**2-D
    assert V == rows[6][0] and D > 0
    assert -451*D < 100000*V < -450*D
    return {
        'family': 'exp(x)*(x+10*K)^2*(x+K)^2; integer K>=6',
        'degrees': degrees,
        'negative_coefficients_after_K_equals_t_plus_6': len(shifted),
        'positive_lower_window_polynomials': lower_count,
        'coefficients_in_K': coeff,
        'coefficients_in_K_minus_6': shifted,
        'K10_rows_starting_at_indices_4_through_10': rows,
        'K10_T6': V,
        'K10_ratio_denominator': D,
        'K10_ratio_bounds': ['-451/100000', '-450/100000'],
    }


if __name__ == '__main__':
    report = verify()
    path = Path(__file__).with_name('turan_theorem_certificate.json')
    path.write_text(json.dumps(report, indent=2)+'\n')
    print('PASS: all 131 shifted coefficients are strictly negative.')
    print('PASS: all 35 lower-window polynomials have positive coefficients.')
    print('PASS: direct fixed-parameter checks at K=6, 10, 37 agree.')
    print('PASS: exact K=10 ratio lies between -0.00451 and -0.00450.')
    print('Generated certificate:', path)
