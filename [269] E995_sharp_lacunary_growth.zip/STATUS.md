# Taisho R48: Erdős #995 / optimal universal growth theorem

**New sharper result:** Every L^p function, 1<p<∞, has mean absolute averages o(log^(1/p) N) for any measure-preserving sequence, with a quantitative truncated weak maximal bound. One fixed lacunary sequence of powers of two, independent of p and of g, admits a centered L^p function with limsup A_N/g(N)=∞ a.e. for every positive g=o(log^(1/p) N). For any nondecreasing positive g, the universal little-o conclusion holds iff liminf g(N)/log^(1/p)(N+1)>0.

**Numbered scope:** For p=2 this determines the optimal universal scale N sqrt(log N) in the growth-estimation clause. The example's proposed N sqrt(log log N) bound was already refuted by Ho; do not count rediscovery. This exact formulation also answers Ho v3's explicit order-without-epsilon question in the universal-gauge sense, not pointwise asymptotics for individual f or special sequences. Treat the original open-ended clause as an exact sharp-scale candidate pending independent mathematical and priority audit, rather than claiming a new answer to the already-resolved example. No external submission.

**Replay:** Run ./replay.sh (Python standard library) and sha256sum -c SHA256SUMS. The standalone English TeX contains complete analytical proofs.
