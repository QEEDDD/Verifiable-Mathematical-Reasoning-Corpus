#!/usr/bin/env python3
"""Finite exact checks of parameters and a toy dyadic upper-tail identity."""
from fractions import Fraction as Q


def stages(total=11):
    prefix, watermark, last_exponent = 0, 0, 0
    total_trials = 0
    direct_shared_windows = 0
    for s in range(1,total+1):
        t = 1 << (s-1)
        L = 1 << (2*t-1)
        d = 2*t+s-2
        assert Q(L,1<<d)==Q(1,t)
        assert prefix+1 == 1 << (t-1)
        stage_failure=Q(1)
        previous_log2 = (prefix+1).bit_length()-1
        for _ in range(t):
            ell = prefix+1
            start = watermark+1
            assert last_exponent < start
            last_exponent = start+(ell-1)*d
            choices = L-ell+1
            assert choices >= L//2
            firstbit = start+ell*d+1
            lastbit = start+(L+1)*d
            assert firstbit>watermark
            watermark = lastbit
            assert last_exponent < watermark
            assert ell*2 == (2*prefix+1)+1 <= L
            if s<=3:
                prob=1-(1-Q(1,1<<d))**choices
                assert prob>=Q(1,4*t)
                stage_failure*=1-prob
                for j in range(ell,L+1):
                    hit_range=(start+j*d+1,start+(j+1)*d)
                    for r in range(ell):
                        q=j-r
                        assert 1<=q<=L
                        assert hit_range==(start+(r+q)*d+1,start+(r+q+1)*d)
                        direct_shared_windows+=1
            else:
                # Endpoint checks cover containment of all intermediate integers.
                assert ell-(ell-1)==1 and L-0==L
                # Rational lower estimate for one trial by the first two
                # inclusion-exclusion terms.
                rho=Q(1,1<<d)
                assert choices*rho-choices*(choices-1)*rho*rho/2 >= Q(1,4*t)
            prefix=2*prefix+1
            total_trials+=1
        assert prefix+1==L
        if s<=3:
            assert 1-stage_failure>Q(1,5)
        # Neighboring final logarithms differ by at most a factor 3.
        if s>1:
            assert 3*previous_log2>=2*t-1
    print(f"Stage recurrence/disjointness: {total} stages, {total_trials} trials.")
    print(f"Exact Bernoulli calculations and all {direct_shared_windows} "
          "shared-window identities in stages 1--3.")


def upper_discrete():
    # At p=2, j^(-1/2)<=2/sqrt(j)-style telescoping is not needed:
    # group j by i^2 <= j < (i+1)^2, i>=1, then the block sum
    # is bounded by (2i+1)/i <= 3. This certifies the toy count.
    for H in range(1,300):
        total=Q(0)
        for i in range(1,H):
            lower=i*i
            upper=min((i+1)**2,H**2)
            total+=Q(max(0,upper-lower),i)
        assert total<=3*H
    print("Integrated dyadic-tail bound: exact p=2 block majorants for 299 cutoffs.")


if __name__=="__main__":
    stages()
    upper_discrete()
