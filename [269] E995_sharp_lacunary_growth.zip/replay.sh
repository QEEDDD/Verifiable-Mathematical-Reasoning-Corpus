#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
tmp=$(mktemp)
trap 'rm -f "$tmp"' EXIT HUP INT TERM
python3 check_E995.py > "$tmp"
diff -u replay.log "$tmp"
cat "$tmp"
